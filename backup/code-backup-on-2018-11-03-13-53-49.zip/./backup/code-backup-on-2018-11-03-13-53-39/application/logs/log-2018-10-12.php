<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-10-12 14:05:03 --> Config Class Initialized
INFO - 2018-10-12 14:05:03 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:05:03 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:05:03 --> Utf8 Class Initialized
INFO - 2018-10-12 14:05:03 --> URI Class Initialized
DEBUG - 2018-10-12 14:05:03 --> No URI present. Default controller set.
INFO - 2018-10-12 14:05:03 --> Router Class Initialized
INFO - 2018-10-12 14:05:03 --> Output Class Initialized
INFO - 2018-10-12 14:05:03 --> Security Class Initialized
DEBUG - 2018-10-12 14:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:05:03 --> CSRF cookie sent
INFO - 2018-10-12 14:05:03 --> Input Class Initialized
INFO - 2018-10-12 14:05:03 --> Language Class Initialized
INFO - 2018-10-12 14:05:03 --> Loader Class Initialized
INFO - 2018-10-12 14:05:03 --> Helper loaded: url_helper
INFO - 2018-10-12 14:05:03 --> Helper loaded: form_helper
INFO - 2018-10-12 14:05:03 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:05:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:05:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:05:03 --> User Agent Class Initialized
INFO - 2018-10-12 14:05:03 --> Controller Class Initialized
INFO - 2018-10-12 14:05:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:05:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:05:03 --> Pixel_Model class loaded
INFO - 2018-10-12 14:05:03 --> Database Driver Class Initialized
INFO - 2018-10-12 14:05:03 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:05:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:05:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:05:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-12 14:05:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:05:03 --> Final output sent to browser
DEBUG - 2018-10-12 14:05:03 --> Total execution time: 0.4480
INFO - 2018-10-12 14:05:09 --> Config Class Initialized
INFO - 2018-10-12 14:05:09 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:05:09 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:05:09 --> Utf8 Class Initialized
INFO - 2018-10-12 14:05:09 --> URI Class Initialized
INFO - 2018-10-12 14:05:09 --> Router Class Initialized
INFO - 2018-10-12 14:05:09 --> Output Class Initialized
INFO - 2018-10-12 14:05:09 --> Security Class Initialized
DEBUG - 2018-10-12 14:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:05:09 --> CSRF cookie sent
INFO - 2018-10-12 14:05:09 --> Input Class Initialized
INFO - 2018-10-12 14:05:09 --> Language Class Initialized
INFO - 2018-10-12 14:05:09 --> Loader Class Initialized
INFO - 2018-10-12 14:05:09 --> Helper loaded: url_helper
INFO - 2018-10-12 14:05:09 --> Helper loaded: form_helper
INFO - 2018-10-12 14:05:09 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:05:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:05:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:05:09 --> User Agent Class Initialized
INFO - 2018-10-12 14:05:09 --> Controller Class Initialized
INFO - 2018-10-12 14:05:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:05:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:05:09 --> Pixel_Model class loaded
INFO - 2018-10-12 14:05:09 --> Database Driver Class Initialized
INFO - 2018-10-12 14:05:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:05:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:05:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:05:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:05:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 14:05:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 14:05:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 14:05:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-10-12 14:05:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:05:09 --> Final output sent to browser
DEBUG - 2018-10-12 14:05:09 --> Total execution time: 0.0385
INFO - 2018-10-12 14:05:14 --> Config Class Initialized
INFO - 2018-10-12 14:05:14 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:05:14 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:05:14 --> Utf8 Class Initialized
INFO - 2018-10-12 14:05:14 --> URI Class Initialized
INFO - 2018-10-12 14:05:14 --> Router Class Initialized
INFO - 2018-10-12 14:05:14 --> Output Class Initialized
INFO - 2018-10-12 14:05:14 --> Security Class Initialized
DEBUG - 2018-10-12 14:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:05:14 --> CSRF cookie sent
INFO - 2018-10-12 14:05:14 --> CSRF token verified
INFO - 2018-10-12 14:05:14 --> Input Class Initialized
INFO - 2018-10-12 14:05:14 --> Language Class Initialized
INFO - 2018-10-12 14:05:14 --> Loader Class Initialized
INFO - 2018-10-12 14:05:14 --> Helper loaded: url_helper
INFO - 2018-10-12 14:05:14 --> Helper loaded: form_helper
INFO - 2018-10-12 14:05:14 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:05:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:05:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:05:14 --> User Agent Class Initialized
INFO - 2018-10-12 14:05:14 --> Controller Class Initialized
INFO - 2018-10-12 14:05:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:05:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:05:14 --> Pixel_Model class loaded
INFO - 2018-10-12 14:05:14 --> Database Driver Class Initialized
INFO - 2018-10-12 14:05:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:05:14 --> Database Driver Class Initialized
INFO - 2018-10-12 14:05:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:05:14 --> Config Class Initialized
INFO - 2018-10-12 14:05:14 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:05:14 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:05:14 --> Utf8 Class Initialized
INFO - 2018-10-12 14:05:14 --> URI Class Initialized
INFO - 2018-10-12 14:05:14 --> Router Class Initialized
INFO - 2018-10-12 14:05:14 --> Output Class Initialized
INFO - 2018-10-12 14:05:14 --> Security Class Initialized
DEBUG - 2018-10-12 14:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:05:14 --> CSRF cookie sent
INFO - 2018-10-12 14:05:14 --> Input Class Initialized
INFO - 2018-10-12 14:05:14 --> Language Class Initialized
INFO - 2018-10-12 14:05:14 --> Loader Class Initialized
INFO - 2018-10-12 14:05:14 --> Helper loaded: url_helper
INFO - 2018-10-12 14:05:14 --> Helper loaded: form_helper
INFO - 2018-10-12 14:05:14 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:05:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:05:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:05:14 --> User Agent Class Initialized
INFO - 2018-10-12 14:05:14 --> Controller Class Initialized
INFO - 2018-10-12 14:05:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:05:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:05:14 --> Pixel_Model class loaded
INFO - 2018-10-12 14:05:14 --> Database Driver Class Initialized
INFO - 2018-10-12 14:05:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:05:14 --> Database Driver Class Initialized
INFO - 2018-10-12 14:05:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:05:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:05:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:05:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:05:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 14:05:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 14:05:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 14:05:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-12 14:05:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:05:14 --> Final output sent to browser
DEBUG - 2018-10-12 14:05:14 --> Total execution time: 0.0484
INFO - 2018-10-12 14:05:20 --> Config Class Initialized
INFO - 2018-10-12 14:05:20 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:05:20 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:05:20 --> Utf8 Class Initialized
INFO - 2018-10-12 14:05:20 --> URI Class Initialized
INFO - 2018-10-12 14:05:20 --> Router Class Initialized
INFO - 2018-10-12 14:05:20 --> Output Class Initialized
INFO - 2018-10-12 14:05:20 --> Security Class Initialized
DEBUG - 2018-10-12 14:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:05:20 --> CSRF cookie sent
INFO - 2018-10-12 14:05:20 --> CSRF token verified
INFO - 2018-10-12 14:05:20 --> Input Class Initialized
INFO - 2018-10-12 14:05:20 --> Language Class Initialized
INFO - 2018-10-12 14:05:20 --> Loader Class Initialized
INFO - 2018-10-12 14:05:20 --> Helper loaded: url_helper
INFO - 2018-10-12 14:05:20 --> Helper loaded: form_helper
INFO - 2018-10-12 14:05:20 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:05:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:05:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:05:20 --> User Agent Class Initialized
INFO - 2018-10-12 14:05:20 --> Controller Class Initialized
INFO - 2018-10-12 14:05:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:05:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:05:20 --> Pixel_Model class loaded
INFO - 2018-10-12 14:05:20 --> Database Driver Class Initialized
INFO - 2018-10-12 14:05:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:05:20 --> Form Validation Class Initialized
INFO - 2018-10-12 14:05:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-12 14:05:20 --> Database Driver Class Initialized
INFO - 2018-10-12 14:05:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:05:20 --> Config Class Initialized
INFO - 2018-10-12 14:05:20 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:05:20 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:05:20 --> Utf8 Class Initialized
INFO - 2018-10-12 14:05:20 --> URI Class Initialized
INFO - 2018-10-12 14:05:20 --> Router Class Initialized
INFO - 2018-10-12 14:05:20 --> Output Class Initialized
INFO - 2018-10-12 14:05:20 --> Security Class Initialized
DEBUG - 2018-10-12 14:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:05:20 --> CSRF cookie sent
INFO - 2018-10-12 14:05:20 --> Input Class Initialized
INFO - 2018-10-12 14:05:20 --> Language Class Initialized
INFO - 2018-10-12 14:05:20 --> Loader Class Initialized
INFO - 2018-10-12 14:05:20 --> Helper loaded: url_helper
INFO - 2018-10-12 14:05:20 --> Helper loaded: form_helper
INFO - 2018-10-12 14:05:20 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:05:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:05:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:05:20 --> User Agent Class Initialized
INFO - 2018-10-12 14:05:20 --> Controller Class Initialized
INFO - 2018-10-12 14:05:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:05:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:05:20 --> Pixel_Model class loaded
INFO - 2018-10-12 14:05:20 --> Database Driver Class Initialized
INFO - 2018-10-12 14:05:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:05:20 --> Database Driver Class Initialized
INFO - 2018-10-12 14:05:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:05:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:05:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:05:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:05:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 14:05:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 14:05:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 14:05:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-10-12 14:05:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:05:20 --> Final output sent to browser
DEBUG - 2018-10-12 14:05:20 --> Total execution time: 0.0463
INFO - 2018-10-12 14:05:23 --> Config Class Initialized
INFO - 2018-10-12 14:05:23 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:05:23 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:05:23 --> Utf8 Class Initialized
INFO - 2018-10-12 14:05:23 --> URI Class Initialized
INFO - 2018-10-12 14:05:23 --> Router Class Initialized
INFO - 2018-10-12 14:05:23 --> Output Class Initialized
INFO - 2018-10-12 14:05:23 --> Security Class Initialized
DEBUG - 2018-10-12 14:05:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:05:23 --> CSRF cookie sent
INFO - 2018-10-12 14:05:23 --> Input Class Initialized
INFO - 2018-10-12 14:05:23 --> Language Class Initialized
INFO - 2018-10-12 14:05:23 --> Loader Class Initialized
INFO - 2018-10-12 14:05:23 --> Helper loaded: url_helper
INFO - 2018-10-12 14:05:23 --> Helper loaded: form_helper
INFO - 2018-10-12 14:05:23 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:05:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:05:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:05:23 --> User Agent Class Initialized
INFO - 2018-10-12 14:05:23 --> Controller Class Initialized
INFO - 2018-10-12 14:05:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:05:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:05:23 --> Pixel_Model class loaded
INFO - 2018-10-12 14:05:23 --> Database Driver Class Initialized
INFO - 2018-10-12 14:05:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:05:23 --> Database Driver Class Initialized
INFO - 2018-10-12 14:05:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:05:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:05:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:05:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:05:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 14:05:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/save_exit.php
INFO - 2018-10-12 14:05:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:05:23 --> Final output sent to browser
DEBUG - 2018-10-12 14:05:23 --> Total execution time: 0.0477
INFO - 2018-10-12 14:07:23 --> Config Class Initialized
INFO - 2018-10-12 14:07:23 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:07:23 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:07:23 --> Utf8 Class Initialized
INFO - 2018-10-12 14:07:23 --> URI Class Initialized
INFO - 2018-10-12 14:07:23 --> Router Class Initialized
INFO - 2018-10-12 14:07:23 --> Output Class Initialized
INFO - 2018-10-12 14:07:23 --> Security Class Initialized
DEBUG - 2018-10-12 14:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:07:23 --> CSRF cookie sent
INFO - 2018-10-12 14:07:23 --> Input Class Initialized
INFO - 2018-10-12 14:07:23 --> Language Class Initialized
INFO - 2018-10-12 14:07:23 --> Loader Class Initialized
INFO - 2018-10-12 14:07:23 --> Helper loaded: url_helper
INFO - 2018-10-12 14:07:23 --> Helper loaded: form_helper
INFO - 2018-10-12 14:07:23 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:07:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:07:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:07:23 --> User Agent Class Initialized
INFO - 2018-10-12 14:07:23 --> Controller Class Initialized
INFO - 2018-10-12 14:07:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:07:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:07:23 --> Pixel_Model class loaded
INFO - 2018-10-12 14:07:23 --> Database Driver Class Initialized
INFO - 2018-10-12 14:07:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:07:23 --> Database Driver Class Initialized
INFO - 2018-10-12 14:07:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:07:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:07:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:07:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:07:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 14:07:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/save_exit.php
INFO - 2018-10-12 14:07:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:07:23 --> Final output sent to browser
DEBUG - 2018-10-12 14:07:23 --> Total execution time: 0.0452
INFO - 2018-10-12 14:07:26 --> Config Class Initialized
INFO - 2018-10-12 14:07:26 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:07:26 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:07:26 --> Utf8 Class Initialized
INFO - 2018-10-12 14:07:26 --> URI Class Initialized
INFO - 2018-10-12 14:07:26 --> Router Class Initialized
INFO - 2018-10-12 14:07:26 --> Output Class Initialized
INFO - 2018-10-12 14:07:26 --> Security Class Initialized
DEBUG - 2018-10-12 14:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:07:26 --> CSRF cookie sent
INFO - 2018-10-12 14:07:26 --> Input Class Initialized
INFO - 2018-10-12 14:07:26 --> Language Class Initialized
INFO - 2018-10-12 14:07:26 --> Loader Class Initialized
INFO - 2018-10-12 14:07:26 --> Helper loaded: url_helper
INFO - 2018-10-12 14:07:26 --> Helper loaded: form_helper
INFO - 2018-10-12 14:07:26 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:07:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:07:26 --> User Agent Class Initialized
INFO - 2018-10-12 14:07:26 --> Controller Class Initialized
INFO - 2018-10-12 14:07:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:07:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:07:26 --> Pixel_Model class loaded
INFO - 2018-10-12 14:07:26 --> Database Driver Class Initialized
INFO - 2018-10-12 14:07:26 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:07:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:07:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:07:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:07:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 14:07:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 14:07:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 14:07:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-10-12 14:07:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:07:26 --> Final output sent to browser
DEBUG - 2018-10-12 14:07:26 --> Total execution time: 0.0385
INFO - 2018-10-12 14:07:27 --> Config Class Initialized
INFO - 2018-10-12 14:07:27 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:07:27 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:07:27 --> Utf8 Class Initialized
INFO - 2018-10-12 14:07:27 --> URI Class Initialized
INFO - 2018-10-12 14:07:27 --> Router Class Initialized
INFO - 2018-10-12 14:07:27 --> Output Class Initialized
INFO - 2018-10-12 14:07:27 --> Security Class Initialized
DEBUG - 2018-10-12 14:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:07:27 --> CSRF cookie sent
INFO - 2018-10-12 14:07:27 --> CSRF token verified
INFO - 2018-10-12 14:07:27 --> Input Class Initialized
INFO - 2018-10-12 14:07:27 --> Language Class Initialized
INFO - 2018-10-12 14:07:27 --> Loader Class Initialized
INFO - 2018-10-12 14:07:27 --> Helper loaded: url_helper
INFO - 2018-10-12 14:07:27 --> Helper loaded: form_helper
INFO - 2018-10-12 14:07:27 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:07:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:07:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:07:27 --> User Agent Class Initialized
INFO - 2018-10-12 14:07:27 --> Controller Class Initialized
INFO - 2018-10-12 14:07:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:07:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:07:27 --> Pixel_Model class loaded
INFO - 2018-10-12 14:07:27 --> Database Driver Class Initialized
INFO - 2018-10-12 14:07:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:07:27 --> Database Driver Class Initialized
INFO - 2018-10-12 14:07:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:07:27 --> Config Class Initialized
INFO - 2018-10-12 14:07:27 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:07:27 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:07:27 --> Utf8 Class Initialized
INFO - 2018-10-12 14:07:27 --> URI Class Initialized
INFO - 2018-10-12 14:07:27 --> Router Class Initialized
INFO - 2018-10-12 14:07:27 --> Output Class Initialized
INFO - 2018-10-12 14:07:27 --> Security Class Initialized
DEBUG - 2018-10-12 14:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:07:27 --> CSRF cookie sent
INFO - 2018-10-12 14:07:27 --> Input Class Initialized
INFO - 2018-10-12 14:07:27 --> Language Class Initialized
INFO - 2018-10-12 14:07:27 --> Loader Class Initialized
INFO - 2018-10-12 14:07:27 --> Helper loaded: url_helper
INFO - 2018-10-12 14:07:27 --> Helper loaded: form_helper
INFO - 2018-10-12 14:07:27 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:07:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:07:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:07:27 --> User Agent Class Initialized
INFO - 2018-10-12 14:07:28 --> Controller Class Initialized
INFO - 2018-10-12 14:07:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:07:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:07:28 --> Pixel_Model class loaded
INFO - 2018-10-12 14:07:28 --> Database Driver Class Initialized
INFO - 2018-10-12 14:07:28 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:07:28 --> Database Driver Class Initialized
INFO - 2018-10-12 14:07:28 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:07:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:07:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:07:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:07:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 14:07:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 14:07:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 14:07:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-10-12 14:07:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:07:28 --> Final output sent to browser
DEBUG - 2018-10-12 14:07:28 --> Total execution time: 0.0459
INFO - 2018-10-12 14:07:29 --> Config Class Initialized
INFO - 2018-10-12 14:07:29 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:07:29 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:07:29 --> Utf8 Class Initialized
INFO - 2018-10-12 14:07:29 --> URI Class Initialized
INFO - 2018-10-12 14:07:29 --> Router Class Initialized
INFO - 2018-10-12 14:07:29 --> Output Class Initialized
INFO - 2018-10-12 14:07:29 --> Security Class Initialized
DEBUG - 2018-10-12 14:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:07:29 --> CSRF cookie sent
INFO - 2018-10-12 14:07:29 --> Input Class Initialized
INFO - 2018-10-12 14:07:29 --> Language Class Initialized
INFO - 2018-10-12 14:07:29 --> Loader Class Initialized
INFO - 2018-10-12 14:07:29 --> Helper loaded: url_helper
INFO - 2018-10-12 14:07:29 --> Helper loaded: form_helper
INFO - 2018-10-12 14:07:29 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:07:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:07:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:07:29 --> User Agent Class Initialized
INFO - 2018-10-12 14:07:29 --> Controller Class Initialized
INFO - 2018-10-12 14:07:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:07:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:07:29 --> Pixel_Model class loaded
INFO - 2018-10-12 14:07:29 --> Database Driver Class Initialized
INFO - 2018-10-12 14:07:29 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:07:29 --> Database Driver Class Initialized
INFO - 2018-10-12 14:07:29 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:07:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:07:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:07:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:07:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 14:07:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/save_exit.php
INFO - 2018-10-12 14:07:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:07:29 --> Final output sent to browser
DEBUG - 2018-10-12 14:07:29 --> Total execution time: 0.0523
INFO - 2018-10-12 14:08:06 --> Config Class Initialized
INFO - 2018-10-12 14:08:06 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:08:06 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:08:06 --> Utf8 Class Initialized
INFO - 2018-10-12 14:08:06 --> URI Class Initialized
INFO - 2018-10-12 14:08:06 --> Router Class Initialized
INFO - 2018-10-12 14:08:06 --> Output Class Initialized
INFO - 2018-10-12 14:08:06 --> Security Class Initialized
DEBUG - 2018-10-12 14:08:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:08:06 --> CSRF cookie sent
INFO - 2018-10-12 14:08:06 --> Input Class Initialized
INFO - 2018-10-12 14:08:06 --> Language Class Initialized
INFO - 2018-10-12 14:08:06 --> Loader Class Initialized
INFO - 2018-10-12 14:08:06 --> Helper loaded: url_helper
INFO - 2018-10-12 14:08:06 --> Helper loaded: form_helper
INFO - 2018-10-12 14:08:06 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:08:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:08:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:08:06 --> User Agent Class Initialized
INFO - 2018-10-12 14:08:06 --> Controller Class Initialized
INFO - 2018-10-12 14:08:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:08:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:08:06 --> Pixel_Model class loaded
INFO - 2018-10-12 14:08:06 --> Database Driver Class Initialized
INFO - 2018-10-12 14:08:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:08:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:08:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:08:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:08:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 14:08:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 14:08:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 14:08:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-10-12 14:08:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:08:06 --> Final output sent to browser
DEBUG - 2018-10-12 14:08:06 --> Total execution time: 0.0609
INFO - 2018-10-12 14:08:08 --> Config Class Initialized
INFO - 2018-10-12 14:08:08 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:08:08 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:08:08 --> Utf8 Class Initialized
INFO - 2018-10-12 14:08:08 --> URI Class Initialized
INFO - 2018-10-12 14:08:08 --> Router Class Initialized
INFO - 2018-10-12 14:08:08 --> Output Class Initialized
INFO - 2018-10-12 14:08:08 --> Security Class Initialized
DEBUG - 2018-10-12 14:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:08:08 --> CSRF cookie sent
INFO - 2018-10-12 14:08:08 --> CSRF token verified
INFO - 2018-10-12 14:08:08 --> Input Class Initialized
INFO - 2018-10-12 14:08:08 --> Language Class Initialized
INFO - 2018-10-12 14:08:08 --> Loader Class Initialized
INFO - 2018-10-12 14:08:08 --> Helper loaded: url_helper
INFO - 2018-10-12 14:08:08 --> Helper loaded: form_helper
INFO - 2018-10-12 14:08:08 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:08:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:08:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:08:08 --> User Agent Class Initialized
INFO - 2018-10-12 14:08:08 --> Controller Class Initialized
INFO - 2018-10-12 14:08:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:08:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:08:08 --> Pixel_Model class loaded
INFO - 2018-10-12 14:08:08 --> Database Driver Class Initialized
INFO - 2018-10-12 14:08:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:08:08 --> Database Driver Class Initialized
INFO - 2018-10-12 14:08:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:08:09 --> Config Class Initialized
INFO - 2018-10-12 14:08:09 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:08:09 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:08:09 --> Utf8 Class Initialized
INFO - 2018-10-12 14:08:09 --> URI Class Initialized
INFO - 2018-10-12 14:08:09 --> Router Class Initialized
INFO - 2018-10-12 14:08:09 --> Output Class Initialized
INFO - 2018-10-12 14:08:09 --> Security Class Initialized
DEBUG - 2018-10-12 14:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:08:09 --> CSRF cookie sent
INFO - 2018-10-12 14:08:09 --> Input Class Initialized
INFO - 2018-10-12 14:08:09 --> Language Class Initialized
INFO - 2018-10-12 14:08:09 --> Loader Class Initialized
INFO - 2018-10-12 14:08:09 --> Helper loaded: url_helper
INFO - 2018-10-12 14:08:09 --> Helper loaded: form_helper
INFO - 2018-10-12 14:08:09 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:08:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:08:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:08:09 --> User Agent Class Initialized
INFO - 2018-10-12 14:08:09 --> Controller Class Initialized
INFO - 2018-10-12 14:08:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:08:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:08:09 --> Pixel_Model class loaded
INFO - 2018-10-12 14:08:09 --> Database Driver Class Initialized
INFO - 2018-10-12 14:08:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:08:09 --> Database Driver Class Initialized
INFO - 2018-10-12 14:08:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:08:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:08:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:08:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:08:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 14:08:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 14:08:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 14:08:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-10-12 14:08:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:08:09 --> Final output sent to browser
DEBUG - 2018-10-12 14:08:09 --> Total execution time: 0.0419
INFO - 2018-10-12 14:08:12 --> Config Class Initialized
INFO - 2018-10-12 14:08:12 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:08:12 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:08:12 --> Utf8 Class Initialized
INFO - 2018-10-12 14:08:12 --> URI Class Initialized
INFO - 2018-10-12 14:08:12 --> Router Class Initialized
INFO - 2018-10-12 14:08:12 --> Output Class Initialized
INFO - 2018-10-12 14:08:12 --> Security Class Initialized
DEBUG - 2018-10-12 14:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:08:12 --> CSRF cookie sent
INFO - 2018-10-12 14:08:12 --> Input Class Initialized
INFO - 2018-10-12 14:08:12 --> Language Class Initialized
INFO - 2018-10-12 14:08:12 --> Loader Class Initialized
INFO - 2018-10-12 14:08:12 --> Helper loaded: url_helper
INFO - 2018-10-12 14:08:12 --> Helper loaded: form_helper
INFO - 2018-10-12 14:08:12 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:08:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:08:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:08:12 --> User Agent Class Initialized
INFO - 2018-10-12 14:08:12 --> Controller Class Initialized
INFO - 2018-10-12 14:08:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:08:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:08:12 --> Pixel_Model class loaded
INFO - 2018-10-12 14:08:12 --> Database Driver Class Initialized
INFO - 2018-10-12 14:08:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:08:12 --> Database Driver Class Initialized
INFO - 2018-10-12 14:08:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:08:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:08:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:08:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:08:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 14:08:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/save_exit.php
INFO - 2018-10-12 14:08:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:08:12 --> Final output sent to browser
DEBUG - 2018-10-12 14:08:12 --> Total execution time: 0.0464
INFO - 2018-10-12 14:08:13 --> Config Class Initialized
INFO - 2018-10-12 14:08:13 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:08:13 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:08:13 --> Utf8 Class Initialized
INFO - 2018-10-12 14:08:13 --> URI Class Initialized
INFO - 2018-10-12 14:08:13 --> Router Class Initialized
INFO - 2018-10-12 14:08:13 --> Output Class Initialized
INFO - 2018-10-12 14:08:13 --> Security Class Initialized
DEBUG - 2018-10-12 14:08:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:08:13 --> CSRF cookie sent
INFO - 2018-10-12 14:08:13 --> Input Class Initialized
INFO - 2018-10-12 14:08:13 --> Language Class Initialized
INFO - 2018-10-12 14:08:13 --> Loader Class Initialized
INFO - 2018-10-12 14:08:13 --> Helper loaded: url_helper
INFO - 2018-10-12 14:08:13 --> Helper loaded: form_helper
INFO - 2018-10-12 14:08:13 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:08:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:08:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:08:13 --> User Agent Class Initialized
INFO - 2018-10-12 14:08:13 --> Controller Class Initialized
INFO - 2018-10-12 14:08:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:08:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:08:13 --> Pixel_Model class loaded
INFO - 2018-10-12 14:08:13 --> Database Driver Class Initialized
INFO - 2018-10-12 14:08:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:08:13 --> Database Driver Class Initialized
INFO - 2018-10-12 14:08:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:08:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:08:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:08:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:08:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 14:08:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 14:08:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 14:08:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-10-12 14:08:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:08:13 --> Final output sent to browser
DEBUG - 2018-10-12 14:08:13 --> Total execution time: 0.0477
INFO - 2018-10-12 14:08:17 --> Config Class Initialized
INFO - 2018-10-12 14:08:17 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:08:17 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:08:17 --> Utf8 Class Initialized
INFO - 2018-10-12 14:08:17 --> URI Class Initialized
INFO - 2018-10-12 14:08:17 --> Router Class Initialized
INFO - 2018-10-12 14:08:17 --> Output Class Initialized
INFO - 2018-10-12 14:08:17 --> Security Class Initialized
DEBUG - 2018-10-12 14:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:08:17 --> CSRF cookie sent
INFO - 2018-10-12 14:08:17 --> Input Class Initialized
INFO - 2018-10-12 14:08:17 --> Language Class Initialized
INFO - 2018-10-12 14:08:17 --> Loader Class Initialized
INFO - 2018-10-12 14:08:17 --> Helper loaded: url_helper
INFO - 2018-10-12 14:08:17 --> Helper loaded: form_helper
INFO - 2018-10-12 14:08:17 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:08:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:08:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:08:17 --> User Agent Class Initialized
INFO - 2018-10-12 14:08:17 --> Controller Class Initialized
INFO - 2018-10-12 14:08:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:08:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:08:17 --> Pixel_Model class loaded
INFO - 2018-10-12 14:08:17 --> Database Driver Class Initialized
INFO - 2018-10-12 14:08:17 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:08:17 --> Database Driver Class Initialized
INFO - 2018-10-12 14:08:17 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:08:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:08:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:08:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:08:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 14:08:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/save_exit.php
INFO - 2018-10-12 14:08:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:08:17 --> Final output sent to browser
DEBUG - 2018-10-12 14:08:17 --> Total execution time: 0.0616
INFO - 2018-10-12 14:08:18 --> Config Class Initialized
INFO - 2018-10-12 14:08:18 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:08:18 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:08:18 --> Utf8 Class Initialized
INFO - 2018-10-12 14:08:18 --> URI Class Initialized
INFO - 2018-10-12 14:08:18 --> Router Class Initialized
INFO - 2018-10-12 14:08:18 --> Output Class Initialized
INFO - 2018-10-12 14:08:18 --> Security Class Initialized
DEBUG - 2018-10-12 14:08:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:08:18 --> CSRF cookie sent
INFO - 2018-10-12 14:08:18 --> Input Class Initialized
INFO - 2018-10-12 14:08:18 --> Language Class Initialized
INFO - 2018-10-12 14:08:18 --> Loader Class Initialized
INFO - 2018-10-12 14:08:18 --> Helper loaded: url_helper
INFO - 2018-10-12 14:08:18 --> Helper loaded: form_helper
INFO - 2018-10-12 14:08:18 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:08:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:08:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:08:18 --> User Agent Class Initialized
INFO - 2018-10-12 14:08:18 --> Controller Class Initialized
INFO - 2018-10-12 14:08:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:08:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:08:18 --> Pixel_Model class loaded
INFO - 2018-10-12 14:08:18 --> Database Driver Class Initialized
INFO - 2018-10-12 14:08:18 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:08:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:08:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:08:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:08:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 14:08:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/contact_us.php
INFO - 2018-10-12 14:08:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:08:18 --> Final output sent to browser
DEBUG - 2018-10-12 14:08:18 --> Total execution time: 0.0457
INFO - 2018-10-12 14:08:21 --> Config Class Initialized
INFO - 2018-10-12 14:08:21 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:08:21 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:08:21 --> Utf8 Class Initialized
INFO - 2018-10-12 14:08:21 --> URI Class Initialized
DEBUG - 2018-10-12 14:08:21 --> No URI present. Default controller set.
INFO - 2018-10-12 14:08:21 --> Router Class Initialized
INFO - 2018-10-12 14:08:21 --> Output Class Initialized
INFO - 2018-10-12 14:08:21 --> Security Class Initialized
DEBUG - 2018-10-12 14:08:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:08:21 --> CSRF cookie sent
INFO - 2018-10-12 14:08:21 --> Input Class Initialized
INFO - 2018-10-12 14:08:21 --> Language Class Initialized
INFO - 2018-10-12 14:08:21 --> Loader Class Initialized
INFO - 2018-10-12 14:08:21 --> Helper loaded: url_helper
INFO - 2018-10-12 14:08:21 --> Helper loaded: form_helper
INFO - 2018-10-12 14:08:21 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:08:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:08:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:08:21 --> User Agent Class Initialized
INFO - 2018-10-12 14:08:21 --> Controller Class Initialized
INFO - 2018-10-12 14:08:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:08:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:08:21 --> Pixel_Model class loaded
INFO - 2018-10-12 14:08:21 --> Database Driver Class Initialized
INFO - 2018-10-12 14:08:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:08:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:08:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:08:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-12 14:08:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:08:21 --> Final output sent to browser
DEBUG - 2018-10-12 14:08:21 --> Total execution time: 0.0417
INFO - 2018-10-12 14:09:54 --> Config Class Initialized
INFO - 2018-10-12 14:09:54 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:09:54 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:09:54 --> Utf8 Class Initialized
INFO - 2018-10-12 14:09:54 --> URI Class Initialized
DEBUG - 2018-10-12 14:09:54 --> No URI present. Default controller set.
INFO - 2018-10-12 14:09:54 --> Router Class Initialized
INFO - 2018-10-12 14:09:54 --> Output Class Initialized
INFO - 2018-10-12 14:09:54 --> Security Class Initialized
DEBUG - 2018-10-12 14:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:09:54 --> CSRF cookie sent
INFO - 2018-10-12 14:09:54 --> Input Class Initialized
INFO - 2018-10-12 14:09:54 --> Language Class Initialized
INFO - 2018-10-12 14:09:54 --> Loader Class Initialized
INFO - 2018-10-12 14:09:54 --> Helper loaded: url_helper
INFO - 2018-10-12 14:09:54 --> Helper loaded: form_helper
INFO - 2018-10-12 14:09:54 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:09:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:09:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:09:54 --> User Agent Class Initialized
INFO - 2018-10-12 14:09:54 --> Controller Class Initialized
INFO - 2018-10-12 14:09:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:09:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:09:54 --> Pixel_Model class loaded
INFO - 2018-10-12 14:09:54 --> Database Driver Class Initialized
INFO - 2018-10-12 14:09:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:09:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:09:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:09:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-12 14:09:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:09:54 --> Final output sent to browser
DEBUG - 2018-10-12 14:09:54 --> Total execution time: 0.0531
INFO - 2018-10-12 14:10:03 --> Config Class Initialized
INFO - 2018-10-12 14:10:03 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:10:03 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:10:03 --> Utf8 Class Initialized
INFO - 2018-10-12 14:10:03 --> URI Class Initialized
INFO - 2018-10-12 14:10:03 --> Router Class Initialized
INFO - 2018-10-12 14:10:03 --> Output Class Initialized
INFO - 2018-10-12 14:10:03 --> Security Class Initialized
DEBUG - 2018-10-12 14:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:10:03 --> CSRF cookie sent
INFO - 2018-10-12 14:10:03 --> Input Class Initialized
INFO - 2018-10-12 14:10:03 --> Language Class Initialized
INFO - 2018-10-12 14:10:03 --> Loader Class Initialized
INFO - 2018-10-12 14:10:03 --> Helper loaded: url_helper
INFO - 2018-10-12 14:10:03 --> Helper loaded: form_helper
INFO - 2018-10-12 14:10:03 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:10:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:10:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:10:03 --> User Agent Class Initialized
INFO - 2018-10-12 14:10:03 --> Controller Class Initialized
INFO - 2018-10-12 14:10:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:10:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:10:03 --> Pixel_Model class loaded
INFO - 2018-10-12 14:10:03 --> Database Driver Class Initialized
INFO - 2018-10-12 14:10:03 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:10:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:10:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:10:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:10:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 14:10:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 14:10:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 14:10:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-10-12 14:10:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:10:03 --> Final output sent to browser
DEBUG - 2018-10-12 14:10:03 --> Total execution time: 0.0574
INFO - 2018-10-12 14:10:05 --> Config Class Initialized
INFO - 2018-10-12 14:10:05 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:10:05 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:10:05 --> Utf8 Class Initialized
INFO - 2018-10-12 14:10:05 --> URI Class Initialized
INFO - 2018-10-12 14:10:05 --> Router Class Initialized
INFO - 2018-10-12 14:10:05 --> Output Class Initialized
INFO - 2018-10-12 14:10:05 --> Security Class Initialized
DEBUG - 2018-10-12 14:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:10:05 --> CSRF cookie sent
INFO - 2018-10-12 14:10:05 --> CSRF token verified
INFO - 2018-10-12 14:10:05 --> Input Class Initialized
INFO - 2018-10-12 14:10:05 --> Language Class Initialized
INFO - 2018-10-12 14:10:05 --> Loader Class Initialized
INFO - 2018-10-12 14:10:05 --> Helper loaded: url_helper
INFO - 2018-10-12 14:10:05 --> Helper loaded: form_helper
INFO - 2018-10-12 14:10:05 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:10:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:10:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:10:05 --> User Agent Class Initialized
INFO - 2018-10-12 14:10:05 --> Controller Class Initialized
INFO - 2018-10-12 14:10:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:10:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:10:05 --> Pixel_Model class loaded
INFO - 2018-10-12 14:10:05 --> Database Driver Class Initialized
INFO - 2018-10-12 14:10:05 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:10:05 --> Database Driver Class Initialized
INFO - 2018-10-12 14:10:05 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:10:05 --> Config Class Initialized
INFO - 2018-10-12 14:10:05 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:10:05 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:10:05 --> Utf8 Class Initialized
INFO - 2018-10-12 14:10:05 --> URI Class Initialized
INFO - 2018-10-12 14:10:05 --> Router Class Initialized
INFO - 2018-10-12 14:10:05 --> Output Class Initialized
INFO - 2018-10-12 14:10:05 --> Security Class Initialized
DEBUG - 2018-10-12 14:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:10:05 --> CSRF cookie sent
INFO - 2018-10-12 14:10:05 --> Input Class Initialized
INFO - 2018-10-12 14:10:05 --> Language Class Initialized
INFO - 2018-10-12 14:10:05 --> Loader Class Initialized
INFO - 2018-10-12 14:10:05 --> Helper loaded: url_helper
INFO - 2018-10-12 14:10:05 --> Helper loaded: form_helper
INFO - 2018-10-12 14:10:05 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:10:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:10:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:10:05 --> User Agent Class Initialized
INFO - 2018-10-12 14:10:05 --> Controller Class Initialized
INFO - 2018-10-12 14:10:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:10:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:10:05 --> Pixel_Model class loaded
INFO - 2018-10-12 14:10:05 --> Database Driver Class Initialized
INFO - 2018-10-12 14:10:05 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:10:05 --> Database Driver Class Initialized
INFO - 2018-10-12 14:10:05 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:10:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:10:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:10:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:10:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 14:10:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 14:10:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 14:10:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-10-12 14:10:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:10:05 --> Final output sent to browser
DEBUG - 2018-10-12 14:10:05 --> Total execution time: 0.0466
INFO - 2018-10-12 14:10:07 --> Config Class Initialized
INFO - 2018-10-12 14:10:07 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:10:07 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:10:07 --> Utf8 Class Initialized
INFO - 2018-10-12 14:10:07 --> URI Class Initialized
INFO - 2018-10-12 14:10:07 --> Router Class Initialized
INFO - 2018-10-12 14:10:07 --> Output Class Initialized
INFO - 2018-10-12 14:10:07 --> Security Class Initialized
DEBUG - 2018-10-12 14:10:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:10:07 --> CSRF cookie sent
INFO - 2018-10-12 14:10:07 --> Input Class Initialized
INFO - 2018-10-12 14:10:07 --> Language Class Initialized
INFO - 2018-10-12 14:10:07 --> Loader Class Initialized
INFO - 2018-10-12 14:10:07 --> Helper loaded: url_helper
INFO - 2018-10-12 14:10:07 --> Helper loaded: form_helper
INFO - 2018-10-12 14:10:07 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:10:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:10:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:10:07 --> User Agent Class Initialized
INFO - 2018-10-12 14:10:08 --> Controller Class Initialized
INFO - 2018-10-12 14:10:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:10:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:10:08 --> Pixel_Model class loaded
INFO - 2018-10-12 14:10:08 --> Database Driver Class Initialized
INFO - 2018-10-12 14:10:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:10:08 --> Database Driver Class Initialized
INFO - 2018-10-12 14:10:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:10:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:10:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:10:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:10:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 14:10:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/save_exit.php
INFO - 2018-10-12 14:10:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:10:08 --> Final output sent to browser
DEBUG - 2018-10-12 14:10:08 --> Total execution time: 0.0459
INFO - 2018-10-12 14:10:11 --> Config Class Initialized
INFO - 2018-10-12 14:10:11 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:10:11 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:10:11 --> Utf8 Class Initialized
INFO - 2018-10-12 14:10:11 --> URI Class Initialized
INFO - 2018-10-12 14:10:11 --> Router Class Initialized
INFO - 2018-10-12 14:10:11 --> Output Class Initialized
INFO - 2018-10-12 14:10:11 --> Security Class Initialized
DEBUG - 2018-10-12 14:10:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:10:11 --> CSRF cookie sent
INFO - 2018-10-12 14:10:11 --> Input Class Initialized
INFO - 2018-10-12 14:10:11 --> Language Class Initialized
ERROR - 2018-10-12 14:10:11 --> 404 Page Not Found: Assets/css
INFO - 2018-10-12 14:11:50 --> Config Class Initialized
INFO - 2018-10-12 14:11:50 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:11:50 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:11:50 --> Utf8 Class Initialized
INFO - 2018-10-12 14:11:50 --> URI Class Initialized
INFO - 2018-10-12 14:11:50 --> Router Class Initialized
INFO - 2018-10-12 14:11:50 --> Output Class Initialized
INFO - 2018-10-12 14:11:50 --> Security Class Initialized
DEBUG - 2018-10-12 14:11:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:11:50 --> CSRF cookie sent
INFO - 2018-10-12 14:11:50 --> Input Class Initialized
INFO - 2018-10-12 14:11:50 --> Language Class Initialized
INFO - 2018-10-12 14:11:50 --> Loader Class Initialized
INFO - 2018-10-12 14:11:50 --> Helper loaded: url_helper
INFO - 2018-10-12 14:11:50 --> Helper loaded: form_helper
INFO - 2018-10-12 14:11:50 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:11:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:11:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:11:50 --> User Agent Class Initialized
INFO - 2018-10-12 14:11:50 --> Controller Class Initialized
INFO - 2018-10-12 14:11:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:11:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:11:50 --> Pixel_Model class loaded
INFO - 2018-10-12 14:11:50 --> Database Driver Class Initialized
INFO - 2018-10-12 14:11:50 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:11:50 --> Database Driver Class Initialized
INFO - 2018-10-12 14:11:50 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:11:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:11:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:11:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:11:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 14:11:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/save_exit.php
INFO - 2018-10-12 14:11:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:11:50 --> Final output sent to browser
DEBUG - 2018-10-12 14:11:50 --> Total execution time: 0.0525
INFO - 2018-10-12 14:11:54 --> Config Class Initialized
INFO - 2018-10-12 14:11:54 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:11:54 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:11:54 --> Utf8 Class Initialized
INFO - 2018-10-12 14:11:54 --> URI Class Initialized
INFO - 2018-10-12 14:11:54 --> Router Class Initialized
INFO - 2018-10-12 14:11:54 --> Output Class Initialized
INFO - 2018-10-12 14:11:54 --> Security Class Initialized
DEBUG - 2018-10-12 14:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:11:54 --> CSRF cookie sent
INFO - 2018-10-12 14:11:54 --> Input Class Initialized
INFO - 2018-10-12 14:11:54 --> Language Class Initialized
INFO - 2018-10-12 14:11:54 --> Loader Class Initialized
INFO - 2018-10-12 14:11:54 --> Helper loaded: url_helper
INFO - 2018-10-12 14:11:54 --> Helper loaded: form_helper
INFO - 2018-10-12 14:11:54 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:11:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:11:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:11:54 --> User Agent Class Initialized
INFO - 2018-10-12 14:11:54 --> Controller Class Initialized
INFO - 2018-10-12 14:11:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:11:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:11:54 --> Pixel_Model class loaded
INFO - 2018-10-12 14:11:54 --> Database Driver Class Initialized
INFO - 2018-10-12 14:11:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:11:54 --> Database Driver Class Initialized
INFO - 2018-10-12 14:11:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:11:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:11:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:11:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:11:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 14:11:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 14:11:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 14:11:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-10-12 14:11:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:11:54 --> Final output sent to browser
DEBUG - 2018-10-12 14:11:54 --> Total execution time: 0.0667
INFO - 2018-10-12 14:12:04 --> Config Class Initialized
INFO - 2018-10-12 14:12:04 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:12:04 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:12:04 --> Utf8 Class Initialized
INFO - 2018-10-12 14:12:04 --> URI Class Initialized
INFO - 2018-10-12 14:12:04 --> Router Class Initialized
INFO - 2018-10-12 14:12:04 --> Output Class Initialized
INFO - 2018-10-12 14:12:04 --> Security Class Initialized
DEBUG - 2018-10-12 14:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:12:04 --> CSRF cookie sent
INFO - 2018-10-12 14:12:04 --> Input Class Initialized
INFO - 2018-10-12 14:12:04 --> Language Class Initialized
INFO - 2018-10-12 14:12:04 --> Loader Class Initialized
INFO - 2018-10-12 14:12:04 --> Helper loaded: url_helper
INFO - 2018-10-12 14:12:04 --> Helper loaded: form_helper
INFO - 2018-10-12 14:12:04 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:12:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:12:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:12:04 --> User Agent Class Initialized
INFO - 2018-10-12 14:12:04 --> Controller Class Initialized
INFO - 2018-10-12 14:12:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:12:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:12:04 --> Pixel_Model class loaded
INFO - 2018-10-12 14:12:04 --> Database Driver Class Initialized
INFO - 2018-10-12 14:12:04 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:12:04 --> Database Driver Class Initialized
INFO - 2018-10-12 14:12:04 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:12:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:12:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:12:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:12:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 14:12:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 14:12:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 14:12:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-12 14:12:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:12:04 --> Final output sent to browser
DEBUG - 2018-10-12 14:12:04 --> Total execution time: 0.0442
INFO - 2018-10-12 14:12:07 --> Config Class Initialized
INFO - 2018-10-12 14:12:07 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:12:07 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:12:07 --> Utf8 Class Initialized
INFO - 2018-10-12 14:12:07 --> URI Class Initialized
INFO - 2018-10-12 14:12:07 --> Router Class Initialized
INFO - 2018-10-12 14:12:07 --> Output Class Initialized
INFO - 2018-10-12 14:12:07 --> Security Class Initialized
DEBUG - 2018-10-12 14:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:12:07 --> CSRF cookie sent
INFO - 2018-10-12 14:12:07 --> Input Class Initialized
INFO - 2018-10-12 14:12:07 --> Language Class Initialized
INFO - 2018-10-12 14:12:07 --> Loader Class Initialized
INFO - 2018-10-12 14:12:07 --> Helper loaded: url_helper
INFO - 2018-10-12 14:12:07 --> Helper loaded: form_helper
INFO - 2018-10-12 14:12:07 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:12:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:12:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:12:07 --> User Agent Class Initialized
INFO - 2018-10-12 14:12:07 --> Controller Class Initialized
INFO - 2018-10-12 14:12:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:12:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:12:07 --> Pixel_Model class loaded
INFO - 2018-10-12 14:12:07 --> Database Driver Class Initialized
INFO - 2018-10-12 14:12:07 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:12:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:12:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:12:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:12:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 14:12:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 14:12:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 14:12:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-10-12 14:12:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:12:07 --> Final output sent to browser
DEBUG - 2018-10-12 14:12:07 --> Total execution time: 0.0465
INFO - 2018-10-12 14:12:11 --> Config Class Initialized
INFO - 2018-10-12 14:12:11 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:12:11 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:12:11 --> Utf8 Class Initialized
INFO - 2018-10-12 14:12:11 --> URI Class Initialized
INFO - 2018-10-12 14:12:11 --> Router Class Initialized
INFO - 2018-10-12 14:12:11 --> Output Class Initialized
INFO - 2018-10-12 14:12:11 --> Security Class Initialized
DEBUG - 2018-10-12 14:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:12:11 --> CSRF cookie sent
INFO - 2018-10-12 14:12:11 --> CSRF token verified
INFO - 2018-10-12 14:12:11 --> Input Class Initialized
INFO - 2018-10-12 14:12:11 --> Language Class Initialized
INFO - 2018-10-12 14:12:11 --> Loader Class Initialized
INFO - 2018-10-12 14:12:11 --> Helper loaded: url_helper
INFO - 2018-10-12 14:12:11 --> Helper loaded: form_helper
INFO - 2018-10-12 14:12:11 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:12:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:12:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:12:11 --> User Agent Class Initialized
INFO - 2018-10-12 14:12:11 --> Controller Class Initialized
INFO - 2018-10-12 14:12:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:12:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:12:11 --> Pixel_Model class loaded
INFO - 2018-10-12 14:12:11 --> Database Driver Class Initialized
INFO - 2018-10-12 14:12:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:12:11 --> Database Driver Class Initialized
INFO - 2018-10-12 14:12:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:12:11 --> Config Class Initialized
INFO - 2018-10-12 14:12:11 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:12:11 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:12:11 --> Utf8 Class Initialized
INFO - 2018-10-12 14:12:11 --> URI Class Initialized
INFO - 2018-10-12 14:12:11 --> Router Class Initialized
INFO - 2018-10-12 14:12:11 --> Output Class Initialized
INFO - 2018-10-12 14:12:11 --> Security Class Initialized
DEBUG - 2018-10-12 14:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:12:11 --> CSRF cookie sent
INFO - 2018-10-12 14:12:11 --> Input Class Initialized
INFO - 2018-10-12 14:12:11 --> Language Class Initialized
INFO - 2018-10-12 14:12:11 --> Loader Class Initialized
INFO - 2018-10-12 14:12:11 --> Helper loaded: url_helper
INFO - 2018-10-12 14:12:11 --> Helper loaded: form_helper
INFO - 2018-10-12 14:12:11 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:12:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:12:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:12:11 --> User Agent Class Initialized
INFO - 2018-10-12 14:12:11 --> Controller Class Initialized
INFO - 2018-10-12 14:12:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:12:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:12:11 --> Pixel_Model class loaded
INFO - 2018-10-12 14:12:11 --> Database Driver Class Initialized
INFO - 2018-10-12 14:12:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:12:11 --> Database Driver Class Initialized
INFO - 2018-10-12 14:12:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:12:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:12:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:12:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:12:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 14:12:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 14:12:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 14:12:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-10-12 14:12:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:12:11 --> Final output sent to browser
DEBUG - 2018-10-12 14:12:11 --> Total execution time: 0.0455
INFO - 2018-10-12 14:12:15 --> Config Class Initialized
INFO - 2018-10-12 14:12:15 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:12:15 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:12:15 --> Utf8 Class Initialized
INFO - 2018-10-12 14:12:15 --> URI Class Initialized
INFO - 2018-10-12 14:12:15 --> Router Class Initialized
INFO - 2018-10-12 14:12:15 --> Output Class Initialized
INFO - 2018-10-12 14:12:15 --> Security Class Initialized
DEBUG - 2018-10-12 14:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:12:15 --> CSRF cookie sent
INFO - 2018-10-12 14:12:15 --> CSRF token verified
INFO - 2018-10-12 14:12:15 --> Input Class Initialized
INFO - 2018-10-12 14:12:15 --> Language Class Initialized
INFO - 2018-10-12 14:12:15 --> Loader Class Initialized
INFO - 2018-10-12 14:12:15 --> Helper loaded: url_helper
INFO - 2018-10-12 14:12:15 --> Helper loaded: form_helper
INFO - 2018-10-12 14:12:15 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:12:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:12:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:12:15 --> User Agent Class Initialized
INFO - 2018-10-12 14:12:15 --> Controller Class Initialized
INFO - 2018-10-12 14:12:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:12:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:12:15 --> Pixel_Model class loaded
INFO - 2018-10-12 14:12:15 --> Database Driver Class Initialized
INFO - 2018-10-12 14:12:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:12:15 --> Form Validation Class Initialized
INFO - 2018-10-12 14:12:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-12 14:12:15 --> Database Driver Class Initialized
INFO - 2018-10-12 14:12:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:12:15 --> Config Class Initialized
INFO - 2018-10-12 14:12:15 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:12:15 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:12:15 --> Utf8 Class Initialized
INFO - 2018-10-12 14:12:15 --> URI Class Initialized
INFO - 2018-10-12 14:12:15 --> Router Class Initialized
INFO - 2018-10-12 14:12:15 --> Output Class Initialized
INFO - 2018-10-12 14:12:15 --> Security Class Initialized
DEBUG - 2018-10-12 14:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:12:15 --> CSRF cookie sent
INFO - 2018-10-12 14:12:15 --> Input Class Initialized
INFO - 2018-10-12 14:12:15 --> Language Class Initialized
INFO - 2018-10-12 14:12:15 --> Loader Class Initialized
INFO - 2018-10-12 14:12:15 --> Helper loaded: url_helper
INFO - 2018-10-12 14:12:15 --> Helper loaded: form_helper
INFO - 2018-10-12 14:12:15 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:12:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:12:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:12:15 --> User Agent Class Initialized
INFO - 2018-10-12 14:12:15 --> Controller Class Initialized
INFO - 2018-10-12 14:12:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:12:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:12:15 --> Pixel_Model class loaded
INFO - 2018-10-12 14:12:15 --> Database Driver Class Initialized
INFO - 2018-10-12 14:12:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:12:15 --> Database Driver Class Initialized
INFO - 2018-10-12 14:12:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:12:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:12:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:12:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-10-12 14:12:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:12:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 14:12:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 14:12:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 14:12:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-10-12 14:12:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:12:15 --> Final output sent to browser
DEBUG - 2018-10-12 14:12:15 --> Total execution time: 0.0418
INFO - 2018-10-12 14:12:22 --> Config Class Initialized
INFO - 2018-10-12 14:12:22 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:12:22 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:12:22 --> Utf8 Class Initialized
INFO - 2018-10-12 14:12:22 --> URI Class Initialized
INFO - 2018-10-12 14:12:22 --> Router Class Initialized
INFO - 2018-10-12 14:12:22 --> Output Class Initialized
INFO - 2018-10-12 14:12:22 --> Security Class Initialized
DEBUG - 2018-10-12 14:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:12:22 --> CSRF cookie sent
INFO - 2018-10-12 14:12:22 --> Input Class Initialized
INFO - 2018-10-12 14:12:22 --> Language Class Initialized
INFO - 2018-10-12 14:12:22 --> Loader Class Initialized
INFO - 2018-10-12 14:12:22 --> Helper loaded: url_helper
INFO - 2018-10-12 14:12:22 --> Helper loaded: form_helper
INFO - 2018-10-12 14:12:22 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:12:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:12:22 --> User Agent Class Initialized
INFO - 2018-10-12 14:12:22 --> Controller Class Initialized
INFO - 2018-10-12 14:12:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:12:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:12:22 --> Pixel_Model class loaded
INFO - 2018-10-12 14:12:22 --> Database Driver Class Initialized
INFO - 2018-10-12 14:12:22 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:12:22 --> Database Driver Class Initialized
INFO - 2018-10-12 14:12:22 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:12:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:12:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:12:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:12:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 14:12:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/save_exit.php
INFO - 2018-10-12 14:12:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:12:22 --> Final output sent to browser
DEBUG - 2018-10-12 14:12:22 --> Total execution time: 0.0498
INFO - 2018-10-12 14:12:23 --> Config Class Initialized
INFO - 2018-10-12 14:12:23 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:12:23 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:12:23 --> Utf8 Class Initialized
INFO - 2018-10-12 14:12:23 --> URI Class Initialized
INFO - 2018-10-12 14:12:23 --> Router Class Initialized
INFO - 2018-10-12 14:12:23 --> Output Class Initialized
INFO - 2018-10-12 14:12:23 --> Security Class Initialized
DEBUG - 2018-10-12 14:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:12:23 --> CSRF cookie sent
INFO - 2018-10-12 14:12:23 --> Input Class Initialized
INFO - 2018-10-12 14:12:23 --> Language Class Initialized
INFO - 2018-10-12 14:12:23 --> Loader Class Initialized
INFO - 2018-10-12 14:12:23 --> Helper loaded: url_helper
INFO - 2018-10-12 14:12:23 --> Helper loaded: form_helper
INFO - 2018-10-12 14:12:23 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:12:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:12:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:12:23 --> User Agent Class Initialized
INFO - 2018-10-12 14:12:23 --> Controller Class Initialized
INFO - 2018-10-12 14:12:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:12:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:12:23 --> Pixel_Model class loaded
INFO - 2018-10-12 14:12:23 --> Database Driver Class Initialized
INFO - 2018-10-12 14:12:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:12:23 --> Database Driver Class Initialized
INFO - 2018-10-12 14:12:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:12:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:12:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:12:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-10-12 14:12:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:12:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 14:12:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 14:12:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 14:12:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-10-12 14:12:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:12:23 --> Final output sent to browser
DEBUG - 2018-10-12 14:12:23 --> Total execution time: 0.0400
INFO - 2018-10-12 14:26:18 --> Config Class Initialized
INFO - 2018-10-12 14:26:18 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:26:18 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:26:18 --> Utf8 Class Initialized
INFO - 2018-10-12 14:26:18 --> URI Class Initialized
DEBUG - 2018-10-12 14:26:18 --> No URI present. Default controller set.
INFO - 2018-10-12 14:26:18 --> Router Class Initialized
INFO - 2018-10-12 14:26:18 --> Output Class Initialized
INFO - 2018-10-12 14:26:18 --> Security Class Initialized
DEBUG - 2018-10-12 14:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:26:18 --> CSRF cookie sent
INFO - 2018-10-12 14:26:18 --> Input Class Initialized
INFO - 2018-10-12 14:26:18 --> Language Class Initialized
INFO - 2018-10-12 14:26:18 --> Loader Class Initialized
INFO - 2018-10-12 14:26:18 --> Helper loaded: url_helper
INFO - 2018-10-12 14:26:18 --> Helper loaded: form_helper
INFO - 2018-10-12 14:26:18 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:26:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:26:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:26:18 --> User Agent Class Initialized
INFO - 2018-10-12 14:26:18 --> Controller Class Initialized
INFO - 2018-10-12 14:26:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:26:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:26:18 --> Pixel_Model class loaded
INFO - 2018-10-12 14:26:18 --> Database Driver Class Initialized
INFO - 2018-10-12 14:26:18 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:26:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:26:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:26:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-12 14:26:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:26:18 --> Final output sent to browser
DEBUG - 2018-10-12 14:26:18 --> Total execution time: 0.0407
INFO - 2018-10-12 14:26:18 --> Config Class Initialized
INFO - 2018-10-12 14:26:18 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:26:18 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:26:18 --> Utf8 Class Initialized
INFO - 2018-10-12 14:26:18 --> URI Class Initialized
DEBUG - 2018-10-12 14:26:18 --> No URI present. Default controller set.
INFO - 2018-10-12 14:26:18 --> Router Class Initialized
INFO - 2018-10-12 14:26:18 --> Output Class Initialized
INFO - 2018-10-12 14:26:18 --> Security Class Initialized
DEBUG - 2018-10-12 14:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:26:18 --> CSRF cookie sent
INFO - 2018-10-12 14:26:18 --> Input Class Initialized
INFO - 2018-10-12 14:26:18 --> Language Class Initialized
INFO - 2018-10-12 14:26:18 --> Loader Class Initialized
INFO - 2018-10-12 14:26:18 --> Helper loaded: url_helper
INFO - 2018-10-12 14:26:18 --> Helper loaded: form_helper
INFO - 2018-10-12 14:26:18 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:26:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:26:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:26:18 --> User Agent Class Initialized
INFO - 2018-10-12 14:26:18 --> Controller Class Initialized
INFO - 2018-10-12 14:26:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:26:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:26:18 --> Pixel_Model class loaded
INFO - 2018-10-12 14:26:18 --> Database Driver Class Initialized
INFO - 2018-10-12 14:26:18 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:26:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:26:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:26:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-12 14:26:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:26:18 --> Final output sent to browser
DEBUG - 2018-10-12 14:26:18 --> Total execution time: 0.0314
INFO - 2018-10-12 14:26:21 --> Config Class Initialized
INFO - 2018-10-12 14:26:21 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:26:21 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:26:21 --> Utf8 Class Initialized
INFO - 2018-10-12 14:26:21 --> URI Class Initialized
INFO - 2018-10-12 14:26:21 --> Router Class Initialized
INFO - 2018-10-12 14:26:21 --> Output Class Initialized
INFO - 2018-10-12 14:26:21 --> Security Class Initialized
DEBUG - 2018-10-12 14:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:26:21 --> CSRF cookie sent
INFO - 2018-10-12 14:26:21 --> Input Class Initialized
INFO - 2018-10-12 14:26:21 --> Language Class Initialized
INFO - 2018-10-12 14:26:21 --> Loader Class Initialized
INFO - 2018-10-12 14:26:21 --> Helper loaded: url_helper
INFO - 2018-10-12 14:26:21 --> Helper loaded: form_helper
INFO - 2018-10-12 14:26:21 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:26:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:26:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:26:21 --> User Agent Class Initialized
INFO - 2018-10-12 14:26:21 --> Controller Class Initialized
INFO - 2018-10-12 14:26:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:26:21 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-12 14:26:21 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-10-12 14:26:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:26:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:26:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:26:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-10-12 14:26:21 --> Could not find the language line "req_email"
INFO - 2018-10-12 14:26:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-10-12 14:26:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:26:21 --> Final output sent to browser
DEBUG - 2018-10-12 14:26:21 --> Total execution time: 0.0224
INFO - 2018-10-12 14:26:23 --> Config Class Initialized
INFO - 2018-10-12 14:26:23 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:26:23 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:26:23 --> Utf8 Class Initialized
INFO - 2018-10-12 14:26:23 --> URI Class Initialized
INFO - 2018-10-12 14:26:23 --> Router Class Initialized
INFO - 2018-10-12 14:26:23 --> Output Class Initialized
INFO - 2018-10-12 14:26:23 --> Security Class Initialized
DEBUG - 2018-10-12 14:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:26:23 --> CSRF cookie sent
INFO - 2018-10-12 14:26:23 --> Input Class Initialized
INFO - 2018-10-12 14:26:23 --> Language Class Initialized
INFO - 2018-10-12 14:26:23 --> Loader Class Initialized
INFO - 2018-10-12 14:26:23 --> Helper loaded: url_helper
INFO - 2018-10-12 14:26:23 --> Helper loaded: form_helper
INFO - 2018-10-12 14:26:23 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:26:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:26:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:26:23 --> User Agent Class Initialized
INFO - 2018-10-12 14:26:23 --> Controller Class Initialized
INFO - 2018-10-12 14:26:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:26:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:26:23 --> Pixel_Model class loaded
INFO - 2018-10-12 14:26:23 --> Database Driver Class Initialized
INFO - 2018-10-12 14:26:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:26:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:26:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:26:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:26:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 14:26:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 14:26:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 14:26:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-10-12 14:26:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:26:23 --> Final output sent to browser
DEBUG - 2018-10-12 14:26:23 --> Total execution time: 0.0379
INFO - 2018-10-12 14:26:24 --> Config Class Initialized
INFO - 2018-10-12 14:26:24 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:26:24 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:26:24 --> Utf8 Class Initialized
INFO - 2018-10-12 14:26:24 --> URI Class Initialized
INFO - 2018-10-12 14:26:24 --> Router Class Initialized
INFO - 2018-10-12 14:26:24 --> Output Class Initialized
INFO - 2018-10-12 14:26:24 --> Security Class Initialized
DEBUG - 2018-10-12 14:26:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:26:24 --> CSRF cookie sent
INFO - 2018-10-12 14:26:24 --> CSRF token verified
INFO - 2018-10-12 14:26:24 --> Input Class Initialized
INFO - 2018-10-12 14:26:24 --> Language Class Initialized
INFO - 2018-10-12 14:26:24 --> Loader Class Initialized
INFO - 2018-10-12 14:26:24 --> Helper loaded: url_helper
INFO - 2018-10-12 14:26:24 --> Helper loaded: form_helper
INFO - 2018-10-12 14:26:24 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:26:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:26:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:26:24 --> User Agent Class Initialized
INFO - 2018-10-12 14:26:24 --> Controller Class Initialized
INFO - 2018-10-12 14:26:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:26:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:26:24 --> Pixel_Model class loaded
INFO - 2018-10-12 14:26:24 --> Database Driver Class Initialized
INFO - 2018-10-12 14:26:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:26:24 --> Database Driver Class Initialized
INFO - 2018-10-12 14:26:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:26:24 --> Config Class Initialized
INFO - 2018-10-12 14:26:24 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:26:24 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:26:24 --> Utf8 Class Initialized
INFO - 2018-10-12 14:26:24 --> URI Class Initialized
INFO - 2018-10-12 14:26:24 --> Router Class Initialized
INFO - 2018-10-12 14:26:24 --> Output Class Initialized
INFO - 2018-10-12 14:26:24 --> Security Class Initialized
DEBUG - 2018-10-12 14:26:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:26:24 --> CSRF cookie sent
INFO - 2018-10-12 14:26:24 --> Input Class Initialized
INFO - 2018-10-12 14:26:24 --> Language Class Initialized
INFO - 2018-10-12 14:26:24 --> Loader Class Initialized
INFO - 2018-10-12 14:26:24 --> Helper loaded: url_helper
INFO - 2018-10-12 14:26:24 --> Helper loaded: form_helper
INFO - 2018-10-12 14:26:24 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:26:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:26:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:26:24 --> User Agent Class Initialized
INFO - 2018-10-12 14:26:24 --> Controller Class Initialized
INFO - 2018-10-12 14:26:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:26:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:26:24 --> Pixel_Model class loaded
INFO - 2018-10-12 14:26:24 --> Database Driver Class Initialized
INFO - 2018-10-12 14:26:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:26:24 --> Database Driver Class Initialized
INFO - 2018-10-12 14:26:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:26:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:26:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:26:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:26:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 14:26:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 14:26:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 14:26:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-12 14:26:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:26:24 --> Final output sent to browser
DEBUG - 2018-10-12 14:26:24 --> Total execution time: 0.0486
INFO - 2018-10-12 14:26:33 --> Config Class Initialized
INFO - 2018-10-12 14:26:33 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:26:33 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:26:33 --> Utf8 Class Initialized
INFO - 2018-10-12 14:26:33 --> URI Class Initialized
INFO - 2018-10-12 14:26:33 --> Router Class Initialized
INFO - 2018-10-12 14:26:33 --> Output Class Initialized
INFO - 2018-10-12 14:26:33 --> Security Class Initialized
DEBUG - 2018-10-12 14:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:26:33 --> CSRF cookie sent
INFO - 2018-10-12 14:26:33 --> CSRF token verified
INFO - 2018-10-12 14:26:33 --> Input Class Initialized
INFO - 2018-10-12 14:26:33 --> Language Class Initialized
INFO - 2018-10-12 14:26:33 --> Loader Class Initialized
INFO - 2018-10-12 14:26:33 --> Helper loaded: url_helper
INFO - 2018-10-12 14:26:33 --> Helper loaded: form_helper
INFO - 2018-10-12 14:26:33 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:26:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:26:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:26:33 --> User Agent Class Initialized
INFO - 2018-10-12 14:26:33 --> Controller Class Initialized
INFO - 2018-10-12 14:26:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:26:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:26:33 --> Pixel_Model class loaded
INFO - 2018-10-12 14:26:33 --> Database Driver Class Initialized
INFO - 2018-10-12 14:26:33 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:26:33 --> Form Validation Class Initialized
INFO - 2018-10-12 14:26:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-12 14:26:33 --> Database Driver Class Initialized
INFO - 2018-10-12 14:26:33 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:26:33 --> Config Class Initialized
INFO - 2018-10-12 14:26:33 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:26:33 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:26:33 --> Utf8 Class Initialized
INFO - 2018-10-12 14:26:33 --> URI Class Initialized
INFO - 2018-10-12 14:26:33 --> Router Class Initialized
INFO - 2018-10-12 14:26:33 --> Output Class Initialized
INFO - 2018-10-12 14:26:33 --> Security Class Initialized
DEBUG - 2018-10-12 14:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:26:33 --> CSRF cookie sent
INFO - 2018-10-12 14:26:33 --> Input Class Initialized
INFO - 2018-10-12 14:26:33 --> Language Class Initialized
INFO - 2018-10-12 14:26:33 --> Loader Class Initialized
INFO - 2018-10-12 14:26:33 --> Helper loaded: url_helper
INFO - 2018-10-12 14:26:33 --> Helper loaded: form_helper
INFO - 2018-10-12 14:26:33 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:26:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:26:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:26:33 --> User Agent Class Initialized
INFO - 2018-10-12 14:26:33 --> Controller Class Initialized
INFO - 2018-10-12 14:26:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:26:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:26:33 --> Pixel_Model class loaded
INFO - 2018-10-12 14:26:33 --> Database Driver Class Initialized
INFO - 2018-10-12 14:26:33 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:26:33 --> Database Driver Class Initialized
INFO - 2018-10-12 14:26:33 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:26:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:26:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:26:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:26:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 14:26:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 14:26:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 14:26:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-10-12 14:26:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:26:33 --> Final output sent to browser
DEBUG - 2018-10-12 14:26:33 --> Total execution time: 0.0489
INFO - 2018-10-12 14:26:36 --> Config Class Initialized
INFO - 2018-10-12 14:26:36 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:26:36 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:26:36 --> Utf8 Class Initialized
INFO - 2018-10-12 14:26:36 --> URI Class Initialized
INFO - 2018-10-12 14:26:36 --> Router Class Initialized
INFO - 2018-10-12 14:26:36 --> Output Class Initialized
INFO - 2018-10-12 14:26:36 --> Security Class Initialized
DEBUG - 2018-10-12 14:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:26:36 --> CSRF cookie sent
INFO - 2018-10-12 14:26:36 --> Input Class Initialized
INFO - 2018-10-12 14:26:36 --> Language Class Initialized
INFO - 2018-10-12 14:26:36 --> Loader Class Initialized
INFO - 2018-10-12 14:26:36 --> Helper loaded: url_helper
INFO - 2018-10-12 14:26:36 --> Helper loaded: form_helper
INFO - 2018-10-12 14:26:36 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:26:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:26:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:26:36 --> User Agent Class Initialized
INFO - 2018-10-12 14:26:36 --> Controller Class Initialized
INFO - 2018-10-12 14:26:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:26:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:26:36 --> Pixel_Model class loaded
INFO - 2018-10-12 14:26:36 --> Database Driver Class Initialized
INFO - 2018-10-12 14:26:36 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:26:36 --> Database Driver Class Initialized
INFO - 2018-10-12 14:26:36 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:26:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:26:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:26:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:26:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 14:26:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/save_exit.php
INFO - 2018-10-12 14:26:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:26:36 --> Final output sent to browser
DEBUG - 2018-10-12 14:26:36 --> Total execution time: 0.0585
INFO - 2018-10-12 14:26:39 --> Config Class Initialized
INFO - 2018-10-12 14:26:39 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:26:39 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:26:39 --> Utf8 Class Initialized
INFO - 2018-10-12 14:26:39 --> URI Class Initialized
INFO - 2018-10-12 14:26:39 --> Router Class Initialized
INFO - 2018-10-12 14:26:39 --> Output Class Initialized
INFO - 2018-10-12 14:26:39 --> Security Class Initialized
DEBUG - 2018-10-12 14:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:26:39 --> CSRF cookie sent
INFO - 2018-10-12 14:26:39 --> Input Class Initialized
INFO - 2018-10-12 14:26:39 --> Language Class Initialized
INFO - 2018-10-12 14:26:39 --> Loader Class Initialized
INFO - 2018-10-12 14:26:39 --> Helper loaded: url_helper
INFO - 2018-10-12 14:26:39 --> Helper loaded: form_helper
INFO - 2018-10-12 14:26:39 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:26:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:26:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:26:39 --> User Agent Class Initialized
INFO - 2018-10-12 14:26:39 --> Controller Class Initialized
INFO - 2018-10-12 14:26:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:26:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:26:39 --> Pixel_Model class loaded
INFO - 2018-10-12 14:26:39 --> Database Driver Class Initialized
INFO - 2018-10-12 14:26:39 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:26:39 --> Database Driver Class Initialized
INFO - 2018-10-12 14:26:39 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:26:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:26:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:26:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:26:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 14:26:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 14:26:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 14:26:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-10-12 14:26:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:26:39 --> Final output sent to browser
DEBUG - 2018-10-12 14:26:39 --> Total execution time: 0.0612
INFO - 2018-10-12 14:26:41 --> Config Class Initialized
INFO - 2018-10-12 14:26:41 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:26:41 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:26:41 --> Utf8 Class Initialized
INFO - 2018-10-12 14:26:41 --> URI Class Initialized
INFO - 2018-10-12 14:26:41 --> Router Class Initialized
INFO - 2018-10-12 14:26:41 --> Output Class Initialized
INFO - 2018-10-12 14:26:41 --> Security Class Initialized
DEBUG - 2018-10-12 14:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:26:41 --> CSRF cookie sent
INFO - 2018-10-12 14:26:41 --> Input Class Initialized
INFO - 2018-10-12 14:26:41 --> Language Class Initialized
INFO - 2018-10-12 14:26:41 --> Loader Class Initialized
INFO - 2018-10-12 14:26:41 --> Helper loaded: url_helper
INFO - 2018-10-12 14:26:41 --> Helper loaded: form_helper
INFO - 2018-10-12 14:26:41 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:26:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:26:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:26:41 --> User Agent Class Initialized
INFO - 2018-10-12 14:26:41 --> Controller Class Initialized
INFO - 2018-10-12 14:26:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:26:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:26:41 --> Pixel_Model class loaded
INFO - 2018-10-12 14:26:41 --> Database Driver Class Initialized
INFO - 2018-10-12 14:26:41 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:26:41 --> Database Driver Class Initialized
INFO - 2018-10-12 14:26:41 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:26:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:26:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:26:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:26:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 14:26:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/save_exit.php
INFO - 2018-10-12 14:26:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:26:41 --> Final output sent to browser
DEBUG - 2018-10-12 14:26:41 --> Total execution time: 0.0673
INFO - 2018-10-12 14:26:42 --> Config Class Initialized
INFO - 2018-10-12 14:26:42 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:26:42 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:26:42 --> Utf8 Class Initialized
INFO - 2018-10-12 14:26:42 --> URI Class Initialized
INFO - 2018-10-12 14:26:42 --> Router Class Initialized
INFO - 2018-10-12 14:26:42 --> Output Class Initialized
INFO - 2018-10-12 14:26:42 --> Security Class Initialized
DEBUG - 2018-10-12 14:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:26:42 --> CSRF cookie sent
INFO - 2018-10-12 14:26:42 --> Input Class Initialized
INFO - 2018-10-12 14:26:42 --> Language Class Initialized
INFO - 2018-10-12 14:26:42 --> Loader Class Initialized
INFO - 2018-10-12 14:26:42 --> Helper loaded: url_helper
INFO - 2018-10-12 14:26:42 --> Helper loaded: form_helper
INFO - 2018-10-12 14:26:42 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:26:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:26:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:26:42 --> User Agent Class Initialized
INFO - 2018-10-12 14:26:42 --> Controller Class Initialized
INFO - 2018-10-12 14:26:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:26:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:26:42 --> Pixel_Model class loaded
INFO - 2018-10-12 14:26:42 --> Database Driver Class Initialized
INFO - 2018-10-12 14:26:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:26:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:26:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:26:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:26:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 14:26:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/contact_us.php
INFO - 2018-10-12 14:26:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:26:42 --> Final output sent to browser
DEBUG - 2018-10-12 14:26:42 --> Total execution time: 0.0478
INFO - 2018-10-12 14:26:53 --> Config Class Initialized
INFO - 2018-10-12 14:26:53 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:26:53 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:26:53 --> Utf8 Class Initialized
INFO - 2018-10-12 14:26:53 --> URI Class Initialized
INFO - 2018-10-12 14:26:53 --> Router Class Initialized
INFO - 2018-10-12 14:26:53 --> Output Class Initialized
INFO - 2018-10-12 14:26:53 --> Security Class Initialized
DEBUG - 2018-10-12 14:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:26:53 --> CSRF cookie sent
INFO - 2018-10-12 14:26:53 --> Input Class Initialized
INFO - 2018-10-12 14:26:53 --> Language Class Initialized
INFO - 2018-10-12 14:26:53 --> Loader Class Initialized
INFO - 2018-10-12 14:26:53 --> Helper loaded: url_helper
INFO - 2018-10-12 14:26:53 --> Helper loaded: form_helper
INFO - 2018-10-12 14:26:53 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:26:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:26:53 --> User Agent Class Initialized
INFO - 2018-10-12 14:26:53 --> Controller Class Initialized
INFO - 2018-10-12 14:26:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:26:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:26:53 --> Pixel_Model class loaded
INFO - 2018-10-12 14:26:53 --> Database Driver Class Initialized
INFO - 2018-10-12 14:26:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:26:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:26:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:26:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:26:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 14:26:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 14:26:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 14:26:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-10-12 14:26:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:26:53 --> Final output sent to browser
DEBUG - 2018-10-12 14:26:53 --> Total execution time: 0.0401
INFO - 2018-10-12 14:26:55 --> Config Class Initialized
INFO - 2018-10-12 14:26:55 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:26:55 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:26:55 --> Utf8 Class Initialized
INFO - 2018-10-12 14:26:55 --> URI Class Initialized
INFO - 2018-10-12 14:26:55 --> Router Class Initialized
INFO - 2018-10-12 14:26:55 --> Output Class Initialized
INFO - 2018-10-12 14:26:55 --> Security Class Initialized
DEBUG - 2018-10-12 14:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:26:55 --> CSRF cookie sent
INFO - 2018-10-12 14:26:55 --> CSRF token verified
INFO - 2018-10-12 14:26:55 --> Input Class Initialized
INFO - 2018-10-12 14:26:55 --> Language Class Initialized
INFO - 2018-10-12 14:26:55 --> Loader Class Initialized
INFO - 2018-10-12 14:26:55 --> Helper loaded: url_helper
INFO - 2018-10-12 14:26:55 --> Helper loaded: form_helper
INFO - 2018-10-12 14:26:55 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:26:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:26:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:26:55 --> User Agent Class Initialized
INFO - 2018-10-12 14:26:55 --> Controller Class Initialized
INFO - 2018-10-12 14:26:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:26:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:26:55 --> Pixel_Model class loaded
INFO - 2018-10-12 14:26:55 --> Database Driver Class Initialized
INFO - 2018-10-12 14:26:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:26:55 --> Database Driver Class Initialized
INFO - 2018-10-12 14:26:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:26:55 --> Config Class Initialized
INFO - 2018-10-12 14:26:55 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:26:55 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:26:55 --> Utf8 Class Initialized
INFO - 2018-10-12 14:26:55 --> URI Class Initialized
INFO - 2018-10-12 14:26:55 --> Router Class Initialized
INFO - 2018-10-12 14:26:55 --> Output Class Initialized
INFO - 2018-10-12 14:26:55 --> Security Class Initialized
DEBUG - 2018-10-12 14:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:26:55 --> CSRF cookie sent
INFO - 2018-10-12 14:26:55 --> Input Class Initialized
INFO - 2018-10-12 14:26:55 --> Language Class Initialized
INFO - 2018-10-12 14:26:55 --> Loader Class Initialized
INFO - 2018-10-12 14:26:55 --> Helper loaded: url_helper
INFO - 2018-10-12 14:26:55 --> Helper loaded: form_helper
INFO - 2018-10-12 14:26:55 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:26:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:26:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:26:55 --> User Agent Class Initialized
INFO - 2018-10-12 14:26:55 --> Controller Class Initialized
INFO - 2018-10-12 14:26:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:26:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:26:55 --> Pixel_Model class loaded
INFO - 2018-10-12 14:26:55 --> Database Driver Class Initialized
INFO - 2018-10-12 14:26:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:26:55 --> Database Driver Class Initialized
INFO - 2018-10-12 14:26:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:26:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:26:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:26:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:26:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 14:26:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 14:26:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 14:26:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-10-12 14:26:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:26:55 --> Final output sent to browser
DEBUG - 2018-10-12 14:26:55 --> Total execution time: 0.0491
INFO - 2018-10-12 14:26:56 --> Config Class Initialized
INFO - 2018-10-12 14:26:56 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:26:56 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:26:56 --> Utf8 Class Initialized
INFO - 2018-10-12 14:26:56 --> URI Class Initialized
INFO - 2018-10-12 14:26:56 --> Router Class Initialized
INFO - 2018-10-12 14:26:56 --> Output Class Initialized
INFO - 2018-10-12 14:26:56 --> Security Class Initialized
DEBUG - 2018-10-12 14:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:26:56 --> CSRF cookie sent
INFO - 2018-10-12 14:26:56 --> CSRF token verified
INFO - 2018-10-12 14:26:56 --> Input Class Initialized
INFO - 2018-10-12 14:26:56 --> Language Class Initialized
INFO - 2018-10-12 14:26:56 --> Loader Class Initialized
INFO - 2018-10-12 14:26:56 --> Helper loaded: url_helper
INFO - 2018-10-12 14:26:56 --> Helper loaded: form_helper
INFO - 2018-10-12 14:26:56 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:26:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:26:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:26:56 --> User Agent Class Initialized
INFO - 2018-10-12 14:26:56 --> Controller Class Initialized
INFO - 2018-10-12 14:26:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:26:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:26:56 --> Pixel_Model class loaded
INFO - 2018-10-12 14:26:56 --> Database Driver Class Initialized
INFO - 2018-10-12 14:26:56 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:26:56 --> Form Validation Class Initialized
INFO - 2018-10-12 14:26:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-12 14:26:56 --> Database Driver Class Initialized
INFO - 2018-10-12 14:26:56 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:26:56 --> Config Class Initialized
INFO - 2018-10-12 14:26:56 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:26:56 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:26:56 --> Utf8 Class Initialized
INFO - 2018-10-12 14:26:56 --> URI Class Initialized
INFO - 2018-10-12 14:26:56 --> Router Class Initialized
INFO - 2018-10-12 14:26:56 --> Output Class Initialized
INFO - 2018-10-12 14:26:56 --> Security Class Initialized
DEBUG - 2018-10-12 14:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:26:56 --> CSRF cookie sent
INFO - 2018-10-12 14:26:56 --> Input Class Initialized
INFO - 2018-10-12 14:26:56 --> Language Class Initialized
INFO - 2018-10-12 14:26:56 --> Loader Class Initialized
INFO - 2018-10-12 14:26:56 --> Helper loaded: url_helper
INFO - 2018-10-12 14:26:56 --> Helper loaded: form_helper
INFO - 2018-10-12 14:26:56 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:26:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:26:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:26:56 --> User Agent Class Initialized
INFO - 2018-10-12 14:26:56 --> Controller Class Initialized
INFO - 2018-10-12 14:26:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:26:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:26:56 --> Pixel_Model class loaded
INFO - 2018-10-12 14:26:56 --> Database Driver Class Initialized
INFO - 2018-10-12 14:26:56 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:26:56 --> Database Driver Class Initialized
INFO - 2018-10-12 14:26:56 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:26:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:26:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:26:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-10-12 14:26:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:26:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 14:26:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 14:26:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 14:26:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-10-12 14:26:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:26:56 --> Final output sent to browser
DEBUG - 2018-10-12 14:26:56 --> Total execution time: 0.0407
INFO - 2018-10-12 14:26:57 --> Config Class Initialized
INFO - 2018-10-12 14:26:57 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:26:57 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:26:57 --> Utf8 Class Initialized
INFO - 2018-10-12 14:26:57 --> URI Class Initialized
INFO - 2018-10-12 14:26:57 --> Router Class Initialized
INFO - 2018-10-12 14:26:57 --> Output Class Initialized
INFO - 2018-10-12 14:26:57 --> Security Class Initialized
DEBUG - 2018-10-12 14:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:26:57 --> CSRF cookie sent
INFO - 2018-10-12 14:26:57 --> CSRF token verified
INFO - 2018-10-12 14:26:57 --> Input Class Initialized
INFO - 2018-10-12 14:26:57 --> Language Class Initialized
INFO - 2018-10-12 14:26:57 --> Loader Class Initialized
INFO - 2018-10-12 14:26:57 --> Helper loaded: url_helper
INFO - 2018-10-12 14:26:57 --> Helper loaded: form_helper
INFO - 2018-10-12 14:26:57 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:26:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:26:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:26:57 --> User Agent Class Initialized
INFO - 2018-10-12 14:26:57 --> Controller Class Initialized
INFO - 2018-10-12 14:26:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:26:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:26:57 --> Pixel_Model class loaded
INFO - 2018-10-12 14:26:57 --> Database Driver Class Initialized
INFO - 2018-10-12 14:26:57 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:26:57 --> Form Validation Class Initialized
INFO - 2018-10-12 14:26:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-12 14:26:57 --> Database Driver Class Initialized
INFO - 2018-10-12 14:26:57 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:26:57 --> Config Class Initialized
INFO - 2018-10-12 14:26:57 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:26:57 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:26:57 --> Utf8 Class Initialized
INFO - 2018-10-12 14:26:57 --> URI Class Initialized
INFO - 2018-10-12 14:26:57 --> Router Class Initialized
INFO - 2018-10-12 14:26:57 --> Output Class Initialized
INFO - 2018-10-12 14:26:57 --> Security Class Initialized
DEBUG - 2018-10-12 14:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:26:57 --> CSRF cookie sent
INFO - 2018-10-12 14:26:57 --> Input Class Initialized
INFO - 2018-10-12 14:26:57 --> Language Class Initialized
INFO - 2018-10-12 14:26:57 --> Loader Class Initialized
INFO - 2018-10-12 14:26:57 --> Helper loaded: url_helper
INFO - 2018-10-12 14:26:57 --> Helper loaded: form_helper
INFO - 2018-10-12 14:26:57 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:26:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:26:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:26:57 --> User Agent Class Initialized
INFO - 2018-10-12 14:26:57 --> Controller Class Initialized
INFO - 2018-10-12 14:26:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:26:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:26:57 --> Pixel_Model class loaded
INFO - 2018-10-12 14:26:57 --> Database Driver Class Initialized
INFO - 2018-10-12 14:26:57 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:26:57 --> Database Driver Class Initialized
INFO - 2018-10-12 14:26:57 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:26:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:26:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:26:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:26:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 14:26:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 14:26:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 14:26:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-12 14:26:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:26:57 --> Final output sent to browser
DEBUG - 2018-10-12 14:26:57 --> Total execution time: 0.0509
INFO - 2018-10-12 14:27:00 --> Config Class Initialized
INFO - 2018-10-12 14:27:00 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:27:00 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:27:00 --> Utf8 Class Initialized
INFO - 2018-10-12 14:27:00 --> URI Class Initialized
INFO - 2018-10-12 14:27:00 --> Router Class Initialized
INFO - 2018-10-12 14:27:00 --> Output Class Initialized
INFO - 2018-10-12 14:27:00 --> Security Class Initialized
DEBUG - 2018-10-12 14:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:27:00 --> CSRF cookie sent
INFO - 2018-10-12 14:27:00 --> Input Class Initialized
INFO - 2018-10-12 14:27:00 --> Language Class Initialized
INFO - 2018-10-12 14:27:00 --> Loader Class Initialized
INFO - 2018-10-12 14:27:00 --> Helper loaded: url_helper
INFO - 2018-10-12 14:27:00 --> Helper loaded: form_helper
INFO - 2018-10-12 14:27:00 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:27:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:27:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:27:00 --> User Agent Class Initialized
INFO - 2018-10-12 14:27:00 --> Controller Class Initialized
INFO - 2018-10-12 14:27:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:27:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:27:00 --> Pixel_Model class loaded
INFO - 2018-10-12 14:27:00 --> Database Driver Class Initialized
INFO - 2018-10-12 14:27:00 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:27:00 --> Database Driver Class Initialized
INFO - 2018-10-12 14:27:00 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:27:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:27:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:27:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:27:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 14:27:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 14:27:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 14:27:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-12 14:27:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:27:00 --> Final output sent to browser
DEBUG - 2018-10-12 14:27:00 --> Total execution time: 0.0530
INFO - 2018-10-12 14:27:01 --> Config Class Initialized
INFO - 2018-10-12 14:27:01 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:27:01 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:27:01 --> Utf8 Class Initialized
INFO - 2018-10-12 14:27:01 --> URI Class Initialized
INFO - 2018-10-12 14:27:01 --> Router Class Initialized
INFO - 2018-10-12 14:27:01 --> Output Class Initialized
INFO - 2018-10-12 14:27:01 --> Security Class Initialized
DEBUG - 2018-10-12 14:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:27:01 --> CSRF cookie sent
INFO - 2018-10-12 14:27:01 --> CSRF token verified
INFO - 2018-10-12 14:27:01 --> Input Class Initialized
INFO - 2018-10-12 14:27:01 --> Language Class Initialized
INFO - 2018-10-12 14:27:01 --> Loader Class Initialized
INFO - 2018-10-12 14:27:01 --> Helper loaded: url_helper
INFO - 2018-10-12 14:27:01 --> Helper loaded: form_helper
INFO - 2018-10-12 14:27:01 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:27:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:27:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:27:01 --> User Agent Class Initialized
INFO - 2018-10-12 14:27:01 --> Controller Class Initialized
INFO - 2018-10-12 14:27:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:27:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:27:01 --> Pixel_Model class loaded
INFO - 2018-10-12 14:27:01 --> Database Driver Class Initialized
INFO - 2018-10-12 14:27:01 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:27:01 --> Form Validation Class Initialized
INFO - 2018-10-12 14:27:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-12 14:27:01 --> Database Driver Class Initialized
INFO - 2018-10-12 14:27:01 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:27:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:27:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:27:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:27:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 14:27:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 14:27:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_errors.php
INFO - 2018-10-12 14:27:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 14:27:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-12 14:27:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:27:01 --> Final output sent to browser
DEBUG - 2018-10-12 14:27:01 --> Total execution time: 0.0522
INFO - 2018-10-12 14:27:03 --> Config Class Initialized
INFO - 2018-10-12 14:27:03 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:27:03 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:27:03 --> Utf8 Class Initialized
INFO - 2018-10-12 14:27:03 --> URI Class Initialized
INFO - 2018-10-12 14:27:03 --> Router Class Initialized
INFO - 2018-10-12 14:27:03 --> Output Class Initialized
INFO - 2018-10-12 14:27:03 --> Security Class Initialized
DEBUG - 2018-10-12 14:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:27:03 --> CSRF cookie sent
INFO - 2018-10-12 14:27:03 --> Input Class Initialized
INFO - 2018-10-12 14:27:03 --> Language Class Initialized
INFO - 2018-10-12 14:27:03 --> Loader Class Initialized
INFO - 2018-10-12 14:27:03 --> Helper loaded: url_helper
INFO - 2018-10-12 14:27:03 --> Helper loaded: form_helper
INFO - 2018-10-12 14:27:03 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:27:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:27:03 --> User Agent Class Initialized
INFO - 2018-10-12 14:27:03 --> Controller Class Initialized
INFO - 2018-10-12 14:27:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:27:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:27:03 --> Pixel_Model class loaded
INFO - 2018-10-12 14:27:03 --> Database Driver Class Initialized
INFO - 2018-10-12 14:27:03 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:27:03 --> Database Driver Class Initialized
INFO - 2018-10-12 14:27:03 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:27:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:27:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:27:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:27:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 14:27:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 14:27:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 14:27:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-12 14:27:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:27:03 --> Final output sent to browser
DEBUG - 2018-10-12 14:27:03 --> Total execution time: 0.0399
INFO - 2018-10-12 14:27:06 --> Config Class Initialized
INFO - 2018-10-12 14:27:06 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:27:06 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:27:06 --> Utf8 Class Initialized
INFO - 2018-10-12 14:27:06 --> URI Class Initialized
INFO - 2018-10-12 14:27:06 --> Router Class Initialized
INFO - 2018-10-12 14:27:06 --> Output Class Initialized
INFO - 2018-10-12 14:27:06 --> Security Class Initialized
DEBUG - 2018-10-12 14:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:27:06 --> CSRF cookie sent
INFO - 2018-10-12 14:27:06 --> Input Class Initialized
INFO - 2018-10-12 14:27:06 --> Language Class Initialized
INFO - 2018-10-12 14:27:06 --> Loader Class Initialized
INFO - 2018-10-12 14:27:06 --> Helper loaded: url_helper
INFO - 2018-10-12 14:27:06 --> Helper loaded: form_helper
INFO - 2018-10-12 14:27:06 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:27:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:27:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:27:06 --> User Agent Class Initialized
INFO - 2018-10-12 14:27:06 --> Controller Class Initialized
INFO - 2018-10-12 14:27:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:27:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:27:06 --> Pixel_Model class loaded
INFO - 2018-10-12 14:27:06 --> Database Driver Class Initialized
INFO - 2018-10-12 14:27:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:27:06 --> Config Class Initialized
INFO - 2018-10-12 14:27:06 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:27:06 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:27:06 --> Utf8 Class Initialized
INFO - 2018-10-12 14:27:06 --> URI Class Initialized
INFO - 2018-10-12 14:27:06 --> Router Class Initialized
INFO - 2018-10-12 14:27:06 --> Output Class Initialized
INFO - 2018-10-12 14:27:06 --> Security Class Initialized
DEBUG - 2018-10-12 14:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:27:06 --> CSRF cookie sent
INFO - 2018-10-12 14:27:06 --> Input Class Initialized
INFO - 2018-10-12 14:27:06 --> Language Class Initialized
INFO - 2018-10-12 14:27:06 --> Loader Class Initialized
INFO - 2018-10-12 14:27:06 --> Helper loaded: url_helper
INFO - 2018-10-12 14:27:06 --> Helper loaded: form_helper
INFO - 2018-10-12 14:27:06 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:27:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:27:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:27:06 --> User Agent Class Initialized
INFO - 2018-10-12 14:27:06 --> Controller Class Initialized
INFO - 2018-10-12 14:27:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:27:06 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-12 14:27:06 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-10-12 14:27:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:27:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:27:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:27:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-10-12 14:27:06 --> Could not find the language line "req_email"
INFO - 2018-10-12 14:27:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-10-12 14:27:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:27:06 --> Final output sent to browser
DEBUG - 2018-10-12 14:27:06 --> Total execution time: 0.0343
INFO - 2018-10-12 14:27:10 --> Config Class Initialized
INFO - 2018-10-12 14:27:10 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:27:10 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:27:10 --> Utf8 Class Initialized
INFO - 2018-10-12 14:27:10 --> URI Class Initialized
INFO - 2018-10-12 14:27:10 --> Router Class Initialized
INFO - 2018-10-12 14:27:10 --> Output Class Initialized
INFO - 2018-10-12 14:27:10 --> Security Class Initialized
DEBUG - 2018-10-12 14:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:27:10 --> CSRF cookie sent
INFO - 2018-10-12 14:27:10 --> Input Class Initialized
INFO - 2018-10-12 14:27:10 --> Language Class Initialized
INFO - 2018-10-12 14:27:10 --> Loader Class Initialized
INFO - 2018-10-12 14:27:10 --> Helper loaded: url_helper
INFO - 2018-10-12 14:27:10 --> Helper loaded: form_helper
INFO - 2018-10-12 14:27:10 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:27:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:27:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:27:10 --> User Agent Class Initialized
INFO - 2018-10-12 14:27:10 --> Controller Class Initialized
INFO - 2018-10-12 14:27:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:27:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:27:10 --> Pixel_Model class loaded
INFO - 2018-10-12 14:27:10 --> Database Driver Class Initialized
INFO - 2018-10-12 14:27:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:27:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:27:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:27:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:27:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 14:27:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 14:27:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 14:27:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-10-12 14:27:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:27:11 --> Final output sent to browser
DEBUG - 2018-10-12 14:27:11 --> Total execution time: 0.0444
INFO - 2018-10-12 14:27:12 --> Config Class Initialized
INFO - 2018-10-12 14:27:12 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:27:12 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:27:12 --> Utf8 Class Initialized
INFO - 2018-10-12 14:27:12 --> URI Class Initialized
INFO - 2018-10-12 14:27:12 --> Router Class Initialized
INFO - 2018-10-12 14:27:12 --> Output Class Initialized
INFO - 2018-10-12 14:27:12 --> Security Class Initialized
DEBUG - 2018-10-12 14:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:27:12 --> CSRF cookie sent
INFO - 2018-10-12 14:27:12 --> CSRF token verified
INFO - 2018-10-12 14:27:12 --> Input Class Initialized
INFO - 2018-10-12 14:27:12 --> Language Class Initialized
INFO - 2018-10-12 14:27:12 --> Loader Class Initialized
INFO - 2018-10-12 14:27:12 --> Helper loaded: url_helper
INFO - 2018-10-12 14:27:12 --> Helper loaded: form_helper
INFO - 2018-10-12 14:27:12 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:27:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:27:12 --> User Agent Class Initialized
INFO - 2018-10-12 14:27:12 --> Controller Class Initialized
INFO - 2018-10-12 14:27:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:27:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:27:12 --> Pixel_Model class loaded
INFO - 2018-10-12 14:27:12 --> Database Driver Class Initialized
INFO - 2018-10-12 14:27:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:27:12 --> Database Driver Class Initialized
INFO - 2018-10-12 14:27:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:27:12 --> Config Class Initialized
INFO - 2018-10-12 14:27:12 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:27:12 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:27:12 --> Utf8 Class Initialized
INFO - 2018-10-12 14:27:12 --> URI Class Initialized
INFO - 2018-10-12 14:27:12 --> Router Class Initialized
INFO - 2018-10-12 14:27:12 --> Output Class Initialized
INFO - 2018-10-12 14:27:12 --> Security Class Initialized
DEBUG - 2018-10-12 14:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:27:12 --> CSRF cookie sent
INFO - 2018-10-12 14:27:12 --> Input Class Initialized
INFO - 2018-10-12 14:27:12 --> Language Class Initialized
INFO - 2018-10-12 14:27:12 --> Loader Class Initialized
INFO - 2018-10-12 14:27:12 --> Helper loaded: url_helper
INFO - 2018-10-12 14:27:12 --> Helper loaded: form_helper
INFO - 2018-10-12 14:27:12 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:27:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:27:12 --> User Agent Class Initialized
INFO - 2018-10-12 14:27:12 --> Controller Class Initialized
INFO - 2018-10-12 14:27:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:27:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:27:12 --> Pixel_Model class loaded
INFO - 2018-10-12 14:27:12 --> Database Driver Class Initialized
INFO - 2018-10-12 14:27:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:27:12 --> Database Driver Class Initialized
INFO - 2018-10-12 14:27:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:27:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:27:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:27:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:27:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 14:27:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 14:27:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 14:27:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-12 14:27:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:27:12 --> Final output sent to browser
DEBUG - 2018-10-12 14:27:12 --> Total execution time: 0.0413
INFO - 2018-10-12 14:27:24 --> Config Class Initialized
INFO - 2018-10-12 14:27:24 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:27:24 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:27:24 --> Utf8 Class Initialized
INFO - 2018-10-12 14:27:24 --> URI Class Initialized
INFO - 2018-10-12 14:27:24 --> Router Class Initialized
INFO - 2018-10-12 14:27:24 --> Output Class Initialized
INFO - 2018-10-12 14:27:24 --> Security Class Initialized
DEBUG - 2018-10-12 14:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:27:24 --> CSRF cookie sent
INFO - 2018-10-12 14:27:24 --> Input Class Initialized
INFO - 2018-10-12 14:27:24 --> Language Class Initialized
INFO - 2018-10-12 14:27:24 --> Loader Class Initialized
INFO - 2018-10-12 14:27:24 --> Helper loaded: url_helper
INFO - 2018-10-12 14:27:24 --> Helper loaded: form_helper
INFO - 2018-10-12 14:27:24 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:27:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:27:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:27:24 --> User Agent Class Initialized
INFO - 2018-10-12 14:27:24 --> Controller Class Initialized
INFO - 2018-10-12 14:27:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:27:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:27:24 --> Pixel_Model class loaded
INFO - 2018-10-12 14:27:24 --> Database Driver Class Initialized
INFO - 2018-10-12 14:27:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:27:24 --> Database Driver Class Initialized
INFO - 2018-10-12 14:27:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:27:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:27:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:27:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-10-12 14:27:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:27:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 14:27:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 14:27:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 14:27:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-10-12 14:27:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:27:24 --> Final output sent to browser
DEBUG - 2018-10-12 14:27:24 --> Total execution time: 0.0419
INFO - 2018-10-12 14:27:26 --> Config Class Initialized
INFO - 2018-10-12 14:27:26 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:27:26 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:27:26 --> Utf8 Class Initialized
INFO - 2018-10-12 14:27:26 --> URI Class Initialized
INFO - 2018-10-12 14:27:26 --> Router Class Initialized
INFO - 2018-10-12 14:27:26 --> Output Class Initialized
INFO - 2018-10-12 14:27:26 --> Security Class Initialized
DEBUG - 2018-10-12 14:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:27:26 --> CSRF cookie sent
INFO - 2018-10-12 14:27:26 --> CSRF token verified
INFO - 2018-10-12 14:27:26 --> Input Class Initialized
INFO - 2018-10-12 14:27:26 --> Language Class Initialized
INFO - 2018-10-12 14:27:26 --> Loader Class Initialized
INFO - 2018-10-12 14:27:26 --> Helper loaded: url_helper
INFO - 2018-10-12 14:27:26 --> Helper loaded: form_helper
INFO - 2018-10-12 14:27:26 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:27:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:27:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:27:26 --> User Agent Class Initialized
INFO - 2018-10-12 14:27:26 --> Controller Class Initialized
INFO - 2018-10-12 14:27:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:27:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:27:26 --> Pixel_Model class loaded
INFO - 2018-10-12 14:27:26 --> Database Driver Class Initialized
INFO - 2018-10-12 14:27:26 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:27:26 --> Form Validation Class Initialized
INFO - 2018-10-12 14:27:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-12 14:27:26 --> Database Driver Class Initialized
INFO - 2018-10-12 14:27:26 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:27:26 --> Config Class Initialized
INFO - 2018-10-12 14:27:26 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:27:26 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:27:26 --> Utf8 Class Initialized
INFO - 2018-10-12 14:27:26 --> URI Class Initialized
INFO - 2018-10-12 14:27:26 --> Router Class Initialized
INFO - 2018-10-12 14:27:26 --> Output Class Initialized
INFO - 2018-10-12 14:27:26 --> Security Class Initialized
DEBUG - 2018-10-12 14:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:27:26 --> CSRF cookie sent
INFO - 2018-10-12 14:27:26 --> Input Class Initialized
INFO - 2018-10-12 14:27:26 --> Language Class Initialized
INFO - 2018-10-12 14:27:26 --> Loader Class Initialized
INFO - 2018-10-12 14:27:26 --> Helper loaded: url_helper
INFO - 2018-10-12 14:27:26 --> Helper loaded: form_helper
INFO - 2018-10-12 14:27:26 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:27:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:27:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:27:26 --> User Agent Class Initialized
INFO - 2018-10-12 14:27:26 --> Controller Class Initialized
INFO - 2018-10-12 14:27:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:27:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:27:26 --> Pixel_Model class loaded
INFO - 2018-10-12 14:27:26 --> Database Driver Class Initialized
INFO - 2018-10-12 14:27:26 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:27:26 --> Database Driver Class Initialized
INFO - 2018-10-12 14:27:26 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:27:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:27:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:27:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:27:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 14:27:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 14:27:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 14:27:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-12 14:27:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:27:26 --> Final output sent to browser
DEBUG - 2018-10-12 14:27:26 --> Total execution time: 0.0407
INFO - 2018-10-12 14:27:31 --> Config Class Initialized
INFO - 2018-10-12 14:27:31 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:27:31 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:27:31 --> Utf8 Class Initialized
INFO - 2018-10-12 14:27:31 --> URI Class Initialized
INFO - 2018-10-12 14:27:31 --> Router Class Initialized
INFO - 2018-10-12 14:27:31 --> Output Class Initialized
INFO - 2018-10-12 14:27:31 --> Security Class Initialized
DEBUG - 2018-10-12 14:27:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:27:31 --> CSRF cookie sent
INFO - 2018-10-12 14:27:31 --> CSRF token verified
INFO - 2018-10-12 14:27:31 --> Input Class Initialized
INFO - 2018-10-12 14:27:31 --> Language Class Initialized
INFO - 2018-10-12 14:27:31 --> Loader Class Initialized
INFO - 2018-10-12 14:27:31 --> Helper loaded: url_helper
INFO - 2018-10-12 14:27:31 --> Helper loaded: form_helper
INFO - 2018-10-12 14:27:31 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:27:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:27:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:27:31 --> User Agent Class Initialized
INFO - 2018-10-12 14:27:31 --> Controller Class Initialized
INFO - 2018-10-12 14:27:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:27:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:27:31 --> Pixel_Model class loaded
INFO - 2018-10-12 14:27:31 --> Database Driver Class Initialized
INFO - 2018-10-12 14:27:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:27:31 --> Form Validation Class Initialized
INFO - 2018-10-12 14:27:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-12 14:27:31 --> Database Driver Class Initialized
INFO - 2018-10-12 14:27:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:27:31 --> Config Class Initialized
INFO - 2018-10-12 14:27:31 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:27:31 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:27:31 --> Utf8 Class Initialized
INFO - 2018-10-12 14:27:31 --> URI Class Initialized
INFO - 2018-10-12 14:27:31 --> Router Class Initialized
INFO - 2018-10-12 14:27:31 --> Output Class Initialized
INFO - 2018-10-12 14:27:31 --> Security Class Initialized
DEBUG - 2018-10-12 14:27:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:27:31 --> CSRF cookie sent
INFO - 2018-10-12 14:27:31 --> Input Class Initialized
INFO - 2018-10-12 14:27:31 --> Language Class Initialized
INFO - 2018-10-12 14:27:31 --> Loader Class Initialized
INFO - 2018-10-12 14:27:31 --> Helper loaded: url_helper
INFO - 2018-10-12 14:27:31 --> Helper loaded: form_helper
INFO - 2018-10-12 14:27:31 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:27:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:27:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:27:31 --> User Agent Class Initialized
INFO - 2018-10-12 14:27:31 --> Controller Class Initialized
INFO - 2018-10-12 14:27:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:27:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:27:31 --> Pixel_Model class loaded
INFO - 2018-10-12 14:27:31 --> Database Driver Class Initialized
INFO - 2018-10-12 14:27:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:27:31 --> Database Driver Class Initialized
INFO - 2018-10-12 14:27:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:27:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:27:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:27:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:27:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 14:27:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 14:27:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 14:27:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-10-12 14:27:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:27:31 --> Final output sent to browser
DEBUG - 2018-10-12 14:27:31 --> Total execution time: 0.0474
INFO - 2018-10-12 14:27:37 --> Config Class Initialized
INFO - 2018-10-12 14:27:37 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:27:37 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:27:37 --> Utf8 Class Initialized
INFO - 2018-10-12 14:27:37 --> URI Class Initialized
INFO - 2018-10-12 14:27:37 --> Router Class Initialized
INFO - 2018-10-12 14:27:37 --> Output Class Initialized
INFO - 2018-10-12 14:27:37 --> Security Class Initialized
DEBUG - 2018-10-12 14:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:27:37 --> CSRF cookie sent
INFO - 2018-10-12 14:27:37 --> CSRF token verified
INFO - 2018-10-12 14:27:37 --> Input Class Initialized
INFO - 2018-10-12 14:27:37 --> Language Class Initialized
INFO - 2018-10-12 14:27:37 --> Loader Class Initialized
INFO - 2018-10-12 14:27:37 --> Helper loaded: url_helper
INFO - 2018-10-12 14:27:37 --> Helper loaded: form_helper
INFO - 2018-10-12 14:27:37 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:27:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:27:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:27:37 --> User Agent Class Initialized
INFO - 2018-10-12 14:27:37 --> Controller Class Initialized
INFO - 2018-10-12 14:27:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:27:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:27:37 --> Pixel_Model class loaded
INFO - 2018-10-12 14:27:37 --> Database Driver Class Initialized
INFO - 2018-10-12 14:27:37 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:27:37 --> Form Validation Class Initialized
INFO - 2018-10-12 14:27:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-12 14:27:37 --> Database Driver Class Initialized
INFO - 2018-10-12 14:27:37 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:27:38 --> Config Class Initialized
INFO - 2018-10-12 14:27:38 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:27:38 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:27:38 --> Utf8 Class Initialized
INFO - 2018-10-12 14:27:38 --> URI Class Initialized
INFO - 2018-10-12 14:27:38 --> Router Class Initialized
INFO - 2018-10-12 14:27:38 --> Output Class Initialized
INFO - 2018-10-12 14:27:38 --> Security Class Initialized
DEBUG - 2018-10-12 14:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:27:38 --> CSRF cookie sent
INFO - 2018-10-12 14:27:38 --> Input Class Initialized
INFO - 2018-10-12 14:27:38 --> Language Class Initialized
INFO - 2018-10-12 14:27:38 --> Loader Class Initialized
INFO - 2018-10-12 14:27:38 --> Helper loaded: url_helper
INFO - 2018-10-12 14:27:38 --> Helper loaded: form_helper
INFO - 2018-10-12 14:27:38 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:27:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:27:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:27:38 --> User Agent Class Initialized
INFO - 2018-10-12 14:27:38 --> Controller Class Initialized
INFO - 2018-10-12 14:27:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:27:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:27:38 --> Pixel_Model class loaded
INFO - 2018-10-12 14:27:38 --> Database Driver Class Initialized
INFO - 2018-10-12 14:27:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:27:38 --> Database Driver Class Initialized
INFO - 2018-10-12 14:27:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:27:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:27:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:27:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:27:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 14:27:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 14:27:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 14:27:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_title.php
INFO - 2018-10-12 14:27:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:27:38 --> Final output sent to browser
DEBUG - 2018-10-12 14:27:38 --> Total execution time: 0.0585
INFO - 2018-10-12 14:27:40 --> Config Class Initialized
INFO - 2018-10-12 14:27:40 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:27:40 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:27:40 --> Utf8 Class Initialized
INFO - 2018-10-12 14:27:40 --> URI Class Initialized
INFO - 2018-10-12 14:27:40 --> Router Class Initialized
INFO - 2018-10-12 14:27:40 --> Output Class Initialized
INFO - 2018-10-12 14:27:40 --> Security Class Initialized
DEBUG - 2018-10-12 14:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:27:40 --> CSRF cookie sent
INFO - 2018-10-12 14:27:40 --> CSRF token verified
INFO - 2018-10-12 14:27:40 --> Input Class Initialized
INFO - 2018-10-12 14:27:40 --> Language Class Initialized
INFO - 2018-10-12 14:27:40 --> Loader Class Initialized
INFO - 2018-10-12 14:27:40 --> Helper loaded: url_helper
INFO - 2018-10-12 14:27:40 --> Helper loaded: form_helper
INFO - 2018-10-12 14:27:40 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:27:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:27:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:27:40 --> User Agent Class Initialized
INFO - 2018-10-12 14:27:40 --> Controller Class Initialized
INFO - 2018-10-12 14:27:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:27:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:27:40 --> Pixel_Model class loaded
INFO - 2018-10-12 14:27:40 --> Database Driver Class Initialized
INFO - 2018-10-12 14:27:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:27:40 --> Form Validation Class Initialized
INFO - 2018-10-12 14:27:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-12 14:27:40 --> Database Driver Class Initialized
INFO - 2018-10-12 14:27:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:27:40 --> Config Class Initialized
INFO - 2018-10-12 14:27:40 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:27:40 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:27:40 --> Utf8 Class Initialized
INFO - 2018-10-12 14:27:40 --> URI Class Initialized
INFO - 2018-10-12 14:27:40 --> Router Class Initialized
INFO - 2018-10-12 14:27:40 --> Output Class Initialized
INFO - 2018-10-12 14:27:40 --> Security Class Initialized
DEBUG - 2018-10-12 14:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:27:40 --> CSRF cookie sent
INFO - 2018-10-12 14:27:40 --> Input Class Initialized
INFO - 2018-10-12 14:27:40 --> Language Class Initialized
INFO - 2018-10-12 14:27:40 --> Loader Class Initialized
INFO - 2018-10-12 14:27:40 --> Helper loaded: url_helper
INFO - 2018-10-12 14:27:40 --> Helper loaded: form_helper
INFO - 2018-10-12 14:27:40 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:27:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:27:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:27:40 --> User Agent Class Initialized
INFO - 2018-10-12 14:27:40 --> Controller Class Initialized
INFO - 2018-10-12 14:27:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:27:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:27:40 --> Pixel_Model class loaded
INFO - 2018-10-12 14:27:40 --> Database Driver Class Initialized
INFO - 2018-10-12 14:27:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:27:40 --> Database Driver Class Initialized
INFO - 2018-10-12 14:27:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:27:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:27:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:27:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:27:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 14:27:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 14:27:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 14:27:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-10-12 14:27:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:27:40 --> Final output sent to browser
DEBUG - 2018-10-12 14:27:40 --> Total execution time: 0.0473
INFO - 2018-10-12 14:27:43 --> Config Class Initialized
INFO - 2018-10-12 14:27:43 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:27:43 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:27:43 --> Utf8 Class Initialized
INFO - 2018-10-12 14:27:43 --> URI Class Initialized
INFO - 2018-10-12 14:27:43 --> Router Class Initialized
INFO - 2018-10-12 14:27:43 --> Output Class Initialized
INFO - 2018-10-12 14:27:43 --> Security Class Initialized
DEBUG - 2018-10-12 14:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:27:43 --> CSRF cookie sent
INFO - 2018-10-12 14:27:43 --> Input Class Initialized
INFO - 2018-10-12 14:27:43 --> Language Class Initialized
INFO - 2018-10-12 14:27:43 --> Loader Class Initialized
INFO - 2018-10-12 14:27:43 --> Helper loaded: url_helper
INFO - 2018-10-12 14:27:43 --> Helper loaded: form_helper
INFO - 2018-10-12 14:27:43 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:27:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:27:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:27:43 --> User Agent Class Initialized
INFO - 2018-10-12 14:27:43 --> Controller Class Initialized
INFO - 2018-10-12 14:27:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:27:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:27:43 --> Pixel_Model class loaded
INFO - 2018-10-12 14:27:43 --> Database Driver Class Initialized
INFO - 2018-10-12 14:27:43 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:27:43 --> Database Driver Class Initialized
INFO - 2018-10-12 14:27:43 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:27:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:27:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:27:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:27:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 14:27:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-10-12 14:27:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:27:43 --> Final output sent to browser
DEBUG - 2018-10-12 14:27:43 --> Total execution time: 0.0684
INFO - 2018-10-12 14:27:46 --> Config Class Initialized
INFO - 2018-10-12 14:27:46 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:27:46 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:27:46 --> Utf8 Class Initialized
INFO - 2018-10-12 14:27:46 --> URI Class Initialized
INFO - 2018-10-12 14:27:46 --> Router Class Initialized
INFO - 2018-10-12 14:27:46 --> Output Class Initialized
INFO - 2018-10-12 14:27:46 --> Security Class Initialized
DEBUG - 2018-10-12 14:27:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:27:46 --> CSRF cookie sent
INFO - 2018-10-12 14:27:46 --> Input Class Initialized
INFO - 2018-10-12 14:27:46 --> Language Class Initialized
INFO - 2018-10-12 14:27:46 --> Loader Class Initialized
INFO - 2018-10-12 14:27:46 --> Helper loaded: url_helper
INFO - 2018-10-12 14:27:46 --> Helper loaded: form_helper
INFO - 2018-10-12 14:27:46 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:27:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:27:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:27:46 --> User Agent Class Initialized
INFO - 2018-10-12 14:27:46 --> Controller Class Initialized
INFO - 2018-10-12 14:27:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:27:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:27:46 --> Pixel_Model class loaded
INFO - 2018-10-12 14:27:46 --> Database Driver Class Initialized
INFO - 2018-10-12 14:27:46 --> Model "MyAccountModel" initialized
ERROR - 2018-10-12 14:27:46 --> 404 Page Not Found: 
INFO - 2018-10-12 14:27:49 --> Config Class Initialized
INFO - 2018-10-12 14:27:49 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:27:49 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:27:49 --> Utf8 Class Initialized
INFO - 2018-10-12 14:27:49 --> URI Class Initialized
INFO - 2018-10-12 14:27:49 --> Router Class Initialized
INFO - 2018-10-12 14:27:49 --> Output Class Initialized
INFO - 2018-10-12 14:27:49 --> Security Class Initialized
DEBUG - 2018-10-12 14:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:27:49 --> CSRF cookie sent
INFO - 2018-10-12 14:27:49 --> Input Class Initialized
INFO - 2018-10-12 14:27:49 --> Language Class Initialized
INFO - 2018-10-12 14:27:49 --> Loader Class Initialized
INFO - 2018-10-12 14:27:49 --> Helper loaded: url_helper
INFO - 2018-10-12 14:27:49 --> Helper loaded: form_helper
INFO - 2018-10-12 14:27:49 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:27:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:27:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:27:49 --> User Agent Class Initialized
INFO - 2018-10-12 14:27:49 --> Controller Class Initialized
INFO - 2018-10-12 14:27:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:27:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:27:49 --> Pixel_Model class loaded
INFO - 2018-10-12 14:27:49 --> Database Driver Class Initialized
INFO - 2018-10-12 14:27:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:27:49 --> Database Driver Class Initialized
INFO - 2018-10-12 14:27:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:27:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:27:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:27:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:27:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 14:27:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-10-12 14:27:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:27:49 --> Final output sent to browser
DEBUG - 2018-10-12 14:27:49 --> Total execution time: 0.0640
INFO - 2018-10-12 14:27:50 --> Config Class Initialized
INFO - 2018-10-12 14:27:50 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:27:50 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:27:50 --> Utf8 Class Initialized
INFO - 2018-10-12 14:27:50 --> URI Class Initialized
INFO - 2018-10-12 14:27:50 --> Router Class Initialized
INFO - 2018-10-12 14:27:50 --> Output Class Initialized
INFO - 2018-10-12 14:27:50 --> Security Class Initialized
DEBUG - 2018-10-12 14:27:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:27:50 --> CSRF cookie sent
INFO - 2018-10-12 14:27:50 --> Input Class Initialized
INFO - 2018-10-12 14:27:50 --> Language Class Initialized
INFO - 2018-10-12 14:27:50 --> Loader Class Initialized
INFO - 2018-10-12 14:27:50 --> Helper loaded: url_helper
INFO - 2018-10-12 14:27:50 --> Helper loaded: form_helper
INFO - 2018-10-12 14:27:50 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:27:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:27:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:27:50 --> User Agent Class Initialized
INFO - 2018-10-12 14:27:50 --> Controller Class Initialized
INFO - 2018-10-12 14:27:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:27:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:27:50 --> Pixel_Model class loaded
INFO - 2018-10-12 14:27:50 --> Database Driver Class Initialized
INFO - 2018-10-12 14:27:50 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:27:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:27:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:27:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:27:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 14:27:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/contact_us.php
INFO - 2018-10-12 14:27:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:27:50 --> Final output sent to browser
DEBUG - 2018-10-12 14:27:50 --> Total execution time: 0.0598
INFO - 2018-10-12 14:27:52 --> Config Class Initialized
INFO - 2018-10-12 14:27:52 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:27:52 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:27:52 --> Utf8 Class Initialized
INFO - 2018-10-12 14:27:52 --> URI Class Initialized
INFO - 2018-10-12 14:27:52 --> Router Class Initialized
INFO - 2018-10-12 14:27:52 --> Output Class Initialized
INFO - 2018-10-12 14:27:52 --> Security Class Initialized
DEBUG - 2018-10-12 14:27:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:27:52 --> CSRF cookie sent
INFO - 2018-10-12 14:27:52 --> Input Class Initialized
INFO - 2018-10-12 14:27:52 --> Language Class Initialized
INFO - 2018-10-12 14:27:52 --> Loader Class Initialized
INFO - 2018-10-12 14:27:52 --> Helper loaded: url_helper
INFO - 2018-10-12 14:27:52 --> Helper loaded: form_helper
INFO - 2018-10-12 14:27:52 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:27:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:27:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:27:52 --> User Agent Class Initialized
INFO - 2018-10-12 14:27:52 --> Controller Class Initialized
INFO - 2018-10-12 14:27:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:27:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:27:52 --> Pixel_Model class loaded
INFO - 2018-10-12 14:27:52 --> Database Driver Class Initialized
INFO - 2018-10-12 14:27:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:27:52 --> Database Driver Class Initialized
INFO - 2018-10-12 14:27:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:27:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:27:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:27:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:27:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 14:27:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-10-12 14:27:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:27:52 --> Final output sent to browser
DEBUG - 2018-10-12 14:27:52 --> Total execution time: 0.0453
INFO - 2018-10-12 14:27:54 --> Config Class Initialized
INFO - 2018-10-12 14:27:54 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:27:54 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:27:54 --> Utf8 Class Initialized
INFO - 2018-10-12 14:27:54 --> URI Class Initialized
INFO - 2018-10-12 14:27:54 --> Router Class Initialized
INFO - 2018-10-12 14:27:54 --> Output Class Initialized
INFO - 2018-10-12 14:27:54 --> Security Class Initialized
DEBUG - 2018-10-12 14:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:27:54 --> CSRF cookie sent
INFO - 2018-10-12 14:27:54 --> Input Class Initialized
INFO - 2018-10-12 14:27:54 --> Language Class Initialized
INFO - 2018-10-12 14:27:54 --> Loader Class Initialized
INFO - 2018-10-12 14:27:54 --> Helper loaded: url_helper
INFO - 2018-10-12 14:27:54 --> Helper loaded: form_helper
INFO - 2018-10-12 14:27:54 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:27:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:27:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:27:54 --> User Agent Class Initialized
INFO - 2018-10-12 14:27:54 --> Controller Class Initialized
INFO - 2018-10-12 14:27:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:27:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:27:54 --> Pixel_Model class loaded
INFO - 2018-10-12 14:27:54 --> Database Driver Class Initialized
INFO - 2018-10-12 14:27:54 --> Model "MyAccountModel" initialized
ERROR - 2018-10-12 14:27:54 --> 404 Page Not Found: 
INFO - 2018-10-12 14:27:55 --> Config Class Initialized
INFO - 2018-10-12 14:27:55 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:27:55 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:27:55 --> Utf8 Class Initialized
INFO - 2018-10-12 14:27:55 --> URI Class Initialized
INFO - 2018-10-12 14:27:55 --> Router Class Initialized
INFO - 2018-10-12 14:27:55 --> Output Class Initialized
INFO - 2018-10-12 14:27:55 --> Security Class Initialized
DEBUG - 2018-10-12 14:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:27:55 --> CSRF cookie sent
INFO - 2018-10-12 14:27:55 --> Input Class Initialized
INFO - 2018-10-12 14:27:55 --> Language Class Initialized
INFO - 2018-10-12 14:27:55 --> Loader Class Initialized
INFO - 2018-10-12 14:27:55 --> Helper loaded: url_helper
INFO - 2018-10-12 14:27:55 --> Helper loaded: form_helper
INFO - 2018-10-12 14:27:55 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:27:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:27:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:27:55 --> User Agent Class Initialized
INFO - 2018-10-12 14:27:55 --> Controller Class Initialized
INFO - 2018-10-12 14:27:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:27:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:27:55 --> Pixel_Model class loaded
INFO - 2018-10-12 14:27:55 --> Database Driver Class Initialized
INFO - 2018-10-12 14:27:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:27:55 --> Database Driver Class Initialized
INFO - 2018-10-12 14:27:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:27:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:27:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:27:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:27:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 14:27:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-10-12 14:27:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:27:55 --> Final output sent to browser
DEBUG - 2018-10-12 14:27:55 --> Total execution time: 0.0605
INFO - 2018-10-12 14:27:57 --> Config Class Initialized
INFO - 2018-10-12 14:27:57 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:27:57 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:27:57 --> Utf8 Class Initialized
INFO - 2018-10-12 14:27:57 --> URI Class Initialized
INFO - 2018-10-12 14:27:57 --> Router Class Initialized
INFO - 2018-10-12 14:27:57 --> Output Class Initialized
INFO - 2018-10-12 14:27:57 --> Security Class Initialized
DEBUG - 2018-10-12 14:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:27:57 --> CSRF cookie sent
INFO - 2018-10-12 14:27:57 --> Input Class Initialized
INFO - 2018-10-12 14:27:57 --> Language Class Initialized
INFO - 2018-10-12 14:27:57 --> Loader Class Initialized
INFO - 2018-10-12 14:27:57 --> Helper loaded: url_helper
INFO - 2018-10-12 14:27:57 --> Helper loaded: form_helper
INFO - 2018-10-12 14:27:57 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:27:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:27:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:27:57 --> User Agent Class Initialized
INFO - 2018-10-12 14:27:57 --> Controller Class Initialized
INFO - 2018-10-12 14:27:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:27:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:27:57 --> Pixel_Model class loaded
INFO - 2018-10-12 14:27:57 --> Database Driver Class Initialized
INFO - 2018-10-12 14:27:57 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:27:57 --> Database Driver Class Initialized
INFO - 2018-10-12 14:27:57 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:27:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:27:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:27:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:27:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 14:27:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 14:27:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 14:27:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-10-12 14:27:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:27:57 --> Final output sent to browser
DEBUG - 2018-10-12 14:27:57 --> Total execution time: 0.0580
INFO - 2018-10-12 14:27:58 --> Config Class Initialized
INFO - 2018-10-12 14:27:58 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:27:58 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:27:58 --> Utf8 Class Initialized
INFO - 2018-10-12 14:27:58 --> URI Class Initialized
INFO - 2018-10-12 14:27:58 --> Router Class Initialized
INFO - 2018-10-12 14:27:58 --> Output Class Initialized
INFO - 2018-10-12 14:27:58 --> Security Class Initialized
DEBUG - 2018-10-12 14:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:27:58 --> CSRF cookie sent
INFO - 2018-10-12 14:27:58 --> Input Class Initialized
INFO - 2018-10-12 14:27:58 --> Language Class Initialized
INFO - 2018-10-12 14:27:58 --> Loader Class Initialized
INFO - 2018-10-12 14:27:58 --> Helper loaded: url_helper
INFO - 2018-10-12 14:27:58 --> Helper loaded: form_helper
INFO - 2018-10-12 14:27:58 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:27:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:27:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:27:58 --> User Agent Class Initialized
INFO - 2018-10-12 14:27:58 --> Controller Class Initialized
INFO - 2018-10-12 14:27:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:27:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:27:58 --> Pixel_Model class loaded
INFO - 2018-10-12 14:27:58 --> Database Driver Class Initialized
INFO - 2018-10-12 14:27:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:27:58 --> Database Driver Class Initialized
INFO - 2018-10-12 14:27:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:27:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:27:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:27:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:27:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 14:27:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 14:27:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 14:27:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_title.php
INFO - 2018-10-12 14:27:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:27:58 --> Final output sent to browser
DEBUG - 2018-10-12 14:27:58 --> Total execution time: 0.0472
INFO - 2018-10-12 14:27:59 --> Config Class Initialized
INFO - 2018-10-12 14:27:59 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:27:59 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:27:59 --> Utf8 Class Initialized
INFO - 2018-10-12 14:27:59 --> URI Class Initialized
INFO - 2018-10-12 14:27:59 --> Router Class Initialized
INFO - 2018-10-12 14:27:59 --> Output Class Initialized
INFO - 2018-10-12 14:27:59 --> Security Class Initialized
DEBUG - 2018-10-12 14:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:27:59 --> CSRF cookie sent
INFO - 2018-10-12 14:27:59 --> CSRF token verified
INFO - 2018-10-12 14:27:59 --> Input Class Initialized
INFO - 2018-10-12 14:27:59 --> Language Class Initialized
INFO - 2018-10-12 14:27:59 --> Loader Class Initialized
INFO - 2018-10-12 14:27:59 --> Helper loaded: url_helper
INFO - 2018-10-12 14:27:59 --> Helper loaded: form_helper
INFO - 2018-10-12 14:27:59 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:27:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:27:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:27:59 --> User Agent Class Initialized
INFO - 2018-10-12 14:27:59 --> Controller Class Initialized
INFO - 2018-10-12 14:27:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:27:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:27:59 --> Pixel_Model class loaded
INFO - 2018-10-12 14:27:59 --> Database Driver Class Initialized
INFO - 2018-10-12 14:27:59 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:27:59 --> Form Validation Class Initialized
INFO - 2018-10-12 14:27:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-12 14:27:59 --> Database Driver Class Initialized
INFO - 2018-10-12 14:27:59 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:27:59 --> Config Class Initialized
INFO - 2018-10-12 14:27:59 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:27:59 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:27:59 --> Utf8 Class Initialized
INFO - 2018-10-12 14:27:59 --> URI Class Initialized
INFO - 2018-10-12 14:27:59 --> Router Class Initialized
INFO - 2018-10-12 14:27:59 --> Output Class Initialized
INFO - 2018-10-12 14:27:59 --> Security Class Initialized
DEBUG - 2018-10-12 14:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:27:59 --> CSRF cookie sent
INFO - 2018-10-12 14:27:59 --> Input Class Initialized
INFO - 2018-10-12 14:27:59 --> Language Class Initialized
INFO - 2018-10-12 14:27:59 --> Loader Class Initialized
INFO - 2018-10-12 14:27:59 --> Helper loaded: url_helper
INFO - 2018-10-12 14:27:59 --> Helper loaded: form_helper
INFO - 2018-10-12 14:27:59 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:27:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:27:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:27:59 --> User Agent Class Initialized
INFO - 2018-10-12 14:27:59 --> Controller Class Initialized
INFO - 2018-10-12 14:27:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:27:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:27:59 --> Pixel_Model class loaded
INFO - 2018-10-12 14:27:59 --> Database Driver Class Initialized
INFO - 2018-10-12 14:27:59 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:27:59 --> Database Driver Class Initialized
INFO - 2018-10-12 14:27:59 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:27:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:27:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:27:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:27:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 14:27:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 14:27:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 14:27:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-10-12 14:27:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:27:59 --> Final output sent to browser
DEBUG - 2018-10-12 14:27:59 --> Total execution time: 0.0466
INFO - 2018-10-12 14:28:00 --> Config Class Initialized
INFO - 2018-10-12 14:28:00 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:28:00 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:28:00 --> Utf8 Class Initialized
INFO - 2018-10-12 14:28:00 --> URI Class Initialized
INFO - 2018-10-12 14:28:00 --> Router Class Initialized
INFO - 2018-10-12 14:28:00 --> Output Class Initialized
INFO - 2018-10-12 14:28:00 --> Security Class Initialized
DEBUG - 2018-10-12 14:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:28:00 --> CSRF cookie sent
INFO - 2018-10-12 14:28:00 --> CSRF token verified
INFO - 2018-10-12 14:28:00 --> Input Class Initialized
INFO - 2018-10-12 14:28:00 --> Language Class Initialized
INFO - 2018-10-12 14:28:00 --> Loader Class Initialized
INFO - 2018-10-12 14:28:00 --> Helper loaded: url_helper
INFO - 2018-10-12 14:28:00 --> Helper loaded: form_helper
INFO - 2018-10-12 14:28:00 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:28:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:28:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:28:00 --> User Agent Class Initialized
INFO - 2018-10-12 14:28:00 --> Controller Class Initialized
INFO - 2018-10-12 14:28:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:28:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:28:00 --> Pixel_Model class loaded
INFO - 2018-10-12 14:28:00 --> Database Driver Class Initialized
INFO - 2018-10-12 14:28:00 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:28:00 --> Form Validation Class Initialized
INFO - 2018-10-12 14:28:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-12 14:28:00 --> Database Driver Class Initialized
INFO - 2018-10-12 14:28:00 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:28:01 --> Config Class Initialized
INFO - 2018-10-12 14:28:01 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:28:01 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:28:01 --> Utf8 Class Initialized
INFO - 2018-10-12 14:28:01 --> URI Class Initialized
INFO - 2018-10-12 14:28:01 --> Router Class Initialized
INFO - 2018-10-12 14:28:01 --> Output Class Initialized
INFO - 2018-10-12 14:28:01 --> Security Class Initialized
DEBUG - 2018-10-12 14:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:28:01 --> CSRF cookie sent
INFO - 2018-10-12 14:28:01 --> Input Class Initialized
INFO - 2018-10-12 14:28:01 --> Language Class Initialized
INFO - 2018-10-12 14:28:01 --> Loader Class Initialized
INFO - 2018-10-12 14:28:01 --> Helper loaded: url_helper
INFO - 2018-10-12 14:28:01 --> Helper loaded: form_helper
INFO - 2018-10-12 14:28:01 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:28:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:28:01 --> User Agent Class Initialized
INFO - 2018-10-12 14:28:01 --> Controller Class Initialized
INFO - 2018-10-12 14:28:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:28:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:28:01 --> Pixel_Model class loaded
INFO - 2018-10-12 14:28:01 --> Database Driver Class Initialized
INFO - 2018-10-12 14:28:01 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:28:01 --> Database Driver Class Initialized
INFO - 2018-10-12 14:28:01 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:28:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:28:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:28:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:28:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 14:28:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-10-12 14:28:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:28:01 --> Final output sent to browser
DEBUG - 2018-10-12 14:28:01 --> Total execution time: 0.0559
INFO - 2018-10-12 14:28:03 --> Config Class Initialized
INFO - 2018-10-12 14:28:03 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:28:03 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:28:03 --> Utf8 Class Initialized
INFO - 2018-10-12 14:28:03 --> URI Class Initialized
INFO - 2018-10-12 14:28:03 --> Router Class Initialized
INFO - 2018-10-12 14:28:03 --> Output Class Initialized
INFO - 2018-10-12 14:28:03 --> Security Class Initialized
DEBUG - 2018-10-12 14:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:28:03 --> CSRF cookie sent
INFO - 2018-10-12 14:28:03 --> Input Class Initialized
INFO - 2018-10-12 14:28:03 --> Language Class Initialized
INFO - 2018-10-12 14:28:03 --> Loader Class Initialized
INFO - 2018-10-12 14:28:03 --> Helper loaded: url_helper
INFO - 2018-10-12 14:28:03 --> Helper loaded: form_helper
INFO - 2018-10-12 14:28:03 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:28:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:28:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:28:03 --> User Agent Class Initialized
INFO - 2018-10-12 14:28:03 --> Controller Class Initialized
INFO - 2018-10-12 14:28:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:28:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:28:03 --> Pixel_Model class loaded
INFO - 2018-10-12 14:28:03 --> Database Driver Class Initialized
INFO - 2018-10-12 14:28:03 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:28:03 --> Config Class Initialized
INFO - 2018-10-12 14:28:03 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:28:03 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:28:03 --> Utf8 Class Initialized
INFO - 2018-10-12 14:28:03 --> URI Class Initialized
INFO - 2018-10-12 14:28:03 --> Router Class Initialized
INFO - 2018-10-12 14:28:03 --> Output Class Initialized
INFO - 2018-10-12 14:28:03 --> Security Class Initialized
DEBUG - 2018-10-12 14:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:28:03 --> CSRF cookie sent
INFO - 2018-10-12 14:28:03 --> Input Class Initialized
INFO - 2018-10-12 14:28:03 --> Language Class Initialized
INFO - 2018-10-12 14:28:03 --> Loader Class Initialized
INFO - 2018-10-12 14:28:03 --> Helper loaded: url_helper
INFO - 2018-10-12 14:28:03 --> Helper loaded: form_helper
INFO - 2018-10-12 14:28:03 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:28:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:28:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:28:03 --> User Agent Class Initialized
INFO - 2018-10-12 14:28:03 --> Controller Class Initialized
INFO - 2018-10-12 14:28:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:28:03 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-12 14:28:03 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-10-12 14:28:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:28:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:28:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:28:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-10-12 14:28:03 --> Could not find the language line "req_email"
INFO - 2018-10-12 14:28:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-10-12 14:28:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:28:03 --> Final output sent to browser
DEBUG - 2018-10-12 14:28:03 --> Total execution time: 0.0230
INFO - 2018-10-12 14:28:07 --> Config Class Initialized
INFO - 2018-10-12 14:28:07 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:28:07 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:28:07 --> Utf8 Class Initialized
INFO - 2018-10-12 14:28:07 --> URI Class Initialized
INFO - 2018-10-12 14:28:07 --> Router Class Initialized
INFO - 2018-10-12 14:28:07 --> Output Class Initialized
INFO - 2018-10-12 14:28:07 --> Security Class Initialized
DEBUG - 2018-10-12 14:28:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:28:07 --> CSRF cookie sent
INFO - 2018-10-12 14:28:07 --> Input Class Initialized
INFO - 2018-10-12 14:28:07 --> Language Class Initialized
INFO - 2018-10-12 14:28:07 --> Loader Class Initialized
INFO - 2018-10-12 14:28:07 --> Helper loaded: url_helper
INFO - 2018-10-12 14:28:07 --> Helper loaded: form_helper
INFO - 2018-10-12 14:28:07 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:28:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:28:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:28:07 --> User Agent Class Initialized
INFO - 2018-10-12 14:28:07 --> Controller Class Initialized
INFO - 2018-10-12 14:28:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:28:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:28:07 --> Pixel_Model class loaded
INFO - 2018-10-12 14:28:07 --> Database Driver Class Initialized
INFO - 2018-10-12 14:28:07 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:28:07 --> Database Driver Class Initialized
INFO - 2018-10-12 14:28:07 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:28:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:28:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:28:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:28:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 14:28:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-10-12 14:28:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:28:07 --> Final output sent to browser
DEBUG - 2018-10-12 14:28:07 --> Total execution time: 0.0456
INFO - 2018-10-12 14:28:08 --> Config Class Initialized
INFO - 2018-10-12 14:28:08 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:28:08 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:28:08 --> Utf8 Class Initialized
INFO - 2018-10-12 14:28:08 --> URI Class Initialized
INFO - 2018-10-12 14:28:08 --> Router Class Initialized
INFO - 2018-10-12 14:28:08 --> Output Class Initialized
INFO - 2018-10-12 14:28:08 --> Security Class Initialized
DEBUG - 2018-10-12 14:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:28:08 --> CSRF cookie sent
INFO - 2018-10-12 14:28:08 --> Input Class Initialized
INFO - 2018-10-12 14:28:08 --> Language Class Initialized
INFO - 2018-10-12 14:28:08 --> Loader Class Initialized
INFO - 2018-10-12 14:28:08 --> Helper loaded: url_helper
INFO - 2018-10-12 14:28:08 --> Helper loaded: form_helper
INFO - 2018-10-12 14:28:08 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:28:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:28:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:28:08 --> User Agent Class Initialized
INFO - 2018-10-12 14:28:08 --> Controller Class Initialized
INFO - 2018-10-12 14:28:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:28:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:28:08 --> Pixel_Model class loaded
INFO - 2018-10-12 14:28:08 --> Database Driver Class Initialized
INFO - 2018-10-12 14:28:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:28:08 --> Database Driver Class Initialized
INFO - 2018-10-12 14:28:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:28:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:28:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:28:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:28:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 14:28:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 14:28:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 14:28:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-10-12 14:28:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:28:08 --> Final output sent to browser
DEBUG - 2018-10-12 14:28:08 --> Total execution time: 0.0548
INFO - 2018-10-12 14:28:22 --> Config Class Initialized
INFO - 2018-10-12 14:28:22 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:28:22 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:28:22 --> Utf8 Class Initialized
INFO - 2018-10-12 14:28:22 --> URI Class Initialized
INFO - 2018-10-12 14:28:22 --> Router Class Initialized
INFO - 2018-10-12 14:28:22 --> Output Class Initialized
INFO - 2018-10-12 14:28:22 --> Security Class Initialized
DEBUG - 2018-10-12 14:28:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:28:22 --> CSRF cookie sent
INFO - 2018-10-12 14:28:22 --> Input Class Initialized
INFO - 2018-10-12 14:28:22 --> Language Class Initialized
INFO - 2018-10-12 14:28:22 --> Loader Class Initialized
INFO - 2018-10-12 14:28:22 --> Helper loaded: url_helper
INFO - 2018-10-12 14:28:22 --> Helper loaded: form_helper
INFO - 2018-10-12 14:28:22 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:28:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:28:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:28:22 --> User Agent Class Initialized
INFO - 2018-10-12 14:28:22 --> Controller Class Initialized
INFO - 2018-10-12 14:28:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:28:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:28:22 --> Pixel_Model class loaded
INFO - 2018-10-12 14:28:22 --> Database Driver Class Initialized
INFO - 2018-10-12 14:28:22 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:28:22 --> Database Driver Class Initialized
INFO - 2018-10-12 14:28:22 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:28:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:28:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:28:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:28:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 14:28:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-10-12 14:28:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:28:22 --> Final output sent to browser
DEBUG - 2018-10-12 14:28:22 --> Total execution time: 0.0515
INFO - 2018-10-12 14:28:23 --> Config Class Initialized
INFO - 2018-10-12 14:28:23 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:28:23 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:28:23 --> Utf8 Class Initialized
INFO - 2018-10-12 14:28:23 --> URI Class Initialized
INFO - 2018-10-12 14:28:23 --> Router Class Initialized
INFO - 2018-10-12 14:28:23 --> Output Class Initialized
INFO - 2018-10-12 14:28:23 --> Security Class Initialized
DEBUG - 2018-10-12 14:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:28:23 --> CSRF cookie sent
INFO - 2018-10-12 14:28:23 --> Input Class Initialized
INFO - 2018-10-12 14:28:23 --> Language Class Initialized
INFO - 2018-10-12 14:28:23 --> Loader Class Initialized
INFO - 2018-10-12 14:28:23 --> Helper loaded: url_helper
INFO - 2018-10-12 14:28:23 --> Helper loaded: form_helper
INFO - 2018-10-12 14:28:23 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:28:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:28:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:28:23 --> User Agent Class Initialized
INFO - 2018-10-12 14:28:23 --> Controller Class Initialized
INFO - 2018-10-12 14:28:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:28:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:28:23 --> Pixel_Model class loaded
INFO - 2018-10-12 14:28:23 --> Database Driver Class Initialized
INFO - 2018-10-12 14:28:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:28:23 --> Config Class Initialized
INFO - 2018-10-12 14:28:23 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:28:23 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:28:23 --> Utf8 Class Initialized
INFO - 2018-10-12 14:28:23 --> URI Class Initialized
INFO - 2018-10-12 14:28:23 --> Router Class Initialized
INFO - 2018-10-12 14:28:23 --> Output Class Initialized
INFO - 2018-10-12 14:28:23 --> Security Class Initialized
DEBUG - 2018-10-12 14:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:28:23 --> CSRF cookie sent
INFO - 2018-10-12 14:28:23 --> Input Class Initialized
INFO - 2018-10-12 14:28:23 --> Language Class Initialized
INFO - 2018-10-12 14:28:23 --> Loader Class Initialized
INFO - 2018-10-12 14:28:23 --> Helper loaded: url_helper
INFO - 2018-10-12 14:28:23 --> Helper loaded: form_helper
INFO - 2018-10-12 14:28:23 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:28:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:28:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:28:23 --> User Agent Class Initialized
INFO - 2018-10-12 14:28:23 --> Controller Class Initialized
INFO - 2018-10-12 14:28:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:28:23 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-12 14:28:23 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-10-12 14:28:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:28:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:28:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:28:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-10-12 14:28:23 --> Could not find the language line "req_email"
INFO - 2018-10-12 14:28:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-10-12 14:28:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:28:23 --> Final output sent to browser
DEBUG - 2018-10-12 14:28:23 --> Total execution time: 0.0319
INFO - 2018-10-12 14:28:26 --> Config Class Initialized
INFO - 2018-10-12 14:28:26 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:28:26 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:28:26 --> Utf8 Class Initialized
INFO - 2018-10-12 14:28:26 --> URI Class Initialized
INFO - 2018-10-12 14:28:26 --> Router Class Initialized
INFO - 2018-10-12 14:28:26 --> Output Class Initialized
INFO - 2018-10-12 14:28:26 --> Security Class Initialized
DEBUG - 2018-10-12 14:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:28:26 --> CSRF cookie sent
INFO - 2018-10-12 14:28:26 --> Input Class Initialized
INFO - 2018-10-12 14:28:26 --> Language Class Initialized
INFO - 2018-10-12 14:28:26 --> Loader Class Initialized
INFO - 2018-10-12 14:28:26 --> Helper loaded: url_helper
INFO - 2018-10-12 14:28:26 --> Helper loaded: form_helper
INFO - 2018-10-12 14:28:26 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:28:26 --> User Agent Class Initialized
INFO - 2018-10-12 14:28:26 --> Controller Class Initialized
INFO - 2018-10-12 14:28:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:28:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:28:26 --> Pixel_Model class loaded
INFO - 2018-10-12 14:28:26 --> Database Driver Class Initialized
INFO - 2018-10-12 14:28:26 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:28:26 --> Database Driver Class Initialized
INFO - 2018-10-12 14:28:26 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:28:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:28:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:28:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:28:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 14:28:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-10-12 14:28:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:28:26 --> Final output sent to browser
DEBUG - 2018-10-12 14:28:26 --> Total execution time: 0.0620
INFO - 2018-10-12 14:28:27 --> Config Class Initialized
INFO - 2018-10-12 14:28:27 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:28:27 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:28:27 --> Utf8 Class Initialized
INFO - 2018-10-12 14:28:27 --> URI Class Initialized
INFO - 2018-10-12 14:28:27 --> Router Class Initialized
INFO - 2018-10-12 14:28:27 --> Output Class Initialized
INFO - 2018-10-12 14:28:27 --> Security Class Initialized
DEBUG - 2018-10-12 14:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:28:27 --> CSRF cookie sent
INFO - 2018-10-12 14:28:27 --> Input Class Initialized
INFO - 2018-10-12 14:28:27 --> Language Class Initialized
INFO - 2018-10-12 14:28:27 --> Loader Class Initialized
INFO - 2018-10-12 14:28:27 --> Helper loaded: url_helper
INFO - 2018-10-12 14:28:27 --> Helper loaded: form_helper
INFO - 2018-10-12 14:28:27 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:28:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:28:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:28:27 --> User Agent Class Initialized
INFO - 2018-10-12 14:28:27 --> Controller Class Initialized
INFO - 2018-10-12 14:28:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:28:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:28:27 --> Pixel_Model class loaded
INFO - 2018-10-12 14:28:27 --> Database Driver Class Initialized
INFO - 2018-10-12 14:28:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:28:27 --> Database Driver Class Initialized
INFO - 2018-10-12 14:28:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:28:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:28:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:28:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:28:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 14:28:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 14:28:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 14:28:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-10-12 14:28:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:28:27 --> Final output sent to browser
DEBUG - 2018-10-12 14:28:27 --> Total execution time: 0.0519
INFO - 2018-10-12 14:28:28 --> Config Class Initialized
INFO - 2018-10-12 14:28:28 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:28:28 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:28:28 --> Utf8 Class Initialized
INFO - 2018-10-12 14:28:28 --> URI Class Initialized
INFO - 2018-10-12 14:28:28 --> Router Class Initialized
INFO - 2018-10-12 14:28:28 --> Output Class Initialized
INFO - 2018-10-12 14:28:28 --> Security Class Initialized
DEBUG - 2018-10-12 14:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:28:28 --> CSRF cookie sent
INFO - 2018-10-12 14:28:28 --> Input Class Initialized
INFO - 2018-10-12 14:28:28 --> Language Class Initialized
INFO - 2018-10-12 14:28:28 --> Loader Class Initialized
INFO - 2018-10-12 14:28:28 --> Helper loaded: url_helper
INFO - 2018-10-12 14:28:28 --> Helper loaded: form_helper
INFO - 2018-10-12 14:28:28 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:28:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:28:28 --> User Agent Class Initialized
INFO - 2018-10-12 14:28:28 --> Controller Class Initialized
INFO - 2018-10-12 14:28:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:28:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:28:28 --> Pixel_Model class loaded
INFO - 2018-10-12 14:28:28 --> Database Driver Class Initialized
INFO - 2018-10-12 14:28:28 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:28:28 --> Database Driver Class Initialized
INFO - 2018-10-12 14:28:28 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:28:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:28:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:28:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:28:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 14:28:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 14:28:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 14:28:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_title.php
INFO - 2018-10-12 14:28:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:28:28 --> Final output sent to browser
DEBUG - 2018-10-12 14:28:28 --> Total execution time: 0.0487
INFO - 2018-10-12 14:28:28 --> Config Class Initialized
INFO - 2018-10-12 14:28:28 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:28:28 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:28:28 --> Utf8 Class Initialized
INFO - 2018-10-12 14:28:28 --> URI Class Initialized
INFO - 2018-10-12 14:28:28 --> Router Class Initialized
INFO - 2018-10-12 14:28:28 --> Output Class Initialized
INFO - 2018-10-12 14:28:28 --> Security Class Initialized
DEBUG - 2018-10-12 14:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:28:28 --> CSRF cookie sent
INFO - 2018-10-12 14:28:28 --> Input Class Initialized
INFO - 2018-10-12 14:28:28 --> Language Class Initialized
INFO - 2018-10-12 14:28:28 --> Loader Class Initialized
INFO - 2018-10-12 14:28:28 --> Helper loaded: url_helper
INFO - 2018-10-12 14:28:28 --> Helper loaded: form_helper
INFO - 2018-10-12 14:28:28 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:28:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:28:28 --> User Agent Class Initialized
INFO - 2018-10-12 14:28:28 --> Controller Class Initialized
INFO - 2018-10-12 14:28:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:28:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:28:28 --> Pixel_Model class loaded
INFO - 2018-10-12 14:28:28 --> Database Driver Class Initialized
INFO - 2018-10-12 14:28:28 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:28:28 --> Database Driver Class Initialized
INFO - 2018-10-12 14:28:28 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:28:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:28:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:28:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:28:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 14:28:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 14:28:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 14:28:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-10-12 14:28:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:28:28 --> Final output sent to browser
DEBUG - 2018-10-12 14:28:28 --> Total execution time: 0.0501
INFO - 2018-10-12 14:28:29 --> Config Class Initialized
INFO - 2018-10-12 14:28:29 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:28:29 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:28:29 --> Utf8 Class Initialized
INFO - 2018-10-12 14:28:29 --> URI Class Initialized
INFO - 2018-10-12 14:28:29 --> Router Class Initialized
INFO - 2018-10-12 14:28:29 --> Output Class Initialized
INFO - 2018-10-12 14:28:29 --> Security Class Initialized
DEBUG - 2018-10-12 14:28:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:28:29 --> CSRF cookie sent
INFO - 2018-10-12 14:28:29 --> Input Class Initialized
INFO - 2018-10-12 14:28:29 --> Language Class Initialized
INFO - 2018-10-12 14:28:29 --> Loader Class Initialized
INFO - 2018-10-12 14:28:29 --> Helper loaded: url_helper
INFO - 2018-10-12 14:28:29 --> Helper loaded: form_helper
INFO - 2018-10-12 14:28:29 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:28:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:28:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:28:29 --> User Agent Class Initialized
INFO - 2018-10-12 14:28:29 --> Controller Class Initialized
INFO - 2018-10-12 14:28:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:28:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:28:29 --> Pixel_Model class loaded
INFO - 2018-10-12 14:28:29 --> Database Driver Class Initialized
INFO - 2018-10-12 14:28:29 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:28:29 --> Database Driver Class Initialized
INFO - 2018-10-12 14:28:29 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:28:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:28:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:28:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:28:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 14:28:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-10-12 14:28:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:28:29 --> Final output sent to browser
DEBUG - 2018-10-12 14:28:29 --> Total execution time: 0.0469
INFO - 2018-10-12 14:28:34 --> Config Class Initialized
INFO - 2018-10-12 14:28:34 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:28:34 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:28:34 --> Utf8 Class Initialized
INFO - 2018-10-12 14:28:34 --> URI Class Initialized
INFO - 2018-10-12 14:28:34 --> Router Class Initialized
INFO - 2018-10-12 14:28:34 --> Output Class Initialized
INFO - 2018-10-12 14:28:34 --> Security Class Initialized
DEBUG - 2018-10-12 14:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:28:34 --> CSRF cookie sent
INFO - 2018-10-12 14:28:34 --> Input Class Initialized
INFO - 2018-10-12 14:28:34 --> Language Class Initialized
INFO - 2018-10-12 14:28:34 --> Loader Class Initialized
INFO - 2018-10-12 14:28:34 --> Helper loaded: url_helper
INFO - 2018-10-12 14:28:34 --> Helper loaded: form_helper
INFO - 2018-10-12 14:28:34 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:28:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:28:34 --> User Agent Class Initialized
INFO - 2018-10-12 14:28:34 --> Controller Class Initialized
INFO - 2018-10-12 14:28:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:28:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:28:34 --> Pixel_Model class loaded
INFO - 2018-10-12 14:28:34 --> Database Driver Class Initialized
INFO - 2018-10-12 14:28:34 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:28:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:28:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:28:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:28:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 14:28:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 14:28:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 14:28:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-10-12 14:28:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:28:34 --> Final output sent to browser
DEBUG - 2018-10-12 14:28:34 --> Total execution time: 0.0373
INFO - 2018-10-12 14:28:36 --> Config Class Initialized
INFO - 2018-10-12 14:28:36 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:28:36 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:28:36 --> Utf8 Class Initialized
INFO - 2018-10-12 14:28:36 --> URI Class Initialized
INFO - 2018-10-12 14:28:36 --> Router Class Initialized
INFO - 2018-10-12 14:28:36 --> Output Class Initialized
INFO - 2018-10-12 14:28:36 --> Security Class Initialized
DEBUG - 2018-10-12 14:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:28:36 --> CSRF cookie sent
INFO - 2018-10-12 14:28:36 --> CSRF token verified
INFO - 2018-10-12 14:28:36 --> Input Class Initialized
INFO - 2018-10-12 14:28:36 --> Language Class Initialized
INFO - 2018-10-12 14:28:36 --> Loader Class Initialized
INFO - 2018-10-12 14:28:36 --> Helper loaded: url_helper
INFO - 2018-10-12 14:28:36 --> Helper loaded: form_helper
INFO - 2018-10-12 14:28:36 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:28:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:28:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:28:36 --> User Agent Class Initialized
INFO - 2018-10-12 14:28:36 --> Controller Class Initialized
INFO - 2018-10-12 14:28:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:28:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:28:36 --> Pixel_Model class loaded
INFO - 2018-10-12 14:28:36 --> Database Driver Class Initialized
INFO - 2018-10-12 14:28:36 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:28:36 --> Database Driver Class Initialized
INFO - 2018-10-12 14:28:36 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:28:36 --> Config Class Initialized
INFO - 2018-10-12 14:28:36 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:28:36 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:28:36 --> Utf8 Class Initialized
INFO - 2018-10-12 14:28:36 --> URI Class Initialized
INFO - 2018-10-12 14:28:36 --> Router Class Initialized
INFO - 2018-10-12 14:28:36 --> Output Class Initialized
INFO - 2018-10-12 14:28:36 --> Security Class Initialized
DEBUG - 2018-10-12 14:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:28:36 --> CSRF cookie sent
INFO - 2018-10-12 14:28:36 --> Input Class Initialized
INFO - 2018-10-12 14:28:36 --> Language Class Initialized
INFO - 2018-10-12 14:28:36 --> Loader Class Initialized
INFO - 2018-10-12 14:28:36 --> Helper loaded: url_helper
INFO - 2018-10-12 14:28:36 --> Helper loaded: form_helper
INFO - 2018-10-12 14:28:36 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:28:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:28:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:28:36 --> User Agent Class Initialized
INFO - 2018-10-12 14:28:36 --> Controller Class Initialized
INFO - 2018-10-12 14:28:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:28:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:28:36 --> Pixel_Model class loaded
INFO - 2018-10-12 14:28:36 --> Database Driver Class Initialized
INFO - 2018-10-12 14:28:36 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:28:36 --> Config Class Initialized
INFO - 2018-10-12 14:28:36 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:28:36 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:28:36 --> Utf8 Class Initialized
INFO - 2018-10-12 14:28:36 --> URI Class Initialized
INFO - 2018-10-12 14:28:36 --> Router Class Initialized
INFO - 2018-10-12 14:28:36 --> Output Class Initialized
INFO - 2018-10-12 14:28:36 --> Security Class Initialized
DEBUG - 2018-10-12 14:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:28:36 --> CSRF cookie sent
INFO - 2018-10-12 14:28:36 --> Input Class Initialized
INFO - 2018-10-12 14:28:36 --> Language Class Initialized
INFO - 2018-10-12 14:28:36 --> Loader Class Initialized
INFO - 2018-10-12 14:28:36 --> Helper loaded: url_helper
INFO - 2018-10-12 14:28:36 --> Helper loaded: form_helper
INFO - 2018-10-12 14:28:36 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:28:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:28:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:28:36 --> User Agent Class Initialized
INFO - 2018-10-12 14:28:36 --> Controller Class Initialized
INFO - 2018-10-12 14:28:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:28:36 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-12 14:28:36 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-10-12 14:28:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:28:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:28:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:28:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-10-12 14:28:36 --> Could not find the language line "req_email"
INFO - 2018-10-12 14:28:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-10-12 14:28:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:28:36 --> Final output sent to browser
DEBUG - 2018-10-12 14:28:36 --> Total execution time: 0.0222
INFO - 2018-10-12 14:28:39 --> Config Class Initialized
INFO - 2018-10-12 14:28:39 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:28:39 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:28:39 --> Utf8 Class Initialized
INFO - 2018-10-12 14:28:39 --> URI Class Initialized
INFO - 2018-10-12 14:28:39 --> Router Class Initialized
INFO - 2018-10-12 14:28:39 --> Output Class Initialized
INFO - 2018-10-12 14:28:39 --> Security Class Initialized
DEBUG - 2018-10-12 14:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:28:39 --> CSRF cookie sent
INFO - 2018-10-12 14:28:39 --> Input Class Initialized
INFO - 2018-10-12 14:28:39 --> Language Class Initialized
INFO - 2018-10-12 14:28:39 --> Loader Class Initialized
INFO - 2018-10-12 14:28:39 --> Helper loaded: url_helper
INFO - 2018-10-12 14:28:39 --> Helper loaded: form_helper
INFO - 2018-10-12 14:28:39 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:28:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:28:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:28:39 --> User Agent Class Initialized
INFO - 2018-10-12 14:28:39 --> Controller Class Initialized
INFO - 2018-10-12 14:28:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:28:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:28:39 --> Pixel_Model class loaded
INFO - 2018-10-12 14:28:39 --> Database Driver Class Initialized
INFO - 2018-10-12 14:28:39 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:28:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:28:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:28:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:28:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 14:28:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 14:28:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 14:28:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-10-12 14:28:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:28:39 --> Final output sent to browser
DEBUG - 2018-10-12 14:28:39 --> Total execution time: 0.0559
INFO - 2018-10-12 14:28:43 --> Config Class Initialized
INFO - 2018-10-12 14:28:43 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:28:43 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:28:43 --> Utf8 Class Initialized
INFO - 2018-10-12 14:28:43 --> URI Class Initialized
INFO - 2018-10-12 14:28:43 --> Router Class Initialized
INFO - 2018-10-12 14:28:43 --> Output Class Initialized
INFO - 2018-10-12 14:28:43 --> Security Class Initialized
DEBUG - 2018-10-12 14:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:28:43 --> CSRF cookie sent
INFO - 2018-10-12 14:28:43 --> CSRF token verified
INFO - 2018-10-12 14:28:43 --> Input Class Initialized
INFO - 2018-10-12 14:28:43 --> Language Class Initialized
INFO - 2018-10-12 14:28:43 --> Loader Class Initialized
INFO - 2018-10-12 14:28:43 --> Helper loaded: url_helper
INFO - 2018-10-12 14:28:43 --> Helper loaded: form_helper
INFO - 2018-10-12 14:28:43 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:28:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:28:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:28:43 --> User Agent Class Initialized
INFO - 2018-10-12 14:28:43 --> Controller Class Initialized
INFO - 2018-10-12 14:28:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:28:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:28:43 --> Pixel_Model class loaded
INFO - 2018-10-12 14:28:43 --> Database Driver Class Initialized
INFO - 2018-10-12 14:28:43 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:28:43 --> Database Driver Class Initialized
INFO - 2018-10-12 14:28:43 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:28:43 --> Config Class Initialized
INFO - 2018-10-12 14:28:43 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:28:43 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:28:43 --> Utf8 Class Initialized
INFO - 2018-10-12 14:28:43 --> URI Class Initialized
INFO - 2018-10-12 14:28:43 --> Router Class Initialized
INFO - 2018-10-12 14:28:43 --> Output Class Initialized
INFO - 2018-10-12 14:28:43 --> Security Class Initialized
DEBUG - 2018-10-12 14:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:28:43 --> CSRF cookie sent
INFO - 2018-10-12 14:28:43 --> Input Class Initialized
INFO - 2018-10-12 14:28:43 --> Language Class Initialized
INFO - 2018-10-12 14:28:43 --> Loader Class Initialized
INFO - 2018-10-12 14:28:43 --> Helper loaded: url_helper
INFO - 2018-10-12 14:28:43 --> Helper loaded: form_helper
INFO - 2018-10-12 14:28:43 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:28:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:28:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:28:43 --> User Agent Class Initialized
INFO - 2018-10-12 14:28:43 --> Controller Class Initialized
INFO - 2018-10-12 14:28:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:28:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:28:43 --> Pixel_Model class loaded
INFO - 2018-10-12 14:28:43 --> Database Driver Class Initialized
INFO - 2018-10-12 14:28:43 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:28:43 --> Config Class Initialized
INFO - 2018-10-12 14:28:43 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:28:43 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:28:43 --> Utf8 Class Initialized
INFO - 2018-10-12 14:28:43 --> URI Class Initialized
INFO - 2018-10-12 14:28:43 --> Router Class Initialized
INFO - 2018-10-12 14:28:43 --> Output Class Initialized
INFO - 2018-10-12 14:28:43 --> Security Class Initialized
DEBUG - 2018-10-12 14:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:28:43 --> CSRF cookie sent
INFO - 2018-10-12 14:28:43 --> Input Class Initialized
INFO - 2018-10-12 14:28:43 --> Language Class Initialized
INFO - 2018-10-12 14:28:43 --> Loader Class Initialized
INFO - 2018-10-12 14:28:43 --> Helper loaded: url_helper
INFO - 2018-10-12 14:28:43 --> Helper loaded: form_helper
INFO - 2018-10-12 14:28:43 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:28:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:28:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:28:43 --> User Agent Class Initialized
INFO - 2018-10-12 14:28:43 --> Controller Class Initialized
INFO - 2018-10-12 14:28:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:28:43 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-12 14:28:43 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-10-12 14:28:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:28:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:28:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:28:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-10-12 14:28:43 --> Could not find the language line "req_email"
INFO - 2018-10-12 14:28:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-10-12 14:28:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:28:43 --> Final output sent to browser
DEBUG - 2018-10-12 14:28:43 --> Total execution time: 0.0211
INFO - 2018-10-12 14:28:47 --> Config Class Initialized
INFO - 2018-10-12 14:28:47 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:28:47 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:28:47 --> Utf8 Class Initialized
INFO - 2018-10-12 14:28:47 --> URI Class Initialized
INFO - 2018-10-12 14:28:47 --> Router Class Initialized
INFO - 2018-10-12 14:28:47 --> Output Class Initialized
INFO - 2018-10-12 14:28:47 --> Security Class Initialized
DEBUG - 2018-10-12 14:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:28:47 --> CSRF cookie sent
INFO - 2018-10-12 14:28:47 --> Input Class Initialized
INFO - 2018-10-12 14:28:47 --> Language Class Initialized
INFO - 2018-10-12 14:28:47 --> Loader Class Initialized
INFO - 2018-10-12 14:28:47 --> Helper loaded: url_helper
INFO - 2018-10-12 14:28:47 --> Helper loaded: form_helper
INFO - 2018-10-12 14:28:47 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:28:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:28:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:28:47 --> User Agent Class Initialized
INFO - 2018-10-12 14:28:47 --> Controller Class Initialized
INFO - 2018-10-12 14:28:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:28:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:28:47 --> Pixel_Model class loaded
INFO - 2018-10-12 14:28:47 --> Database Driver Class Initialized
INFO - 2018-10-12 14:28:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:28:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:28:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:28:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:28:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 14:28:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 14:28:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 14:28:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-10-12 14:28:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:28:47 --> Final output sent to browser
DEBUG - 2018-10-12 14:28:47 --> Total execution time: 0.0393
INFO - 2018-10-12 14:28:49 --> Config Class Initialized
INFO - 2018-10-12 14:28:49 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:28:49 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:28:49 --> Utf8 Class Initialized
INFO - 2018-10-12 14:28:49 --> URI Class Initialized
DEBUG - 2018-10-12 14:28:49 --> No URI present. Default controller set.
INFO - 2018-10-12 14:28:49 --> Router Class Initialized
INFO - 2018-10-12 14:28:49 --> Output Class Initialized
INFO - 2018-10-12 14:28:49 --> Security Class Initialized
DEBUG - 2018-10-12 14:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:28:49 --> CSRF cookie sent
INFO - 2018-10-12 14:28:49 --> Input Class Initialized
INFO - 2018-10-12 14:28:49 --> Language Class Initialized
INFO - 2018-10-12 14:28:49 --> Loader Class Initialized
INFO - 2018-10-12 14:28:49 --> Helper loaded: url_helper
INFO - 2018-10-12 14:28:49 --> Helper loaded: form_helper
INFO - 2018-10-12 14:28:49 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:28:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:28:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:28:49 --> User Agent Class Initialized
INFO - 2018-10-12 14:28:49 --> Controller Class Initialized
INFO - 2018-10-12 14:28:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:28:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:28:49 --> Pixel_Model class loaded
INFO - 2018-10-12 14:28:49 --> Database Driver Class Initialized
INFO - 2018-10-12 14:28:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:28:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:28:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:28:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-12 14:28:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:28:49 --> Final output sent to browser
DEBUG - 2018-10-12 14:28:49 --> Total execution time: 0.0489
INFO - 2018-10-12 14:28:53 --> Config Class Initialized
INFO - 2018-10-12 14:28:53 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:28:53 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:28:53 --> Utf8 Class Initialized
INFO - 2018-10-12 14:28:53 --> URI Class Initialized
INFO - 2018-10-12 14:28:53 --> Router Class Initialized
INFO - 2018-10-12 14:28:53 --> Output Class Initialized
INFO - 2018-10-12 14:28:53 --> Security Class Initialized
DEBUG - 2018-10-12 14:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:28:53 --> CSRF cookie sent
INFO - 2018-10-12 14:28:53 --> CSRF token verified
INFO - 2018-10-12 14:28:53 --> Input Class Initialized
INFO - 2018-10-12 14:28:53 --> Language Class Initialized
INFO - 2018-10-12 14:28:53 --> Loader Class Initialized
INFO - 2018-10-12 14:28:53 --> Helper loaded: url_helper
INFO - 2018-10-12 14:28:53 --> Helper loaded: form_helper
INFO - 2018-10-12 14:28:53 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:28:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:28:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:28:53 --> User Agent Class Initialized
INFO - 2018-10-12 14:28:53 --> Controller Class Initialized
INFO - 2018-10-12 14:28:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:28:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:28:53 --> Pixel_Model class loaded
INFO - 2018-10-12 14:28:53 --> Database Driver Class Initialized
INFO - 2018-10-12 14:28:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:28:53 --> Database Driver Class Initialized
INFO - 2018-10-12 14:28:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:28:53 --> Config Class Initialized
INFO - 2018-10-12 14:28:53 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:28:53 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:28:53 --> Utf8 Class Initialized
INFO - 2018-10-12 14:28:53 --> URI Class Initialized
INFO - 2018-10-12 14:28:53 --> Router Class Initialized
INFO - 2018-10-12 14:28:53 --> Output Class Initialized
INFO - 2018-10-12 14:28:53 --> Security Class Initialized
DEBUG - 2018-10-12 14:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:28:53 --> CSRF cookie sent
INFO - 2018-10-12 14:28:53 --> Input Class Initialized
INFO - 2018-10-12 14:28:53 --> Language Class Initialized
INFO - 2018-10-12 14:28:53 --> Loader Class Initialized
INFO - 2018-10-12 14:28:53 --> Helper loaded: url_helper
INFO - 2018-10-12 14:28:53 --> Helper loaded: form_helper
INFO - 2018-10-12 14:28:53 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:28:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:28:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:28:53 --> User Agent Class Initialized
INFO - 2018-10-12 14:28:53 --> Controller Class Initialized
INFO - 2018-10-12 14:28:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:28:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:28:53 --> Pixel_Model class loaded
INFO - 2018-10-12 14:28:53 --> Database Driver Class Initialized
INFO - 2018-10-12 14:28:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:28:53 --> Config Class Initialized
INFO - 2018-10-12 14:28:53 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:28:53 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:28:53 --> Utf8 Class Initialized
INFO - 2018-10-12 14:28:53 --> URI Class Initialized
INFO - 2018-10-12 14:28:53 --> Router Class Initialized
INFO - 2018-10-12 14:28:53 --> Output Class Initialized
INFO - 2018-10-12 14:28:53 --> Security Class Initialized
DEBUG - 2018-10-12 14:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:28:53 --> CSRF cookie sent
INFO - 2018-10-12 14:28:53 --> Input Class Initialized
INFO - 2018-10-12 14:28:53 --> Language Class Initialized
INFO - 2018-10-12 14:28:53 --> Loader Class Initialized
INFO - 2018-10-12 14:28:53 --> Helper loaded: url_helper
INFO - 2018-10-12 14:28:53 --> Helper loaded: form_helper
INFO - 2018-10-12 14:28:53 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:28:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:28:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:28:53 --> User Agent Class Initialized
INFO - 2018-10-12 14:28:53 --> Controller Class Initialized
INFO - 2018-10-12 14:28:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:28:53 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-12 14:28:53 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-10-12 14:28:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:28:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:28:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:28:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-10-12 14:28:53 --> Could not find the language line "req_email"
INFO - 2018-10-12 14:28:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-10-12 14:28:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:28:54 --> Final output sent to browser
DEBUG - 2018-10-12 14:28:54 --> Total execution time: 0.0236
INFO - 2018-10-12 14:32:58 --> Config Class Initialized
INFO - 2018-10-12 14:32:58 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:32:58 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:32:58 --> Utf8 Class Initialized
INFO - 2018-10-12 14:32:58 --> URI Class Initialized
DEBUG - 2018-10-12 14:32:58 --> No URI present. Default controller set.
INFO - 2018-10-12 14:32:58 --> Router Class Initialized
INFO - 2018-10-12 14:32:58 --> Output Class Initialized
INFO - 2018-10-12 14:32:58 --> Security Class Initialized
DEBUG - 2018-10-12 14:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:32:58 --> CSRF cookie sent
INFO - 2018-10-12 14:32:58 --> Input Class Initialized
INFO - 2018-10-12 14:32:58 --> Language Class Initialized
INFO - 2018-10-12 14:32:58 --> Loader Class Initialized
INFO - 2018-10-12 14:32:58 --> Helper loaded: url_helper
INFO - 2018-10-12 14:32:58 --> Helper loaded: form_helper
INFO - 2018-10-12 14:32:58 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:32:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:32:58 --> User Agent Class Initialized
INFO - 2018-10-12 14:32:58 --> Controller Class Initialized
INFO - 2018-10-12 14:32:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:32:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:32:58 --> Pixel_Model class loaded
INFO - 2018-10-12 14:32:58 --> Database Driver Class Initialized
INFO - 2018-10-12 14:32:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:32:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:32:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:32:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-12 14:32:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:32:58 --> Final output sent to browser
DEBUG - 2018-10-12 14:32:58 --> Total execution time: 0.0547
INFO - 2018-10-12 14:33:32 --> Config Class Initialized
INFO - 2018-10-12 14:33:32 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:33:32 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:33:32 --> Utf8 Class Initialized
INFO - 2018-10-12 14:33:32 --> URI Class Initialized
INFO - 2018-10-12 14:33:32 --> Router Class Initialized
INFO - 2018-10-12 14:33:32 --> Output Class Initialized
INFO - 2018-10-12 14:33:32 --> Security Class Initialized
DEBUG - 2018-10-12 14:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:33:32 --> CSRF cookie sent
INFO - 2018-10-12 14:33:32 --> Input Class Initialized
INFO - 2018-10-12 14:33:32 --> Language Class Initialized
INFO - 2018-10-12 14:33:32 --> Loader Class Initialized
INFO - 2018-10-12 14:33:32 --> Helper loaded: url_helper
INFO - 2018-10-12 14:33:32 --> Helper loaded: form_helper
INFO - 2018-10-12 14:33:32 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:33:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:33:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:33:32 --> User Agent Class Initialized
INFO - 2018-10-12 14:33:32 --> Controller Class Initialized
INFO - 2018-10-12 14:33:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:33:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:33:32 --> Pixel_Model class loaded
INFO - 2018-10-12 14:33:32 --> Database Driver Class Initialized
INFO - 2018-10-12 14:33:32 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:33:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:33:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:33:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:33:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 14:33:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 14:33:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 14:33:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-10-12 14:33:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:33:32 --> Final output sent to browser
DEBUG - 2018-10-12 14:33:32 --> Total execution time: 0.0372
INFO - 2018-10-12 14:33:35 --> Config Class Initialized
INFO - 2018-10-12 14:33:35 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:33:35 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:33:35 --> Utf8 Class Initialized
INFO - 2018-10-12 14:33:35 --> URI Class Initialized
INFO - 2018-10-12 14:33:35 --> Router Class Initialized
INFO - 2018-10-12 14:33:35 --> Output Class Initialized
INFO - 2018-10-12 14:33:35 --> Security Class Initialized
DEBUG - 2018-10-12 14:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:33:35 --> CSRF cookie sent
INFO - 2018-10-12 14:33:35 --> CSRF token verified
INFO - 2018-10-12 14:33:35 --> Input Class Initialized
INFO - 2018-10-12 14:33:35 --> Language Class Initialized
INFO - 2018-10-12 14:33:35 --> Loader Class Initialized
INFO - 2018-10-12 14:33:35 --> Helper loaded: url_helper
INFO - 2018-10-12 14:33:35 --> Helper loaded: form_helper
INFO - 2018-10-12 14:33:35 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:33:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:33:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:33:35 --> User Agent Class Initialized
INFO - 2018-10-12 14:33:35 --> Controller Class Initialized
INFO - 2018-10-12 14:33:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:33:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:33:35 --> Pixel_Model class loaded
INFO - 2018-10-12 14:33:35 --> Database Driver Class Initialized
INFO - 2018-10-12 14:33:35 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:33:35 --> Database Driver Class Initialized
INFO - 2018-10-12 14:33:35 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:33:35 --> Config Class Initialized
INFO - 2018-10-12 14:33:35 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:33:35 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:33:35 --> Utf8 Class Initialized
INFO - 2018-10-12 14:33:35 --> URI Class Initialized
INFO - 2018-10-12 14:33:35 --> Router Class Initialized
INFO - 2018-10-12 14:33:35 --> Output Class Initialized
INFO - 2018-10-12 14:33:35 --> Security Class Initialized
DEBUG - 2018-10-12 14:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:33:35 --> CSRF cookie sent
INFO - 2018-10-12 14:33:35 --> Input Class Initialized
INFO - 2018-10-12 14:33:35 --> Language Class Initialized
INFO - 2018-10-12 14:33:35 --> Loader Class Initialized
INFO - 2018-10-12 14:33:35 --> Helper loaded: url_helper
INFO - 2018-10-12 14:33:35 --> Helper loaded: form_helper
INFO - 2018-10-12 14:33:35 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:33:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:33:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:33:35 --> User Agent Class Initialized
INFO - 2018-10-12 14:33:35 --> Controller Class Initialized
INFO - 2018-10-12 14:33:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:33:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:33:35 --> Pixel_Model class loaded
INFO - 2018-10-12 14:33:35 --> Database Driver Class Initialized
INFO - 2018-10-12 14:33:35 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:33:35 --> Database Driver Class Initialized
INFO - 2018-10-12 14:33:35 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:33:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:33:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:33:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:33:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 14:33:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 14:33:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 14:33:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-12 14:33:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:33:35 --> Final output sent to browser
DEBUG - 2018-10-12 14:33:35 --> Total execution time: 0.0475
INFO - 2018-10-12 14:33:59 --> Config Class Initialized
INFO - 2018-10-12 14:33:59 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:33:59 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:33:59 --> Utf8 Class Initialized
INFO - 2018-10-12 14:33:59 --> URI Class Initialized
INFO - 2018-10-12 14:33:59 --> Router Class Initialized
INFO - 2018-10-12 14:33:59 --> Output Class Initialized
INFO - 2018-10-12 14:33:59 --> Security Class Initialized
DEBUG - 2018-10-12 14:33:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:33:59 --> CSRF cookie sent
INFO - 2018-10-12 14:33:59 --> Input Class Initialized
INFO - 2018-10-12 14:33:59 --> Language Class Initialized
INFO - 2018-10-12 14:33:59 --> Loader Class Initialized
INFO - 2018-10-12 14:33:59 --> Helper loaded: url_helper
INFO - 2018-10-12 14:33:59 --> Helper loaded: form_helper
INFO - 2018-10-12 14:33:59 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:33:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:33:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:33:59 --> User Agent Class Initialized
INFO - 2018-10-12 14:33:59 --> Controller Class Initialized
INFO - 2018-10-12 14:33:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:33:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:33:59 --> Pixel_Model class loaded
INFO - 2018-10-12 14:33:59 --> Database Driver Class Initialized
INFO - 2018-10-12 14:33:59 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:33:59 --> Database Driver Class Initialized
INFO - 2018-10-12 14:33:59 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:33:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:33:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:33:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:33:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 14:33:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 14:33:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 14:33:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-12 14:33:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:33:59 --> Final output sent to browser
DEBUG - 2018-10-12 14:33:59 --> Total execution time: 0.0481
INFO - 2018-10-12 14:34:02 --> Config Class Initialized
INFO - 2018-10-12 14:34:02 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:34:02 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:34:02 --> Utf8 Class Initialized
INFO - 2018-10-12 14:34:02 --> URI Class Initialized
DEBUG - 2018-10-12 14:34:02 --> No URI present. Default controller set.
INFO - 2018-10-12 14:34:02 --> Router Class Initialized
INFO - 2018-10-12 14:34:02 --> Output Class Initialized
INFO - 2018-10-12 14:34:02 --> Security Class Initialized
DEBUG - 2018-10-12 14:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:34:02 --> CSRF cookie sent
INFO - 2018-10-12 14:34:02 --> Input Class Initialized
INFO - 2018-10-12 14:34:02 --> Language Class Initialized
INFO - 2018-10-12 14:34:02 --> Loader Class Initialized
INFO - 2018-10-12 14:34:02 --> Helper loaded: url_helper
INFO - 2018-10-12 14:34:02 --> Helper loaded: form_helper
INFO - 2018-10-12 14:34:02 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:34:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:34:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:34:02 --> User Agent Class Initialized
INFO - 2018-10-12 14:34:02 --> Controller Class Initialized
INFO - 2018-10-12 14:34:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:34:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:34:02 --> Pixel_Model class loaded
INFO - 2018-10-12 14:34:02 --> Database Driver Class Initialized
INFO - 2018-10-12 14:34:02 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:34:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:34:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:34:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-12 14:34:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:34:02 --> Final output sent to browser
DEBUG - 2018-10-12 14:34:02 --> Total execution time: 0.0364
INFO - 2018-10-12 14:34:10 --> Config Class Initialized
INFO - 2018-10-12 14:34:10 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:34:10 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:34:10 --> Utf8 Class Initialized
INFO - 2018-10-12 14:34:10 --> URI Class Initialized
INFO - 2018-10-12 14:34:10 --> Router Class Initialized
INFO - 2018-10-12 14:34:10 --> Output Class Initialized
INFO - 2018-10-12 14:34:10 --> Security Class Initialized
DEBUG - 2018-10-12 14:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:34:10 --> CSRF cookie sent
INFO - 2018-10-12 14:34:10 --> CSRF token verified
INFO - 2018-10-12 14:34:10 --> Input Class Initialized
INFO - 2018-10-12 14:34:10 --> Language Class Initialized
INFO - 2018-10-12 14:34:10 --> Loader Class Initialized
INFO - 2018-10-12 14:34:10 --> Helper loaded: url_helper
INFO - 2018-10-12 14:34:10 --> Helper loaded: form_helper
INFO - 2018-10-12 14:34:10 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:34:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:34:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:34:10 --> User Agent Class Initialized
INFO - 2018-10-12 14:34:10 --> Controller Class Initialized
INFO - 2018-10-12 14:34:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:34:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:34:10 --> Pixel_Model class loaded
INFO - 2018-10-12 14:34:10 --> Database Driver Class Initialized
INFO - 2018-10-12 14:34:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:34:10 --> Form Validation Class Initialized
INFO - 2018-10-12 14:34:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-12 14:34:10 --> Database Driver Class Initialized
INFO - 2018-10-12 14:34:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:34:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:34:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:34:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:34:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 14:34:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 14:34:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_errors.php
INFO - 2018-10-12 14:34:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 14:34:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-12 14:34:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:34:10 --> Final output sent to browser
DEBUG - 2018-10-12 14:34:10 --> Total execution time: 0.0526
INFO - 2018-10-12 14:34:15 --> Config Class Initialized
INFO - 2018-10-12 14:34:15 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:34:15 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:34:15 --> Utf8 Class Initialized
INFO - 2018-10-12 14:34:15 --> URI Class Initialized
INFO - 2018-10-12 14:34:15 --> Router Class Initialized
INFO - 2018-10-12 14:34:15 --> Output Class Initialized
INFO - 2018-10-12 14:34:15 --> Security Class Initialized
DEBUG - 2018-10-12 14:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:34:15 --> CSRF cookie sent
INFO - 2018-10-12 14:34:15 --> CSRF token verified
INFO - 2018-10-12 14:34:15 --> Input Class Initialized
INFO - 2018-10-12 14:34:15 --> Language Class Initialized
INFO - 2018-10-12 14:34:15 --> Loader Class Initialized
INFO - 2018-10-12 14:34:15 --> Helper loaded: url_helper
INFO - 2018-10-12 14:34:15 --> Helper loaded: form_helper
INFO - 2018-10-12 14:34:15 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:34:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:34:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:34:15 --> User Agent Class Initialized
INFO - 2018-10-12 14:34:15 --> Controller Class Initialized
INFO - 2018-10-12 14:34:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:34:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:34:15 --> Pixel_Model class loaded
INFO - 2018-10-12 14:34:15 --> Database Driver Class Initialized
INFO - 2018-10-12 14:34:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:34:15 --> Form Validation Class Initialized
INFO - 2018-10-12 14:34:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-12 14:34:15 --> Database Driver Class Initialized
INFO - 2018-10-12 14:34:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:34:15 --> Config Class Initialized
INFO - 2018-10-12 14:34:15 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:34:15 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:34:15 --> Utf8 Class Initialized
INFO - 2018-10-12 14:34:15 --> URI Class Initialized
INFO - 2018-10-12 14:34:15 --> Router Class Initialized
INFO - 2018-10-12 14:34:15 --> Output Class Initialized
INFO - 2018-10-12 14:34:15 --> Security Class Initialized
DEBUG - 2018-10-12 14:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:34:15 --> CSRF cookie sent
INFO - 2018-10-12 14:34:15 --> Input Class Initialized
INFO - 2018-10-12 14:34:15 --> Language Class Initialized
INFO - 2018-10-12 14:34:15 --> Loader Class Initialized
INFO - 2018-10-12 14:34:15 --> Helper loaded: url_helper
INFO - 2018-10-12 14:34:15 --> Helper loaded: form_helper
INFO - 2018-10-12 14:34:15 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:34:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:34:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:34:15 --> User Agent Class Initialized
INFO - 2018-10-12 14:34:15 --> Controller Class Initialized
INFO - 2018-10-12 14:34:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:34:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:34:15 --> Pixel_Model class loaded
INFO - 2018-10-12 14:34:15 --> Database Driver Class Initialized
INFO - 2018-10-12 14:34:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:34:15 --> Database Driver Class Initialized
INFO - 2018-10-12 14:34:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:34:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:34:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:34:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:34:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 14:34:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 14:34:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 14:34:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-10-12 14:34:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:34:15 --> Final output sent to browser
DEBUG - 2018-10-12 14:34:15 --> Total execution time: 0.0427
INFO - 2018-10-12 14:34:17 --> Config Class Initialized
INFO - 2018-10-12 14:34:17 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:34:17 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:34:17 --> Utf8 Class Initialized
INFO - 2018-10-12 14:34:17 --> URI Class Initialized
INFO - 2018-10-12 14:34:17 --> Router Class Initialized
INFO - 2018-10-12 14:34:17 --> Output Class Initialized
INFO - 2018-10-12 14:34:17 --> Security Class Initialized
DEBUG - 2018-10-12 14:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:34:17 --> CSRF cookie sent
INFO - 2018-10-12 14:34:17 --> CSRF token verified
INFO - 2018-10-12 14:34:17 --> Input Class Initialized
INFO - 2018-10-12 14:34:17 --> Language Class Initialized
INFO - 2018-10-12 14:34:17 --> Loader Class Initialized
INFO - 2018-10-12 14:34:17 --> Helper loaded: url_helper
INFO - 2018-10-12 14:34:17 --> Helper loaded: form_helper
INFO - 2018-10-12 14:34:17 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:34:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:34:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:34:17 --> User Agent Class Initialized
INFO - 2018-10-12 14:34:17 --> Controller Class Initialized
INFO - 2018-10-12 14:34:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:34:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:34:17 --> Pixel_Model class loaded
INFO - 2018-10-12 14:34:17 --> Database Driver Class Initialized
INFO - 2018-10-12 14:34:17 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:34:17 --> Form Validation Class Initialized
INFO - 2018-10-12 14:34:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-12 14:34:17 --> Database Driver Class Initialized
INFO - 2018-10-12 14:34:17 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:34:17 --> Config Class Initialized
INFO - 2018-10-12 14:34:17 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:34:17 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:34:17 --> Utf8 Class Initialized
INFO - 2018-10-12 14:34:17 --> URI Class Initialized
INFO - 2018-10-12 14:34:17 --> Router Class Initialized
INFO - 2018-10-12 14:34:17 --> Output Class Initialized
INFO - 2018-10-12 14:34:17 --> Security Class Initialized
DEBUG - 2018-10-12 14:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:34:17 --> CSRF cookie sent
INFO - 2018-10-12 14:34:17 --> Input Class Initialized
INFO - 2018-10-12 14:34:17 --> Language Class Initialized
INFO - 2018-10-12 14:34:17 --> Loader Class Initialized
INFO - 2018-10-12 14:34:17 --> Helper loaded: url_helper
INFO - 2018-10-12 14:34:17 --> Helper loaded: form_helper
INFO - 2018-10-12 14:34:17 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:34:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:34:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:34:17 --> User Agent Class Initialized
INFO - 2018-10-12 14:34:17 --> Controller Class Initialized
INFO - 2018-10-12 14:34:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:34:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:34:17 --> Pixel_Model class loaded
INFO - 2018-10-12 14:34:17 --> Database Driver Class Initialized
INFO - 2018-10-12 14:34:17 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:34:17 --> Database Driver Class Initialized
INFO - 2018-10-12 14:34:17 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:34:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:34:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:34:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-10-12 14:34:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:34:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 14:34:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 14:34:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 14:34:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-10-12 14:34:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:34:17 --> Final output sent to browser
DEBUG - 2018-10-12 14:34:17 --> Total execution time: 0.0569
INFO - 2018-10-12 14:34:19 --> Config Class Initialized
INFO - 2018-10-12 14:34:19 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:34:19 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:34:19 --> Utf8 Class Initialized
INFO - 2018-10-12 14:34:19 --> URI Class Initialized
INFO - 2018-10-12 14:34:19 --> Router Class Initialized
INFO - 2018-10-12 14:34:19 --> Output Class Initialized
INFO - 2018-10-12 14:34:19 --> Security Class Initialized
DEBUG - 2018-10-12 14:34:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:34:19 --> CSRF cookie sent
INFO - 2018-10-12 14:34:19 --> CSRF token verified
INFO - 2018-10-12 14:34:19 --> Input Class Initialized
INFO - 2018-10-12 14:34:19 --> Language Class Initialized
INFO - 2018-10-12 14:34:19 --> Loader Class Initialized
INFO - 2018-10-12 14:34:19 --> Helper loaded: url_helper
INFO - 2018-10-12 14:34:19 --> Helper loaded: form_helper
INFO - 2018-10-12 14:34:19 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:34:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:34:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:34:19 --> User Agent Class Initialized
INFO - 2018-10-12 14:34:19 --> Controller Class Initialized
INFO - 2018-10-12 14:34:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:34:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:34:19 --> Pixel_Model class loaded
INFO - 2018-10-12 14:34:19 --> Database Driver Class Initialized
INFO - 2018-10-12 14:34:19 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:34:19 --> Form Validation Class Initialized
INFO - 2018-10-12 14:34:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-12 14:34:19 --> Database Driver Class Initialized
INFO - 2018-10-12 14:34:19 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:34:20 --> Config Class Initialized
INFO - 2018-10-12 14:34:20 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:34:20 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:34:20 --> Utf8 Class Initialized
INFO - 2018-10-12 14:34:20 --> URI Class Initialized
INFO - 2018-10-12 14:34:20 --> Router Class Initialized
INFO - 2018-10-12 14:34:20 --> Output Class Initialized
INFO - 2018-10-12 14:34:20 --> Security Class Initialized
DEBUG - 2018-10-12 14:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:34:20 --> CSRF cookie sent
INFO - 2018-10-12 14:34:20 --> Input Class Initialized
INFO - 2018-10-12 14:34:20 --> Language Class Initialized
INFO - 2018-10-12 14:34:20 --> Loader Class Initialized
INFO - 2018-10-12 14:34:20 --> Helper loaded: url_helper
INFO - 2018-10-12 14:34:20 --> Helper loaded: form_helper
INFO - 2018-10-12 14:34:20 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:34:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:34:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:34:20 --> User Agent Class Initialized
INFO - 2018-10-12 14:34:20 --> Controller Class Initialized
INFO - 2018-10-12 14:34:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:34:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:34:20 --> Pixel_Model class loaded
INFO - 2018-10-12 14:34:20 --> Database Driver Class Initialized
INFO - 2018-10-12 14:34:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:34:20 --> Database Driver Class Initialized
INFO - 2018-10-12 14:34:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:34:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:34:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:34:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:34:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 14:34:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 14:34:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 14:34:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-12 14:34:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:34:20 --> Final output sent to browser
DEBUG - 2018-10-12 14:34:20 --> Total execution time: 0.0360
INFO - 2018-10-12 14:34:25 --> Config Class Initialized
INFO - 2018-10-12 14:34:25 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:34:25 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:34:25 --> Utf8 Class Initialized
INFO - 2018-10-12 14:34:25 --> URI Class Initialized
INFO - 2018-10-12 14:34:25 --> Router Class Initialized
INFO - 2018-10-12 14:34:25 --> Output Class Initialized
INFO - 2018-10-12 14:34:25 --> Security Class Initialized
DEBUG - 2018-10-12 14:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:34:25 --> CSRF cookie sent
INFO - 2018-10-12 14:34:25 --> CSRF token verified
INFO - 2018-10-12 14:34:25 --> Input Class Initialized
INFO - 2018-10-12 14:34:25 --> Language Class Initialized
INFO - 2018-10-12 14:34:25 --> Loader Class Initialized
INFO - 2018-10-12 14:34:25 --> Helper loaded: url_helper
INFO - 2018-10-12 14:34:25 --> Helper loaded: form_helper
INFO - 2018-10-12 14:34:25 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:34:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:34:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:34:25 --> User Agent Class Initialized
INFO - 2018-10-12 14:34:25 --> Controller Class Initialized
INFO - 2018-10-12 14:34:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:34:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:34:25 --> Pixel_Model class loaded
INFO - 2018-10-12 14:34:25 --> Database Driver Class Initialized
INFO - 2018-10-12 14:34:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:34:25 --> Form Validation Class Initialized
INFO - 2018-10-12 14:34:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-12 14:34:25 --> Database Driver Class Initialized
INFO - 2018-10-12 14:34:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:34:25 --> Config Class Initialized
INFO - 2018-10-12 14:34:25 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:34:25 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:34:25 --> Utf8 Class Initialized
INFO - 2018-10-12 14:34:25 --> URI Class Initialized
INFO - 2018-10-12 14:34:25 --> Router Class Initialized
INFO - 2018-10-12 14:34:25 --> Output Class Initialized
INFO - 2018-10-12 14:34:25 --> Security Class Initialized
DEBUG - 2018-10-12 14:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:34:25 --> CSRF cookie sent
INFO - 2018-10-12 14:34:25 --> Input Class Initialized
INFO - 2018-10-12 14:34:25 --> Language Class Initialized
INFO - 2018-10-12 14:34:25 --> Loader Class Initialized
INFO - 2018-10-12 14:34:25 --> Helper loaded: url_helper
INFO - 2018-10-12 14:34:25 --> Helper loaded: form_helper
INFO - 2018-10-12 14:34:25 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:34:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:34:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:34:25 --> User Agent Class Initialized
INFO - 2018-10-12 14:34:25 --> Controller Class Initialized
INFO - 2018-10-12 14:34:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:34:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:34:25 --> Pixel_Model class loaded
INFO - 2018-10-12 14:34:25 --> Database Driver Class Initialized
INFO - 2018-10-12 14:34:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:34:25 --> Database Driver Class Initialized
INFO - 2018-10-12 14:34:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:34:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:34:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:34:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:34:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 14:34:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 14:34:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 14:34:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-10-12 14:34:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:34:25 --> Final output sent to browser
DEBUG - 2018-10-12 14:34:25 --> Total execution time: 0.0499
INFO - 2018-10-12 14:34:35 --> Config Class Initialized
INFO - 2018-10-12 14:34:35 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:34:35 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:34:35 --> Utf8 Class Initialized
INFO - 2018-10-12 14:34:35 --> URI Class Initialized
INFO - 2018-10-12 14:34:35 --> Router Class Initialized
INFO - 2018-10-12 14:34:35 --> Output Class Initialized
INFO - 2018-10-12 14:34:35 --> Security Class Initialized
DEBUG - 2018-10-12 14:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:34:35 --> CSRF cookie sent
INFO - 2018-10-12 14:34:35 --> Input Class Initialized
INFO - 2018-10-12 14:34:35 --> Language Class Initialized
INFO - 2018-10-12 14:34:35 --> Loader Class Initialized
INFO - 2018-10-12 14:34:35 --> Helper loaded: url_helper
INFO - 2018-10-12 14:34:35 --> Helper loaded: form_helper
INFO - 2018-10-12 14:34:35 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:34:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:34:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:34:35 --> User Agent Class Initialized
INFO - 2018-10-12 14:34:35 --> Controller Class Initialized
INFO - 2018-10-12 14:34:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:34:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:34:35 --> Pixel_Model class loaded
INFO - 2018-10-12 14:34:35 --> Database Driver Class Initialized
INFO - 2018-10-12 14:34:35 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:34:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:34:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:34:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:34:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 14:34:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 14:34:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 14:34:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-10-12 14:34:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:34:35 --> Final output sent to browser
DEBUG - 2018-10-12 14:34:35 --> Total execution time: 0.0389
INFO - 2018-10-12 14:34:43 --> Config Class Initialized
INFO - 2018-10-12 14:34:43 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:34:43 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:34:43 --> Utf8 Class Initialized
INFO - 2018-10-12 14:34:43 --> URI Class Initialized
INFO - 2018-10-12 14:34:43 --> Router Class Initialized
INFO - 2018-10-12 14:34:43 --> Output Class Initialized
INFO - 2018-10-12 14:34:43 --> Security Class Initialized
DEBUG - 2018-10-12 14:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:34:43 --> CSRF cookie sent
INFO - 2018-10-12 14:34:43 --> CSRF token verified
INFO - 2018-10-12 14:34:43 --> Input Class Initialized
INFO - 2018-10-12 14:34:43 --> Language Class Initialized
INFO - 2018-10-12 14:34:43 --> Loader Class Initialized
INFO - 2018-10-12 14:34:43 --> Helper loaded: url_helper
INFO - 2018-10-12 14:34:43 --> Helper loaded: form_helper
INFO - 2018-10-12 14:34:43 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:34:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:34:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:34:43 --> User Agent Class Initialized
INFO - 2018-10-12 14:34:43 --> Controller Class Initialized
INFO - 2018-10-12 14:34:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:34:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:34:43 --> Pixel_Model class loaded
INFO - 2018-10-12 14:34:43 --> Database Driver Class Initialized
INFO - 2018-10-12 14:34:43 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:34:43 --> Database Driver Class Initialized
INFO - 2018-10-12 14:34:43 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:34:44 --> Config Class Initialized
INFO - 2018-10-12 14:34:44 --> Hooks Class Initialized
DEBUG - 2018-10-12 14:34:44 --> UTF-8 Support Enabled
INFO - 2018-10-12 14:34:44 --> Utf8 Class Initialized
INFO - 2018-10-12 14:34:44 --> URI Class Initialized
INFO - 2018-10-12 14:34:44 --> Router Class Initialized
INFO - 2018-10-12 14:34:44 --> Output Class Initialized
INFO - 2018-10-12 14:34:44 --> Security Class Initialized
DEBUG - 2018-10-12 14:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 14:34:44 --> CSRF cookie sent
INFO - 2018-10-12 14:34:44 --> Input Class Initialized
INFO - 2018-10-12 14:34:44 --> Language Class Initialized
INFO - 2018-10-12 14:34:44 --> Loader Class Initialized
INFO - 2018-10-12 14:34:44 --> Helper loaded: url_helper
INFO - 2018-10-12 14:34:44 --> Helper loaded: form_helper
INFO - 2018-10-12 14:34:44 --> Helper loaded: language_helper
DEBUG - 2018-10-12 14:34:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 14:34:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 14:34:44 --> User Agent Class Initialized
INFO - 2018-10-12 14:34:44 --> Controller Class Initialized
INFO - 2018-10-12 14:34:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 14:34:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 14:34:44 --> Pixel_Model class loaded
INFO - 2018-10-12 14:34:44 --> Database Driver Class Initialized
INFO - 2018-10-12 14:34:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:34:44 --> Database Driver Class Initialized
INFO - 2018-10-12 14:34:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 14:34:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 14:34:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 14:34:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 14:34:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 14:34:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 14:34:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 14:34:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-10-12 14:34:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 14:34:44 --> Final output sent to browser
DEBUG - 2018-10-12 14:34:44 --> Total execution time: 0.0477
INFO - 2018-10-12 15:12:33 --> Config Class Initialized
INFO - 2018-10-12 15:12:33 --> Hooks Class Initialized
DEBUG - 2018-10-12 15:12:33 --> UTF-8 Support Enabled
INFO - 2018-10-12 15:12:33 --> Utf8 Class Initialized
INFO - 2018-10-12 15:12:33 --> URI Class Initialized
INFO - 2018-10-12 15:12:33 --> Router Class Initialized
INFO - 2018-10-12 15:12:33 --> Output Class Initialized
INFO - 2018-10-12 15:12:33 --> Security Class Initialized
DEBUG - 2018-10-12 15:12:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 15:12:33 --> CSRF cookie sent
INFO - 2018-10-12 15:12:33 --> Input Class Initialized
INFO - 2018-10-12 15:12:33 --> Language Class Initialized
INFO - 2018-10-12 15:12:33 --> Loader Class Initialized
INFO - 2018-10-12 15:12:33 --> Helper loaded: url_helper
INFO - 2018-10-12 15:12:33 --> Helper loaded: form_helper
INFO - 2018-10-12 15:12:33 --> Helper loaded: language_helper
DEBUG - 2018-10-12 15:12:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 15:12:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 15:12:33 --> User Agent Class Initialized
INFO - 2018-10-12 15:12:34 --> Controller Class Initialized
INFO - 2018-10-12 15:12:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 15:12:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 15:12:34 --> Pixel_Model class loaded
INFO - 2018-10-12 15:12:34 --> Database Driver Class Initialized
INFO - 2018-10-12 15:12:34 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:12:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 15:12:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 15:12:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 15:12:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 15:12:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 15:12:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 15:12:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-10-12 15:12:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 15:12:34 --> Final output sent to browser
DEBUG - 2018-10-12 15:12:34 --> Total execution time: 0.0539
INFO - 2018-10-12 15:12:44 --> Config Class Initialized
INFO - 2018-10-12 15:12:44 --> Hooks Class Initialized
DEBUG - 2018-10-12 15:12:44 --> UTF-8 Support Enabled
INFO - 2018-10-12 15:12:44 --> Utf8 Class Initialized
INFO - 2018-10-12 15:12:44 --> URI Class Initialized
DEBUG - 2018-10-12 15:12:44 --> No URI present. Default controller set.
INFO - 2018-10-12 15:12:44 --> Router Class Initialized
INFO - 2018-10-12 15:12:44 --> Output Class Initialized
INFO - 2018-10-12 15:12:44 --> Security Class Initialized
DEBUG - 2018-10-12 15:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 15:12:44 --> CSRF cookie sent
INFO - 2018-10-12 15:12:44 --> Input Class Initialized
INFO - 2018-10-12 15:12:44 --> Language Class Initialized
INFO - 2018-10-12 15:12:44 --> Loader Class Initialized
INFO - 2018-10-12 15:12:44 --> Helper loaded: url_helper
INFO - 2018-10-12 15:12:44 --> Helper loaded: form_helper
INFO - 2018-10-12 15:12:44 --> Helper loaded: language_helper
DEBUG - 2018-10-12 15:12:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 15:12:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 15:12:44 --> User Agent Class Initialized
INFO - 2018-10-12 15:12:44 --> Controller Class Initialized
INFO - 2018-10-12 15:12:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 15:12:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 15:12:44 --> Pixel_Model class loaded
INFO - 2018-10-12 15:12:44 --> Database Driver Class Initialized
INFO - 2018-10-12 15:12:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:12:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 15:12:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 15:12:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-12 15:12:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 15:12:44 --> Final output sent to browser
DEBUG - 2018-10-12 15:12:44 --> Total execution time: 0.0428
INFO - 2018-10-12 15:13:39 --> Config Class Initialized
INFO - 2018-10-12 15:13:39 --> Hooks Class Initialized
DEBUG - 2018-10-12 15:13:39 --> UTF-8 Support Enabled
INFO - 2018-10-12 15:13:39 --> Utf8 Class Initialized
INFO - 2018-10-12 15:13:39 --> URI Class Initialized
INFO - 2018-10-12 15:13:39 --> Router Class Initialized
INFO - 2018-10-12 15:13:39 --> Output Class Initialized
INFO - 2018-10-12 15:13:39 --> Security Class Initialized
DEBUG - 2018-10-12 15:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 15:13:39 --> CSRF cookie sent
INFO - 2018-10-12 15:13:39 --> Input Class Initialized
INFO - 2018-10-12 15:13:39 --> Language Class Initialized
INFO - 2018-10-12 15:13:39 --> Loader Class Initialized
INFO - 2018-10-12 15:13:39 --> Helper loaded: url_helper
INFO - 2018-10-12 15:13:39 --> Helper loaded: form_helper
INFO - 2018-10-12 15:13:39 --> Helper loaded: language_helper
DEBUG - 2018-10-12 15:13:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 15:13:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 15:13:39 --> User Agent Class Initialized
INFO - 2018-10-12 15:13:39 --> Controller Class Initialized
INFO - 2018-10-12 15:13:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 15:13:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 15:13:39 --> Pixel_Model class loaded
INFO - 2018-10-12 15:13:39 --> Database Driver Class Initialized
INFO - 2018-10-12 15:13:39 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:13:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 15:13:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 15:13:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 15:13:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 15:13:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 15:13:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 15:13:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-10-12 15:13:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 15:13:39 --> Final output sent to browser
DEBUG - 2018-10-12 15:13:39 --> Total execution time: 0.0504
INFO - 2018-10-12 15:13:42 --> Config Class Initialized
INFO - 2018-10-12 15:13:42 --> Hooks Class Initialized
DEBUG - 2018-10-12 15:13:42 --> UTF-8 Support Enabled
INFO - 2018-10-12 15:13:42 --> Utf8 Class Initialized
INFO - 2018-10-12 15:13:42 --> URI Class Initialized
INFO - 2018-10-12 15:13:42 --> Router Class Initialized
INFO - 2018-10-12 15:13:42 --> Output Class Initialized
INFO - 2018-10-12 15:13:42 --> Security Class Initialized
DEBUG - 2018-10-12 15:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 15:13:42 --> CSRF cookie sent
INFO - 2018-10-12 15:13:42 --> CSRF token verified
INFO - 2018-10-12 15:13:42 --> Input Class Initialized
INFO - 2018-10-12 15:13:42 --> Language Class Initialized
INFO - 2018-10-12 15:13:42 --> Loader Class Initialized
INFO - 2018-10-12 15:13:42 --> Helper loaded: url_helper
INFO - 2018-10-12 15:13:42 --> Helper loaded: form_helper
INFO - 2018-10-12 15:13:42 --> Helper loaded: language_helper
DEBUG - 2018-10-12 15:13:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 15:13:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 15:13:42 --> User Agent Class Initialized
INFO - 2018-10-12 15:13:42 --> Controller Class Initialized
INFO - 2018-10-12 15:13:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 15:13:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 15:13:42 --> Pixel_Model class loaded
INFO - 2018-10-12 15:13:42 --> Database Driver Class Initialized
INFO - 2018-10-12 15:13:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:13:42 --> Database Driver Class Initialized
INFO - 2018-10-12 15:13:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:13:42 --> Config Class Initialized
INFO - 2018-10-12 15:13:42 --> Hooks Class Initialized
DEBUG - 2018-10-12 15:13:42 --> UTF-8 Support Enabled
INFO - 2018-10-12 15:13:42 --> Utf8 Class Initialized
INFO - 2018-10-12 15:13:42 --> URI Class Initialized
INFO - 2018-10-12 15:13:42 --> Router Class Initialized
INFO - 2018-10-12 15:13:42 --> Output Class Initialized
INFO - 2018-10-12 15:13:42 --> Security Class Initialized
DEBUG - 2018-10-12 15:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 15:13:42 --> CSRF cookie sent
INFO - 2018-10-12 15:13:42 --> Input Class Initialized
INFO - 2018-10-12 15:13:42 --> Language Class Initialized
INFO - 2018-10-12 15:13:42 --> Loader Class Initialized
INFO - 2018-10-12 15:13:42 --> Helper loaded: url_helper
INFO - 2018-10-12 15:13:42 --> Helper loaded: form_helper
INFO - 2018-10-12 15:13:42 --> Helper loaded: language_helper
DEBUG - 2018-10-12 15:13:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 15:13:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 15:13:42 --> User Agent Class Initialized
INFO - 2018-10-12 15:13:42 --> Controller Class Initialized
INFO - 2018-10-12 15:13:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 15:13:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 15:13:42 --> Pixel_Model class loaded
INFO - 2018-10-12 15:13:42 --> Database Driver Class Initialized
INFO - 2018-10-12 15:13:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:13:42 --> Database Driver Class Initialized
INFO - 2018-10-12 15:13:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:13:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 15:13:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 15:13:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 15:13:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 15:13:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 15:13:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 15:13:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-12 15:13:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 15:13:42 --> Final output sent to browser
DEBUG - 2018-10-12 15:13:42 --> Total execution time: 0.0476
INFO - 2018-10-12 15:13:46 --> Config Class Initialized
INFO - 2018-10-12 15:13:46 --> Hooks Class Initialized
DEBUG - 2018-10-12 15:13:46 --> UTF-8 Support Enabled
INFO - 2018-10-12 15:13:46 --> Utf8 Class Initialized
INFO - 2018-10-12 15:13:46 --> URI Class Initialized
INFO - 2018-10-12 15:13:46 --> Router Class Initialized
INFO - 2018-10-12 15:13:46 --> Output Class Initialized
INFO - 2018-10-12 15:13:46 --> Security Class Initialized
DEBUG - 2018-10-12 15:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 15:13:46 --> CSRF cookie sent
INFO - 2018-10-12 15:13:46 --> CSRF token verified
INFO - 2018-10-12 15:13:46 --> Input Class Initialized
INFO - 2018-10-12 15:13:46 --> Language Class Initialized
INFO - 2018-10-12 15:13:46 --> Loader Class Initialized
INFO - 2018-10-12 15:13:46 --> Helper loaded: url_helper
INFO - 2018-10-12 15:13:46 --> Helper loaded: form_helper
INFO - 2018-10-12 15:13:46 --> Helper loaded: language_helper
DEBUG - 2018-10-12 15:13:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 15:13:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 15:13:46 --> User Agent Class Initialized
INFO - 2018-10-12 15:13:46 --> Controller Class Initialized
INFO - 2018-10-12 15:13:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 15:13:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 15:13:46 --> Pixel_Model class loaded
INFO - 2018-10-12 15:13:46 --> Database Driver Class Initialized
INFO - 2018-10-12 15:13:46 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:13:46 --> Form Validation Class Initialized
INFO - 2018-10-12 15:13:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-12 15:13:46 --> Database Driver Class Initialized
INFO - 2018-10-12 15:13:46 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:13:47 --> Config Class Initialized
INFO - 2018-10-12 15:13:47 --> Hooks Class Initialized
DEBUG - 2018-10-12 15:13:47 --> UTF-8 Support Enabled
INFO - 2018-10-12 15:13:47 --> Utf8 Class Initialized
INFO - 2018-10-12 15:13:47 --> URI Class Initialized
INFO - 2018-10-12 15:13:47 --> Router Class Initialized
INFO - 2018-10-12 15:13:47 --> Output Class Initialized
INFO - 2018-10-12 15:13:47 --> Security Class Initialized
DEBUG - 2018-10-12 15:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 15:13:47 --> CSRF cookie sent
INFO - 2018-10-12 15:13:47 --> Input Class Initialized
INFO - 2018-10-12 15:13:47 --> Language Class Initialized
INFO - 2018-10-12 15:13:47 --> Loader Class Initialized
INFO - 2018-10-12 15:13:47 --> Helper loaded: url_helper
INFO - 2018-10-12 15:13:47 --> Helper loaded: form_helper
INFO - 2018-10-12 15:13:47 --> Helper loaded: language_helper
DEBUG - 2018-10-12 15:13:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 15:13:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 15:13:47 --> User Agent Class Initialized
INFO - 2018-10-12 15:13:47 --> Controller Class Initialized
INFO - 2018-10-12 15:13:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 15:13:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 15:13:47 --> Pixel_Model class loaded
INFO - 2018-10-12 15:13:47 --> Database Driver Class Initialized
INFO - 2018-10-12 15:13:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:13:47 --> Database Driver Class Initialized
INFO - 2018-10-12 15:13:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:13:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 15:13:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 15:13:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 15:13:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 15:13:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 15:13:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 15:13:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-10-12 15:13:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 15:13:47 --> Final output sent to browser
DEBUG - 2018-10-12 15:13:47 --> Total execution time: 0.0643
INFO - 2018-10-12 15:13:50 --> Config Class Initialized
INFO - 2018-10-12 15:13:50 --> Hooks Class Initialized
DEBUG - 2018-10-12 15:13:50 --> UTF-8 Support Enabled
INFO - 2018-10-12 15:13:50 --> Utf8 Class Initialized
INFO - 2018-10-12 15:13:50 --> URI Class Initialized
INFO - 2018-10-12 15:13:50 --> Router Class Initialized
INFO - 2018-10-12 15:13:50 --> Output Class Initialized
INFO - 2018-10-12 15:13:50 --> Security Class Initialized
DEBUG - 2018-10-12 15:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 15:13:50 --> CSRF cookie sent
INFO - 2018-10-12 15:13:50 --> Input Class Initialized
INFO - 2018-10-12 15:13:50 --> Language Class Initialized
INFO - 2018-10-12 15:13:50 --> Loader Class Initialized
INFO - 2018-10-12 15:13:50 --> Helper loaded: url_helper
INFO - 2018-10-12 15:13:50 --> Helper loaded: form_helper
INFO - 2018-10-12 15:13:50 --> Helper loaded: language_helper
DEBUG - 2018-10-12 15:13:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 15:13:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 15:13:50 --> User Agent Class Initialized
INFO - 2018-10-12 15:13:50 --> Controller Class Initialized
INFO - 2018-10-12 15:13:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 15:13:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 15:13:50 --> Pixel_Model class loaded
INFO - 2018-10-12 15:13:50 --> Database Driver Class Initialized
INFO - 2018-10-12 15:13:50 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:13:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 15:13:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 15:13:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 15:13:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 15:13:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 15:13:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 15:13:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-10-12 15:13:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 15:13:50 --> Final output sent to browser
DEBUG - 2018-10-12 15:13:50 --> Total execution time: 0.0403
INFO - 2018-10-12 15:14:59 --> Config Class Initialized
INFO - 2018-10-12 15:14:59 --> Hooks Class Initialized
DEBUG - 2018-10-12 15:14:59 --> UTF-8 Support Enabled
INFO - 2018-10-12 15:14:59 --> Utf8 Class Initialized
INFO - 2018-10-12 15:14:59 --> URI Class Initialized
DEBUG - 2018-10-12 15:14:59 --> No URI present. Default controller set.
INFO - 2018-10-12 15:14:59 --> Router Class Initialized
INFO - 2018-10-12 15:14:59 --> Output Class Initialized
INFO - 2018-10-12 15:14:59 --> Security Class Initialized
DEBUG - 2018-10-12 15:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 15:14:59 --> CSRF cookie sent
INFO - 2018-10-12 15:14:59 --> Input Class Initialized
INFO - 2018-10-12 15:14:59 --> Language Class Initialized
INFO - 2018-10-12 15:14:59 --> Loader Class Initialized
INFO - 2018-10-12 15:14:59 --> Helper loaded: url_helper
INFO - 2018-10-12 15:14:59 --> Helper loaded: form_helper
INFO - 2018-10-12 15:14:59 --> Helper loaded: language_helper
DEBUG - 2018-10-12 15:14:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 15:14:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 15:14:59 --> User Agent Class Initialized
INFO - 2018-10-12 15:14:59 --> Controller Class Initialized
INFO - 2018-10-12 15:14:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 15:14:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 15:14:59 --> Pixel_Model class loaded
INFO - 2018-10-12 15:14:59 --> Database Driver Class Initialized
INFO - 2018-10-12 15:14:59 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:14:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 15:14:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 15:14:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-12 15:14:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 15:14:59 --> Final output sent to browser
DEBUG - 2018-10-12 15:14:59 --> Total execution time: 0.0503
INFO - 2018-10-12 15:15:16 --> Config Class Initialized
INFO - 2018-10-12 15:15:16 --> Hooks Class Initialized
DEBUG - 2018-10-12 15:15:16 --> UTF-8 Support Enabled
INFO - 2018-10-12 15:15:16 --> Utf8 Class Initialized
INFO - 2018-10-12 15:15:16 --> URI Class Initialized
INFO - 2018-10-12 15:15:16 --> Router Class Initialized
INFO - 2018-10-12 15:15:16 --> Output Class Initialized
INFO - 2018-10-12 15:15:16 --> Security Class Initialized
DEBUG - 2018-10-12 15:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 15:15:16 --> CSRF cookie sent
INFO - 2018-10-12 15:15:16 --> Input Class Initialized
INFO - 2018-10-12 15:15:16 --> Language Class Initialized
INFO - 2018-10-12 15:15:16 --> Loader Class Initialized
INFO - 2018-10-12 15:15:16 --> Helper loaded: url_helper
INFO - 2018-10-12 15:15:16 --> Helper loaded: form_helper
INFO - 2018-10-12 15:15:16 --> Helper loaded: language_helper
DEBUG - 2018-10-12 15:15:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 15:15:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 15:15:16 --> User Agent Class Initialized
INFO - 2018-10-12 15:15:16 --> Controller Class Initialized
INFO - 2018-10-12 15:15:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 15:15:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 15:15:16 --> Pixel_Model class loaded
INFO - 2018-10-12 15:15:16 --> Database Driver Class Initialized
INFO - 2018-10-12 15:15:16 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:15:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 15:15:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 15:15:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 15:15:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 15:15:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 15:15:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 15:15:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-10-12 15:15:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 15:15:16 --> Final output sent to browser
DEBUG - 2018-10-12 15:15:16 --> Total execution time: 0.0371
INFO - 2018-10-12 15:15:19 --> Config Class Initialized
INFO - 2018-10-12 15:15:19 --> Hooks Class Initialized
DEBUG - 2018-10-12 15:15:19 --> UTF-8 Support Enabled
INFO - 2018-10-12 15:15:19 --> Utf8 Class Initialized
INFO - 2018-10-12 15:15:19 --> URI Class Initialized
INFO - 2018-10-12 15:15:19 --> Router Class Initialized
INFO - 2018-10-12 15:15:19 --> Output Class Initialized
INFO - 2018-10-12 15:15:19 --> Security Class Initialized
DEBUG - 2018-10-12 15:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 15:15:19 --> CSRF cookie sent
INFO - 2018-10-12 15:15:19 --> CSRF token verified
INFO - 2018-10-12 15:15:19 --> Input Class Initialized
INFO - 2018-10-12 15:15:19 --> Language Class Initialized
INFO - 2018-10-12 15:15:19 --> Loader Class Initialized
INFO - 2018-10-12 15:15:19 --> Helper loaded: url_helper
INFO - 2018-10-12 15:15:19 --> Helper loaded: form_helper
INFO - 2018-10-12 15:15:19 --> Helper loaded: language_helper
DEBUG - 2018-10-12 15:15:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 15:15:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 15:15:19 --> User Agent Class Initialized
INFO - 2018-10-12 15:15:19 --> Controller Class Initialized
INFO - 2018-10-12 15:15:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 15:15:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 15:15:19 --> Pixel_Model class loaded
INFO - 2018-10-12 15:15:19 --> Database Driver Class Initialized
INFO - 2018-10-12 15:15:19 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:15:19 --> Database Driver Class Initialized
INFO - 2018-10-12 15:15:19 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:15:20 --> Config Class Initialized
INFO - 2018-10-12 15:15:20 --> Hooks Class Initialized
DEBUG - 2018-10-12 15:15:20 --> UTF-8 Support Enabled
INFO - 2018-10-12 15:15:20 --> Utf8 Class Initialized
INFO - 2018-10-12 15:15:20 --> URI Class Initialized
INFO - 2018-10-12 15:15:20 --> Router Class Initialized
INFO - 2018-10-12 15:15:20 --> Output Class Initialized
INFO - 2018-10-12 15:15:20 --> Security Class Initialized
DEBUG - 2018-10-12 15:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 15:15:20 --> CSRF cookie sent
INFO - 2018-10-12 15:15:20 --> Input Class Initialized
INFO - 2018-10-12 15:15:20 --> Language Class Initialized
INFO - 2018-10-12 15:15:20 --> Loader Class Initialized
INFO - 2018-10-12 15:15:20 --> Helper loaded: url_helper
INFO - 2018-10-12 15:15:20 --> Helper loaded: form_helper
INFO - 2018-10-12 15:15:20 --> Helper loaded: language_helper
DEBUG - 2018-10-12 15:15:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 15:15:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 15:15:20 --> User Agent Class Initialized
INFO - 2018-10-12 15:15:20 --> Controller Class Initialized
INFO - 2018-10-12 15:15:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 15:15:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 15:15:20 --> Pixel_Model class loaded
INFO - 2018-10-12 15:15:20 --> Database Driver Class Initialized
INFO - 2018-10-12 15:15:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:15:20 --> Database Driver Class Initialized
INFO - 2018-10-12 15:15:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:15:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 15:15:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 15:15:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 15:15:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 15:15:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 15:15:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 15:15:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-12 15:15:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 15:15:20 --> Final output sent to browser
DEBUG - 2018-10-12 15:15:20 --> Total execution time: 0.0483
INFO - 2018-10-12 15:15:23 --> Config Class Initialized
INFO - 2018-10-12 15:15:23 --> Hooks Class Initialized
DEBUG - 2018-10-12 15:15:23 --> UTF-8 Support Enabled
INFO - 2018-10-12 15:15:23 --> Utf8 Class Initialized
INFO - 2018-10-12 15:15:23 --> URI Class Initialized
INFO - 2018-10-12 15:15:23 --> Router Class Initialized
INFO - 2018-10-12 15:15:23 --> Output Class Initialized
INFO - 2018-10-12 15:15:23 --> Security Class Initialized
DEBUG - 2018-10-12 15:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 15:15:23 --> CSRF cookie sent
INFO - 2018-10-12 15:15:23 --> CSRF token verified
INFO - 2018-10-12 15:15:23 --> Input Class Initialized
INFO - 2018-10-12 15:15:23 --> Language Class Initialized
INFO - 2018-10-12 15:15:23 --> Loader Class Initialized
INFO - 2018-10-12 15:15:23 --> Helper loaded: url_helper
INFO - 2018-10-12 15:15:23 --> Helper loaded: form_helper
INFO - 2018-10-12 15:15:23 --> Helper loaded: language_helper
DEBUG - 2018-10-12 15:15:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 15:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 15:15:23 --> User Agent Class Initialized
INFO - 2018-10-12 15:15:23 --> Controller Class Initialized
INFO - 2018-10-12 15:15:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 15:15:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 15:15:23 --> Pixel_Model class loaded
INFO - 2018-10-12 15:15:23 --> Database Driver Class Initialized
INFO - 2018-10-12 15:15:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:15:23 --> Form Validation Class Initialized
INFO - 2018-10-12 15:15:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-12 15:15:23 --> Database Driver Class Initialized
INFO - 2018-10-12 15:15:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:15:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 15:15:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 15:15:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 15:15:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 15:15:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 15:15:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_errors.php
INFO - 2018-10-12 15:15:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 15:15:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-12 15:15:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 15:15:23 --> Final output sent to browser
DEBUG - 2018-10-12 15:15:23 --> Total execution time: 0.0684
INFO - 2018-10-12 15:15:27 --> Config Class Initialized
INFO - 2018-10-12 15:15:27 --> Hooks Class Initialized
DEBUG - 2018-10-12 15:15:27 --> UTF-8 Support Enabled
INFO - 2018-10-12 15:15:27 --> Utf8 Class Initialized
INFO - 2018-10-12 15:15:27 --> URI Class Initialized
INFO - 2018-10-12 15:15:27 --> Router Class Initialized
INFO - 2018-10-12 15:15:27 --> Output Class Initialized
INFO - 2018-10-12 15:15:27 --> Security Class Initialized
DEBUG - 2018-10-12 15:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 15:15:27 --> CSRF cookie sent
INFO - 2018-10-12 15:15:27 --> CSRF token verified
INFO - 2018-10-12 15:15:27 --> Input Class Initialized
INFO - 2018-10-12 15:15:27 --> Language Class Initialized
INFO - 2018-10-12 15:15:27 --> Loader Class Initialized
INFO - 2018-10-12 15:15:27 --> Helper loaded: url_helper
INFO - 2018-10-12 15:15:27 --> Helper loaded: form_helper
INFO - 2018-10-12 15:15:27 --> Helper loaded: language_helper
DEBUG - 2018-10-12 15:15:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 15:15:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 15:15:27 --> User Agent Class Initialized
INFO - 2018-10-12 15:15:27 --> Controller Class Initialized
INFO - 2018-10-12 15:15:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 15:15:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 15:15:27 --> Pixel_Model class loaded
INFO - 2018-10-12 15:15:27 --> Database Driver Class Initialized
INFO - 2018-10-12 15:15:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:15:27 --> Form Validation Class Initialized
INFO - 2018-10-12 15:15:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-12 15:15:27 --> Database Driver Class Initialized
INFO - 2018-10-12 15:15:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:15:28 --> Config Class Initialized
INFO - 2018-10-12 15:15:28 --> Hooks Class Initialized
DEBUG - 2018-10-12 15:15:28 --> UTF-8 Support Enabled
INFO - 2018-10-12 15:15:28 --> Utf8 Class Initialized
INFO - 2018-10-12 15:15:28 --> URI Class Initialized
INFO - 2018-10-12 15:15:28 --> Router Class Initialized
INFO - 2018-10-12 15:15:28 --> Output Class Initialized
INFO - 2018-10-12 15:15:28 --> Security Class Initialized
DEBUG - 2018-10-12 15:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 15:15:28 --> CSRF cookie sent
INFO - 2018-10-12 15:15:28 --> Input Class Initialized
INFO - 2018-10-12 15:15:28 --> Language Class Initialized
INFO - 2018-10-12 15:15:28 --> Loader Class Initialized
INFO - 2018-10-12 15:15:28 --> Helper loaded: url_helper
INFO - 2018-10-12 15:15:28 --> Helper loaded: form_helper
INFO - 2018-10-12 15:15:28 --> Helper loaded: language_helper
DEBUG - 2018-10-12 15:15:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 15:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 15:15:28 --> User Agent Class Initialized
INFO - 2018-10-12 15:15:28 --> Controller Class Initialized
INFO - 2018-10-12 15:15:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 15:15:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 15:15:28 --> Pixel_Model class loaded
INFO - 2018-10-12 15:15:28 --> Database Driver Class Initialized
INFO - 2018-10-12 15:15:28 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:15:28 --> Database Driver Class Initialized
INFO - 2018-10-12 15:15:28 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:15:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 15:15:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 15:15:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 15:15:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 15:15:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 15:15:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 15:15:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-10-12 15:15:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 15:15:28 --> Final output sent to browser
DEBUG - 2018-10-12 15:15:28 --> Total execution time: 0.0471
INFO - 2018-10-12 15:15:30 --> Config Class Initialized
INFO - 2018-10-12 15:15:30 --> Hooks Class Initialized
DEBUG - 2018-10-12 15:15:30 --> UTF-8 Support Enabled
INFO - 2018-10-12 15:15:30 --> Utf8 Class Initialized
INFO - 2018-10-12 15:15:30 --> URI Class Initialized
INFO - 2018-10-12 15:15:30 --> Router Class Initialized
INFO - 2018-10-12 15:15:30 --> Output Class Initialized
INFO - 2018-10-12 15:15:30 --> Security Class Initialized
DEBUG - 2018-10-12 15:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 15:15:30 --> CSRF cookie sent
INFO - 2018-10-12 15:15:30 --> CSRF token verified
INFO - 2018-10-12 15:15:30 --> Input Class Initialized
INFO - 2018-10-12 15:15:30 --> Language Class Initialized
INFO - 2018-10-12 15:15:30 --> Loader Class Initialized
INFO - 2018-10-12 15:15:30 --> Helper loaded: url_helper
INFO - 2018-10-12 15:15:30 --> Helper loaded: form_helper
INFO - 2018-10-12 15:15:30 --> Helper loaded: language_helper
DEBUG - 2018-10-12 15:15:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 15:15:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 15:15:30 --> User Agent Class Initialized
INFO - 2018-10-12 15:15:30 --> Controller Class Initialized
INFO - 2018-10-12 15:15:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 15:15:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 15:15:30 --> Pixel_Model class loaded
INFO - 2018-10-12 15:15:30 --> Database Driver Class Initialized
INFO - 2018-10-12 15:15:30 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:15:30 --> Form Validation Class Initialized
INFO - 2018-10-12 15:15:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-12 15:15:30 --> Database Driver Class Initialized
INFO - 2018-10-12 15:15:30 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:15:30 --> Config Class Initialized
INFO - 2018-10-12 15:15:30 --> Hooks Class Initialized
DEBUG - 2018-10-12 15:15:30 --> UTF-8 Support Enabled
INFO - 2018-10-12 15:15:30 --> Utf8 Class Initialized
INFO - 2018-10-12 15:15:30 --> URI Class Initialized
INFO - 2018-10-12 15:15:30 --> Router Class Initialized
INFO - 2018-10-12 15:15:30 --> Output Class Initialized
INFO - 2018-10-12 15:15:30 --> Security Class Initialized
DEBUG - 2018-10-12 15:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 15:15:30 --> CSRF cookie sent
INFO - 2018-10-12 15:15:30 --> Input Class Initialized
INFO - 2018-10-12 15:15:30 --> Language Class Initialized
INFO - 2018-10-12 15:15:30 --> Loader Class Initialized
INFO - 2018-10-12 15:15:30 --> Helper loaded: url_helper
INFO - 2018-10-12 15:15:30 --> Helper loaded: form_helper
INFO - 2018-10-12 15:15:30 --> Helper loaded: language_helper
DEBUG - 2018-10-12 15:15:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 15:15:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 15:15:30 --> User Agent Class Initialized
INFO - 2018-10-12 15:15:30 --> Controller Class Initialized
INFO - 2018-10-12 15:15:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 15:15:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 15:15:30 --> Pixel_Model class loaded
INFO - 2018-10-12 15:15:30 --> Database Driver Class Initialized
INFO - 2018-10-12 15:15:30 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:15:30 --> Database Driver Class Initialized
INFO - 2018-10-12 15:15:30 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:15:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 15:15:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 15:15:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-10-12 15:15:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 15:15:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 15:15:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 15:15:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 15:15:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-10-12 15:15:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 15:15:30 --> Final output sent to browser
DEBUG - 2018-10-12 15:15:30 --> Total execution time: 0.0341
INFO - 2018-10-12 15:15:32 --> Config Class Initialized
INFO - 2018-10-12 15:15:32 --> Hooks Class Initialized
DEBUG - 2018-10-12 15:15:32 --> UTF-8 Support Enabled
INFO - 2018-10-12 15:15:32 --> Utf8 Class Initialized
INFO - 2018-10-12 15:15:32 --> URI Class Initialized
INFO - 2018-10-12 15:15:32 --> Router Class Initialized
INFO - 2018-10-12 15:15:32 --> Output Class Initialized
INFO - 2018-10-12 15:15:32 --> Security Class Initialized
DEBUG - 2018-10-12 15:15:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 15:15:32 --> CSRF cookie sent
INFO - 2018-10-12 15:15:32 --> CSRF token verified
INFO - 2018-10-12 15:15:32 --> Input Class Initialized
INFO - 2018-10-12 15:15:32 --> Language Class Initialized
INFO - 2018-10-12 15:15:32 --> Loader Class Initialized
INFO - 2018-10-12 15:15:32 --> Helper loaded: url_helper
INFO - 2018-10-12 15:15:32 --> Helper loaded: form_helper
INFO - 2018-10-12 15:15:32 --> Helper loaded: language_helper
DEBUG - 2018-10-12 15:15:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 15:15:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 15:15:32 --> User Agent Class Initialized
INFO - 2018-10-12 15:15:32 --> Controller Class Initialized
INFO - 2018-10-12 15:15:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 15:15:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 15:15:32 --> Pixel_Model class loaded
INFO - 2018-10-12 15:15:32 --> Database Driver Class Initialized
INFO - 2018-10-12 15:15:32 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:15:32 --> Form Validation Class Initialized
INFO - 2018-10-12 15:15:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-12 15:15:32 --> Database Driver Class Initialized
INFO - 2018-10-12 15:15:32 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:15:33 --> Config Class Initialized
INFO - 2018-10-12 15:15:33 --> Hooks Class Initialized
DEBUG - 2018-10-12 15:15:33 --> UTF-8 Support Enabled
INFO - 2018-10-12 15:15:33 --> Utf8 Class Initialized
INFO - 2018-10-12 15:15:33 --> URI Class Initialized
INFO - 2018-10-12 15:15:33 --> Router Class Initialized
INFO - 2018-10-12 15:15:33 --> Output Class Initialized
INFO - 2018-10-12 15:15:33 --> Security Class Initialized
DEBUG - 2018-10-12 15:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 15:15:33 --> CSRF cookie sent
INFO - 2018-10-12 15:15:33 --> Input Class Initialized
INFO - 2018-10-12 15:15:33 --> Language Class Initialized
INFO - 2018-10-12 15:15:33 --> Loader Class Initialized
INFO - 2018-10-12 15:15:33 --> Helper loaded: url_helper
INFO - 2018-10-12 15:15:33 --> Helper loaded: form_helper
INFO - 2018-10-12 15:15:33 --> Helper loaded: language_helper
DEBUG - 2018-10-12 15:15:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 15:15:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 15:15:33 --> User Agent Class Initialized
INFO - 2018-10-12 15:15:33 --> Controller Class Initialized
INFO - 2018-10-12 15:15:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 15:15:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 15:15:33 --> Pixel_Model class loaded
INFO - 2018-10-12 15:15:33 --> Database Driver Class Initialized
INFO - 2018-10-12 15:15:33 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:15:33 --> Database Driver Class Initialized
INFO - 2018-10-12 15:15:33 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:15:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 15:15:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 15:15:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 15:15:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 15:15:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 15:15:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 15:15:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-12 15:15:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 15:15:33 --> Final output sent to browser
DEBUG - 2018-10-12 15:15:33 --> Total execution time: 0.0500
INFO - 2018-10-12 15:15:40 --> Config Class Initialized
INFO - 2018-10-12 15:15:40 --> Hooks Class Initialized
DEBUG - 2018-10-12 15:15:40 --> UTF-8 Support Enabled
INFO - 2018-10-12 15:15:40 --> Utf8 Class Initialized
INFO - 2018-10-12 15:15:40 --> URI Class Initialized
INFO - 2018-10-12 15:15:40 --> Router Class Initialized
INFO - 2018-10-12 15:15:40 --> Output Class Initialized
INFO - 2018-10-12 15:15:40 --> Security Class Initialized
DEBUG - 2018-10-12 15:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 15:15:40 --> CSRF cookie sent
INFO - 2018-10-12 15:15:40 --> CSRF token verified
INFO - 2018-10-12 15:15:40 --> Input Class Initialized
INFO - 2018-10-12 15:15:40 --> Language Class Initialized
INFO - 2018-10-12 15:15:40 --> Loader Class Initialized
INFO - 2018-10-12 15:15:40 --> Helper loaded: url_helper
INFO - 2018-10-12 15:15:40 --> Helper loaded: form_helper
INFO - 2018-10-12 15:15:40 --> Helper loaded: language_helper
DEBUG - 2018-10-12 15:15:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 15:15:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 15:15:40 --> User Agent Class Initialized
INFO - 2018-10-12 15:15:40 --> Controller Class Initialized
INFO - 2018-10-12 15:15:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 15:15:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 15:15:40 --> Pixel_Model class loaded
INFO - 2018-10-12 15:15:40 --> Database Driver Class Initialized
INFO - 2018-10-12 15:15:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:15:40 --> Form Validation Class Initialized
INFO - 2018-10-12 15:15:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-12 15:15:40 --> Database Driver Class Initialized
INFO - 2018-10-12 15:15:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:15:40 --> Config Class Initialized
INFO - 2018-10-12 15:15:40 --> Hooks Class Initialized
DEBUG - 2018-10-12 15:15:40 --> UTF-8 Support Enabled
INFO - 2018-10-12 15:15:40 --> Utf8 Class Initialized
INFO - 2018-10-12 15:15:40 --> URI Class Initialized
INFO - 2018-10-12 15:15:40 --> Router Class Initialized
INFO - 2018-10-12 15:15:40 --> Output Class Initialized
INFO - 2018-10-12 15:15:40 --> Security Class Initialized
DEBUG - 2018-10-12 15:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 15:15:40 --> CSRF cookie sent
INFO - 2018-10-12 15:15:40 --> Input Class Initialized
INFO - 2018-10-12 15:15:40 --> Language Class Initialized
INFO - 2018-10-12 15:15:40 --> Loader Class Initialized
INFO - 2018-10-12 15:15:40 --> Helper loaded: url_helper
INFO - 2018-10-12 15:15:40 --> Helper loaded: form_helper
INFO - 2018-10-12 15:15:40 --> Helper loaded: language_helper
DEBUG - 2018-10-12 15:15:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 15:15:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 15:15:40 --> User Agent Class Initialized
INFO - 2018-10-12 15:15:40 --> Controller Class Initialized
INFO - 2018-10-12 15:15:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 15:15:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 15:15:40 --> Pixel_Model class loaded
INFO - 2018-10-12 15:15:40 --> Database Driver Class Initialized
INFO - 2018-10-12 15:15:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:15:40 --> Database Driver Class Initialized
INFO - 2018-10-12 15:15:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:15:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 15:15:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 15:15:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 15:15:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 15:15:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 15:15:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 15:15:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-10-12 15:15:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 15:15:40 --> Final output sent to browser
DEBUG - 2018-10-12 15:15:40 --> Total execution time: 0.0429
INFO - 2018-10-12 15:15:46 --> Config Class Initialized
INFO - 2018-10-12 15:15:46 --> Hooks Class Initialized
DEBUG - 2018-10-12 15:15:46 --> UTF-8 Support Enabled
INFO - 2018-10-12 15:15:46 --> Utf8 Class Initialized
INFO - 2018-10-12 15:15:46 --> URI Class Initialized
INFO - 2018-10-12 15:15:46 --> Router Class Initialized
INFO - 2018-10-12 15:15:46 --> Output Class Initialized
INFO - 2018-10-12 15:15:46 --> Security Class Initialized
DEBUG - 2018-10-12 15:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 15:15:46 --> CSRF cookie sent
INFO - 2018-10-12 15:15:46 --> CSRF token verified
INFO - 2018-10-12 15:15:46 --> Input Class Initialized
INFO - 2018-10-12 15:15:46 --> Language Class Initialized
INFO - 2018-10-12 15:15:46 --> Loader Class Initialized
INFO - 2018-10-12 15:15:46 --> Helper loaded: url_helper
INFO - 2018-10-12 15:15:46 --> Helper loaded: form_helper
INFO - 2018-10-12 15:15:46 --> Helper loaded: language_helper
DEBUG - 2018-10-12 15:15:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 15:15:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 15:15:46 --> User Agent Class Initialized
INFO - 2018-10-12 15:15:46 --> Controller Class Initialized
INFO - 2018-10-12 15:15:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 15:15:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 15:15:46 --> Pixel_Model class loaded
INFO - 2018-10-12 15:15:46 --> Database Driver Class Initialized
INFO - 2018-10-12 15:15:46 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:15:46 --> Form Validation Class Initialized
INFO - 2018-10-12 15:15:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-12 15:15:46 --> Database Driver Class Initialized
INFO - 2018-10-12 15:15:46 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:15:46 --> Config Class Initialized
INFO - 2018-10-12 15:15:46 --> Hooks Class Initialized
DEBUG - 2018-10-12 15:15:46 --> UTF-8 Support Enabled
INFO - 2018-10-12 15:15:46 --> Utf8 Class Initialized
INFO - 2018-10-12 15:15:46 --> URI Class Initialized
INFO - 2018-10-12 15:15:46 --> Router Class Initialized
INFO - 2018-10-12 15:15:46 --> Output Class Initialized
INFO - 2018-10-12 15:15:46 --> Security Class Initialized
DEBUG - 2018-10-12 15:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 15:15:46 --> CSRF cookie sent
INFO - 2018-10-12 15:15:46 --> Input Class Initialized
INFO - 2018-10-12 15:15:46 --> Language Class Initialized
INFO - 2018-10-12 15:15:46 --> Loader Class Initialized
INFO - 2018-10-12 15:15:46 --> Helper loaded: url_helper
INFO - 2018-10-12 15:15:46 --> Helper loaded: form_helper
INFO - 2018-10-12 15:15:46 --> Helper loaded: language_helper
DEBUG - 2018-10-12 15:15:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 15:15:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 15:15:46 --> User Agent Class Initialized
INFO - 2018-10-12 15:15:46 --> Controller Class Initialized
INFO - 2018-10-12 15:15:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 15:15:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 15:15:46 --> Pixel_Model class loaded
INFO - 2018-10-12 15:15:46 --> Database Driver Class Initialized
INFO - 2018-10-12 15:15:46 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:15:46 --> Database Driver Class Initialized
INFO - 2018-10-12 15:15:46 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:15:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 15:15:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 15:15:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 15:15:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 15:15:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 15:15:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 15:15:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_title.php
INFO - 2018-10-12 15:15:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 15:15:46 --> Final output sent to browser
DEBUG - 2018-10-12 15:15:46 --> Total execution time: 0.0612
INFO - 2018-10-12 15:15:48 --> Config Class Initialized
INFO - 2018-10-12 15:15:48 --> Hooks Class Initialized
DEBUG - 2018-10-12 15:15:48 --> UTF-8 Support Enabled
INFO - 2018-10-12 15:15:48 --> Utf8 Class Initialized
INFO - 2018-10-12 15:15:48 --> URI Class Initialized
INFO - 2018-10-12 15:15:48 --> Router Class Initialized
INFO - 2018-10-12 15:15:48 --> Output Class Initialized
INFO - 2018-10-12 15:15:48 --> Security Class Initialized
DEBUG - 2018-10-12 15:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 15:15:48 --> CSRF cookie sent
INFO - 2018-10-12 15:15:48 --> CSRF token verified
INFO - 2018-10-12 15:15:48 --> Input Class Initialized
INFO - 2018-10-12 15:15:48 --> Language Class Initialized
INFO - 2018-10-12 15:15:48 --> Loader Class Initialized
INFO - 2018-10-12 15:15:48 --> Helper loaded: url_helper
INFO - 2018-10-12 15:15:48 --> Helper loaded: form_helper
INFO - 2018-10-12 15:15:48 --> Helper loaded: language_helper
DEBUG - 2018-10-12 15:15:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 15:15:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 15:15:48 --> User Agent Class Initialized
INFO - 2018-10-12 15:15:48 --> Controller Class Initialized
INFO - 2018-10-12 15:15:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 15:15:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 15:15:48 --> Pixel_Model class loaded
INFO - 2018-10-12 15:15:49 --> Database Driver Class Initialized
INFO - 2018-10-12 15:15:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:15:49 --> Form Validation Class Initialized
INFO - 2018-10-12 15:15:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-12 15:15:49 --> Database Driver Class Initialized
INFO - 2018-10-12 15:15:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:15:49 --> Config Class Initialized
INFO - 2018-10-12 15:15:49 --> Hooks Class Initialized
DEBUG - 2018-10-12 15:15:49 --> UTF-8 Support Enabled
INFO - 2018-10-12 15:15:49 --> Utf8 Class Initialized
INFO - 2018-10-12 15:15:49 --> URI Class Initialized
INFO - 2018-10-12 15:15:49 --> Router Class Initialized
INFO - 2018-10-12 15:15:49 --> Output Class Initialized
INFO - 2018-10-12 15:15:49 --> Security Class Initialized
DEBUG - 2018-10-12 15:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 15:15:49 --> CSRF cookie sent
INFO - 2018-10-12 15:15:49 --> Input Class Initialized
INFO - 2018-10-12 15:15:49 --> Language Class Initialized
INFO - 2018-10-12 15:15:49 --> Loader Class Initialized
INFO - 2018-10-12 15:15:49 --> Helper loaded: url_helper
INFO - 2018-10-12 15:15:49 --> Helper loaded: form_helper
INFO - 2018-10-12 15:15:49 --> Helper loaded: language_helper
DEBUG - 2018-10-12 15:15:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 15:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 15:15:49 --> User Agent Class Initialized
INFO - 2018-10-12 15:15:49 --> Controller Class Initialized
INFO - 2018-10-12 15:15:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 15:15:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 15:15:49 --> Pixel_Model class loaded
INFO - 2018-10-12 15:15:49 --> Database Driver Class Initialized
INFO - 2018-10-12 15:15:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:15:49 --> Database Driver Class Initialized
INFO - 2018-10-12 15:15:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:15:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 15:15:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 15:15:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 15:15:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 15:15:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 15:15:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 15:15:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-10-12 15:15:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 15:15:49 --> Final output sent to browser
DEBUG - 2018-10-12 15:15:49 --> Total execution time: 0.0460
INFO - 2018-10-12 15:15:51 --> Config Class Initialized
INFO - 2018-10-12 15:15:51 --> Hooks Class Initialized
DEBUG - 2018-10-12 15:15:51 --> UTF-8 Support Enabled
INFO - 2018-10-12 15:15:51 --> Utf8 Class Initialized
INFO - 2018-10-12 15:15:51 --> URI Class Initialized
INFO - 2018-10-12 15:15:51 --> Router Class Initialized
INFO - 2018-10-12 15:15:51 --> Output Class Initialized
INFO - 2018-10-12 15:15:51 --> Security Class Initialized
DEBUG - 2018-10-12 15:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 15:15:51 --> CSRF cookie sent
INFO - 2018-10-12 15:15:51 --> CSRF token verified
INFO - 2018-10-12 15:15:51 --> Input Class Initialized
INFO - 2018-10-12 15:15:51 --> Language Class Initialized
INFO - 2018-10-12 15:15:51 --> Loader Class Initialized
INFO - 2018-10-12 15:15:51 --> Helper loaded: url_helper
INFO - 2018-10-12 15:15:51 --> Helper loaded: form_helper
INFO - 2018-10-12 15:15:51 --> Helper loaded: language_helper
DEBUG - 2018-10-12 15:15:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 15:15:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 15:15:51 --> User Agent Class Initialized
INFO - 2018-10-12 15:15:51 --> Controller Class Initialized
INFO - 2018-10-12 15:15:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 15:15:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 15:15:51 --> Pixel_Model class loaded
INFO - 2018-10-12 15:15:51 --> Database Driver Class Initialized
INFO - 2018-10-12 15:15:51 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:15:51 --> Form Validation Class Initialized
INFO - 2018-10-12 15:15:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-12 15:15:51 --> Database Driver Class Initialized
INFO - 2018-10-12 15:15:51 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:15:51 --> Config Class Initialized
INFO - 2018-10-12 15:15:51 --> Hooks Class Initialized
DEBUG - 2018-10-12 15:15:51 --> UTF-8 Support Enabled
INFO - 2018-10-12 15:15:51 --> Utf8 Class Initialized
INFO - 2018-10-12 15:15:51 --> URI Class Initialized
INFO - 2018-10-12 15:15:51 --> Router Class Initialized
INFO - 2018-10-12 15:15:51 --> Output Class Initialized
INFO - 2018-10-12 15:15:51 --> Security Class Initialized
DEBUG - 2018-10-12 15:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 15:15:51 --> CSRF cookie sent
INFO - 2018-10-12 15:15:51 --> Input Class Initialized
INFO - 2018-10-12 15:15:51 --> Language Class Initialized
INFO - 2018-10-12 15:15:51 --> Loader Class Initialized
INFO - 2018-10-12 15:15:51 --> Helper loaded: url_helper
INFO - 2018-10-12 15:15:51 --> Helper loaded: form_helper
INFO - 2018-10-12 15:15:51 --> Helper loaded: language_helper
DEBUG - 2018-10-12 15:15:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 15:15:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 15:15:51 --> User Agent Class Initialized
INFO - 2018-10-12 15:15:51 --> Controller Class Initialized
INFO - 2018-10-12 15:15:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 15:15:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 15:15:51 --> Pixel_Model class loaded
INFO - 2018-10-12 15:15:51 --> Database Driver Class Initialized
INFO - 2018-10-12 15:15:51 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:15:51 --> Database Driver Class Initialized
INFO - 2018-10-12 15:15:51 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:15:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 15:15:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 15:15:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 15:15:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 15:15:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-10-12 15:15:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 15:15:51 --> Final output sent to browser
DEBUG - 2018-10-12 15:15:51 --> Total execution time: 0.0379
INFO - 2018-10-12 15:16:00 --> Config Class Initialized
INFO - 2018-10-12 15:16:00 --> Hooks Class Initialized
DEBUG - 2018-10-12 15:16:00 --> UTF-8 Support Enabled
INFO - 2018-10-12 15:16:00 --> Utf8 Class Initialized
INFO - 2018-10-12 15:16:00 --> URI Class Initialized
INFO - 2018-10-12 15:16:00 --> Router Class Initialized
INFO - 2018-10-12 15:16:00 --> Output Class Initialized
INFO - 2018-10-12 15:16:00 --> Security Class Initialized
DEBUG - 2018-10-12 15:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 15:16:00 --> CSRF cookie sent
INFO - 2018-10-12 15:16:00 --> Input Class Initialized
INFO - 2018-10-12 15:16:00 --> Language Class Initialized
INFO - 2018-10-12 15:16:00 --> Loader Class Initialized
INFO - 2018-10-12 15:16:00 --> Helper loaded: url_helper
INFO - 2018-10-12 15:16:00 --> Helper loaded: form_helper
INFO - 2018-10-12 15:16:00 --> Helper loaded: language_helper
DEBUG - 2018-10-12 15:16:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 15:16:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 15:16:00 --> User Agent Class Initialized
INFO - 2018-10-12 15:16:00 --> Controller Class Initialized
INFO - 2018-10-12 15:16:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 15:16:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 15:16:00 --> Pixel_Model class loaded
INFO - 2018-10-12 15:16:00 --> Database Driver Class Initialized
INFO - 2018-10-12 15:16:00 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:16:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 15:16:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 15:16:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 15:16:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 15:16:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 15:16:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 15:16:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-10-12 15:16:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 15:16:00 --> Final output sent to browser
DEBUG - 2018-10-12 15:16:00 --> Total execution time: 0.0497
INFO - 2018-10-12 15:16:07 --> Config Class Initialized
INFO - 2018-10-12 15:16:07 --> Hooks Class Initialized
DEBUG - 2018-10-12 15:16:07 --> UTF-8 Support Enabled
INFO - 2018-10-12 15:16:07 --> Utf8 Class Initialized
INFO - 2018-10-12 15:16:07 --> URI Class Initialized
INFO - 2018-10-12 15:16:07 --> Router Class Initialized
INFO - 2018-10-12 15:16:07 --> Output Class Initialized
INFO - 2018-10-12 15:16:07 --> Security Class Initialized
DEBUG - 2018-10-12 15:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 15:16:07 --> CSRF cookie sent
INFO - 2018-10-12 15:16:07 --> CSRF token verified
INFO - 2018-10-12 15:16:07 --> Input Class Initialized
INFO - 2018-10-12 15:16:07 --> Language Class Initialized
INFO - 2018-10-12 15:16:07 --> Loader Class Initialized
INFO - 2018-10-12 15:16:07 --> Helper loaded: url_helper
INFO - 2018-10-12 15:16:07 --> Helper loaded: form_helper
INFO - 2018-10-12 15:16:07 --> Helper loaded: language_helper
DEBUG - 2018-10-12 15:16:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 15:16:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 15:16:07 --> User Agent Class Initialized
INFO - 2018-10-12 15:16:07 --> Controller Class Initialized
INFO - 2018-10-12 15:16:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 15:16:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 15:16:07 --> Pixel_Model class loaded
INFO - 2018-10-12 15:16:07 --> Database Driver Class Initialized
INFO - 2018-10-12 15:16:07 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:16:07 --> Database Driver Class Initialized
INFO - 2018-10-12 15:16:07 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:16:07 --> Config Class Initialized
INFO - 2018-10-12 15:16:07 --> Hooks Class Initialized
DEBUG - 2018-10-12 15:16:07 --> UTF-8 Support Enabled
INFO - 2018-10-12 15:16:07 --> Utf8 Class Initialized
INFO - 2018-10-12 15:16:07 --> URI Class Initialized
INFO - 2018-10-12 15:16:07 --> Router Class Initialized
INFO - 2018-10-12 15:16:07 --> Output Class Initialized
INFO - 2018-10-12 15:16:07 --> Security Class Initialized
DEBUG - 2018-10-12 15:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 15:16:07 --> CSRF cookie sent
INFO - 2018-10-12 15:16:07 --> Input Class Initialized
INFO - 2018-10-12 15:16:07 --> Language Class Initialized
INFO - 2018-10-12 15:16:07 --> Loader Class Initialized
INFO - 2018-10-12 15:16:07 --> Helper loaded: url_helper
INFO - 2018-10-12 15:16:07 --> Helper loaded: form_helper
INFO - 2018-10-12 15:16:07 --> Helper loaded: language_helper
DEBUG - 2018-10-12 15:16:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 15:16:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 15:16:07 --> User Agent Class Initialized
INFO - 2018-10-12 15:16:07 --> Controller Class Initialized
INFO - 2018-10-12 15:16:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 15:16:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 15:16:07 --> Pixel_Model class loaded
INFO - 2018-10-12 15:16:07 --> Database Driver Class Initialized
INFO - 2018-10-12 15:16:07 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:16:07 --> Config Class Initialized
INFO - 2018-10-12 15:16:07 --> Hooks Class Initialized
DEBUG - 2018-10-12 15:16:07 --> UTF-8 Support Enabled
INFO - 2018-10-12 15:16:07 --> Utf8 Class Initialized
INFO - 2018-10-12 15:16:07 --> URI Class Initialized
INFO - 2018-10-12 15:16:07 --> Router Class Initialized
INFO - 2018-10-12 15:16:07 --> Output Class Initialized
INFO - 2018-10-12 15:16:07 --> Security Class Initialized
DEBUG - 2018-10-12 15:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 15:16:07 --> CSRF cookie sent
INFO - 2018-10-12 15:16:07 --> Input Class Initialized
INFO - 2018-10-12 15:16:07 --> Language Class Initialized
INFO - 2018-10-12 15:16:07 --> Loader Class Initialized
INFO - 2018-10-12 15:16:07 --> Helper loaded: url_helper
INFO - 2018-10-12 15:16:07 --> Helper loaded: form_helper
INFO - 2018-10-12 15:16:07 --> Helper loaded: language_helper
DEBUG - 2018-10-12 15:16:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 15:16:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 15:16:07 --> User Agent Class Initialized
INFO - 2018-10-12 15:16:07 --> Controller Class Initialized
INFO - 2018-10-12 15:16:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 15:16:07 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-12 15:16:07 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-10-12 15:16:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 15:16:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 15:16:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 15:16:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-10-12 15:16:07 --> Could not find the language line "req_email"
INFO - 2018-10-12 15:16:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-10-12 15:16:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 15:16:07 --> Final output sent to browser
DEBUG - 2018-10-12 15:16:07 --> Total execution time: 0.0247
INFO - 2018-10-12 15:17:23 --> Config Class Initialized
INFO - 2018-10-12 15:17:23 --> Hooks Class Initialized
DEBUG - 2018-10-12 15:17:23 --> UTF-8 Support Enabled
INFO - 2018-10-12 15:17:23 --> Utf8 Class Initialized
INFO - 2018-10-12 15:17:23 --> URI Class Initialized
INFO - 2018-10-12 15:17:23 --> Router Class Initialized
INFO - 2018-10-12 15:17:23 --> Output Class Initialized
INFO - 2018-10-12 15:17:23 --> Security Class Initialized
DEBUG - 2018-10-12 15:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 15:17:23 --> CSRF cookie sent
INFO - 2018-10-12 15:17:23 --> Input Class Initialized
INFO - 2018-10-12 15:17:23 --> Language Class Initialized
INFO - 2018-10-12 15:17:23 --> Loader Class Initialized
INFO - 2018-10-12 15:17:23 --> Helper loaded: url_helper
INFO - 2018-10-12 15:17:23 --> Helper loaded: form_helper
INFO - 2018-10-12 15:17:23 --> Helper loaded: language_helper
DEBUG - 2018-10-12 15:17:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 15:17:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 15:17:23 --> User Agent Class Initialized
INFO - 2018-10-12 15:17:23 --> Controller Class Initialized
INFO - 2018-10-12 15:17:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 15:17:23 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-12 15:17:23 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-10-12 15:17:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 15:17:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 15:17:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 15:17:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-10-12 15:17:23 --> Could not find the language line "req_email"
INFO - 2018-10-12 15:17:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-10-12 15:17:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 15:17:24 --> Final output sent to browser
DEBUG - 2018-10-12 15:17:24 --> Total execution time: 0.0229
INFO - 2018-10-12 15:17:30 --> Config Class Initialized
INFO - 2018-10-12 15:17:30 --> Hooks Class Initialized
DEBUG - 2018-10-12 15:17:30 --> UTF-8 Support Enabled
INFO - 2018-10-12 15:17:30 --> Utf8 Class Initialized
INFO - 2018-10-12 15:17:30 --> URI Class Initialized
INFO - 2018-10-12 15:17:30 --> Router Class Initialized
INFO - 2018-10-12 15:17:30 --> Output Class Initialized
INFO - 2018-10-12 15:17:30 --> Security Class Initialized
DEBUG - 2018-10-12 15:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 15:17:30 --> CSRF cookie sent
INFO - 2018-10-12 15:17:30 --> Input Class Initialized
INFO - 2018-10-12 15:17:30 --> Language Class Initialized
INFO - 2018-10-12 15:17:30 --> Loader Class Initialized
INFO - 2018-10-12 15:17:30 --> Helper loaded: url_helper
INFO - 2018-10-12 15:17:30 --> Helper loaded: form_helper
INFO - 2018-10-12 15:17:30 --> Helper loaded: language_helper
DEBUG - 2018-10-12 15:17:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 15:17:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 15:17:30 --> User Agent Class Initialized
INFO - 2018-10-12 15:17:30 --> Controller Class Initialized
INFO - 2018-10-12 15:17:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 15:17:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 15:17:30 --> Pixel_Model class loaded
INFO - 2018-10-12 15:17:30 --> Database Driver Class Initialized
INFO - 2018-10-12 15:17:30 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:17:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 15:17:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 15:17:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 15:17:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 15:17:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 15:17:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 15:17:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-10-12 15:17:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 15:17:30 --> Final output sent to browser
DEBUG - 2018-10-12 15:17:30 --> Total execution time: 0.0386
INFO - 2018-10-12 15:17:32 --> Config Class Initialized
INFO - 2018-10-12 15:17:32 --> Hooks Class Initialized
DEBUG - 2018-10-12 15:17:32 --> UTF-8 Support Enabled
INFO - 2018-10-12 15:17:32 --> Utf8 Class Initialized
INFO - 2018-10-12 15:17:32 --> URI Class Initialized
INFO - 2018-10-12 15:17:32 --> Router Class Initialized
INFO - 2018-10-12 15:17:32 --> Output Class Initialized
INFO - 2018-10-12 15:17:32 --> Security Class Initialized
DEBUG - 2018-10-12 15:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 15:17:32 --> CSRF cookie sent
INFO - 2018-10-12 15:17:32 --> CSRF token verified
INFO - 2018-10-12 15:17:32 --> Input Class Initialized
INFO - 2018-10-12 15:17:32 --> Language Class Initialized
INFO - 2018-10-12 15:17:32 --> Loader Class Initialized
INFO - 2018-10-12 15:17:32 --> Helper loaded: url_helper
INFO - 2018-10-12 15:17:32 --> Helper loaded: form_helper
INFO - 2018-10-12 15:17:32 --> Helper loaded: language_helper
DEBUG - 2018-10-12 15:17:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 15:17:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 15:17:32 --> User Agent Class Initialized
INFO - 2018-10-12 15:17:32 --> Controller Class Initialized
INFO - 2018-10-12 15:17:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 15:17:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 15:17:32 --> Pixel_Model class loaded
INFO - 2018-10-12 15:17:32 --> Database Driver Class Initialized
INFO - 2018-10-12 15:17:32 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:17:32 --> Database Driver Class Initialized
INFO - 2018-10-12 15:17:32 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:17:32 --> Config Class Initialized
INFO - 2018-10-12 15:17:32 --> Hooks Class Initialized
DEBUG - 2018-10-12 15:17:32 --> UTF-8 Support Enabled
INFO - 2018-10-12 15:17:32 --> Utf8 Class Initialized
INFO - 2018-10-12 15:17:32 --> URI Class Initialized
INFO - 2018-10-12 15:17:32 --> Router Class Initialized
INFO - 2018-10-12 15:17:32 --> Output Class Initialized
INFO - 2018-10-12 15:17:32 --> Security Class Initialized
DEBUG - 2018-10-12 15:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 15:17:32 --> CSRF cookie sent
INFO - 2018-10-12 15:17:32 --> Input Class Initialized
INFO - 2018-10-12 15:17:32 --> Language Class Initialized
INFO - 2018-10-12 15:17:32 --> Loader Class Initialized
INFO - 2018-10-12 15:17:32 --> Helper loaded: url_helper
INFO - 2018-10-12 15:17:32 --> Helper loaded: form_helper
INFO - 2018-10-12 15:17:32 --> Helper loaded: language_helper
DEBUG - 2018-10-12 15:17:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 15:17:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 15:17:32 --> User Agent Class Initialized
INFO - 2018-10-12 15:17:32 --> Controller Class Initialized
INFO - 2018-10-12 15:17:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 15:17:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 15:17:32 --> Pixel_Model class loaded
INFO - 2018-10-12 15:17:32 --> Database Driver Class Initialized
INFO - 2018-10-12 15:17:32 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:17:33 --> Config Class Initialized
INFO - 2018-10-12 15:17:33 --> Hooks Class Initialized
DEBUG - 2018-10-12 15:17:33 --> UTF-8 Support Enabled
INFO - 2018-10-12 15:17:33 --> Utf8 Class Initialized
INFO - 2018-10-12 15:17:33 --> URI Class Initialized
INFO - 2018-10-12 15:17:33 --> Router Class Initialized
INFO - 2018-10-12 15:17:33 --> Output Class Initialized
INFO - 2018-10-12 15:17:33 --> Security Class Initialized
DEBUG - 2018-10-12 15:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 15:17:33 --> CSRF cookie sent
INFO - 2018-10-12 15:17:33 --> Input Class Initialized
INFO - 2018-10-12 15:17:33 --> Language Class Initialized
INFO - 2018-10-12 15:17:33 --> Loader Class Initialized
INFO - 2018-10-12 15:17:33 --> Helper loaded: url_helper
INFO - 2018-10-12 15:17:33 --> Helper loaded: form_helper
INFO - 2018-10-12 15:17:33 --> Helper loaded: language_helper
DEBUG - 2018-10-12 15:17:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 15:17:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 15:17:33 --> User Agent Class Initialized
INFO - 2018-10-12 15:17:33 --> Controller Class Initialized
INFO - 2018-10-12 15:17:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 15:17:33 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-12 15:17:33 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-10-12 15:17:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 15:17:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 15:17:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 15:17:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-10-12 15:17:33 --> Could not find the language line "req_email"
INFO - 2018-10-12 15:17:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-10-12 15:17:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 15:17:33 --> Final output sent to browser
DEBUG - 2018-10-12 15:17:33 --> Total execution time: 0.0262
INFO - 2018-10-12 15:19:10 --> Config Class Initialized
INFO - 2018-10-12 15:19:10 --> Hooks Class Initialized
DEBUG - 2018-10-12 15:19:10 --> UTF-8 Support Enabled
INFO - 2018-10-12 15:19:10 --> Utf8 Class Initialized
INFO - 2018-10-12 15:19:10 --> URI Class Initialized
DEBUG - 2018-10-12 15:19:10 --> No URI present. Default controller set.
INFO - 2018-10-12 15:19:10 --> Router Class Initialized
INFO - 2018-10-12 15:19:10 --> Output Class Initialized
INFO - 2018-10-12 15:19:10 --> Security Class Initialized
DEBUG - 2018-10-12 15:19:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 15:19:10 --> CSRF cookie sent
INFO - 2018-10-12 15:19:10 --> Input Class Initialized
INFO - 2018-10-12 15:19:10 --> Language Class Initialized
INFO - 2018-10-12 15:19:10 --> Loader Class Initialized
INFO - 2018-10-12 15:19:10 --> Helper loaded: url_helper
INFO - 2018-10-12 15:19:10 --> Helper loaded: form_helper
INFO - 2018-10-12 15:19:10 --> Helper loaded: language_helper
DEBUG - 2018-10-12 15:19:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 15:19:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 15:19:10 --> User Agent Class Initialized
INFO - 2018-10-12 15:19:10 --> Controller Class Initialized
INFO - 2018-10-12 15:19:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 15:19:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 15:19:10 --> Pixel_Model class loaded
INFO - 2018-10-12 15:19:10 --> Database Driver Class Initialized
INFO - 2018-10-12 15:19:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:19:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 15:19:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 15:19:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-12 15:19:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 15:19:10 --> Final output sent to browser
DEBUG - 2018-10-12 15:19:10 --> Total execution time: 0.0352
INFO - 2018-10-12 15:19:13 --> Config Class Initialized
INFO - 2018-10-12 15:19:13 --> Hooks Class Initialized
DEBUG - 2018-10-12 15:19:13 --> UTF-8 Support Enabled
INFO - 2018-10-12 15:19:13 --> Utf8 Class Initialized
INFO - 2018-10-12 15:19:13 --> URI Class Initialized
INFO - 2018-10-12 15:19:13 --> Router Class Initialized
INFO - 2018-10-12 15:19:13 --> Output Class Initialized
INFO - 2018-10-12 15:19:13 --> Security Class Initialized
DEBUG - 2018-10-12 15:19:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 15:19:13 --> CSRF cookie sent
INFO - 2018-10-12 15:19:13 --> Input Class Initialized
INFO - 2018-10-12 15:19:13 --> Language Class Initialized
INFO - 2018-10-12 15:19:13 --> Loader Class Initialized
INFO - 2018-10-12 15:19:13 --> Helper loaded: url_helper
INFO - 2018-10-12 15:19:13 --> Helper loaded: form_helper
INFO - 2018-10-12 15:19:13 --> Helper loaded: language_helper
DEBUG - 2018-10-12 15:19:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 15:19:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 15:19:13 --> User Agent Class Initialized
INFO - 2018-10-12 15:19:13 --> Controller Class Initialized
INFO - 2018-10-12 15:19:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 15:19:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 15:19:13 --> Pixel_Model class loaded
INFO - 2018-10-12 15:19:13 --> Database Driver Class Initialized
INFO - 2018-10-12 15:19:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:19:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 15:19:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 15:19:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 15:19:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 15:19:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 15:19:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 15:19:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-10-12 15:19:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 15:19:13 --> Final output sent to browser
DEBUG - 2018-10-12 15:19:13 --> Total execution time: 0.0390
INFO - 2018-10-12 15:19:17 --> Config Class Initialized
INFO - 2018-10-12 15:19:17 --> Hooks Class Initialized
DEBUG - 2018-10-12 15:19:17 --> UTF-8 Support Enabled
INFO - 2018-10-12 15:19:17 --> Utf8 Class Initialized
INFO - 2018-10-12 15:19:17 --> URI Class Initialized
INFO - 2018-10-12 15:19:17 --> Router Class Initialized
INFO - 2018-10-12 15:19:17 --> Output Class Initialized
INFO - 2018-10-12 15:19:17 --> Security Class Initialized
DEBUG - 2018-10-12 15:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 15:19:17 --> CSRF cookie sent
INFO - 2018-10-12 15:19:17 --> CSRF token verified
INFO - 2018-10-12 15:19:17 --> Input Class Initialized
INFO - 2018-10-12 15:19:17 --> Language Class Initialized
INFO - 2018-10-12 15:19:17 --> Loader Class Initialized
INFO - 2018-10-12 15:19:17 --> Helper loaded: url_helper
INFO - 2018-10-12 15:19:17 --> Helper loaded: form_helper
INFO - 2018-10-12 15:19:17 --> Helper loaded: language_helper
DEBUG - 2018-10-12 15:19:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 15:19:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 15:19:17 --> User Agent Class Initialized
INFO - 2018-10-12 15:19:17 --> Controller Class Initialized
INFO - 2018-10-12 15:19:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 15:19:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 15:19:17 --> Pixel_Model class loaded
INFO - 2018-10-12 15:19:17 --> Database Driver Class Initialized
INFO - 2018-10-12 15:19:17 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:19:17 --> Database Driver Class Initialized
INFO - 2018-10-12 15:19:17 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:19:17 --> Config Class Initialized
INFO - 2018-10-12 15:19:17 --> Hooks Class Initialized
DEBUG - 2018-10-12 15:19:17 --> UTF-8 Support Enabled
INFO - 2018-10-12 15:19:17 --> Utf8 Class Initialized
INFO - 2018-10-12 15:19:17 --> URI Class Initialized
INFO - 2018-10-12 15:19:17 --> Router Class Initialized
INFO - 2018-10-12 15:19:17 --> Output Class Initialized
INFO - 2018-10-12 15:19:17 --> Security Class Initialized
DEBUG - 2018-10-12 15:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 15:19:17 --> CSRF cookie sent
INFO - 2018-10-12 15:19:17 --> Input Class Initialized
INFO - 2018-10-12 15:19:17 --> Language Class Initialized
INFO - 2018-10-12 15:19:17 --> Loader Class Initialized
INFO - 2018-10-12 15:19:17 --> Helper loaded: url_helper
INFO - 2018-10-12 15:19:17 --> Helper loaded: form_helper
INFO - 2018-10-12 15:19:17 --> Helper loaded: language_helper
DEBUG - 2018-10-12 15:19:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 15:19:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 15:19:17 --> User Agent Class Initialized
INFO - 2018-10-12 15:19:17 --> Controller Class Initialized
INFO - 2018-10-12 15:19:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 15:19:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 15:19:17 --> Pixel_Model class loaded
INFO - 2018-10-12 15:19:17 --> Database Driver Class Initialized
INFO - 2018-10-12 15:19:17 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:19:17 --> Database Driver Class Initialized
INFO - 2018-10-12 15:19:17 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:19:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 15:19:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 15:19:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 15:19:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 15:19:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 15:19:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 15:19:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-12 15:19:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 15:19:17 --> Final output sent to browser
DEBUG - 2018-10-12 15:19:17 --> Total execution time: 0.0500
INFO - 2018-10-12 15:19:23 --> Config Class Initialized
INFO - 2018-10-12 15:19:23 --> Hooks Class Initialized
DEBUG - 2018-10-12 15:19:23 --> UTF-8 Support Enabled
INFO - 2018-10-12 15:19:23 --> Utf8 Class Initialized
INFO - 2018-10-12 15:19:23 --> URI Class Initialized
INFO - 2018-10-12 15:19:23 --> Router Class Initialized
INFO - 2018-10-12 15:19:23 --> Output Class Initialized
INFO - 2018-10-12 15:19:23 --> Security Class Initialized
DEBUG - 2018-10-12 15:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 15:19:23 --> CSRF cookie sent
INFO - 2018-10-12 15:19:23 --> CSRF token verified
INFO - 2018-10-12 15:19:23 --> Input Class Initialized
INFO - 2018-10-12 15:19:23 --> Language Class Initialized
INFO - 2018-10-12 15:19:23 --> Loader Class Initialized
INFO - 2018-10-12 15:19:23 --> Helper loaded: url_helper
INFO - 2018-10-12 15:19:23 --> Helper loaded: form_helper
INFO - 2018-10-12 15:19:23 --> Helper loaded: language_helper
DEBUG - 2018-10-12 15:19:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 15:19:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 15:19:23 --> User Agent Class Initialized
INFO - 2018-10-12 15:19:23 --> Controller Class Initialized
INFO - 2018-10-12 15:19:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 15:19:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 15:19:23 --> Pixel_Model class loaded
INFO - 2018-10-12 15:19:23 --> Database Driver Class Initialized
INFO - 2018-10-12 15:19:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:19:23 --> Form Validation Class Initialized
INFO - 2018-10-12 15:19:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-12 15:19:23 --> Database Driver Class Initialized
INFO - 2018-10-12 15:19:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:19:23 --> Config Class Initialized
INFO - 2018-10-12 15:19:23 --> Hooks Class Initialized
DEBUG - 2018-10-12 15:19:23 --> UTF-8 Support Enabled
INFO - 2018-10-12 15:19:23 --> Utf8 Class Initialized
INFO - 2018-10-12 15:19:23 --> URI Class Initialized
INFO - 2018-10-12 15:19:23 --> Router Class Initialized
INFO - 2018-10-12 15:19:23 --> Output Class Initialized
INFO - 2018-10-12 15:19:23 --> Security Class Initialized
DEBUG - 2018-10-12 15:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 15:19:23 --> CSRF cookie sent
INFO - 2018-10-12 15:19:23 --> Input Class Initialized
INFO - 2018-10-12 15:19:23 --> Language Class Initialized
INFO - 2018-10-12 15:19:23 --> Loader Class Initialized
INFO - 2018-10-12 15:19:23 --> Helper loaded: url_helper
INFO - 2018-10-12 15:19:23 --> Helper loaded: form_helper
INFO - 2018-10-12 15:19:23 --> Helper loaded: language_helper
DEBUG - 2018-10-12 15:19:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 15:19:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 15:19:23 --> User Agent Class Initialized
INFO - 2018-10-12 15:19:23 --> Controller Class Initialized
INFO - 2018-10-12 15:19:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 15:19:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 15:19:23 --> Pixel_Model class loaded
INFO - 2018-10-12 15:19:23 --> Database Driver Class Initialized
INFO - 2018-10-12 15:19:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:19:23 --> Database Driver Class Initialized
INFO - 2018-10-12 15:19:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:19:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 15:19:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 15:19:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 15:19:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 15:19:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 15:19:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 15:19:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-10-12 15:19:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 15:19:23 --> Final output sent to browser
DEBUG - 2018-10-12 15:19:23 --> Total execution time: 0.0591
INFO - 2018-10-12 15:19:24 --> Config Class Initialized
INFO - 2018-10-12 15:19:24 --> Hooks Class Initialized
DEBUG - 2018-10-12 15:19:24 --> UTF-8 Support Enabled
INFO - 2018-10-12 15:19:24 --> Utf8 Class Initialized
INFO - 2018-10-12 15:19:24 --> URI Class Initialized
INFO - 2018-10-12 15:19:24 --> Router Class Initialized
INFO - 2018-10-12 15:19:24 --> Output Class Initialized
INFO - 2018-10-12 15:19:24 --> Security Class Initialized
DEBUG - 2018-10-12 15:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 15:19:24 --> CSRF cookie sent
INFO - 2018-10-12 15:19:24 --> CSRF token verified
INFO - 2018-10-12 15:19:24 --> Input Class Initialized
INFO - 2018-10-12 15:19:24 --> Language Class Initialized
INFO - 2018-10-12 15:19:24 --> Loader Class Initialized
INFO - 2018-10-12 15:19:24 --> Helper loaded: url_helper
INFO - 2018-10-12 15:19:24 --> Helper loaded: form_helper
INFO - 2018-10-12 15:19:24 --> Helper loaded: language_helper
DEBUG - 2018-10-12 15:19:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 15:19:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 15:19:24 --> User Agent Class Initialized
INFO - 2018-10-12 15:19:24 --> Controller Class Initialized
INFO - 2018-10-12 15:19:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 15:19:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 15:19:24 --> Pixel_Model class loaded
INFO - 2018-10-12 15:19:24 --> Database Driver Class Initialized
INFO - 2018-10-12 15:19:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:19:24 --> Form Validation Class Initialized
INFO - 2018-10-12 15:19:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-12 15:19:24 --> Database Driver Class Initialized
INFO - 2018-10-12 15:19:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:19:25 --> Config Class Initialized
INFO - 2018-10-12 15:19:25 --> Hooks Class Initialized
DEBUG - 2018-10-12 15:19:25 --> UTF-8 Support Enabled
INFO - 2018-10-12 15:19:25 --> Utf8 Class Initialized
INFO - 2018-10-12 15:19:25 --> URI Class Initialized
INFO - 2018-10-12 15:19:25 --> Router Class Initialized
INFO - 2018-10-12 15:19:25 --> Output Class Initialized
INFO - 2018-10-12 15:19:25 --> Security Class Initialized
DEBUG - 2018-10-12 15:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 15:19:25 --> CSRF cookie sent
INFO - 2018-10-12 15:19:25 --> Input Class Initialized
INFO - 2018-10-12 15:19:25 --> Language Class Initialized
INFO - 2018-10-12 15:19:25 --> Loader Class Initialized
INFO - 2018-10-12 15:19:25 --> Helper loaded: url_helper
INFO - 2018-10-12 15:19:25 --> Helper loaded: form_helper
INFO - 2018-10-12 15:19:25 --> Helper loaded: language_helper
DEBUG - 2018-10-12 15:19:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 15:19:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 15:19:25 --> User Agent Class Initialized
INFO - 2018-10-12 15:19:25 --> Controller Class Initialized
INFO - 2018-10-12 15:19:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 15:19:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 15:19:25 --> Pixel_Model class loaded
INFO - 2018-10-12 15:19:25 --> Database Driver Class Initialized
INFO - 2018-10-12 15:19:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:19:25 --> Database Driver Class Initialized
INFO - 2018-10-12 15:19:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:19:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 15:19:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 15:19:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-10-12 15:19:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 15:19:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 15:19:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 15:19:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 15:19:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-10-12 15:19:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 15:19:25 --> Final output sent to browser
DEBUG - 2018-10-12 15:19:25 --> Total execution time: 0.0482
INFO - 2018-10-12 15:19:26 --> Config Class Initialized
INFO - 2018-10-12 15:19:26 --> Hooks Class Initialized
DEBUG - 2018-10-12 15:19:26 --> UTF-8 Support Enabled
INFO - 2018-10-12 15:19:26 --> Utf8 Class Initialized
INFO - 2018-10-12 15:19:26 --> URI Class Initialized
INFO - 2018-10-12 15:19:26 --> Router Class Initialized
INFO - 2018-10-12 15:19:26 --> Output Class Initialized
INFO - 2018-10-12 15:19:26 --> Security Class Initialized
DEBUG - 2018-10-12 15:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 15:19:26 --> CSRF cookie sent
INFO - 2018-10-12 15:19:26 --> CSRF token verified
INFO - 2018-10-12 15:19:26 --> Input Class Initialized
INFO - 2018-10-12 15:19:26 --> Language Class Initialized
INFO - 2018-10-12 15:19:26 --> Loader Class Initialized
INFO - 2018-10-12 15:19:26 --> Helper loaded: url_helper
INFO - 2018-10-12 15:19:26 --> Helper loaded: form_helper
INFO - 2018-10-12 15:19:26 --> Helper loaded: language_helper
DEBUG - 2018-10-12 15:19:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 15:19:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 15:19:26 --> User Agent Class Initialized
INFO - 2018-10-12 15:19:26 --> Controller Class Initialized
INFO - 2018-10-12 15:19:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 15:19:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 15:19:26 --> Pixel_Model class loaded
INFO - 2018-10-12 15:19:26 --> Database Driver Class Initialized
INFO - 2018-10-12 15:19:26 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:19:26 --> Form Validation Class Initialized
INFO - 2018-10-12 15:19:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-12 15:19:26 --> Database Driver Class Initialized
INFO - 2018-10-12 15:19:26 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:19:26 --> Config Class Initialized
INFO - 2018-10-12 15:19:26 --> Hooks Class Initialized
DEBUG - 2018-10-12 15:19:26 --> UTF-8 Support Enabled
INFO - 2018-10-12 15:19:26 --> Utf8 Class Initialized
INFO - 2018-10-12 15:19:26 --> URI Class Initialized
INFO - 2018-10-12 15:19:26 --> Router Class Initialized
INFO - 2018-10-12 15:19:26 --> Output Class Initialized
INFO - 2018-10-12 15:19:26 --> Security Class Initialized
DEBUG - 2018-10-12 15:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 15:19:26 --> CSRF cookie sent
INFO - 2018-10-12 15:19:26 --> Input Class Initialized
INFO - 2018-10-12 15:19:26 --> Language Class Initialized
INFO - 2018-10-12 15:19:26 --> Loader Class Initialized
INFO - 2018-10-12 15:19:26 --> Helper loaded: url_helper
INFO - 2018-10-12 15:19:26 --> Helper loaded: form_helper
INFO - 2018-10-12 15:19:26 --> Helper loaded: language_helper
DEBUG - 2018-10-12 15:19:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 15:19:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 15:19:26 --> User Agent Class Initialized
INFO - 2018-10-12 15:19:26 --> Controller Class Initialized
INFO - 2018-10-12 15:19:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 15:19:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 15:19:26 --> Pixel_Model class loaded
INFO - 2018-10-12 15:19:26 --> Database Driver Class Initialized
INFO - 2018-10-12 15:19:26 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:19:26 --> Database Driver Class Initialized
INFO - 2018-10-12 15:19:26 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:19:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 15:19:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 15:19:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 15:19:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 15:19:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 15:19:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 15:19:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-12 15:19:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 15:19:26 --> Final output sent to browser
DEBUG - 2018-10-12 15:19:26 --> Total execution time: 0.0412
INFO - 2018-10-12 15:19:30 --> Config Class Initialized
INFO - 2018-10-12 15:19:30 --> Hooks Class Initialized
DEBUG - 2018-10-12 15:19:30 --> UTF-8 Support Enabled
INFO - 2018-10-12 15:19:30 --> Utf8 Class Initialized
INFO - 2018-10-12 15:19:30 --> URI Class Initialized
INFO - 2018-10-12 15:19:30 --> Router Class Initialized
INFO - 2018-10-12 15:19:30 --> Output Class Initialized
INFO - 2018-10-12 15:19:30 --> Security Class Initialized
DEBUG - 2018-10-12 15:19:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 15:19:30 --> CSRF cookie sent
INFO - 2018-10-12 15:19:30 --> CSRF token verified
INFO - 2018-10-12 15:19:30 --> Input Class Initialized
INFO - 2018-10-12 15:19:30 --> Language Class Initialized
INFO - 2018-10-12 15:19:30 --> Loader Class Initialized
INFO - 2018-10-12 15:19:30 --> Helper loaded: url_helper
INFO - 2018-10-12 15:19:30 --> Helper loaded: form_helper
INFO - 2018-10-12 15:19:30 --> Helper loaded: language_helper
DEBUG - 2018-10-12 15:19:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 15:19:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 15:19:30 --> User Agent Class Initialized
INFO - 2018-10-12 15:19:30 --> Controller Class Initialized
INFO - 2018-10-12 15:19:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 15:19:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 15:19:30 --> Pixel_Model class loaded
INFO - 2018-10-12 15:19:30 --> Database Driver Class Initialized
INFO - 2018-10-12 15:19:30 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:19:30 --> Form Validation Class Initialized
INFO - 2018-10-12 15:19:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-12 15:19:30 --> Database Driver Class Initialized
INFO - 2018-10-12 15:19:30 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:19:30 --> Config Class Initialized
INFO - 2018-10-12 15:19:30 --> Hooks Class Initialized
DEBUG - 2018-10-12 15:19:30 --> UTF-8 Support Enabled
INFO - 2018-10-12 15:19:30 --> Utf8 Class Initialized
INFO - 2018-10-12 15:19:30 --> URI Class Initialized
INFO - 2018-10-12 15:19:30 --> Router Class Initialized
INFO - 2018-10-12 15:19:30 --> Output Class Initialized
INFO - 2018-10-12 15:19:30 --> Security Class Initialized
DEBUG - 2018-10-12 15:19:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 15:19:30 --> CSRF cookie sent
INFO - 2018-10-12 15:19:30 --> Input Class Initialized
INFO - 2018-10-12 15:19:30 --> Language Class Initialized
INFO - 2018-10-12 15:19:30 --> Loader Class Initialized
INFO - 2018-10-12 15:19:30 --> Helper loaded: url_helper
INFO - 2018-10-12 15:19:30 --> Helper loaded: form_helper
INFO - 2018-10-12 15:19:30 --> Helper loaded: language_helper
DEBUG - 2018-10-12 15:19:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 15:19:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 15:19:30 --> User Agent Class Initialized
INFO - 2018-10-12 15:19:30 --> Controller Class Initialized
INFO - 2018-10-12 15:19:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 15:19:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 15:19:30 --> Pixel_Model class loaded
INFO - 2018-10-12 15:19:31 --> Database Driver Class Initialized
INFO - 2018-10-12 15:19:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:19:31 --> Database Driver Class Initialized
INFO - 2018-10-12 15:19:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:19:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 15:19:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 15:19:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 15:19:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 15:19:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 15:19:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 15:19:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-10-12 15:19:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 15:19:31 --> Final output sent to browser
DEBUG - 2018-10-12 15:19:31 --> Total execution time: 0.0451
INFO - 2018-10-12 15:19:35 --> Config Class Initialized
INFO - 2018-10-12 15:19:35 --> Hooks Class Initialized
DEBUG - 2018-10-12 15:19:35 --> UTF-8 Support Enabled
INFO - 2018-10-12 15:19:35 --> Utf8 Class Initialized
INFO - 2018-10-12 15:19:35 --> URI Class Initialized
INFO - 2018-10-12 15:19:35 --> Router Class Initialized
INFO - 2018-10-12 15:19:35 --> Output Class Initialized
INFO - 2018-10-12 15:19:35 --> Security Class Initialized
DEBUG - 2018-10-12 15:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 15:19:35 --> CSRF cookie sent
INFO - 2018-10-12 15:19:35 --> CSRF token verified
INFO - 2018-10-12 15:19:35 --> Input Class Initialized
INFO - 2018-10-12 15:19:35 --> Language Class Initialized
INFO - 2018-10-12 15:19:35 --> Loader Class Initialized
INFO - 2018-10-12 15:19:35 --> Helper loaded: url_helper
INFO - 2018-10-12 15:19:35 --> Helper loaded: form_helper
INFO - 2018-10-12 15:19:35 --> Helper loaded: language_helper
DEBUG - 2018-10-12 15:19:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 15:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 15:19:35 --> User Agent Class Initialized
INFO - 2018-10-12 15:19:35 --> Controller Class Initialized
INFO - 2018-10-12 15:19:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 15:19:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 15:19:35 --> Pixel_Model class loaded
INFO - 2018-10-12 15:19:35 --> Database Driver Class Initialized
INFO - 2018-10-12 15:19:35 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:19:35 --> Form Validation Class Initialized
INFO - 2018-10-12 15:19:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-12 15:19:35 --> Database Driver Class Initialized
INFO - 2018-10-12 15:19:35 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:19:35 --> Config Class Initialized
INFO - 2018-10-12 15:19:35 --> Hooks Class Initialized
DEBUG - 2018-10-12 15:19:35 --> UTF-8 Support Enabled
INFO - 2018-10-12 15:19:35 --> Utf8 Class Initialized
INFO - 2018-10-12 15:19:35 --> URI Class Initialized
INFO - 2018-10-12 15:19:35 --> Router Class Initialized
INFO - 2018-10-12 15:19:35 --> Output Class Initialized
INFO - 2018-10-12 15:19:35 --> Security Class Initialized
DEBUG - 2018-10-12 15:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 15:19:35 --> CSRF cookie sent
INFO - 2018-10-12 15:19:35 --> Input Class Initialized
INFO - 2018-10-12 15:19:35 --> Language Class Initialized
INFO - 2018-10-12 15:19:35 --> Loader Class Initialized
INFO - 2018-10-12 15:19:35 --> Helper loaded: url_helper
INFO - 2018-10-12 15:19:35 --> Helper loaded: form_helper
INFO - 2018-10-12 15:19:35 --> Helper loaded: language_helper
DEBUG - 2018-10-12 15:19:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 15:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 15:19:35 --> User Agent Class Initialized
INFO - 2018-10-12 15:19:35 --> Controller Class Initialized
INFO - 2018-10-12 15:19:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 15:19:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 15:19:35 --> Pixel_Model class loaded
INFO - 2018-10-12 15:19:35 --> Database Driver Class Initialized
INFO - 2018-10-12 15:19:35 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:19:35 --> Database Driver Class Initialized
INFO - 2018-10-12 15:19:35 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:19:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 15:19:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 15:19:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 15:19:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 15:19:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 15:19:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 15:19:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_title.php
INFO - 2018-10-12 15:19:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 15:19:35 --> Final output sent to browser
DEBUG - 2018-10-12 15:19:35 --> Total execution time: 0.0418
INFO - 2018-10-12 15:19:38 --> Config Class Initialized
INFO - 2018-10-12 15:19:38 --> Hooks Class Initialized
DEBUG - 2018-10-12 15:19:38 --> UTF-8 Support Enabled
INFO - 2018-10-12 15:19:38 --> Utf8 Class Initialized
INFO - 2018-10-12 15:19:38 --> URI Class Initialized
INFO - 2018-10-12 15:19:38 --> Router Class Initialized
INFO - 2018-10-12 15:19:38 --> Output Class Initialized
INFO - 2018-10-12 15:19:38 --> Security Class Initialized
DEBUG - 2018-10-12 15:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 15:19:38 --> CSRF cookie sent
INFO - 2018-10-12 15:19:38 --> CSRF token verified
INFO - 2018-10-12 15:19:38 --> Input Class Initialized
INFO - 2018-10-12 15:19:38 --> Language Class Initialized
INFO - 2018-10-12 15:19:38 --> Loader Class Initialized
INFO - 2018-10-12 15:19:38 --> Helper loaded: url_helper
INFO - 2018-10-12 15:19:38 --> Helper loaded: form_helper
INFO - 2018-10-12 15:19:38 --> Helper loaded: language_helper
DEBUG - 2018-10-12 15:19:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 15:19:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 15:19:38 --> User Agent Class Initialized
INFO - 2018-10-12 15:19:38 --> Controller Class Initialized
INFO - 2018-10-12 15:19:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 15:19:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 15:19:38 --> Pixel_Model class loaded
INFO - 2018-10-12 15:19:38 --> Database Driver Class Initialized
INFO - 2018-10-12 15:19:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:19:38 --> Form Validation Class Initialized
INFO - 2018-10-12 15:19:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-12 15:19:38 --> Database Driver Class Initialized
INFO - 2018-10-12 15:19:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:19:38 --> Config Class Initialized
INFO - 2018-10-12 15:19:38 --> Hooks Class Initialized
DEBUG - 2018-10-12 15:19:38 --> UTF-8 Support Enabled
INFO - 2018-10-12 15:19:38 --> Utf8 Class Initialized
INFO - 2018-10-12 15:19:38 --> URI Class Initialized
INFO - 2018-10-12 15:19:38 --> Router Class Initialized
INFO - 2018-10-12 15:19:38 --> Output Class Initialized
INFO - 2018-10-12 15:19:38 --> Security Class Initialized
DEBUG - 2018-10-12 15:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 15:19:38 --> CSRF cookie sent
INFO - 2018-10-12 15:19:38 --> Input Class Initialized
INFO - 2018-10-12 15:19:38 --> Language Class Initialized
INFO - 2018-10-12 15:19:38 --> Loader Class Initialized
INFO - 2018-10-12 15:19:38 --> Helper loaded: url_helper
INFO - 2018-10-12 15:19:38 --> Helper loaded: form_helper
INFO - 2018-10-12 15:19:38 --> Helper loaded: language_helper
DEBUG - 2018-10-12 15:19:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 15:19:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 15:19:38 --> User Agent Class Initialized
INFO - 2018-10-12 15:19:38 --> Controller Class Initialized
INFO - 2018-10-12 15:19:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 15:19:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 15:19:38 --> Pixel_Model class loaded
INFO - 2018-10-12 15:19:38 --> Database Driver Class Initialized
INFO - 2018-10-12 15:19:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:19:38 --> Database Driver Class Initialized
INFO - 2018-10-12 15:19:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:19:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 15:19:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 15:19:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 15:19:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 15:19:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 15:19:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 15:19:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-10-12 15:19:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 15:19:38 --> Final output sent to browser
DEBUG - 2018-10-12 15:19:38 --> Total execution time: 0.0456
INFO - 2018-10-12 15:19:40 --> Config Class Initialized
INFO - 2018-10-12 15:19:40 --> Hooks Class Initialized
DEBUG - 2018-10-12 15:19:40 --> UTF-8 Support Enabled
INFO - 2018-10-12 15:19:40 --> Utf8 Class Initialized
INFO - 2018-10-12 15:19:40 --> URI Class Initialized
INFO - 2018-10-12 15:19:40 --> Router Class Initialized
INFO - 2018-10-12 15:19:40 --> Output Class Initialized
INFO - 2018-10-12 15:19:40 --> Security Class Initialized
DEBUG - 2018-10-12 15:19:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 15:19:40 --> CSRF cookie sent
INFO - 2018-10-12 15:19:40 --> CSRF token verified
INFO - 2018-10-12 15:19:40 --> Input Class Initialized
INFO - 2018-10-12 15:19:40 --> Language Class Initialized
INFO - 2018-10-12 15:19:40 --> Loader Class Initialized
INFO - 2018-10-12 15:19:40 --> Helper loaded: url_helper
INFO - 2018-10-12 15:19:40 --> Helper loaded: form_helper
INFO - 2018-10-12 15:19:40 --> Helper loaded: language_helper
DEBUG - 2018-10-12 15:19:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 15:19:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 15:19:40 --> User Agent Class Initialized
INFO - 2018-10-12 15:19:40 --> Controller Class Initialized
INFO - 2018-10-12 15:19:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 15:19:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 15:19:40 --> Pixel_Model class loaded
INFO - 2018-10-12 15:19:40 --> Database Driver Class Initialized
INFO - 2018-10-12 15:19:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:19:40 --> Form Validation Class Initialized
INFO - 2018-10-12 15:19:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-12 15:19:40 --> Database Driver Class Initialized
INFO - 2018-10-12 15:19:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:19:40 --> Config Class Initialized
INFO - 2018-10-12 15:19:40 --> Hooks Class Initialized
DEBUG - 2018-10-12 15:19:40 --> UTF-8 Support Enabled
INFO - 2018-10-12 15:19:40 --> Utf8 Class Initialized
INFO - 2018-10-12 15:19:40 --> URI Class Initialized
INFO - 2018-10-12 15:19:40 --> Router Class Initialized
INFO - 2018-10-12 15:19:40 --> Output Class Initialized
INFO - 2018-10-12 15:19:40 --> Security Class Initialized
DEBUG - 2018-10-12 15:19:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 15:19:40 --> CSRF cookie sent
INFO - 2018-10-12 15:19:40 --> Input Class Initialized
INFO - 2018-10-12 15:19:40 --> Language Class Initialized
INFO - 2018-10-12 15:19:40 --> Loader Class Initialized
INFO - 2018-10-12 15:19:40 --> Helper loaded: url_helper
INFO - 2018-10-12 15:19:40 --> Helper loaded: form_helper
INFO - 2018-10-12 15:19:40 --> Helper loaded: language_helper
DEBUG - 2018-10-12 15:19:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 15:19:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 15:19:40 --> User Agent Class Initialized
INFO - 2018-10-12 15:19:40 --> Controller Class Initialized
INFO - 2018-10-12 15:19:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 15:19:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 15:19:40 --> Pixel_Model class loaded
INFO - 2018-10-12 15:19:40 --> Database Driver Class Initialized
INFO - 2018-10-12 15:19:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:19:40 --> Database Driver Class Initialized
INFO - 2018-10-12 15:19:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:19:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 15:19:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 15:19:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 15:19:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 15:19:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-10-12 15:19:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 15:19:40 --> Final output sent to browser
DEBUG - 2018-10-12 15:19:40 --> Total execution time: 0.0598
INFO - 2018-10-12 15:19:47 --> Config Class Initialized
INFO - 2018-10-12 15:19:47 --> Hooks Class Initialized
DEBUG - 2018-10-12 15:19:47 --> UTF-8 Support Enabled
INFO - 2018-10-12 15:19:47 --> Utf8 Class Initialized
INFO - 2018-10-12 15:19:47 --> URI Class Initialized
INFO - 2018-10-12 15:19:47 --> Router Class Initialized
INFO - 2018-10-12 15:19:47 --> Output Class Initialized
INFO - 2018-10-12 15:19:47 --> Security Class Initialized
DEBUG - 2018-10-12 15:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 15:19:47 --> CSRF cookie sent
INFO - 2018-10-12 15:19:47 --> Input Class Initialized
INFO - 2018-10-12 15:19:47 --> Language Class Initialized
INFO - 2018-10-12 15:19:47 --> Loader Class Initialized
INFO - 2018-10-12 15:19:47 --> Helper loaded: url_helper
INFO - 2018-10-12 15:19:47 --> Helper loaded: form_helper
INFO - 2018-10-12 15:19:47 --> Helper loaded: language_helper
DEBUG - 2018-10-12 15:19:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 15:19:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 15:19:47 --> User Agent Class Initialized
INFO - 2018-10-12 15:19:47 --> Controller Class Initialized
INFO - 2018-10-12 15:19:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 15:19:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 15:19:47 --> Pixel_Model class loaded
INFO - 2018-10-12 15:19:47 --> Database Driver Class Initialized
INFO - 2018-10-12 15:19:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:19:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 15:19:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 15:19:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 15:19:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 15:19:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 15:19:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 15:19:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-10-12 15:19:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 15:19:47 --> Final output sent to browser
DEBUG - 2018-10-12 15:19:47 --> Total execution time: 0.0377
INFO - 2018-10-12 15:19:50 --> Config Class Initialized
INFO - 2018-10-12 15:19:50 --> Hooks Class Initialized
DEBUG - 2018-10-12 15:19:50 --> UTF-8 Support Enabled
INFO - 2018-10-12 15:19:50 --> Utf8 Class Initialized
INFO - 2018-10-12 15:19:50 --> URI Class Initialized
INFO - 2018-10-12 15:19:50 --> Router Class Initialized
INFO - 2018-10-12 15:19:50 --> Output Class Initialized
INFO - 2018-10-12 15:19:50 --> Security Class Initialized
DEBUG - 2018-10-12 15:19:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 15:19:50 --> CSRF cookie sent
INFO - 2018-10-12 15:19:50 --> CSRF token verified
INFO - 2018-10-12 15:19:50 --> Input Class Initialized
INFO - 2018-10-12 15:19:50 --> Language Class Initialized
INFO - 2018-10-12 15:19:50 --> Loader Class Initialized
INFO - 2018-10-12 15:19:50 --> Helper loaded: url_helper
INFO - 2018-10-12 15:19:50 --> Helper loaded: form_helper
INFO - 2018-10-12 15:19:50 --> Helper loaded: language_helper
DEBUG - 2018-10-12 15:19:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 15:19:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 15:19:50 --> User Agent Class Initialized
INFO - 2018-10-12 15:19:50 --> Controller Class Initialized
INFO - 2018-10-12 15:19:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 15:19:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 15:19:50 --> Pixel_Model class loaded
INFO - 2018-10-12 15:19:50 --> Database Driver Class Initialized
INFO - 2018-10-12 15:19:50 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:19:50 --> Database Driver Class Initialized
INFO - 2018-10-12 15:19:50 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:19:50 --> Config Class Initialized
INFO - 2018-10-12 15:19:50 --> Hooks Class Initialized
DEBUG - 2018-10-12 15:19:50 --> UTF-8 Support Enabled
INFO - 2018-10-12 15:19:50 --> Utf8 Class Initialized
INFO - 2018-10-12 15:19:50 --> URI Class Initialized
INFO - 2018-10-12 15:19:50 --> Router Class Initialized
INFO - 2018-10-12 15:19:50 --> Output Class Initialized
INFO - 2018-10-12 15:19:50 --> Security Class Initialized
DEBUG - 2018-10-12 15:19:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 15:19:50 --> CSRF cookie sent
INFO - 2018-10-12 15:19:50 --> Input Class Initialized
INFO - 2018-10-12 15:19:50 --> Language Class Initialized
INFO - 2018-10-12 15:19:50 --> Loader Class Initialized
INFO - 2018-10-12 15:19:50 --> Helper loaded: url_helper
INFO - 2018-10-12 15:19:50 --> Helper loaded: form_helper
INFO - 2018-10-12 15:19:50 --> Helper loaded: language_helper
DEBUG - 2018-10-12 15:19:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 15:19:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 15:19:50 --> User Agent Class Initialized
INFO - 2018-10-12 15:19:50 --> Controller Class Initialized
INFO - 2018-10-12 15:19:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 15:19:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 15:19:50 --> Pixel_Model class loaded
INFO - 2018-10-12 15:19:50 --> Database Driver Class Initialized
INFO - 2018-10-12 15:19:50 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 15:19:51 --> Config Class Initialized
INFO - 2018-10-12 15:19:51 --> Hooks Class Initialized
DEBUG - 2018-10-12 15:19:51 --> UTF-8 Support Enabled
INFO - 2018-10-12 15:19:51 --> Utf8 Class Initialized
INFO - 2018-10-12 15:19:51 --> URI Class Initialized
INFO - 2018-10-12 15:19:51 --> Router Class Initialized
INFO - 2018-10-12 15:19:51 --> Output Class Initialized
INFO - 2018-10-12 15:19:51 --> Security Class Initialized
DEBUG - 2018-10-12 15:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 15:19:51 --> CSRF cookie sent
INFO - 2018-10-12 15:19:51 --> Input Class Initialized
INFO - 2018-10-12 15:19:51 --> Language Class Initialized
INFO - 2018-10-12 15:19:51 --> Loader Class Initialized
INFO - 2018-10-12 15:19:51 --> Helper loaded: url_helper
INFO - 2018-10-12 15:19:51 --> Helper loaded: form_helper
INFO - 2018-10-12 15:19:51 --> Helper loaded: language_helper
DEBUG - 2018-10-12 15:19:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 15:19:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 15:19:51 --> User Agent Class Initialized
INFO - 2018-10-12 15:19:51 --> Controller Class Initialized
INFO - 2018-10-12 15:19:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 15:19:51 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-12 15:19:51 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-10-12 15:19:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 15:19:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 15:19:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 15:19:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-10-12 15:19:51 --> Could not find the language line "req_email"
INFO - 2018-10-12 15:19:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-10-12 15:19:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 15:19:51 --> Final output sent to browser
DEBUG - 2018-10-12 15:19:51 --> Total execution time: 0.0206
INFO - 2018-10-12 17:21:23 --> Config Class Initialized
INFO - 2018-10-12 17:21:23 --> Hooks Class Initialized
DEBUG - 2018-10-12 17:21:23 --> UTF-8 Support Enabled
INFO - 2018-10-12 17:21:23 --> Utf8 Class Initialized
INFO - 2018-10-12 17:21:23 --> URI Class Initialized
DEBUG - 2018-10-12 17:21:23 --> No URI present. Default controller set.
INFO - 2018-10-12 17:21:23 --> Router Class Initialized
INFO - 2018-10-12 17:21:23 --> Output Class Initialized
INFO - 2018-10-12 17:21:23 --> Security Class Initialized
DEBUG - 2018-10-12 17:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 17:21:23 --> CSRF cookie sent
INFO - 2018-10-12 17:21:23 --> Input Class Initialized
INFO - 2018-10-12 17:21:23 --> Language Class Initialized
INFO - 2018-10-12 17:21:23 --> Loader Class Initialized
INFO - 2018-10-12 17:21:23 --> Helper loaded: url_helper
INFO - 2018-10-12 17:21:23 --> Helper loaded: form_helper
INFO - 2018-10-12 17:21:23 --> Helper loaded: language_helper
DEBUG - 2018-10-12 17:21:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 17:21:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 17:21:23 --> User Agent Class Initialized
INFO - 2018-10-12 17:21:23 --> Controller Class Initialized
INFO - 2018-10-12 17:21:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 17:21:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 17:21:23 --> Pixel_Model class loaded
INFO - 2018-10-12 17:21:23 --> Database Driver Class Initialized
INFO - 2018-10-12 17:21:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:21:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 17:21:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 17:21:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-12 17:21:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 17:21:23 --> Final output sent to browser
DEBUG - 2018-10-12 17:21:23 --> Total execution time: 0.0361
INFO - 2018-10-12 17:21:26 --> Config Class Initialized
INFO - 2018-10-12 17:21:26 --> Hooks Class Initialized
DEBUG - 2018-10-12 17:21:26 --> UTF-8 Support Enabled
INFO - 2018-10-12 17:21:26 --> Utf8 Class Initialized
INFO - 2018-10-12 17:21:26 --> URI Class Initialized
INFO - 2018-10-12 17:21:26 --> Router Class Initialized
INFO - 2018-10-12 17:21:26 --> Output Class Initialized
INFO - 2018-10-12 17:21:26 --> Security Class Initialized
DEBUG - 2018-10-12 17:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 17:21:26 --> CSRF cookie sent
INFO - 2018-10-12 17:21:26 --> Input Class Initialized
INFO - 2018-10-12 17:21:26 --> Language Class Initialized
INFO - 2018-10-12 17:21:26 --> Loader Class Initialized
INFO - 2018-10-12 17:21:26 --> Helper loaded: url_helper
INFO - 2018-10-12 17:21:26 --> Helper loaded: form_helper
INFO - 2018-10-12 17:21:26 --> Helper loaded: language_helper
DEBUG - 2018-10-12 17:21:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 17:21:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 17:21:26 --> User Agent Class Initialized
INFO - 2018-10-12 17:21:26 --> Controller Class Initialized
INFO - 2018-10-12 17:21:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 17:21:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 17:21:26 --> Pixel_Model class loaded
INFO - 2018-10-12 17:21:26 --> Database Driver Class Initialized
INFO - 2018-10-12 17:21:26 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:21:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 17:21:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 17:21:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 17:21:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 17:21:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 17:21:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 17:21:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-10-12 17:21:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 17:21:26 --> Final output sent to browser
DEBUG - 2018-10-12 17:21:26 --> Total execution time: 0.0391
INFO - 2018-10-12 17:21:29 --> Config Class Initialized
INFO - 2018-10-12 17:21:29 --> Hooks Class Initialized
DEBUG - 2018-10-12 17:21:29 --> UTF-8 Support Enabled
INFO - 2018-10-12 17:21:29 --> Utf8 Class Initialized
INFO - 2018-10-12 17:21:29 --> URI Class Initialized
INFO - 2018-10-12 17:21:29 --> Router Class Initialized
INFO - 2018-10-12 17:21:29 --> Output Class Initialized
INFO - 2018-10-12 17:21:29 --> Security Class Initialized
DEBUG - 2018-10-12 17:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 17:21:29 --> CSRF cookie sent
INFO - 2018-10-12 17:21:29 --> CSRF token verified
INFO - 2018-10-12 17:21:29 --> Input Class Initialized
INFO - 2018-10-12 17:21:29 --> Language Class Initialized
INFO - 2018-10-12 17:21:29 --> Loader Class Initialized
INFO - 2018-10-12 17:21:29 --> Helper loaded: url_helper
INFO - 2018-10-12 17:21:29 --> Helper loaded: form_helper
INFO - 2018-10-12 17:21:29 --> Helper loaded: language_helper
DEBUG - 2018-10-12 17:21:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 17:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 17:21:29 --> User Agent Class Initialized
INFO - 2018-10-12 17:21:29 --> Controller Class Initialized
INFO - 2018-10-12 17:21:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 17:21:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 17:21:29 --> Pixel_Model class loaded
INFO - 2018-10-12 17:21:29 --> Database Driver Class Initialized
INFO - 2018-10-12 17:21:29 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:21:29 --> Database Driver Class Initialized
INFO - 2018-10-12 17:21:29 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:21:29 --> Config Class Initialized
INFO - 2018-10-12 17:21:29 --> Hooks Class Initialized
DEBUG - 2018-10-12 17:21:29 --> UTF-8 Support Enabled
INFO - 2018-10-12 17:21:29 --> Utf8 Class Initialized
INFO - 2018-10-12 17:21:29 --> URI Class Initialized
INFO - 2018-10-12 17:21:29 --> Router Class Initialized
INFO - 2018-10-12 17:21:29 --> Output Class Initialized
INFO - 2018-10-12 17:21:29 --> Security Class Initialized
DEBUG - 2018-10-12 17:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 17:21:29 --> CSRF cookie sent
INFO - 2018-10-12 17:21:29 --> Input Class Initialized
INFO - 2018-10-12 17:21:29 --> Language Class Initialized
INFO - 2018-10-12 17:21:29 --> Loader Class Initialized
INFO - 2018-10-12 17:21:29 --> Helper loaded: url_helper
INFO - 2018-10-12 17:21:29 --> Helper loaded: form_helper
INFO - 2018-10-12 17:21:29 --> Helper loaded: language_helper
DEBUG - 2018-10-12 17:21:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 17:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 17:21:29 --> User Agent Class Initialized
INFO - 2018-10-12 17:21:29 --> Controller Class Initialized
INFO - 2018-10-12 17:21:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 17:21:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 17:21:29 --> Pixel_Model class loaded
INFO - 2018-10-12 17:21:29 --> Database Driver Class Initialized
INFO - 2018-10-12 17:21:29 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:21:29 --> Database Driver Class Initialized
INFO - 2018-10-12 17:21:29 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:21:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 17:21:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 17:21:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 17:21:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 17:21:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 17:21:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 17:21:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-12 17:21:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 17:21:29 --> Final output sent to browser
DEBUG - 2018-10-12 17:21:29 --> Total execution time: 0.0507
INFO - 2018-10-12 17:21:33 --> Config Class Initialized
INFO - 2018-10-12 17:21:34 --> Hooks Class Initialized
DEBUG - 2018-10-12 17:21:34 --> UTF-8 Support Enabled
INFO - 2018-10-12 17:21:34 --> Utf8 Class Initialized
INFO - 2018-10-12 17:21:34 --> URI Class Initialized
INFO - 2018-10-12 17:21:34 --> Router Class Initialized
INFO - 2018-10-12 17:21:34 --> Output Class Initialized
INFO - 2018-10-12 17:21:34 --> Security Class Initialized
DEBUG - 2018-10-12 17:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 17:21:34 --> CSRF cookie sent
INFO - 2018-10-12 17:21:34 --> CSRF token verified
INFO - 2018-10-12 17:21:34 --> Input Class Initialized
INFO - 2018-10-12 17:21:34 --> Language Class Initialized
INFO - 2018-10-12 17:21:34 --> Loader Class Initialized
INFO - 2018-10-12 17:21:34 --> Helper loaded: url_helper
INFO - 2018-10-12 17:21:34 --> Helper loaded: form_helper
INFO - 2018-10-12 17:21:34 --> Helper loaded: language_helper
DEBUG - 2018-10-12 17:21:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 17:21:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 17:21:34 --> User Agent Class Initialized
INFO - 2018-10-12 17:21:34 --> Controller Class Initialized
INFO - 2018-10-12 17:21:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 17:21:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 17:21:34 --> Pixel_Model class loaded
INFO - 2018-10-12 17:21:34 --> Database Driver Class Initialized
INFO - 2018-10-12 17:21:34 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:21:34 --> Form Validation Class Initialized
INFO - 2018-10-12 17:21:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-12 17:21:34 --> Database Driver Class Initialized
INFO - 2018-10-12 17:21:34 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:21:34 --> Config Class Initialized
INFO - 2018-10-12 17:21:34 --> Hooks Class Initialized
DEBUG - 2018-10-12 17:21:34 --> UTF-8 Support Enabled
INFO - 2018-10-12 17:21:34 --> Utf8 Class Initialized
INFO - 2018-10-12 17:21:34 --> URI Class Initialized
INFO - 2018-10-12 17:21:34 --> Router Class Initialized
INFO - 2018-10-12 17:21:34 --> Output Class Initialized
INFO - 2018-10-12 17:21:34 --> Security Class Initialized
DEBUG - 2018-10-12 17:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 17:21:34 --> CSRF cookie sent
INFO - 2018-10-12 17:21:34 --> Input Class Initialized
INFO - 2018-10-12 17:21:34 --> Language Class Initialized
INFO - 2018-10-12 17:21:34 --> Loader Class Initialized
INFO - 2018-10-12 17:21:34 --> Helper loaded: url_helper
INFO - 2018-10-12 17:21:34 --> Helper loaded: form_helper
INFO - 2018-10-12 17:21:34 --> Helper loaded: language_helper
DEBUG - 2018-10-12 17:21:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 17:21:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 17:21:34 --> User Agent Class Initialized
INFO - 2018-10-12 17:21:34 --> Controller Class Initialized
INFO - 2018-10-12 17:21:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 17:21:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 17:21:34 --> Pixel_Model class loaded
INFO - 2018-10-12 17:21:34 --> Database Driver Class Initialized
INFO - 2018-10-12 17:21:34 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:21:34 --> Database Driver Class Initialized
INFO - 2018-10-12 17:21:34 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:21:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 17:21:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 17:21:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 17:21:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 17:21:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 17:21:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 17:21:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-10-12 17:21:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 17:21:34 --> Final output sent to browser
DEBUG - 2018-10-12 17:21:34 --> Total execution time: 0.0509
INFO - 2018-10-12 17:21:35 --> Config Class Initialized
INFO - 2018-10-12 17:21:35 --> Hooks Class Initialized
DEBUG - 2018-10-12 17:21:35 --> UTF-8 Support Enabled
INFO - 2018-10-12 17:21:35 --> Utf8 Class Initialized
INFO - 2018-10-12 17:21:35 --> URI Class Initialized
INFO - 2018-10-12 17:21:35 --> Router Class Initialized
INFO - 2018-10-12 17:21:35 --> Output Class Initialized
INFO - 2018-10-12 17:21:35 --> Security Class Initialized
DEBUG - 2018-10-12 17:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 17:21:35 --> CSRF cookie sent
INFO - 2018-10-12 17:21:35 --> CSRF token verified
INFO - 2018-10-12 17:21:35 --> Input Class Initialized
INFO - 2018-10-12 17:21:35 --> Language Class Initialized
INFO - 2018-10-12 17:21:35 --> Loader Class Initialized
INFO - 2018-10-12 17:21:35 --> Helper loaded: url_helper
INFO - 2018-10-12 17:21:35 --> Helper loaded: form_helper
INFO - 2018-10-12 17:21:35 --> Helper loaded: language_helper
DEBUG - 2018-10-12 17:21:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 17:21:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 17:21:35 --> User Agent Class Initialized
INFO - 2018-10-12 17:21:35 --> Controller Class Initialized
INFO - 2018-10-12 17:21:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 17:21:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 17:21:35 --> Pixel_Model class loaded
INFO - 2018-10-12 17:21:35 --> Database Driver Class Initialized
INFO - 2018-10-12 17:21:35 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:21:35 --> Form Validation Class Initialized
INFO - 2018-10-12 17:21:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-12 17:21:35 --> Database Driver Class Initialized
INFO - 2018-10-12 17:21:35 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:21:35 --> Config Class Initialized
INFO - 2018-10-12 17:21:35 --> Hooks Class Initialized
DEBUG - 2018-10-12 17:21:35 --> UTF-8 Support Enabled
INFO - 2018-10-12 17:21:35 --> Utf8 Class Initialized
INFO - 2018-10-12 17:21:35 --> URI Class Initialized
INFO - 2018-10-12 17:21:35 --> Router Class Initialized
INFO - 2018-10-12 17:21:35 --> Output Class Initialized
INFO - 2018-10-12 17:21:35 --> Security Class Initialized
DEBUG - 2018-10-12 17:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 17:21:35 --> CSRF cookie sent
INFO - 2018-10-12 17:21:35 --> Input Class Initialized
INFO - 2018-10-12 17:21:35 --> Language Class Initialized
INFO - 2018-10-12 17:21:35 --> Loader Class Initialized
INFO - 2018-10-12 17:21:35 --> Helper loaded: url_helper
INFO - 2018-10-12 17:21:35 --> Helper loaded: form_helper
INFO - 2018-10-12 17:21:35 --> Helper loaded: language_helper
DEBUG - 2018-10-12 17:21:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 17:21:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 17:21:35 --> User Agent Class Initialized
INFO - 2018-10-12 17:21:35 --> Controller Class Initialized
INFO - 2018-10-12 17:21:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 17:21:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 17:21:35 --> Pixel_Model class loaded
INFO - 2018-10-12 17:21:35 --> Database Driver Class Initialized
INFO - 2018-10-12 17:21:35 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:21:35 --> Database Driver Class Initialized
INFO - 2018-10-12 17:21:35 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:21:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 17:21:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 17:21:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-10-12 17:21:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 17:21:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 17:21:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 17:21:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 17:21:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-10-12 17:21:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 17:21:35 --> Final output sent to browser
DEBUG - 2018-10-12 17:21:35 --> Total execution time: 0.0414
INFO - 2018-10-12 17:21:36 --> Config Class Initialized
INFO - 2018-10-12 17:21:36 --> Hooks Class Initialized
DEBUG - 2018-10-12 17:21:36 --> UTF-8 Support Enabled
INFO - 2018-10-12 17:21:36 --> Utf8 Class Initialized
INFO - 2018-10-12 17:21:36 --> URI Class Initialized
INFO - 2018-10-12 17:21:36 --> Router Class Initialized
INFO - 2018-10-12 17:21:36 --> Output Class Initialized
INFO - 2018-10-12 17:21:36 --> Security Class Initialized
DEBUG - 2018-10-12 17:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 17:21:36 --> CSRF cookie sent
INFO - 2018-10-12 17:21:36 --> CSRF token verified
INFO - 2018-10-12 17:21:36 --> Input Class Initialized
INFO - 2018-10-12 17:21:36 --> Language Class Initialized
INFO - 2018-10-12 17:21:36 --> Loader Class Initialized
INFO - 2018-10-12 17:21:36 --> Helper loaded: url_helper
INFO - 2018-10-12 17:21:36 --> Helper loaded: form_helper
INFO - 2018-10-12 17:21:36 --> Helper loaded: language_helper
DEBUG - 2018-10-12 17:21:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 17:21:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 17:21:36 --> User Agent Class Initialized
INFO - 2018-10-12 17:21:36 --> Controller Class Initialized
INFO - 2018-10-12 17:21:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 17:21:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 17:21:36 --> Pixel_Model class loaded
INFO - 2018-10-12 17:21:36 --> Database Driver Class Initialized
INFO - 2018-10-12 17:21:36 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:21:36 --> Form Validation Class Initialized
INFO - 2018-10-12 17:21:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-12 17:21:36 --> Database Driver Class Initialized
INFO - 2018-10-12 17:21:36 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:21:37 --> Config Class Initialized
INFO - 2018-10-12 17:21:37 --> Hooks Class Initialized
DEBUG - 2018-10-12 17:21:37 --> UTF-8 Support Enabled
INFO - 2018-10-12 17:21:37 --> Utf8 Class Initialized
INFO - 2018-10-12 17:21:37 --> URI Class Initialized
INFO - 2018-10-12 17:21:37 --> Router Class Initialized
INFO - 2018-10-12 17:21:37 --> Output Class Initialized
INFO - 2018-10-12 17:21:37 --> Security Class Initialized
DEBUG - 2018-10-12 17:21:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 17:21:37 --> CSRF cookie sent
INFO - 2018-10-12 17:21:37 --> Input Class Initialized
INFO - 2018-10-12 17:21:37 --> Language Class Initialized
INFO - 2018-10-12 17:21:37 --> Loader Class Initialized
INFO - 2018-10-12 17:21:37 --> Helper loaded: url_helper
INFO - 2018-10-12 17:21:37 --> Helper loaded: form_helper
INFO - 2018-10-12 17:21:37 --> Helper loaded: language_helper
DEBUG - 2018-10-12 17:21:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 17:21:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 17:21:37 --> User Agent Class Initialized
INFO - 2018-10-12 17:21:37 --> Controller Class Initialized
INFO - 2018-10-12 17:21:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 17:21:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 17:21:37 --> Pixel_Model class loaded
INFO - 2018-10-12 17:21:37 --> Database Driver Class Initialized
INFO - 2018-10-12 17:21:37 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:21:37 --> Database Driver Class Initialized
INFO - 2018-10-12 17:21:37 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:21:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 17:21:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 17:21:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 17:21:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 17:21:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 17:21:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 17:21:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-12 17:21:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 17:21:37 --> Final output sent to browser
DEBUG - 2018-10-12 17:21:37 --> Total execution time: 0.0353
INFO - 2018-10-12 17:21:45 --> Config Class Initialized
INFO - 2018-10-12 17:21:45 --> Hooks Class Initialized
DEBUG - 2018-10-12 17:21:45 --> UTF-8 Support Enabled
INFO - 2018-10-12 17:21:45 --> Utf8 Class Initialized
INFO - 2018-10-12 17:21:45 --> URI Class Initialized
INFO - 2018-10-12 17:21:45 --> Router Class Initialized
INFO - 2018-10-12 17:21:45 --> Output Class Initialized
INFO - 2018-10-12 17:21:45 --> Security Class Initialized
DEBUG - 2018-10-12 17:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 17:21:45 --> CSRF cookie sent
INFO - 2018-10-12 17:21:45 --> CSRF token verified
INFO - 2018-10-12 17:21:45 --> Input Class Initialized
INFO - 2018-10-12 17:21:45 --> Language Class Initialized
INFO - 2018-10-12 17:21:45 --> Loader Class Initialized
INFO - 2018-10-12 17:21:45 --> Helper loaded: url_helper
INFO - 2018-10-12 17:21:45 --> Helper loaded: form_helper
INFO - 2018-10-12 17:21:45 --> Helper loaded: language_helper
DEBUG - 2018-10-12 17:21:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 17:21:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 17:21:45 --> User Agent Class Initialized
INFO - 2018-10-12 17:21:45 --> Controller Class Initialized
INFO - 2018-10-12 17:21:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 17:21:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 17:21:45 --> Pixel_Model class loaded
INFO - 2018-10-12 17:21:45 --> Database Driver Class Initialized
INFO - 2018-10-12 17:21:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:21:45 --> Form Validation Class Initialized
INFO - 2018-10-12 17:21:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-12 17:21:45 --> Database Driver Class Initialized
INFO - 2018-10-12 17:21:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:21:46 --> Config Class Initialized
INFO - 2018-10-12 17:21:46 --> Hooks Class Initialized
DEBUG - 2018-10-12 17:21:46 --> UTF-8 Support Enabled
INFO - 2018-10-12 17:21:46 --> Utf8 Class Initialized
INFO - 2018-10-12 17:21:46 --> URI Class Initialized
INFO - 2018-10-12 17:21:46 --> Router Class Initialized
INFO - 2018-10-12 17:21:46 --> Output Class Initialized
INFO - 2018-10-12 17:21:46 --> Security Class Initialized
DEBUG - 2018-10-12 17:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 17:21:46 --> CSRF cookie sent
INFO - 2018-10-12 17:21:46 --> Input Class Initialized
INFO - 2018-10-12 17:21:46 --> Language Class Initialized
INFO - 2018-10-12 17:21:46 --> Loader Class Initialized
INFO - 2018-10-12 17:21:46 --> Helper loaded: url_helper
INFO - 2018-10-12 17:21:46 --> Helper loaded: form_helper
INFO - 2018-10-12 17:21:46 --> Helper loaded: language_helper
DEBUG - 2018-10-12 17:21:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 17:21:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 17:21:46 --> User Agent Class Initialized
INFO - 2018-10-12 17:21:46 --> Controller Class Initialized
INFO - 2018-10-12 17:21:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 17:21:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 17:21:46 --> Pixel_Model class loaded
INFO - 2018-10-12 17:21:46 --> Database Driver Class Initialized
INFO - 2018-10-12 17:21:46 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:21:46 --> Database Driver Class Initialized
INFO - 2018-10-12 17:21:46 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:21:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 17:21:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 17:21:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 17:21:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 17:21:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 17:21:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 17:21:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-10-12 17:21:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 17:21:46 --> Final output sent to browser
DEBUG - 2018-10-12 17:21:46 --> Total execution time: 0.0427
INFO - 2018-10-12 17:21:51 --> Config Class Initialized
INFO - 2018-10-12 17:21:51 --> Hooks Class Initialized
DEBUG - 2018-10-12 17:21:51 --> UTF-8 Support Enabled
INFO - 2018-10-12 17:21:51 --> Utf8 Class Initialized
INFO - 2018-10-12 17:21:51 --> URI Class Initialized
INFO - 2018-10-12 17:21:51 --> Router Class Initialized
INFO - 2018-10-12 17:21:51 --> Output Class Initialized
INFO - 2018-10-12 17:21:51 --> Security Class Initialized
DEBUG - 2018-10-12 17:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 17:21:51 --> CSRF cookie sent
INFO - 2018-10-12 17:21:51 --> CSRF token verified
INFO - 2018-10-12 17:21:51 --> Input Class Initialized
INFO - 2018-10-12 17:21:51 --> Language Class Initialized
INFO - 2018-10-12 17:21:51 --> Loader Class Initialized
INFO - 2018-10-12 17:21:51 --> Helper loaded: url_helper
INFO - 2018-10-12 17:21:51 --> Helper loaded: form_helper
INFO - 2018-10-12 17:21:51 --> Helper loaded: language_helper
DEBUG - 2018-10-12 17:21:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 17:21:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 17:21:51 --> User Agent Class Initialized
INFO - 2018-10-12 17:21:51 --> Controller Class Initialized
INFO - 2018-10-12 17:21:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 17:21:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 17:21:51 --> Pixel_Model class loaded
INFO - 2018-10-12 17:21:51 --> Database Driver Class Initialized
INFO - 2018-10-12 17:21:51 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:21:51 --> Form Validation Class Initialized
INFO - 2018-10-12 17:21:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-12 17:21:51 --> Database Driver Class Initialized
INFO - 2018-10-12 17:21:51 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:21:51 --> Config Class Initialized
INFO - 2018-10-12 17:21:51 --> Hooks Class Initialized
DEBUG - 2018-10-12 17:21:51 --> UTF-8 Support Enabled
INFO - 2018-10-12 17:21:51 --> Utf8 Class Initialized
INFO - 2018-10-12 17:21:51 --> URI Class Initialized
INFO - 2018-10-12 17:21:51 --> Router Class Initialized
INFO - 2018-10-12 17:21:51 --> Output Class Initialized
INFO - 2018-10-12 17:21:51 --> Security Class Initialized
DEBUG - 2018-10-12 17:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 17:21:51 --> CSRF cookie sent
INFO - 2018-10-12 17:21:51 --> Input Class Initialized
INFO - 2018-10-12 17:21:51 --> Language Class Initialized
INFO - 2018-10-12 17:21:51 --> Loader Class Initialized
INFO - 2018-10-12 17:21:51 --> Helper loaded: url_helper
INFO - 2018-10-12 17:21:51 --> Helper loaded: form_helper
INFO - 2018-10-12 17:21:51 --> Helper loaded: language_helper
DEBUG - 2018-10-12 17:21:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 17:21:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 17:21:51 --> User Agent Class Initialized
INFO - 2018-10-12 17:21:51 --> Controller Class Initialized
INFO - 2018-10-12 17:21:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 17:21:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 17:21:51 --> Pixel_Model class loaded
INFO - 2018-10-12 17:21:51 --> Database Driver Class Initialized
INFO - 2018-10-12 17:21:51 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:21:51 --> Database Driver Class Initialized
INFO - 2018-10-12 17:21:51 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:21:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 17:21:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 17:21:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 17:21:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 17:21:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 17:21:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 17:21:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_title.php
INFO - 2018-10-12 17:21:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 17:21:51 --> Final output sent to browser
DEBUG - 2018-10-12 17:21:51 --> Total execution time: 0.0465
INFO - 2018-10-12 17:21:53 --> Config Class Initialized
INFO - 2018-10-12 17:21:53 --> Hooks Class Initialized
DEBUG - 2018-10-12 17:21:53 --> UTF-8 Support Enabled
INFO - 2018-10-12 17:21:53 --> Utf8 Class Initialized
INFO - 2018-10-12 17:21:53 --> URI Class Initialized
INFO - 2018-10-12 17:21:53 --> Router Class Initialized
INFO - 2018-10-12 17:21:53 --> Output Class Initialized
INFO - 2018-10-12 17:21:53 --> Security Class Initialized
DEBUG - 2018-10-12 17:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 17:21:53 --> CSRF cookie sent
INFO - 2018-10-12 17:21:53 --> CSRF token verified
INFO - 2018-10-12 17:21:53 --> Input Class Initialized
INFO - 2018-10-12 17:21:53 --> Language Class Initialized
INFO - 2018-10-12 17:21:53 --> Loader Class Initialized
INFO - 2018-10-12 17:21:53 --> Helper loaded: url_helper
INFO - 2018-10-12 17:21:53 --> Helper loaded: form_helper
INFO - 2018-10-12 17:21:53 --> Helper loaded: language_helper
DEBUG - 2018-10-12 17:21:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 17:21:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 17:21:53 --> User Agent Class Initialized
INFO - 2018-10-12 17:21:53 --> Controller Class Initialized
INFO - 2018-10-12 17:21:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 17:21:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 17:21:53 --> Pixel_Model class loaded
INFO - 2018-10-12 17:21:53 --> Database Driver Class Initialized
INFO - 2018-10-12 17:21:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:21:53 --> Form Validation Class Initialized
INFO - 2018-10-12 17:21:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-12 17:21:53 --> Database Driver Class Initialized
INFO - 2018-10-12 17:21:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:21:53 --> Config Class Initialized
INFO - 2018-10-12 17:21:53 --> Hooks Class Initialized
DEBUG - 2018-10-12 17:21:53 --> UTF-8 Support Enabled
INFO - 2018-10-12 17:21:53 --> Utf8 Class Initialized
INFO - 2018-10-12 17:21:53 --> URI Class Initialized
INFO - 2018-10-12 17:21:53 --> Router Class Initialized
INFO - 2018-10-12 17:21:53 --> Output Class Initialized
INFO - 2018-10-12 17:21:53 --> Security Class Initialized
DEBUG - 2018-10-12 17:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 17:21:53 --> CSRF cookie sent
INFO - 2018-10-12 17:21:53 --> Input Class Initialized
INFO - 2018-10-12 17:21:53 --> Language Class Initialized
INFO - 2018-10-12 17:21:53 --> Loader Class Initialized
INFO - 2018-10-12 17:21:53 --> Helper loaded: url_helper
INFO - 2018-10-12 17:21:53 --> Helper loaded: form_helper
INFO - 2018-10-12 17:21:53 --> Helper loaded: language_helper
DEBUG - 2018-10-12 17:21:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 17:21:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 17:21:53 --> User Agent Class Initialized
INFO - 2018-10-12 17:21:53 --> Controller Class Initialized
INFO - 2018-10-12 17:21:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 17:21:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 17:21:53 --> Pixel_Model class loaded
INFO - 2018-10-12 17:21:53 --> Database Driver Class Initialized
INFO - 2018-10-12 17:21:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:21:53 --> Database Driver Class Initialized
INFO - 2018-10-12 17:21:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:21:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 17:21:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 17:21:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 17:21:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 17:21:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 17:21:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 17:21:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-10-12 17:21:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 17:21:53 --> Final output sent to browser
DEBUG - 2018-10-12 17:21:53 --> Total execution time: 0.0622
INFO - 2018-10-12 17:21:55 --> Config Class Initialized
INFO - 2018-10-12 17:21:55 --> Hooks Class Initialized
DEBUG - 2018-10-12 17:21:55 --> UTF-8 Support Enabled
INFO - 2018-10-12 17:21:55 --> Utf8 Class Initialized
INFO - 2018-10-12 17:21:55 --> URI Class Initialized
INFO - 2018-10-12 17:21:55 --> Router Class Initialized
INFO - 2018-10-12 17:21:55 --> Output Class Initialized
INFO - 2018-10-12 17:21:55 --> Security Class Initialized
DEBUG - 2018-10-12 17:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 17:21:55 --> CSRF cookie sent
INFO - 2018-10-12 17:21:55 --> CSRF token verified
INFO - 2018-10-12 17:21:55 --> Input Class Initialized
INFO - 2018-10-12 17:21:55 --> Language Class Initialized
INFO - 2018-10-12 17:21:55 --> Loader Class Initialized
INFO - 2018-10-12 17:21:55 --> Helper loaded: url_helper
INFO - 2018-10-12 17:21:55 --> Helper loaded: form_helper
INFO - 2018-10-12 17:21:55 --> Helper loaded: language_helper
DEBUG - 2018-10-12 17:21:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 17:21:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 17:21:55 --> User Agent Class Initialized
INFO - 2018-10-12 17:21:55 --> Controller Class Initialized
INFO - 2018-10-12 17:21:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 17:21:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 17:21:55 --> Pixel_Model class loaded
INFO - 2018-10-12 17:21:55 --> Database Driver Class Initialized
INFO - 2018-10-12 17:21:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:21:55 --> Form Validation Class Initialized
INFO - 2018-10-12 17:21:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-12 17:21:55 --> Database Driver Class Initialized
INFO - 2018-10-12 17:21:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:21:55 --> Config Class Initialized
INFO - 2018-10-12 17:21:55 --> Hooks Class Initialized
DEBUG - 2018-10-12 17:21:55 --> UTF-8 Support Enabled
INFO - 2018-10-12 17:21:55 --> Utf8 Class Initialized
INFO - 2018-10-12 17:21:55 --> URI Class Initialized
INFO - 2018-10-12 17:21:55 --> Router Class Initialized
INFO - 2018-10-12 17:21:55 --> Output Class Initialized
INFO - 2018-10-12 17:21:55 --> Security Class Initialized
DEBUG - 2018-10-12 17:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 17:21:55 --> CSRF cookie sent
INFO - 2018-10-12 17:21:55 --> Input Class Initialized
INFO - 2018-10-12 17:21:55 --> Language Class Initialized
INFO - 2018-10-12 17:21:55 --> Loader Class Initialized
INFO - 2018-10-12 17:21:55 --> Helper loaded: url_helper
INFO - 2018-10-12 17:21:55 --> Helper loaded: form_helper
INFO - 2018-10-12 17:21:55 --> Helper loaded: language_helper
DEBUG - 2018-10-12 17:21:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 17:21:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 17:21:55 --> User Agent Class Initialized
INFO - 2018-10-12 17:21:55 --> Controller Class Initialized
INFO - 2018-10-12 17:21:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 17:21:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 17:21:55 --> Pixel_Model class loaded
INFO - 2018-10-12 17:21:55 --> Database Driver Class Initialized
INFO - 2018-10-12 17:21:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:21:55 --> Database Driver Class Initialized
INFO - 2018-10-12 17:21:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:21:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 17:21:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 17:21:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 17:21:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 17:21:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-10-12 17:21:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 17:21:55 --> Final output sent to browser
DEBUG - 2018-10-12 17:21:55 --> Total execution time: 0.0503
INFO - 2018-10-12 17:21:59 --> Config Class Initialized
INFO - 2018-10-12 17:21:59 --> Hooks Class Initialized
DEBUG - 2018-10-12 17:21:59 --> UTF-8 Support Enabled
INFO - 2018-10-12 17:21:59 --> Utf8 Class Initialized
INFO - 2018-10-12 17:21:59 --> URI Class Initialized
INFO - 2018-10-12 17:21:59 --> Router Class Initialized
INFO - 2018-10-12 17:21:59 --> Output Class Initialized
INFO - 2018-10-12 17:21:59 --> Security Class Initialized
DEBUG - 2018-10-12 17:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 17:21:59 --> CSRF cookie sent
INFO - 2018-10-12 17:21:59 --> Input Class Initialized
INFO - 2018-10-12 17:21:59 --> Language Class Initialized
INFO - 2018-10-12 17:21:59 --> Loader Class Initialized
INFO - 2018-10-12 17:21:59 --> Helper loaded: url_helper
INFO - 2018-10-12 17:21:59 --> Helper loaded: form_helper
INFO - 2018-10-12 17:21:59 --> Helper loaded: language_helper
DEBUG - 2018-10-12 17:21:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 17:21:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 17:21:59 --> User Agent Class Initialized
INFO - 2018-10-12 17:21:59 --> Controller Class Initialized
INFO - 2018-10-12 17:21:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 17:21:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 17:21:59 --> Pixel_Model class loaded
INFO - 2018-10-12 17:21:59 --> Database Driver Class Initialized
INFO - 2018-10-12 17:21:59 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:21:59 --> Config Class Initialized
INFO - 2018-10-12 17:21:59 --> Hooks Class Initialized
DEBUG - 2018-10-12 17:21:59 --> UTF-8 Support Enabled
INFO - 2018-10-12 17:21:59 --> Utf8 Class Initialized
INFO - 2018-10-12 17:21:59 --> URI Class Initialized
INFO - 2018-10-12 17:21:59 --> Router Class Initialized
INFO - 2018-10-12 17:21:59 --> Output Class Initialized
INFO - 2018-10-12 17:21:59 --> Security Class Initialized
DEBUG - 2018-10-12 17:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 17:21:59 --> CSRF cookie sent
INFO - 2018-10-12 17:21:59 --> Input Class Initialized
INFO - 2018-10-12 17:21:59 --> Language Class Initialized
INFO - 2018-10-12 17:21:59 --> Loader Class Initialized
INFO - 2018-10-12 17:21:59 --> Helper loaded: url_helper
INFO - 2018-10-12 17:21:59 --> Helper loaded: form_helper
INFO - 2018-10-12 17:21:59 --> Helper loaded: language_helper
DEBUG - 2018-10-12 17:21:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 17:21:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 17:21:59 --> User Agent Class Initialized
INFO - 2018-10-12 17:21:59 --> Controller Class Initialized
INFO - 2018-10-12 17:21:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 17:21:59 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-12 17:21:59 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-10-12 17:21:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 17:21:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 17:21:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 17:21:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-10-12 17:21:59 --> Could not find the language line "req_email"
INFO - 2018-10-12 17:21:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-10-12 17:21:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 17:21:59 --> Final output sent to browser
DEBUG - 2018-10-12 17:21:59 --> Total execution time: 0.0320
INFO - 2018-10-12 17:22:13 --> Config Class Initialized
INFO - 2018-10-12 17:22:13 --> Hooks Class Initialized
DEBUG - 2018-10-12 17:22:13 --> UTF-8 Support Enabled
INFO - 2018-10-12 17:22:13 --> Utf8 Class Initialized
INFO - 2018-10-12 17:22:13 --> URI Class Initialized
INFO - 2018-10-12 17:22:13 --> Router Class Initialized
INFO - 2018-10-12 17:22:13 --> Output Class Initialized
INFO - 2018-10-12 17:22:13 --> Security Class Initialized
DEBUG - 2018-10-12 17:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 17:22:13 --> CSRF cookie sent
INFO - 2018-10-12 17:22:13 --> Input Class Initialized
INFO - 2018-10-12 17:22:13 --> Language Class Initialized
INFO - 2018-10-12 17:22:13 --> Loader Class Initialized
INFO - 2018-10-12 17:22:13 --> Helper loaded: url_helper
INFO - 2018-10-12 17:22:13 --> Helper loaded: form_helper
INFO - 2018-10-12 17:22:13 --> Helper loaded: language_helper
DEBUG - 2018-10-12 17:22:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 17:22:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 17:22:13 --> User Agent Class Initialized
INFO - 2018-10-12 17:22:13 --> Controller Class Initialized
INFO - 2018-10-12 17:22:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 17:22:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 17:22:13 --> Pixel_Model class loaded
INFO - 2018-10-12 17:22:13 --> Database Driver Class Initialized
INFO - 2018-10-12 17:22:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:22:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 17:22:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 17:22:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 17:22:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 17:22:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 17:22:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 17:22:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-10-12 17:22:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 17:22:13 --> Final output sent to browser
DEBUG - 2018-10-12 17:22:13 --> Total execution time: 0.0433
INFO - 2018-10-12 17:22:22 --> Config Class Initialized
INFO - 2018-10-12 17:22:22 --> Hooks Class Initialized
DEBUG - 2018-10-12 17:22:22 --> UTF-8 Support Enabled
INFO - 2018-10-12 17:22:22 --> Utf8 Class Initialized
INFO - 2018-10-12 17:22:22 --> URI Class Initialized
INFO - 2018-10-12 17:22:22 --> Router Class Initialized
INFO - 2018-10-12 17:22:22 --> Output Class Initialized
INFO - 2018-10-12 17:22:22 --> Security Class Initialized
DEBUG - 2018-10-12 17:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 17:22:22 --> CSRF cookie sent
INFO - 2018-10-12 17:22:22 --> CSRF token verified
INFO - 2018-10-12 17:22:22 --> Input Class Initialized
INFO - 2018-10-12 17:22:22 --> Language Class Initialized
INFO - 2018-10-12 17:22:22 --> Loader Class Initialized
INFO - 2018-10-12 17:22:22 --> Helper loaded: url_helper
INFO - 2018-10-12 17:22:22 --> Helper loaded: form_helper
INFO - 2018-10-12 17:22:22 --> Helper loaded: language_helper
DEBUG - 2018-10-12 17:22:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 17:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 17:22:22 --> User Agent Class Initialized
INFO - 2018-10-12 17:22:22 --> Controller Class Initialized
INFO - 2018-10-12 17:22:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 17:22:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 17:22:22 --> Pixel_Model class loaded
INFO - 2018-10-12 17:22:22 --> Database Driver Class Initialized
INFO - 2018-10-12 17:22:22 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:22:22 --> Database Driver Class Initialized
INFO - 2018-10-12 17:22:22 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:22:22 --> Config Class Initialized
INFO - 2018-10-12 17:22:22 --> Hooks Class Initialized
DEBUG - 2018-10-12 17:22:22 --> UTF-8 Support Enabled
INFO - 2018-10-12 17:22:22 --> Utf8 Class Initialized
INFO - 2018-10-12 17:22:22 --> URI Class Initialized
INFO - 2018-10-12 17:22:22 --> Router Class Initialized
INFO - 2018-10-12 17:22:22 --> Output Class Initialized
INFO - 2018-10-12 17:22:22 --> Security Class Initialized
DEBUG - 2018-10-12 17:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 17:22:22 --> CSRF cookie sent
INFO - 2018-10-12 17:22:22 --> Input Class Initialized
INFO - 2018-10-12 17:22:22 --> Language Class Initialized
INFO - 2018-10-12 17:22:22 --> Loader Class Initialized
INFO - 2018-10-12 17:22:22 --> Helper loaded: url_helper
INFO - 2018-10-12 17:22:22 --> Helper loaded: form_helper
INFO - 2018-10-12 17:22:22 --> Helper loaded: language_helper
DEBUG - 2018-10-12 17:22:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 17:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 17:22:22 --> User Agent Class Initialized
INFO - 2018-10-12 17:22:22 --> Controller Class Initialized
INFO - 2018-10-12 17:22:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 17:22:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 17:22:22 --> Pixel_Model class loaded
INFO - 2018-10-12 17:22:22 --> Database Driver Class Initialized
INFO - 2018-10-12 17:22:22 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:22:23 --> Config Class Initialized
INFO - 2018-10-12 17:22:23 --> Hooks Class Initialized
DEBUG - 2018-10-12 17:22:23 --> UTF-8 Support Enabled
INFO - 2018-10-12 17:22:23 --> Utf8 Class Initialized
INFO - 2018-10-12 17:22:23 --> URI Class Initialized
INFO - 2018-10-12 17:22:23 --> Router Class Initialized
INFO - 2018-10-12 17:22:23 --> Output Class Initialized
INFO - 2018-10-12 17:22:23 --> Security Class Initialized
DEBUG - 2018-10-12 17:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 17:22:23 --> CSRF cookie sent
INFO - 2018-10-12 17:22:23 --> Input Class Initialized
INFO - 2018-10-12 17:22:23 --> Language Class Initialized
INFO - 2018-10-12 17:22:23 --> Loader Class Initialized
INFO - 2018-10-12 17:22:23 --> Helper loaded: url_helper
INFO - 2018-10-12 17:22:23 --> Helper loaded: form_helper
INFO - 2018-10-12 17:22:23 --> Helper loaded: language_helper
DEBUG - 2018-10-12 17:22:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 17:22:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 17:22:23 --> User Agent Class Initialized
INFO - 2018-10-12 17:22:23 --> Controller Class Initialized
INFO - 2018-10-12 17:22:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 17:22:23 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-12 17:22:23 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-10-12 17:22:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 17:22:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 17:22:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 17:22:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-10-12 17:22:23 --> Could not find the language line "req_email"
INFO - 2018-10-12 17:22:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-10-12 17:22:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 17:22:23 --> Final output sent to browser
DEBUG - 2018-10-12 17:22:23 --> Total execution time: 0.0241
INFO - 2018-10-12 17:22:28 --> Config Class Initialized
INFO - 2018-10-12 17:22:28 --> Hooks Class Initialized
DEBUG - 2018-10-12 17:22:28 --> UTF-8 Support Enabled
INFO - 2018-10-12 17:22:28 --> Utf8 Class Initialized
INFO - 2018-10-12 17:22:28 --> URI Class Initialized
INFO - 2018-10-12 17:22:28 --> Router Class Initialized
INFO - 2018-10-12 17:22:28 --> Output Class Initialized
INFO - 2018-10-12 17:22:28 --> Security Class Initialized
DEBUG - 2018-10-12 17:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 17:22:28 --> CSRF cookie sent
INFO - 2018-10-12 17:22:28 --> Input Class Initialized
INFO - 2018-10-12 17:22:28 --> Language Class Initialized
INFO - 2018-10-12 17:22:28 --> Loader Class Initialized
INFO - 2018-10-12 17:22:28 --> Helper loaded: url_helper
INFO - 2018-10-12 17:22:28 --> Helper loaded: form_helper
INFO - 2018-10-12 17:22:28 --> Helper loaded: language_helper
DEBUG - 2018-10-12 17:22:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 17:22:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 17:22:28 --> User Agent Class Initialized
INFO - 2018-10-12 17:22:28 --> Controller Class Initialized
INFO - 2018-10-12 17:22:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 17:22:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 17:22:28 --> Pixel_Model class loaded
INFO - 2018-10-12 17:22:28 --> Database Driver Class Initialized
INFO - 2018-10-12 17:22:28 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:22:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 17:22:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 17:22:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 17:22:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 17:22:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 17:22:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 17:22:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-10-12 17:22:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 17:22:28 --> Final output sent to browser
DEBUG - 2018-10-12 17:22:28 --> Total execution time: 0.0391
INFO - 2018-10-12 17:22:31 --> Config Class Initialized
INFO - 2018-10-12 17:22:31 --> Hooks Class Initialized
DEBUG - 2018-10-12 17:22:31 --> UTF-8 Support Enabled
INFO - 2018-10-12 17:22:31 --> Utf8 Class Initialized
INFO - 2018-10-12 17:22:31 --> URI Class Initialized
INFO - 2018-10-12 17:22:31 --> Router Class Initialized
INFO - 2018-10-12 17:22:31 --> Output Class Initialized
INFO - 2018-10-12 17:22:31 --> Security Class Initialized
DEBUG - 2018-10-12 17:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 17:22:31 --> CSRF cookie sent
INFO - 2018-10-12 17:22:31 --> CSRF token verified
INFO - 2018-10-12 17:22:31 --> Input Class Initialized
INFO - 2018-10-12 17:22:31 --> Language Class Initialized
INFO - 2018-10-12 17:22:31 --> Loader Class Initialized
INFO - 2018-10-12 17:22:31 --> Helper loaded: url_helper
INFO - 2018-10-12 17:22:31 --> Helper loaded: form_helper
INFO - 2018-10-12 17:22:31 --> Helper loaded: language_helper
DEBUG - 2018-10-12 17:22:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 17:22:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 17:22:31 --> User Agent Class Initialized
INFO - 2018-10-12 17:22:31 --> Controller Class Initialized
INFO - 2018-10-12 17:22:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 17:22:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 17:22:31 --> Pixel_Model class loaded
INFO - 2018-10-12 17:22:31 --> Database Driver Class Initialized
INFO - 2018-10-12 17:22:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:22:31 --> Database Driver Class Initialized
INFO - 2018-10-12 17:22:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:22:33 --> Config Class Initialized
INFO - 2018-10-12 17:22:33 --> Hooks Class Initialized
DEBUG - 2018-10-12 17:22:33 --> UTF-8 Support Enabled
INFO - 2018-10-12 17:22:33 --> Utf8 Class Initialized
INFO - 2018-10-12 17:22:33 --> URI Class Initialized
INFO - 2018-10-12 17:22:33 --> Router Class Initialized
INFO - 2018-10-12 17:22:33 --> Output Class Initialized
INFO - 2018-10-12 17:22:33 --> Security Class Initialized
DEBUG - 2018-10-12 17:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 17:22:33 --> CSRF cookie sent
INFO - 2018-10-12 17:22:33 --> Input Class Initialized
INFO - 2018-10-12 17:22:33 --> Language Class Initialized
INFO - 2018-10-12 17:22:33 --> Loader Class Initialized
INFO - 2018-10-12 17:22:33 --> Helper loaded: url_helper
INFO - 2018-10-12 17:22:33 --> Helper loaded: form_helper
INFO - 2018-10-12 17:22:33 --> Helper loaded: language_helper
DEBUG - 2018-10-12 17:22:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 17:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 17:22:33 --> User Agent Class Initialized
INFO - 2018-10-12 17:22:33 --> Controller Class Initialized
INFO - 2018-10-12 17:22:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 17:22:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 17:22:33 --> Pixel_Model class loaded
INFO - 2018-10-12 17:22:33 --> Database Driver Class Initialized
INFO - 2018-10-12 17:22:33 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:22:34 --> Config Class Initialized
INFO - 2018-10-12 17:22:34 --> Hooks Class Initialized
DEBUG - 2018-10-12 17:22:34 --> UTF-8 Support Enabled
INFO - 2018-10-12 17:22:34 --> Utf8 Class Initialized
INFO - 2018-10-12 17:22:34 --> URI Class Initialized
INFO - 2018-10-12 17:22:34 --> Router Class Initialized
INFO - 2018-10-12 17:22:34 --> Output Class Initialized
INFO - 2018-10-12 17:22:34 --> Security Class Initialized
DEBUG - 2018-10-12 17:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 17:22:34 --> CSRF cookie sent
INFO - 2018-10-12 17:22:34 --> Input Class Initialized
INFO - 2018-10-12 17:22:34 --> Language Class Initialized
INFO - 2018-10-12 17:22:34 --> Loader Class Initialized
INFO - 2018-10-12 17:22:34 --> Helper loaded: url_helper
INFO - 2018-10-12 17:22:34 --> Helper loaded: form_helper
INFO - 2018-10-12 17:22:34 --> Helper loaded: language_helper
DEBUG - 2018-10-12 17:22:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 17:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 17:22:34 --> User Agent Class Initialized
INFO - 2018-10-12 17:22:34 --> Controller Class Initialized
INFO - 2018-10-12 17:22:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 17:22:34 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-12 17:22:34 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-10-12 17:22:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 17:22:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 17:22:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 17:22:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-10-12 17:22:34 --> Could not find the language line "req_email"
INFO - 2018-10-12 17:22:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-10-12 17:22:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 17:22:34 --> Final output sent to browser
DEBUG - 2018-10-12 17:22:34 --> Total execution time: 0.0289
INFO - 2018-10-12 17:22:42 --> Config Class Initialized
INFO - 2018-10-12 17:22:42 --> Hooks Class Initialized
DEBUG - 2018-10-12 17:22:42 --> UTF-8 Support Enabled
INFO - 2018-10-12 17:22:42 --> Utf8 Class Initialized
INFO - 2018-10-12 17:22:42 --> URI Class Initialized
INFO - 2018-10-12 17:22:42 --> Router Class Initialized
INFO - 2018-10-12 17:22:42 --> Output Class Initialized
INFO - 2018-10-12 17:22:42 --> Security Class Initialized
DEBUG - 2018-10-12 17:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 17:22:42 --> CSRF cookie sent
INFO - 2018-10-12 17:22:42 --> Input Class Initialized
INFO - 2018-10-12 17:22:42 --> Language Class Initialized
INFO - 2018-10-12 17:22:42 --> Loader Class Initialized
INFO - 2018-10-12 17:22:42 --> Helper loaded: url_helper
INFO - 2018-10-12 17:22:42 --> Helper loaded: form_helper
INFO - 2018-10-12 17:22:42 --> Helper loaded: language_helper
DEBUG - 2018-10-12 17:22:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 17:22:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 17:22:42 --> User Agent Class Initialized
INFO - 2018-10-12 17:22:42 --> Controller Class Initialized
INFO - 2018-10-12 17:22:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 17:22:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 17:22:42 --> Pixel_Model class loaded
INFO - 2018-10-12 17:22:42 --> Database Driver Class Initialized
INFO - 2018-10-12 17:22:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:22:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 17:22:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 17:22:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 17:22:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 17:22:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 17:22:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 17:22:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-10-12 17:22:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 17:22:42 --> Final output sent to browser
DEBUG - 2018-10-12 17:22:42 --> Total execution time: 0.0454
INFO - 2018-10-12 17:29:01 --> Config Class Initialized
INFO - 2018-10-12 17:29:01 --> Hooks Class Initialized
DEBUG - 2018-10-12 17:29:01 --> UTF-8 Support Enabled
INFO - 2018-10-12 17:29:01 --> Utf8 Class Initialized
INFO - 2018-10-12 17:29:01 --> URI Class Initialized
INFO - 2018-10-12 17:29:01 --> Router Class Initialized
INFO - 2018-10-12 17:29:01 --> Output Class Initialized
INFO - 2018-10-12 17:29:01 --> Security Class Initialized
DEBUG - 2018-10-12 17:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 17:29:01 --> CSRF cookie sent
INFO - 2018-10-12 17:29:01 --> Input Class Initialized
INFO - 2018-10-12 17:29:01 --> Language Class Initialized
INFO - 2018-10-12 17:29:01 --> Loader Class Initialized
INFO - 2018-10-12 17:29:01 --> Helper loaded: url_helper
INFO - 2018-10-12 17:29:01 --> Helper loaded: form_helper
INFO - 2018-10-12 17:29:01 --> Helper loaded: language_helper
DEBUG - 2018-10-12 17:29:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 17:29:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 17:29:01 --> User Agent Class Initialized
INFO - 2018-10-12 17:29:01 --> Controller Class Initialized
INFO - 2018-10-12 17:29:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 17:29:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 17:29:01 --> Pixel_Model class loaded
INFO - 2018-10-12 17:29:02 --> Database Driver Class Initialized
INFO - 2018-10-12 17:29:02 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:29:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 17:29:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 17:29:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 17:29:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 17:29:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 17:29:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 17:29:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-10-12 17:29:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 17:29:02 --> Final output sent to browser
DEBUG - 2018-10-12 17:29:02 --> Total execution time: 0.0723
INFO - 2018-10-12 17:29:04 --> Config Class Initialized
INFO - 2018-10-12 17:29:04 --> Hooks Class Initialized
DEBUG - 2018-10-12 17:29:04 --> UTF-8 Support Enabled
INFO - 2018-10-12 17:29:04 --> Utf8 Class Initialized
INFO - 2018-10-12 17:29:04 --> URI Class Initialized
INFO - 2018-10-12 17:29:04 --> Router Class Initialized
INFO - 2018-10-12 17:29:04 --> Output Class Initialized
INFO - 2018-10-12 17:29:04 --> Security Class Initialized
DEBUG - 2018-10-12 17:29:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 17:29:04 --> CSRF cookie sent
INFO - 2018-10-12 17:29:04 --> CSRF token verified
INFO - 2018-10-12 17:29:04 --> Input Class Initialized
INFO - 2018-10-12 17:29:04 --> Language Class Initialized
INFO - 2018-10-12 17:29:04 --> Loader Class Initialized
INFO - 2018-10-12 17:29:04 --> Helper loaded: url_helper
INFO - 2018-10-12 17:29:04 --> Helper loaded: form_helper
INFO - 2018-10-12 17:29:04 --> Helper loaded: language_helper
DEBUG - 2018-10-12 17:29:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 17:29:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 17:29:04 --> User Agent Class Initialized
INFO - 2018-10-12 17:29:04 --> Controller Class Initialized
INFO - 2018-10-12 17:29:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 17:29:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 17:29:04 --> Pixel_Model class loaded
INFO - 2018-10-12 17:29:04 --> Database Driver Class Initialized
INFO - 2018-10-12 17:29:04 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:29:04 --> Form Validation Class Initialized
INFO - 2018-10-12 17:29:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-12 17:29:04 --> Database Driver Class Initialized
INFO - 2018-10-12 17:29:04 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:29:06 --> Config Class Initialized
INFO - 2018-10-12 17:29:06 --> Hooks Class Initialized
DEBUG - 2018-10-12 17:29:06 --> UTF-8 Support Enabled
INFO - 2018-10-12 17:29:06 --> Utf8 Class Initialized
INFO - 2018-10-12 17:29:06 --> URI Class Initialized
INFO - 2018-10-12 17:29:06 --> Router Class Initialized
INFO - 2018-10-12 17:29:06 --> Output Class Initialized
INFO - 2018-10-12 17:29:06 --> Security Class Initialized
DEBUG - 2018-10-12 17:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 17:29:06 --> CSRF cookie sent
INFO - 2018-10-12 17:29:06 --> Input Class Initialized
INFO - 2018-10-12 17:29:06 --> Language Class Initialized
INFO - 2018-10-12 17:29:06 --> Loader Class Initialized
INFO - 2018-10-12 17:29:06 --> Helper loaded: url_helper
INFO - 2018-10-12 17:29:06 --> Helper loaded: form_helper
INFO - 2018-10-12 17:29:06 --> Helper loaded: language_helper
DEBUG - 2018-10-12 17:29:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 17:29:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 17:29:06 --> User Agent Class Initialized
INFO - 2018-10-12 17:29:06 --> Controller Class Initialized
INFO - 2018-10-12 17:29:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 17:29:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 17:29:06 --> Pixel_Model class loaded
INFO - 2018-10-12 17:29:06 --> Database Driver Class Initialized
INFO - 2018-10-12 17:29:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:29:06 --> Database Driver Class Initialized
INFO - 2018-10-12 17:29:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:29:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 17:29:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 17:29:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 17:29:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 17:29:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 17:29:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 17:29:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-12 17:29:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 17:29:06 --> Final output sent to browser
DEBUG - 2018-10-12 17:29:06 --> Total execution time: 0.0479
INFO - 2018-10-12 17:29:11 --> Config Class Initialized
INFO - 2018-10-12 17:29:11 --> Hooks Class Initialized
DEBUG - 2018-10-12 17:29:11 --> UTF-8 Support Enabled
INFO - 2018-10-12 17:29:11 --> Utf8 Class Initialized
INFO - 2018-10-12 17:29:11 --> URI Class Initialized
INFO - 2018-10-12 17:29:11 --> Router Class Initialized
INFO - 2018-10-12 17:29:11 --> Output Class Initialized
INFO - 2018-10-12 17:29:11 --> Security Class Initialized
DEBUG - 2018-10-12 17:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 17:29:11 --> CSRF cookie sent
INFO - 2018-10-12 17:29:11 --> CSRF token verified
INFO - 2018-10-12 17:29:11 --> Input Class Initialized
INFO - 2018-10-12 17:29:11 --> Language Class Initialized
INFO - 2018-10-12 17:29:11 --> Loader Class Initialized
INFO - 2018-10-12 17:29:11 --> Helper loaded: url_helper
INFO - 2018-10-12 17:29:11 --> Helper loaded: form_helper
INFO - 2018-10-12 17:29:11 --> Helper loaded: language_helper
DEBUG - 2018-10-12 17:29:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 17:29:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 17:29:11 --> User Agent Class Initialized
INFO - 2018-10-12 17:29:11 --> Controller Class Initialized
INFO - 2018-10-12 17:29:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 17:29:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 17:29:11 --> Pixel_Model class loaded
INFO - 2018-10-12 17:29:11 --> Database Driver Class Initialized
INFO - 2018-10-12 17:29:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:29:11 --> Form Validation Class Initialized
INFO - 2018-10-12 17:29:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-12 17:29:11 --> Database Driver Class Initialized
INFO - 2018-10-12 17:29:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:29:11 --> Config Class Initialized
INFO - 2018-10-12 17:29:11 --> Hooks Class Initialized
DEBUG - 2018-10-12 17:29:11 --> UTF-8 Support Enabled
INFO - 2018-10-12 17:29:11 --> Utf8 Class Initialized
INFO - 2018-10-12 17:29:11 --> URI Class Initialized
INFO - 2018-10-12 17:29:11 --> Router Class Initialized
INFO - 2018-10-12 17:29:11 --> Output Class Initialized
INFO - 2018-10-12 17:29:11 --> Security Class Initialized
DEBUG - 2018-10-12 17:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 17:29:11 --> CSRF cookie sent
INFO - 2018-10-12 17:29:11 --> Input Class Initialized
INFO - 2018-10-12 17:29:11 --> Language Class Initialized
INFO - 2018-10-12 17:29:11 --> Loader Class Initialized
INFO - 2018-10-12 17:29:11 --> Helper loaded: url_helper
INFO - 2018-10-12 17:29:11 --> Helper loaded: form_helper
INFO - 2018-10-12 17:29:11 --> Helper loaded: language_helper
DEBUG - 2018-10-12 17:29:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 17:29:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 17:29:11 --> User Agent Class Initialized
INFO - 2018-10-12 17:29:11 --> Controller Class Initialized
INFO - 2018-10-12 17:29:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 17:29:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 17:29:11 --> Pixel_Model class loaded
INFO - 2018-10-12 17:29:11 --> Database Driver Class Initialized
INFO - 2018-10-12 17:29:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:29:11 --> Database Driver Class Initialized
INFO - 2018-10-12 17:29:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:29:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 17:29:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 17:29:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 17:29:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 17:29:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 17:29:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 17:29:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-10-12 17:29:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 17:29:11 --> Final output sent to browser
DEBUG - 2018-10-12 17:29:11 --> Total execution time: 0.0443
INFO - 2018-10-12 17:29:14 --> Config Class Initialized
INFO - 2018-10-12 17:29:14 --> Hooks Class Initialized
DEBUG - 2018-10-12 17:29:14 --> UTF-8 Support Enabled
INFO - 2018-10-12 17:29:14 --> Utf8 Class Initialized
INFO - 2018-10-12 17:29:14 --> URI Class Initialized
INFO - 2018-10-12 17:29:14 --> Router Class Initialized
INFO - 2018-10-12 17:29:14 --> Output Class Initialized
INFO - 2018-10-12 17:29:14 --> Security Class Initialized
DEBUG - 2018-10-12 17:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 17:29:14 --> CSRF cookie sent
INFO - 2018-10-12 17:29:14 --> CSRF token verified
INFO - 2018-10-12 17:29:14 --> Input Class Initialized
INFO - 2018-10-12 17:29:14 --> Language Class Initialized
INFO - 2018-10-12 17:29:14 --> Loader Class Initialized
INFO - 2018-10-12 17:29:14 --> Helper loaded: url_helper
INFO - 2018-10-12 17:29:14 --> Helper loaded: form_helper
INFO - 2018-10-12 17:29:14 --> Helper loaded: language_helper
DEBUG - 2018-10-12 17:29:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 17:29:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 17:29:14 --> User Agent Class Initialized
INFO - 2018-10-12 17:29:14 --> Controller Class Initialized
INFO - 2018-10-12 17:29:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 17:29:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 17:29:14 --> Pixel_Model class loaded
INFO - 2018-10-12 17:29:14 --> Database Driver Class Initialized
INFO - 2018-10-12 17:29:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:29:14 --> Form Validation Class Initialized
INFO - 2018-10-12 17:29:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-12 17:29:14 --> Database Driver Class Initialized
INFO - 2018-10-12 17:29:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:29:14 --> Config Class Initialized
INFO - 2018-10-12 17:29:14 --> Hooks Class Initialized
DEBUG - 2018-10-12 17:29:14 --> UTF-8 Support Enabled
INFO - 2018-10-12 17:29:14 --> Utf8 Class Initialized
INFO - 2018-10-12 17:29:14 --> URI Class Initialized
INFO - 2018-10-12 17:29:14 --> Router Class Initialized
INFO - 2018-10-12 17:29:14 --> Output Class Initialized
INFO - 2018-10-12 17:29:14 --> Security Class Initialized
DEBUG - 2018-10-12 17:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 17:29:14 --> CSRF cookie sent
INFO - 2018-10-12 17:29:14 --> Input Class Initialized
INFO - 2018-10-12 17:29:14 --> Language Class Initialized
INFO - 2018-10-12 17:29:14 --> Loader Class Initialized
INFO - 2018-10-12 17:29:14 --> Helper loaded: url_helper
INFO - 2018-10-12 17:29:14 --> Helper loaded: form_helper
INFO - 2018-10-12 17:29:14 --> Helper loaded: language_helper
DEBUG - 2018-10-12 17:29:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 17:29:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 17:29:14 --> User Agent Class Initialized
INFO - 2018-10-12 17:29:14 --> Controller Class Initialized
INFO - 2018-10-12 17:29:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 17:29:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 17:29:14 --> Pixel_Model class loaded
INFO - 2018-10-12 17:29:14 --> Database Driver Class Initialized
INFO - 2018-10-12 17:29:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:29:14 --> Database Driver Class Initialized
INFO - 2018-10-12 17:29:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:29:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 17:29:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 17:29:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-10-12 17:29:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 17:29:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 17:29:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 17:29:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 17:29:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-10-12 17:29:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 17:29:14 --> Final output sent to browser
DEBUG - 2018-10-12 17:29:14 --> Total execution time: 0.0354
INFO - 2018-10-12 17:29:16 --> Config Class Initialized
INFO - 2018-10-12 17:29:16 --> Hooks Class Initialized
DEBUG - 2018-10-12 17:29:16 --> UTF-8 Support Enabled
INFO - 2018-10-12 17:29:16 --> Utf8 Class Initialized
INFO - 2018-10-12 17:29:16 --> URI Class Initialized
INFO - 2018-10-12 17:29:16 --> Router Class Initialized
INFO - 2018-10-12 17:29:16 --> Output Class Initialized
INFO - 2018-10-12 17:29:16 --> Security Class Initialized
DEBUG - 2018-10-12 17:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 17:29:16 --> CSRF cookie sent
INFO - 2018-10-12 17:29:16 --> CSRF token verified
INFO - 2018-10-12 17:29:16 --> Input Class Initialized
INFO - 2018-10-12 17:29:16 --> Language Class Initialized
INFO - 2018-10-12 17:29:16 --> Loader Class Initialized
INFO - 2018-10-12 17:29:16 --> Helper loaded: url_helper
INFO - 2018-10-12 17:29:16 --> Helper loaded: form_helper
INFO - 2018-10-12 17:29:16 --> Helper loaded: language_helper
DEBUG - 2018-10-12 17:29:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 17:29:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 17:29:16 --> User Agent Class Initialized
INFO - 2018-10-12 17:29:16 --> Controller Class Initialized
INFO - 2018-10-12 17:29:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 17:29:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 17:29:16 --> Pixel_Model class loaded
INFO - 2018-10-12 17:29:16 --> Database Driver Class Initialized
INFO - 2018-10-12 17:29:16 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:29:16 --> Form Validation Class Initialized
INFO - 2018-10-12 17:29:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-12 17:29:16 --> Database Driver Class Initialized
INFO - 2018-10-12 17:29:16 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:29:16 --> Config Class Initialized
INFO - 2018-10-12 17:29:16 --> Hooks Class Initialized
DEBUG - 2018-10-12 17:29:16 --> UTF-8 Support Enabled
INFO - 2018-10-12 17:29:16 --> Utf8 Class Initialized
INFO - 2018-10-12 17:29:16 --> URI Class Initialized
INFO - 2018-10-12 17:29:16 --> Router Class Initialized
INFO - 2018-10-12 17:29:16 --> Output Class Initialized
INFO - 2018-10-12 17:29:16 --> Security Class Initialized
DEBUG - 2018-10-12 17:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 17:29:16 --> CSRF cookie sent
INFO - 2018-10-12 17:29:16 --> Input Class Initialized
INFO - 2018-10-12 17:29:16 --> Language Class Initialized
INFO - 2018-10-12 17:29:16 --> Loader Class Initialized
INFO - 2018-10-12 17:29:16 --> Helper loaded: url_helper
INFO - 2018-10-12 17:29:16 --> Helper loaded: form_helper
INFO - 2018-10-12 17:29:16 --> Helper loaded: language_helper
DEBUG - 2018-10-12 17:29:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 17:29:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 17:29:16 --> User Agent Class Initialized
INFO - 2018-10-12 17:29:16 --> Controller Class Initialized
INFO - 2018-10-12 17:29:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 17:29:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 17:29:16 --> Pixel_Model class loaded
INFO - 2018-10-12 17:29:16 --> Database Driver Class Initialized
INFO - 2018-10-12 17:29:16 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:29:16 --> Database Driver Class Initialized
INFO - 2018-10-12 17:29:16 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:29:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 17:29:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 17:29:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 17:29:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 17:29:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 17:29:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 17:29:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-12 17:29:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 17:29:16 --> Final output sent to browser
DEBUG - 2018-10-12 17:29:16 --> Total execution time: 0.0400
INFO - 2018-10-12 17:29:19 --> Config Class Initialized
INFO - 2018-10-12 17:29:19 --> Hooks Class Initialized
DEBUG - 2018-10-12 17:29:19 --> UTF-8 Support Enabled
INFO - 2018-10-12 17:29:19 --> Utf8 Class Initialized
INFO - 2018-10-12 17:29:19 --> URI Class Initialized
INFO - 2018-10-12 17:29:19 --> Router Class Initialized
INFO - 2018-10-12 17:29:19 --> Output Class Initialized
INFO - 2018-10-12 17:29:19 --> Security Class Initialized
DEBUG - 2018-10-12 17:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 17:29:19 --> CSRF cookie sent
INFO - 2018-10-12 17:29:19 --> CSRF token verified
INFO - 2018-10-12 17:29:19 --> Input Class Initialized
INFO - 2018-10-12 17:29:19 --> Language Class Initialized
INFO - 2018-10-12 17:29:19 --> Loader Class Initialized
INFO - 2018-10-12 17:29:19 --> Helper loaded: url_helper
INFO - 2018-10-12 17:29:19 --> Helper loaded: form_helper
INFO - 2018-10-12 17:29:19 --> Helper loaded: language_helper
DEBUG - 2018-10-12 17:29:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 17:29:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 17:29:19 --> User Agent Class Initialized
INFO - 2018-10-12 17:29:19 --> Controller Class Initialized
INFO - 2018-10-12 17:29:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 17:29:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 17:29:19 --> Pixel_Model class loaded
INFO - 2018-10-12 17:29:19 --> Database Driver Class Initialized
INFO - 2018-10-12 17:29:19 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:29:19 --> Form Validation Class Initialized
INFO - 2018-10-12 17:29:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-12 17:29:19 --> Database Driver Class Initialized
INFO - 2018-10-12 17:29:19 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:29:21 --> Config Class Initialized
INFO - 2018-10-12 17:29:21 --> Hooks Class Initialized
DEBUG - 2018-10-12 17:29:21 --> UTF-8 Support Enabled
INFO - 2018-10-12 17:29:21 --> Utf8 Class Initialized
INFO - 2018-10-12 17:29:21 --> URI Class Initialized
INFO - 2018-10-12 17:29:21 --> Router Class Initialized
INFO - 2018-10-12 17:29:21 --> Output Class Initialized
INFO - 2018-10-12 17:29:21 --> Security Class Initialized
DEBUG - 2018-10-12 17:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 17:29:21 --> CSRF cookie sent
INFO - 2018-10-12 17:29:21 --> Input Class Initialized
INFO - 2018-10-12 17:29:21 --> Language Class Initialized
INFO - 2018-10-12 17:29:21 --> Loader Class Initialized
INFO - 2018-10-12 17:29:21 --> Helper loaded: url_helper
INFO - 2018-10-12 17:29:21 --> Helper loaded: form_helper
INFO - 2018-10-12 17:29:21 --> Helper loaded: language_helper
DEBUG - 2018-10-12 17:29:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 17:29:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 17:29:21 --> User Agent Class Initialized
INFO - 2018-10-12 17:29:21 --> Controller Class Initialized
INFO - 2018-10-12 17:29:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 17:29:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 17:29:21 --> Pixel_Model class loaded
INFO - 2018-10-12 17:29:21 --> Database Driver Class Initialized
INFO - 2018-10-12 17:29:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:29:21 --> Database Driver Class Initialized
INFO - 2018-10-12 17:29:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:29:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 17:29:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 17:29:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 17:29:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 17:29:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 17:29:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 17:29:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-10-12 17:29:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 17:29:21 --> Final output sent to browser
DEBUG - 2018-10-12 17:29:21 --> Total execution time: 0.0532
INFO - 2018-10-12 17:29:23 --> Config Class Initialized
INFO - 2018-10-12 17:29:23 --> Hooks Class Initialized
DEBUG - 2018-10-12 17:29:23 --> UTF-8 Support Enabled
INFO - 2018-10-12 17:29:23 --> Utf8 Class Initialized
INFO - 2018-10-12 17:29:23 --> URI Class Initialized
INFO - 2018-10-12 17:29:23 --> Router Class Initialized
INFO - 2018-10-12 17:29:23 --> Output Class Initialized
INFO - 2018-10-12 17:29:23 --> Security Class Initialized
DEBUG - 2018-10-12 17:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 17:29:23 --> CSRF cookie sent
INFO - 2018-10-12 17:29:23 --> CSRF token verified
INFO - 2018-10-12 17:29:23 --> Input Class Initialized
INFO - 2018-10-12 17:29:23 --> Language Class Initialized
INFO - 2018-10-12 17:29:23 --> Loader Class Initialized
INFO - 2018-10-12 17:29:23 --> Helper loaded: url_helper
INFO - 2018-10-12 17:29:23 --> Helper loaded: form_helper
INFO - 2018-10-12 17:29:23 --> Helper loaded: language_helper
DEBUG - 2018-10-12 17:29:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 17:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 17:29:23 --> User Agent Class Initialized
INFO - 2018-10-12 17:29:23 --> Controller Class Initialized
INFO - 2018-10-12 17:29:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 17:29:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 17:29:23 --> Pixel_Model class loaded
INFO - 2018-10-12 17:29:23 --> Database Driver Class Initialized
INFO - 2018-10-12 17:29:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:29:23 --> Form Validation Class Initialized
INFO - 2018-10-12 17:29:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-12 17:29:23 --> Database Driver Class Initialized
INFO - 2018-10-12 17:29:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:29:23 --> Config Class Initialized
INFO - 2018-10-12 17:29:23 --> Hooks Class Initialized
DEBUG - 2018-10-12 17:29:23 --> UTF-8 Support Enabled
INFO - 2018-10-12 17:29:23 --> Utf8 Class Initialized
INFO - 2018-10-12 17:29:23 --> URI Class Initialized
INFO - 2018-10-12 17:29:23 --> Router Class Initialized
INFO - 2018-10-12 17:29:23 --> Output Class Initialized
INFO - 2018-10-12 17:29:23 --> Security Class Initialized
DEBUG - 2018-10-12 17:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 17:29:23 --> CSRF cookie sent
INFO - 2018-10-12 17:29:23 --> Input Class Initialized
INFO - 2018-10-12 17:29:23 --> Language Class Initialized
INFO - 2018-10-12 17:29:23 --> Loader Class Initialized
INFO - 2018-10-12 17:29:23 --> Helper loaded: url_helper
INFO - 2018-10-12 17:29:23 --> Helper loaded: form_helper
INFO - 2018-10-12 17:29:23 --> Helper loaded: language_helper
DEBUG - 2018-10-12 17:29:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 17:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 17:29:23 --> User Agent Class Initialized
INFO - 2018-10-12 17:29:23 --> Controller Class Initialized
INFO - 2018-10-12 17:29:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 17:29:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 17:29:23 --> Pixel_Model class loaded
INFO - 2018-10-12 17:29:23 --> Database Driver Class Initialized
INFO - 2018-10-12 17:29:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:29:23 --> Database Driver Class Initialized
INFO - 2018-10-12 17:29:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:29:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 17:29:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 17:29:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 17:29:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 17:29:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 17:29:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 17:29:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_title.php
INFO - 2018-10-12 17:29:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 17:29:23 --> Final output sent to browser
DEBUG - 2018-10-12 17:29:23 --> Total execution time: 0.0388
INFO - 2018-10-12 17:29:25 --> Config Class Initialized
INFO - 2018-10-12 17:29:25 --> Hooks Class Initialized
DEBUG - 2018-10-12 17:29:25 --> UTF-8 Support Enabled
INFO - 2018-10-12 17:29:25 --> Utf8 Class Initialized
INFO - 2018-10-12 17:29:25 --> URI Class Initialized
INFO - 2018-10-12 17:29:25 --> Router Class Initialized
INFO - 2018-10-12 17:29:25 --> Output Class Initialized
INFO - 2018-10-12 17:29:25 --> Security Class Initialized
DEBUG - 2018-10-12 17:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 17:29:25 --> CSRF cookie sent
INFO - 2018-10-12 17:29:25 --> CSRF token verified
INFO - 2018-10-12 17:29:25 --> Input Class Initialized
INFO - 2018-10-12 17:29:25 --> Language Class Initialized
INFO - 2018-10-12 17:29:25 --> Loader Class Initialized
INFO - 2018-10-12 17:29:25 --> Helper loaded: url_helper
INFO - 2018-10-12 17:29:25 --> Helper loaded: form_helper
INFO - 2018-10-12 17:29:25 --> Helper loaded: language_helper
DEBUG - 2018-10-12 17:29:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 17:29:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 17:29:25 --> User Agent Class Initialized
INFO - 2018-10-12 17:29:25 --> Controller Class Initialized
INFO - 2018-10-12 17:29:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 17:29:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 17:29:25 --> Pixel_Model class loaded
INFO - 2018-10-12 17:29:25 --> Database Driver Class Initialized
INFO - 2018-10-12 17:29:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:29:25 --> Form Validation Class Initialized
INFO - 2018-10-12 17:29:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-12 17:29:25 --> Database Driver Class Initialized
INFO - 2018-10-12 17:29:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:29:25 --> Config Class Initialized
INFO - 2018-10-12 17:29:25 --> Hooks Class Initialized
DEBUG - 2018-10-12 17:29:25 --> UTF-8 Support Enabled
INFO - 2018-10-12 17:29:25 --> Utf8 Class Initialized
INFO - 2018-10-12 17:29:25 --> URI Class Initialized
INFO - 2018-10-12 17:29:25 --> Router Class Initialized
INFO - 2018-10-12 17:29:25 --> Output Class Initialized
INFO - 2018-10-12 17:29:25 --> Security Class Initialized
DEBUG - 2018-10-12 17:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 17:29:25 --> CSRF cookie sent
INFO - 2018-10-12 17:29:25 --> Input Class Initialized
INFO - 2018-10-12 17:29:25 --> Language Class Initialized
INFO - 2018-10-12 17:29:25 --> Loader Class Initialized
INFO - 2018-10-12 17:29:25 --> Helper loaded: url_helper
INFO - 2018-10-12 17:29:25 --> Helper loaded: form_helper
INFO - 2018-10-12 17:29:25 --> Helper loaded: language_helper
DEBUG - 2018-10-12 17:29:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 17:29:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 17:29:25 --> User Agent Class Initialized
INFO - 2018-10-12 17:29:25 --> Controller Class Initialized
INFO - 2018-10-12 17:29:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 17:29:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 17:29:25 --> Pixel_Model class loaded
INFO - 2018-10-12 17:29:25 --> Database Driver Class Initialized
INFO - 2018-10-12 17:29:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:29:25 --> Database Driver Class Initialized
INFO - 2018-10-12 17:29:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:29:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 17:29:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 17:29:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 17:29:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 17:29:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 17:29:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 17:29:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-10-12 17:29:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 17:29:25 --> Final output sent to browser
DEBUG - 2018-10-12 17:29:25 --> Total execution time: 0.0442
INFO - 2018-10-12 17:29:27 --> Config Class Initialized
INFO - 2018-10-12 17:29:27 --> Hooks Class Initialized
DEBUG - 2018-10-12 17:29:27 --> UTF-8 Support Enabled
INFO - 2018-10-12 17:29:27 --> Utf8 Class Initialized
INFO - 2018-10-12 17:29:27 --> URI Class Initialized
INFO - 2018-10-12 17:29:27 --> Router Class Initialized
INFO - 2018-10-12 17:29:27 --> Output Class Initialized
INFO - 2018-10-12 17:29:27 --> Security Class Initialized
DEBUG - 2018-10-12 17:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 17:29:27 --> CSRF cookie sent
INFO - 2018-10-12 17:29:27 --> CSRF token verified
INFO - 2018-10-12 17:29:27 --> Input Class Initialized
INFO - 2018-10-12 17:29:27 --> Language Class Initialized
INFO - 2018-10-12 17:29:27 --> Loader Class Initialized
INFO - 2018-10-12 17:29:27 --> Helper loaded: url_helper
INFO - 2018-10-12 17:29:27 --> Helper loaded: form_helper
INFO - 2018-10-12 17:29:27 --> Helper loaded: language_helper
DEBUG - 2018-10-12 17:29:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 17:29:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 17:29:27 --> User Agent Class Initialized
INFO - 2018-10-12 17:29:27 --> Controller Class Initialized
INFO - 2018-10-12 17:29:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 17:29:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 17:29:27 --> Pixel_Model class loaded
INFO - 2018-10-12 17:29:27 --> Database Driver Class Initialized
INFO - 2018-10-12 17:29:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:29:27 --> Form Validation Class Initialized
INFO - 2018-10-12 17:29:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-12 17:29:27 --> Database Driver Class Initialized
INFO - 2018-10-12 17:29:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:29:27 --> Config Class Initialized
INFO - 2018-10-12 17:29:27 --> Hooks Class Initialized
DEBUG - 2018-10-12 17:29:27 --> UTF-8 Support Enabled
INFO - 2018-10-12 17:29:27 --> Utf8 Class Initialized
INFO - 2018-10-12 17:29:27 --> URI Class Initialized
INFO - 2018-10-12 17:29:27 --> Router Class Initialized
INFO - 2018-10-12 17:29:27 --> Output Class Initialized
INFO - 2018-10-12 17:29:27 --> Security Class Initialized
DEBUG - 2018-10-12 17:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 17:29:27 --> CSRF cookie sent
INFO - 2018-10-12 17:29:27 --> Input Class Initialized
INFO - 2018-10-12 17:29:27 --> Language Class Initialized
INFO - 2018-10-12 17:29:27 --> Loader Class Initialized
INFO - 2018-10-12 17:29:27 --> Helper loaded: url_helper
INFO - 2018-10-12 17:29:27 --> Helper loaded: form_helper
INFO - 2018-10-12 17:29:27 --> Helper loaded: language_helper
DEBUG - 2018-10-12 17:29:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 17:29:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 17:29:27 --> User Agent Class Initialized
INFO - 2018-10-12 17:29:27 --> Controller Class Initialized
INFO - 2018-10-12 17:29:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 17:29:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 17:29:27 --> Pixel_Model class loaded
INFO - 2018-10-12 17:29:27 --> Database Driver Class Initialized
INFO - 2018-10-12 17:29:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:29:27 --> Database Driver Class Initialized
INFO - 2018-10-12 17:29:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:29:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 17:29:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 17:29:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 17:29:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 17:29:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-10-12 17:29:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 17:29:27 --> Final output sent to browser
DEBUG - 2018-10-12 17:29:27 --> Total execution time: 0.0392
INFO - 2018-10-12 17:29:30 --> Config Class Initialized
INFO - 2018-10-12 17:29:30 --> Hooks Class Initialized
DEBUG - 2018-10-12 17:29:30 --> UTF-8 Support Enabled
INFO - 2018-10-12 17:29:30 --> Utf8 Class Initialized
INFO - 2018-10-12 17:29:30 --> URI Class Initialized
INFO - 2018-10-12 17:29:30 --> Router Class Initialized
INFO - 2018-10-12 17:29:30 --> Output Class Initialized
INFO - 2018-10-12 17:29:30 --> Security Class Initialized
DEBUG - 2018-10-12 17:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 17:29:30 --> CSRF cookie sent
INFO - 2018-10-12 17:29:30 --> Input Class Initialized
INFO - 2018-10-12 17:29:30 --> Language Class Initialized
INFO - 2018-10-12 17:29:30 --> Loader Class Initialized
INFO - 2018-10-12 17:29:30 --> Helper loaded: url_helper
INFO - 2018-10-12 17:29:30 --> Helper loaded: form_helper
INFO - 2018-10-12 17:29:30 --> Helper loaded: language_helper
DEBUG - 2018-10-12 17:29:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 17:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 17:29:30 --> User Agent Class Initialized
INFO - 2018-10-12 17:29:30 --> Controller Class Initialized
INFO - 2018-10-12 17:29:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 17:29:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 17:29:30 --> Pixel_Model class loaded
INFO - 2018-10-12 17:29:30 --> Database Driver Class Initialized
INFO - 2018-10-12 17:29:30 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:29:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 17:29:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 17:29:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 17:29:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 17:29:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 17:29:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 17:29:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-10-12 17:29:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 17:29:30 --> Final output sent to browser
DEBUG - 2018-10-12 17:29:30 --> Total execution time: 0.0373
INFO - 2018-10-12 17:29:31 --> Config Class Initialized
INFO - 2018-10-12 17:29:31 --> Hooks Class Initialized
DEBUG - 2018-10-12 17:29:31 --> UTF-8 Support Enabled
INFO - 2018-10-12 17:29:31 --> Utf8 Class Initialized
INFO - 2018-10-12 17:29:31 --> URI Class Initialized
INFO - 2018-10-12 17:29:31 --> Router Class Initialized
INFO - 2018-10-12 17:29:31 --> Output Class Initialized
INFO - 2018-10-12 17:29:31 --> Security Class Initialized
DEBUG - 2018-10-12 17:29:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 17:29:31 --> CSRF cookie sent
INFO - 2018-10-12 17:29:31 --> CSRF token verified
INFO - 2018-10-12 17:29:31 --> Input Class Initialized
INFO - 2018-10-12 17:29:31 --> Language Class Initialized
INFO - 2018-10-12 17:29:31 --> Loader Class Initialized
INFO - 2018-10-12 17:29:31 --> Helper loaded: url_helper
INFO - 2018-10-12 17:29:31 --> Helper loaded: form_helper
INFO - 2018-10-12 17:29:31 --> Helper loaded: language_helper
DEBUG - 2018-10-12 17:29:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 17:29:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 17:29:31 --> User Agent Class Initialized
INFO - 2018-10-12 17:29:31 --> Controller Class Initialized
INFO - 2018-10-12 17:29:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 17:29:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 17:29:31 --> Pixel_Model class loaded
INFO - 2018-10-12 17:29:31 --> Database Driver Class Initialized
INFO - 2018-10-12 17:29:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:29:31 --> Form Validation Class Initialized
INFO - 2018-10-12 17:29:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-12 17:29:31 --> Database Driver Class Initialized
INFO - 2018-10-12 17:29:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:29:32 --> Config Class Initialized
INFO - 2018-10-12 17:29:32 --> Hooks Class Initialized
DEBUG - 2018-10-12 17:29:32 --> UTF-8 Support Enabled
INFO - 2018-10-12 17:29:32 --> Utf8 Class Initialized
INFO - 2018-10-12 17:29:32 --> URI Class Initialized
INFO - 2018-10-12 17:29:32 --> Router Class Initialized
INFO - 2018-10-12 17:29:32 --> Output Class Initialized
INFO - 2018-10-12 17:29:32 --> Security Class Initialized
DEBUG - 2018-10-12 17:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 17:29:32 --> CSRF cookie sent
INFO - 2018-10-12 17:29:32 --> Input Class Initialized
INFO - 2018-10-12 17:29:32 --> Language Class Initialized
INFO - 2018-10-12 17:29:32 --> Loader Class Initialized
INFO - 2018-10-12 17:29:32 --> Helper loaded: url_helper
INFO - 2018-10-12 17:29:32 --> Helper loaded: form_helper
INFO - 2018-10-12 17:29:32 --> Helper loaded: language_helper
DEBUG - 2018-10-12 17:29:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 17:29:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 17:29:32 --> User Agent Class Initialized
INFO - 2018-10-12 17:29:32 --> Controller Class Initialized
INFO - 2018-10-12 17:29:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 17:29:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 17:29:32 --> Pixel_Model class loaded
INFO - 2018-10-12 17:29:32 --> Database Driver Class Initialized
INFO - 2018-10-12 17:29:32 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:29:32 --> Database Driver Class Initialized
INFO - 2018-10-12 17:29:32 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:29:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 17:29:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 17:29:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 17:29:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 17:29:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 17:29:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 17:29:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-12 17:29:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 17:29:32 --> Final output sent to browser
DEBUG - 2018-10-12 17:29:32 --> Total execution time: 0.0590
INFO - 2018-10-12 17:29:43 --> Config Class Initialized
INFO - 2018-10-12 17:29:43 --> Hooks Class Initialized
DEBUG - 2018-10-12 17:29:43 --> UTF-8 Support Enabled
INFO - 2018-10-12 17:29:43 --> Utf8 Class Initialized
INFO - 2018-10-12 17:29:43 --> URI Class Initialized
DEBUG - 2018-10-12 17:29:43 --> No URI present. Default controller set.
INFO - 2018-10-12 17:29:43 --> Router Class Initialized
INFO - 2018-10-12 17:29:43 --> Output Class Initialized
INFO - 2018-10-12 17:29:43 --> Security Class Initialized
DEBUG - 2018-10-12 17:29:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 17:29:43 --> CSRF cookie sent
INFO - 2018-10-12 17:29:43 --> Input Class Initialized
INFO - 2018-10-12 17:29:43 --> Language Class Initialized
INFO - 2018-10-12 17:29:43 --> Loader Class Initialized
INFO - 2018-10-12 17:29:43 --> Helper loaded: url_helper
INFO - 2018-10-12 17:29:43 --> Helper loaded: form_helper
INFO - 2018-10-12 17:29:43 --> Helper loaded: language_helper
DEBUG - 2018-10-12 17:29:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 17:29:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 17:29:43 --> User Agent Class Initialized
INFO - 2018-10-12 17:29:43 --> Controller Class Initialized
INFO - 2018-10-12 17:29:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 17:29:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 17:29:43 --> Pixel_Model class loaded
INFO - 2018-10-12 17:29:43 --> Database Driver Class Initialized
INFO - 2018-10-12 17:29:43 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:29:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 17:29:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 17:29:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-12 17:29:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 17:29:43 --> Final output sent to browser
DEBUG - 2018-10-12 17:29:43 --> Total execution time: 0.0349
INFO - 2018-10-12 17:29:50 --> Config Class Initialized
INFO - 2018-10-12 17:29:50 --> Hooks Class Initialized
DEBUG - 2018-10-12 17:29:50 --> UTF-8 Support Enabled
INFO - 2018-10-12 17:29:50 --> Utf8 Class Initialized
INFO - 2018-10-12 17:29:50 --> URI Class Initialized
INFO - 2018-10-12 17:29:50 --> Router Class Initialized
INFO - 2018-10-12 17:29:50 --> Output Class Initialized
INFO - 2018-10-12 17:29:50 --> Security Class Initialized
DEBUG - 2018-10-12 17:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 17:29:50 --> CSRF cookie sent
INFO - 2018-10-12 17:29:50 --> Input Class Initialized
INFO - 2018-10-12 17:29:50 --> Language Class Initialized
INFO - 2018-10-12 17:29:50 --> Loader Class Initialized
INFO - 2018-10-12 17:29:50 --> Helper loaded: url_helper
INFO - 2018-10-12 17:29:50 --> Helper loaded: form_helper
INFO - 2018-10-12 17:29:50 --> Helper loaded: language_helper
DEBUG - 2018-10-12 17:29:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 17:29:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 17:29:50 --> User Agent Class Initialized
INFO - 2018-10-12 17:29:50 --> Controller Class Initialized
INFO - 2018-10-12 17:29:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 17:29:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 17:29:50 --> Pixel_Model class loaded
INFO - 2018-10-12 17:29:50 --> Database Driver Class Initialized
INFO - 2018-10-12 17:29:50 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:29:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 17:29:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 17:29:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 17:29:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 17:29:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 17:29:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 17:29:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-10-12 17:29:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 17:29:50 --> Final output sent to browser
DEBUG - 2018-10-12 17:29:50 --> Total execution time: 0.0381
INFO - 2018-10-12 17:29:57 --> Config Class Initialized
INFO - 2018-10-12 17:29:57 --> Hooks Class Initialized
DEBUG - 2018-10-12 17:29:57 --> UTF-8 Support Enabled
INFO - 2018-10-12 17:29:57 --> Utf8 Class Initialized
INFO - 2018-10-12 17:29:57 --> URI Class Initialized
INFO - 2018-10-12 17:29:57 --> Router Class Initialized
INFO - 2018-10-12 17:29:57 --> Output Class Initialized
INFO - 2018-10-12 17:29:57 --> Security Class Initialized
DEBUG - 2018-10-12 17:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 17:29:57 --> CSRF cookie sent
INFO - 2018-10-12 17:29:57 --> CSRF token verified
INFO - 2018-10-12 17:29:57 --> Input Class Initialized
INFO - 2018-10-12 17:29:57 --> Language Class Initialized
INFO - 2018-10-12 17:29:57 --> Loader Class Initialized
INFO - 2018-10-12 17:29:57 --> Helper loaded: url_helper
INFO - 2018-10-12 17:29:57 --> Helper loaded: form_helper
INFO - 2018-10-12 17:29:57 --> Helper loaded: language_helper
DEBUG - 2018-10-12 17:29:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 17:29:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 17:29:57 --> User Agent Class Initialized
INFO - 2018-10-12 17:29:57 --> Controller Class Initialized
INFO - 2018-10-12 17:29:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 17:29:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 17:29:57 --> Pixel_Model class loaded
INFO - 2018-10-12 17:29:57 --> Database Driver Class Initialized
INFO - 2018-10-12 17:29:57 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:29:57 --> Form Validation Class Initialized
INFO - 2018-10-12 17:29:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-12 17:29:57 --> Database Driver Class Initialized
INFO - 2018-10-12 17:29:57 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:29:57 --> Config Class Initialized
INFO - 2018-10-12 17:29:57 --> Hooks Class Initialized
DEBUG - 2018-10-12 17:29:57 --> UTF-8 Support Enabled
INFO - 2018-10-12 17:29:57 --> Utf8 Class Initialized
INFO - 2018-10-12 17:29:57 --> URI Class Initialized
INFO - 2018-10-12 17:29:57 --> Router Class Initialized
INFO - 2018-10-12 17:29:57 --> Output Class Initialized
INFO - 2018-10-12 17:29:57 --> Security Class Initialized
DEBUG - 2018-10-12 17:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 17:29:57 --> CSRF cookie sent
INFO - 2018-10-12 17:29:57 --> Input Class Initialized
INFO - 2018-10-12 17:29:57 --> Language Class Initialized
INFO - 2018-10-12 17:29:57 --> Loader Class Initialized
INFO - 2018-10-12 17:29:57 --> Helper loaded: url_helper
INFO - 2018-10-12 17:29:57 --> Helper loaded: form_helper
INFO - 2018-10-12 17:29:57 --> Helper loaded: language_helper
DEBUG - 2018-10-12 17:29:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 17:29:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 17:29:57 --> User Agent Class Initialized
INFO - 2018-10-12 17:29:57 --> Controller Class Initialized
INFO - 2018-10-12 17:29:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 17:29:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 17:29:57 --> Pixel_Model class loaded
INFO - 2018-10-12 17:29:57 --> Database Driver Class Initialized
INFO - 2018-10-12 17:29:57 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:29:57 --> Database Driver Class Initialized
INFO - 2018-10-12 17:29:57 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:29:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 17:29:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 17:29:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 17:29:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 17:29:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 17:29:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 17:29:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-12 17:29:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 17:29:57 --> Final output sent to browser
DEBUG - 2018-10-12 17:29:57 --> Total execution time: 0.0470
INFO - 2018-10-12 17:30:08 --> Config Class Initialized
INFO - 2018-10-12 17:30:08 --> Hooks Class Initialized
DEBUG - 2018-10-12 17:30:08 --> UTF-8 Support Enabled
INFO - 2018-10-12 17:30:08 --> Utf8 Class Initialized
INFO - 2018-10-12 17:30:08 --> URI Class Initialized
INFO - 2018-10-12 17:30:08 --> Router Class Initialized
INFO - 2018-10-12 17:30:08 --> Output Class Initialized
INFO - 2018-10-12 17:30:08 --> Security Class Initialized
DEBUG - 2018-10-12 17:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 17:30:08 --> CSRF cookie sent
INFO - 2018-10-12 17:30:08 --> CSRF token verified
INFO - 2018-10-12 17:30:08 --> Input Class Initialized
INFO - 2018-10-12 17:30:08 --> Language Class Initialized
INFO - 2018-10-12 17:30:08 --> Loader Class Initialized
INFO - 2018-10-12 17:30:08 --> Helper loaded: url_helper
INFO - 2018-10-12 17:30:08 --> Helper loaded: form_helper
INFO - 2018-10-12 17:30:08 --> Helper loaded: language_helper
DEBUG - 2018-10-12 17:30:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 17:30:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 17:30:08 --> User Agent Class Initialized
INFO - 2018-10-12 17:30:08 --> Controller Class Initialized
INFO - 2018-10-12 17:30:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 17:30:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 17:30:08 --> Pixel_Model class loaded
INFO - 2018-10-12 17:30:08 --> Database Driver Class Initialized
INFO - 2018-10-12 17:30:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:30:08 --> Form Validation Class Initialized
INFO - 2018-10-12 17:30:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-12 17:30:08 --> Database Driver Class Initialized
INFO - 2018-10-12 17:30:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:30:08 --> Config Class Initialized
INFO - 2018-10-12 17:30:08 --> Hooks Class Initialized
DEBUG - 2018-10-12 17:30:08 --> UTF-8 Support Enabled
INFO - 2018-10-12 17:30:08 --> Utf8 Class Initialized
INFO - 2018-10-12 17:30:08 --> URI Class Initialized
INFO - 2018-10-12 17:30:08 --> Router Class Initialized
INFO - 2018-10-12 17:30:08 --> Output Class Initialized
INFO - 2018-10-12 17:30:08 --> Security Class Initialized
DEBUG - 2018-10-12 17:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 17:30:08 --> CSRF cookie sent
INFO - 2018-10-12 17:30:08 --> Input Class Initialized
INFO - 2018-10-12 17:30:08 --> Language Class Initialized
INFO - 2018-10-12 17:30:08 --> Loader Class Initialized
INFO - 2018-10-12 17:30:08 --> Helper loaded: url_helper
INFO - 2018-10-12 17:30:08 --> Helper loaded: form_helper
INFO - 2018-10-12 17:30:08 --> Helper loaded: language_helper
DEBUG - 2018-10-12 17:30:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 17:30:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 17:30:08 --> User Agent Class Initialized
INFO - 2018-10-12 17:30:08 --> Controller Class Initialized
INFO - 2018-10-12 17:30:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 17:30:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 17:30:08 --> Pixel_Model class loaded
INFO - 2018-10-12 17:30:08 --> Database Driver Class Initialized
INFO - 2018-10-12 17:30:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:30:08 --> Database Driver Class Initialized
INFO - 2018-10-12 17:30:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:30:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 17:30:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 17:30:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 17:30:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 17:30:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 17:30:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 17:30:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-10-12 17:30:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 17:30:08 --> Final output sent to browser
DEBUG - 2018-10-12 17:30:08 --> Total execution time: 0.0489
INFO - 2018-10-12 17:30:10 --> Config Class Initialized
INFO - 2018-10-12 17:30:10 --> Hooks Class Initialized
DEBUG - 2018-10-12 17:30:10 --> UTF-8 Support Enabled
INFO - 2018-10-12 17:30:10 --> Utf8 Class Initialized
INFO - 2018-10-12 17:30:10 --> URI Class Initialized
INFO - 2018-10-12 17:30:10 --> Router Class Initialized
INFO - 2018-10-12 17:30:10 --> Output Class Initialized
INFO - 2018-10-12 17:30:10 --> Security Class Initialized
DEBUG - 2018-10-12 17:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 17:30:10 --> CSRF cookie sent
INFO - 2018-10-12 17:30:10 --> CSRF token verified
INFO - 2018-10-12 17:30:10 --> Input Class Initialized
INFO - 2018-10-12 17:30:10 --> Language Class Initialized
INFO - 2018-10-12 17:30:10 --> Loader Class Initialized
INFO - 2018-10-12 17:30:10 --> Helper loaded: url_helper
INFO - 2018-10-12 17:30:10 --> Helper loaded: form_helper
INFO - 2018-10-12 17:30:10 --> Helper loaded: language_helper
DEBUG - 2018-10-12 17:30:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 17:30:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 17:30:10 --> User Agent Class Initialized
INFO - 2018-10-12 17:30:10 --> Controller Class Initialized
INFO - 2018-10-12 17:30:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 17:30:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 17:30:10 --> Pixel_Model class loaded
INFO - 2018-10-12 17:30:10 --> Database Driver Class Initialized
INFO - 2018-10-12 17:30:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:30:10 --> Form Validation Class Initialized
INFO - 2018-10-12 17:30:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-12 17:30:10 --> Database Driver Class Initialized
INFO - 2018-10-12 17:30:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:30:11 --> Config Class Initialized
INFO - 2018-10-12 17:30:11 --> Hooks Class Initialized
DEBUG - 2018-10-12 17:30:11 --> UTF-8 Support Enabled
INFO - 2018-10-12 17:30:11 --> Utf8 Class Initialized
INFO - 2018-10-12 17:30:11 --> URI Class Initialized
INFO - 2018-10-12 17:30:11 --> Router Class Initialized
INFO - 2018-10-12 17:30:11 --> Output Class Initialized
INFO - 2018-10-12 17:30:11 --> Security Class Initialized
DEBUG - 2018-10-12 17:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 17:30:11 --> CSRF cookie sent
INFO - 2018-10-12 17:30:11 --> Input Class Initialized
INFO - 2018-10-12 17:30:11 --> Language Class Initialized
INFO - 2018-10-12 17:30:11 --> Loader Class Initialized
INFO - 2018-10-12 17:30:11 --> Helper loaded: url_helper
INFO - 2018-10-12 17:30:11 --> Helper loaded: form_helper
INFO - 2018-10-12 17:30:11 --> Helper loaded: language_helper
DEBUG - 2018-10-12 17:30:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 17:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 17:30:11 --> User Agent Class Initialized
INFO - 2018-10-12 17:30:11 --> Controller Class Initialized
INFO - 2018-10-12 17:30:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 17:30:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 17:30:11 --> Pixel_Model class loaded
INFO - 2018-10-12 17:30:11 --> Database Driver Class Initialized
INFO - 2018-10-12 17:30:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:30:11 --> Database Driver Class Initialized
INFO - 2018-10-12 17:30:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:30:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 17:30:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 17:30:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-10-12 17:30:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 17:30:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 17:30:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 17:30:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 17:30:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-10-12 17:30:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 17:30:11 --> Final output sent to browser
DEBUG - 2018-10-12 17:30:11 --> Total execution time: 0.0469
INFO - 2018-10-12 17:30:12 --> Config Class Initialized
INFO - 2018-10-12 17:30:12 --> Hooks Class Initialized
DEBUG - 2018-10-12 17:30:12 --> UTF-8 Support Enabled
INFO - 2018-10-12 17:30:12 --> Utf8 Class Initialized
INFO - 2018-10-12 17:30:12 --> URI Class Initialized
INFO - 2018-10-12 17:30:12 --> Router Class Initialized
INFO - 2018-10-12 17:30:12 --> Output Class Initialized
INFO - 2018-10-12 17:30:12 --> Security Class Initialized
DEBUG - 2018-10-12 17:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 17:30:12 --> CSRF cookie sent
INFO - 2018-10-12 17:30:12 --> CSRF token verified
INFO - 2018-10-12 17:30:12 --> Input Class Initialized
INFO - 2018-10-12 17:30:12 --> Language Class Initialized
INFO - 2018-10-12 17:30:12 --> Loader Class Initialized
INFO - 2018-10-12 17:30:12 --> Helper loaded: url_helper
INFO - 2018-10-12 17:30:12 --> Helper loaded: form_helper
INFO - 2018-10-12 17:30:12 --> Helper loaded: language_helper
DEBUG - 2018-10-12 17:30:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 17:30:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 17:30:12 --> User Agent Class Initialized
INFO - 2018-10-12 17:30:12 --> Controller Class Initialized
INFO - 2018-10-12 17:30:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 17:30:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 17:30:12 --> Pixel_Model class loaded
INFO - 2018-10-12 17:30:12 --> Database Driver Class Initialized
INFO - 2018-10-12 17:30:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:30:12 --> Form Validation Class Initialized
INFO - 2018-10-12 17:30:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-12 17:30:12 --> Database Driver Class Initialized
INFO - 2018-10-12 17:30:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:30:13 --> Config Class Initialized
INFO - 2018-10-12 17:30:13 --> Hooks Class Initialized
DEBUG - 2018-10-12 17:30:13 --> UTF-8 Support Enabled
INFO - 2018-10-12 17:30:13 --> Utf8 Class Initialized
INFO - 2018-10-12 17:30:13 --> URI Class Initialized
INFO - 2018-10-12 17:30:13 --> Router Class Initialized
INFO - 2018-10-12 17:30:13 --> Output Class Initialized
INFO - 2018-10-12 17:30:13 --> Security Class Initialized
DEBUG - 2018-10-12 17:30:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 17:30:13 --> CSRF cookie sent
INFO - 2018-10-12 17:30:13 --> Input Class Initialized
INFO - 2018-10-12 17:30:13 --> Language Class Initialized
INFO - 2018-10-12 17:30:13 --> Loader Class Initialized
INFO - 2018-10-12 17:30:13 --> Helper loaded: url_helper
INFO - 2018-10-12 17:30:13 --> Helper loaded: form_helper
INFO - 2018-10-12 17:30:13 --> Helper loaded: language_helper
DEBUG - 2018-10-12 17:30:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 17:30:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 17:30:13 --> User Agent Class Initialized
INFO - 2018-10-12 17:30:13 --> Controller Class Initialized
INFO - 2018-10-12 17:30:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 17:30:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 17:30:13 --> Pixel_Model class loaded
INFO - 2018-10-12 17:30:13 --> Database Driver Class Initialized
INFO - 2018-10-12 17:30:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:30:13 --> Database Driver Class Initialized
INFO - 2018-10-12 17:30:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:30:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 17:30:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 17:30:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 17:30:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 17:30:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 17:30:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 17:30:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-12 17:30:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 17:30:13 --> Final output sent to browser
DEBUG - 2018-10-12 17:30:13 --> Total execution time: 0.0450
INFO - 2018-10-12 17:30:20 --> Config Class Initialized
INFO - 2018-10-12 17:30:20 --> Hooks Class Initialized
DEBUG - 2018-10-12 17:30:20 --> UTF-8 Support Enabled
INFO - 2018-10-12 17:30:20 --> Utf8 Class Initialized
INFO - 2018-10-12 17:30:20 --> URI Class Initialized
INFO - 2018-10-12 17:30:20 --> Router Class Initialized
INFO - 2018-10-12 17:30:20 --> Output Class Initialized
INFO - 2018-10-12 17:30:20 --> Security Class Initialized
DEBUG - 2018-10-12 17:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 17:30:20 --> CSRF cookie sent
INFO - 2018-10-12 17:30:20 --> CSRF token verified
INFO - 2018-10-12 17:30:20 --> Input Class Initialized
INFO - 2018-10-12 17:30:20 --> Language Class Initialized
INFO - 2018-10-12 17:30:20 --> Loader Class Initialized
INFO - 2018-10-12 17:30:20 --> Helper loaded: url_helper
INFO - 2018-10-12 17:30:20 --> Helper loaded: form_helper
INFO - 2018-10-12 17:30:20 --> Helper loaded: language_helper
DEBUG - 2018-10-12 17:30:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 17:30:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 17:30:20 --> User Agent Class Initialized
INFO - 2018-10-12 17:30:20 --> Controller Class Initialized
INFO - 2018-10-12 17:30:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 17:30:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 17:30:20 --> Pixel_Model class loaded
INFO - 2018-10-12 17:30:20 --> Database Driver Class Initialized
INFO - 2018-10-12 17:30:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:30:20 --> Form Validation Class Initialized
INFO - 2018-10-12 17:30:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-12 17:30:20 --> Database Driver Class Initialized
INFO - 2018-10-12 17:30:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:30:20 --> Config Class Initialized
INFO - 2018-10-12 17:30:20 --> Hooks Class Initialized
DEBUG - 2018-10-12 17:30:20 --> UTF-8 Support Enabled
INFO - 2018-10-12 17:30:20 --> Utf8 Class Initialized
INFO - 2018-10-12 17:30:20 --> URI Class Initialized
INFO - 2018-10-12 17:30:20 --> Router Class Initialized
INFO - 2018-10-12 17:30:20 --> Output Class Initialized
INFO - 2018-10-12 17:30:20 --> Security Class Initialized
DEBUG - 2018-10-12 17:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 17:30:20 --> CSRF cookie sent
INFO - 2018-10-12 17:30:20 --> Input Class Initialized
INFO - 2018-10-12 17:30:20 --> Language Class Initialized
INFO - 2018-10-12 17:30:20 --> Loader Class Initialized
INFO - 2018-10-12 17:30:20 --> Helper loaded: url_helper
INFO - 2018-10-12 17:30:20 --> Helper loaded: form_helper
INFO - 2018-10-12 17:30:20 --> Helper loaded: language_helper
DEBUG - 2018-10-12 17:30:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 17:30:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 17:30:20 --> User Agent Class Initialized
INFO - 2018-10-12 17:30:20 --> Controller Class Initialized
INFO - 2018-10-12 17:30:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 17:30:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 17:30:20 --> Pixel_Model class loaded
INFO - 2018-10-12 17:30:20 --> Database Driver Class Initialized
INFO - 2018-10-12 17:30:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:30:20 --> Database Driver Class Initialized
INFO - 2018-10-12 17:30:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:30:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 17:30:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 17:30:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 17:30:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 17:30:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 17:30:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 17:30:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-10-12 17:30:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 17:30:20 --> Final output sent to browser
DEBUG - 2018-10-12 17:30:20 --> Total execution time: 0.0543
INFO - 2018-10-12 17:30:24 --> Config Class Initialized
INFO - 2018-10-12 17:30:24 --> Hooks Class Initialized
DEBUG - 2018-10-12 17:30:24 --> UTF-8 Support Enabled
INFO - 2018-10-12 17:30:24 --> Utf8 Class Initialized
INFO - 2018-10-12 17:30:24 --> URI Class Initialized
INFO - 2018-10-12 17:30:24 --> Router Class Initialized
INFO - 2018-10-12 17:30:24 --> Output Class Initialized
INFO - 2018-10-12 17:30:24 --> Security Class Initialized
DEBUG - 2018-10-12 17:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 17:30:24 --> CSRF cookie sent
INFO - 2018-10-12 17:30:24 --> CSRF token verified
INFO - 2018-10-12 17:30:24 --> Input Class Initialized
INFO - 2018-10-12 17:30:24 --> Language Class Initialized
INFO - 2018-10-12 17:30:24 --> Loader Class Initialized
INFO - 2018-10-12 17:30:24 --> Helper loaded: url_helper
INFO - 2018-10-12 17:30:24 --> Helper loaded: form_helper
INFO - 2018-10-12 17:30:24 --> Helper loaded: language_helper
DEBUG - 2018-10-12 17:30:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 17:30:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 17:30:24 --> User Agent Class Initialized
INFO - 2018-10-12 17:30:24 --> Controller Class Initialized
INFO - 2018-10-12 17:30:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 17:30:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 17:30:24 --> Pixel_Model class loaded
INFO - 2018-10-12 17:30:24 --> Database Driver Class Initialized
INFO - 2018-10-12 17:30:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:30:24 --> Form Validation Class Initialized
INFO - 2018-10-12 17:30:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-12 17:30:24 --> Database Driver Class Initialized
INFO - 2018-10-12 17:30:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:30:25 --> Config Class Initialized
INFO - 2018-10-12 17:30:25 --> Hooks Class Initialized
DEBUG - 2018-10-12 17:30:25 --> UTF-8 Support Enabled
INFO - 2018-10-12 17:30:25 --> Utf8 Class Initialized
INFO - 2018-10-12 17:30:25 --> URI Class Initialized
INFO - 2018-10-12 17:30:25 --> Router Class Initialized
INFO - 2018-10-12 17:30:25 --> Output Class Initialized
INFO - 2018-10-12 17:30:25 --> Security Class Initialized
DEBUG - 2018-10-12 17:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 17:30:25 --> CSRF cookie sent
INFO - 2018-10-12 17:30:25 --> Input Class Initialized
INFO - 2018-10-12 17:30:25 --> Language Class Initialized
INFO - 2018-10-12 17:30:25 --> Loader Class Initialized
INFO - 2018-10-12 17:30:25 --> Helper loaded: url_helper
INFO - 2018-10-12 17:30:25 --> Helper loaded: form_helper
INFO - 2018-10-12 17:30:25 --> Helper loaded: language_helper
DEBUG - 2018-10-12 17:30:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 17:30:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 17:30:25 --> User Agent Class Initialized
INFO - 2018-10-12 17:30:25 --> Controller Class Initialized
INFO - 2018-10-12 17:30:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 17:30:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 17:30:25 --> Pixel_Model class loaded
INFO - 2018-10-12 17:30:25 --> Database Driver Class Initialized
INFO - 2018-10-12 17:30:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:30:25 --> Database Driver Class Initialized
INFO - 2018-10-12 17:30:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:30:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 17:30:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 17:30:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 17:30:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 17:30:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 17:30:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 17:30:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_title.php
INFO - 2018-10-12 17:30:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 17:30:25 --> Final output sent to browser
DEBUG - 2018-10-12 17:30:25 --> Total execution time: 0.0492
INFO - 2018-10-12 17:30:29 --> Config Class Initialized
INFO - 2018-10-12 17:30:29 --> Hooks Class Initialized
DEBUG - 2018-10-12 17:30:29 --> UTF-8 Support Enabled
INFO - 2018-10-12 17:30:29 --> Utf8 Class Initialized
INFO - 2018-10-12 17:30:29 --> URI Class Initialized
INFO - 2018-10-12 17:30:29 --> Router Class Initialized
INFO - 2018-10-12 17:30:29 --> Output Class Initialized
INFO - 2018-10-12 17:30:29 --> Security Class Initialized
DEBUG - 2018-10-12 17:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 17:30:29 --> CSRF cookie sent
INFO - 2018-10-12 17:30:29 --> CSRF token verified
INFO - 2018-10-12 17:30:29 --> Input Class Initialized
INFO - 2018-10-12 17:30:29 --> Language Class Initialized
INFO - 2018-10-12 17:30:29 --> Loader Class Initialized
INFO - 2018-10-12 17:30:29 --> Helper loaded: url_helper
INFO - 2018-10-12 17:30:29 --> Helper loaded: form_helper
INFO - 2018-10-12 17:30:29 --> Helper loaded: language_helper
DEBUG - 2018-10-12 17:30:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 17:30:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 17:30:29 --> User Agent Class Initialized
INFO - 2018-10-12 17:30:29 --> Controller Class Initialized
INFO - 2018-10-12 17:30:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 17:30:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 17:30:29 --> Pixel_Model class loaded
INFO - 2018-10-12 17:30:29 --> Database Driver Class Initialized
INFO - 2018-10-12 17:30:29 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:30:29 --> Form Validation Class Initialized
INFO - 2018-10-12 17:30:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-12 17:30:29 --> Database Driver Class Initialized
INFO - 2018-10-12 17:30:29 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:30:29 --> Config Class Initialized
INFO - 2018-10-12 17:30:29 --> Hooks Class Initialized
DEBUG - 2018-10-12 17:30:29 --> UTF-8 Support Enabled
INFO - 2018-10-12 17:30:29 --> Utf8 Class Initialized
INFO - 2018-10-12 17:30:29 --> URI Class Initialized
INFO - 2018-10-12 17:30:29 --> Router Class Initialized
INFO - 2018-10-12 17:30:29 --> Output Class Initialized
INFO - 2018-10-12 17:30:29 --> Security Class Initialized
DEBUG - 2018-10-12 17:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 17:30:29 --> CSRF cookie sent
INFO - 2018-10-12 17:30:29 --> Input Class Initialized
INFO - 2018-10-12 17:30:29 --> Language Class Initialized
INFO - 2018-10-12 17:30:29 --> Loader Class Initialized
INFO - 2018-10-12 17:30:29 --> Helper loaded: url_helper
INFO - 2018-10-12 17:30:29 --> Helper loaded: form_helper
INFO - 2018-10-12 17:30:29 --> Helper loaded: language_helper
DEBUG - 2018-10-12 17:30:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 17:30:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 17:30:29 --> User Agent Class Initialized
INFO - 2018-10-12 17:30:29 --> Controller Class Initialized
INFO - 2018-10-12 17:30:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 17:30:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 17:30:29 --> Pixel_Model class loaded
INFO - 2018-10-12 17:30:29 --> Database Driver Class Initialized
INFO - 2018-10-12 17:30:29 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:30:29 --> Database Driver Class Initialized
INFO - 2018-10-12 17:30:29 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:30:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 17:30:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 17:30:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 17:30:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 17:30:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 17:30:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 17:30:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-10-12 17:30:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 17:30:29 --> Final output sent to browser
DEBUG - 2018-10-12 17:30:29 --> Total execution time: 0.0385
INFO - 2018-10-12 17:30:31 --> Config Class Initialized
INFO - 2018-10-12 17:30:31 --> Hooks Class Initialized
DEBUG - 2018-10-12 17:30:31 --> UTF-8 Support Enabled
INFO - 2018-10-12 17:30:31 --> Utf8 Class Initialized
INFO - 2018-10-12 17:30:31 --> URI Class Initialized
INFO - 2018-10-12 17:30:32 --> Router Class Initialized
INFO - 2018-10-12 17:30:32 --> Output Class Initialized
INFO - 2018-10-12 17:30:32 --> Security Class Initialized
DEBUG - 2018-10-12 17:30:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 17:30:32 --> CSRF cookie sent
INFO - 2018-10-12 17:30:32 --> CSRF token verified
INFO - 2018-10-12 17:30:32 --> Input Class Initialized
INFO - 2018-10-12 17:30:32 --> Language Class Initialized
INFO - 2018-10-12 17:30:32 --> Loader Class Initialized
INFO - 2018-10-12 17:30:32 --> Helper loaded: url_helper
INFO - 2018-10-12 17:30:32 --> Helper loaded: form_helper
INFO - 2018-10-12 17:30:32 --> Helper loaded: language_helper
DEBUG - 2018-10-12 17:30:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 17:30:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 17:30:32 --> User Agent Class Initialized
INFO - 2018-10-12 17:30:32 --> Controller Class Initialized
INFO - 2018-10-12 17:30:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 17:30:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 17:30:32 --> Pixel_Model class loaded
INFO - 2018-10-12 17:30:32 --> Database Driver Class Initialized
INFO - 2018-10-12 17:30:32 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:30:32 --> Form Validation Class Initialized
INFO - 2018-10-12 17:30:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-12 17:30:32 --> Database Driver Class Initialized
INFO - 2018-10-12 17:30:32 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:30:32 --> Config Class Initialized
INFO - 2018-10-12 17:30:32 --> Hooks Class Initialized
DEBUG - 2018-10-12 17:30:32 --> UTF-8 Support Enabled
INFO - 2018-10-12 17:30:32 --> Utf8 Class Initialized
INFO - 2018-10-12 17:30:32 --> URI Class Initialized
INFO - 2018-10-12 17:30:32 --> Router Class Initialized
INFO - 2018-10-12 17:30:32 --> Output Class Initialized
INFO - 2018-10-12 17:30:32 --> Security Class Initialized
DEBUG - 2018-10-12 17:30:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 17:30:32 --> CSRF cookie sent
INFO - 2018-10-12 17:30:32 --> Input Class Initialized
INFO - 2018-10-12 17:30:32 --> Language Class Initialized
INFO - 2018-10-12 17:30:32 --> Loader Class Initialized
INFO - 2018-10-12 17:30:32 --> Helper loaded: url_helper
INFO - 2018-10-12 17:30:32 --> Helper loaded: form_helper
INFO - 2018-10-12 17:30:32 --> Helper loaded: language_helper
DEBUG - 2018-10-12 17:30:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 17:30:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 17:30:32 --> User Agent Class Initialized
INFO - 2018-10-12 17:30:32 --> Controller Class Initialized
INFO - 2018-10-12 17:30:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 17:30:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 17:30:32 --> Pixel_Model class loaded
INFO - 2018-10-12 17:30:32 --> Database Driver Class Initialized
INFO - 2018-10-12 17:30:32 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:30:32 --> Database Driver Class Initialized
INFO - 2018-10-12 17:30:32 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:30:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 17:30:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 17:30:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 17:30:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 17:30:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-10-12 17:30:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 17:30:32 --> Final output sent to browser
DEBUG - 2018-10-12 17:30:32 --> Total execution time: 0.0474
INFO - 2018-10-12 17:30:36 --> Config Class Initialized
INFO - 2018-10-12 17:30:36 --> Hooks Class Initialized
DEBUG - 2018-10-12 17:30:36 --> UTF-8 Support Enabled
INFO - 2018-10-12 17:30:36 --> Utf8 Class Initialized
INFO - 2018-10-12 17:30:36 --> URI Class Initialized
INFO - 2018-10-12 17:30:36 --> Router Class Initialized
INFO - 2018-10-12 17:30:36 --> Output Class Initialized
INFO - 2018-10-12 17:30:36 --> Security Class Initialized
DEBUG - 2018-10-12 17:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 17:30:36 --> CSRF cookie sent
INFO - 2018-10-12 17:30:36 --> Input Class Initialized
INFO - 2018-10-12 17:30:36 --> Language Class Initialized
INFO - 2018-10-12 17:30:36 --> Loader Class Initialized
INFO - 2018-10-12 17:30:36 --> Helper loaded: url_helper
INFO - 2018-10-12 17:30:36 --> Helper loaded: form_helper
INFO - 2018-10-12 17:30:36 --> Helper loaded: language_helper
DEBUG - 2018-10-12 17:30:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 17:30:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 17:30:36 --> User Agent Class Initialized
INFO - 2018-10-12 17:30:36 --> Controller Class Initialized
INFO - 2018-10-12 17:30:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 17:30:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 17:30:36 --> Pixel_Model class loaded
INFO - 2018-10-12 17:30:36 --> Database Driver Class Initialized
INFO - 2018-10-12 17:30:36 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:30:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 17:30:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 17:30:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 17:30:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 17:30:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 17:30:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 17:30:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-10-12 17:30:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 17:30:36 --> Final output sent to browser
DEBUG - 2018-10-12 17:30:36 --> Total execution time: 0.0427
INFO - 2018-10-12 17:30:38 --> Config Class Initialized
INFO - 2018-10-12 17:30:38 --> Hooks Class Initialized
DEBUG - 2018-10-12 17:30:38 --> UTF-8 Support Enabled
INFO - 2018-10-12 17:30:38 --> Utf8 Class Initialized
INFO - 2018-10-12 17:30:38 --> URI Class Initialized
INFO - 2018-10-12 17:30:38 --> Router Class Initialized
INFO - 2018-10-12 17:30:38 --> Output Class Initialized
INFO - 2018-10-12 17:30:38 --> Security Class Initialized
DEBUG - 2018-10-12 17:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 17:30:38 --> CSRF cookie sent
INFO - 2018-10-12 17:30:38 --> CSRF token verified
INFO - 2018-10-12 17:30:38 --> Input Class Initialized
INFO - 2018-10-12 17:30:38 --> Language Class Initialized
INFO - 2018-10-12 17:30:38 --> Loader Class Initialized
INFO - 2018-10-12 17:30:38 --> Helper loaded: url_helper
INFO - 2018-10-12 17:30:38 --> Helper loaded: form_helper
INFO - 2018-10-12 17:30:38 --> Helper loaded: language_helper
DEBUG - 2018-10-12 17:30:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 17:30:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 17:30:38 --> User Agent Class Initialized
INFO - 2018-10-12 17:30:38 --> Controller Class Initialized
INFO - 2018-10-12 17:30:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 17:30:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 17:30:38 --> Pixel_Model class loaded
INFO - 2018-10-12 17:30:38 --> Database Driver Class Initialized
INFO - 2018-10-12 17:30:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:30:38 --> Form Validation Class Initialized
INFO - 2018-10-12 17:30:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-12 17:30:38 --> Database Driver Class Initialized
INFO - 2018-10-12 17:30:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:30:38 --> Config Class Initialized
INFO - 2018-10-12 17:30:38 --> Hooks Class Initialized
DEBUG - 2018-10-12 17:30:38 --> UTF-8 Support Enabled
INFO - 2018-10-12 17:30:38 --> Utf8 Class Initialized
INFO - 2018-10-12 17:30:38 --> URI Class Initialized
INFO - 2018-10-12 17:30:38 --> Router Class Initialized
INFO - 2018-10-12 17:30:38 --> Output Class Initialized
INFO - 2018-10-12 17:30:38 --> Security Class Initialized
DEBUG - 2018-10-12 17:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 17:30:38 --> CSRF cookie sent
INFO - 2018-10-12 17:30:38 --> Input Class Initialized
INFO - 2018-10-12 17:30:38 --> Language Class Initialized
INFO - 2018-10-12 17:30:38 --> Loader Class Initialized
INFO - 2018-10-12 17:30:38 --> Helper loaded: url_helper
INFO - 2018-10-12 17:30:38 --> Helper loaded: form_helper
INFO - 2018-10-12 17:30:38 --> Helper loaded: language_helper
DEBUG - 2018-10-12 17:30:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 17:30:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 17:30:38 --> User Agent Class Initialized
INFO - 2018-10-12 17:30:38 --> Controller Class Initialized
INFO - 2018-10-12 17:30:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 17:30:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 17:30:38 --> Pixel_Model class loaded
INFO - 2018-10-12 17:30:38 --> Database Driver Class Initialized
INFO - 2018-10-12 17:30:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:30:38 --> Database Driver Class Initialized
INFO - 2018-10-12 17:30:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 17:30:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 17:30:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 17:30:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 17:30:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 17:30:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 17:30:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 17:30:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-12 17:30:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 17:30:38 --> Final output sent to browser
DEBUG - 2018-10-12 17:30:38 --> Total execution time: 0.0708
INFO - 2018-10-12 18:33:29 --> Config Class Initialized
INFO - 2018-10-12 18:33:29 --> Hooks Class Initialized
DEBUG - 2018-10-12 18:33:29 --> UTF-8 Support Enabled
INFO - 2018-10-12 18:33:29 --> Utf8 Class Initialized
INFO - 2018-10-12 18:33:29 --> URI Class Initialized
DEBUG - 2018-10-12 18:33:29 --> No URI present. Default controller set.
INFO - 2018-10-12 18:33:29 --> Router Class Initialized
INFO - 2018-10-12 18:33:29 --> Output Class Initialized
INFO - 2018-10-12 18:33:29 --> Security Class Initialized
DEBUG - 2018-10-12 18:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 18:33:29 --> CSRF cookie sent
INFO - 2018-10-12 18:33:29 --> Input Class Initialized
INFO - 2018-10-12 18:33:29 --> Language Class Initialized
INFO - 2018-10-12 18:33:29 --> Loader Class Initialized
INFO - 2018-10-12 18:33:29 --> Helper loaded: url_helper
INFO - 2018-10-12 18:33:29 --> Helper loaded: form_helper
INFO - 2018-10-12 18:33:29 --> Helper loaded: language_helper
DEBUG - 2018-10-12 18:33:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 18:33:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 18:33:29 --> User Agent Class Initialized
INFO - 2018-10-12 18:33:29 --> Controller Class Initialized
INFO - 2018-10-12 18:33:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 18:33:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 18:33:29 --> Pixel_Model class loaded
INFO - 2018-10-12 18:33:29 --> Database Driver Class Initialized
INFO - 2018-10-12 18:33:29 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:33:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 18:33:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 18:33:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-12 18:33:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 18:33:29 --> Final output sent to browser
DEBUG - 2018-10-12 18:33:29 --> Total execution time: 0.0558
INFO - 2018-10-12 18:33:36 --> Config Class Initialized
INFO - 2018-10-12 18:33:36 --> Hooks Class Initialized
DEBUG - 2018-10-12 18:33:36 --> UTF-8 Support Enabled
INFO - 2018-10-12 18:33:36 --> Utf8 Class Initialized
INFO - 2018-10-12 18:33:36 --> URI Class Initialized
INFO - 2018-10-12 18:33:36 --> Router Class Initialized
INFO - 2018-10-12 18:33:36 --> Output Class Initialized
INFO - 2018-10-12 18:33:36 --> Security Class Initialized
DEBUG - 2018-10-12 18:33:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 18:33:36 --> CSRF cookie sent
INFO - 2018-10-12 18:33:36 --> CSRF token verified
INFO - 2018-10-12 18:33:36 --> Input Class Initialized
INFO - 2018-10-12 18:33:36 --> Language Class Initialized
INFO - 2018-10-12 18:33:36 --> Loader Class Initialized
INFO - 2018-10-12 18:33:36 --> Helper loaded: url_helper
INFO - 2018-10-12 18:33:36 --> Helper loaded: form_helper
INFO - 2018-10-12 18:33:36 --> Helper loaded: language_helper
DEBUG - 2018-10-12 18:33:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 18:33:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 18:33:36 --> User Agent Class Initialized
INFO - 2018-10-12 18:33:36 --> Controller Class Initialized
INFO - 2018-10-12 18:33:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 18:33:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 18:33:36 --> Pixel_Model class loaded
INFO - 2018-10-12 18:33:36 --> Database Driver Class Initialized
INFO - 2018-10-12 18:33:36 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:33:36 --> Form Validation Class Initialized
INFO - 2018-10-12 18:33:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-12 18:33:36 --> Database Driver Class Initialized
INFO - 2018-10-12 18:33:36 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:33:36 --> Config Class Initialized
INFO - 2018-10-12 18:33:36 --> Hooks Class Initialized
DEBUG - 2018-10-12 18:33:36 --> UTF-8 Support Enabled
INFO - 2018-10-12 18:33:36 --> Utf8 Class Initialized
INFO - 2018-10-12 18:33:36 --> URI Class Initialized
INFO - 2018-10-12 18:33:36 --> Router Class Initialized
INFO - 2018-10-12 18:33:36 --> Output Class Initialized
INFO - 2018-10-12 18:33:36 --> Security Class Initialized
DEBUG - 2018-10-12 18:33:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 18:33:36 --> CSRF cookie sent
INFO - 2018-10-12 18:33:36 --> Input Class Initialized
INFO - 2018-10-12 18:33:36 --> Language Class Initialized
INFO - 2018-10-12 18:33:36 --> Loader Class Initialized
INFO - 2018-10-12 18:33:36 --> Helper loaded: url_helper
INFO - 2018-10-12 18:33:36 --> Helper loaded: form_helper
INFO - 2018-10-12 18:33:36 --> Helper loaded: language_helper
DEBUG - 2018-10-12 18:33:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 18:33:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 18:33:36 --> User Agent Class Initialized
INFO - 2018-10-12 18:33:36 --> Controller Class Initialized
INFO - 2018-10-12 18:33:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 18:33:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 18:33:36 --> Pixel_Model class loaded
INFO - 2018-10-12 18:33:36 --> Database Driver Class Initialized
INFO - 2018-10-12 18:33:36 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:33:36 --> Database Driver Class Initialized
INFO - 2018-10-12 18:33:36 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:33:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 18:33:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 18:33:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 18:33:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 18:33:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 18:33:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 18:33:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-12 18:33:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 18:33:36 --> Final output sent to browser
DEBUG - 2018-10-12 18:33:36 --> Total execution time: 0.0467
INFO - 2018-10-12 18:34:07 --> Config Class Initialized
INFO - 2018-10-12 18:34:07 --> Hooks Class Initialized
DEBUG - 2018-10-12 18:34:07 --> UTF-8 Support Enabled
INFO - 2018-10-12 18:34:07 --> Utf8 Class Initialized
INFO - 2018-10-12 18:34:07 --> URI Class Initialized
DEBUG - 2018-10-12 18:34:07 --> No URI present. Default controller set.
INFO - 2018-10-12 18:34:07 --> Router Class Initialized
INFO - 2018-10-12 18:34:07 --> Output Class Initialized
INFO - 2018-10-12 18:34:07 --> Security Class Initialized
DEBUG - 2018-10-12 18:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 18:34:07 --> CSRF cookie sent
INFO - 2018-10-12 18:34:07 --> Input Class Initialized
INFO - 2018-10-12 18:34:07 --> Language Class Initialized
INFO - 2018-10-12 18:34:07 --> Loader Class Initialized
INFO - 2018-10-12 18:34:07 --> Helper loaded: url_helper
INFO - 2018-10-12 18:34:07 --> Helper loaded: form_helper
INFO - 2018-10-12 18:34:07 --> Helper loaded: language_helper
DEBUG - 2018-10-12 18:34:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 18:34:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 18:34:07 --> User Agent Class Initialized
INFO - 2018-10-12 18:34:07 --> Controller Class Initialized
INFO - 2018-10-12 18:34:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 18:34:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 18:34:07 --> Pixel_Model class loaded
INFO - 2018-10-12 18:34:07 --> Database Driver Class Initialized
INFO - 2018-10-12 18:34:07 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:34:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 18:34:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 18:34:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-12 18:34:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 18:34:07 --> Final output sent to browser
DEBUG - 2018-10-12 18:34:07 --> Total execution time: 0.0357
INFO - 2018-10-12 18:34:09 --> Config Class Initialized
INFO - 2018-10-12 18:34:09 --> Hooks Class Initialized
DEBUG - 2018-10-12 18:34:09 --> UTF-8 Support Enabled
INFO - 2018-10-12 18:34:09 --> Utf8 Class Initialized
INFO - 2018-10-12 18:34:09 --> URI Class Initialized
INFO - 2018-10-12 18:34:09 --> Router Class Initialized
INFO - 2018-10-12 18:34:09 --> Output Class Initialized
INFO - 2018-10-12 18:34:09 --> Security Class Initialized
DEBUG - 2018-10-12 18:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 18:34:09 --> CSRF cookie sent
INFO - 2018-10-12 18:34:09 --> CSRF token verified
INFO - 2018-10-12 18:34:09 --> Input Class Initialized
INFO - 2018-10-12 18:34:09 --> Language Class Initialized
INFO - 2018-10-12 18:34:09 --> Loader Class Initialized
INFO - 2018-10-12 18:34:09 --> Helper loaded: url_helper
INFO - 2018-10-12 18:34:09 --> Helper loaded: form_helper
INFO - 2018-10-12 18:34:09 --> Helper loaded: language_helper
DEBUG - 2018-10-12 18:34:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 18:34:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 18:34:09 --> User Agent Class Initialized
INFO - 2018-10-12 18:34:09 --> Controller Class Initialized
INFO - 2018-10-12 18:34:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 18:34:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 18:34:09 --> Pixel_Model class loaded
INFO - 2018-10-12 18:34:09 --> Database Driver Class Initialized
INFO - 2018-10-12 18:34:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:34:09 --> Form Validation Class Initialized
INFO - 2018-10-12 18:34:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-12 18:34:09 --> Database Driver Class Initialized
INFO - 2018-10-12 18:34:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:34:09 --> Config Class Initialized
INFO - 2018-10-12 18:34:09 --> Hooks Class Initialized
DEBUG - 2018-10-12 18:34:09 --> UTF-8 Support Enabled
INFO - 2018-10-12 18:34:09 --> Utf8 Class Initialized
INFO - 2018-10-12 18:34:09 --> URI Class Initialized
INFO - 2018-10-12 18:34:09 --> Router Class Initialized
INFO - 2018-10-12 18:34:09 --> Output Class Initialized
INFO - 2018-10-12 18:34:09 --> Security Class Initialized
DEBUG - 2018-10-12 18:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 18:34:09 --> CSRF cookie sent
INFO - 2018-10-12 18:34:09 --> Input Class Initialized
INFO - 2018-10-12 18:34:09 --> Language Class Initialized
INFO - 2018-10-12 18:34:09 --> Loader Class Initialized
INFO - 2018-10-12 18:34:09 --> Helper loaded: url_helper
INFO - 2018-10-12 18:34:09 --> Helper loaded: form_helper
INFO - 2018-10-12 18:34:09 --> Helper loaded: language_helper
DEBUG - 2018-10-12 18:34:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 18:34:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 18:34:09 --> User Agent Class Initialized
INFO - 2018-10-12 18:34:09 --> Controller Class Initialized
INFO - 2018-10-12 18:34:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 18:34:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 18:34:09 --> Pixel_Model class loaded
INFO - 2018-10-12 18:34:09 --> Database Driver Class Initialized
INFO - 2018-10-12 18:34:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:34:09 --> Database Driver Class Initialized
INFO - 2018-10-12 18:34:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:34:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 18:34:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 18:34:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 18:34:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 18:34:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 18:34:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 18:34:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-12 18:34:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 18:34:09 --> Final output sent to browser
DEBUG - 2018-10-12 18:34:09 --> Total execution time: 0.0624
INFO - 2018-10-12 18:34:26 --> Config Class Initialized
INFO - 2018-10-12 18:34:26 --> Hooks Class Initialized
DEBUG - 2018-10-12 18:34:26 --> UTF-8 Support Enabled
INFO - 2018-10-12 18:34:26 --> Utf8 Class Initialized
INFO - 2018-10-12 18:34:26 --> URI Class Initialized
INFO - 2018-10-12 18:34:26 --> Router Class Initialized
INFO - 2018-10-12 18:34:26 --> Output Class Initialized
INFO - 2018-10-12 18:34:26 --> Security Class Initialized
DEBUG - 2018-10-12 18:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 18:34:26 --> CSRF cookie sent
INFO - 2018-10-12 18:34:26 --> Input Class Initialized
INFO - 2018-10-12 18:34:26 --> Language Class Initialized
INFO - 2018-10-12 18:34:26 --> Loader Class Initialized
INFO - 2018-10-12 18:34:26 --> Helper loaded: url_helper
INFO - 2018-10-12 18:34:26 --> Helper loaded: form_helper
INFO - 2018-10-12 18:34:26 --> Helper loaded: language_helper
DEBUG - 2018-10-12 18:34:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 18:34:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 18:34:26 --> User Agent Class Initialized
INFO - 2018-10-12 18:34:26 --> Controller Class Initialized
INFO - 2018-10-12 18:34:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 18:34:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 18:34:26 --> Pixel_Model class loaded
INFO - 2018-10-12 18:34:26 --> Database Driver Class Initialized
INFO - 2018-10-12 18:34:26 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:34:26 --> Database Driver Class Initialized
INFO - 2018-10-12 18:34:26 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:34:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 18:34:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 18:34:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 18:34:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 18:34:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/save_exit.php
INFO - 2018-10-12 18:34:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 18:34:26 --> Final output sent to browser
DEBUG - 2018-10-12 18:34:26 --> Total execution time: 0.0460
INFO - 2018-10-12 18:34:28 --> Config Class Initialized
INFO - 2018-10-12 18:34:28 --> Hooks Class Initialized
DEBUG - 2018-10-12 18:34:28 --> UTF-8 Support Enabled
INFO - 2018-10-12 18:34:28 --> Utf8 Class Initialized
INFO - 2018-10-12 18:34:28 --> URI Class Initialized
INFO - 2018-10-12 18:34:28 --> Router Class Initialized
INFO - 2018-10-12 18:34:28 --> Output Class Initialized
INFO - 2018-10-12 18:34:28 --> Security Class Initialized
DEBUG - 2018-10-12 18:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 18:34:28 --> CSRF cookie sent
INFO - 2018-10-12 18:34:28 --> Input Class Initialized
INFO - 2018-10-12 18:34:28 --> Language Class Initialized
INFO - 2018-10-12 18:34:28 --> Loader Class Initialized
INFO - 2018-10-12 18:34:28 --> Helper loaded: url_helper
INFO - 2018-10-12 18:34:28 --> Helper loaded: form_helper
INFO - 2018-10-12 18:34:28 --> Helper loaded: language_helper
DEBUG - 2018-10-12 18:34:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 18:34:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 18:34:28 --> User Agent Class Initialized
INFO - 2018-10-12 18:34:28 --> Controller Class Initialized
INFO - 2018-10-12 18:34:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 18:34:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 18:34:28 --> Pixel_Model class loaded
INFO - 2018-10-12 18:34:28 --> Database Driver Class Initialized
INFO - 2018-10-12 18:34:28 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:34:28 --> Database Driver Class Initialized
INFO - 2018-10-12 18:34:28 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:34:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 18:34:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 18:34:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 18:34:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 18:34:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 18:34:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 18:34:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-12 18:34:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 18:34:28 --> Final output sent to browser
DEBUG - 2018-10-12 18:34:28 --> Total execution time: 0.0563
INFO - 2018-10-12 18:34:31 --> Config Class Initialized
INFO - 2018-10-12 18:34:31 --> Hooks Class Initialized
DEBUG - 2018-10-12 18:34:31 --> UTF-8 Support Enabled
INFO - 2018-10-12 18:34:31 --> Utf8 Class Initialized
INFO - 2018-10-12 18:34:31 --> URI Class Initialized
INFO - 2018-10-12 18:34:31 --> Router Class Initialized
INFO - 2018-10-12 18:34:31 --> Output Class Initialized
INFO - 2018-10-12 18:34:31 --> Security Class Initialized
DEBUG - 2018-10-12 18:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 18:34:31 --> CSRF cookie sent
INFO - 2018-10-12 18:34:31 --> Input Class Initialized
INFO - 2018-10-12 18:34:31 --> Language Class Initialized
INFO - 2018-10-12 18:34:31 --> Loader Class Initialized
INFO - 2018-10-12 18:34:31 --> Helper loaded: url_helper
INFO - 2018-10-12 18:34:31 --> Helper loaded: form_helper
INFO - 2018-10-12 18:34:31 --> Helper loaded: language_helper
DEBUG - 2018-10-12 18:34:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 18:34:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 18:34:31 --> User Agent Class Initialized
INFO - 2018-10-12 18:34:31 --> Controller Class Initialized
INFO - 2018-10-12 18:34:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 18:34:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 18:34:31 --> Pixel_Model class loaded
INFO - 2018-10-12 18:34:31 --> Database Driver Class Initialized
INFO - 2018-10-12 18:34:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:34:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 18:34:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 18:34:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 18:34:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 18:34:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 18:34:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 18:34:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-10-12 18:34:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 18:34:31 --> Final output sent to browser
DEBUG - 2018-10-12 18:34:31 --> Total execution time: 0.0420
INFO - 2018-10-12 18:34:32 --> Config Class Initialized
INFO - 2018-10-12 18:34:32 --> Hooks Class Initialized
DEBUG - 2018-10-12 18:34:32 --> UTF-8 Support Enabled
INFO - 2018-10-12 18:34:32 --> Utf8 Class Initialized
INFO - 2018-10-12 18:34:32 --> URI Class Initialized
INFO - 2018-10-12 18:34:32 --> Router Class Initialized
INFO - 2018-10-12 18:34:32 --> Output Class Initialized
INFO - 2018-10-12 18:34:32 --> Security Class Initialized
DEBUG - 2018-10-12 18:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 18:34:32 --> CSRF cookie sent
INFO - 2018-10-12 18:34:32 --> CSRF token verified
INFO - 2018-10-12 18:34:32 --> Input Class Initialized
INFO - 2018-10-12 18:34:32 --> Language Class Initialized
INFO - 2018-10-12 18:34:32 --> Loader Class Initialized
INFO - 2018-10-12 18:34:32 --> Helper loaded: url_helper
INFO - 2018-10-12 18:34:32 --> Helper loaded: form_helper
INFO - 2018-10-12 18:34:32 --> Helper loaded: language_helper
DEBUG - 2018-10-12 18:34:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 18:34:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 18:34:32 --> User Agent Class Initialized
INFO - 2018-10-12 18:34:32 --> Controller Class Initialized
INFO - 2018-10-12 18:34:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 18:34:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 18:34:32 --> Pixel_Model class loaded
INFO - 2018-10-12 18:34:32 --> Database Driver Class Initialized
INFO - 2018-10-12 18:34:32 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:34:32 --> Form Validation Class Initialized
INFO - 2018-10-12 18:34:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-12 18:34:32 --> Database Driver Class Initialized
INFO - 2018-10-12 18:34:32 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:34:32 --> Config Class Initialized
INFO - 2018-10-12 18:34:32 --> Hooks Class Initialized
DEBUG - 2018-10-12 18:34:32 --> UTF-8 Support Enabled
INFO - 2018-10-12 18:34:32 --> Utf8 Class Initialized
INFO - 2018-10-12 18:34:32 --> URI Class Initialized
INFO - 2018-10-12 18:34:32 --> Router Class Initialized
INFO - 2018-10-12 18:34:32 --> Output Class Initialized
INFO - 2018-10-12 18:34:32 --> Security Class Initialized
DEBUG - 2018-10-12 18:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 18:34:32 --> CSRF cookie sent
INFO - 2018-10-12 18:34:32 --> Input Class Initialized
INFO - 2018-10-12 18:34:32 --> Language Class Initialized
INFO - 2018-10-12 18:34:32 --> Loader Class Initialized
INFO - 2018-10-12 18:34:32 --> Helper loaded: url_helper
INFO - 2018-10-12 18:34:32 --> Helper loaded: form_helper
INFO - 2018-10-12 18:34:32 --> Helper loaded: language_helper
DEBUG - 2018-10-12 18:34:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 18:34:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 18:34:32 --> User Agent Class Initialized
INFO - 2018-10-12 18:34:32 --> Controller Class Initialized
INFO - 2018-10-12 18:34:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 18:34:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 18:34:32 --> Pixel_Model class loaded
INFO - 2018-10-12 18:34:32 --> Database Driver Class Initialized
INFO - 2018-10-12 18:34:32 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:34:32 --> Database Driver Class Initialized
INFO - 2018-10-12 18:34:32 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:34:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 18:34:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 18:34:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 18:34:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 18:34:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 18:34:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 18:34:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-12 18:34:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 18:34:32 --> Final output sent to browser
DEBUG - 2018-10-12 18:34:32 --> Total execution time: 0.0456
INFO - 2018-10-12 18:34:35 --> Config Class Initialized
INFO - 2018-10-12 18:34:35 --> Hooks Class Initialized
DEBUG - 2018-10-12 18:34:35 --> UTF-8 Support Enabled
INFO - 2018-10-12 18:34:35 --> Utf8 Class Initialized
INFO - 2018-10-12 18:34:35 --> URI Class Initialized
INFO - 2018-10-12 18:34:35 --> Router Class Initialized
INFO - 2018-10-12 18:34:35 --> Output Class Initialized
INFO - 2018-10-12 18:34:35 --> Security Class Initialized
DEBUG - 2018-10-12 18:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 18:34:35 --> CSRF cookie sent
INFO - 2018-10-12 18:34:35 --> CSRF token verified
INFO - 2018-10-12 18:34:35 --> Input Class Initialized
INFO - 2018-10-12 18:34:35 --> Language Class Initialized
INFO - 2018-10-12 18:34:35 --> Loader Class Initialized
INFO - 2018-10-12 18:34:35 --> Helper loaded: url_helper
INFO - 2018-10-12 18:34:35 --> Helper loaded: form_helper
INFO - 2018-10-12 18:34:35 --> Helper loaded: language_helper
DEBUG - 2018-10-12 18:34:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 18:34:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 18:34:35 --> User Agent Class Initialized
INFO - 2018-10-12 18:34:35 --> Controller Class Initialized
INFO - 2018-10-12 18:34:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 18:34:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 18:34:35 --> Pixel_Model class loaded
INFO - 2018-10-12 18:34:35 --> Database Driver Class Initialized
INFO - 2018-10-12 18:34:35 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:34:35 --> Form Validation Class Initialized
INFO - 2018-10-12 18:34:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-12 18:34:35 --> Database Driver Class Initialized
INFO - 2018-10-12 18:34:35 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:34:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 18:34:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 18:34:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 18:34:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 18:34:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 18:34:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_errors.php
INFO - 2018-10-12 18:34:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 18:34:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-12 18:34:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 18:34:35 --> Final output sent to browser
DEBUG - 2018-10-12 18:34:35 --> Total execution time: 0.0669
INFO - 2018-10-12 18:34:37 --> Config Class Initialized
INFO - 2018-10-12 18:34:37 --> Hooks Class Initialized
DEBUG - 2018-10-12 18:34:37 --> UTF-8 Support Enabled
INFO - 2018-10-12 18:34:37 --> Utf8 Class Initialized
INFO - 2018-10-12 18:34:37 --> URI Class Initialized
INFO - 2018-10-12 18:34:37 --> Router Class Initialized
INFO - 2018-10-12 18:34:37 --> Output Class Initialized
INFO - 2018-10-12 18:34:37 --> Security Class Initialized
DEBUG - 2018-10-12 18:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 18:34:37 --> CSRF cookie sent
INFO - 2018-10-12 18:34:37 --> CSRF token verified
INFO - 2018-10-12 18:34:37 --> Input Class Initialized
INFO - 2018-10-12 18:34:37 --> Language Class Initialized
INFO - 2018-10-12 18:34:37 --> Loader Class Initialized
INFO - 2018-10-12 18:34:37 --> Helper loaded: url_helper
INFO - 2018-10-12 18:34:37 --> Helper loaded: form_helper
INFO - 2018-10-12 18:34:37 --> Helper loaded: language_helper
DEBUG - 2018-10-12 18:34:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 18:34:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 18:34:37 --> User Agent Class Initialized
INFO - 2018-10-12 18:34:37 --> Controller Class Initialized
INFO - 2018-10-12 18:34:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 18:34:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 18:34:37 --> Pixel_Model class loaded
INFO - 2018-10-12 18:34:37 --> Database Driver Class Initialized
INFO - 2018-10-12 18:34:37 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:34:37 --> Form Validation Class Initialized
INFO - 2018-10-12 18:34:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-12 18:34:37 --> Database Driver Class Initialized
INFO - 2018-10-12 18:34:37 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:34:37 --> Config Class Initialized
INFO - 2018-10-12 18:34:37 --> Hooks Class Initialized
DEBUG - 2018-10-12 18:34:37 --> UTF-8 Support Enabled
INFO - 2018-10-12 18:34:37 --> Utf8 Class Initialized
INFO - 2018-10-12 18:34:37 --> URI Class Initialized
INFO - 2018-10-12 18:34:37 --> Router Class Initialized
INFO - 2018-10-12 18:34:37 --> Output Class Initialized
INFO - 2018-10-12 18:34:37 --> Security Class Initialized
DEBUG - 2018-10-12 18:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 18:34:37 --> CSRF cookie sent
INFO - 2018-10-12 18:34:37 --> Input Class Initialized
INFO - 2018-10-12 18:34:37 --> Language Class Initialized
INFO - 2018-10-12 18:34:37 --> Loader Class Initialized
INFO - 2018-10-12 18:34:37 --> Helper loaded: url_helper
INFO - 2018-10-12 18:34:37 --> Helper loaded: form_helper
INFO - 2018-10-12 18:34:37 --> Helper loaded: language_helper
DEBUG - 2018-10-12 18:34:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 18:34:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 18:34:37 --> User Agent Class Initialized
INFO - 2018-10-12 18:34:37 --> Controller Class Initialized
INFO - 2018-10-12 18:34:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 18:34:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 18:34:37 --> Pixel_Model class loaded
INFO - 2018-10-12 18:34:37 --> Database Driver Class Initialized
INFO - 2018-10-12 18:34:37 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:34:37 --> Database Driver Class Initialized
INFO - 2018-10-12 18:34:37 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:34:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 18:34:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 18:34:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 18:34:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 18:34:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 18:34:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 18:34:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-10-12 18:34:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 18:34:37 --> Final output sent to browser
DEBUG - 2018-10-12 18:34:37 --> Total execution time: 0.0510
INFO - 2018-10-12 18:34:40 --> Config Class Initialized
INFO - 2018-10-12 18:34:40 --> Hooks Class Initialized
DEBUG - 2018-10-12 18:34:40 --> UTF-8 Support Enabled
INFO - 2018-10-12 18:34:40 --> Utf8 Class Initialized
INFO - 2018-10-12 18:34:40 --> URI Class Initialized
INFO - 2018-10-12 18:34:40 --> Router Class Initialized
INFO - 2018-10-12 18:34:40 --> Output Class Initialized
INFO - 2018-10-12 18:34:40 --> Security Class Initialized
DEBUG - 2018-10-12 18:34:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 18:34:40 --> CSRF cookie sent
INFO - 2018-10-12 18:34:40 --> Input Class Initialized
INFO - 2018-10-12 18:34:40 --> Language Class Initialized
INFO - 2018-10-12 18:34:40 --> Loader Class Initialized
INFO - 2018-10-12 18:34:40 --> Helper loaded: url_helper
INFO - 2018-10-12 18:34:40 --> Helper loaded: form_helper
INFO - 2018-10-12 18:34:40 --> Helper loaded: language_helper
DEBUG - 2018-10-12 18:34:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 18:34:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 18:34:40 --> User Agent Class Initialized
INFO - 2018-10-12 18:34:40 --> Controller Class Initialized
INFO - 2018-10-12 18:34:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 18:34:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 18:34:40 --> Pixel_Model class loaded
INFO - 2018-10-12 18:34:40 --> Database Driver Class Initialized
INFO - 2018-10-12 18:34:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:34:40 --> Database Driver Class Initialized
INFO - 2018-10-12 18:34:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:34:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 18:34:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 18:34:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 18:34:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 18:34:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/save_exit.php
INFO - 2018-10-12 18:34:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 18:34:40 --> Final output sent to browser
DEBUG - 2018-10-12 18:34:40 --> Total execution time: 0.0484
INFO - 2018-10-12 18:34:41 --> Config Class Initialized
INFO - 2018-10-12 18:34:41 --> Hooks Class Initialized
DEBUG - 2018-10-12 18:34:41 --> UTF-8 Support Enabled
INFO - 2018-10-12 18:34:41 --> Utf8 Class Initialized
INFO - 2018-10-12 18:34:41 --> URI Class Initialized
INFO - 2018-10-12 18:34:41 --> Router Class Initialized
INFO - 2018-10-12 18:34:41 --> Output Class Initialized
INFO - 2018-10-12 18:34:41 --> Security Class Initialized
DEBUG - 2018-10-12 18:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 18:34:41 --> CSRF cookie sent
INFO - 2018-10-12 18:34:41 --> Input Class Initialized
INFO - 2018-10-12 18:34:41 --> Language Class Initialized
INFO - 2018-10-12 18:34:41 --> Loader Class Initialized
INFO - 2018-10-12 18:34:41 --> Helper loaded: url_helper
INFO - 2018-10-12 18:34:41 --> Helper loaded: form_helper
INFO - 2018-10-12 18:34:41 --> Helper loaded: language_helper
DEBUG - 2018-10-12 18:34:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 18:34:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 18:34:41 --> User Agent Class Initialized
INFO - 2018-10-12 18:34:41 --> Controller Class Initialized
INFO - 2018-10-12 18:34:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 18:34:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 18:34:41 --> Pixel_Model class loaded
INFO - 2018-10-12 18:34:41 --> Database Driver Class Initialized
INFO - 2018-10-12 18:34:41 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:34:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 18:34:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 18:34:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 18:34:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 18:34:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/contact_us.php
INFO - 2018-10-12 18:34:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 18:34:41 --> Final output sent to browser
DEBUG - 2018-10-12 18:34:41 --> Total execution time: 0.0556
INFO - 2018-10-12 18:34:48 --> Config Class Initialized
INFO - 2018-10-12 18:34:48 --> Hooks Class Initialized
DEBUG - 2018-10-12 18:34:48 --> UTF-8 Support Enabled
INFO - 2018-10-12 18:34:48 --> Utf8 Class Initialized
INFO - 2018-10-12 18:34:48 --> URI Class Initialized
INFO - 2018-10-12 18:34:48 --> Router Class Initialized
INFO - 2018-10-12 18:34:48 --> Output Class Initialized
INFO - 2018-10-12 18:34:48 --> Security Class Initialized
DEBUG - 2018-10-12 18:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 18:34:48 --> CSRF cookie sent
INFO - 2018-10-12 18:34:48 --> Input Class Initialized
INFO - 2018-10-12 18:34:48 --> Language Class Initialized
INFO - 2018-10-12 18:34:48 --> Loader Class Initialized
INFO - 2018-10-12 18:34:48 --> Helper loaded: url_helper
INFO - 2018-10-12 18:34:48 --> Helper loaded: form_helper
INFO - 2018-10-12 18:34:48 --> Helper loaded: language_helper
DEBUG - 2018-10-12 18:34:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 18:34:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 18:34:48 --> User Agent Class Initialized
INFO - 2018-10-12 18:34:48 --> Controller Class Initialized
INFO - 2018-10-12 18:34:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 18:34:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 18:34:48 --> Pixel_Model class loaded
INFO - 2018-10-12 18:34:48 --> Database Driver Class Initialized
INFO - 2018-10-12 18:34:48 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:34:48 --> Database Driver Class Initialized
INFO - 2018-10-12 18:34:48 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:34:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 18:34:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 18:34:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 18:34:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 18:34:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/save_exit.php
INFO - 2018-10-12 18:34:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 18:34:48 --> Final output sent to browser
DEBUG - 2018-10-12 18:34:48 --> Total execution time: 0.0454
INFO - 2018-10-12 18:34:55 --> Config Class Initialized
INFO - 2018-10-12 18:34:55 --> Hooks Class Initialized
DEBUG - 2018-10-12 18:34:55 --> UTF-8 Support Enabled
INFO - 2018-10-12 18:34:55 --> Utf8 Class Initialized
INFO - 2018-10-12 18:34:55 --> URI Class Initialized
INFO - 2018-10-12 18:34:55 --> Router Class Initialized
INFO - 2018-10-12 18:34:55 --> Output Class Initialized
INFO - 2018-10-12 18:34:55 --> Security Class Initialized
DEBUG - 2018-10-12 18:34:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 18:34:55 --> CSRF cookie sent
INFO - 2018-10-12 18:34:55 --> Input Class Initialized
INFO - 2018-10-12 18:34:55 --> Language Class Initialized
INFO - 2018-10-12 18:34:55 --> Loader Class Initialized
INFO - 2018-10-12 18:34:55 --> Helper loaded: url_helper
INFO - 2018-10-12 18:34:55 --> Helper loaded: form_helper
INFO - 2018-10-12 18:34:55 --> Helper loaded: language_helper
DEBUG - 2018-10-12 18:34:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 18:34:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 18:34:55 --> User Agent Class Initialized
INFO - 2018-10-12 18:34:55 --> Controller Class Initialized
INFO - 2018-10-12 18:34:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 18:34:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 18:34:55 --> Pixel_Model class loaded
INFO - 2018-10-12 18:34:55 --> Database Driver Class Initialized
INFO - 2018-10-12 18:34:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:34:55 --> Database Driver Class Initialized
INFO - 2018-10-12 18:34:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:34:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 18:34:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 18:34:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 18:34:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 18:34:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 18:34:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 18:34:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-10-12 18:34:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 18:34:55 --> Final output sent to browser
DEBUG - 2018-10-12 18:34:55 --> Total execution time: 0.0547
INFO - 2018-10-12 18:34:58 --> Config Class Initialized
INFO - 2018-10-12 18:34:58 --> Hooks Class Initialized
DEBUG - 2018-10-12 18:34:58 --> UTF-8 Support Enabled
INFO - 2018-10-12 18:34:58 --> Utf8 Class Initialized
INFO - 2018-10-12 18:34:58 --> URI Class Initialized
INFO - 2018-10-12 18:34:58 --> Router Class Initialized
INFO - 2018-10-12 18:34:58 --> Output Class Initialized
INFO - 2018-10-12 18:34:58 --> Security Class Initialized
DEBUG - 2018-10-12 18:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 18:34:58 --> CSRF cookie sent
INFO - 2018-10-12 18:34:58 --> CSRF token verified
INFO - 2018-10-12 18:34:58 --> Input Class Initialized
INFO - 2018-10-12 18:34:58 --> Language Class Initialized
INFO - 2018-10-12 18:34:58 --> Loader Class Initialized
INFO - 2018-10-12 18:34:58 --> Helper loaded: url_helper
INFO - 2018-10-12 18:34:58 --> Helper loaded: form_helper
INFO - 2018-10-12 18:34:58 --> Helper loaded: language_helper
DEBUG - 2018-10-12 18:34:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 18:34:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 18:34:58 --> User Agent Class Initialized
INFO - 2018-10-12 18:34:58 --> Controller Class Initialized
INFO - 2018-10-12 18:34:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 18:34:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 18:34:58 --> Pixel_Model class loaded
INFO - 2018-10-12 18:34:58 --> Database Driver Class Initialized
INFO - 2018-10-12 18:34:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:34:58 --> Form Validation Class Initialized
INFO - 2018-10-12 18:34:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-12 18:34:58 --> Database Driver Class Initialized
INFO - 2018-10-12 18:34:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:34:58 --> Config Class Initialized
INFO - 2018-10-12 18:34:58 --> Hooks Class Initialized
DEBUG - 2018-10-12 18:34:58 --> UTF-8 Support Enabled
INFO - 2018-10-12 18:34:58 --> Utf8 Class Initialized
INFO - 2018-10-12 18:34:58 --> URI Class Initialized
INFO - 2018-10-12 18:34:58 --> Router Class Initialized
INFO - 2018-10-12 18:34:58 --> Output Class Initialized
INFO - 2018-10-12 18:34:58 --> Security Class Initialized
DEBUG - 2018-10-12 18:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 18:34:58 --> CSRF cookie sent
INFO - 2018-10-12 18:34:58 --> Input Class Initialized
INFO - 2018-10-12 18:34:58 --> Language Class Initialized
INFO - 2018-10-12 18:34:58 --> Loader Class Initialized
INFO - 2018-10-12 18:34:58 --> Helper loaded: url_helper
INFO - 2018-10-12 18:34:58 --> Helper loaded: form_helper
INFO - 2018-10-12 18:34:58 --> Helper loaded: language_helper
DEBUG - 2018-10-12 18:34:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 18:34:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 18:34:58 --> User Agent Class Initialized
INFO - 2018-10-12 18:34:58 --> Controller Class Initialized
INFO - 2018-10-12 18:34:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 18:34:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 18:34:58 --> Pixel_Model class loaded
INFO - 2018-10-12 18:34:58 --> Database Driver Class Initialized
INFO - 2018-10-12 18:34:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:34:58 --> Database Driver Class Initialized
INFO - 2018-10-12 18:34:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:34:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 18:34:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 18:34:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-10-12 18:34:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 18:34:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 18:34:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 18:34:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 18:34:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-10-12 18:34:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 18:34:58 --> Final output sent to browser
DEBUG - 2018-10-12 18:34:58 --> Total execution time: 0.0331
INFO - 2018-10-12 18:35:06 --> Config Class Initialized
INFO - 2018-10-12 18:35:06 --> Hooks Class Initialized
DEBUG - 2018-10-12 18:35:06 --> UTF-8 Support Enabled
INFO - 2018-10-12 18:35:06 --> Utf8 Class Initialized
INFO - 2018-10-12 18:35:06 --> URI Class Initialized
INFO - 2018-10-12 18:35:06 --> Router Class Initialized
INFO - 2018-10-12 18:35:06 --> Output Class Initialized
INFO - 2018-10-12 18:35:06 --> Security Class Initialized
DEBUG - 2018-10-12 18:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 18:35:06 --> CSRF cookie sent
INFO - 2018-10-12 18:35:06 --> CSRF token verified
INFO - 2018-10-12 18:35:06 --> Input Class Initialized
INFO - 2018-10-12 18:35:06 --> Language Class Initialized
INFO - 2018-10-12 18:35:06 --> Loader Class Initialized
INFO - 2018-10-12 18:35:06 --> Helper loaded: url_helper
INFO - 2018-10-12 18:35:06 --> Helper loaded: form_helper
INFO - 2018-10-12 18:35:06 --> Helper loaded: language_helper
DEBUG - 2018-10-12 18:35:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 18:35:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 18:35:06 --> User Agent Class Initialized
INFO - 2018-10-12 18:35:06 --> Controller Class Initialized
INFO - 2018-10-12 18:35:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 18:35:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 18:35:06 --> Pixel_Model class loaded
INFO - 2018-10-12 18:35:06 --> Database Driver Class Initialized
INFO - 2018-10-12 18:35:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:35:06 --> Form Validation Class Initialized
INFO - 2018-10-12 18:35:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-12 18:35:06 --> Database Driver Class Initialized
INFO - 2018-10-12 18:35:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:35:06 --> Config Class Initialized
INFO - 2018-10-12 18:35:06 --> Hooks Class Initialized
DEBUG - 2018-10-12 18:35:06 --> UTF-8 Support Enabled
INFO - 2018-10-12 18:35:06 --> Utf8 Class Initialized
INFO - 2018-10-12 18:35:06 --> URI Class Initialized
INFO - 2018-10-12 18:35:06 --> Router Class Initialized
INFO - 2018-10-12 18:35:06 --> Output Class Initialized
INFO - 2018-10-12 18:35:06 --> Security Class Initialized
DEBUG - 2018-10-12 18:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 18:35:06 --> CSRF cookie sent
INFO - 2018-10-12 18:35:06 --> Input Class Initialized
INFO - 2018-10-12 18:35:06 --> Language Class Initialized
INFO - 2018-10-12 18:35:06 --> Loader Class Initialized
INFO - 2018-10-12 18:35:06 --> Helper loaded: url_helper
INFO - 2018-10-12 18:35:06 --> Helper loaded: form_helper
INFO - 2018-10-12 18:35:06 --> Helper loaded: language_helper
DEBUG - 2018-10-12 18:35:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 18:35:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 18:35:06 --> User Agent Class Initialized
INFO - 2018-10-12 18:35:06 --> Controller Class Initialized
INFO - 2018-10-12 18:35:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 18:35:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 18:35:06 --> Pixel_Model class loaded
INFO - 2018-10-12 18:35:06 --> Database Driver Class Initialized
INFO - 2018-10-12 18:35:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:35:06 --> Database Driver Class Initialized
INFO - 2018-10-12 18:35:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:35:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 18:35:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 18:35:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 18:35:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 18:35:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 18:35:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 18:35:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-12 18:35:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 18:35:06 --> Final output sent to browser
DEBUG - 2018-10-12 18:35:06 --> Total execution time: 0.0328
INFO - 2018-10-12 18:35:14 --> Config Class Initialized
INFO - 2018-10-12 18:35:14 --> Hooks Class Initialized
DEBUG - 2018-10-12 18:35:14 --> UTF-8 Support Enabled
INFO - 2018-10-12 18:35:14 --> Utf8 Class Initialized
INFO - 2018-10-12 18:35:14 --> URI Class Initialized
INFO - 2018-10-12 18:35:14 --> Router Class Initialized
INFO - 2018-10-12 18:35:14 --> Output Class Initialized
INFO - 2018-10-12 18:35:14 --> Security Class Initialized
DEBUG - 2018-10-12 18:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 18:35:14 --> CSRF cookie sent
INFO - 2018-10-12 18:35:14 --> CSRF token verified
INFO - 2018-10-12 18:35:14 --> Input Class Initialized
INFO - 2018-10-12 18:35:14 --> Language Class Initialized
INFO - 2018-10-12 18:35:14 --> Loader Class Initialized
INFO - 2018-10-12 18:35:14 --> Helper loaded: url_helper
INFO - 2018-10-12 18:35:14 --> Helper loaded: form_helper
INFO - 2018-10-12 18:35:14 --> Helper loaded: language_helper
DEBUG - 2018-10-12 18:35:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 18:35:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 18:35:14 --> User Agent Class Initialized
INFO - 2018-10-12 18:35:14 --> Controller Class Initialized
INFO - 2018-10-12 18:35:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 18:35:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 18:35:14 --> Pixel_Model class loaded
INFO - 2018-10-12 18:35:14 --> Database Driver Class Initialized
INFO - 2018-10-12 18:35:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:35:14 --> Form Validation Class Initialized
INFO - 2018-10-12 18:35:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-12 18:35:14 --> Database Driver Class Initialized
INFO - 2018-10-12 18:35:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:35:14 --> Config Class Initialized
INFO - 2018-10-12 18:35:14 --> Hooks Class Initialized
DEBUG - 2018-10-12 18:35:14 --> UTF-8 Support Enabled
INFO - 2018-10-12 18:35:14 --> Utf8 Class Initialized
INFO - 2018-10-12 18:35:14 --> URI Class Initialized
INFO - 2018-10-12 18:35:14 --> Router Class Initialized
INFO - 2018-10-12 18:35:14 --> Output Class Initialized
INFO - 2018-10-12 18:35:14 --> Security Class Initialized
DEBUG - 2018-10-12 18:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 18:35:14 --> CSRF cookie sent
INFO - 2018-10-12 18:35:14 --> Input Class Initialized
INFO - 2018-10-12 18:35:14 --> Language Class Initialized
INFO - 2018-10-12 18:35:14 --> Loader Class Initialized
INFO - 2018-10-12 18:35:14 --> Helper loaded: url_helper
INFO - 2018-10-12 18:35:14 --> Helper loaded: form_helper
INFO - 2018-10-12 18:35:14 --> Helper loaded: language_helper
DEBUG - 2018-10-12 18:35:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 18:35:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 18:35:14 --> User Agent Class Initialized
INFO - 2018-10-12 18:35:14 --> Controller Class Initialized
INFO - 2018-10-12 18:35:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 18:35:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 18:35:14 --> Pixel_Model class loaded
INFO - 2018-10-12 18:35:14 --> Database Driver Class Initialized
INFO - 2018-10-12 18:35:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:35:14 --> Database Driver Class Initialized
INFO - 2018-10-12 18:35:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:35:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 18:35:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 18:35:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 18:35:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 18:35:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 18:35:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 18:35:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/marriage.php
INFO - 2018-10-12 18:35:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 18:35:14 --> Final output sent to browser
DEBUG - 2018-10-12 18:35:14 --> Total execution time: 0.0325
INFO - 2018-10-12 18:35:21 --> Config Class Initialized
INFO - 2018-10-12 18:35:21 --> Hooks Class Initialized
DEBUG - 2018-10-12 18:35:21 --> UTF-8 Support Enabled
INFO - 2018-10-12 18:35:21 --> Utf8 Class Initialized
INFO - 2018-10-12 18:35:21 --> URI Class Initialized
INFO - 2018-10-12 18:35:21 --> Router Class Initialized
INFO - 2018-10-12 18:35:21 --> Output Class Initialized
INFO - 2018-10-12 18:35:21 --> Security Class Initialized
DEBUG - 2018-10-12 18:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 18:35:21 --> CSRF cookie sent
INFO - 2018-10-12 18:35:21 --> CSRF token verified
INFO - 2018-10-12 18:35:21 --> Input Class Initialized
INFO - 2018-10-12 18:35:21 --> Language Class Initialized
INFO - 2018-10-12 18:35:21 --> Loader Class Initialized
INFO - 2018-10-12 18:35:21 --> Helper loaded: url_helper
INFO - 2018-10-12 18:35:21 --> Helper loaded: form_helper
INFO - 2018-10-12 18:35:21 --> Helper loaded: language_helper
DEBUG - 2018-10-12 18:35:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 18:35:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 18:35:21 --> User Agent Class Initialized
INFO - 2018-10-12 18:35:21 --> Controller Class Initialized
INFO - 2018-10-12 18:35:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 18:35:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 18:35:21 --> Pixel_Model class loaded
INFO - 2018-10-12 18:35:21 --> Database Driver Class Initialized
INFO - 2018-10-12 18:35:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:35:21 --> Form Validation Class Initialized
INFO - 2018-10-12 18:35:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-12 18:35:21 --> Database Driver Class Initialized
INFO - 2018-10-12 18:35:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:35:21 --> Config Class Initialized
INFO - 2018-10-12 18:35:21 --> Hooks Class Initialized
DEBUG - 2018-10-12 18:35:21 --> UTF-8 Support Enabled
INFO - 2018-10-12 18:35:21 --> Utf8 Class Initialized
INFO - 2018-10-12 18:35:21 --> URI Class Initialized
INFO - 2018-10-12 18:35:21 --> Router Class Initialized
INFO - 2018-10-12 18:35:21 --> Output Class Initialized
INFO - 2018-10-12 18:35:21 --> Security Class Initialized
DEBUG - 2018-10-12 18:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 18:35:21 --> CSRF cookie sent
INFO - 2018-10-12 18:35:21 --> Input Class Initialized
INFO - 2018-10-12 18:35:21 --> Language Class Initialized
INFO - 2018-10-12 18:35:21 --> Loader Class Initialized
INFO - 2018-10-12 18:35:21 --> Helper loaded: url_helper
INFO - 2018-10-12 18:35:21 --> Helper loaded: form_helper
INFO - 2018-10-12 18:35:21 --> Helper loaded: language_helper
DEBUG - 2018-10-12 18:35:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 18:35:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 18:35:21 --> User Agent Class Initialized
INFO - 2018-10-12 18:35:21 --> Controller Class Initialized
INFO - 2018-10-12 18:35:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 18:35:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 18:35:21 --> Pixel_Model class loaded
INFO - 2018-10-12 18:35:21 --> Database Driver Class Initialized
INFO - 2018-10-12 18:35:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:35:21 --> Database Driver Class Initialized
INFO - 2018-10-12 18:35:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:35:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 18:35:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 18:35:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 18:35:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 18:35:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 18:35:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 18:35:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-10-12 18:35:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 18:35:21 --> Final output sent to browser
DEBUG - 2018-10-12 18:35:21 --> Total execution time: 0.0330
INFO - 2018-10-12 18:35:26 --> Config Class Initialized
INFO - 2018-10-12 18:35:26 --> Hooks Class Initialized
DEBUG - 2018-10-12 18:35:26 --> UTF-8 Support Enabled
INFO - 2018-10-12 18:35:26 --> Utf8 Class Initialized
INFO - 2018-10-12 18:35:26 --> URI Class Initialized
INFO - 2018-10-12 18:35:26 --> Router Class Initialized
INFO - 2018-10-12 18:35:26 --> Output Class Initialized
INFO - 2018-10-12 18:35:26 --> Security Class Initialized
DEBUG - 2018-10-12 18:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 18:35:26 --> CSRF cookie sent
INFO - 2018-10-12 18:35:26 --> Input Class Initialized
INFO - 2018-10-12 18:35:26 --> Language Class Initialized
INFO - 2018-10-12 18:35:26 --> Loader Class Initialized
INFO - 2018-10-12 18:35:26 --> Helper loaded: url_helper
INFO - 2018-10-12 18:35:26 --> Helper loaded: form_helper
INFO - 2018-10-12 18:35:26 --> Helper loaded: language_helper
DEBUG - 2018-10-12 18:35:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 18:35:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 18:35:26 --> User Agent Class Initialized
INFO - 2018-10-12 18:35:26 --> Controller Class Initialized
INFO - 2018-10-12 18:35:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 18:35:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 18:35:26 --> Pixel_Model class loaded
INFO - 2018-10-12 18:35:26 --> Database Driver Class Initialized
INFO - 2018-10-12 18:35:26 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:35:27 --> Database Driver Class Initialized
INFO - 2018-10-12 18:35:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:35:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 18:35:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 18:35:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 18:35:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 18:35:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 18:35:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 18:35:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/marriage.php
INFO - 2018-10-12 18:35:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 18:35:27 --> Final output sent to browser
DEBUG - 2018-10-12 18:35:27 --> Total execution time: 0.0477
INFO - 2018-10-12 18:35:28 --> Config Class Initialized
INFO - 2018-10-12 18:35:28 --> Hooks Class Initialized
DEBUG - 2018-10-12 18:35:28 --> UTF-8 Support Enabled
INFO - 2018-10-12 18:35:28 --> Utf8 Class Initialized
INFO - 2018-10-12 18:35:28 --> URI Class Initialized
INFO - 2018-10-12 18:35:28 --> Router Class Initialized
INFO - 2018-10-12 18:35:28 --> Output Class Initialized
INFO - 2018-10-12 18:35:28 --> Security Class Initialized
DEBUG - 2018-10-12 18:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 18:35:28 --> CSRF cookie sent
INFO - 2018-10-12 18:35:28 --> Input Class Initialized
INFO - 2018-10-12 18:35:28 --> Language Class Initialized
INFO - 2018-10-12 18:35:28 --> Loader Class Initialized
INFO - 2018-10-12 18:35:28 --> Helper loaded: url_helper
INFO - 2018-10-12 18:35:28 --> Helper loaded: form_helper
INFO - 2018-10-12 18:35:28 --> Helper loaded: language_helper
DEBUG - 2018-10-12 18:35:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 18:35:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 18:35:28 --> User Agent Class Initialized
INFO - 2018-10-12 18:35:28 --> Controller Class Initialized
INFO - 2018-10-12 18:35:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 18:35:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 18:35:28 --> Pixel_Model class loaded
INFO - 2018-10-12 18:35:28 --> Database Driver Class Initialized
INFO - 2018-10-12 18:35:28 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:35:28 --> Database Driver Class Initialized
INFO - 2018-10-12 18:35:28 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:35:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 18:35:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 18:35:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 18:35:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 18:35:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 18:35:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 18:35:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-12 18:35:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 18:35:28 --> Final output sent to browser
DEBUG - 2018-10-12 18:35:28 --> Total execution time: 0.0579
INFO - 2018-10-12 18:35:29 --> Config Class Initialized
INFO - 2018-10-12 18:35:29 --> Hooks Class Initialized
DEBUG - 2018-10-12 18:35:29 --> UTF-8 Support Enabled
INFO - 2018-10-12 18:35:29 --> Utf8 Class Initialized
INFO - 2018-10-12 18:35:29 --> URI Class Initialized
INFO - 2018-10-12 18:35:29 --> Router Class Initialized
INFO - 2018-10-12 18:35:29 --> Output Class Initialized
INFO - 2018-10-12 18:35:29 --> Security Class Initialized
DEBUG - 2018-10-12 18:35:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 18:35:29 --> CSRF cookie sent
INFO - 2018-10-12 18:35:29 --> Input Class Initialized
INFO - 2018-10-12 18:35:29 --> Language Class Initialized
INFO - 2018-10-12 18:35:29 --> Loader Class Initialized
INFO - 2018-10-12 18:35:29 --> Helper loaded: url_helper
INFO - 2018-10-12 18:35:29 --> Helper loaded: form_helper
INFO - 2018-10-12 18:35:29 --> Helper loaded: language_helper
DEBUG - 2018-10-12 18:35:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 18:35:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 18:35:29 --> User Agent Class Initialized
INFO - 2018-10-12 18:35:29 --> Controller Class Initialized
INFO - 2018-10-12 18:35:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 18:35:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 18:35:29 --> Pixel_Model class loaded
INFO - 2018-10-12 18:35:29 --> Database Driver Class Initialized
INFO - 2018-10-12 18:35:29 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:35:29 --> Database Driver Class Initialized
INFO - 2018-10-12 18:35:29 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:35:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 18:35:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 18:35:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-10-12 18:35:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 18:35:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 18:35:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 18:35:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 18:35:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-10-12 18:35:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 18:35:29 --> Final output sent to browser
DEBUG - 2018-10-12 18:35:29 --> Total execution time: 0.0395
INFO - 2018-10-12 18:35:35 --> Config Class Initialized
INFO - 2018-10-12 18:35:35 --> Hooks Class Initialized
DEBUG - 2018-10-12 18:35:35 --> UTF-8 Support Enabled
INFO - 2018-10-12 18:35:35 --> Utf8 Class Initialized
INFO - 2018-10-12 18:35:35 --> URI Class Initialized
INFO - 2018-10-12 18:35:35 --> Router Class Initialized
INFO - 2018-10-12 18:35:35 --> Output Class Initialized
INFO - 2018-10-12 18:35:35 --> Security Class Initialized
DEBUG - 2018-10-12 18:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 18:35:35 --> CSRF cookie sent
INFO - 2018-10-12 18:35:35 --> CSRF token verified
INFO - 2018-10-12 18:35:35 --> Input Class Initialized
INFO - 2018-10-12 18:35:35 --> Language Class Initialized
INFO - 2018-10-12 18:35:35 --> Loader Class Initialized
INFO - 2018-10-12 18:35:35 --> Helper loaded: url_helper
INFO - 2018-10-12 18:35:35 --> Helper loaded: form_helper
INFO - 2018-10-12 18:35:35 --> Helper loaded: language_helper
DEBUG - 2018-10-12 18:35:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 18:35:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 18:35:35 --> User Agent Class Initialized
INFO - 2018-10-12 18:35:35 --> Controller Class Initialized
INFO - 2018-10-12 18:35:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 18:35:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 18:35:35 --> Pixel_Model class loaded
INFO - 2018-10-12 18:35:35 --> Database Driver Class Initialized
INFO - 2018-10-12 18:35:35 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:35:35 --> Form Validation Class Initialized
INFO - 2018-10-12 18:35:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-12 18:35:35 --> Database Driver Class Initialized
INFO - 2018-10-12 18:35:35 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:35:35 --> Config Class Initialized
INFO - 2018-10-12 18:35:35 --> Hooks Class Initialized
DEBUG - 2018-10-12 18:35:35 --> UTF-8 Support Enabled
INFO - 2018-10-12 18:35:35 --> Utf8 Class Initialized
INFO - 2018-10-12 18:35:35 --> URI Class Initialized
INFO - 2018-10-12 18:35:35 --> Router Class Initialized
INFO - 2018-10-12 18:35:35 --> Output Class Initialized
INFO - 2018-10-12 18:35:35 --> Security Class Initialized
DEBUG - 2018-10-12 18:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 18:35:35 --> CSRF cookie sent
INFO - 2018-10-12 18:35:35 --> Input Class Initialized
INFO - 2018-10-12 18:35:35 --> Language Class Initialized
INFO - 2018-10-12 18:35:35 --> Loader Class Initialized
INFO - 2018-10-12 18:35:35 --> Helper loaded: url_helper
INFO - 2018-10-12 18:35:35 --> Helper loaded: form_helper
INFO - 2018-10-12 18:35:35 --> Helper loaded: language_helper
DEBUG - 2018-10-12 18:35:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 18:35:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 18:35:35 --> User Agent Class Initialized
INFO - 2018-10-12 18:35:35 --> Controller Class Initialized
INFO - 2018-10-12 18:35:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 18:35:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 18:35:35 --> Pixel_Model class loaded
INFO - 2018-10-12 18:35:35 --> Database Driver Class Initialized
INFO - 2018-10-12 18:35:35 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:35:35 --> Database Driver Class Initialized
INFO - 2018-10-12 18:35:35 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:35:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 18:35:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 18:35:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 18:35:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 18:35:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 18:35:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 18:35:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-12 18:35:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 18:35:35 --> Final output sent to browser
DEBUG - 2018-10-12 18:35:35 --> Total execution time: 0.0512
INFO - 2018-10-12 18:35:36 --> Config Class Initialized
INFO - 2018-10-12 18:35:36 --> Hooks Class Initialized
DEBUG - 2018-10-12 18:35:36 --> UTF-8 Support Enabled
INFO - 2018-10-12 18:35:36 --> Utf8 Class Initialized
INFO - 2018-10-12 18:35:36 --> URI Class Initialized
INFO - 2018-10-12 18:35:36 --> Router Class Initialized
INFO - 2018-10-12 18:35:36 --> Output Class Initialized
INFO - 2018-10-12 18:35:36 --> Security Class Initialized
DEBUG - 2018-10-12 18:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 18:35:36 --> CSRF cookie sent
INFO - 2018-10-12 18:35:36 --> CSRF token verified
INFO - 2018-10-12 18:35:36 --> Input Class Initialized
INFO - 2018-10-12 18:35:36 --> Language Class Initialized
INFO - 2018-10-12 18:35:36 --> Loader Class Initialized
INFO - 2018-10-12 18:35:36 --> Helper loaded: url_helper
INFO - 2018-10-12 18:35:36 --> Helper loaded: form_helper
INFO - 2018-10-12 18:35:36 --> Helper loaded: language_helper
DEBUG - 2018-10-12 18:35:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 18:35:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 18:35:36 --> User Agent Class Initialized
INFO - 2018-10-12 18:35:36 --> Controller Class Initialized
INFO - 2018-10-12 18:35:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 18:35:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 18:35:36 --> Pixel_Model class loaded
INFO - 2018-10-12 18:35:36 --> Database Driver Class Initialized
INFO - 2018-10-12 18:35:36 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:35:36 --> Form Validation Class Initialized
INFO - 2018-10-12 18:35:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-12 18:35:36 --> Database Driver Class Initialized
INFO - 2018-10-12 18:35:36 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:35:36 --> Config Class Initialized
INFO - 2018-10-12 18:35:36 --> Hooks Class Initialized
DEBUG - 2018-10-12 18:35:36 --> UTF-8 Support Enabled
INFO - 2018-10-12 18:35:36 --> Utf8 Class Initialized
INFO - 2018-10-12 18:35:36 --> URI Class Initialized
INFO - 2018-10-12 18:35:36 --> Router Class Initialized
INFO - 2018-10-12 18:35:36 --> Output Class Initialized
INFO - 2018-10-12 18:35:36 --> Security Class Initialized
DEBUG - 2018-10-12 18:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 18:35:36 --> CSRF cookie sent
INFO - 2018-10-12 18:35:36 --> Input Class Initialized
INFO - 2018-10-12 18:35:36 --> Language Class Initialized
INFO - 2018-10-12 18:35:36 --> Loader Class Initialized
INFO - 2018-10-12 18:35:36 --> Helper loaded: url_helper
INFO - 2018-10-12 18:35:36 --> Helper loaded: form_helper
INFO - 2018-10-12 18:35:36 --> Helper loaded: language_helper
DEBUG - 2018-10-12 18:35:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 18:35:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 18:35:36 --> User Agent Class Initialized
INFO - 2018-10-12 18:35:36 --> Controller Class Initialized
INFO - 2018-10-12 18:35:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 18:35:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 18:35:36 --> Pixel_Model class loaded
INFO - 2018-10-12 18:35:36 --> Database Driver Class Initialized
INFO - 2018-10-12 18:35:36 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:35:36 --> Database Driver Class Initialized
INFO - 2018-10-12 18:35:36 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:35:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 18:35:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 18:35:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 18:35:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 18:35:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 18:35:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 18:35:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/marriage.php
INFO - 2018-10-12 18:35:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 18:35:36 --> Final output sent to browser
DEBUG - 2018-10-12 18:35:36 --> Total execution time: 0.0405
INFO - 2018-10-12 18:35:38 --> Config Class Initialized
INFO - 2018-10-12 18:35:38 --> Hooks Class Initialized
DEBUG - 2018-10-12 18:35:38 --> UTF-8 Support Enabled
INFO - 2018-10-12 18:35:38 --> Utf8 Class Initialized
INFO - 2018-10-12 18:35:38 --> URI Class Initialized
INFO - 2018-10-12 18:35:38 --> Router Class Initialized
INFO - 2018-10-12 18:35:38 --> Output Class Initialized
INFO - 2018-10-12 18:35:38 --> Security Class Initialized
DEBUG - 2018-10-12 18:35:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 18:35:38 --> CSRF cookie sent
INFO - 2018-10-12 18:35:38 --> CSRF token verified
INFO - 2018-10-12 18:35:38 --> Input Class Initialized
INFO - 2018-10-12 18:35:38 --> Language Class Initialized
INFO - 2018-10-12 18:35:38 --> Loader Class Initialized
INFO - 2018-10-12 18:35:38 --> Helper loaded: url_helper
INFO - 2018-10-12 18:35:38 --> Helper loaded: form_helper
INFO - 2018-10-12 18:35:38 --> Helper loaded: language_helper
DEBUG - 2018-10-12 18:35:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 18:35:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 18:35:38 --> User Agent Class Initialized
INFO - 2018-10-12 18:35:38 --> Controller Class Initialized
INFO - 2018-10-12 18:35:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 18:35:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 18:35:38 --> Pixel_Model class loaded
INFO - 2018-10-12 18:35:38 --> Database Driver Class Initialized
INFO - 2018-10-12 18:35:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:35:38 --> Form Validation Class Initialized
INFO - 2018-10-12 18:35:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-12 18:35:38 --> Database Driver Class Initialized
INFO - 2018-10-12 18:35:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:35:38 --> Config Class Initialized
INFO - 2018-10-12 18:35:38 --> Hooks Class Initialized
DEBUG - 2018-10-12 18:35:38 --> UTF-8 Support Enabled
INFO - 2018-10-12 18:35:38 --> Utf8 Class Initialized
INFO - 2018-10-12 18:35:38 --> URI Class Initialized
INFO - 2018-10-12 18:35:38 --> Router Class Initialized
INFO - 2018-10-12 18:35:38 --> Output Class Initialized
INFO - 2018-10-12 18:35:38 --> Security Class Initialized
DEBUG - 2018-10-12 18:35:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 18:35:38 --> CSRF cookie sent
INFO - 2018-10-12 18:35:38 --> Input Class Initialized
INFO - 2018-10-12 18:35:38 --> Language Class Initialized
INFO - 2018-10-12 18:35:38 --> Loader Class Initialized
INFO - 2018-10-12 18:35:38 --> Helper loaded: url_helper
INFO - 2018-10-12 18:35:38 --> Helper loaded: form_helper
INFO - 2018-10-12 18:35:38 --> Helper loaded: language_helper
DEBUG - 2018-10-12 18:35:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 18:35:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 18:35:38 --> User Agent Class Initialized
INFO - 2018-10-12 18:35:38 --> Controller Class Initialized
INFO - 2018-10-12 18:35:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 18:35:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 18:35:38 --> Pixel_Model class loaded
INFO - 2018-10-12 18:35:38 --> Database Driver Class Initialized
INFO - 2018-10-12 18:35:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:35:38 --> Database Driver Class Initialized
INFO - 2018-10-12 18:35:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:35:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 18:35:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 18:35:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 18:35:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 18:35:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 18:35:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 18:35:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-10-12 18:35:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 18:35:38 --> Final output sent to browser
DEBUG - 2018-10-12 18:35:38 --> Total execution time: 0.0628
INFO - 2018-10-12 18:35:44 --> Config Class Initialized
INFO - 2018-10-12 18:35:44 --> Hooks Class Initialized
DEBUG - 2018-10-12 18:35:44 --> UTF-8 Support Enabled
INFO - 2018-10-12 18:35:44 --> Utf8 Class Initialized
INFO - 2018-10-12 18:35:44 --> URI Class Initialized
INFO - 2018-10-12 18:35:44 --> Router Class Initialized
INFO - 2018-10-12 18:35:44 --> Output Class Initialized
INFO - 2018-10-12 18:35:44 --> Security Class Initialized
DEBUG - 2018-10-12 18:35:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 18:35:44 --> CSRF cookie sent
INFO - 2018-10-12 18:35:44 --> CSRF token verified
INFO - 2018-10-12 18:35:44 --> Input Class Initialized
INFO - 2018-10-12 18:35:44 --> Language Class Initialized
INFO - 2018-10-12 18:35:44 --> Loader Class Initialized
INFO - 2018-10-12 18:35:44 --> Helper loaded: url_helper
INFO - 2018-10-12 18:35:44 --> Helper loaded: form_helper
INFO - 2018-10-12 18:35:44 --> Helper loaded: language_helper
DEBUG - 2018-10-12 18:35:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 18:35:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 18:35:44 --> User Agent Class Initialized
INFO - 2018-10-12 18:35:44 --> Controller Class Initialized
INFO - 2018-10-12 18:35:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 18:35:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 18:35:44 --> Pixel_Model class loaded
INFO - 2018-10-12 18:35:44 --> Database Driver Class Initialized
INFO - 2018-10-12 18:35:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:35:44 --> Form Validation Class Initialized
INFO - 2018-10-12 18:35:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-12 18:35:44 --> Database Driver Class Initialized
INFO - 2018-10-12 18:35:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:35:44 --> Config Class Initialized
INFO - 2018-10-12 18:35:44 --> Hooks Class Initialized
DEBUG - 2018-10-12 18:35:44 --> UTF-8 Support Enabled
INFO - 2018-10-12 18:35:44 --> Utf8 Class Initialized
INFO - 2018-10-12 18:35:44 --> URI Class Initialized
INFO - 2018-10-12 18:35:44 --> Router Class Initialized
INFO - 2018-10-12 18:35:44 --> Output Class Initialized
INFO - 2018-10-12 18:35:44 --> Security Class Initialized
DEBUG - 2018-10-12 18:35:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 18:35:44 --> CSRF cookie sent
INFO - 2018-10-12 18:35:44 --> Input Class Initialized
INFO - 2018-10-12 18:35:44 --> Language Class Initialized
INFO - 2018-10-12 18:35:44 --> Loader Class Initialized
INFO - 2018-10-12 18:35:44 --> Helper loaded: url_helper
INFO - 2018-10-12 18:35:44 --> Helper loaded: form_helper
INFO - 2018-10-12 18:35:44 --> Helper loaded: language_helper
DEBUG - 2018-10-12 18:35:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 18:35:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 18:35:44 --> User Agent Class Initialized
INFO - 2018-10-12 18:35:44 --> Controller Class Initialized
INFO - 2018-10-12 18:35:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 18:35:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 18:35:44 --> Pixel_Model class loaded
INFO - 2018-10-12 18:35:44 --> Database Driver Class Initialized
INFO - 2018-10-12 18:35:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:35:44 --> Database Driver Class Initialized
INFO - 2018-10-12 18:35:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:35:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 18:35:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 18:35:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 18:35:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 18:35:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 18:35:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 18:35:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-10-12 18:35:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 18:35:44 --> Final output sent to browser
DEBUG - 2018-10-12 18:35:44 --> Total execution time: 0.0476
INFO - 2018-10-12 18:35:53 --> Config Class Initialized
INFO - 2018-10-12 18:35:53 --> Hooks Class Initialized
DEBUG - 2018-10-12 18:35:53 --> UTF-8 Support Enabled
INFO - 2018-10-12 18:35:53 --> Utf8 Class Initialized
INFO - 2018-10-12 18:35:53 --> URI Class Initialized
INFO - 2018-10-12 18:35:53 --> Router Class Initialized
INFO - 2018-10-12 18:35:53 --> Output Class Initialized
INFO - 2018-10-12 18:35:53 --> Security Class Initialized
DEBUG - 2018-10-12 18:35:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 18:35:53 --> CSRF cookie sent
INFO - 2018-10-12 18:35:53 --> CSRF token verified
INFO - 2018-10-12 18:35:53 --> Input Class Initialized
INFO - 2018-10-12 18:35:53 --> Language Class Initialized
INFO - 2018-10-12 18:35:53 --> Loader Class Initialized
INFO - 2018-10-12 18:35:53 --> Helper loaded: url_helper
INFO - 2018-10-12 18:35:53 --> Helper loaded: form_helper
INFO - 2018-10-12 18:35:53 --> Helper loaded: language_helper
DEBUG - 2018-10-12 18:35:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 18:35:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 18:35:53 --> User Agent Class Initialized
INFO - 2018-10-12 18:35:53 --> Controller Class Initialized
INFO - 2018-10-12 18:35:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 18:35:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 18:35:53 --> Pixel_Model class loaded
INFO - 2018-10-12 18:35:53 --> Database Driver Class Initialized
INFO - 2018-10-12 18:35:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:35:53 --> Form Validation Class Initialized
INFO - 2018-10-12 18:35:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-12 18:35:53 --> Database Driver Class Initialized
INFO - 2018-10-12 18:35:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:35:53 --> Config Class Initialized
INFO - 2018-10-12 18:35:53 --> Hooks Class Initialized
DEBUG - 2018-10-12 18:35:53 --> UTF-8 Support Enabled
INFO - 2018-10-12 18:35:53 --> Utf8 Class Initialized
INFO - 2018-10-12 18:35:53 --> URI Class Initialized
INFO - 2018-10-12 18:35:53 --> Router Class Initialized
INFO - 2018-10-12 18:35:53 --> Output Class Initialized
INFO - 2018-10-12 18:35:53 --> Security Class Initialized
DEBUG - 2018-10-12 18:35:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 18:35:53 --> CSRF cookie sent
INFO - 2018-10-12 18:35:53 --> Input Class Initialized
INFO - 2018-10-12 18:35:53 --> Language Class Initialized
INFO - 2018-10-12 18:35:53 --> Loader Class Initialized
INFO - 2018-10-12 18:35:53 --> Helper loaded: url_helper
INFO - 2018-10-12 18:35:53 --> Helper loaded: form_helper
INFO - 2018-10-12 18:35:53 --> Helper loaded: language_helper
DEBUG - 2018-10-12 18:35:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 18:35:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 18:35:53 --> User Agent Class Initialized
INFO - 2018-10-12 18:35:53 --> Controller Class Initialized
INFO - 2018-10-12 18:35:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 18:35:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 18:35:53 --> Pixel_Model class loaded
INFO - 2018-10-12 18:35:53 --> Database Driver Class Initialized
INFO - 2018-10-12 18:35:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:35:53 --> Database Driver Class Initialized
INFO - 2018-10-12 18:35:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:35:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 18:35:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 18:35:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 18:35:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 18:35:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 18:35:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 18:35:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-10-12 18:35:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 18:35:53 --> Final output sent to browser
DEBUG - 2018-10-12 18:35:53 --> Total execution time: 0.0658
INFO - 2018-10-12 18:36:00 --> Config Class Initialized
INFO - 2018-10-12 18:36:00 --> Hooks Class Initialized
DEBUG - 2018-10-12 18:36:00 --> UTF-8 Support Enabled
INFO - 2018-10-12 18:36:00 --> Utf8 Class Initialized
INFO - 2018-10-12 18:36:00 --> URI Class Initialized
INFO - 2018-10-12 18:36:00 --> Router Class Initialized
INFO - 2018-10-12 18:36:00 --> Output Class Initialized
INFO - 2018-10-12 18:36:00 --> Security Class Initialized
DEBUG - 2018-10-12 18:36:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 18:36:00 --> CSRF cookie sent
INFO - 2018-10-12 18:36:00 --> CSRF token verified
INFO - 2018-10-12 18:36:00 --> Input Class Initialized
INFO - 2018-10-12 18:36:00 --> Language Class Initialized
INFO - 2018-10-12 18:36:00 --> Loader Class Initialized
INFO - 2018-10-12 18:36:00 --> Helper loaded: url_helper
INFO - 2018-10-12 18:36:00 --> Helper loaded: form_helper
INFO - 2018-10-12 18:36:00 --> Helper loaded: language_helper
DEBUG - 2018-10-12 18:36:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 18:36:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 18:36:00 --> User Agent Class Initialized
INFO - 2018-10-12 18:36:00 --> Controller Class Initialized
INFO - 2018-10-12 18:36:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 18:36:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 18:36:00 --> Pixel_Model class loaded
INFO - 2018-10-12 18:36:00 --> Database Driver Class Initialized
INFO - 2018-10-12 18:36:00 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:36:00 --> Form Validation Class Initialized
INFO - 2018-10-12 18:36:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-12 18:36:00 --> Database Driver Class Initialized
INFO - 2018-10-12 18:36:00 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:36:00 --> Config Class Initialized
INFO - 2018-10-12 18:36:00 --> Hooks Class Initialized
DEBUG - 2018-10-12 18:36:00 --> UTF-8 Support Enabled
INFO - 2018-10-12 18:36:00 --> Utf8 Class Initialized
INFO - 2018-10-12 18:36:00 --> URI Class Initialized
INFO - 2018-10-12 18:36:00 --> Router Class Initialized
INFO - 2018-10-12 18:36:00 --> Output Class Initialized
INFO - 2018-10-12 18:36:00 --> Security Class Initialized
DEBUG - 2018-10-12 18:36:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 18:36:00 --> CSRF cookie sent
INFO - 2018-10-12 18:36:00 --> Input Class Initialized
INFO - 2018-10-12 18:36:00 --> Language Class Initialized
INFO - 2018-10-12 18:36:00 --> Loader Class Initialized
INFO - 2018-10-12 18:36:00 --> Helper loaded: url_helper
INFO - 2018-10-12 18:36:00 --> Helper loaded: form_helper
INFO - 2018-10-12 18:36:00 --> Helper loaded: language_helper
DEBUG - 2018-10-12 18:36:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 18:36:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 18:36:00 --> User Agent Class Initialized
INFO - 2018-10-12 18:36:00 --> Controller Class Initialized
INFO - 2018-10-12 18:36:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 18:36:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 18:36:00 --> Pixel_Model class loaded
INFO - 2018-10-12 18:36:00 --> Database Driver Class Initialized
INFO - 2018-10-12 18:36:00 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:36:00 --> Database Driver Class Initialized
INFO - 2018-10-12 18:36:00 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:36:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 18:36:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 18:36:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 18:36:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 18:36:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 18:36:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 18:36:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_owner.php
INFO - 2018-10-12 18:36:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 18:36:00 --> Final output sent to browser
DEBUG - 2018-10-12 18:36:00 --> Total execution time: 0.0462
INFO - 2018-10-12 18:36:06 --> Config Class Initialized
INFO - 2018-10-12 18:36:06 --> Hooks Class Initialized
DEBUG - 2018-10-12 18:36:06 --> UTF-8 Support Enabled
INFO - 2018-10-12 18:36:06 --> Utf8 Class Initialized
INFO - 2018-10-12 18:36:06 --> URI Class Initialized
INFO - 2018-10-12 18:36:06 --> Router Class Initialized
INFO - 2018-10-12 18:36:06 --> Output Class Initialized
INFO - 2018-10-12 18:36:06 --> Security Class Initialized
DEBUG - 2018-10-12 18:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 18:36:06 --> CSRF cookie sent
INFO - 2018-10-12 18:36:06 --> CSRF token verified
INFO - 2018-10-12 18:36:06 --> Input Class Initialized
INFO - 2018-10-12 18:36:06 --> Language Class Initialized
INFO - 2018-10-12 18:36:06 --> Loader Class Initialized
INFO - 2018-10-12 18:36:06 --> Helper loaded: url_helper
INFO - 2018-10-12 18:36:06 --> Helper loaded: form_helper
INFO - 2018-10-12 18:36:06 --> Helper loaded: language_helper
DEBUG - 2018-10-12 18:36:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 18:36:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 18:36:06 --> User Agent Class Initialized
INFO - 2018-10-12 18:36:06 --> Controller Class Initialized
INFO - 2018-10-12 18:36:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 18:36:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 18:36:06 --> Pixel_Model class loaded
INFO - 2018-10-12 18:36:06 --> Database Driver Class Initialized
INFO - 2018-10-12 18:36:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:36:06 --> Form Validation Class Initialized
INFO - 2018-10-12 18:36:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-12 18:36:06 --> Database Driver Class Initialized
INFO - 2018-10-12 18:36:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:36:06 --> Config Class Initialized
INFO - 2018-10-12 18:36:06 --> Hooks Class Initialized
DEBUG - 2018-10-12 18:36:06 --> UTF-8 Support Enabled
INFO - 2018-10-12 18:36:06 --> Utf8 Class Initialized
INFO - 2018-10-12 18:36:06 --> URI Class Initialized
INFO - 2018-10-12 18:36:06 --> Router Class Initialized
INFO - 2018-10-12 18:36:06 --> Output Class Initialized
INFO - 2018-10-12 18:36:06 --> Security Class Initialized
DEBUG - 2018-10-12 18:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 18:36:06 --> CSRF cookie sent
INFO - 2018-10-12 18:36:06 --> Input Class Initialized
INFO - 2018-10-12 18:36:06 --> Language Class Initialized
INFO - 2018-10-12 18:36:06 --> Loader Class Initialized
INFO - 2018-10-12 18:36:06 --> Helper loaded: url_helper
INFO - 2018-10-12 18:36:06 --> Helper loaded: form_helper
INFO - 2018-10-12 18:36:06 --> Helper loaded: language_helper
DEBUG - 2018-10-12 18:36:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 18:36:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 18:36:06 --> User Agent Class Initialized
INFO - 2018-10-12 18:36:06 --> Controller Class Initialized
INFO - 2018-10-12 18:36:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 18:36:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 18:36:06 --> Pixel_Model class loaded
INFO - 2018-10-12 18:36:06 --> Database Driver Class Initialized
INFO - 2018-10-12 18:36:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:36:06 --> Database Driver Class Initialized
INFO - 2018-10-12 18:36:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:36:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 18:36:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 18:36:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 18:36:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 18:36:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 18:36:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 18:36:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-10-12 18:36:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 18:36:06 --> Final output sent to browser
DEBUG - 2018-10-12 18:36:06 --> Total execution time: 0.0497
INFO - 2018-10-12 18:36:09 --> Config Class Initialized
INFO - 2018-10-12 18:36:09 --> Hooks Class Initialized
DEBUG - 2018-10-12 18:36:09 --> UTF-8 Support Enabled
INFO - 2018-10-12 18:36:09 --> Utf8 Class Initialized
INFO - 2018-10-12 18:36:09 --> URI Class Initialized
INFO - 2018-10-12 18:36:09 --> Router Class Initialized
INFO - 2018-10-12 18:36:09 --> Output Class Initialized
INFO - 2018-10-12 18:36:09 --> Security Class Initialized
DEBUG - 2018-10-12 18:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 18:36:09 --> CSRF cookie sent
INFO - 2018-10-12 18:36:09 --> CSRF token verified
INFO - 2018-10-12 18:36:09 --> Input Class Initialized
INFO - 2018-10-12 18:36:09 --> Language Class Initialized
INFO - 2018-10-12 18:36:09 --> Loader Class Initialized
INFO - 2018-10-12 18:36:09 --> Helper loaded: url_helper
INFO - 2018-10-12 18:36:09 --> Helper loaded: form_helper
INFO - 2018-10-12 18:36:09 --> Helper loaded: language_helper
DEBUG - 2018-10-12 18:36:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 18:36:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 18:36:09 --> User Agent Class Initialized
INFO - 2018-10-12 18:36:09 --> Controller Class Initialized
INFO - 2018-10-12 18:36:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 18:36:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 18:36:09 --> Pixel_Model class loaded
INFO - 2018-10-12 18:36:09 --> Database Driver Class Initialized
INFO - 2018-10-12 18:36:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:36:09 --> Form Validation Class Initialized
INFO - 2018-10-12 18:36:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-12 18:36:09 --> Database Driver Class Initialized
INFO - 2018-10-12 18:36:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:36:09 --> Config Class Initialized
INFO - 2018-10-12 18:36:09 --> Hooks Class Initialized
DEBUG - 2018-10-12 18:36:10 --> UTF-8 Support Enabled
INFO - 2018-10-12 18:36:10 --> Utf8 Class Initialized
INFO - 2018-10-12 18:36:10 --> URI Class Initialized
INFO - 2018-10-12 18:36:10 --> Router Class Initialized
INFO - 2018-10-12 18:36:10 --> Output Class Initialized
INFO - 2018-10-12 18:36:10 --> Security Class Initialized
DEBUG - 2018-10-12 18:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 18:36:10 --> CSRF cookie sent
INFO - 2018-10-12 18:36:10 --> Input Class Initialized
INFO - 2018-10-12 18:36:10 --> Language Class Initialized
INFO - 2018-10-12 18:36:10 --> Loader Class Initialized
INFO - 2018-10-12 18:36:10 --> Helper loaded: url_helper
INFO - 2018-10-12 18:36:10 --> Helper loaded: form_helper
INFO - 2018-10-12 18:36:10 --> Helper loaded: language_helper
DEBUG - 2018-10-12 18:36:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 18:36:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 18:36:10 --> User Agent Class Initialized
INFO - 2018-10-12 18:36:10 --> Controller Class Initialized
INFO - 2018-10-12 18:36:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 18:36:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 18:36:10 --> Pixel_Model class loaded
INFO - 2018-10-12 18:36:10 --> Database Driver Class Initialized
INFO - 2018-10-12 18:36:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:36:10 --> Database Driver Class Initialized
INFO - 2018-10-12 18:36:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:36:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 18:36:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 18:36:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 18:36:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 18:36:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-10-12 18:36:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 18:36:10 --> Final output sent to browser
DEBUG - 2018-10-12 18:36:10 --> Total execution time: 0.0504
INFO - 2018-10-12 18:36:13 --> Config Class Initialized
INFO - 2018-10-12 18:36:13 --> Hooks Class Initialized
DEBUG - 2018-10-12 18:36:13 --> UTF-8 Support Enabled
INFO - 2018-10-12 18:36:13 --> Utf8 Class Initialized
INFO - 2018-10-12 18:36:13 --> URI Class Initialized
INFO - 2018-10-12 18:36:13 --> Router Class Initialized
INFO - 2018-10-12 18:36:13 --> Output Class Initialized
INFO - 2018-10-12 18:36:13 --> Security Class Initialized
DEBUG - 2018-10-12 18:36:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 18:36:13 --> CSRF cookie sent
INFO - 2018-10-12 18:36:13 --> Input Class Initialized
INFO - 2018-10-12 18:36:13 --> Language Class Initialized
INFO - 2018-10-12 18:36:13 --> Loader Class Initialized
INFO - 2018-10-12 18:36:13 --> Helper loaded: url_helper
INFO - 2018-10-12 18:36:13 --> Helper loaded: form_helper
INFO - 2018-10-12 18:36:13 --> Helper loaded: language_helper
DEBUG - 2018-10-12 18:36:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 18:36:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 18:36:13 --> User Agent Class Initialized
INFO - 2018-10-12 18:36:13 --> Controller Class Initialized
INFO - 2018-10-12 18:36:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 18:36:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 18:36:13 --> Pixel_Model class loaded
INFO - 2018-10-12 18:36:13 --> Database Driver Class Initialized
INFO - 2018-10-12 18:36:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:36:13 --> Config Class Initialized
INFO - 2018-10-12 18:36:13 --> Hooks Class Initialized
DEBUG - 2018-10-12 18:36:13 --> UTF-8 Support Enabled
INFO - 2018-10-12 18:36:13 --> Utf8 Class Initialized
INFO - 2018-10-12 18:36:13 --> URI Class Initialized
INFO - 2018-10-12 18:36:13 --> Router Class Initialized
INFO - 2018-10-12 18:36:13 --> Output Class Initialized
INFO - 2018-10-12 18:36:13 --> Security Class Initialized
DEBUG - 2018-10-12 18:36:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 18:36:13 --> CSRF cookie sent
INFO - 2018-10-12 18:36:13 --> Input Class Initialized
INFO - 2018-10-12 18:36:13 --> Language Class Initialized
INFO - 2018-10-12 18:36:13 --> Loader Class Initialized
INFO - 2018-10-12 18:36:13 --> Helper loaded: url_helper
INFO - 2018-10-12 18:36:13 --> Helper loaded: form_helper
INFO - 2018-10-12 18:36:13 --> Helper loaded: language_helper
DEBUG - 2018-10-12 18:36:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 18:36:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 18:36:13 --> User Agent Class Initialized
INFO - 2018-10-12 18:36:13 --> Controller Class Initialized
INFO - 2018-10-12 18:36:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 18:36:13 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-12 18:36:13 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-10-12 18:36:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 18:36:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 18:36:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 18:36:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-10-12 18:36:13 --> Could not find the language line "req_email"
INFO - 2018-10-12 18:36:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-10-12 18:36:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 18:36:13 --> Final output sent to browser
DEBUG - 2018-10-12 18:36:13 --> Total execution time: 0.0214
INFO - 2018-10-12 18:36:34 --> Config Class Initialized
INFO - 2018-10-12 18:36:34 --> Hooks Class Initialized
DEBUG - 2018-10-12 18:36:34 --> UTF-8 Support Enabled
INFO - 2018-10-12 18:36:34 --> Utf8 Class Initialized
INFO - 2018-10-12 18:36:34 --> URI Class Initialized
INFO - 2018-10-12 18:36:34 --> Router Class Initialized
INFO - 2018-10-12 18:36:34 --> Output Class Initialized
INFO - 2018-10-12 18:36:34 --> Security Class Initialized
DEBUG - 2018-10-12 18:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 18:36:34 --> CSRF cookie sent
INFO - 2018-10-12 18:36:34 --> Input Class Initialized
INFO - 2018-10-12 18:36:34 --> Language Class Initialized
INFO - 2018-10-12 18:36:34 --> Loader Class Initialized
INFO - 2018-10-12 18:36:34 --> Helper loaded: url_helper
INFO - 2018-10-12 18:36:34 --> Helper loaded: form_helper
INFO - 2018-10-12 18:36:34 --> Helper loaded: language_helper
DEBUG - 2018-10-12 18:36:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 18:36:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 18:36:34 --> User Agent Class Initialized
INFO - 2018-10-12 18:36:34 --> Controller Class Initialized
INFO - 2018-10-12 18:36:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 18:36:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 18:36:34 --> Pixel_Model class loaded
INFO - 2018-10-12 18:36:34 --> Database Driver Class Initialized
INFO - 2018-10-12 18:36:34 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:36:34 --> Database Driver Class Initialized
INFO - 2018-10-12 18:36:34 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:36:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 18:36:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 18:36:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 18:36:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 18:36:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-10-12 18:36:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 18:36:34 --> Final output sent to browser
DEBUG - 2018-10-12 18:36:34 --> Total execution time: 0.0579
INFO - 2018-10-12 18:36:37 --> Config Class Initialized
INFO - 2018-10-12 18:36:37 --> Hooks Class Initialized
DEBUG - 2018-10-12 18:36:37 --> UTF-8 Support Enabled
INFO - 2018-10-12 18:36:37 --> Utf8 Class Initialized
INFO - 2018-10-12 18:36:37 --> URI Class Initialized
INFO - 2018-10-12 18:36:37 --> Router Class Initialized
INFO - 2018-10-12 18:36:37 --> Output Class Initialized
INFO - 2018-10-12 18:36:37 --> Security Class Initialized
DEBUG - 2018-10-12 18:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 18:36:37 --> CSRF cookie sent
INFO - 2018-10-12 18:36:37 --> Input Class Initialized
INFO - 2018-10-12 18:36:37 --> Language Class Initialized
INFO - 2018-10-12 18:36:37 --> Loader Class Initialized
INFO - 2018-10-12 18:36:37 --> Helper loaded: url_helper
INFO - 2018-10-12 18:36:37 --> Helper loaded: form_helper
INFO - 2018-10-12 18:36:37 --> Helper loaded: language_helper
DEBUG - 2018-10-12 18:36:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 18:36:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 18:36:37 --> User Agent Class Initialized
INFO - 2018-10-12 18:36:37 --> Controller Class Initialized
INFO - 2018-10-12 18:36:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 18:36:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 18:36:37 --> Pixel_Model class loaded
INFO - 2018-10-12 18:36:38 --> Database Driver Class Initialized
INFO - 2018-10-12 18:36:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:36:38 --> Database Driver Class Initialized
INFO - 2018-10-12 18:36:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:36:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 18:36:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 18:36:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 18:36:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 18:36:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 18:36:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 18:36:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-10-12 18:36:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 18:36:38 --> Final output sent to browser
DEBUG - 2018-10-12 18:36:38 --> Total execution time: 0.0528
INFO - 2018-10-12 18:40:52 --> Config Class Initialized
INFO - 2018-10-12 18:40:52 --> Hooks Class Initialized
DEBUG - 2018-10-12 18:40:52 --> UTF-8 Support Enabled
INFO - 2018-10-12 18:40:52 --> Utf8 Class Initialized
INFO - 2018-10-12 18:40:52 --> URI Class Initialized
INFO - 2018-10-12 18:40:52 --> Router Class Initialized
INFO - 2018-10-12 18:40:52 --> Output Class Initialized
INFO - 2018-10-12 18:40:52 --> Security Class Initialized
DEBUG - 2018-10-12 18:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 18:40:52 --> CSRF cookie sent
INFO - 2018-10-12 18:40:52 --> Input Class Initialized
INFO - 2018-10-12 18:40:52 --> Language Class Initialized
INFO - 2018-10-12 18:40:52 --> Loader Class Initialized
INFO - 2018-10-12 18:40:52 --> Helper loaded: url_helper
INFO - 2018-10-12 18:40:52 --> Helper loaded: form_helper
INFO - 2018-10-12 18:40:52 --> Helper loaded: language_helper
DEBUG - 2018-10-12 18:40:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 18:40:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 18:40:52 --> User Agent Class Initialized
INFO - 2018-10-12 18:40:52 --> Controller Class Initialized
INFO - 2018-10-12 18:40:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 18:40:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 18:40:52 --> Pixel_Model class loaded
INFO - 2018-10-12 18:40:52 --> Database Driver Class Initialized
INFO - 2018-10-12 18:40:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:40:52 --> Database Driver Class Initialized
INFO - 2018-10-12 18:40:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:40:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 18:40:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 18:40:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 18:40:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 18:40:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 18:40:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 18:40:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-12 18:40:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 18:40:52 --> Final output sent to browser
DEBUG - 2018-10-12 18:40:52 --> Total execution time: 0.0620
INFO - 2018-10-12 18:40:54 --> Config Class Initialized
INFO - 2018-10-12 18:40:54 --> Hooks Class Initialized
DEBUG - 2018-10-12 18:40:54 --> UTF-8 Support Enabled
INFO - 2018-10-12 18:40:54 --> Utf8 Class Initialized
INFO - 2018-10-12 18:40:54 --> URI Class Initialized
INFO - 2018-10-12 18:40:54 --> Router Class Initialized
INFO - 2018-10-12 18:40:54 --> Output Class Initialized
INFO - 2018-10-12 18:40:54 --> Security Class Initialized
DEBUG - 2018-10-12 18:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 18:40:54 --> CSRF cookie sent
INFO - 2018-10-12 18:40:54 --> Input Class Initialized
INFO - 2018-10-12 18:40:54 --> Language Class Initialized
INFO - 2018-10-12 18:40:54 --> Loader Class Initialized
INFO - 2018-10-12 18:40:54 --> Helper loaded: url_helper
INFO - 2018-10-12 18:40:54 --> Helper loaded: form_helper
INFO - 2018-10-12 18:40:54 --> Helper loaded: language_helper
DEBUG - 2018-10-12 18:40:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 18:40:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 18:40:54 --> User Agent Class Initialized
INFO - 2018-10-12 18:40:54 --> Controller Class Initialized
INFO - 2018-10-12 18:40:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 18:40:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 18:40:54 --> Pixel_Model class loaded
INFO - 2018-10-12 18:40:54 --> Database Driver Class Initialized
INFO - 2018-10-12 18:40:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:40:54 --> Database Driver Class Initialized
INFO - 2018-10-12 18:40:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:40:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 18:40:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 18:40:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 18:40:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 18:40:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/save_exit.php
INFO - 2018-10-12 18:40:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 18:40:54 --> Final output sent to browser
DEBUG - 2018-10-12 18:40:54 --> Total execution time: 0.0558
INFO - 2018-10-12 18:40:55 --> Config Class Initialized
INFO - 2018-10-12 18:40:55 --> Hooks Class Initialized
DEBUG - 2018-10-12 18:40:55 --> UTF-8 Support Enabled
INFO - 2018-10-12 18:40:55 --> Utf8 Class Initialized
INFO - 2018-10-12 18:40:55 --> URI Class Initialized
INFO - 2018-10-12 18:40:55 --> Router Class Initialized
INFO - 2018-10-12 18:40:55 --> Output Class Initialized
INFO - 2018-10-12 18:40:55 --> Security Class Initialized
DEBUG - 2018-10-12 18:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 18:40:55 --> CSRF cookie sent
INFO - 2018-10-12 18:40:55 --> Input Class Initialized
INFO - 2018-10-12 18:40:55 --> Language Class Initialized
INFO - 2018-10-12 18:40:55 --> Loader Class Initialized
INFO - 2018-10-12 18:40:55 --> Helper loaded: url_helper
INFO - 2018-10-12 18:40:55 --> Helper loaded: form_helper
INFO - 2018-10-12 18:40:55 --> Helper loaded: language_helper
DEBUG - 2018-10-12 18:40:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 18:40:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 18:40:55 --> User Agent Class Initialized
INFO - 2018-10-12 18:40:55 --> Controller Class Initialized
INFO - 2018-10-12 18:40:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 18:40:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 18:40:55 --> Pixel_Model class loaded
INFO - 2018-10-12 18:40:55 --> Database Driver Class Initialized
INFO - 2018-10-12 18:40:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 18:40:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 18:40:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 18:40:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 18:40:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 18:40:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/contact_us.php
INFO - 2018-10-12 18:40:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 18:40:55 --> Final output sent to browser
DEBUG - 2018-10-12 18:40:55 --> Total execution time: 0.0618
INFO - 2018-10-12 19:53:35 --> Config Class Initialized
INFO - 2018-10-12 19:53:35 --> Hooks Class Initialized
DEBUG - 2018-10-12 19:53:35 --> UTF-8 Support Enabled
INFO - 2018-10-12 19:53:35 --> Utf8 Class Initialized
INFO - 2018-10-12 19:53:35 --> URI Class Initialized
INFO - 2018-10-12 19:53:35 --> Router Class Initialized
INFO - 2018-10-12 19:53:35 --> Output Class Initialized
INFO - 2018-10-12 19:53:35 --> Security Class Initialized
DEBUG - 2018-10-12 19:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 19:53:35 --> CSRF cookie sent
INFO - 2018-10-12 19:53:35 --> Input Class Initialized
INFO - 2018-10-12 19:53:35 --> Language Class Initialized
INFO - 2018-10-12 19:53:35 --> Loader Class Initialized
INFO - 2018-10-12 19:53:35 --> Helper loaded: url_helper
INFO - 2018-10-12 19:53:35 --> Helper loaded: form_helper
INFO - 2018-10-12 19:53:35 --> Helper loaded: language_helper
DEBUG - 2018-10-12 19:53:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 19:53:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 19:53:35 --> User Agent Class Initialized
INFO - 2018-10-12 19:53:35 --> Controller Class Initialized
INFO - 2018-10-12 19:53:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 19:53:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 19:53:35 --> Pixel_Model class loaded
INFO - 2018-10-12 19:53:35 --> Database Driver Class Initialized
INFO - 2018-10-12 19:53:35 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 19:53:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 19:53:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 19:53:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 19:53:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 19:53:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 19:53:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 19:53:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-10-12 19:53:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 19:53:35 --> Final output sent to browser
DEBUG - 2018-10-12 19:53:35 --> Total execution time: 0.0535
INFO - 2018-10-12 19:53:39 --> Config Class Initialized
INFO - 2018-10-12 19:53:39 --> Hooks Class Initialized
DEBUG - 2018-10-12 19:53:39 --> UTF-8 Support Enabled
INFO - 2018-10-12 19:53:39 --> Utf8 Class Initialized
INFO - 2018-10-12 19:53:39 --> URI Class Initialized
INFO - 2018-10-12 19:53:39 --> Router Class Initialized
INFO - 2018-10-12 19:53:39 --> Output Class Initialized
INFO - 2018-10-12 19:53:39 --> Security Class Initialized
DEBUG - 2018-10-12 19:53:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 19:53:39 --> CSRF cookie sent
INFO - 2018-10-12 19:53:39 --> CSRF token verified
INFO - 2018-10-12 19:53:39 --> Input Class Initialized
INFO - 2018-10-12 19:53:39 --> Language Class Initialized
INFO - 2018-10-12 19:53:39 --> Loader Class Initialized
INFO - 2018-10-12 19:53:39 --> Helper loaded: url_helper
INFO - 2018-10-12 19:53:39 --> Helper loaded: form_helper
INFO - 2018-10-12 19:53:39 --> Helper loaded: language_helper
DEBUG - 2018-10-12 19:53:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 19:53:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 19:53:39 --> User Agent Class Initialized
INFO - 2018-10-12 19:53:39 --> Controller Class Initialized
INFO - 2018-10-12 19:53:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 19:53:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 19:53:39 --> Pixel_Model class loaded
INFO - 2018-10-12 19:53:39 --> Database Driver Class Initialized
INFO - 2018-10-12 19:53:39 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 19:53:39 --> Form Validation Class Initialized
INFO - 2018-10-12 19:53:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-12 19:53:39 --> Database Driver Class Initialized
INFO - 2018-10-12 19:53:39 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 19:53:40 --> Config Class Initialized
INFO - 2018-10-12 19:53:40 --> Hooks Class Initialized
DEBUG - 2018-10-12 19:53:40 --> UTF-8 Support Enabled
INFO - 2018-10-12 19:53:40 --> Utf8 Class Initialized
INFO - 2018-10-12 19:53:40 --> URI Class Initialized
INFO - 2018-10-12 19:53:40 --> Router Class Initialized
INFO - 2018-10-12 19:53:40 --> Output Class Initialized
INFO - 2018-10-12 19:53:40 --> Security Class Initialized
DEBUG - 2018-10-12 19:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 19:53:40 --> CSRF cookie sent
INFO - 2018-10-12 19:53:40 --> Input Class Initialized
INFO - 2018-10-12 19:53:40 --> Language Class Initialized
INFO - 2018-10-12 19:53:40 --> Loader Class Initialized
INFO - 2018-10-12 19:53:40 --> Helper loaded: url_helper
INFO - 2018-10-12 19:53:40 --> Helper loaded: form_helper
INFO - 2018-10-12 19:53:40 --> Helper loaded: language_helper
DEBUG - 2018-10-12 19:53:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 19:53:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 19:53:40 --> User Agent Class Initialized
INFO - 2018-10-12 19:53:40 --> Controller Class Initialized
INFO - 2018-10-12 19:53:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 19:53:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 19:53:40 --> Pixel_Model class loaded
INFO - 2018-10-12 19:53:40 --> Database Driver Class Initialized
INFO - 2018-10-12 19:53:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 19:53:40 --> Database Driver Class Initialized
INFO - 2018-10-12 19:53:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 19:53:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 19:53:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 19:53:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 19:53:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 19:53:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 19:53:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 19:53:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-12 19:53:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 19:53:40 --> Final output sent to browser
DEBUG - 2018-10-12 19:53:40 --> Total execution time: 0.0513
INFO - 2018-10-12 19:53:43 --> Config Class Initialized
INFO - 2018-10-12 19:53:43 --> Hooks Class Initialized
DEBUG - 2018-10-12 19:53:43 --> UTF-8 Support Enabled
INFO - 2018-10-12 19:53:43 --> Utf8 Class Initialized
INFO - 2018-10-12 19:53:43 --> URI Class Initialized
INFO - 2018-10-12 19:53:43 --> Router Class Initialized
INFO - 2018-10-12 19:53:43 --> Output Class Initialized
INFO - 2018-10-12 19:53:43 --> Security Class Initialized
DEBUG - 2018-10-12 19:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 19:53:43 --> CSRF cookie sent
INFO - 2018-10-12 19:53:43 --> CSRF token verified
INFO - 2018-10-12 19:53:43 --> Input Class Initialized
INFO - 2018-10-12 19:53:43 --> Language Class Initialized
INFO - 2018-10-12 19:53:43 --> Loader Class Initialized
INFO - 2018-10-12 19:53:43 --> Helper loaded: url_helper
INFO - 2018-10-12 19:53:43 --> Helper loaded: form_helper
INFO - 2018-10-12 19:53:43 --> Helper loaded: language_helper
DEBUG - 2018-10-12 19:53:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 19:53:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 19:53:43 --> User Agent Class Initialized
INFO - 2018-10-12 19:53:43 --> Controller Class Initialized
INFO - 2018-10-12 19:53:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 19:53:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 19:53:43 --> Pixel_Model class loaded
INFO - 2018-10-12 19:53:43 --> Database Driver Class Initialized
INFO - 2018-10-12 19:53:43 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 19:53:43 --> Form Validation Class Initialized
INFO - 2018-10-12 19:53:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-12 19:53:43 --> Database Driver Class Initialized
INFO - 2018-10-12 19:53:43 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 19:53:44 --> Config Class Initialized
INFO - 2018-10-12 19:53:44 --> Hooks Class Initialized
DEBUG - 2018-10-12 19:53:44 --> UTF-8 Support Enabled
INFO - 2018-10-12 19:53:44 --> Utf8 Class Initialized
INFO - 2018-10-12 19:53:44 --> URI Class Initialized
INFO - 2018-10-12 19:53:44 --> Router Class Initialized
INFO - 2018-10-12 19:53:44 --> Output Class Initialized
INFO - 2018-10-12 19:53:44 --> Security Class Initialized
DEBUG - 2018-10-12 19:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 19:53:44 --> CSRF cookie sent
INFO - 2018-10-12 19:53:44 --> Input Class Initialized
INFO - 2018-10-12 19:53:44 --> Language Class Initialized
INFO - 2018-10-12 19:53:44 --> Loader Class Initialized
INFO - 2018-10-12 19:53:44 --> Helper loaded: url_helper
INFO - 2018-10-12 19:53:44 --> Helper loaded: form_helper
INFO - 2018-10-12 19:53:44 --> Helper loaded: language_helper
DEBUG - 2018-10-12 19:53:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 19:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 19:53:44 --> User Agent Class Initialized
INFO - 2018-10-12 19:53:44 --> Controller Class Initialized
INFO - 2018-10-12 19:53:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 19:53:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 19:53:44 --> Pixel_Model class loaded
INFO - 2018-10-12 19:53:44 --> Database Driver Class Initialized
INFO - 2018-10-12 19:53:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 19:53:44 --> Database Driver Class Initialized
INFO - 2018-10-12 19:53:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 19:53:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 19:53:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 19:53:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 19:53:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 19:53:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 19:53:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 19:53:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-10-12 19:53:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 19:53:44 --> Final output sent to browser
DEBUG - 2018-10-12 19:53:44 --> Total execution time: 0.0610
INFO - 2018-10-12 19:53:46 --> Config Class Initialized
INFO - 2018-10-12 19:53:46 --> Hooks Class Initialized
DEBUG - 2018-10-12 19:53:46 --> UTF-8 Support Enabled
INFO - 2018-10-12 19:53:46 --> Utf8 Class Initialized
INFO - 2018-10-12 19:53:46 --> URI Class Initialized
INFO - 2018-10-12 19:53:46 --> Router Class Initialized
INFO - 2018-10-12 19:53:46 --> Output Class Initialized
INFO - 2018-10-12 19:53:46 --> Security Class Initialized
DEBUG - 2018-10-12 19:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 19:53:46 --> CSRF cookie sent
INFO - 2018-10-12 19:53:46 --> CSRF token verified
INFO - 2018-10-12 19:53:46 --> Input Class Initialized
INFO - 2018-10-12 19:53:46 --> Language Class Initialized
INFO - 2018-10-12 19:53:46 --> Loader Class Initialized
INFO - 2018-10-12 19:53:46 --> Helper loaded: url_helper
INFO - 2018-10-12 19:53:46 --> Helper loaded: form_helper
INFO - 2018-10-12 19:53:46 --> Helper loaded: language_helper
DEBUG - 2018-10-12 19:53:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 19:53:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 19:53:46 --> User Agent Class Initialized
INFO - 2018-10-12 19:53:46 --> Controller Class Initialized
INFO - 2018-10-12 19:53:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 19:53:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 19:53:46 --> Pixel_Model class loaded
INFO - 2018-10-12 19:53:46 --> Database Driver Class Initialized
INFO - 2018-10-12 19:53:46 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 19:53:46 --> Form Validation Class Initialized
INFO - 2018-10-12 19:53:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-12 19:53:46 --> Database Driver Class Initialized
INFO - 2018-10-12 19:53:46 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 19:53:46 --> Config Class Initialized
INFO - 2018-10-12 19:53:46 --> Hooks Class Initialized
DEBUG - 2018-10-12 19:53:46 --> UTF-8 Support Enabled
INFO - 2018-10-12 19:53:46 --> Utf8 Class Initialized
INFO - 2018-10-12 19:53:46 --> URI Class Initialized
INFO - 2018-10-12 19:53:46 --> Router Class Initialized
INFO - 2018-10-12 19:53:46 --> Output Class Initialized
INFO - 2018-10-12 19:53:46 --> Security Class Initialized
DEBUG - 2018-10-12 19:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 19:53:46 --> CSRF cookie sent
INFO - 2018-10-12 19:53:46 --> Input Class Initialized
INFO - 2018-10-12 19:53:46 --> Language Class Initialized
INFO - 2018-10-12 19:53:46 --> Loader Class Initialized
INFO - 2018-10-12 19:53:46 --> Helper loaded: url_helper
INFO - 2018-10-12 19:53:46 --> Helper loaded: form_helper
INFO - 2018-10-12 19:53:46 --> Helper loaded: language_helper
DEBUG - 2018-10-12 19:53:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 19:53:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 19:53:46 --> User Agent Class Initialized
INFO - 2018-10-12 19:53:46 --> Controller Class Initialized
INFO - 2018-10-12 19:53:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 19:53:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 19:53:46 --> Pixel_Model class loaded
INFO - 2018-10-12 19:53:46 --> Database Driver Class Initialized
INFO - 2018-10-12 19:53:46 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 19:53:46 --> Database Driver Class Initialized
INFO - 2018-10-12 19:53:46 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 19:53:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 19:53:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 19:53:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-10-12 19:53:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 19:53:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 19:53:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 19:53:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 19:53:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-10-12 19:53:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 19:53:46 --> Final output sent to browser
DEBUG - 2018-10-12 19:53:46 --> Total execution time: 0.0324
INFO - 2018-10-12 20:59:52 --> Config Class Initialized
INFO - 2018-10-12 20:59:52 --> Hooks Class Initialized
DEBUG - 2018-10-12 20:59:52 --> UTF-8 Support Enabled
INFO - 2018-10-12 20:59:52 --> Utf8 Class Initialized
INFO - 2018-10-12 20:59:52 --> URI Class Initialized
DEBUG - 2018-10-12 20:59:52 --> No URI present. Default controller set.
INFO - 2018-10-12 20:59:52 --> Router Class Initialized
INFO - 2018-10-12 20:59:52 --> Output Class Initialized
INFO - 2018-10-12 20:59:52 --> Security Class Initialized
DEBUG - 2018-10-12 20:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 20:59:52 --> CSRF cookie sent
INFO - 2018-10-12 20:59:52 --> Input Class Initialized
INFO - 2018-10-12 20:59:52 --> Language Class Initialized
INFO - 2018-10-12 20:59:52 --> Loader Class Initialized
INFO - 2018-10-12 20:59:52 --> Helper loaded: url_helper
INFO - 2018-10-12 20:59:52 --> Helper loaded: form_helper
INFO - 2018-10-12 20:59:52 --> Helper loaded: language_helper
DEBUG - 2018-10-12 20:59:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 20:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 20:59:52 --> User Agent Class Initialized
INFO - 2018-10-12 20:59:52 --> Controller Class Initialized
INFO - 2018-10-12 20:59:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 20:59:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 20:59:52 --> Pixel_Model class loaded
INFO - 2018-10-12 20:59:52 --> Database Driver Class Initialized
INFO - 2018-10-12 20:59:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 20:59:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 20:59:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 20:59:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-12 20:59:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 20:59:52 --> Final output sent to browser
DEBUG - 2018-10-12 20:59:52 --> Total execution time: 0.0357
INFO - 2018-10-12 21:00:24 --> Config Class Initialized
INFO - 2018-10-12 21:00:24 --> Hooks Class Initialized
DEBUG - 2018-10-12 21:00:24 --> UTF-8 Support Enabled
INFO - 2018-10-12 21:00:24 --> Utf8 Class Initialized
INFO - 2018-10-12 21:00:24 --> URI Class Initialized
INFO - 2018-10-12 21:00:24 --> Router Class Initialized
INFO - 2018-10-12 21:00:24 --> Output Class Initialized
INFO - 2018-10-12 21:00:24 --> Security Class Initialized
DEBUG - 2018-10-12 21:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 21:00:24 --> CSRF cookie sent
INFO - 2018-10-12 21:00:24 --> Input Class Initialized
INFO - 2018-10-12 21:00:24 --> Language Class Initialized
INFO - 2018-10-12 21:00:24 --> Loader Class Initialized
INFO - 2018-10-12 21:00:24 --> Helper loaded: url_helper
INFO - 2018-10-12 21:00:24 --> Helper loaded: form_helper
INFO - 2018-10-12 21:00:24 --> Helper loaded: language_helper
DEBUG - 2018-10-12 21:00:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 21:00:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 21:00:24 --> User Agent Class Initialized
INFO - 2018-10-12 21:00:24 --> Controller Class Initialized
INFO - 2018-10-12 21:00:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 21:00:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 21:00:24 --> Pixel_Model class loaded
INFO - 2018-10-12 21:00:24 --> Database Driver Class Initialized
INFO - 2018-10-12 21:00:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 21:00:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 21:00:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 21:00:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 21:00:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 21:00:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 21:00:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 21:00:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-10-12 21:00:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 21:00:24 --> Final output sent to browser
DEBUG - 2018-10-12 21:00:24 --> Total execution time: 0.0377
INFO - 2018-10-12 21:00:31 --> Config Class Initialized
INFO - 2018-10-12 21:00:31 --> Hooks Class Initialized
DEBUG - 2018-10-12 21:00:31 --> UTF-8 Support Enabled
INFO - 2018-10-12 21:00:31 --> Utf8 Class Initialized
INFO - 2018-10-12 21:00:31 --> URI Class Initialized
INFO - 2018-10-12 21:00:31 --> Router Class Initialized
INFO - 2018-10-12 21:00:31 --> Output Class Initialized
INFO - 2018-10-12 21:00:31 --> Security Class Initialized
DEBUG - 2018-10-12 21:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 21:00:31 --> CSRF cookie sent
INFO - 2018-10-12 21:00:31 --> CSRF token verified
INFO - 2018-10-12 21:00:31 --> Input Class Initialized
INFO - 2018-10-12 21:00:31 --> Language Class Initialized
INFO - 2018-10-12 21:00:31 --> Loader Class Initialized
INFO - 2018-10-12 21:00:31 --> Helper loaded: url_helper
INFO - 2018-10-12 21:00:31 --> Helper loaded: form_helper
INFO - 2018-10-12 21:00:31 --> Helper loaded: language_helper
DEBUG - 2018-10-12 21:00:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 21:00:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 21:00:31 --> User Agent Class Initialized
INFO - 2018-10-12 21:00:31 --> Controller Class Initialized
INFO - 2018-10-12 21:00:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 21:00:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 21:00:31 --> Pixel_Model class loaded
INFO - 2018-10-12 21:00:31 --> Database Driver Class Initialized
INFO - 2018-10-12 21:00:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 21:00:31 --> Form Validation Class Initialized
INFO - 2018-10-12 21:00:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-12 21:00:31 --> Database Driver Class Initialized
INFO - 2018-10-12 21:00:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 21:00:31 --> Config Class Initialized
INFO - 2018-10-12 21:00:31 --> Hooks Class Initialized
DEBUG - 2018-10-12 21:00:31 --> UTF-8 Support Enabled
INFO - 2018-10-12 21:00:31 --> Utf8 Class Initialized
INFO - 2018-10-12 21:00:31 --> URI Class Initialized
INFO - 2018-10-12 21:00:31 --> Router Class Initialized
INFO - 2018-10-12 21:00:31 --> Output Class Initialized
INFO - 2018-10-12 21:00:31 --> Security Class Initialized
DEBUG - 2018-10-12 21:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 21:00:31 --> CSRF cookie sent
INFO - 2018-10-12 21:00:31 --> Input Class Initialized
INFO - 2018-10-12 21:00:31 --> Language Class Initialized
INFO - 2018-10-12 21:00:31 --> Loader Class Initialized
INFO - 2018-10-12 21:00:31 --> Helper loaded: url_helper
INFO - 2018-10-12 21:00:31 --> Helper loaded: form_helper
INFO - 2018-10-12 21:00:31 --> Helper loaded: language_helper
DEBUG - 2018-10-12 21:00:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 21:00:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 21:00:31 --> User Agent Class Initialized
INFO - 2018-10-12 21:00:31 --> Controller Class Initialized
INFO - 2018-10-12 21:00:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 21:00:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 21:00:31 --> Pixel_Model class loaded
INFO - 2018-10-12 21:00:31 --> Database Driver Class Initialized
INFO - 2018-10-12 21:00:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 21:00:31 --> Database Driver Class Initialized
INFO - 2018-10-12 21:00:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 21:00:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 21:00:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 21:00:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 21:00:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 21:00:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 21:00:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 21:00:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-12 21:00:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 21:00:31 --> Final output sent to browser
DEBUG - 2018-10-12 21:00:31 --> Total execution time: 0.0527
INFO - 2018-10-12 21:00:43 --> Config Class Initialized
INFO - 2018-10-12 21:00:43 --> Hooks Class Initialized
DEBUG - 2018-10-12 21:00:43 --> UTF-8 Support Enabled
INFO - 2018-10-12 21:00:43 --> Utf8 Class Initialized
INFO - 2018-10-12 21:00:43 --> URI Class Initialized
INFO - 2018-10-12 21:00:43 --> Router Class Initialized
INFO - 2018-10-12 21:00:43 --> Output Class Initialized
INFO - 2018-10-12 21:00:43 --> Security Class Initialized
DEBUG - 2018-10-12 21:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 21:00:43 --> CSRF cookie sent
INFO - 2018-10-12 21:00:43 --> CSRF token verified
INFO - 2018-10-12 21:00:43 --> Input Class Initialized
INFO - 2018-10-12 21:00:43 --> Language Class Initialized
INFO - 2018-10-12 21:00:43 --> Loader Class Initialized
INFO - 2018-10-12 21:00:43 --> Helper loaded: url_helper
INFO - 2018-10-12 21:00:43 --> Helper loaded: form_helper
INFO - 2018-10-12 21:00:43 --> Helper loaded: language_helper
DEBUG - 2018-10-12 21:00:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 21:00:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 21:00:43 --> User Agent Class Initialized
INFO - 2018-10-12 21:00:43 --> Controller Class Initialized
INFO - 2018-10-12 21:00:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 21:00:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 21:00:43 --> Pixel_Model class loaded
INFO - 2018-10-12 21:00:43 --> Database Driver Class Initialized
INFO - 2018-10-12 21:00:43 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 21:00:43 --> Form Validation Class Initialized
INFO - 2018-10-12 21:00:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-12 21:00:43 --> Database Driver Class Initialized
INFO - 2018-10-12 21:00:43 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 21:00:44 --> Config Class Initialized
INFO - 2018-10-12 21:00:44 --> Hooks Class Initialized
DEBUG - 2018-10-12 21:00:44 --> UTF-8 Support Enabled
INFO - 2018-10-12 21:00:44 --> Utf8 Class Initialized
INFO - 2018-10-12 21:00:44 --> URI Class Initialized
INFO - 2018-10-12 21:00:44 --> Router Class Initialized
INFO - 2018-10-12 21:00:44 --> Output Class Initialized
INFO - 2018-10-12 21:00:44 --> Security Class Initialized
DEBUG - 2018-10-12 21:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 21:00:44 --> CSRF cookie sent
INFO - 2018-10-12 21:00:44 --> Input Class Initialized
INFO - 2018-10-12 21:00:44 --> Language Class Initialized
INFO - 2018-10-12 21:00:44 --> Loader Class Initialized
INFO - 2018-10-12 21:00:44 --> Helper loaded: url_helper
INFO - 2018-10-12 21:00:44 --> Helper loaded: form_helper
INFO - 2018-10-12 21:00:44 --> Helper loaded: language_helper
DEBUG - 2018-10-12 21:00:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 21:00:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 21:00:44 --> User Agent Class Initialized
INFO - 2018-10-12 21:00:44 --> Controller Class Initialized
INFO - 2018-10-12 21:00:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 21:00:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 21:00:44 --> Pixel_Model class loaded
INFO - 2018-10-12 21:00:44 --> Database Driver Class Initialized
INFO - 2018-10-12 21:00:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 21:00:44 --> Database Driver Class Initialized
INFO - 2018-10-12 21:00:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 21:00:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 21:00:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 21:00:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 21:00:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 21:00:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 21:00:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 21:00:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-10-12 21:00:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 21:00:44 --> Final output sent to browser
DEBUG - 2018-10-12 21:00:44 --> Total execution time: 0.0431
INFO - 2018-10-12 21:00:46 --> Config Class Initialized
INFO - 2018-10-12 21:00:46 --> Hooks Class Initialized
DEBUG - 2018-10-12 21:00:46 --> UTF-8 Support Enabled
INFO - 2018-10-12 21:00:46 --> Utf8 Class Initialized
INFO - 2018-10-12 21:00:46 --> URI Class Initialized
INFO - 2018-10-12 21:00:46 --> Router Class Initialized
INFO - 2018-10-12 21:00:46 --> Output Class Initialized
INFO - 2018-10-12 21:00:46 --> Security Class Initialized
DEBUG - 2018-10-12 21:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 21:00:46 --> CSRF cookie sent
INFO - 2018-10-12 21:00:46 --> CSRF token verified
INFO - 2018-10-12 21:00:46 --> Input Class Initialized
INFO - 2018-10-12 21:00:46 --> Language Class Initialized
INFO - 2018-10-12 21:00:46 --> Loader Class Initialized
INFO - 2018-10-12 21:00:46 --> Helper loaded: url_helper
INFO - 2018-10-12 21:00:46 --> Helper loaded: form_helper
INFO - 2018-10-12 21:00:46 --> Helper loaded: language_helper
DEBUG - 2018-10-12 21:00:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 21:00:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 21:00:46 --> User Agent Class Initialized
INFO - 2018-10-12 21:00:46 --> Controller Class Initialized
INFO - 2018-10-12 21:00:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 21:00:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 21:00:46 --> Pixel_Model class loaded
INFO - 2018-10-12 21:00:46 --> Database Driver Class Initialized
INFO - 2018-10-12 21:00:46 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 21:00:46 --> Form Validation Class Initialized
INFO - 2018-10-12 21:00:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-12 21:00:46 --> Database Driver Class Initialized
INFO - 2018-10-12 21:00:46 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 21:00:46 --> Config Class Initialized
INFO - 2018-10-12 21:00:46 --> Hooks Class Initialized
DEBUG - 2018-10-12 21:00:46 --> UTF-8 Support Enabled
INFO - 2018-10-12 21:00:46 --> Utf8 Class Initialized
INFO - 2018-10-12 21:00:46 --> URI Class Initialized
INFO - 2018-10-12 21:00:46 --> Router Class Initialized
INFO - 2018-10-12 21:00:46 --> Output Class Initialized
INFO - 2018-10-12 21:00:46 --> Security Class Initialized
DEBUG - 2018-10-12 21:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-12 21:00:46 --> CSRF cookie sent
INFO - 2018-10-12 21:00:46 --> Input Class Initialized
INFO - 2018-10-12 21:00:46 --> Language Class Initialized
INFO - 2018-10-12 21:00:46 --> Loader Class Initialized
INFO - 2018-10-12 21:00:46 --> Helper loaded: url_helper
INFO - 2018-10-12 21:00:46 --> Helper loaded: form_helper
INFO - 2018-10-12 21:00:46 --> Helper loaded: language_helper
DEBUG - 2018-10-12 21:00:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-12 21:00:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-12 21:00:46 --> User Agent Class Initialized
INFO - 2018-10-12 21:00:46 --> Controller Class Initialized
INFO - 2018-10-12 21:00:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-12 21:00:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-12 21:00:46 --> Pixel_Model class loaded
INFO - 2018-10-12 21:00:47 --> Database Driver Class Initialized
INFO - 2018-10-12 21:00:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 21:00:47 --> Database Driver Class Initialized
INFO - 2018-10-12 21:00:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-12 21:00:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-12 21:00:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-12 21:00:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-10-12 21:00:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-12 21:00:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-12 21:00:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-12 21:00:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-12 21:00:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-10-12 21:00:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-12 21:00:47 --> Final output sent to browser
DEBUG - 2018-10-12 21:00:47 --> Total execution time: 0.0391

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-10-14 15:00:24 --> Config Class Initialized
INFO - 2018-10-14 15:00:24 --> Hooks Class Initialized
DEBUG - 2018-10-14 15:00:24 --> UTF-8 Support Enabled
INFO - 2018-10-14 15:00:24 --> Utf8 Class Initialized
INFO - 2018-10-14 15:00:24 --> URI Class Initialized
DEBUG - 2018-10-14 15:00:24 --> No URI present. Default controller set.
INFO - 2018-10-14 15:00:24 --> Router Class Initialized
INFO - 2018-10-14 15:00:24 --> Output Class Initialized
INFO - 2018-10-14 15:00:24 --> Security Class Initialized
DEBUG - 2018-10-14 15:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-14 15:00:24 --> CSRF cookie sent
INFO - 2018-10-14 15:00:24 --> Input Class Initialized
INFO - 2018-10-14 15:00:24 --> Language Class Initialized
INFO - 2018-10-14 15:00:24 --> Loader Class Initialized
INFO - 2018-10-14 15:00:24 --> Helper loaded: url_helper
INFO - 2018-10-14 15:00:24 --> Helper loaded: form_helper
INFO - 2018-10-14 15:00:24 --> Helper loaded: language_helper
DEBUG - 2018-10-14 15:00:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-14 15:00:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-14 15:00:24 --> User Agent Class Initialized
INFO - 2018-10-14 15:00:24 --> Controller Class Initialized
INFO - 2018-10-14 15:00:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-14 15:00:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-14 15:00:24 --> Pixel_Model class loaded
INFO - 2018-10-14 15:00:24 --> Database Driver Class Initialized
INFO - 2018-10-14 15:00:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:00:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-14 15:00:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-14 15:00:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-14 15:00:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-14 15:00:24 --> Final output sent to browser
DEBUG - 2018-10-14 15:00:24 --> Total execution time: 0.0630
INFO - 2018-10-14 15:00:36 --> Config Class Initialized
INFO - 2018-10-14 15:00:36 --> Hooks Class Initialized
DEBUG - 2018-10-14 15:00:36 --> UTF-8 Support Enabled
INFO - 2018-10-14 15:00:36 --> Utf8 Class Initialized
INFO - 2018-10-14 15:00:36 --> URI Class Initialized
INFO - 2018-10-14 15:00:36 --> Router Class Initialized
INFO - 2018-10-14 15:00:36 --> Output Class Initialized
INFO - 2018-10-14 15:00:36 --> Security Class Initialized
DEBUG - 2018-10-14 15:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-14 15:00:36 --> CSRF cookie sent
INFO - 2018-10-14 15:00:36 --> CSRF token verified
INFO - 2018-10-14 15:00:36 --> Input Class Initialized
INFO - 2018-10-14 15:00:36 --> Language Class Initialized
INFO - 2018-10-14 15:00:36 --> Loader Class Initialized
INFO - 2018-10-14 15:00:36 --> Helper loaded: url_helper
INFO - 2018-10-14 15:00:36 --> Helper loaded: form_helper
INFO - 2018-10-14 15:00:36 --> Helper loaded: language_helper
DEBUG - 2018-10-14 15:00:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-14 15:00:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-14 15:00:36 --> User Agent Class Initialized
INFO - 2018-10-14 15:00:36 --> Controller Class Initialized
INFO - 2018-10-14 15:00:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-14 15:00:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-14 15:00:36 --> Pixel_Model class loaded
INFO - 2018-10-14 15:00:36 --> Database Driver Class Initialized
INFO - 2018-10-14 15:00:36 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:00:36 --> Form Validation Class Initialized
INFO - 2018-10-14 15:00:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-14 15:00:36 --> Database Driver Class Initialized
INFO - 2018-10-14 15:00:36 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:00:36 --> Config Class Initialized
INFO - 2018-10-14 15:00:36 --> Hooks Class Initialized
DEBUG - 2018-10-14 15:00:36 --> UTF-8 Support Enabled
INFO - 2018-10-14 15:00:36 --> Utf8 Class Initialized
INFO - 2018-10-14 15:00:36 --> URI Class Initialized
INFO - 2018-10-14 15:00:36 --> Router Class Initialized
INFO - 2018-10-14 15:00:36 --> Output Class Initialized
INFO - 2018-10-14 15:00:36 --> Security Class Initialized
DEBUG - 2018-10-14 15:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-14 15:00:36 --> CSRF cookie sent
INFO - 2018-10-14 15:00:36 --> Input Class Initialized
INFO - 2018-10-14 15:00:36 --> Language Class Initialized
INFO - 2018-10-14 15:00:36 --> Loader Class Initialized
INFO - 2018-10-14 15:00:36 --> Helper loaded: url_helper
INFO - 2018-10-14 15:00:36 --> Helper loaded: form_helper
INFO - 2018-10-14 15:00:36 --> Helper loaded: language_helper
DEBUG - 2018-10-14 15:00:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-14 15:00:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-14 15:00:36 --> User Agent Class Initialized
INFO - 2018-10-14 15:00:36 --> Controller Class Initialized
INFO - 2018-10-14 15:00:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-14 15:00:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-14 15:00:36 --> Pixel_Model class loaded
INFO - 2018-10-14 15:00:36 --> Database Driver Class Initialized
INFO - 2018-10-14 15:00:36 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:00:36 --> Database Driver Class Initialized
INFO - 2018-10-14 15:00:36 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:00:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-14 15:00:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-14 15:00:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-14 15:00:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-14 15:00:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-14 15:00:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-14 15:00:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-14 15:00:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-14 15:00:36 --> Final output sent to browser
DEBUG - 2018-10-14 15:00:36 --> Total execution time: 0.0531
INFO - 2018-10-14 15:01:07 --> Config Class Initialized
INFO - 2018-10-14 15:01:07 --> Hooks Class Initialized
DEBUG - 2018-10-14 15:01:07 --> UTF-8 Support Enabled
INFO - 2018-10-14 15:01:07 --> Utf8 Class Initialized
INFO - 2018-10-14 15:01:07 --> URI Class Initialized
INFO - 2018-10-14 15:01:07 --> Router Class Initialized
INFO - 2018-10-14 15:01:07 --> Output Class Initialized
INFO - 2018-10-14 15:01:07 --> Security Class Initialized
DEBUG - 2018-10-14 15:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-14 15:01:07 --> CSRF cookie sent
INFO - 2018-10-14 15:01:07 --> Input Class Initialized
INFO - 2018-10-14 15:01:07 --> Language Class Initialized
INFO - 2018-10-14 15:01:07 --> Loader Class Initialized
INFO - 2018-10-14 15:01:07 --> Helper loaded: url_helper
INFO - 2018-10-14 15:01:07 --> Helper loaded: form_helper
INFO - 2018-10-14 15:01:07 --> Helper loaded: language_helper
DEBUG - 2018-10-14 15:01:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-14 15:01:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-14 15:01:07 --> User Agent Class Initialized
INFO - 2018-10-14 15:01:07 --> Controller Class Initialized
INFO - 2018-10-14 15:01:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-14 15:01:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-14 15:01:07 --> Pixel_Model class loaded
INFO - 2018-10-14 15:01:07 --> Database Driver Class Initialized
INFO - 2018-10-14 15:01:07 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:01:07 --> Database Driver Class Initialized
INFO - 2018-10-14 15:01:07 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:01:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-14 15:01:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-14 15:01:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-14 15:01:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-14 15:01:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/save_exit.php
INFO - 2018-10-14 15:01:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-14 15:01:07 --> Final output sent to browser
DEBUG - 2018-10-14 15:01:07 --> Total execution time: 0.0486
INFO - 2018-10-14 15:01:09 --> Config Class Initialized
INFO - 2018-10-14 15:01:09 --> Hooks Class Initialized
DEBUG - 2018-10-14 15:01:09 --> UTF-8 Support Enabled
INFO - 2018-10-14 15:01:09 --> Utf8 Class Initialized
INFO - 2018-10-14 15:01:09 --> URI Class Initialized
INFO - 2018-10-14 15:01:09 --> Router Class Initialized
INFO - 2018-10-14 15:01:09 --> Output Class Initialized
INFO - 2018-10-14 15:01:09 --> Security Class Initialized
DEBUG - 2018-10-14 15:01:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-14 15:01:09 --> CSRF cookie sent
INFO - 2018-10-14 15:01:09 --> Input Class Initialized
INFO - 2018-10-14 15:01:09 --> Language Class Initialized
INFO - 2018-10-14 15:01:09 --> Loader Class Initialized
INFO - 2018-10-14 15:01:09 --> Helper loaded: url_helper
INFO - 2018-10-14 15:01:09 --> Helper loaded: form_helper
INFO - 2018-10-14 15:01:09 --> Helper loaded: language_helper
DEBUG - 2018-10-14 15:01:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-14 15:01:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-14 15:01:09 --> User Agent Class Initialized
INFO - 2018-10-14 15:01:09 --> Controller Class Initialized
INFO - 2018-10-14 15:01:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-14 15:01:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-14 15:01:09 --> Pixel_Model class loaded
INFO - 2018-10-14 15:01:09 --> Database Driver Class Initialized
INFO - 2018-10-14 15:01:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:01:09 --> Database Driver Class Initialized
INFO - 2018-10-14 15:01:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:01:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-14 15:01:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-14 15:01:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-14 15:01:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-14 15:01:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-14 15:01:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-14 15:01:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-14 15:01:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-14 15:01:09 --> Final output sent to browser
DEBUG - 2018-10-14 15:01:09 --> Total execution time: 0.0629
INFO - 2018-10-14 15:01:11 --> Config Class Initialized
INFO - 2018-10-14 15:01:11 --> Hooks Class Initialized
DEBUG - 2018-10-14 15:01:11 --> UTF-8 Support Enabled
INFO - 2018-10-14 15:01:11 --> Utf8 Class Initialized
INFO - 2018-10-14 15:01:11 --> URI Class Initialized
INFO - 2018-10-14 15:01:11 --> Router Class Initialized
INFO - 2018-10-14 15:01:11 --> Output Class Initialized
INFO - 2018-10-14 15:01:11 --> Security Class Initialized
DEBUG - 2018-10-14 15:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-14 15:01:11 --> CSRF cookie sent
INFO - 2018-10-14 15:01:11 --> Input Class Initialized
INFO - 2018-10-14 15:01:11 --> Language Class Initialized
INFO - 2018-10-14 15:01:11 --> Loader Class Initialized
INFO - 2018-10-14 15:01:11 --> Helper loaded: url_helper
INFO - 2018-10-14 15:01:11 --> Helper loaded: form_helper
INFO - 2018-10-14 15:01:11 --> Helper loaded: language_helper
DEBUG - 2018-10-14 15:01:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-14 15:01:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-14 15:01:11 --> User Agent Class Initialized
INFO - 2018-10-14 15:01:11 --> Controller Class Initialized
INFO - 2018-10-14 15:01:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-14 15:01:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-14 15:01:11 --> Pixel_Model class loaded
INFO - 2018-10-14 15:01:11 --> Database Driver Class Initialized
INFO - 2018-10-14 15:01:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:01:11 --> Database Driver Class Initialized
INFO - 2018-10-14 15:01:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:01:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-14 15:01:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-14 15:01:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-14 15:01:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-14 15:01:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/save_exit.php
INFO - 2018-10-14 15:01:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-14 15:01:11 --> Final output sent to browser
DEBUG - 2018-10-14 15:01:11 --> Total execution time: 0.0455
INFO - 2018-10-14 15:01:12 --> Config Class Initialized
INFO - 2018-10-14 15:01:12 --> Hooks Class Initialized
DEBUG - 2018-10-14 15:01:12 --> UTF-8 Support Enabled
INFO - 2018-10-14 15:01:12 --> Utf8 Class Initialized
INFO - 2018-10-14 15:01:12 --> URI Class Initialized
INFO - 2018-10-14 15:01:12 --> Router Class Initialized
INFO - 2018-10-14 15:01:12 --> Output Class Initialized
INFO - 2018-10-14 15:01:12 --> Security Class Initialized
DEBUG - 2018-10-14 15:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-14 15:01:12 --> CSRF cookie sent
INFO - 2018-10-14 15:01:12 --> Input Class Initialized
INFO - 2018-10-14 15:01:12 --> Language Class Initialized
INFO - 2018-10-14 15:01:12 --> Loader Class Initialized
INFO - 2018-10-14 15:01:12 --> Helper loaded: url_helper
INFO - 2018-10-14 15:01:12 --> Helper loaded: form_helper
INFO - 2018-10-14 15:01:12 --> Helper loaded: language_helper
DEBUG - 2018-10-14 15:01:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-14 15:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-14 15:01:12 --> User Agent Class Initialized
INFO - 2018-10-14 15:01:12 --> Controller Class Initialized
INFO - 2018-10-14 15:01:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-14 15:01:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-14 15:01:12 --> Pixel_Model class loaded
INFO - 2018-10-14 15:01:12 --> Database Driver Class Initialized
INFO - 2018-10-14 15:01:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:01:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-14 15:01:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-14 15:01:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-14 15:01:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-14 15:01:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/contact_us.php
INFO - 2018-10-14 15:01:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-14 15:01:12 --> Final output sent to browser
DEBUG - 2018-10-14 15:01:12 --> Total execution time: 0.0492
INFO - 2018-10-14 15:01:14 --> Config Class Initialized
INFO - 2018-10-14 15:01:14 --> Hooks Class Initialized
DEBUG - 2018-10-14 15:01:14 --> UTF-8 Support Enabled
INFO - 2018-10-14 15:01:14 --> Utf8 Class Initialized
INFO - 2018-10-14 15:01:14 --> URI Class Initialized
INFO - 2018-10-14 15:01:14 --> Router Class Initialized
INFO - 2018-10-14 15:01:14 --> Output Class Initialized
INFO - 2018-10-14 15:01:14 --> Security Class Initialized
DEBUG - 2018-10-14 15:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-14 15:01:14 --> CSRF cookie sent
INFO - 2018-10-14 15:01:14 --> Input Class Initialized
INFO - 2018-10-14 15:01:14 --> Language Class Initialized
INFO - 2018-10-14 15:01:14 --> Loader Class Initialized
INFO - 2018-10-14 15:01:14 --> Helper loaded: url_helper
INFO - 2018-10-14 15:01:14 --> Helper loaded: form_helper
INFO - 2018-10-14 15:01:14 --> Helper loaded: language_helper
DEBUG - 2018-10-14 15:01:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-14 15:01:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-14 15:01:14 --> User Agent Class Initialized
INFO - 2018-10-14 15:01:14 --> Controller Class Initialized
INFO - 2018-10-14 15:01:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-14 15:01:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-14 15:01:14 --> Pixel_Model class loaded
INFO - 2018-10-14 15:01:14 --> Database Driver Class Initialized
INFO - 2018-10-14 15:01:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:01:14 --> Database Driver Class Initialized
INFO - 2018-10-14 15:01:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:01:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-14 15:01:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-14 15:01:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-14 15:01:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-14 15:01:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/save_exit.php
INFO - 2018-10-14 15:01:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-14 15:01:14 --> Final output sent to browser
DEBUG - 2018-10-14 15:01:14 --> Total execution time: 0.0584
INFO - 2018-10-14 15:01:17 --> Config Class Initialized
INFO - 2018-10-14 15:01:17 --> Hooks Class Initialized
DEBUG - 2018-10-14 15:01:17 --> UTF-8 Support Enabled
INFO - 2018-10-14 15:01:17 --> Utf8 Class Initialized
INFO - 2018-10-14 15:01:17 --> URI Class Initialized
INFO - 2018-10-14 15:01:17 --> Router Class Initialized
INFO - 2018-10-14 15:01:17 --> Output Class Initialized
INFO - 2018-10-14 15:01:17 --> Security Class Initialized
DEBUG - 2018-10-14 15:01:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-14 15:01:17 --> CSRF cookie sent
INFO - 2018-10-14 15:01:17 --> Input Class Initialized
INFO - 2018-10-14 15:01:17 --> Language Class Initialized
INFO - 2018-10-14 15:01:17 --> Loader Class Initialized
INFO - 2018-10-14 15:01:17 --> Helper loaded: url_helper
INFO - 2018-10-14 15:01:17 --> Helper loaded: form_helper
INFO - 2018-10-14 15:01:17 --> Helper loaded: language_helper
DEBUG - 2018-10-14 15:01:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-14 15:01:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-14 15:01:17 --> User Agent Class Initialized
INFO - 2018-10-14 15:01:17 --> Controller Class Initialized
INFO - 2018-10-14 15:01:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-14 15:01:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-14 15:01:17 --> Pixel_Model class loaded
INFO - 2018-10-14 15:01:17 --> Database Driver Class Initialized
INFO - 2018-10-14 15:01:17 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:01:17 --> Database Driver Class Initialized
INFO - 2018-10-14 15:01:17 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:01:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-14 15:01:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-14 15:01:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-14 15:01:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-14 15:01:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-14 15:01:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-14 15:01:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-14 15:01:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-14 15:01:17 --> Final output sent to browser
DEBUG - 2018-10-14 15:01:17 --> Total execution time: 0.0704
INFO - 2018-10-14 15:01:20 --> Config Class Initialized
INFO - 2018-10-14 15:01:20 --> Hooks Class Initialized
DEBUG - 2018-10-14 15:01:20 --> UTF-8 Support Enabled
INFO - 2018-10-14 15:01:20 --> Utf8 Class Initialized
INFO - 2018-10-14 15:01:20 --> URI Class Initialized
INFO - 2018-10-14 15:01:20 --> Router Class Initialized
INFO - 2018-10-14 15:01:20 --> Output Class Initialized
INFO - 2018-10-14 15:01:20 --> Security Class Initialized
DEBUG - 2018-10-14 15:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-14 15:01:20 --> CSRF cookie sent
INFO - 2018-10-14 15:01:20 --> Input Class Initialized
INFO - 2018-10-14 15:01:20 --> Language Class Initialized
INFO - 2018-10-14 15:01:20 --> Loader Class Initialized
INFO - 2018-10-14 15:01:20 --> Helper loaded: url_helper
INFO - 2018-10-14 15:01:20 --> Helper loaded: form_helper
INFO - 2018-10-14 15:01:20 --> Helper loaded: language_helper
DEBUG - 2018-10-14 15:01:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-14 15:01:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-14 15:01:20 --> User Agent Class Initialized
INFO - 2018-10-14 15:01:20 --> Controller Class Initialized
INFO - 2018-10-14 15:01:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-14 15:01:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-14 15:01:20 --> Pixel_Model class loaded
INFO - 2018-10-14 15:01:20 --> Database Driver Class Initialized
INFO - 2018-10-14 15:01:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:01:20 --> Database Driver Class Initialized
INFO - 2018-10-14 15:01:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:01:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-14 15:01:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-14 15:01:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-14 15:01:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-14 15:01:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/save_exit.php
INFO - 2018-10-14 15:01:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-14 15:01:20 --> Final output sent to browser
DEBUG - 2018-10-14 15:01:20 --> Total execution time: 0.0473
INFO - 2018-10-14 15:01:23 --> Config Class Initialized
INFO - 2018-10-14 15:01:23 --> Hooks Class Initialized
DEBUG - 2018-10-14 15:01:23 --> UTF-8 Support Enabled
INFO - 2018-10-14 15:01:23 --> Utf8 Class Initialized
INFO - 2018-10-14 15:01:23 --> URI Class Initialized
INFO - 2018-10-14 15:01:23 --> Router Class Initialized
INFO - 2018-10-14 15:01:23 --> Output Class Initialized
INFO - 2018-10-14 15:01:23 --> Security Class Initialized
DEBUG - 2018-10-14 15:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-14 15:01:23 --> CSRF cookie sent
INFO - 2018-10-14 15:01:23 --> Input Class Initialized
INFO - 2018-10-14 15:01:23 --> Language Class Initialized
INFO - 2018-10-14 15:01:23 --> Loader Class Initialized
INFO - 2018-10-14 15:01:23 --> Helper loaded: url_helper
INFO - 2018-10-14 15:01:23 --> Helper loaded: form_helper
INFO - 2018-10-14 15:01:23 --> Helper loaded: language_helper
DEBUG - 2018-10-14 15:01:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-14 15:01:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-14 15:01:23 --> User Agent Class Initialized
INFO - 2018-10-14 15:01:23 --> Controller Class Initialized
INFO - 2018-10-14 15:01:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-14 15:01:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-14 15:01:23 --> Pixel_Model class loaded
INFO - 2018-10-14 15:01:23 --> Database Driver Class Initialized
INFO - 2018-10-14 15:01:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:01:23 --> Database Driver Class Initialized
INFO - 2018-10-14 15:01:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:01:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-14 15:01:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-14 15:01:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-14 15:01:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-14 15:01:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-14 15:01:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-14 15:01:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-14 15:01:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-14 15:01:23 --> Final output sent to browser
DEBUG - 2018-10-14 15:01:23 --> Total execution time: 0.0506
INFO - 2018-10-14 15:01:24 --> Config Class Initialized
INFO - 2018-10-14 15:01:24 --> Hooks Class Initialized
DEBUG - 2018-10-14 15:01:24 --> UTF-8 Support Enabled
INFO - 2018-10-14 15:01:24 --> Utf8 Class Initialized
INFO - 2018-10-14 15:01:24 --> URI Class Initialized
INFO - 2018-10-14 15:01:24 --> Router Class Initialized
INFO - 2018-10-14 15:01:24 --> Output Class Initialized
INFO - 2018-10-14 15:01:24 --> Security Class Initialized
DEBUG - 2018-10-14 15:01:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-14 15:01:24 --> CSRF cookie sent
INFO - 2018-10-14 15:01:24 --> Input Class Initialized
INFO - 2018-10-14 15:01:24 --> Language Class Initialized
INFO - 2018-10-14 15:01:24 --> Loader Class Initialized
INFO - 2018-10-14 15:01:24 --> Helper loaded: url_helper
INFO - 2018-10-14 15:01:24 --> Helper loaded: form_helper
INFO - 2018-10-14 15:01:24 --> Helper loaded: language_helper
DEBUG - 2018-10-14 15:01:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-14 15:01:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-14 15:01:24 --> User Agent Class Initialized
INFO - 2018-10-14 15:01:24 --> Controller Class Initialized
INFO - 2018-10-14 15:01:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-14 15:01:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-14 15:01:24 --> Pixel_Model class loaded
INFO - 2018-10-14 15:01:24 --> Database Driver Class Initialized
INFO - 2018-10-14 15:01:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:01:24 --> Database Driver Class Initialized
INFO - 2018-10-14 15:01:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:01:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-14 15:01:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-14 15:01:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-14 15:01:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-14 15:01:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/save_exit.php
INFO - 2018-10-14 15:01:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-14 15:01:24 --> Final output sent to browser
DEBUG - 2018-10-14 15:01:24 --> Total execution time: 0.0576
INFO - 2018-10-14 15:01:25 --> Config Class Initialized
INFO - 2018-10-14 15:01:25 --> Hooks Class Initialized
DEBUG - 2018-10-14 15:01:25 --> UTF-8 Support Enabled
INFO - 2018-10-14 15:01:25 --> Utf8 Class Initialized
INFO - 2018-10-14 15:01:25 --> URI Class Initialized
INFO - 2018-10-14 15:01:25 --> Router Class Initialized
INFO - 2018-10-14 15:01:25 --> Output Class Initialized
INFO - 2018-10-14 15:01:25 --> Security Class Initialized
DEBUG - 2018-10-14 15:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-14 15:01:25 --> CSRF cookie sent
INFO - 2018-10-14 15:01:25 --> Input Class Initialized
INFO - 2018-10-14 15:01:25 --> Language Class Initialized
INFO - 2018-10-14 15:01:25 --> Loader Class Initialized
INFO - 2018-10-14 15:01:25 --> Helper loaded: url_helper
INFO - 2018-10-14 15:01:25 --> Helper loaded: form_helper
INFO - 2018-10-14 15:01:25 --> Helper loaded: language_helper
DEBUG - 2018-10-14 15:01:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-14 15:01:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-14 15:01:25 --> User Agent Class Initialized
INFO - 2018-10-14 15:01:25 --> Controller Class Initialized
INFO - 2018-10-14 15:01:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-14 15:01:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-14 15:01:25 --> Pixel_Model class loaded
INFO - 2018-10-14 15:01:25 --> Database Driver Class Initialized
INFO - 2018-10-14 15:01:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:01:25 --> Database Driver Class Initialized
INFO - 2018-10-14 15:01:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:01:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-14 15:01:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-14 15:01:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-14 15:01:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-14 15:01:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-14 15:01:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-14 15:01:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-14 15:01:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-14 15:01:25 --> Final output sent to browser
DEBUG - 2018-10-14 15:01:25 --> Total execution time: 0.0461
INFO - 2018-10-14 15:01:27 --> Config Class Initialized
INFO - 2018-10-14 15:01:27 --> Hooks Class Initialized
DEBUG - 2018-10-14 15:01:27 --> UTF-8 Support Enabled
INFO - 2018-10-14 15:01:27 --> Utf8 Class Initialized
INFO - 2018-10-14 15:01:27 --> URI Class Initialized
INFO - 2018-10-14 15:01:27 --> Router Class Initialized
INFO - 2018-10-14 15:01:27 --> Output Class Initialized
INFO - 2018-10-14 15:01:27 --> Security Class Initialized
DEBUG - 2018-10-14 15:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-14 15:01:27 --> CSRF cookie sent
INFO - 2018-10-14 15:01:27 --> Input Class Initialized
INFO - 2018-10-14 15:01:27 --> Language Class Initialized
INFO - 2018-10-14 15:01:27 --> Loader Class Initialized
INFO - 2018-10-14 15:01:27 --> Helper loaded: url_helper
INFO - 2018-10-14 15:01:27 --> Helper loaded: form_helper
INFO - 2018-10-14 15:01:27 --> Helper loaded: language_helper
DEBUG - 2018-10-14 15:01:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-14 15:01:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-14 15:01:27 --> User Agent Class Initialized
INFO - 2018-10-14 15:01:27 --> Controller Class Initialized
INFO - 2018-10-14 15:01:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-14 15:01:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-14 15:01:27 --> Pixel_Model class loaded
INFO - 2018-10-14 15:01:27 --> Database Driver Class Initialized
INFO - 2018-10-14 15:01:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:01:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-14 15:01:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-14 15:01:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-14 15:01:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-14 15:01:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-14 15:01:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-14 15:01:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-10-14 15:01:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-14 15:01:27 --> Final output sent to browser
DEBUG - 2018-10-14 15:01:27 --> Total execution time: 0.0385
INFO - 2018-10-14 15:01:37 --> Config Class Initialized
INFO - 2018-10-14 15:01:37 --> Hooks Class Initialized
DEBUG - 2018-10-14 15:01:37 --> UTF-8 Support Enabled
INFO - 2018-10-14 15:01:37 --> Utf8 Class Initialized
INFO - 2018-10-14 15:01:37 --> URI Class Initialized
INFO - 2018-10-14 15:01:37 --> Router Class Initialized
INFO - 2018-10-14 15:01:37 --> Output Class Initialized
INFO - 2018-10-14 15:01:37 --> Security Class Initialized
DEBUG - 2018-10-14 15:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-14 15:01:37 --> CSRF cookie sent
INFO - 2018-10-14 15:01:37 --> Input Class Initialized
INFO - 2018-10-14 15:01:37 --> Language Class Initialized
INFO - 2018-10-14 15:01:37 --> Loader Class Initialized
INFO - 2018-10-14 15:01:37 --> Helper loaded: url_helper
INFO - 2018-10-14 15:01:37 --> Helper loaded: form_helper
INFO - 2018-10-14 15:01:37 --> Helper loaded: language_helper
DEBUG - 2018-10-14 15:01:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-14 15:01:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-14 15:01:37 --> User Agent Class Initialized
INFO - 2018-10-14 15:01:37 --> Controller Class Initialized
INFO - 2018-10-14 15:01:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-14 15:01:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-14 15:01:37 --> Pixel_Model class loaded
INFO - 2018-10-14 15:01:37 --> Database Driver Class Initialized
INFO - 2018-10-14 15:01:37 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:01:37 --> Database Driver Class Initialized
INFO - 2018-10-14 15:01:37 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:01:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-14 15:01:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-14 15:01:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-14 15:01:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-14 15:01:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-14 15:01:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-14 15:01:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-14 15:01:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-14 15:01:37 --> Final output sent to browser
DEBUG - 2018-10-14 15:01:37 --> Total execution time: 0.0472
INFO - 2018-10-14 15:01:38 --> Config Class Initialized
INFO - 2018-10-14 15:01:38 --> Hooks Class Initialized
DEBUG - 2018-10-14 15:01:38 --> UTF-8 Support Enabled
INFO - 2018-10-14 15:01:38 --> Utf8 Class Initialized
INFO - 2018-10-14 15:01:38 --> URI Class Initialized
DEBUG - 2018-10-14 15:01:38 --> No URI present. Default controller set.
INFO - 2018-10-14 15:01:38 --> Router Class Initialized
INFO - 2018-10-14 15:01:38 --> Output Class Initialized
INFO - 2018-10-14 15:01:38 --> Security Class Initialized
DEBUG - 2018-10-14 15:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-14 15:01:38 --> CSRF cookie sent
INFO - 2018-10-14 15:01:38 --> Input Class Initialized
INFO - 2018-10-14 15:01:38 --> Language Class Initialized
INFO - 2018-10-14 15:01:38 --> Loader Class Initialized
INFO - 2018-10-14 15:01:38 --> Helper loaded: url_helper
INFO - 2018-10-14 15:01:38 --> Helper loaded: form_helper
INFO - 2018-10-14 15:01:38 --> Helper loaded: language_helper
DEBUG - 2018-10-14 15:01:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-14 15:01:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-14 15:01:38 --> User Agent Class Initialized
INFO - 2018-10-14 15:01:38 --> Controller Class Initialized
INFO - 2018-10-14 15:01:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-14 15:01:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-14 15:01:38 --> Pixel_Model class loaded
INFO - 2018-10-14 15:01:38 --> Database Driver Class Initialized
INFO - 2018-10-14 15:01:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:01:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-14 15:01:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-14 15:01:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-14 15:01:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-14 15:01:38 --> Final output sent to browser
DEBUG - 2018-10-14 15:01:38 --> Total execution time: 0.0445
INFO - 2018-10-14 15:01:49 --> Config Class Initialized
INFO - 2018-10-14 15:01:49 --> Hooks Class Initialized
DEBUG - 2018-10-14 15:01:49 --> UTF-8 Support Enabled
INFO - 2018-10-14 15:01:49 --> Utf8 Class Initialized
INFO - 2018-10-14 15:01:49 --> URI Class Initialized
DEBUG - 2018-10-14 15:01:49 --> No URI present. Default controller set.
INFO - 2018-10-14 15:01:49 --> Router Class Initialized
INFO - 2018-10-14 15:01:49 --> Output Class Initialized
INFO - 2018-10-14 15:01:49 --> Security Class Initialized
DEBUG - 2018-10-14 15:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-14 15:01:49 --> CSRF cookie sent
INFO - 2018-10-14 15:01:49 --> Input Class Initialized
INFO - 2018-10-14 15:01:49 --> Language Class Initialized
INFO - 2018-10-14 15:01:49 --> Loader Class Initialized
INFO - 2018-10-14 15:01:49 --> Helper loaded: url_helper
INFO - 2018-10-14 15:01:49 --> Helper loaded: form_helper
INFO - 2018-10-14 15:01:49 --> Helper loaded: language_helper
DEBUG - 2018-10-14 15:01:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-14 15:01:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-14 15:01:49 --> User Agent Class Initialized
INFO - 2018-10-14 15:01:49 --> Controller Class Initialized
INFO - 2018-10-14 15:01:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-14 15:01:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-14 15:01:49 --> Pixel_Model class loaded
INFO - 2018-10-14 15:01:49 --> Database Driver Class Initialized
INFO - 2018-10-14 15:01:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:01:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-14 15:01:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-14 15:01:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-14 15:01:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-14 15:01:49 --> Final output sent to browser
DEBUG - 2018-10-14 15:01:49 --> Total execution time: 0.0435
INFO - 2018-10-14 15:01:54 --> Config Class Initialized
INFO - 2018-10-14 15:01:54 --> Hooks Class Initialized
DEBUG - 2018-10-14 15:01:54 --> UTF-8 Support Enabled
INFO - 2018-10-14 15:01:54 --> Utf8 Class Initialized
INFO - 2018-10-14 15:01:54 --> URI Class Initialized
INFO - 2018-10-14 15:01:54 --> Router Class Initialized
INFO - 2018-10-14 15:01:54 --> Output Class Initialized
INFO - 2018-10-14 15:01:54 --> Security Class Initialized
DEBUG - 2018-10-14 15:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-14 15:01:55 --> CSRF cookie sent
INFO - 2018-10-14 15:01:55 --> CSRF token verified
INFO - 2018-10-14 15:01:55 --> Input Class Initialized
INFO - 2018-10-14 15:01:55 --> Language Class Initialized
INFO - 2018-10-14 15:01:55 --> Loader Class Initialized
INFO - 2018-10-14 15:01:55 --> Helper loaded: url_helper
INFO - 2018-10-14 15:01:55 --> Helper loaded: form_helper
INFO - 2018-10-14 15:01:55 --> Helper loaded: language_helper
DEBUG - 2018-10-14 15:01:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-14 15:01:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-14 15:01:55 --> User Agent Class Initialized
INFO - 2018-10-14 15:01:55 --> Controller Class Initialized
INFO - 2018-10-14 15:01:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-14 15:01:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-14 15:01:55 --> Pixel_Model class loaded
INFO - 2018-10-14 15:01:55 --> Database Driver Class Initialized
INFO - 2018-10-14 15:01:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:01:55 --> Form Validation Class Initialized
INFO - 2018-10-14 15:01:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-14 15:01:55 --> Database Driver Class Initialized
INFO - 2018-10-14 15:01:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:01:55 --> Config Class Initialized
INFO - 2018-10-14 15:01:55 --> Hooks Class Initialized
DEBUG - 2018-10-14 15:01:55 --> UTF-8 Support Enabled
INFO - 2018-10-14 15:01:55 --> Utf8 Class Initialized
INFO - 2018-10-14 15:01:55 --> URI Class Initialized
INFO - 2018-10-14 15:01:55 --> Router Class Initialized
INFO - 2018-10-14 15:01:55 --> Output Class Initialized
INFO - 2018-10-14 15:01:55 --> Security Class Initialized
DEBUG - 2018-10-14 15:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-14 15:01:55 --> CSRF cookie sent
INFO - 2018-10-14 15:01:55 --> Input Class Initialized
INFO - 2018-10-14 15:01:55 --> Language Class Initialized
INFO - 2018-10-14 15:01:55 --> Loader Class Initialized
INFO - 2018-10-14 15:01:55 --> Helper loaded: url_helper
INFO - 2018-10-14 15:01:55 --> Helper loaded: form_helper
INFO - 2018-10-14 15:01:55 --> Helper loaded: language_helper
DEBUG - 2018-10-14 15:01:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-14 15:01:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-14 15:01:55 --> User Agent Class Initialized
INFO - 2018-10-14 15:01:55 --> Controller Class Initialized
INFO - 2018-10-14 15:01:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-14 15:01:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-14 15:01:55 --> Pixel_Model class loaded
INFO - 2018-10-14 15:01:55 --> Database Driver Class Initialized
INFO - 2018-10-14 15:01:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:01:55 --> Database Driver Class Initialized
INFO - 2018-10-14 15:01:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:01:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-14 15:01:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-14 15:01:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-14 15:01:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-14 15:01:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-14 15:01:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-14 15:01:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-14 15:01:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-14 15:01:55 --> Final output sent to browser
DEBUG - 2018-10-14 15:01:55 --> Total execution time: 0.0469
INFO - 2018-10-14 15:02:35 --> Config Class Initialized
INFO - 2018-10-14 15:02:35 --> Hooks Class Initialized
DEBUG - 2018-10-14 15:02:35 --> UTF-8 Support Enabled
INFO - 2018-10-14 15:02:35 --> Utf8 Class Initialized
INFO - 2018-10-14 15:02:35 --> URI Class Initialized
DEBUG - 2018-10-14 15:02:35 --> No URI present. Default controller set.
INFO - 2018-10-14 15:02:35 --> Router Class Initialized
INFO - 2018-10-14 15:02:35 --> Output Class Initialized
INFO - 2018-10-14 15:02:35 --> Security Class Initialized
DEBUG - 2018-10-14 15:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-14 15:02:35 --> CSRF cookie sent
INFO - 2018-10-14 15:02:35 --> Input Class Initialized
INFO - 2018-10-14 15:02:35 --> Language Class Initialized
INFO - 2018-10-14 15:02:35 --> Loader Class Initialized
INFO - 2018-10-14 15:02:35 --> Helper loaded: url_helper
INFO - 2018-10-14 15:02:35 --> Helper loaded: form_helper
INFO - 2018-10-14 15:02:35 --> Helper loaded: language_helper
DEBUG - 2018-10-14 15:02:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-14 15:02:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-14 15:02:35 --> User Agent Class Initialized
INFO - 2018-10-14 15:02:35 --> Controller Class Initialized
INFO - 2018-10-14 15:02:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-14 15:02:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-14 15:02:35 --> Pixel_Model class loaded
INFO - 2018-10-14 15:02:35 --> Database Driver Class Initialized
INFO - 2018-10-14 15:02:35 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:02:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-14 15:02:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-14 15:02:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-14 15:02:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-14 15:02:35 --> Final output sent to browser
DEBUG - 2018-10-14 15:02:35 --> Total execution time: 0.0413
INFO - 2018-10-14 15:05:13 --> Config Class Initialized
INFO - 2018-10-14 15:05:13 --> Hooks Class Initialized
DEBUG - 2018-10-14 15:05:13 --> UTF-8 Support Enabled
INFO - 2018-10-14 15:05:13 --> Utf8 Class Initialized
INFO - 2018-10-14 15:05:13 --> URI Class Initialized
INFO - 2018-10-14 15:05:13 --> Router Class Initialized
INFO - 2018-10-14 15:05:13 --> Output Class Initialized
INFO - 2018-10-14 15:05:13 --> Security Class Initialized
DEBUG - 2018-10-14 15:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-14 15:05:13 --> CSRF cookie sent
INFO - 2018-10-14 15:05:13 --> CSRF token verified
INFO - 2018-10-14 15:05:13 --> Input Class Initialized
INFO - 2018-10-14 15:05:13 --> Language Class Initialized
INFO - 2018-10-14 15:05:13 --> Loader Class Initialized
INFO - 2018-10-14 15:05:13 --> Helper loaded: url_helper
INFO - 2018-10-14 15:05:13 --> Helper loaded: form_helper
INFO - 2018-10-14 15:05:13 --> Helper loaded: language_helper
DEBUG - 2018-10-14 15:05:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-14 15:05:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-14 15:05:13 --> User Agent Class Initialized
INFO - 2018-10-14 15:05:13 --> Controller Class Initialized
INFO - 2018-10-14 15:05:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-14 15:05:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-14 15:05:13 --> Pixel_Model class loaded
INFO - 2018-10-14 15:05:13 --> Database Driver Class Initialized
INFO - 2018-10-14 15:05:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:05:13 --> Form Validation Class Initialized
INFO - 2018-10-14 15:05:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-14 15:05:13 --> Database Driver Class Initialized
INFO - 2018-10-14 15:05:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:05:13 --> Config Class Initialized
INFO - 2018-10-14 15:05:13 --> Hooks Class Initialized
DEBUG - 2018-10-14 15:05:13 --> UTF-8 Support Enabled
INFO - 2018-10-14 15:05:13 --> Utf8 Class Initialized
INFO - 2018-10-14 15:05:13 --> URI Class Initialized
INFO - 2018-10-14 15:05:13 --> Router Class Initialized
INFO - 2018-10-14 15:05:13 --> Output Class Initialized
INFO - 2018-10-14 15:05:13 --> Security Class Initialized
DEBUG - 2018-10-14 15:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-14 15:05:13 --> CSRF cookie sent
INFO - 2018-10-14 15:05:13 --> Input Class Initialized
INFO - 2018-10-14 15:05:13 --> Language Class Initialized
INFO - 2018-10-14 15:05:13 --> Loader Class Initialized
INFO - 2018-10-14 15:05:13 --> Helper loaded: url_helper
INFO - 2018-10-14 15:05:13 --> Helper loaded: form_helper
INFO - 2018-10-14 15:05:13 --> Helper loaded: language_helper
DEBUG - 2018-10-14 15:05:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-14 15:05:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-14 15:05:13 --> User Agent Class Initialized
INFO - 2018-10-14 15:05:13 --> Controller Class Initialized
INFO - 2018-10-14 15:05:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-14 15:05:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-14 15:05:13 --> Pixel_Model class loaded
INFO - 2018-10-14 15:05:13 --> Database Driver Class Initialized
INFO - 2018-10-14 15:05:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:05:13 --> Database Driver Class Initialized
INFO - 2018-10-14 15:05:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:05:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-14 15:05:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-14 15:05:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-14 15:05:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-14 15:05:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-14 15:05:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-14 15:05:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-14 15:05:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-14 15:05:13 --> Final output sent to browser
DEBUG - 2018-10-14 15:05:13 --> Total execution time: 0.0478
INFO - 2018-10-14 15:05:18 --> Config Class Initialized
INFO - 2018-10-14 15:05:18 --> Hooks Class Initialized
DEBUG - 2018-10-14 15:05:18 --> UTF-8 Support Enabled
INFO - 2018-10-14 15:05:18 --> Utf8 Class Initialized
INFO - 2018-10-14 15:05:18 --> URI Class Initialized
INFO - 2018-10-14 15:05:18 --> Router Class Initialized
INFO - 2018-10-14 15:05:18 --> Output Class Initialized
INFO - 2018-10-14 15:05:18 --> Security Class Initialized
DEBUG - 2018-10-14 15:05:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-14 15:05:18 --> CSRF cookie sent
INFO - 2018-10-14 15:05:18 --> CSRF token verified
INFO - 2018-10-14 15:05:18 --> Input Class Initialized
INFO - 2018-10-14 15:05:18 --> Language Class Initialized
INFO - 2018-10-14 15:05:18 --> Loader Class Initialized
INFO - 2018-10-14 15:05:18 --> Helper loaded: url_helper
INFO - 2018-10-14 15:05:18 --> Helper loaded: form_helper
INFO - 2018-10-14 15:05:18 --> Helper loaded: language_helper
DEBUG - 2018-10-14 15:05:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-14 15:05:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-14 15:05:18 --> User Agent Class Initialized
INFO - 2018-10-14 15:05:18 --> Controller Class Initialized
INFO - 2018-10-14 15:05:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-14 15:05:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-14 15:05:18 --> Pixel_Model class loaded
INFO - 2018-10-14 15:05:18 --> Database Driver Class Initialized
INFO - 2018-10-14 15:05:18 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:05:18 --> Form Validation Class Initialized
INFO - 2018-10-14 15:05:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-14 15:05:18 --> Database Driver Class Initialized
INFO - 2018-10-14 15:05:18 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:05:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-14 15:05:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-14 15:05:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-14 15:05:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-14 15:05:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-14 15:05:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_errors.php
INFO - 2018-10-14 15:05:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-14 15:05:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-14 15:05:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-14 15:05:18 --> Final output sent to browser
DEBUG - 2018-10-14 15:05:18 --> Total execution time: 0.0671
INFO - 2018-10-14 15:05:36 --> Config Class Initialized
INFO - 2018-10-14 15:05:36 --> Hooks Class Initialized
DEBUG - 2018-10-14 15:05:36 --> UTF-8 Support Enabled
INFO - 2018-10-14 15:05:36 --> Utf8 Class Initialized
INFO - 2018-10-14 15:05:36 --> URI Class Initialized
INFO - 2018-10-14 15:05:36 --> Router Class Initialized
INFO - 2018-10-14 15:05:36 --> Output Class Initialized
INFO - 2018-10-14 15:05:36 --> Security Class Initialized
DEBUG - 2018-10-14 15:05:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-14 15:05:36 --> CSRF cookie sent
INFO - 2018-10-14 15:05:36 --> CSRF token verified
INFO - 2018-10-14 15:05:36 --> Input Class Initialized
INFO - 2018-10-14 15:05:36 --> Language Class Initialized
INFO - 2018-10-14 15:05:36 --> Loader Class Initialized
INFO - 2018-10-14 15:05:36 --> Helper loaded: url_helper
INFO - 2018-10-14 15:05:36 --> Helper loaded: form_helper
INFO - 2018-10-14 15:05:36 --> Helper loaded: language_helper
DEBUG - 2018-10-14 15:05:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-14 15:05:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-14 15:05:36 --> User Agent Class Initialized
INFO - 2018-10-14 15:05:36 --> Controller Class Initialized
INFO - 2018-10-14 15:05:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-14 15:05:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-14 15:05:36 --> Pixel_Model class loaded
INFO - 2018-10-14 15:05:36 --> Database Driver Class Initialized
INFO - 2018-10-14 15:05:36 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:05:36 --> Form Validation Class Initialized
INFO - 2018-10-14 15:05:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-14 15:05:36 --> Database Driver Class Initialized
INFO - 2018-10-14 15:05:36 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:05:36 --> Config Class Initialized
INFO - 2018-10-14 15:05:36 --> Hooks Class Initialized
DEBUG - 2018-10-14 15:05:36 --> UTF-8 Support Enabled
INFO - 2018-10-14 15:05:36 --> Utf8 Class Initialized
INFO - 2018-10-14 15:05:36 --> URI Class Initialized
INFO - 2018-10-14 15:05:36 --> Router Class Initialized
INFO - 2018-10-14 15:05:36 --> Output Class Initialized
INFO - 2018-10-14 15:05:36 --> Security Class Initialized
DEBUG - 2018-10-14 15:05:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-14 15:05:36 --> CSRF cookie sent
INFO - 2018-10-14 15:05:36 --> Input Class Initialized
INFO - 2018-10-14 15:05:36 --> Language Class Initialized
INFO - 2018-10-14 15:05:36 --> Loader Class Initialized
INFO - 2018-10-14 15:05:36 --> Helper loaded: url_helper
INFO - 2018-10-14 15:05:36 --> Helper loaded: form_helper
INFO - 2018-10-14 15:05:36 --> Helper loaded: language_helper
DEBUG - 2018-10-14 15:05:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-14 15:05:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-14 15:05:36 --> User Agent Class Initialized
INFO - 2018-10-14 15:05:36 --> Controller Class Initialized
INFO - 2018-10-14 15:05:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-14 15:05:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-14 15:05:36 --> Pixel_Model class loaded
INFO - 2018-10-14 15:05:36 --> Database Driver Class Initialized
INFO - 2018-10-14 15:05:36 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:05:36 --> Database Driver Class Initialized
INFO - 2018-10-14 15:05:36 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:05:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-14 15:05:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-14 15:05:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-14 15:05:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-14 15:05:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-14 15:05:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-14 15:05:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-10-14 15:05:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-14 15:05:36 --> Final output sent to browser
DEBUG - 2018-10-14 15:05:36 --> Total execution time: 0.0588
INFO - 2018-10-14 15:06:42 --> Config Class Initialized
INFO - 2018-10-14 15:06:42 --> Hooks Class Initialized
DEBUG - 2018-10-14 15:06:42 --> UTF-8 Support Enabled
INFO - 2018-10-14 15:06:42 --> Utf8 Class Initialized
INFO - 2018-10-14 15:06:42 --> URI Class Initialized
INFO - 2018-10-14 15:06:42 --> Router Class Initialized
INFO - 2018-10-14 15:06:42 --> Output Class Initialized
INFO - 2018-10-14 15:06:42 --> Security Class Initialized
DEBUG - 2018-10-14 15:06:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-14 15:06:42 --> CSRF cookie sent
INFO - 2018-10-14 15:06:42 --> CSRF token verified
INFO - 2018-10-14 15:06:42 --> Input Class Initialized
INFO - 2018-10-14 15:06:42 --> Language Class Initialized
INFO - 2018-10-14 15:06:42 --> Loader Class Initialized
INFO - 2018-10-14 15:06:42 --> Helper loaded: url_helper
INFO - 2018-10-14 15:06:42 --> Helper loaded: form_helper
INFO - 2018-10-14 15:06:42 --> Helper loaded: language_helper
DEBUG - 2018-10-14 15:06:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-14 15:06:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-14 15:06:42 --> User Agent Class Initialized
INFO - 2018-10-14 15:06:42 --> Controller Class Initialized
INFO - 2018-10-14 15:06:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-14 15:06:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-14 15:06:42 --> Pixel_Model class loaded
INFO - 2018-10-14 15:06:42 --> Database Driver Class Initialized
INFO - 2018-10-14 15:06:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:06:42 --> Form Validation Class Initialized
INFO - 2018-10-14 15:06:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-14 15:06:42 --> Database Driver Class Initialized
INFO - 2018-10-14 15:06:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:06:43 --> Config Class Initialized
INFO - 2018-10-14 15:06:43 --> Hooks Class Initialized
DEBUG - 2018-10-14 15:06:43 --> UTF-8 Support Enabled
INFO - 2018-10-14 15:06:43 --> Utf8 Class Initialized
INFO - 2018-10-14 15:06:43 --> URI Class Initialized
INFO - 2018-10-14 15:06:43 --> Router Class Initialized
INFO - 2018-10-14 15:06:43 --> Output Class Initialized
INFO - 2018-10-14 15:06:43 --> Security Class Initialized
DEBUG - 2018-10-14 15:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-14 15:06:43 --> CSRF cookie sent
INFO - 2018-10-14 15:06:43 --> Input Class Initialized
INFO - 2018-10-14 15:06:43 --> Language Class Initialized
INFO - 2018-10-14 15:06:43 --> Loader Class Initialized
INFO - 2018-10-14 15:06:43 --> Helper loaded: url_helper
INFO - 2018-10-14 15:06:43 --> Helper loaded: form_helper
INFO - 2018-10-14 15:06:43 --> Helper loaded: language_helper
DEBUG - 2018-10-14 15:06:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-14 15:06:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-14 15:06:43 --> User Agent Class Initialized
INFO - 2018-10-14 15:06:43 --> Controller Class Initialized
INFO - 2018-10-14 15:06:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-14 15:06:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-14 15:06:43 --> Pixel_Model class loaded
INFO - 2018-10-14 15:06:43 --> Database Driver Class Initialized
INFO - 2018-10-14 15:06:43 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:06:43 --> Database Driver Class Initialized
INFO - 2018-10-14 15:06:43 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:06:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-14 15:06:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-14 15:06:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-10-14 15:06:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-14 15:06:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-14 15:06:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-14 15:06:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-14 15:06:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-10-14 15:06:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-14 15:06:43 --> Final output sent to browser
DEBUG - 2018-10-14 15:06:43 --> Total execution time: 0.0345
INFO - 2018-10-14 15:06:59 --> Config Class Initialized
INFO - 2018-10-14 15:06:59 --> Hooks Class Initialized
DEBUG - 2018-10-14 15:06:59 --> UTF-8 Support Enabled
INFO - 2018-10-14 15:06:59 --> Utf8 Class Initialized
INFO - 2018-10-14 15:06:59 --> URI Class Initialized
INFO - 2018-10-14 15:06:59 --> Router Class Initialized
INFO - 2018-10-14 15:06:59 --> Output Class Initialized
INFO - 2018-10-14 15:06:59 --> Security Class Initialized
DEBUG - 2018-10-14 15:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-14 15:06:59 --> CSRF cookie sent
INFO - 2018-10-14 15:06:59 --> CSRF token verified
INFO - 2018-10-14 15:06:59 --> Input Class Initialized
INFO - 2018-10-14 15:06:59 --> Language Class Initialized
INFO - 2018-10-14 15:06:59 --> Loader Class Initialized
INFO - 2018-10-14 15:06:59 --> Helper loaded: url_helper
INFO - 2018-10-14 15:06:59 --> Helper loaded: form_helper
INFO - 2018-10-14 15:06:59 --> Helper loaded: language_helper
DEBUG - 2018-10-14 15:06:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-14 15:06:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-14 15:06:59 --> User Agent Class Initialized
INFO - 2018-10-14 15:06:59 --> Controller Class Initialized
INFO - 2018-10-14 15:06:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-14 15:06:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-14 15:06:59 --> Pixel_Model class loaded
INFO - 2018-10-14 15:06:59 --> Database Driver Class Initialized
INFO - 2018-10-14 15:06:59 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:06:59 --> Form Validation Class Initialized
INFO - 2018-10-14 15:06:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-14 15:06:59 --> Database Driver Class Initialized
INFO - 2018-10-14 15:06:59 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:06:59 --> Config Class Initialized
INFO - 2018-10-14 15:06:59 --> Hooks Class Initialized
DEBUG - 2018-10-14 15:06:59 --> UTF-8 Support Enabled
INFO - 2018-10-14 15:06:59 --> Utf8 Class Initialized
INFO - 2018-10-14 15:06:59 --> URI Class Initialized
INFO - 2018-10-14 15:06:59 --> Router Class Initialized
INFO - 2018-10-14 15:06:59 --> Output Class Initialized
INFO - 2018-10-14 15:06:59 --> Security Class Initialized
DEBUG - 2018-10-14 15:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-14 15:06:59 --> CSRF cookie sent
INFO - 2018-10-14 15:06:59 --> Input Class Initialized
INFO - 2018-10-14 15:06:59 --> Language Class Initialized
INFO - 2018-10-14 15:06:59 --> Loader Class Initialized
INFO - 2018-10-14 15:06:59 --> Helper loaded: url_helper
INFO - 2018-10-14 15:06:59 --> Helper loaded: form_helper
INFO - 2018-10-14 15:06:59 --> Helper loaded: language_helper
DEBUG - 2018-10-14 15:06:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-14 15:06:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-14 15:06:59 --> User Agent Class Initialized
INFO - 2018-10-14 15:06:59 --> Controller Class Initialized
INFO - 2018-10-14 15:06:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-14 15:06:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-14 15:06:59 --> Pixel_Model class loaded
INFO - 2018-10-14 15:06:59 --> Database Driver Class Initialized
INFO - 2018-10-14 15:06:59 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:06:59 --> Database Driver Class Initialized
INFO - 2018-10-14 15:06:59 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:06:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-14 15:06:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-14 15:06:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-14 15:06:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-14 15:06:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-14 15:06:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-14 15:06:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-14 15:06:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-14 15:06:59 --> Final output sent to browser
DEBUG - 2018-10-14 15:06:59 --> Total execution time: 0.0350
INFO - 2018-10-14 15:07:04 --> Config Class Initialized
INFO - 2018-10-14 15:07:04 --> Hooks Class Initialized
DEBUG - 2018-10-14 15:07:04 --> UTF-8 Support Enabled
INFO - 2018-10-14 15:07:04 --> Utf8 Class Initialized
INFO - 2018-10-14 15:07:04 --> URI Class Initialized
INFO - 2018-10-14 15:07:04 --> Router Class Initialized
INFO - 2018-10-14 15:07:04 --> Output Class Initialized
INFO - 2018-10-14 15:07:04 --> Security Class Initialized
DEBUG - 2018-10-14 15:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-14 15:07:04 --> CSRF cookie sent
INFO - 2018-10-14 15:07:04 --> Input Class Initialized
INFO - 2018-10-14 15:07:04 --> Language Class Initialized
INFO - 2018-10-14 15:07:04 --> Loader Class Initialized
INFO - 2018-10-14 15:07:04 --> Helper loaded: url_helper
INFO - 2018-10-14 15:07:04 --> Helper loaded: form_helper
INFO - 2018-10-14 15:07:04 --> Helper loaded: language_helper
DEBUG - 2018-10-14 15:07:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-14 15:07:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-14 15:07:04 --> User Agent Class Initialized
INFO - 2018-10-14 15:07:04 --> Controller Class Initialized
INFO - 2018-10-14 15:07:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-14 15:07:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-14 15:07:04 --> Pixel_Model class loaded
INFO - 2018-10-14 15:07:04 --> Database Driver Class Initialized
INFO - 2018-10-14 15:07:04 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:07:04 --> Database Driver Class Initialized
INFO - 2018-10-14 15:07:04 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:07:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-14 15:07:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-14 15:07:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-14 15:07:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-14 15:07:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/save_exit.php
INFO - 2018-10-14 15:07:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-14 15:07:04 --> Final output sent to browser
DEBUG - 2018-10-14 15:07:04 --> Total execution time: 0.0479
INFO - 2018-10-14 15:07:06 --> Config Class Initialized
INFO - 2018-10-14 15:07:06 --> Hooks Class Initialized
DEBUG - 2018-10-14 15:07:06 --> UTF-8 Support Enabled
INFO - 2018-10-14 15:07:06 --> Utf8 Class Initialized
INFO - 2018-10-14 15:07:06 --> URI Class Initialized
INFO - 2018-10-14 15:07:06 --> Router Class Initialized
INFO - 2018-10-14 15:07:06 --> Output Class Initialized
INFO - 2018-10-14 15:07:06 --> Security Class Initialized
DEBUG - 2018-10-14 15:07:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-14 15:07:06 --> CSRF cookie sent
INFO - 2018-10-14 15:07:06 --> Input Class Initialized
INFO - 2018-10-14 15:07:06 --> Language Class Initialized
INFO - 2018-10-14 15:07:06 --> Loader Class Initialized
INFO - 2018-10-14 15:07:06 --> Helper loaded: url_helper
INFO - 2018-10-14 15:07:06 --> Helper loaded: form_helper
INFO - 2018-10-14 15:07:06 --> Helper loaded: language_helper
DEBUG - 2018-10-14 15:07:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-14 15:07:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-14 15:07:06 --> User Agent Class Initialized
INFO - 2018-10-14 15:07:06 --> Controller Class Initialized
INFO - 2018-10-14 15:07:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-14 15:07:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-14 15:07:06 --> Pixel_Model class loaded
INFO - 2018-10-14 15:07:06 --> Database Driver Class Initialized
INFO - 2018-10-14 15:07:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:07:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-14 15:07:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-14 15:07:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-14 15:07:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-14 15:07:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/contact_us.php
INFO - 2018-10-14 15:07:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-14 15:07:06 --> Final output sent to browser
DEBUG - 2018-10-14 15:07:06 --> Total execution time: 0.0571
INFO - 2018-10-14 15:07:11 --> Config Class Initialized
INFO - 2018-10-14 15:07:11 --> Hooks Class Initialized
DEBUG - 2018-10-14 15:07:11 --> UTF-8 Support Enabled
INFO - 2018-10-14 15:07:11 --> Utf8 Class Initialized
INFO - 2018-10-14 15:07:11 --> URI Class Initialized
INFO - 2018-10-14 15:07:11 --> Router Class Initialized
INFO - 2018-10-14 15:07:11 --> Output Class Initialized
INFO - 2018-10-14 15:07:11 --> Security Class Initialized
DEBUG - 2018-10-14 15:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-14 15:07:11 --> CSRF cookie sent
INFO - 2018-10-14 15:07:11 --> Input Class Initialized
INFO - 2018-10-14 15:07:11 --> Language Class Initialized
INFO - 2018-10-14 15:07:11 --> Loader Class Initialized
INFO - 2018-10-14 15:07:11 --> Helper loaded: url_helper
INFO - 2018-10-14 15:07:11 --> Helper loaded: form_helper
INFO - 2018-10-14 15:07:11 --> Helper loaded: language_helper
DEBUG - 2018-10-14 15:07:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-14 15:07:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-14 15:07:11 --> User Agent Class Initialized
INFO - 2018-10-14 15:07:11 --> Controller Class Initialized
INFO - 2018-10-14 15:07:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-14 15:07:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-14 15:07:11 --> Pixel_Model class loaded
INFO - 2018-10-14 15:07:11 --> Database Driver Class Initialized
INFO - 2018-10-14 15:07:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:07:11 --> Database Driver Class Initialized
INFO - 2018-10-14 15:07:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:07:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-14 15:07:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-14 15:07:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-14 15:07:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-14 15:07:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/save_exit.php
INFO - 2018-10-14 15:07:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-14 15:07:11 --> Final output sent to browser
DEBUG - 2018-10-14 15:07:11 --> Total execution time: 0.0452
INFO - 2018-10-14 15:07:13 --> Config Class Initialized
INFO - 2018-10-14 15:07:13 --> Hooks Class Initialized
DEBUG - 2018-10-14 15:07:13 --> UTF-8 Support Enabled
INFO - 2018-10-14 15:07:13 --> Utf8 Class Initialized
INFO - 2018-10-14 15:07:13 --> URI Class Initialized
INFO - 2018-10-14 15:07:13 --> Router Class Initialized
INFO - 2018-10-14 15:07:13 --> Output Class Initialized
INFO - 2018-10-14 15:07:13 --> Security Class Initialized
DEBUG - 2018-10-14 15:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-14 15:07:13 --> CSRF cookie sent
INFO - 2018-10-14 15:07:13 --> Input Class Initialized
INFO - 2018-10-14 15:07:13 --> Language Class Initialized
INFO - 2018-10-14 15:07:13 --> Loader Class Initialized
INFO - 2018-10-14 15:07:13 --> Helper loaded: url_helper
INFO - 2018-10-14 15:07:13 --> Helper loaded: form_helper
INFO - 2018-10-14 15:07:13 --> Helper loaded: language_helper
DEBUG - 2018-10-14 15:07:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-14 15:07:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-14 15:07:13 --> User Agent Class Initialized
INFO - 2018-10-14 15:07:13 --> Controller Class Initialized
INFO - 2018-10-14 15:07:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-14 15:07:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-14 15:07:13 --> Pixel_Model class loaded
INFO - 2018-10-14 15:07:13 --> Database Driver Class Initialized
INFO - 2018-10-14 15:07:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:07:13 --> Database Driver Class Initialized
INFO - 2018-10-14 15:07:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:07:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-14 15:07:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-14 15:07:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-14 15:07:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-14 15:07:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-14 15:07:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-14 15:07:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-14 15:07:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-14 15:07:13 --> Final output sent to browser
DEBUG - 2018-10-14 15:07:13 --> Total execution time: 0.0420
INFO - 2018-10-14 15:07:20 --> Config Class Initialized
INFO - 2018-10-14 15:07:20 --> Hooks Class Initialized
DEBUG - 2018-10-14 15:07:20 --> UTF-8 Support Enabled
INFO - 2018-10-14 15:07:20 --> Utf8 Class Initialized
INFO - 2018-10-14 15:07:20 --> URI Class Initialized
INFO - 2018-10-14 15:07:20 --> Router Class Initialized
INFO - 2018-10-14 15:07:20 --> Output Class Initialized
INFO - 2018-10-14 15:07:20 --> Security Class Initialized
DEBUG - 2018-10-14 15:07:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-14 15:07:20 --> CSRF cookie sent
INFO - 2018-10-14 15:07:20 --> CSRF token verified
INFO - 2018-10-14 15:07:20 --> Input Class Initialized
INFO - 2018-10-14 15:07:20 --> Language Class Initialized
INFO - 2018-10-14 15:07:20 --> Loader Class Initialized
INFO - 2018-10-14 15:07:20 --> Helper loaded: url_helper
INFO - 2018-10-14 15:07:20 --> Helper loaded: form_helper
INFO - 2018-10-14 15:07:20 --> Helper loaded: language_helper
DEBUG - 2018-10-14 15:07:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-14 15:07:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-14 15:07:20 --> User Agent Class Initialized
INFO - 2018-10-14 15:07:20 --> Controller Class Initialized
INFO - 2018-10-14 15:07:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-14 15:07:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-14 15:07:20 --> Pixel_Model class loaded
INFO - 2018-10-14 15:07:20 --> Database Driver Class Initialized
INFO - 2018-10-14 15:07:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:07:20 --> Form Validation Class Initialized
INFO - 2018-10-14 15:07:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-14 15:07:20 --> Database Driver Class Initialized
INFO - 2018-10-14 15:07:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:07:20 --> Config Class Initialized
INFO - 2018-10-14 15:07:20 --> Hooks Class Initialized
DEBUG - 2018-10-14 15:07:20 --> UTF-8 Support Enabled
INFO - 2018-10-14 15:07:20 --> Utf8 Class Initialized
INFO - 2018-10-14 15:07:20 --> URI Class Initialized
INFO - 2018-10-14 15:07:20 --> Router Class Initialized
INFO - 2018-10-14 15:07:20 --> Output Class Initialized
INFO - 2018-10-14 15:07:20 --> Security Class Initialized
DEBUG - 2018-10-14 15:07:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-14 15:07:20 --> CSRF cookie sent
INFO - 2018-10-14 15:07:20 --> Input Class Initialized
INFO - 2018-10-14 15:07:20 --> Language Class Initialized
INFO - 2018-10-14 15:07:20 --> Loader Class Initialized
INFO - 2018-10-14 15:07:20 --> Helper loaded: url_helper
INFO - 2018-10-14 15:07:20 --> Helper loaded: form_helper
INFO - 2018-10-14 15:07:20 --> Helper loaded: language_helper
DEBUG - 2018-10-14 15:07:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-14 15:07:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-14 15:07:20 --> User Agent Class Initialized
INFO - 2018-10-14 15:07:20 --> Controller Class Initialized
INFO - 2018-10-14 15:07:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-14 15:07:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-14 15:07:20 --> Pixel_Model class loaded
INFO - 2018-10-14 15:07:20 --> Database Driver Class Initialized
INFO - 2018-10-14 15:07:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:07:20 --> Database Driver Class Initialized
INFO - 2018-10-14 15:07:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:07:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-14 15:07:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-14 15:07:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-14 15:07:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-14 15:07:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-14 15:07:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-14 15:07:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/marriage.php
INFO - 2018-10-14 15:07:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-14 15:07:20 --> Final output sent to browser
DEBUG - 2018-10-14 15:07:20 --> Total execution time: 0.0424
INFO - 2018-10-14 15:08:11 --> Config Class Initialized
INFO - 2018-10-14 15:08:11 --> Hooks Class Initialized
DEBUG - 2018-10-14 15:08:11 --> UTF-8 Support Enabled
INFO - 2018-10-14 15:08:11 --> Utf8 Class Initialized
INFO - 2018-10-14 15:08:11 --> URI Class Initialized
INFO - 2018-10-14 15:08:11 --> Router Class Initialized
INFO - 2018-10-14 15:08:11 --> Output Class Initialized
INFO - 2018-10-14 15:08:11 --> Security Class Initialized
DEBUG - 2018-10-14 15:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-14 15:08:11 --> CSRF cookie sent
INFO - 2018-10-14 15:08:11 --> Input Class Initialized
INFO - 2018-10-14 15:08:11 --> Language Class Initialized
INFO - 2018-10-14 15:08:11 --> Loader Class Initialized
INFO - 2018-10-14 15:08:11 --> Helper loaded: url_helper
INFO - 2018-10-14 15:08:11 --> Helper loaded: form_helper
INFO - 2018-10-14 15:08:11 --> Helper loaded: language_helper
DEBUG - 2018-10-14 15:08:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-14 15:08:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-14 15:08:11 --> User Agent Class Initialized
INFO - 2018-10-14 15:08:11 --> Controller Class Initialized
INFO - 2018-10-14 15:08:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-14 15:08:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-14 15:08:11 --> Pixel_Model class loaded
INFO - 2018-10-14 15:08:11 --> Database Driver Class Initialized
INFO - 2018-10-14 15:08:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:08:11 --> Database Driver Class Initialized
INFO - 2018-10-14 15:08:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:08:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-14 15:08:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-14 15:08:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-14 15:08:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-14 15:08:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-10-14 15:08:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-14 15:08:11 --> Final output sent to browser
DEBUG - 2018-10-14 15:08:11 --> Total execution time: 0.0470
INFO - 2018-10-14 15:08:17 --> Config Class Initialized
INFO - 2018-10-14 15:08:17 --> Hooks Class Initialized
DEBUG - 2018-10-14 15:08:17 --> UTF-8 Support Enabled
INFO - 2018-10-14 15:08:17 --> Utf8 Class Initialized
INFO - 2018-10-14 15:08:17 --> URI Class Initialized
INFO - 2018-10-14 15:08:17 --> Router Class Initialized
INFO - 2018-10-14 15:08:17 --> Output Class Initialized
INFO - 2018-10-14 15:08:17 --> Security Class Initialized
DEBUG - 2018-10-14 15:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-14 15:08:17 --> CSRF cookie sent
INFO - 2018-10-14 15:08:17 --> Input Class Initialized
INFO - 2018-10-14 15:08:17 --> Language Class Initialized
INFO - 2018-10-14 15:08:17 --> Loader Class Initialized
INFO - 2018-10-14 15:08:17 --> Helper loaded: url_helper
INFO - 2018-10-14 15:08:17 --> Helper loaded: form_helper
INFO - 2018-10-14 15:08:17 --> Helper loaded: language_helper
DEBUG - 2018-10-14 15:08:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-14 15:08:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-14 15:08:17 --> User Agent Class Initialized
INFO - 2018-10-14 15:08:17 --> Controller Class Initialized
INFO - 2018-10-14 15:08:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-14 15:08:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-14 15:08:17 --> Pixel_Model class loaded
INFO - 2018-10-14 15:08:17 --> Database Driver Class Initialized
INFO - 2018-10-14 15:08:17 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:08:17 --> Database Driver Class Initialized
INFO - 2018-10-14 15:08:17 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:08:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-14 15:08:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-14 15:08:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-14 15:08:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-14 15:08:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-14 15:08:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-14 15:08:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/marriage.php
INFO - 2018-10-14 15:08:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-14 15:08:17 --> Final output sent to browser
DEBUG - 2018-10-14 15:08:17 --> Total execution time: 0.0408
INFO - 2018-10-14 15:08:31 --> Config Class Initialized
INFO - 2018-10-14 15:08:31 --> Hooks Class Initialized
DEBUG - 2018-10-14 15:08:31 --> UTF-8 Support Enabled
INFO - 2018-10-14 15:08:31 --> Utf8 Class Initialized
INFO - 2018-10-14 15:08:31 --> URI Class Initialized
INFO - 2018-10-14 15:08:31 --> Router Class Initialized
INFO - 2018-10-14 15:08:31 --> Output Class Initialized
INFO - 2018-10-14 15:08:31 --> Security Class Initialized
DEBUG - 2018-10-14 15:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-14 15:08:31 --> CSRF cookie sent
INFO - 2018-10-14 15:08:31 --> Input Class Initialized
INFO - 2018-10-14 15:08:31 --> Language Class Initialized
INFO - 2018-10-14 15:08:31 --> Loader Class Initialized
INFO - 2018-10-14 15:08:31 --> Helper loaded: url_helper
INFO - 2018-10-14 15:08:31 --> Helper loaded: form_helper
INFO - 2018-10-14 15:08:31 --> Helper loaded: language_helper
DEBUG - 2018-10-14 15:08:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-14 15:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-14 15:08:31 --> User Agent Class Initialized
INFO - 2018-10-14 15:08:31 --> Controller Class Initialized
INFO - 2018-10-14 15:08:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-14 15:08:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-14 15:08:31 --> Pixel_Model class loaded
INFO - 2018-10-14 15:08:31 --> Database Driver Class Initialized
INFO - 2018-10-14 15:08:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:08:31 --> Database Driver Class Initialized
INFO - 2018-10-14 15:08:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:08:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-14 15:08:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-14 15:08:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-14 15:08:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-14 15:08:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-14 15:08:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-14 15:08:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-10-14 15:08:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-14 15:08:31 --> Final output sent to browser
DEBUG - 2018-10-14 15:08:31 --> Total execution time: 0.0441
INFO - 2018-10-14 15:08:34 --> Config Class Initialized
INFO - 2018-10-14 15:08:34 --> Hooks Class Initialized
DEBUG - 2018-10-14 15:08:34 --> UTF-8 Support Enabled
INFO - 2018-10-14 15:08:34 --> Utf8 Class Initialized
INFO - 2018-10-14 15:08:34 --> URI Class Initialized
INFO - 2018-10-14 15:08:34 --> Router Class Initialized
INFO - 2018-10-14 15:08:34 --> Output Class Initialized
INFO - 2018-10-14 15:08:34 --> Security Class Initialized
DEBUG - 2018-10-14 15:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-14 15:08:34 --> CSRF cookie sent
INFO - 2018-10-14 15:08:34 --> Input Class Initialized
INFO - 2018-10-14 15:08:34 --> Language Class Initialized
INFO - 2018-10-14 15:08:34 --> Loader Class Initialized
INFO - 2018-10-14 15:08:34 --> Helper loaded: url_helper
INFO - 2018-10-14 15:08:34 --> Helper loaded: form_helper
INFO - 2018-10-14 15:08:34 --> Helper loaded: language_helper
DEBUG - 2018-10-14 15:08:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-14 15:08:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-14 15:08:34 --> User Agent Class Initialized
INFO - 2018-10-14 15:08:34 --> Controller Class Initialized
INFO - 2018-10-14 15:08:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-14 15:08:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-14 15:08:34 --> Pixel_Model class loaded
INFO - 2018-10-14 15:08:34 --> Database Driver Class Initialized
INFO - 2018-10-14 15:08:34 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:08:34 --> Database Driver Class Initialized
INFO - 2018-10-14 15:08:34 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:08:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-14 15:08:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-14 15:08:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-14 15:08:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-14 15:08:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-14 15:08:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-14 15:08:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/marriage.php
INFO - 2018-10-14 15:08:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-14 15:08:34 --> Final output sent to browser
DEBUG - 2018-10-14 15:08:34 --> Total execution time: 0.0522
INFO - 2018-10-14 15:08:41 --> Config Class Initialized
INFO - 2018-10-14 15:08:41 --> Hooks Class Initialized
DEBUG - 2018-10-14 15:08:41 --> UTF-8 Support Enabled
INFO - 2018-10-14 15:08:41 --> Utf8 Class Initialized
INFO - 2018-10-14 15:08:41 --> URI Class Initialized
INFO - 2018-10-14 15:08:41 --> Router Class Initialized
INFO - 2018-10-14 15:08:41 --> Output Class Initialized
INFO - 2018-10-14 15:08:41 --> Security Class Initialized
DEBUG - 2018-10-14 15:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-14 15:08:41 --> CSRF cookie sent
INFO - 2018-10-14 15:08:41 --> CSRF token verified
INFO - 2018-10-14 15:08:41 --> Input Class Initialized
INFO - 2018-10-14 15:08:41 --> Language Class Initialized
INFO - 2018-10-14 15:08:41 --> Loader Class Initialized
INFO - 2018-10-14 15:08:41 --> Helper loaded: url_helper
INFO - 2018-10-14 15:08:41 --> Helper loaded: form_helper
INFO - 2018-10-14 15:08:41 --> Helper loaded: language_helper
DEBUG - 2018-10-14 15:08:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-14 15:08:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-14 15:08:41 --> User Agent Class Initialized
INFO - 2018-10-14 15:08:41 --> Controller Class Initialized
INFO - 2018-10-14 15:08:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-14 15:08:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-14 15:08:41 --> Pixel_Model class loaded
INFO - 2018-10-14 15:08:41 --> Database Driver Class Initialized
INFO - 2018-10-14 15:08:41 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:08:41 --> Form Validation Class Initialized
INFO - 2018-10-14 15:08:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-14 15:08:41 --> Database Driver Class Initialized
INFO - 2018-10-14 15:08:41 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:08:41 --> Config Class Initialized
INFO - 2018-10-14 15:08:41 --> Hooks Class Initialized
DEBUG - 2018-10-14 15:08:41 --> UTF-8 Support Enabled
INFO - 2018-10-14 15:08:41 --> Utf8 Class Initialized
INFO - 2018-10-14 15:08:41 --> URI Class Initialized
INFO - 2018-10-14 15:08:41 --> Router Class Initialized
INFO - 2018-10-14 15:08:41 --> Output Class Initialized
INFO - 2018-10-14 15:08:41 --> Security Class Initialized
DEBUG - 2018-10-14 15:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-14 15:08:41 --> CSRF cookie sent
INFO - 2018-10-14 15:08:41 --> Input Class Initialized
INFO - 2018-10-14 15:08:41 --> Language Class Initialized
INFO - 2018-10-14 15:08:41 --> Loader Class Initialized
INFO - 2018-10-14 15:08:41 --> Helper loaded: url_helper
INFO - 2018-10-14 15:08:41 --> Helper loaded: form_helper
INFO - 2018-10-14 15:08:41 --> Helper loaded: language_helper
DEBUG - 2018-10-14 15:08:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-14 15:08:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-14 15:08:41 --> User Agent Class Initialized
INFO - 2018-10-14 15:08:41 --> Controller Class Initialized
INFO - 2018-10-14 15:08:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-14 15:08:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-14 15:08:41 --> Pixel_Model class loaded
INFO - 2018-10-14 15:08:41 --> Database Driver Class Initialized
INFO - 2018-10-14 15:08:41 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:08:41 --> Database Driver Class Initialized
INFO - 2018-10-14 15:08:41 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:08:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-14 15:08:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-14 15:08:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-14 15:08:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-14 15:08:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-14 15:08:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-14 15:08:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-10-14 15:08:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-14 15:08:41 --> Final output sent to browser
DEBUG - 2018-10-14 15:08:41 --> Total execution time: 0.0521
INFO - 2018-10-14 15:08:52 --> Config Class Initialized
INFO - 2018-10-14 15:08:52 --> Hooks Class Initialized
DEBUG - 2018-10-14 15:08:52 --> UTF-8 Support Enabled
INFO - 2018-10-14 15:08:52 --> Utf8 Class Initialized
INFO - 2018-10-14 15:08:52 --> URI Class Initialized
INFO - 2018-10-14 15:08:52 --> Router Class Initialized
INFO - 2018-10-14 15:08:52 --> Output Class Initialized
INFO - 2018-10-14 15:08:52 --> Security Class Initialized
DEBUG - 2018-10-14 15:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-14 15:08:52 --> CSRF cookie sent
INFO - 2018-10-14 15:08:52 --> Input Class Initialized
INFO - 2018-10-14 15:08:52 --> Language Class Initialized
INFO - 2018-10-14 15:08:52 --> Loader Class Initialized
INFO - 2018-10-14 15:08:52 --> Helper loaded: url_helper
INFO - 2018-10-14 15:08:52 --> Helper loaded: form_helper
INFO - 2018-10-14 15:08:52 --> Helper loaded: language_helper
DEBUG - 2018-10-14 15:08:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-14 15:08:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-14 15:08:52 --> User Agent Class Initialized
INFO - 2018-10-14 15:08:52 --> Controller Class Initialized
INFO - 2018-10-14 15:08:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-14 15:08:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-14 15:08:52 --> Pixel_Model class loaded
INFO - 2018-10-14 15:08:52 --> Database Driver Class Initialized
INFO - 2018-10-14 15:08:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:08:52 --> Database Driver Class Initialized
INFO - 2018-10-14 15:08:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:08:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-14 15:08:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-14 15:08:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-14 15:08:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-14 15:08:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-14 15:08:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-14 15:08:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/marriage.php
INFO - 2018-10-14 15:08:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-14 15:08:52 --> Final output sent to browser
DEBUG - 2018-10-14 15:08:52 --> Total execution time: 0.0546
INFO - 2018-10-14 15:08:53 --> Config Class Initialized
INFO - 2018-10-14 15:08:53 --> Hooks Class Initialized
DEBUG - 2018-10-14 15:08:53 --> UTF-8 Support Enabled
INFO - 2018-10-14 15:08:53 --> Utf8 Class Initialized
INFO - 2018-10-14 15:08:53 --> URI Class Initialized
INFO - 2018-10-14 15:08:53 --> Router Class Initialized
INFO - 2018-10-14 15:08:53 --> Output Class Initialized
INFO - 2018-10-14 15:08:53 --> Security Class Initialized
DEBUG - 2018-10-14 15:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-14 15:08:53 --> CSRF cookie sent
INFO - 2018-10-14 15:08:53 --> Input Class Initialized
INFO - 2018-10-14 15:08:53 --> Language Class Initialized
INFO - 2018-10-14 15:08:53 --> Loader Class Initialized
INFO - 2018-10-14 15:08:53 --> Helper loaded: url_helper
INFO - 2018-10-14 15:08:53 --> Helper loaded: form_helper
INFO - 2018-10-14 15:08:53 --> Helper loaded: language_helper
DEBUG - 2018-10-14 15:08:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-14 15:08:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-14 15:08:53 --> User Agent Class Initialized
INFO - 2018-10-14 15:08:53 --> Controller Class Initialized
INFO - 2018-10-14 15:08:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-14 15:08:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-14 15:08:53 --> Pixel_Model class loaded
INFO - 2018-10-14 15:08:53 --> Database Driver Class Initialized
INFO - 2018-10-14 15:08:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:08:53 --> Database Driver Class Initialized
INFO - 2018-10-14 15:08:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:08:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-14 15:08:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-14 15:08:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-14 15:08:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-14 15:08:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-14 15:08:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-14 15:08:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-14 15:08:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-14 15:08:53 --> Final output sent to browser
DEBUG - 2018-10-14 15:08:53 --> Total execution time: 0.0391
INFO - 2018-10-14 15:09:08 --> Config Class Initialized
INFO - 2018-10-14 15:09:08 --> Hooks Class Initialized
DEBUG - 2018-10-14 15:09:08 --> UTF-8 Support Enabled
INFO - 2018-10-14 15:09:08 --> Utf8 Class Initialized
INFO - 2018-10-14 15:09:08 --> URI Class Initialized
INFO - 2018-10-14 15:09:08 --> Router Class Initialized
INFO - 2018-10-14 15:09:08 --> Output Class Initialized
INFO - 2018-10-14 15:09:08 --> Security Class Initialized
DEBUG - 2018-10-14 15:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-14 15:09:08 --> CSRF cookie sent
INFO - 2018-10-14 15:09:08 --> Input Class Initialized
INFO - 2018-10-14 15:09:08 --> Language Class Initialized
INFO - 2018-10-14 15:09:08 --> Loader Class Initialized
INFO - 2018-10-14 15:09:08 --> Helper loaded: url_helper
INFO - 2018-10-14 15:09:08 --> Helper loaded: form_helper
INFO - 2018-10-14 15:09:08 --> Helper loaded: language_helper
DEBUG - 2018-10-14 15:09:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-14 15:09:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-14 15:09:08 --> User Agent Class Initialized
INFO - 2018-10-14 15:09:08 --> Controller Class Initialized
INFO - 2018-10-14 15:09:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-14 15:09:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-14 15:09:08 --> Pixel_Model class loaded
INFO - 2018-10-14 15:09:08 --> Database Driver Class Initialized
INFO - 2018-10-14 15:09:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:09:08 --> Database Driver Class Initialized
INFO - 2018-10-14 15:09:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:09:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-14 15:09:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-14 15:09:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-14 15:09:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-14 15:09:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-14 15:09:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-14 15:09:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/marriage.php
INFO - 2018-10-14 15:09:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-14 15:09:08 --> Final output sent to browser
DEBUG - 2018-10-14 15:09:08 --> Total execution time: 0.0573
INFO - 2018-10-14 15:09:11 --> Config Class Initialized
INFO - 2018-10-14 15:09:11 --> Hooks Class Initialized
DEBUG - 2018-10-14 15:09:11 --> UTF-8 Support Enabled
INFO - 2018-10-14 15:09:11 --> Utf8 Class Initialized
INFO - 2018-10-14 15:09:11 --> URI Class Initialized
INFO - 2018-10-14 15:09:11 --> Router Class Initialized
INFO - 2018-10-14 15:09:11 --> Output Class Initialized
INFO - 2018-10-14 15:09:11 --> Security Class Initialized
DEBUG - 2018-10-14 15:09:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-14 15:09:11 --> CSRF cookie sent
INFO - 2018-10-14 15:09:11 --> Input Class Initialized
INFO - 2018-10-14 15:09:11 --> Language Class Initialized
INFO - 2018-10-14 15:09:11 --> Loader Class Initialized
INFO - 2018-10-14 15:09:11 --> Helper loaded: url_helper
INFO - 2018-10-14 15:09:11 --> Helper loaded: form_helper
INFO - 2018-10-14 15:09:11 --> Helper loaded: language_helper
DEBUG - 2018-10-14 15:09:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-14 15:09:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-14 15:09:11 --> User Agent Class Initialized
INFO - 2018-10-14 15:09:11 --> Controller Class Initialized
INFO - 2018-10-14 15:09:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-14 15:09:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-14 15:09:11 --> Pixel_Model class loaded
INFO - 2018-10-14 15:09:11 --> Database Driver Class Initialized
INFO - 2018-10-14 15:09:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:09:11 --> Database Driver Class Initialized
INFO - 2018-10-14 15:09:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:09:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-14 15:09:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-14 15:09:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-14 15:09:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-14 15:09:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-14 15:09:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-14 15:09:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-10-14 15:09:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-14 15:09:11 --> Final output sent to browser
DEBUG - 2018-10-14 15:09:11 --> Total execution time: 0.0450
INFO - 2018-10-14 15:11:36 --> Config Class Initialized
INFO - 2018-10-14 15:11:36 --> Hooks Class Initialized
DEBUG - 2018-10-14 15:11:36 --> UTF-8 Support Enabled
INFO - 2018-10-14 15:11:36 --> Utf8 Class Initialized
INFO - 2018-10-14 15:11:36 --> URI Class Initialized
INFO - 2018-10-14 15:11:36 --> Router Class Initialized
INFO - 2018-10-14 15:11:36 --> Output Class Initialized
INFO - 2018-10-14 15:11:36 --> Security Class Initialized
DEBUG - 2018-10-14 15:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-14 15:11:36 --> CSRF cookie sent
INFO - 2018-10-14 15:11:36 --> Input Class Initialized
INFO - 2018-10-14 15:11:36 --> Language Class Initialized
INFO - 2018-10-14 15:11:36 --> Loader Class Initialized
INFO - 2018-10-14 15:11:36 --> Helper loaded: url_helper
INFO - 2018-10-14 15:11:36 --> Helper loaded: form_helper
INFO - 2018-10-14 15:11:36 --> Helper loaded: language_helper
DEBUG - 2018-10-14 15:11:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-14 15:11:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-14 15:11:36 --> User Agent Class Initialized
INFO - 2018-10-14 15:11:36 --> Controller Class Initialized
INFO - 2018-10-14 15:11:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-14 15:11:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-14 15:11:36 --> Pixel_Model class loaded
INFO - 2018-10-14 15:11:36 --> Database Driver Class Initialized
INFO - 2018-10-14 15:11:36 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:11:36 --> Database Driver Class Initialized
INFO - 2018-10-14 15:11:36 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:11:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-14 15:11:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-14 15:11:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-14 15:11:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-14 15:11:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-10-14 15:11:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-14 15:11:36 --> Final output sent to browser
DEBUG - 2018-10-14 15:11:36 --> Total execution time: 0.0600
INFO - 2018-10-14 15:11:40 --> Config Class Initialized
INFO - 2018-10-14 15:11:40 --> Hooks Class Initialized
DEBUG - 2018-10-14 15:11:40 --> UTF-8 Support Enabled
INFO - 2018-10-14 15:11:40 --> Utf8 Class Initialized
INFO - 2018-10-14 15:11:40 --> URI Class Initialized
INFO - 2018-10-14 15:11:40 --> Router Class Initialized
INFO - 2018-10-14 15:11:40 --> Output Class Initialized
INFO - 2018-10-14 15:11:40 --> Security Class Initialized
DEBUG - 2018-10-14 15:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-14 15:11:40 --> CSRF cookie sent
INFO - 2018-10-14 15:11:40 --> Input Class Initialized
INFO - 2018-10-14 15:11:40 --> Language Class Initialized
INFO - 2018-10-14 15:11:40 --> Loader Class Initialized
INFO - 2018-10-14 15:11:40 --> Helper loaded: url_helper
INFO - 2018-10-14 15:11:40 --> Helper loaded: form_helper
INFO - 2018-10-14 15:11:40 --> Helper loaded: language_helper
DEBUG - 2018-10-14 15:11:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-14 15:11:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-14 15:11:40 --> User Agent Class Initialized
INFO - 2018-10-14 15:11:40 --> Controller Class Initialized
INFO - 2018-10-14 15:11:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-14 15:11:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-14 15:11:40 --> Pixel_Model class loaded
INFO - 2018-10-14 15:11:40 --> Database Driver Class Initialized
INFO - 2018-10-14 15:11:40 --> Model "MyAccountModel" initialized
ERROR - 2018-10-14 15:11:40 --> 404 Page Not Found: 
INFO - 2018-10-14 15:11:42 --> Config Class Initialized
INFO - 2018-10-14 15:11:42 --> Hooks Class Initialized
DEBUG - 2018-10-14 15:11:42 --> UTF-8 Support Enabled
INFO - 2018-10-14 15:11:42 --> Utf8 Class Initialized
INFO - 2018-10-14 15:11:42 --> URI Class Initialized
INFO - 2018-10-14 15:11:42 --> Router Class Initialized
INFO - 2018-10-14 15:11:42 --> Output Class Initialized
INFO - 2018-10-14 15:11:42 --> Security Class Initialized
DEBUG - 2018-10-14 15:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-14 15:11:42 --> CSRF cookie sent
INFO - 2018-10-14 15:11:42 --> Input Class Initialized
INFO - 2018-10-14 15:11:42 --> Language Class Initialized
INFO - 2018-10-14 15:11:42 --> Loader Class Initialized
INFO - 2018-10-14 15:11:42 --> Helper loaded: url_helper
INFO - 2018-10-14 15:11:42 --> Helper loaded: form_helper
INFO - 2018-10-14 15:11:42 --> Helper loaded: language_helper
DEBUG - 2018-10-14 15:11:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-14 15:11:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-14 15:11:42 --> User Agent Class Initialized
INFO - 2018-10-14 15:11:42 --> Controller Class Initialized
INFO - 2018-10-14 15:11:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-14 15:11:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-14 15:11:42 --> Pixel_Model class loaded
INFO - 2018-10-14 15:11:42 --> Database Driver Class Initialized
INFO - 2018-10-14 15:11:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:11:42 --> Database Driver Class Initialized
INFO - 2018-10-14 15:11:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:11:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-14 15:11:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-14 15:11:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-14 15:11:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-14 15:11:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-10-14 15:11:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-14 15:11:42 --> Final output sent to browser
DEBUG - 2018-10-14 15:11:42 --> Total execution time: 0.0611
INFO - 2018-10-14 15:11:51 --> Config Class Initialized
INFO - 2018-10-14 15:11:51 --> Hooks Class Initialized
DEBUG - 2018-10-14 15:11:51 --> UTF-8 Support Enabled
INFO - 2018-10-14 15:11:51 --> Utf8 Class Initialized
INFO - 2018-10-14 15:11:51 --> URI Class Initialized
INFO - 2018-10-14 15:11:51 --> Router Class Initialized
INFO - 2018-10-14 15:11:51 --> Output Class Initialized
INFO - 2018-10-14 15:11:51 --> Security Class Initialized
DEBUG - 2018-10-14 15:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-14 15:11:51 --> CSRF cookie sent
INFO - 2018-10-14 15:11:51 --> Input Class Initialized
INFO - 2018-10-14 15:11:51 --> Language Class Initialized
INFO - 2018-10-14 15:11:51 --> Loader Class Initialized
INFO - 2018-10-14 15:11:51 --> Helper loaded: url_helper
INFO - 2018-10-14 15:11:51 --> Helper loaded: form_helper
INFO - 2018-10-14 15:11:51 --> Helper loaded: language_helper
DEBUG - 2018-10-14 15:11:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-14 15:11:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-14 15:11:51 --> User Agent Class Initialized
INFO - 2018-10-14 15:11:51 --> Controller Class Initialized
INFO - 2018-10-14 15:11:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-14 15:11:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-14 15:11:51 --> Pixel_Model class loaded
INFO - 2018-10-14 15:11:51 --> Database Driver Class Initialized
INFO - 2018-10-14 15:11:51 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:11:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-14 15:11:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-14 15:11:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-14 15:11:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-14 15:11:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/contact_us.php
INFO - 2018-10-14 15:11:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-14 15:11:51 --> Final output sent to browser
DEBUG - 2018-10-14 15:11:51 --> Total execution time: 0.0447
INFO - 2018-10-14 15:11:54 --> Config Class Initialized
INFO - 2018-10-14 15:11:54 --> Hooks Class Initialized
DEBUG - 2018-10-14 15:11:54 --> UTF-8 Support Enabled
INFO - 2018-10-14 15:11:54 --> Utf8 Class Initialized
INFO - 2018-10-14 15:11:54 --> URI Class Initialized
INFO - 2018-10-14 15:11:54 --> Router Class Initialized
INFO - 2018-10-14 15:11:54 --> Output Class Initialized
INFO - 2018-10-14 15:11:54 --> Security Class Initialized
DEBUG - 2018-10-14 15:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-14 15:11:54 --> CSRF cookie sent
INFO - 2018-10-14 15:11:54 --> Input Class Initialized
INFO - 2018-10-14 15:11:54 --> Language Class Initialized
INFO - 2018-10-14 15:11:54 --> Loader Class Initialized
INFO - 2018-10-14 15:11:54 --> Helper loaded: url_helper
INFO - 2018-10-14 15:11:54 --> Helper loaded: form_helper
INFO - 2018-10-14 15:11:54 --> Helper loaded: language_helper
DEBUG - 2018-10-14 15:11:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-14 15:11:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-14 15:11:54 --> User Agent Class Initialized
INFO - 2018-10-14 15:11:54 --> Controller Class Initialized
INFO - 2018-10-14 15:11:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-14 15:11:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-14 15:11:54 --> Pixel_Model class loaded
INFO - 2018-10-14 15:11:54 --> Database Driver Class Initialized
INFO - 2018-10-14 15:11:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:11:54 --> Database Driver Class Initialized
INFO - 2018-10-14 15:11:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:11:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-14 15:11:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-14 15:11:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-14 15:11:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-14 15:11:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-10-14 15:11:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-14 15:11:54 --> Final output sent to browser
DEBUG - 2018-10-14 15:11:54 --> Total execution time: 0.0465
INFO - 2018-10-14 15:11:56 --> Config Class Initialized
INFO - 2018-10-14 15:11:56 --> Hooks Class Initialized
DEBUG - 2018-10-14 15:11:56 --> UTF-8 Support Enabled
INFO - 2018-10-14 15:11:56 --> Utf8 Class Initialized
INFO - 2018-10-14 15:11:56 --> URI Class Initialized
INFO - 2018-10-14 15:11:56 --> Router Class Initialized
INFO - 2018-10-14 15:11:56 --> Output Class Initialized
INFO - 2018-10-14 15:11:56 --> Security Class Initialized
DEBUG - 2018-10-14 15:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-14 15:11:56 --> CSRF cookie sent
INFO - 2018-10-14 15:11:56 --> Input Class Initialized
INFO - 2018-10-14 15:11:56 --> Language Class Initialized
INFO - 2018-10-14 15:11:56 --> Loader Class Initialized
INFO - 2018-10-14 15:11:56 --> Helper loaded: url_helper
INFO - 2018-10-14 15:11:56 --> Helper loaded: form_helper
INFO - 2018-10-14 15:11:56 --> Helper loaded: language_helper
DEBUG - 2018-10-14 15:11:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-14 15:11:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-14 15:11:56 --> User Agent Class Initialized
INFO - 2018-10-14 15:11:56 --> Controller Class Initialized
INFO - 2018-10-14 15:11:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-14 15:11:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-14 15:11:56 --> Pixel_Model class loaded
INFO - 2018-10-14 15:11:56 --> Database Driver Class Initialized
INFO - 2018-10-14 15:11:56 --> Model "MyAccountModel" initialized
ERROR - 2018-10-14 15:11:56 --> 404 Page Not Found: 
INFO - 2018-10-14 15:11:58 --> Config Class Initialized
INFO - 2018-10-14 15:11:58 --> Hooks Class Initialized
DEBUG - 2018-10-14 15:11:58 --> UTF-8 Support Enabled
INFO - 2018-10-14 15:11:58 --> Utf8 Class Initialized
INFO - 2018-10-14 15:11:58 --> URI Class Initialized
INFO - 2018-10-14 15:11:58 --> Router Class Initialized
INFO - 2018-10-14 15:11:58 --> Output Class Initialized
INFO - 2018-10-14 15:11:58 --> Security Class Initialized
DEBUG - 2018-10-14 15:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-14 15:11:58 --> CSRF cookie sent
INFO - 2018-10-14 15:11:58 --> Input Class Initialized
INFO - 2018-10-14 15:11:58 --> Language Class Initialized
INFO - 2018-10-14 15:11:58 --> Loader Class Initialized
INFO - 2018-10-14 15:11:58 --> Helper loaded: url_helper
INFO - 2018-10-14 15:11:58 --> Helper loaded: form_helper
INFO - 2018-10-14 15:11:58 --> Helper loaded: language_helper
DEBUG - 2018-10-14 15:11:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-14 15:11:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-14 15:11:58 --> User Agent Class Initialized
INFO - 2018-10-14 15:11:58 --> Controller Class Initialized
INFO - 2018-10-14 15:11:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-14 15:11:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-14 15:11:58 --> Pixel_Model class loaded
INFO - 2018-10-14 15:11:58 --> Database Driver Class Initialized
INFO - 2018-10-14 15:11:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:11:58 --> Database Driver Class Initialized
INFO - 2018-10-14 15:11:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:11:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-14 15:11:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-14 15:11:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-14 15:11:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-14 15:11:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-10-14 15:11:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-14 15:11:58 --> Final output sent to browser
DEBUG - 2018-10-14 15:11:58 --> Total execution time: 0.0463
INFO - 2018-10-14 15:12:09 --> Config Class Initialized
INFO - 2018-10-14 15:12:09 --> Hooks Class Initialized
DEBUG - 2018-10-14 15:12:09 --> UTF-8 Support Enabled
INFO - 2018-10-14 15:12:09 --> Utf8 Class Initialized
INFO - 2018-10-14 15:12:09 --> URI Class Initialized
INFO - 2018-10-14 15:12:09 --> Router Class Initialized
INFO - 2018-10-14 15:12:09 --> Output Class Initialized
INFO - 2018-10-14 15:12:09 --> Security Class Initialized
DEBUG - 2018-10-14 15:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-14 15:12:09 --> CSRF cookie sent
INFO - 2018-10-14 15:12:09 --> Input Class Initialized
INFO - 2018-10-14 15:12:09 --> Language Class Initialized
INFO - 2018-10-14 15:12:09 --> Loader Class Initialized
INFO - 2018-10-14 15:12:09 --> Helper loaded: url_helper
INFO - 2018-10-14 15:12:09 --> Helper loaded: form_helper
INFO - 2018-10-14 15:12:09 --> Helper loaded: language_helper
DEBUG - 2018-10-14 15:12:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-14 15:12:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-14 15:12:09 --> User Agent Class Initialized
INFO - 2018-10-14 15:12:09 --> Controller Class Initialized
INFO - 2018-10-14 15:12:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-14 15:12:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-14 15:12:09 --> Pixel_Model class loaded
INFO - 2018-10-14 15:12:09 --> Database Driver Class Initialized
INFO - 2018-10-14 15:12:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:12:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-14 15:12:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-14 15:12:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-14 15:12:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-14 15:12:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/contact_us.php
INFO - 2018-10-14 15:12:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-14 15:12:09 --> Final output sent to browser
DEBUG - 2018-10-14 15:12:09 --> Total execution time: 0.0426
INFO - 2018-10-14 15:12:11 --> Config Class Initialized
INFO - 2018-10-14 15:12:11 --> Hooks Class Initialized
DEBUG - 2018-10-14 15:12:11 --> UTF-8 Support Enabled
INFO - 2018-10-14 15:12:11 --> Utf8 Class Initialized
INFO - 2018-10-14 15:12:11 --> URI Class Initialized
INFO - 2018-10-14 15:12:11 --> Router Class Initialized
INFO - 2018-10-14 15:12:11 --> Output Class Initialized
INFO - 2018-10-14 15:12:11 --> Security Class Initialized
DEBUG - 2018-10-14 15:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-14 15:12:11 --> CSRF cookie sent
INFO - 2018-10-14 15:12:11 --> Input Class Initialized
INFO - 2018-10-14 15:12:11 --> Language Class Initialized
INFO - 2018-10-14 15:12:11 --> Loader Class Initialized
INFO - 2018-10-14 15:12:11 --> Helper loaded: url_helper
INFO - 2018-10-14 15:12:11 --> Helper loaded: form_helper
INFO - 2018-10-14 15:12:11 --> Helper loaded: language_helper
DEBUG - 2018-10-14 15:12:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-14 15:12:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-14 15:12:11 --> User Agent Class Initialized
INFO - 2018-10-14 15:12:11 --> Controller Class Initialized
INFO - 2018-10-14 15:12:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-14 15:12:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-14 15:12:11 --> Pixel_Model class loaded
INFO - 2018-10-14 15:12:11 --> Database Driver Class Initialized
INFO - 2018-10-14 15:12:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:12:11 --> Database Driver Class Initialized
INFO - 2018-10-14 15:12:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:12:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-14 15:12:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-14 15:12:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-14 15:12:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-14 15:12:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-10-14 15:12:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-14 15:12:11 --> Final output sent to browser
DEBUG - 2018-10-14 15:12:11 --> Total execution time: 0.0518
INFO - 2018-10-14 15:12:52 --> Config Class Initialized
INFO - 2018-10-14 15:12:52 --> Hooks Class Initialized
DEBUG - 2018-10-14 15:12:52 --> UTF-8 Support Enabled
INFO - 2018-10-14 15:12:52 --> Utf8 Class Initialized
INFO - 2018-10-14 15:12:52 --> URI Class Initialized
INFO - 2018-10-14 15:12:52 --> Router Class Initialized
INFO - 2018-10-14 15:12:52 --> Output Class Initialized
INFO - 2018-10-14 15:12:52 --> Security Class Initialized
DEBUG - 2018-10-14 15:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-14 15:12:52 --> CSRF cookie sent
INFO - 2018-10-14 15:12:52 --> Input Class Initialized
INFO - 2018-10-14 15:12:52 --> Language Class Initialized
INFO - 2018-10-14 15:12:52 --> Loader Class Initialized
INFO - 2018-10-14 15:12:52 --> Helper loaded: url_helper
INFO - 2018-10-14 15:12:52 --> Helper loaded: form_helper
INFO - 2018-10-14 15:12:52 --> Helper loaded: language_helper
DEBUG - 2018-10-14 15:12:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-14 15:12:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-14 15:12:52 --> User Agent Class Initialized
INFO - 2018-10-14 15:12:52 --> Controller Class Initialized
INFO - 2018-10-14 15:12:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-14 15:12:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-14 15:12:52 --> Pixel_Model class loaded
INFO - 2018-10-14 15:12:52 --> Database Driver Class Initialized
INFO - 2018-10-14 15:12:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-14 15:12:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-14 15:12:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-14 15:12:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-14 15:12:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-14 15:12:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/contact_us.php
INFO - 2018-10-14 15:12:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-14 15:12:52 --> Final output sent to browser
DEBUG - 2018-10-14 15:12:52 --> Total execution time: 0.0441

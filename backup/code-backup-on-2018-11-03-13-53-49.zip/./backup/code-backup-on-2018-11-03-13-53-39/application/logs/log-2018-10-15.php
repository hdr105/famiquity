<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-10-15 12:41:06 --> Config Class Initialized
INFO - 2018-10-15 12:41:06 --> Hooks Class Initialized
DEBUG - 2018-10-15 12:41:06 --> UTF-8 Support Enabled
INFO - 2018-10-15 12:41:06 --> Utf8 Class Initialized
INFO - 2018-10-15 12:41:06 --> URI Class Initialized
DEBUG - 2018-10-15 12:41:06 --> No URI present. Default controller set.
INFO - 2018-10-15 12:41:06 --> Router Class Initialized
INFO - 2018-10-15 12:41:06 --> Output Class Initialized
INFO - 2018-10-15 12:41:06 --> Security Class Initialized
DEBUG - 2018-10-15 12:41:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-15 12:41:06 --> CSRF cookie sent
INFO - 2018-10-15 12:41:06 --> Input Class Initialized
INFO - 2018-10-15 12:41:06 --> Language Class Initialized
INFO - 2018-10-15 12:41:06 --> Loader Class Initialized
INFO - 2018-10-15 12:41:06 --> Helper loaded: url_helper
INFO - 2018-10-15 12:41:06 --> Helper loaded: form_helper
INFO - 2018-10-15 12:41:06 --> Helper loaded: language_helper
DEBUG - 2018-10-15 12:41:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-15 12:41:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-15 12:41:06 --> User Agent Class Initialized
INFO - 2018-10-15 12:41:06 --> Controller Class Initialized
INFO - 2018-10-15 12:41:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-15 12:41:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-15 12:41:06 --> Pixel_Model class loaded
INFO - 2018-10-15 12:41:06 --> Database Driver Class Initialized
INFO - 2018-10-15 12:41:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 12:41:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-15 12:41:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-15 12:41:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-15 12:41:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-15 12:41:06 --> Final output sent to browser
DEBUG - 2018-10-15 12:41:06 --> Total execution time: 0.0350
INFO - 2018-10-15 12:41:11 --> Config Class Initialized
INFO - 2018-10-15 12:41:11 --> Hooks Class Initialized
DEBUG - 2018-10-15 12:41:11 --> UTF-8 Support Enabled
INFO - 2018-10-15 12:41:11 --> Utf8 Class Initialized
INFO - 2018-10-15 12:41:11 --> URI Class Initialized
INFO - 2018-10-15 12:41:11 --> Router Class Initialized
INFO - 2018-10-15 12:41:11 --> Output Class Initialized
INFO - 2018-10-15 12:41:11 --> Security Class Initialized
DEBUG - 2018-10-15 12:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-15 12:41:11 --> CSRF cookie sent
INFO - 2018-10-15 12:41:11 --> CSRF token verified
INFO - 2018-10-15 12:41:11 --> Input Class Initialized
INFO - 2018-10-15 12:41:11 --> Language Class Initialized
INFO - 2018-10-15 12:41:11 --> Loader Class Initialized
INFO - 2018-10-15 12:41:11 --> Helper loaded: url_helper
INFO - 2018-10-15 12:41:11 --> Helper loaded: form_helper
INFO - 2018-10-15 12:41:11 --> Helper loaded: language_helper
DEBUG - 2018-10-15 12:41:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-15 12:41:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-15 12:41:11 --> User Agent Class Initialized
INFO - 2018-10-15 12:41:11 --> Controller Class Initialized
INFO - 2018-10-15 12:41:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-15 12:41:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-15 12:41:11 --> Pixel_Model class loaded
INFO - 2018-10-15 12:41:11 --> Database Driver Class Initialized
INFO - 2018-10-15 12:41:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 12:41:11 --> Form Validation Class Initialized
INFO - 2018-10-15 12:41:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-15 12:41:11 --> Database Driver Class Initialized
INFO - 2018-10-15 12:41:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 12:41:11 --> Config Class Initialized
INFO - 2018-10-15 12:41:11 --> Hooks Class Initialized
DEBUG - 2018-10-15 12:41:11 --> UTF-8 Support Enabled
INFO - 2018-10-15 12:41:11 --> Utf8 Class Initialized
INFO - 2018-10-15 12:41:11 --> URI Class Initialized
INFO - 2018-10-15 12:41:11 --> Router Class Initialized
INFO - 2018-10-15 12:41:11 --> Output Class Initialized
INFO - 2018-10-15 12:41:11 --> Security Class Initialized
DEBUG - 2018-10-15 12:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-15 12:41:11 --> CSRF cookie sent
INFO - 2018-10-15 12:41:11 --> Input Class Initialized
INFO - 2018-10-15 12:41:11 --> Language Class Initialized
INFO - 2018-10-15 12:41:11 --> Loader Class Initialized
INFO - 2018-10-15 12:41:11 --> Helper loaded: url_helper
INFO - 2018-10-15 12:41:11 --> Helper loaded: form_helper
INFO - 2018-10-15 12:41:11 --> Helper loaded: language_helper
DEBUG - 2018-10-15 12:41:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-15 12:41:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-15 12:41:11 --> User Agent Class Initialized
INFO - 2018-10-15 12:41:11 --> Controller Class Initialized
INFO - 2018-10-15 12:41:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-15 12:41:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-15 12:41:11 --> Pixel_Model class loaded
INFO - 2018-10-15 12:41:11 --> Database Driver Class Initialized
INFO - 2018-10-15 12:41:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 12:41:11 --> Database Driver Class Initialized
INFO - 2018-10-15 12:41:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 12:41:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-15 12:41:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-15 12:41:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-15 12:41:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-15 12:41:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-15 12:41:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-15 12:41:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-15 12:41:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-15 12:41:11 --> Final output sent to browser
DEBUG - 2018-10-15 12:41:11 --> Total execution time: 0.0480
INFO - 2018-10-15 12:41:28 --> Config Class Initialized
INFO - 2018-10-15 12:41:28 --> Hooks Class Initialized
DEBUG - 2018-10-15 12:41:28 --> UTF-8 Support Enabled
INFO - 2018-10-15 12:41:28 --> Utf8 Class Initialized
INFO - 2018-10-15 12:41:28 --> URI Class Initialized
INFO - 2018-10-15 12:41:28 --> Router Class Initialized
INFO - 2018-10-15 12:41:28 --> Output Class Initialized
INFO - 2018-10-15 12:41:28 --> Security Class Initialized
DEBUG - 2018-10-15 12:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-15 12:41:28 --> CSRF cookie sent
INFO - 2018-10-15 12:41:28 --> CSRF token verified
INFO - 2018-10-15 12:41:28 --> Input Class Initialized
INFO - 2018-10-15 12:41:28 --> Language Class Initialized
INFO - 2018-10-15 12:41:28 --> Loader Class Initialized
INFO - 2018-10-15 12:41:28 --> Helper loaded: url_helper
INFO - 2018-10-15 12:41:28 --> Helper loaded: form_helper
INFO - 2018-10-15 12:41:28 --> Helper loaded: language_helper
DEBUG - 2018-10-15 12:41:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-15 12:41:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-15 12:41:28 --> User Agent Class Initialized
INFO - 2018-10-15 12:41:28 --> Controller Class Initialized
INFO - 2018-10-15 12:41:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-15 12:41:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-15 12:41:28 --> Pixel_Model class loaded
INFO - 2018-10-15 12:41:28 --> Database Driver Class Initialized
INFO - 2018-10-15 12:41:28 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 12:41:28 --> Form Validation Class Initialized
INFO - 2018-10-15 12:41:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-15 12:41:28 --> Database Driver Class Initialized
INFO - 2018-10-15 12:41:28 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 12:41:28 --> Config Class Initialized
INFO - 2018-10-15 12:41:28 --> Hooks Class Initialized
DEBUG - 2018-10-15 12:41:28 --> UTF-8 Support Enabled
INFO - 2018-10-15 12:41:28 --> Utf8 Class Initialized
INFO - 2018-10-15 12:41:28 --> URI Class Initialized
INFO - 2018-10-15 12:41:28 --> Router Class Initialized
INFO - 2018-10-15 12:41:28 --> Output Class Initialized
INFO - 2018-10-15 12:41:28 --> Security Class Initialized
DEBUG - 2018-10-15 12:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-15 12:41:28 --> CSRF cookie sent
INFO - 2018-10-15 12:41:28 --> Input Class Initialized
INFO - 2018-10-15 12:41:28 --> Language Class Initialized
INFO - 2018-10-15 12:41:28 --> Loader Class Initialized
INFO - 2018-10-15 12:41:28 --> Helper loaded: url_helper
INFO - 2018-10-15 12:41:28 --> Helper loaded: form_helper
INFO - 2018-10-15 12:41:28 --> Helper loaded: language_helper
DEBUG - 2018-10-15 12:41:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-15 12:41:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-15 12:41:28 --> User Agent Class Initialized
INFO - 2018-10-15 12:41:28 --> Controller Class Initialized
INFO - 2018-10-15 12:41:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-15 12:41:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-15 12:41:28 --> Pixel_Model class loaded
INFO - 2018-10-15 12:41:28 --> Database Driver Class Initialized
INFO - 2018-10-15 12:41:28 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 12:41:28 --> Database Driver Class Initialized
INFO - 2018-10-15 12:41:28 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 12:41:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-15 12:41:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-15 12:41:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-15 12:41:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-15 12:41:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-15 12:41:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-15 12:41:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-10-15 12:41:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-15 12:41:28 --> Final output sent to browser
DEBUG - 2018-10-15 12:41:28 --> Total execution time: 0.0463
INFO - 2018-10-15 12:41:33 --> Config Class Initialized
INFO - 2018-10-15 12:41:33 --> Hooks Class Initialized
DEBUG - 2018-10-15 12:41:33 --> UTF-8 Support Enabled
INFO - 2018-10-15 12:41:33 --> Utf8 Class Initialized
INFO - 2018-10-15 12:41:33 --> URI Class Initialized
INFO - 2018-10-15 12:41:33 --> Router Class Initialized
INFO - 2018-10-15 12:41:33 --> Output Class Initialized
INFO - 2018-10-15 12:41:33 --> Security Class Initialized
DEBUG - 2018-10-15 12:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-15 12:41:33 --> CSRF cookie sent
INFO - 2018-10-15 12:41:33 --> Input Class Initialized
INFO - 2018-10-15 12:41:33 --> Language Class Initialized
INFO - 2018-10-15 12:41:33 --> Loader Class Initialized
INFO - 2018-10-15 12:41:33 --> Helper loaded: url_helper
INFO - 2018-10-15 12:41:33 --> Helper loaded: form_helper
INFO - 2018-10-15 12:41:33 --> Helper loaded: language_helper
DEBUG - 2018-10-15 12:41:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-15 12:41:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-15 12:41:33 --> User Agent Class Initialized
INFO - 2018-10-15 12:41:33 --> Controller Class Initialized
INFO - 2018-10-15 12:41:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-15 12:41:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-15 12:41:33 --> Pixel_Model class loaded
INFO - 2018-10-15 12:41:33 --> Database Driver Class Initialized
INFO - 2018-10-15 12:41:33 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 12:41:33 --> Database Driver Class Initialized
INFO - 2018-10-15 12:41:33 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 12:41:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-15 12:41:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-15 12:41:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-15 12:41:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-15 12:41:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-15 12:41:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-15 12:41:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-15 12:41:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-15 12:41:33 --> Final output sent to browser
DEBUG - 2018-10-15 12:41:33 --> Total execution time: 0.0458
INFO - 2018-10-15 14:38:38 --> Config Class Initialized
INFO - 2018-10-15 14:38:38 --> Hooks Class Initialized
DEBUG - 2018-10-15 14:38:38 --> UTF-8 Support Enabled
INFO - 2018-10-15 14:38:38 --> Utf8 Class Initialized
INFO - 2018-10-15 14:38:38 --> URI Class Initialized
DEBUG - 2018-10-15 14:38:38 --> No URI present. Default controller set.
INFO - 2018-10-15 14:38:38 --> Router Class Initialized
INFO - 2018-10-15 14:38:38 --> Output Class Initialized
INFO - 2018-10-15 14:38:38 --> Security Class Initialized
DEBUG - 2018-10-15 14:38:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-15 14:38:38 --> CSRF cookie sent
INFO - 2018-10-15 14:38:38 --> Input Class Initialized
INFO - 2018-10-15 14:38:38 --> Language Class Initialized
INFO - 2018-10-15 14:38:38 --> Loader Class Initialized
INFO - 2018-10-15 14:38:38 --> Helper loaded: url_helper
INFO - 2018-10-15 14:38:38 --> Helper loaded: form_helper
INFO - 2018-10-15 14:38:38 --> Helper loaded: language_helper
DEBUG - 2018-10-15 14:38:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-15 14:38:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-15 14:38:38 --> User Agent Class Initialized
INFO - 2018-10-15 14:38:38 --> Controller Class Initialized
INFO - 2018-10-15 14:38:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-15 14:38:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-15 14:38:38 --> Pixel_Model class loaded
INFO - 2018-10-15 14:38:38 --> Database Driver Class Initialized
INFO - 2018-10-15 14:38:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 14:38:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-15 14:38:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-15 14:38:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-15 14:38:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-15 14:38:38 --> Final output sent to browser
DEBUG - 2018-10-15 14:38:38 --> Total execution time: 0.0345
INFO - 2018-10-15 14:38:39 --> Config Class Initialized
INFO - 2018-10-15 14:38:39 --> Hooks Class Initialized
DEBUG - 2018-10-15 14:38:39 --> UTF-8 Support Enabled
INFO - 2018-10-15 14:38:39 --> Utf8 Class Initialized
INFO - 2018-10-15 14:38:39 --> URI Class Initialized
DEBUG - 2018-10-15 14:38:39 --> No URI present. Default controller set.
INFO - 2018-10-15 14:38:39 --> Router Class Initialized
INFO - 2018-10-15 14:38:39 --> Output Class Initialized
INFO - 2018-10-15 14:38:39 --> Security Class Initialized
DEBUG - 2018-10-15 14:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-15 14:38:39 --> CSRF cookie sent
INFO - 2018-10-15 14:38:39 --> Input Class Initialized
INFO - 2018-10-15 14:38:39 --> Language Class Initialized
INFO - 2018-10-15 14:38:39 --> Loader Class Initialized
INFO - 2018-10-15 14:38:39 --> Helper loaded: url_helper
INFO - 2018-10-15 14:38:39 --> Helper loaded: form_helper
INFO - 2018-10-15 14:38:39 --> Helper loaded: language_helper
DEBUG - 2018-10-15 14:38:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-15 14:38:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-15 14:38:39 --> User Agent Class Initialized
INFO - 2018-10-15 14:38:39 --> Controller Class Initialized
INFO - 2018-10-15 14:38:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-15 14:38:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-15 14:38:39 --> Pixel_Model class loaded
INFO - 2018-10-15 14:38:39 --> Database Driver Class Initialized
INFO - 2018-10-15 14:38:39 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 14:38:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-15 14:38:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-15 14:38:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-15 14:38:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-15 14:38:39 --> Final output sent to browser
DEBUG - 2018-10-15 14:38:39 --> Total execution time: 0.0428
INFO - 2018-10-15 14:38:44 --> Config Class Initialized
INFO - 2018-10-15 14:38:44 --> Hooks Class Initialized
DEBUG - 2018-10-15 14:38:44 --> UTF-8 Support Enabled
INFO - 2018-10-15 14:38:44 --> Utf8 Class Initialized
INFO - 2018-10-15 14:38:44 --> URI Class Initialized
INFO - 2018-10-15 14:38:44 --> Router Class Initialized
INFO - 2018-10-15 14:38:44 --> Output Class Initialized
INFO - 2018-10-15 14:38:44 --> Security Class Initialized
DEBUG - 2018-10-15 14:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-15 14:38:44 --> CSRF cookie sent
INFO - 2018-10-15 14:38:44 --> Input Class Initialized
INFO - 2018-10-15 14:38:44 --> Language Class Initialized
INFO - 2018-10-15 14:38:44 --> Loader Class Initialized
INFO - 2018-10-15 14:38:44 --> Helper loaded: url_helper
INFO - 2018-10-15 14:38:44 --> Helper loaded: form_helper
INFO - 2018-10-15 14:38:44 --> Helper loaded: language_helper
DEBUG - 2018-10-15 14:38:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-15 14:38:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-15 14:38:44 --> User Agent Class Initialized
INFO - 2018-10-15 14:38:44 --> Controller Class Initialized
INFO - 2018-10-15 14:38:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-15 14:38:44 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-15 14:38:44 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-10-15 14:38:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-15 14:38:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-15 14:38:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-15 14:38:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-10-15 14:38:44 --> Could not find the language line "req_email"
INFO - 2018-10-15 14:38:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-10-15 14:38:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-15 14:38:44 --> Final output sent to browser
DEBUG - 2018-10-15 14:38:44 --> Total execution time: 0.0265
INFO - 2018-10-15 14:38:51 --> Config Class Initialized
INFO - 2018-10-15 14:38:51 --> Hooks Class Initialized
DEBUG - 2018-10-15 14:38:51 --> UTF-8 Support Enabled
INFO - 2018-10-15 14:38:51 --> Utf8 Class Initialized
INFO - 2018-10-15 14:38:51 --> URI Class Initialized
DEBUG - 2018-10-15 14:38:51 --> No URI present. Default controller set.
INFO - 2018-10-15 14:38:51 --> Router Class Initialized
INFO - 2018-10-15 14:38:51 --> Output Class Initialized
INFO - 2018-10-15 14:38:51 --> Security Class Initialized
DEBUG - 2018-10-15 14:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-15 14:38:51 --> CSRF cookie sent
INFO - 2018-10-15 14:38:51 --> Input Class Initialized
INFO - 2018-10-15 14:38:51 --> Language Class Initialized
INFO - 2018-10-15 14:38:51 --> Loader Class Initialized
INFO - 2018-10-15 14:38:51 --> Helper loaded: url_helper
INFO - 2018-10-15 14:38:51 --> Helper loaded: form_helper
INFO - 2018-10-15 14:38:51 --> Helper loaded: language_helper
DEBUG - 2018-10-15 14:38:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-15 14:38:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-15 14:38:51 --> User Agent Class Initialized
INFO - 2018-10-15 14:38:51 --> Controller Class Initialized
INFO - 2018-10-15 14:38:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-15 14:38:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-15 14:38:51 --> Pixel_Model class loaded
INFO - 2018-10-15 14:38:51 --> Database Driver Class Initialized
INFO - 2018-10-15 14:38:51 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 14:38:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-15 14:38:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-15 14:38:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-15 14:38:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-15 14:38:51 --> Final output sent to browser
DEBUG - 2018-10-15 14:38:51 --> Total execution time: 0.0358
INFO - 2018-10-15 14:38:59 --> Config Class Initialized
INFO - 2018-10-15 14:38:59 --> Hooks Class Initialized
DEBUG - 2018-10-15 14:38:59 --> UTF-8 Support Enabled
INFO - 2018-10-15 14:38:59 --> Utf8 Class Initialized
INFO - 2018-10-15 14:38:59 --> URI Class Initialized
INFO - 2018-10-15 14:38:59 --> Router Class Initialized
INFO - 2018-10-15 14:38:59 --> Output Class Initialized
INFO - 2018-10-15 14:38:59 --> Security Class Initialized
DEBUG - 2018-10-15 14:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-15 14:38:59 --> CSRF cookie sent
INFO - 2018-10-15 14:38:59 --> CSRF token verified
INFO - 2018-10-15 14:38:59 --> Input Class Initialized
INFO - 2018-10-15 14:38:59 --> Language Class Initialized
INFO - 2018-10-15 14:38:59 --> Loader Class Initialized
INFO - 2018-10-15 14:38:59 --> Helper loaded: url_helper
INFO - 2018-10-15 14:38:59 --> Helper loaded: form_helper
INFO - 2018-10-15 14:38:59 --> Helper loaded: language_helper
DEBUG - 2018-10-15 14:38:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-15 14:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-15 14:38:59 --> User Agent Class Initialized
INFO - 2018-10-15 14:38:59 --> Controller Class Initialized
INFO - 2018-10-15 14:38:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-15 14:38:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-15 14:38:59 --> Pixel_Model class loaded
INFO - 2018-10-15 14:38:59 --> Database Driver Class Initialized
INFO - 2018-10-15 14:38:59 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 14:38:59 --> Form Validation Class Initialized
INFO - 2018-10-15 14:38:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-15 14:38:59 --> Database Driver Class Initialized
INFO - 2018-10-15 14:38:59 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 14:38:59 --> Config Class Initialized
INFO - 2018-10-15 14:38:59 --> Hooks Class Initialized
DEBUG - 2018-10-15 14:38:59 --> UTF-8 Support Enabled
INFO - 2018-10-15 14:38:59 --> Utf8 Class Initialized
INFO - 2018-10-15 14:38:59 --> URI Class Initialized
INFO - 2018-10-15 14:38:59 --> Router Class Initialized
INFO - 2018-10-15 14:38:59 --> Output Class Initialized
INFO - 2018-10-15 14:38:59 --> Security Class Initialized
DEBUG - 2018-10-15 14:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-15 14:38:59 --> CSRF cookie sent
INFO - 2018-10-15 14:38:59 --> Input Class Initialized
INFO - 2018-10-15 14:38:59 --> Language Class Initialized
INFO - 2018-10-15 14:38:59 --> Loader Class Initialized
INFO - 2018-10-15 14:38:59 --> Helper loaded: url_helper
INFO - 2018-10-15 14:38:59 --> Helper loaded: form_helper
INFO - 2018-10-15 14:38:59 --> Helper loaded: language_helper
DEBUG - 2018-10-15 14:38:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-15 14:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-15 14:38:59 --> User Agent Class Initialized
INFO - 2018-10-15 14:38:59 --> Controller Class Initialized
INFO - 2018-10-15 14:38:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-15 14:38:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-15 14:38:59 --> Pixel_Model class loaded
INFO - 2018-10-15 14:38:59 --> Database Driver Class Initialized
INFO - 2018-10-15 14:38:59 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 14:38:59 --> Database Driver Class Initialized
INFO - 2018-10-15 14:38:59 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 14:38:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-15 14:38:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-15 14:38:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-15 14:38:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-15 14:38:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-15 14:38:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-15 14:38:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-15 14:38:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-15 14:38:59 --> Final output sent to browser
DEBUG - 2018-10-15 14:38:59 --> Total execution time: 0.0482
INFO - 2018-10-15 15:39:34 --> Config Class Initialized
INFO - 2018-10-15 15:39:34 --> Hooks Class Initialized
DEBUG - 2018-10-15 15:39:34 --> UTF-8 Support Enabled
INFO - 2018-10-15 15:39:34 --> Utf8 Class Initialized
INFO - 2018-10-15 15:39:34 --> URI Class Initialized
DEBUG - 2018-10-15 15:39:34 --> No URI present. Default controller set.
INFO - 2018-10-15 15:39:34 --> Router Class Initialized
INFO - 2018-10-15 15:39:34 --> Output Class Initialized
INFO - 2018-10-15 15:39:34 --> Security Class Initialized
DEBUG - 2018-10-15 15:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-15 15:39:34 --> CSRF cookie sent
INFO - 2018-10-15 15:39:34 --> Input Class Initialized
INFO - 2018-10-15 15:39:34 --> Language Class Initialized
INFO - 2018-10-15 15:39:34 --> Loader Class Initialized
INFO - 2018-10-15 15:39:34 --> Helper loaded: url_helper
INFO - 2018-10-15 15:39:34 --> Helper loaded: form_helper
INFO - 2018-10-15 15:39:34 --> Helper loaded: language_helper
DEBUG - 2018-10-15 15:39:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-15 15:39:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-15 15:39:34 --> User Agent Class Initialized
INFO - 2018-10-15 15:39:34 --> Controller Class Initialized
INFO - 2018-10-15 15:39:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-15 15:39:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-15 15:39:34 --> Pixel_Model class loaded
INFO - 2018-10-15 15:39:34 --> Database Driver Class Initialized
INFO - 2018-10-15 15:39:34 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:39:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-15 15:39:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-15 15:39:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-15 15:39:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-15 15:39:34 --> Final output sent to browser
DEBUG - 2018-10-15 15:39:34 --> Total execution time: 0.0402
INFO - 2018-10-15 15:39:34 --> Config Class Initialized
INFO - 2018-10-15 15:39:34 --> Hooks Class Initialized
DEBUG - 2018-10-15 15:39:34 --> UTF-8 Support Enabled
INFO - 2018-10-15 15:39:34 --> Utf8 Class Initialized
INFO - 2018-10-15 15:39:34 --> URI Class Initialized
DEBUG - 2018-10-15 15:39:34 --> No URI present. Default controller set.
INFO - 2018-10-15 15:39:34 --> Router Class Initialized
INFO - 2018-10-15 15:39:34 --> Output Class Initialized
INFO - 2018-10-15 15:39:34 --> Security Class Initialized
DEBUG - 2018-10-15 15:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-15 15:39:34 --> CSRF cookie sent
INFO - 2018-10-15 15:39:34 --> Input Class Initialized
INFO - 2018-10-15 15:39:34 --> Language Class Initialized
INFO - 2018-10-15 15:39:34 --> Loader Class Initialized
INFO - 2018-10-15 15:39:34 --> Helper loaded: url_helper
INFO - 2018-10-15 15:39:34 --> Helper loaded: form_helper
INFO - 2018-10-15 15:39:34 --> Helper loaded: language_helper
DEBUG - 2018-10-15 15:39:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-15 15:39:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-15 15:39:34 --> User Agent Class Initialized
INFO - 2018-10-15 15:39:34 --> Controller Class Initialized
INFO - 2018-10-15 15:39:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-15 15:39:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-15 15:39:34 --> Pixel_Model class loaded
INFO - 2018-10-15 15:39:34 --> Database Driver Class Initialized
INFO - 2018-10-15 15:39:34 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:39:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-15 15:39:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-15 15:39:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-15 15:39:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-15 15:39:34 --> Final output sent to browser
DEBUG - 2018-10-15 15:39:34 --> Total execution time: 0.0352
INFO - 2018-10-15 15:39:38 --> Config Class Initialized
INFO - 2018-10-15 15:39:38 --> Hooks Class Initialized
DEBUG - 2018-10-15 15:39:38 --> UTF-8 Support Enabled
INFO - 2018-10-15 15:39:38 --> Utf8 Class Initialized
INFO - 2018-10-15 15:39:38 --> URI Class Initialized
INFO - 2018-10-15 15:39:38 --> Router Class Initialized
INFO - 2018-10-15 15:39:38 --> Output Class Initialized
INFO - 2018-10-15 15:39:38 --> Security Class Initialized
DEBUG - 2018-10-15 15:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-15 15:39:38 --> CSRF cookie sent
INFO - 2018-10-15 15:39:38 --> CSRF token verified
INFO - 2018-10-15 15:39:38 --> Input Class Initialized
INFO - 2018-10-15 15:39:38 --> Language Class Initialized
INFO - 2018-10-15 15:39:38 --> Loader Class Initialized
INFO - 2018-10-15 15:39:38 --> Helper loaded: url_helper
INFO - 2018-10-15 15:39:38 --> Helper loaded: form_helper
INFO - 2018-10-15 15:39:38 --> Helper loaded: language_helper
DEBUG - 2018-10-15 15:39:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-15 15:39:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-15 15:39:38 --> User Agent Class Initialized
INFO - 2018-10-15 15:39:38 --> Controller Class Initialized
INFO - 2018-10-15 15:39:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-15 15:39:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-15 15:39:38 --> Pixel_Model class loaded
INFO - 2018-10-15 15:39:38 --> Database Driver Class Initialized
INFO - 2018-10-15 15:39:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:39:38 --> Form Validation Class Initialized
INFO - 2018-10-15 15:39:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-15 15:39:38 --> Database Driver Class Initialized
INFO - 2018-10-15 15:39:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:39:38 --> Config Class Initialized
INFO - 2018-10-15 15:39:38 --> Hooks Class Initialized
DEBUG - 2018-10-15 15:39:38 --> UTF-8 Support Enabled
INFO - 2018-10-15 15:39:38 --> Utf8 Class Initialized
INFO - 2018-10-15 15:39:38 --> URI Class Initialized
INFO - 2018-10-15 15:39:38 --> Router Class Initialized
INFO - 2018-10-15 15:39:38 --> Output Class Initialized
INFO - 2018-10-15 15:39:38 --> Security Class Initialized
DEBUG - 2018-10-15 15:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-15 15:39:38 --> CSRF cookie sent
INFO - 2018-10-15 15:39:38 --> Input Class Initialized
INFO - 2018-10-15 15:39:38 --> Language Class Initialized
INFO - 2018-10-15 15:39:38 --> Loader Class Initialized
INFO - 2018-10-15 15:39:38 --> Helper loaded: url_helper
INFO - 2018-10-15 15:39:38 --> Helper loaded: form_helper
INFO - 2018-10-15 15:39:38 --> Helper loaded: language_helper
DEBUG - 2018-10-15 15:39:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-15 15:39:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-15 15:39:38 --> User Agent Class Initialized
INFO - 2018-10-15 15:39:38 --> Controller Class Initialized
INFO - 2018-10-15 15:39:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-15 15:39:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-15 15:39:38 --> Pixel_Model class loaded
INFO - 2018-10-15 15:39:38 --> Database Driver Class Initialized
INFO - 2018-10-15 15:39:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:39:38 --> Database Driver Class Initialized
INFO - 2018-10-15 15:39:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:39:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-15 15:39:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-15 15:39:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-15 15:39:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-15 15:39:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-15 15:39:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-15 15:39:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-15 15:39:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-15 15:39:38 --> Final output sent to browser
DEBUG - 2018-10-15 15:39:38 --> Total execution time: 0.0454
INFO - 2018-10-15 15:41:52 --> Config Class Initialized
INFO - 2018-10-15 15:41:52 --> Hooks Class Initialized
DEBUG - 2018-10-15 15:41:52 --> UTF-8 Support Enabled
INFO - 2018-10-15 15:41:52 --> Utf8 Class Initialized
INFO - 2018-10-15 15:41:52 --> URI Class Initialized
INFO - 2018-10-15 15:41:52 --> Router Class Initialized
INFO - 2018-10-15 15:41:52 --> Output Class Initialized
INFO - 2018-10-15 15:41:52 --> Security Class Initialized
DEBUG - 2018-10-15 15:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-15 15:41:52 --> CSRF cookie sent
INFO - 2018-10-15 15:41:52 --> CSRF token verified
INFO - 2018-10-15 15:41:52 --> Input Class Initialized
INFO - 2018-10-15 15:41:52 --> Language Class Initialized
INFO - 2018-10-15 15:41:52 --> Loader Class Initialized
INFO - 2018-10-15 15:41:52 --> Helper loaded: url_helper
INFO - 2018-10-15 15:41:52 --> Helper loaded: form_helper
INFO - 2018-10-15 15:41:52 --> Helper loaded: language_helper
DEBUG - 2018-10-15 15:41:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-15 15:41:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-15 15:41:52 --> User Agent Class Initialized
INFO - 2018-10-15 15:41:52 --> Controller Class Initialized
INFO - 2018-10-15 15:41:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-15 15:41:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-15 15:41:52 --> Pixel_Model class loaded
INFO - 2018-10-15 15:41:52 --> Database Driver Class Initialized
INFO - 2018-10-15 15:41:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:41:52 --> Form Validation Class Initialized
INFO - 2018-10-15 15:41:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-15 15:41:52 --> Database Driver Class Initialized
INFO - 2018-10-15 15:41:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:41:52 --> Config Class Initialized
INFO - 2018-10-15 15:41:52 --> Hooks Class Initialized
DEBUG - 2018-10-15 15:41:52 --> UTF-8 Support Enabled
INFO - 2018-10-15 15:41:52 --> Utf8 Class Initialized
INFO - 2018-10-15 15:41:52 --> URI Class Initialized
INFO - 2018-10-15 15:41:52 --> Router Class Initialized
INFO - 2018-10-15 15:41:52 --> Output Class Initialized
INFO - 2018-10-15 15:41:52 --> Security Class Initialized
DEBUG - 2018-10-15 15:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-15 15:41:52 --> CSRF cookie sent
INFO - 2018-10-15 15:41:52 --> Input Class Initialized
INFO - 2018-10-15 15:41:52 --> Language Class Initialized
INFO - 2018-10-15 15:41:52 --> Loader Class Initialized
INFO - 2018-10-15 15:41:52 --> Helper loaded: url_helper
INFO - 2018-10-15 15:41:52 --> Helper loaded: form_helper
INFO - 2018-10-15 15:41:52 --> Helper loaded: language_helper
DEBUG - 2018-10-15 15:41:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-15 15:41:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-15 15:41:52 --> User Agent Class Initialized
INFO - 2018-10-15 15:41:52 --> Controller Class Initialized
INFO - 2018-10-15 15:41:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-15 15:41:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-15 15:41:52 --> Pixel_Model class loaded
INFO - 2018-10-15 15:41:52 --> Database Driver Class Initialized
INFO - 2018-10-15 15:41:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:41:52 --> Database Driver Class Initialized
INFO - 2018-10-15 15:41:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:41:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-15 15:41:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-15 15:41:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-15 15:41:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-15 15:41:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-15 15:41:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-15 15:41:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-10-15 15:41:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-15 15:41:52 --> Final output sent to browser
DEBUG - 2018-10-15 15:41:52 --> Total execution time: 0.0483
INFO - 2018-10-15 15:41:54 --> Config Class Initialized
INFO - 2018-10-15 15:41:54 --> Hooks Class Initialized
DEBUG - 2018-10-15 15:41:54 --> UTF-8 Support Enabled
INFO - 2018-10-15 15:41:54 --> Utf8 Class Initialized
INFO - 2018-10-15 15:41:54 --> URI Class Initialized
INFO - 2018-10-15 15:41:54 --> Router Class Initialized
INFO - 2018-10-15 15:41:54 --> Output Class Initialized
INFO - 2018-10-15 15:41:54 --> Security Class Initialized
DEBUG - 2018-10-15 15:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-15 15:41:54 --> CSRF cookie sent
INFO - 2018-10-15 15:41:54 --> CSRF token verified
INFO - 2018-10-15 15:41:54 --> Input Class Initialized
INFO - 2018-10-15 15:41:54 --> Language Class Initialized
INFO - 2018-10-15 15:41:54 --> Loader Class Initialized
INFO - 2018-10-15 15:41:54 --> Helper loaded: url_helper
INFO - 2018-10-15 15:41:54 --> Helper loaded: form_helper
INFO - 2018-10-15 15:41:54 --> Helper loaded: language_helper
DEBUG - 2018-10-15 15:41:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-15 15:41:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-15 15:41:54 --> User Agent Class Initialized
INFO - 2018-10-15 15:41:54 --> Controller Class Initialized
INFO - 2018-10-15 15:41:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-15 15:41:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-15 15:41:54 --> Pixel_Model class loaded
INFO - 2018-10-15 15:41:54 --> Database Driver Class Initialized
INFO - 2018-10-15 15:41:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:41:54 --> Form Validation Class Initialized
INFO - 2018-10-15 15:41:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-15 15:41:54 --> Database Driver Class Initialized
INFO - 2018-10-15 15:41:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:41:54 --> Config Class Initialized
INFO - 2018-10-15 15:41:54 --> Hooks Class Initialized
DEBUG - 2018-10-15 15:41:54 --> UTF-8 Support Enabled
INFO - 2018-10-15 15:41:54 --> Utf8 Class Initialized
INFO - 2018-10-15 15:41:54 --> URI Class Initialized
INFO - 2018-10-15 15:41:54 --> Router Class Initialized
INFO - 2018-10-15 15:41:54 --> Output Class Initialized
INFO - 2018-10-15 15:41:54 --> Security Class Initialized
DEBUG - 2018-10-15 15:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-15 15:41:54 --> CSRF cookie sent
INFO - 2018-10-15 15:41:54 --> Input Class Initialized
INFO - 2018-10-15 15:41:54 --> Language Class Initialized
INFO - 2018-10-15 15:41:54 --> Loader Class Initialized
INFO - 2018-10-15 15:41:54 --> Helper loaded: url_helper
INFO - 2018-10-15 15:41:54 --> Helper loaded: form_helper
INFO - 2018-10-15 15:41:54 --> Helper loaded: language_helper
DEBUG - 2018-10-15 15:41:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-15 15:41:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-15 15:41:54 --> User Agent Class Initialized
INFO - 2018-10-15 15:41:54 --> Controller Class Initialized
INFO - 2018-10-15 15:41:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-15 15:41:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-15 15:41:54 --> Pixel_Model class loaded
INFO - 2018-10-15 15:41:54 --> Database Driver Class Initialized
INFO - 2018-10-15 15:41:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:41:54 --> Database Driver Class Initialized
INFO - 2018-10-15 15:41:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:41:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-15 15:41:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-15 15:41:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-10-15 15:41:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-15 15:41:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-15 15:41:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-15 15:41:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-15 15:41:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-10-15 15:41:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-15 15:41:54 --> Final output sent to browser
DEBUG - 2018-10-15 15:41:54 --> Total execution time: 0.0411
INFO - 2018-10-15 15:41:55 --> Config Class Initialized
INFO - 2018-10-15 15:41:55 --> Hooks Class Initialized
DEBUG - 2018-10-15 15:41:55 --> UTF-8 Support Enabled
INFO - 2018-10-15 15:41:55 --> Utf8 Class Initialized
INFO - 2018-10-15 15:41:55 --> URI Class Initialized
INFO - 2018-10-15 15:41:55 --> Router Class Initialized
INFO - 2018-10-15 15:41:55 --> Output Class Initialized
INFO - 2018-10-15 15:41:55 --> Security Class Initialized
DEBUG - 2018-10-15 15:41:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-15 15:41:55 --> CSRF cookie sent
INFO - 2018-10-15 15:41:55 --> CSRF token verified
INFO - 2018-10-15 15:41:55 --> Input Class Initialized
INFO - 2018-10-15 15:41:55 --> Language Class Initialized
INFO - 2018-10-15 15:41:55 --> Loader Class Initialized
INFO - 2018-10-15 15:41:55 --> Helper loaded: url_helper
INFO - 2018-10-15 15:41:55 --> Helper loaded: form_helper
INFO - 2018-10-15 15:41:55 --> Helper loaded: language_helper
DEBUG - 2018-10-15 15:41:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-15 15:41:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-15 15:41:55 --> User Agent Class Initialized
INFO - 2018-10-15 15:41:55 --> Controller Class Initialized
INFO - 2018-10-15 15:41:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-15 15:41:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-15 15:41:55 --> Pixel_Model class loaded
INFO - 2018-10-15 15:41:55 --> Database Driver Class Initialized
INFO - 2018-10-15 15:41:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:41:55 --> Form Validation Class Initialized
INFO - 2018-10-15 15:41:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-15 15:41:55 --> Database Driver Class Initialized
INFO - 2018-10-15 15:41:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:41:55 --> Config Class Initialized
INFO - 2018-10-15 15:41:55 --> Hooks Class Initialized
DEBUG - 2018-10-15 15:41:55 --> UTF-8 Support Enabled
INFO - 2018-10-15 15:41:55 --> Utf8 Class Initialized
INFO - 2018-10-15 15:41:55 --> URI Class Initialized
INFO - 2018-10-15 15:41:55 --> Router Class Initialized
INFO - 2018-10-15 15:41:55 --> Output Class Initialized
INFO - 2018-10-15 15:41:55 --> Security Class Initialized
DEBUG - 2018-10-15 15:41:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-15 15:41:55 --> CSRF cookie sent
INFO - 2018-10-15 15:41:55 --> Input Class Initialized
INFO - 2018-10-15 15:41:55 --> Language Class Initialized
INFO - 2018-10-15 15:41:55 --> Loader Class Initialized
INFO - 2018-10-15 15:41:55 --> Helper loaded: url_helper
INFO - 2018-10-15 15:41:55 --> Helper loaded: form_helper
INFO - 2018-10-15 15:41:55 --> Helper loaded: language_helper
DEBUG - 2018-10-15 15:41:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-15 15:41:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-15 15:41:55 --> User Agent Class Initialized
INFO - 2018-10-15 15:41:55 --> Controller Class Initialized
INFO - 2018-10-15 15:41:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-15 15:41:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-15 15:41:55 --> Pixel_Model class loaded
INFO - 2018-10-15 15:41:55 --> Database Driver Class Initialized
INFO - 2018-10-15 15:41:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:41:55 --> Database Driver Class Initialized
INFO - 2018-10-15 15:41:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:41:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-15 15:41:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-15 15:41:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-15 15:41:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-15 15:41:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-15 15:41:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-15 15:41:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-15 15:41:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-15 15:41:55 --> Final output sent to browser
DEBUG - 2018-10-15 15:41:55 --> Total execution time: 0.0392
INFO - 2018-10-15 15:42:01 --> Config Class Initialized
INFO - 2018-10-15 15:42:01 --> Hooks Class Initialized
DEBUG - 2018-10-15 15:42:01 --> UTF-8 Support Enabled
INFO - 2018-10-15 15:42:01 --> Utf8 Class Initialized
INFO - 2018-10-15 15:42:01 --> URI Class Initialized
INFO - 2018-10-15 15:42:01 --> Router Class Initialized
INFO - 2018-10-15 15:42:01 --> Output Class Initialized
INFO - 2018-10-15 15:42:01 --> Security Class Initialized
DEBUG - 2018-10-15 15:42:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-15 15:42:01 --> CSRF cookie sent
INFO - 2018-10-15 15:42:01 --> CSRF token verified
INFO - 2018-10-15 15:42:01 --> Input Class Initialized
INFO - 2018-10-15 15:42:01 --> Language Class Initialized
INFO - 2018-10-15 15:42:01 --> Loader Class Initialized
INFO - 2018-10-15 15:42:01 --> Helper loaded: url_helper
INFO - 2018-10-15 15:42:01 --> Helper loaded: form_helper
INFO - 2018-10-15 15:42:01 --> Helper loaded: language_helper
DEBUG - 2018-10-15 15:42:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-15 15:42:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-15 15:42:01 --> User Agent Class Initialized
INFO - 2018-10-15 15:42:01 --> Controller Class Initialized
INFO - 2018-10-15 15:42:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-15 15:42:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-15 15:42:01 --> Pixel_Model class loaded
INFO - 2018-10-15 15:42:01 --> Database Driver Class Initialized
INFO - 2018-10-15 15:42:01 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:42:01 --> Form Validation Class Initialized
INFO - 2018-10-15 15:42:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-15 15:42:01 --> Database Driver Class Initialized
INFO - 2018-10-15 15:42:01 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:42:01 --> Config Class Initialized
INFO - 2018-10-15 15:42:01 --> Hooks Class Initialized
DEBUG - 2018-10-15 15:42:01 --> UTF-8 Support Enabled
INFO - 2018-10-15 15:42:01 --> Utf8 Class Initialized
INFO - 2018-10-15 15:42:01 --> URI Class Initialized
INFO - 2018-10-15 15:42:01 --> Router Class Initialized
INFO - 2018-10-15 15:42:01 --> Output Class Initialized
INFO - 2018-10-15 15:42:01 --> Security Class Initialized
DEBUG - 2018-10-15 15:42:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-15 15:42:01 --> CSRF cookie sent
INFO - 2018-10-15 15:42:01 --> Input Class Initialized
INFO - 2018-10-15 15:42:01 --> Language Class Initialized
INFO - 2018-10-15 15:42:01 --> Loader Class Initialized
INFO - 2018-10-15 15:42:01 --> Helper loaded: url_helper
INFO - 2018-10-15 15:42:01 --> Helper loaded: form_helper
INFO - 2018-10-15 15:42:01 --> Helper loaded: language_helper
DEBUG - 2018-10-15 15:42:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-15 15:42:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-15 15:42:01 --> User Agent Class Initialized
INFO - 2018-10-15 15:42:01 --> Controller Class Initialized
INFO - 2018-10-15 15:42:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-15 15:42:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-15 15:42:01 --> Pixel_Model class loaded
INFO - 2018-10-15 15:42:01 --> Database Driver Class Initialized
INFO - 2018-10-15 15:42:01 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:42:01 --> Database Driver Class Initialized
INFO - 2018-10-15 15:42:01 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:42:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-15 15:42:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-15 15:42:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-15 15:42:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-15 15:42:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-15 15:42:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-15 15:42:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/marriage.php
INFO - 2018-10-15 15:42:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-15 15:42:01 --> Final output sent to browser
DEBUG - 2018-10-15 15:42:01 --> Total execution time: 0.0411
INFO - 2018-10-15 15:42:10 --> Config Class Initialized
INFO - 2018-10-15 15:42:10 --> Hooks Class Initialized
DEBUG - 2018-10-15 15:42:10 --> UTF-8 Support Enabled
INFO - 2018-10-15 15:42:10 --> Utf8 Class Initialized
INFO - 2018-10-15 15:42:10 --> URI Class Initialized
INFO - 2018-10-15 15:42:10 --> Router Class Initialized
INFO - 2018-10-15 15:42:10 --> Output Class Initialized
INFO - 2018-10-15 15:42:10 --> Security Class Initialized
DEBUG - 2018-10-15 15:42:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-15 15:42:10 --> CSRF cookie sent
INFO - 2018-10-15 15:42:10 --> CSRF token verified
INFO - 2018-10-15 15:42:10 --> Input Class Initialized
INFO - 2018-10-15 15:42:10 --> Language Class Initialized
INFO - 2018-10-15 15:42:10 --> Loader Class Initialized
INFO - 2018-10-15 15:42:10 --> Helper loaded: url_helper
INFO - 2018-10-15 15:42:10 --> Helper loaded: form_helper
INFO - 2018-10-15 15:42:10 --> Helper loaded: language_helper
DEBUG - 2018-10-15 15:42:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-15 15:42:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-15 15:42:10 --> User Agent Class Initialized
INFO - 2018-10-15 15:42:10 --> Controller Class Initialized
INFO - 2018-10-15 15:42:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-15 15:42:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-15 15:42:10 --> Pixel_Model class loaded
INFO - 2018-10-15 15:42:10 --> Database Driver Class Initialized
INFO - 2018-10-15 15:42:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:42:10 --> Form Validation Class Initialized
INFO - 2018-10-15 15:42:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-15 15:42:10 --> Database Driver Class Initialized
INFO - 2018-10-15 15:42:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:42:10 --> Config Class Initialized
INFO - 2018-10-15 15:42:10 --> Hooks Class Initialized
DEBUG - 2018-10-15 15:42:10 --> UTF-8 Support Enabled
INFO - 2018-10-15 15:42:10 --> Utf8 Class Initialized
INFO - 2018-10-15 15:42:10 --> URI Class Initialized
INFO - 2018-10-15 15:42:10 --> Router Class Initialized
INFO - 2018-10-15 15:42:10 --> Output Class Initialized
INFO - 2018-10-15 15:42:10 --> Security Class Initialized
DEBUG - 2018-10-15 15:42:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-15 15:42:10 --> CSRF cookie sent
INFO - 2018-10-15 15:42:10 --> Input Class Initialized
INFO - 2018-10-15 15:42:10 --> Language Class Initialized
INFO - 2018-10-15 15:42:10 --> Loader Class Initialized
INFO - 2018-10-15 15:42:10 --> Helper loaded: url_helper
INFO - 2018-10-15 15:42:10 --> Helper loaded: form_helper
INFO - 2018-10-15 15:42:10 --> Helper loaded: language_helper
DEBUG - 2018-10-15 15:42:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-15 15:42:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-15 15:42:10 --> User Agent Class Initialized
INFO - 2018-10-15 15:42:10 --> Controller Class Initialized
INFO - 2018-10-15 15:42:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-15 15:42:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-15 15:42:10 --> Pixel_Model class loaded
INFO - 2018-10-15 15:42:10 --> Database Driver Class Initialized
INFO - 2018-10-15 15:42:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:42:10 --> Database Driver Class Initialized
INFO - 2018-10-15 15:42:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:42:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-15 15:42:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-15 15:42:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-15 15:42:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-15 15:42:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-15 15:42:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-15 15:42:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-10-15 15:42:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-15 15:42:10 --> Final output sent to browser
DEBUG - 2018-10-15 15:42:10 --> Total execution time: 0.0397
INFO - 2018-10-15 15:43:09 --> Config Class Initialized
INFO - 2018-10-15 15:43:09 --> Hooks Class Initialized
DEBUG - 2018-10-15 15:43:09 --> UTF-8 Support Enabled
INFO - 2018-10-15 15:43:09 --> Utf8 Class Initialized
INFO - 2018-10-15 15:43:09 --> URI Class Initialized
DEBUG - 2018-10-15 15:43:09 --> No URI present. Default controller set.
INFO - 2018-10-15 15:43:09 --> Router Class Initialized
INFO - 2018-10-15 15:43:09 --> Output Class Initialized
INFO - 2018-10-15 15:43:09 --> Security Class Initialized
DEBUG - 2018-10-15 15:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-15 15:43:09 --> CSRF cookie sent
INFO - 2018-10-15 15:43:09 --> Input Class Initialized
INFO - 2018-10-15 15:43:09 --> Language Class Initialized
INFO - 2018-10-15 15:43:09 --> Loader Class Initialized
INFO - 2018-10-15 15:43:09 --> Helper loaded: url_helper
INFO - 2018-10-15 15:43:09 --> Helper loaded: form_helper
INFO - 2018-10-15 15:43:09 --> Helper loaded: language_helper
DEBUG - 2018-10-15 15:43:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-15 15:43:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-15 15:43:09 --> User Agent Class Initialized
INFO - 2018-10-15 15:43:09 --> Controller Class Initialized
INFO - 2018-10-15 15:43:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-15 15:43:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-15 15:43:09 --> Pixel_Model class loaded
INFO - 2018-10-15 15:43:10 --> Database Driver Class Initialized
INFO - 2018-10-15 15:43:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:43:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-15 15:43:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-15 15:43:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-15 15:43:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-15 15:43:10 --> Final output sent to browser
DEBUG - 2018-10-15 15:43:10 --> Total execution time: 0.0341
INFO - 2018-10-15 15:43:48 --> Config Class Initialized
INFO - 2018-10-15 15:43:48 --> Hooks Class Initialized
DEBUG - 2018-10-15 15:43:48 --> UTF-8 Support Enabled
INFO - 2018-10-15 15:43:48 --> Utf8 Class Initialized
INFO - 2018-10-15 15:43:48 --> URI Class Initialized
INFO - 2018-10-15 15:43:48 --> Router Class Initialized
INFO - 2018-10-15 15:43:48 --> Output Class Initialized
INFO - 2018-10-15 15:43:48 --> Security Class Initialized
DEBUG - 2018-10-15 15:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-15 15:43:48 --> CSRF cookie sent
INFO - 2018-10-15 15:43:48 --> CSRF token verified
INFO - 2018-10-15 15:43:48 --> Input Class Initialized
INFO - 2018-10-15 15:43:48 --> Language Class Initialized
INFO - 2018-10-15 15:43:48 --> Loader Class Initialized
INFO - 2018-10-15 15:43:48 --> Helper loaded: url_helper
INFO - 2018-10-15 15:43:48 --> Helper loaded: form_helper
INFO - 2018-10-15 15:43:48 --> Helper loaded: language_helper
DEBUG - 2018-10-15 15:43:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-15 15:43:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-15 15:43:48 --> User Agent Class Initialized
INFO - 2018-10-15 15:43:48 --> Controller Class Initialized
INFO - 2018-10-15 15:43:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-15 15:43:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-15 15:43:48 --> Pixel_Model class loaded
INFO - 2018-10-15 15:43:48 --> Database Driver Class Initialized
INFO - 2018-10-15 15:43:48 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:43:48 --> Form Validation Class Initialized
INFO - 2018-10-15 15:43:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-15 15:43:48 --> Database Driver Class Initialized
INFO - 2018-10-15 15:43:48 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:43:48 --> Config Class Initialized
INFO - 2018-10-15 15:43:48 --> Hooks Class Initialized
DEBUG - 2018-10-15 15:43:48 --> UTF-8 Support Enabled
INFO - 2018-10-15 15:43:48 --> Utf8 Class Initialized
INFO - 2018-10-15 15:43:48 --> URI Class Initialized
INFO - 2018-10-15 15:43:48 --> Router Class Initialized
INFO - 2018-10-15 15:43:48 --> Output Class Initialized
INFO - 2018-10-15 15:43:48 --> Security Class Initialized
DEBUG - 2018-10-15 15:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-15 15:43:48 --> CSRF cookie sent
INFO - 2018-10-15 15:43:48 --> Input Class Initialized
INFO - 2018-10-15 15:43:48 --> Language Class Initialized
INFO - 2018-10-15 15:43:48 --> Loader Class Initialized
INFO - 2018-10-15 15:43:48 --> Helper loaded: url_helper
INFO - 2018-10-15 15:43:48 --> Helper loaded: form_helper
INFO - 2018-10-15 15:43:48 --> Helper loaded: language_helper
DEBUG - 2018-10-15 15:43:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-15 15:43:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-15 15:43:48 --> User Agent Class Initialized
INFO - 2018-10-15 15:43:48 --> Controller Class Initialized
INFO - 2018-10-15 15:43:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-15 15:43:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-15 15:43:48 --> Pixel_Model class loaded
INFO - 2018-10-15 15:43:48 --> Database Driver Class Initialized
INFO - 2018-10-15 15:43:48 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:43:48 --> Database Driver Class Initialized
INFO - 2018-10-15 15:43:48 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:43:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-15 15:43:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-15 15:43:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-15 15:43:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-15 15:43:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-15 15:43:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-15 15:43:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-15 15:43:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-15 15:43:48 --> Final output sent to browser
DEBUG - 2018-10-15 15:43:48 --> Total execution time: 0.0547
INFO - 2018-10-15 15:43:50 --> Config Class Initialized
INFO - 2018-10-15 15:43:50 --> Hooks Class Initialized
DEBUG - 2018-10-15 15:43:50 --> UTF-8 Support Enabled
INFO - 2018-10-15 15:43:50 --> Utf8 Class Initialized
INFO - 2018-10-15 15:43:50 --> URI Class Initialized
INFO - 2018-10-15 15:43:50 --> Router Class Initialized
INFO - 2018-10-15 15:43:50 --> Output Class Initialized
INFO - 2018-10-15 15:43:50 --> Security Class Initialized
DEBUG - 2018-10-15 15:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-15 15:43:50 --> CSRF cookie sent
INFO - 2018-10-15 15:43:50 --> CSRF token verified
INFO - 2018-10-15 15:43:50 --> Input Class Initialized
INFO - 2018-10-15 15:43:50 --> Language Class Initialized
INFO - 2018-10-15 15:43:50 --> Loader Class Initialized
INFO - 2018-10-15 15:43:50 --> Helper loaded: url_helper
INFO - 2018-10-15 15:43:50 --> Helper loaded: form_helper
INFO - 2018-10-15 15:43:50 --> Helper loaded: language_helper
DEBUG - 2018-10-15 15:43:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-15 15:43:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-15 15:43:50 --> User Agent Class Initialized
INFO - 2018-10-15 15:43:50 --> Controller Class Initialized
INFO - 2018-10-15 15:43:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-15 15:43:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-15 15:43:50 --> Pixel_Model class loaded
INFO - 2018-10-15 15:43:50 --> Database Driver Class Initialized
INFO - 2018-10-15 15:43:50 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:43:50 --> Form Validation Class Initialized
INFO - 2018-10-15 15:43:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-15 15:43:50 --> Database Driver Class Initialized
INFO - 2018-10-15 15:43:50 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:43:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-15 15:43:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-15 15:43:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-15 15:43:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-15 15:43:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-15 15:43:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_errors.php
INFO - 2018-10-15 15:43:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-15 15:43:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-15 15:43:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-15 15:43:50 --> Final output sent to browser
DEBUG - 2018-10-15 15:43:50 --> Total execution time: 0.0643
INFO - 2018-10-15 15:43:58 --> Config Class Initialized
INFO - 2018-10-15 15:43:58 --> Hooks Class Initialized
DEBUG - 2018-10-15 15:43:58 --> UTF-8 Support Enabled
INFO - 2018-10-15 15:43:58 --> Utf8 Class Initialized
INFO - 2018-10-15 15:43:58 --> URI Class Initialized
INFO - 2018-10-15 15:43:59 --> Router Class Initialized
INFO - 2018-10-15 15:43:59 --> Output Class Initialized
INFO - 2018-10-15 15:43:59 --> Security Class Initialized
DEBUG - 2018-10-15 15:43:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-15 15:43:59 --> CSRF cookie sent
INFO - 2018-10-15 15:43:59 --> CSRF token verified
INFO - 2018-10-15 15:43:59 --> Input Class Initialized
INFO - 2018-10-15 15:43:59 --> Language Class Initialized
INFO - 2018-10-15 15:43:59 --> Loader Class Initialized
INFO - 2018-10-15 15:43:59 --> Helper loaded: url_helper
INFO - 2018-10-15 15:43:59 --> Helper loaded: form_helper
INFO - 2018-10-15 15:43:59 --> Helper loaded: language_helper
DEBUG - 2018-10-15 15:43:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-15 15:43:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-15 15:43:59 --> User Agent Class Initialized
INFO - 2018-10-15 15:43:59 --> Controller Class Initialized
INFO - 2018-10-15 15:43:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-15 15:43:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-15 15:43:59 --> Pixel_Model class loaded
INFO - 2018-10-15 15:43:59 --> Database Driver Class Initialized
INFO - 2018-10-15 15:43:59 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:43:59 --> Form Validation Class Initialized
INFO - 2018-10-15 15:43:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-15 15:43:59 --> Database Driver Class Initialized
INFO - 2018-10-15 15:43:59 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:43:59 --> Config Class Initialized
INFO - 2018-10-15 15:43:59 --> Hooks Class Initialized
DEBUG - 2018-10-15 15:43:59 --> UTF-8 Support Enabled
INFO - 2018-10-15 15:43:59 --> Utf8 Class Initialized
INFO - 2018-10-15 15:43:59 --> URI Class Initialized
INFO - 2018-10-15 15:43:59 --> Router Class Initialized
INFO - 2018-10-15 15:43:59 --> Output Class Initialized
INFO - 2018-10-15 15:43:59 --> Security Class Initialized
DEBUG - 2018-10-15 15:43:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-15 15:43:59 --> CSRF cookie sent
INFO - 2018-10-15 15:43:59 --> Input Class Initialized
INFO - 2018-10-15 15:43:59 --> Language Class Initialized
INFO - 2018-10-15 15:43:59 --> Loader Class Initialized
INFO - 2018-10-15 15:43:59 --> Helper loaded: url_helper
INFO - 2018-10-15 15:43:59 --> Helper loaded: form_helper
INFO - 2018-10-15 15:43:59 --> Helper loaded: language_helper
DEBUG - 2018-10-15 15:43:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-15 15:43:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-15 15:43:59 --> User Agent Class Initialized
INFO - 2018-10-15 15:43:59 --> Controller Class Initialized
INFO - 2018-10-15 15:43:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-15 15:43:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-15 15:43:59 --> Pixel_Model class loaded
INFO - 2018-10-15 15:43:59 --> Database Driver Class Initialized
INFO - 2018-10-15 15:43:59 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:43:59 --> Database Driver Class Initialized
INFO - 2018-10-15 15:43:59 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:43:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-15 15:43:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-15 15:43:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-15 15:43:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-15 15:43:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-15 15:43:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-15 15:43:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-10-15 15:43:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-15 15:43:59 --> Final output sent to browser
DEBUG - 2018-10-15 15:43:59 --> Total execution time: 0.0469
INFO - 2018-10-15 15:44:01 --> Config Class Initialized
INFO - 2018-10-15 15:44:01 --> Hooks Class Initialized
DEBUG - 2018-10-15 15:44:01 --> UTF-8 Support Enabled
INFO - 2018-10-15 15:44:01 --> Utf8 Class Initialized
INFO - 2018-10-15 15:44:01 --> URI Class Initialized
INFO - 2018-10-15 15:44:01 --> Router Class Initialized
INFO - 2018-10-15 15:44:01 --> Output Class Initialized
INFO - 2018-10-15 15:44:01 --> Security Class Initialized
DEBUG - 2018-10-15 15:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-15 15:44:01 --> CSRF cookie sent
INFO - 2018-10-15 15:44:01 --> CSRF token verified
INFO - 2018-10-15 15:44:01 --> Input Class Initialized
INFO - 2018-10-15 15:44:01 --> Language Class Initialized
INFO - 2018-10-15 15:44:01 --> Loader Class Initialized
INFO - 2018-10-15 15:44:01 --> Helper loaded: url_helper
INFO - 2018-10-15 15:44:01 --> Helper loaded: form_helper
INFO - 2018-10-15 15:44:01 --> Helper loaded: language_helper
DEBUG - 2018-10-15 15:44:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-15 15:44:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-15 15:44:01 --> User Agent Class Initialized
INFO - 2018-10-15 15:44:01 --> Controller Class Initialized
INFO - 2018-10-15 15:44:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-15 15:44:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-15 15:44:01 --> Pixel_Model class loaded
INFO - 2018-10-15 15:44:01 --> Database Driver Class Initialized
INFO - 2018-10-15 15:44:01 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:44:01 --> Form Validation Class Initialized
INFO - 2018-10-15 15:44:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-15 15:44:01 --> Database Driver Class Initialized
INFO - 2018-10-15 15:44:01 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:44:01 --> Config Class Initialized
INFO - 2018-10-15 15:44:01 --> Hooks Class Initialized
DEBUG - 2018-10-15 15:44:01 --> UTF-8 Support Enabled
INFO - 2018-10-15 15:44:01 --> Utf8 Class Initialized
INFO - 2018-10-15 15:44:01 --> URI Class Initialized
INFO - 2018-10-15 15:44:01 --> Router Class Initialized
INFO - 2018-10-15 15:44:01 --> Output Class Initialized
INFO - 2018-10-15 15:44:01 --> Security Class Initialized
DEBUG - 2018-10-15 15:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-15 15:44:01 --> CSRF cookie sent
INFO - 2018-10-15 15:44:01 --> Input Class Initialized
INFO - 2018-10-15 15:44:01 --> Language Class Initialized
INFO - 2018-10-15 15:44:01 --> Loader Class Initialized
INFO - 2018-10-15 15:44:01 --> Helper loaded: url_helper
INFO - 2018-10-15 15:44:01 --> Helper loaded: form_helper
INFO - 2018-10-15 15:44:01 --> Helper loaded: language_helper
DEBUG - 2018-10-15 15:44:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-15 15:44:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-15 15:44:01 --> User Agent Class Initialized
INFO - 2018-10-15 15:44:01 --> Controller Class Initialized
INFO - 2018-10-15 15:44:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-15 15:44:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-15 15:44:01 --> Pixel_Model class loaded
INFO - 2018-10-15 15:44:01 --> Database Driver Class Initialized
INFO - 2018-10-15 15:44:01 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:44:01 --> Database Driver Class Initialized
INFO - 2018-10-15 15:44:01 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:44:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-15 15:44:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-15 15:44:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-10-15 15:44:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-15 15:44:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-15 15:44:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-15 15:44:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-15 15:44:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-10-15 15:44:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-15 15:44:01 --> Final output sent to browser
DEBUG - 2018-10-15 15:44:01 --> Total execution time: 0.0336
INFO - 2018-10-15 15:44:03 --> Config Class Initialized
INFO - 2018-10-15 15:44:03 --> Hooks Class Initialized
DEBUG - 2018-10-15 15:44:03 --> UTF-8 Support Enabled
INFO - 2018-10-15 15:44:03 --> Utf8 Class Initialized
INFO - 2018-10-15 15:44:03 --> URI Class Initialized
INFO - 2018-10-15 15:44:03 --> Router Class Initialized
INFO - 2018-10-15 15:44:03 --> Output Class Initialized
INFO - 2018-10-15 15:44:03 --> Security Class Initialized
DEBUG - 2018-10-15 15:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-15 15:44:03 --> CSRF cookie sent
INFO - 2018-10-15 15:44:03 --> CSRF token verified
INFO - 2018-10-15 15:44:03 --> Input Class Initialized
INFO - 2018-10-15 15:44:03 --> Language Class Initialized
INFO - 2018-10-15 15:44:03 --> Loader Class Initialized
INFO - 2018-10-15 15:44:03 --> Helper loaded: url_helper
INFO - 2018-10-15 15:44:03 --> Helper loaded: form_helper
INFO - 2018-10-15 15:44:03 --> Helper loaded: language_helper
DEBUG - 2018-10-15 15:44:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-15 15:44:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-15 15:44:03 --> User Agent Class Initialized
INFO - 2018-10-15 15:44:03 --> Controller Class Initialized
INFO - 2018-10-15 15:44:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-15 15:44:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-15 15:44:03 --> Pixel_Model class loaded
INFO - 2018-10-15 15:44:03 --> Database Driver Class Initialized
INFO - 2018-10-15 15:44:03 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:44:03 --> Form Validation Class Initialized
INFO - 2018-10-15 15:44:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-15 15:44:03 --> Database Driver Class Initialized
INFO - 2018-10-15 15:44:03 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:44:03 --> Config Class Initialized
INFO - 2018-10-15 15:44:03 --> Hooks Class Initialized
DEBUG - 2018-10-15 15:44:03 --> UTF-8 Support Enabled
INFO - 2018-10-15 15:44:03 --> Utf8 Class Initialized
INFO - 2018-10-15 15:44:03 --> URI Class Initialized
INFO - 2018-10-15 15:44:03 --> Router Class Initialized
INFO - 2018-10-15 15:44:03 --> Output Class Initialized
INFO - 2018-10-15 15:44:03 --> Security Class Initialized
DEBUG - 2018-10-15 15:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-15 15:44:03 --> CSRF cookie sent
INFO - 2018-10-15 15:44:03 --> Input Class Initialized
INFO - 2018-10-15 15:44:03 --> Language Class Initialized
INFO - 2018-10-15 15:44:03 --> Loader Class Initialized
INFO - 2018-10-15 15:44:03 --> Helper loaded: url_helper
INFO - 2018-10-15 15:44:03 --> Helper loaded: form_helper
INFO - 2018-10-15 15:44:03 --> Helper loaded: language_helper
DEBUG - 2018-10-15 15:44:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-15 15:44:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-15 15:44:03 --> User Agent Class Initialized
INFO - 2018-10-15 15:44:03 --> Controller Class Initialized
INFO - 2018-10-15 15:44:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-15 15:44:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-15 15:44:03 --> Pixel_Model class loaded
INFO - 2018-10-15 15:44:03 --> Database Driver Class Initialized
INFO - 2018-10-15 15:44:03 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:44:03 --> Database Driver Class Initialized
INFO - 2018-10-15 15:44:03 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:44:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-15 15:44:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-15 15:44:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-15 15:44:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-15 15:44:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-15 15:44:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-15 15:44:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-15 15:44:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-15 15:44:03 --> Final output sent to browser
DEBUG - 2018-10-15 15:44:03 --> Total execution time: 0.0356
INFO - 2018-10-15 15:44:06 --> Config Class Initialized
INFO - 2018-10-15 15:44:06 --> Hooks Class Initialized
DEBUG - 2018-10-15 15:44:06 --> UTF-8 Support Enabled
INFO - 2018-10-15 15:44:06 --> Utf8 Class Initialized
INFO - 2018-10-15 15:44:06 --> URI Class Initialized
INFO - 2018-10-15 15:44:06 --> Router Class Initialized
INFO - 2018-10-15 15:44:06 --> Output Class Initialized
INFO - 2018-10-15 15:44:06 --> Security Class Initialized
DEBUG - 2018-10-15 15:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-15 15:44:06 --> CSRF cookie sent
INFO - 2018-10-15 15:44:06 --> Input Class Initialized
INFO - 2018-10-15 15:44:06 --> Language Class Initialized
INFO - 2018-10-15 15:44:06 --> Loader Class Initialized
INFO - 2018-10-15 15:44:06 --> Helper loaded: url_helper
INFO - 2018-10-15 15:44:06 --> Helper loaded: form_helper
INFO - 2018-10-15 15:44:06 --> Helper loaded: language_helper
DEBUG - 2018-10-15 15:44:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-15 15:44:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-15 15:44:06 --> User Agent Class Initialized
INFO - 2018-10-15 15:44:06 --> Controller Class Initialized
INFO - 2018-10-15 15:44:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-15 15:44:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-15 15:44:06 --> Pixel_Model class loaded
INFO - 2018-10-15 15:44:06 --> Database Driver Class Initialized
INFO - 2018-10-15 15:44:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:44:06 --> Database Driver Class Initialized
INFO - 2018-10-15 15:44:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:44:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-15 15:44:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-15 15:44:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-10-15 15:44:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-15 15:44:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-15 15:44:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-15 15:44:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-15 15:44:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-10-15 15:44:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-15 15:44:06 --> Final output sent to browser
DEBUG - 2018-10-15 15:44:06 --> Total execution time: 0.0428
INFO - 2018-10-15 15:44:11 --> Config Class Initialized
INFO - 2018-10-15 15:44:11 --> Hooks Class Initialized
DEBUG - 2018-10-15 15:44:11 --> UTF-8 Support Enabled
INFO - 2018-10-15 15:44:11 --> Utf8 Class Initialized
INFO - 2018-10-15 15:44:11 --> URI Class Initialized
INFO - 2018-10-15 15:44:11 --> Router Class Initialized
INFO - 2018-10-15 15:44:11 --> Output Class Initialized
INFO - 2018-10-15 15:44:11 --> Security Class Initialized
DEBUG - 2018-10-15 15:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-15 15:44:11 --> CSRF cookie sent
INFO - 2018-10-15 15:44:11 --> CSRF token verified
INFO - 2018-10-15 15:44:11 --> Input Class Initialized
INFO - 2018-10-15 15:44:11 --> Language Class Initialized
INFO - 2018-10-15 15:44:11 --> Loader Class Initialized
INFO - 2018-10-15 15:44:11 --> Helper loaded: url_helper
INFO - 2018-10-15 15:44:11 --> Helper loaded: form_helper
INFO - 2018-10-15 15:44:11 --> Helper loaded: language_helper
DEBUG - 2018-10-15 15:44:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-15 15:44:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-15 15:44:11 --> User Agent Class Initialized
INFO - 2018-10-15 15:44:11 --> Controller Class Initialized
INFO - 2018-10-15 15:44:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-15 15:44:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-15 15:44:11 --> Pixel_Model class loaded
INFO - 2018-10-15 15:44:11 --> Database Driver Class Initialized
INFO - 2018-10-15 15:44:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:44:11 --> Form Validation Class Initialized
INFO - 2018-10-15 15:44:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-15 15:44:11 --> Database Driver Class Initialized
INFO - 2018-10-15 15:44:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:44:11 --> Config Class Initialized
INFO - 2018-10-15 15:44:11 --> Hooks Class Initialized
DEBUG - 2018-10-15 15:44:11 --> UTF-8 Support Enabled
INFO - 2018-10-15 15:44:11 --> Utf8 Class Initialized
INFO - 2018-10-15 15:44:11 --> URI Class Initialized
INFO - 2018-10-15 15:44:11 --> Router Class Initialized
INFO - 2018-10-15 15:44:11 --> Output Class Initialized
INFO - 2018-10-15 15:44:11 --> Security Class Initialized
DEBUG - 2018-10-15 15:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-15 15:44:11 --> CSRF cookie sent
INFO - 2018-10-15 15:44:11 --> Input Class Initialized
INFO - 2018-10-15 15:44:11 --> Language Class Initialized
INFO - 2018-10-15 15:44:11 --> Loader Class Initialized
INFO - 2018-10-15 15:44:11 --> Helper loaded: url_helper
INFO - 2018-10-15 15:44:11 --> Helper loaded: form_helper
INFO - 2018-10-15 15:44:11 --> Helper loaded: language_helper
DEBUG - 2018-10-15 15:44:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-15 15:44:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-15 15:44:11 --> User Agent Class Initialized
INFO - 2018-10-15 15:44:11 --> Controller Class Initialized
INFO - 2018-10-15 15:44:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-15 15:44:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-15 15:44:11 --> Pixel_Model class loaded
INFO - 2018-10-15 15:44:11 --> Database Driver Class Initialized
INFO - 2018-10-15 15:44:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:44:11 --> Database Driver Class Initialized
INFO - 2018-10-15 15:44:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:44:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-15 15:44:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-15 15:44:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-15 15:44:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-15 15:44:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-15 15:44:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-15 15:44:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-15 15:44:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-15 15:44:11 --> Final output sent to browser
DEBUG - 2018-10-15 15:44:11 --> Total execution time: 0.0413
INFO - 2018-10-15 15:44:24 --> Config Class Initialized
INFO - 2018-10-15 15:44:24 --> Hooks Class Initialized
DEBUG - 2018-10-15 15:44:24 --> UTF-8 Support Enabled
INFO - 2018-10-15 15:44:24 --> Utf8 Class Initialized
INFO - 2018-10-15 15:44:24 --> URI Class Initialized
INFO - 2018-10-15 15:44:24 --> Router Class Initialized
INFO - 2018-10-15 15:44:24 --> Output Class Initialized
INFO - 2018-10-15 15:44:24 --> Security Class Initialized
DEBUG - 2018-10-15 15:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-15 15:44:24 --> CSRF cookie sent
INFO - 2018-10-15 15:44:24 --> CSRF token verified
INFO - 2018-10-15 15:44:24 --> Input Class Initialized
INFO - 2018-10-15 15:44:24 --> Language Class Initialized
INFO - 2018-10-15 15:44:24 --> Loader Class Initialized
INFO - 2018-10-15 15:44:24 --> Helper loaded: url_helper
INFO - 2018-10-15 15:44:24 --> Helper loaded: form_helper
INFO - 2018-10-15 15:44:24 --> Helper loaded: language_helper
DEBUG - 2018-10-15 15:44:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-15 15:44:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-15 15:44:24 --> User Agent Class Initialized
INFO - 2018-10-15 15:44:24 --> Controller Class Initialized
INFO - 2018-10-15 15:44:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-15 15:44:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-15 15:44:24 --> Pixel_Model class loaded
INFO - 2018-10-15 15:44:24 --> Database Driver Class Initialized
INFO - 2018-10-15 15:44:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:44:24 --> Form Validation Class Initialized
INFO - 2018-10-15 15:44:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-15 15:44:24 --> Database Driver Class Initialized
INFO - 2018-10-15 15:44:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:44:24 --> Config Class Initialized
INFO - 2018-10-15 15:44:24 --> Hooks Class Initialized
DEBUG - 2018-10-15 15:44:24 --> UTF-8 Support Enabled
INFO - 2018-10-15 15:44:24 --> Utf8 Class Initialized
INFO - 2018-10-15 15:44:24 --> URI Class Initialized
INFO - 2018-10-15 15:44:24 --> Router Class Initialized
INFO - 2018-10-15 15:44:24 --> Output Class Initialized
INFO - 2018-10-15 15:44:24 --> Security Class Initialized
DEBUG - 2018-10-15 15:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-15 15:44:24 --> CSRF cookie sent
INFO - 2018-10-15 15:44:24 --> Input Class Initialized
INFO - 2018-10-15 15:44:24 --> Language Class Initialized
INFO - 2018-10-15 15:44:24 --> Loader Class Initialized
INFO - 2018-10-15 15:44:24 --> Helper loaded: url_helper
INFO - 2018-10-15 15:44:24 --> Helper loaded: form_helper
INFO - 2018-10-15 15:44:24 --> Helper loaded: language_helper
DEBUG - 2018-10-15 15:44:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-15 15:44:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-15 15:44:24 --> User Agent Class Initialized
INFO - 2018-10-15 15:44:24 --> Controller Class Initialized
INFO - 2018-10-15 15:44:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-15 15:44:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-15 15:44:24 --> Pixel_Model class loaded
INFO - 2018-10-15 15:44:24 --> Database Driver Class Initialized
INFO - 2018-10-15 15:44:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:44:24 --> Database Driver Class Initialized
INFO - 2018-10-15 15:44:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:44:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-15 15:44:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-15 15:44:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-15 15:44:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-15 15:44:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-15 15:44:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-15 15:44:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/marriage.php
INFO - 2018-10-15 15:44:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-15 15:44:24 --> Final output sent to browser
DEBUG - 2018-10-15 15:44:24 --> Total execution time: 0.0447
INFO - 2018-10-15 15:44:31 --> Config Class Initialized
INFO - 2018-10-15 15:44:31 --> Hooks Class Initialized
DEBUG - 2018-10-15 15:44:31 --> UTF-8 Support Enabled
INFO - 2018-10-15 15:44:31 --> Utf8 Class Initialized
INFO - 2018-10-15 15:44:31 --> URI Class Initialized
INFO - 2018-10-15 15:44:31 --> Router Class Initialized
INFO - 2018-10-15 15:44:31 --> Output Class Initialized
INFO - 2018-10-15 15:44:31 --> Security Class Initialized
DEBUG - 2018-10-15 15:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-15 15:44:31 --> CSRF cookie sent
INFO - 2018-10-15 15:44:31 --> Input Class Initialized
INFO - 2018-10-15 15:44:31 --> Language Class Initialized
INFO - 2018-10-15 15:44:31 --> Loader Class Initialized
INFO - 2018-10-15 15:44:31 --> Helper loaded: url_helper
INFO - 2018-10-15 15:44:31 --> Helper loaded: form_helper
INFO - 2018-10-15 15:44:31 --> Helper loaded: language_helper
DEBUG - 2018-10-15 15:44:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-15 15:44:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-15 15:44:31 --> User Agent Class Initialized
INFO - 2018-10-15 15:44:31 --> Controller Class Initialized
INFO - 2018-10-15 15:44:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-15 15:44:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-15 15:44:31 --> Pixel_Model class loaded
INFO - 2018-10-15 15:44:31 --> Database Driver Class Initialized
INFO - 2018-10-15 15:44:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:44:31 --> Database Driver Class Initialized
INFO - 2018-10-15 15:44:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:44:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-15 15:44:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-15 15:44:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-15 15:44:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-15 15:44:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-15 15:44:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-15 15:44:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-15 15:44:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-15 15:44:31 --> Final output sent to browser
DEBUG - 2018-10-15 15:44:31 --> Total execution time: 0.0396
INFO - 2018-10-15 15:44:33 --> Config Class Initialized
INFO - 2018-10-15 15:44:33 --> Hooks Class Initialized
DEBUG - 2018-10-15 15:44:33 --> UTF-8 Support Enabled
INFO - 2018-10-15 15:44:33 --> Utf8 Class Initialized
INFO - 2018-10-15 15:44:33 --> URI Class Initialized
INFO - 2018-10-15 15:44:33 --> Router Class Initialized
INFO - 2018-10-15 15:44:33 --> Output Class Initialized
INFO - 2018-10-15 15:44:33 --> Security Class Initialized
DEBUG - 2018-10-15 15:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-15 15:44:33 --> CSRF cookie sent
INFO - 2018-10-15 15:44:33 --> Input Class Initialized
INFO - 2018-10-15 15:44:33 --> Language Class Initialized
INFO - 2018-10-15 15:44:33 --> Loader Class Initialized
INFO - 2018-10-15 15:44:33 --> Helper loaded: url_helper
INFO - 2018-10-15 15:44:33 --> Helper loaded: form_helper
INFO - 2018-10-15 15:44:33 --> Helper loaded: language_helper
DEBUG - 2018-10-15 15:44:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-15 15:44:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-15 15:44:33 --> User Agent Class Initialized
INFO - 2018-10-15 15:44:33 --> Controller Class Initialized
INFO - 2018-10-15 15:44:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-15 15:44:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-15 15:44:33 --> Pixel_Model class loaded
INFO - 2018-10-15 15:44:33 --> Database Driver Class Initialized
INFO - 2018-10-15 15:44:33 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:44:33 --> Database Driver Class Initialized
INFO - 2018-10-15 15:44:33 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:44:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-15 15:44:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-15 15:44:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-10-15 15:44:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-15 15:44:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-15 15:44:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-15 15:44:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-15 15:44:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-10-15 15:44:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-15 15:44:33 --> Final output sent to browser
DEBUG - 2018-10-15 15:44:33 --> Total execution time: 0.0430
INFO - 2018-10-15 15:44:40 --> Config Class Initialized
INFO - 2018-10-15 15:44:40 --> Hooks Class Initialized
DEBUG - 2018-10-15 15:44:40 --> UTF-8 Support Enabled
INFO - 2018-10-15 15:44:40 --> Utf8 Class Initialized
INFO - 2018-10-15 15:44:40 --> URI Class Initialized
INFO - 2018-10-15 15:44:40 --> Router Class Initialized
INFO - 2018-10-15 15:44:40 --> Output Class Initialized
INFO - 2018-10-15 15:44:40 --> Security Class Initialized
DEBUG - 2018-10-15 15:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-15 15:44:40 --> CSRF cookie sent
INFO - 2018-10-15 15:44:40 --> CSRF token verified
INFO - 2018-10-15 15:44:40 --> Input Class Initialized
INFO - 2018-10-15 15:44:40 --> Language Class Initialized
INFO - 2018-10-15 15:44:40 --> Loader Class Initialized
INFO - 2018-10-15 15:44:40 --> Helper loaded: url_helper
INFO - 2018-10-15 15:44:40 --> Helper loaded: form_helper
INFO - 2018-10-15 15:44:40 --> Helper loaded: language_helper
DEBUG - 2018-10-15 15:44:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-15 15:44:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-15 15:44:40 --> User Agent Class Initialized
INFO - 2018-10-15 15:44:40 --> Controller Class Initialized
INFO - 2018-10-15 15:44:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-15 15:44:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-15 15:44:40 --> Pixel_Model class loaded
INFO - 2018-10-15 15:44:40 --> Database Driver Class Initialized
INFO - 2018-10-15 15:44:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:44:40 --> Form Validation Class Initialized
INFO - 2018-10-15 15:44:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-15 15:44:40 --> Database Driver Class Initialized
INFO - 2018-10-15 15:44:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:44:40 --> Config Class Initialized
INFO - 2018-10-15 15:44:40 --> Hooks Class Initialized
DEBUG - 2018-10-15 15:44:40 --> UTF-8 Support Enabled
INFO - 2018-10-15 15:44:40 --> Utf8 Class Initialized
INFO - 2018-10-15 15:44:40 --> URI Class Initialized
INFO - 2018-10-15 15:44:40 --> Router Class Initialized
INFO - 2018-10-15 15:44:40 --> Output Class Initialized
INFO - 2018-10-15 15:44:40 --> Security Class Initialized
DEBUG - 2018-10-15 15:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-15 15:44:40 --> CSRF cookie sent
INFO - 2018-10-15 15:44:40 --> Input Class Initialized
INFO - 2018-10-15 15:44:40 --> Language Class Initialized
INFO - 2018-10-15 15:44:40 --> Loader Class Initialized
INFO - 2018-10-15 15:44:40 --> Helper loaded: url_helper
INFO - 2018-10-15 15:44:40 --> Helper loaded: form_helper
INFO - 2018-10-15 15:44:40 --> Helper loaded: language_helper
DEBUG - 2018-10-15 15:44:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-15 15:44:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-15 15:44:40 --> User Agent Class Initialized
INFO - 2018-10-15 15:44:40 --> Controller Class Initialized
INFO - 2018-10-15 15:44:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-15 15:44:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-15 15:44:40 --> Pixel_Model class loaded
INFO - 2018-10-15 15:44:40 --> Database Driver Class Initialized
INFO - 2018-10-15 15:44:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:44:40 --> Database Driver Class Initialized
INFO - 2018-10-15 15:44:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:44:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-15 15:44:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-15 15:44:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-15 15:44:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-15 15:44:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-15 15:44:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-15 15:44:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-15 15:44:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-15 15:44:40 --> Final output sent to browser
DEBUG - 2018-10-15 15:44:40 --> Total execution time: 0.0596
INFO - 2018-10-15 15:44:42 --> Config Class Initialized
INFO - 2018-10-15 15:44:42 --> Hooks Class Initialized
DEBUG - 2018-10-15 15:44:42 --> UTF-8 Support Enabled
INFO - 2018-10-15 15:44:42 --> Utf8 Class Initialized
INFO - 2018-10-15 15:44:42 --> URI Class Initialized
INFO - 2018-10-15 15:44:42 --> Router Class Initialized
INFO - 2018-10-15 15:44:42 --> Output Class Initialized
INFO - 2018-10-15 15:44:42 --> Security Class Initialized
DEBUG - 2018-10-15 15:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-15 15:44:42 --> CSRF cookie sent
INFO - 2018-10-15 15:44:42 --> CSRF token verified
INFO - 2018-10-15 15:44:42 --> Input Class Initialized
INFO - 2018-10-15 15:44:42 --> Language Class Initialized
INFO - 2018-10-15 15:44:42 --> Loader Class Initialized
INFO - 2018-10-15 15:44:42 --> Helper loaded: url_helper
INFO - 2018-10-15 15:44:42 --> Helper loaded: form_helper
INFO - 2018-10-15 15:44:42 --> Helper loaded: language_helper
DEBUG - 2018-10-15 15:44:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-15 15:44:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-15 15:44:42 --> User Agent Class Initialized
INFO - 2018-10-15 15:44:42 --> Controller Class Initialized
INFO - 2018-10-15 15:44:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-15 15:44:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-15 15:44:42 --> Pixel_Model class loaded
INFO - 2018-10-15 15:44:42 --> Database Driver Class Initialized
INFO - 2018-10-15 15:44:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:44:42 --> Form Validation Class Initialized
INFO - 2018-10-15 15:44:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-15 15:44:42 --> Database Driver Class Initialized
INFO - 2018-10-15 15:44:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:44:42 --> Config Class Initialized
INFO - 2018-10-15 15:44:42 --> Hooks Class Initialized
DEBUG - 2018-10-15 15:44:42 --> UTF-8 Support Enabled
INFO - 2018-10-15 15:44:42 --> Utf8 Class Initialized
INFO - 2018-10-15 15:44:42 --> URI Class Initialized
INFO - 2018-10-15 15:44:42 --> Router Class Initialized
INFO - 2018-10-15 15:44:42 --> Output Class Initialized
INFO - 2018-10-15 15:44:42 --> Security Class Initialized
DEBUG - 2018-10-15 15:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-15 15:44:42 --> CSRF cookie sent
INFO - 2018-10-15 15:44:42 --> Input Class Initialized
INFO - 2018-10-15 15:44:42 --> Language Class Initialized
INFO - 2018-10-15 15:44:42 --> Loader Class Initialized
INFO - 2018-10-15 15:44:42 --> Helper loaded: url_helper
INFO - 2018-10-15 15:44:42 --> Helper loaded: form_helper
INFO - 2018-10-15 15:44:42 --> Helper loaded: language_helper
DEBUG - 2018-10-15 15:44:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-15 15:44:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-15 15:44:42 --> User Agent Class Initialized
INFO - 2018-10-15 15:44:42 --> Controller Class Initialized
INFO - 2018-10-15 15:44:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-15 15:44:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-15 15:44:42 --> Pixel_Model class loaded
INFO - 2018-10-15 15:44:42 --> Database Driver Class Initialized
INFO - 2018-10-15 15:44:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:44:42 --> Database Driver Class Initialized
INFO - 2018-10-15 15:44:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:44:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-15 15:44:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-15 15:44:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-15 15:44:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-15 15:44:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-15 15:44:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-15 15:44:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/marriage.php
INFO - 2018-10-15 15:44:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-15 15:44:42 --> Final output sent to browser
DEBUG - 2018-10-15 15:44:42 --> Total execution time: 0.0416
INFO - 2018-10-15 15:44:49 --> Config Class Initialized
INFO - 2018-10-15 15:44:49 --> Hooks Class Initialized
DEBUG - 2018-10-15 15:44:49 --> UTF-8 Support Enabled
INFO - 2018-10-15 15:44:49 --> Utf8 Class Initialized
INFO - 2018-10-15 15:44:49 --> URI Class Initialized
INFO - 2018-10-15 15:44:49 --> Router Class Initialized
INFO - 2018-10-15 15:44:49 --> Output Class Initialized
INFO - 2018-10-15 15:44:49 --> Security Class Initialized
DEBUG - 2018-10-15 15:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-15 15:44:49 --> CSRF cookie sent
INFO - 2018-10-15 15:44:49 --> Input Class Initialized
INFO - 2018-10-15 15:44:49 --> Language Class Initialized
INFO - 2018-10-15 15:44:49 --> Loader Class Initialized
INFO - 2018-10-15 15:44:49 --> Helper loaded: url_helper
INFO - 2018-10-15 15:44:49 --> Helper loaded: form_helper
INFO - 2018-10-15 15:44:49 --> Helper loaded: language_helper
DEBUG - 2018-10-15 15:44:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-15 15:44:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-15 15:44:49 --> User Agent Class Initialized
INFO - 2018-10-15 15:44:49 --> Controller Class Initialized
INFO - 2018-10-15 15:44:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-15 15:44:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-15 15:44:49 --> Pixel_Model class loaded
INFO - 2018-10-15 15:44:49 --> Database Driver Class Initialized
INFO - 2018-10-15 15:44:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:44:49 --> Database Driver Class Initialized
INFO - 2018-10-15 15:44:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:44:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-15 15:44:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-15 15:44:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-15 15:44:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-15 15:44:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-15 15:44:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-15 15:44:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-15 15:44:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-15 15:44:49 --> Final output sent to browser
DEBUG - 2018-10-15 15:44:49 --> Total execution time: 0.0506
INFO - 2018-10-15 15:44:50 --> Config Class Initialized
INFO - 2018-10-15 15:44:50 --> Hooks Class Initialized
DEBUG - 2018-10-15 15:44:50 --> UTF-8 Support Enabled
INFO - 2018-10-15 15:44:50 --> Utf8 Class Initialized
INFO - 2018-10-15 15:44:50 --> URI Class Initialized
INFO - 2018-10-15 15:44:50 --> Router Class Initialized
INFO - 2018-10-15 15:44:50 --> Output Class Initialized
INFO - 2018-10-15 15:44:50 --> Security Class Initialized
DEBUG - 2018-10-15 15:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-15 15:44:50 --> CSRF cookie sent
INFO - 2018-10-15 15:44:50 --> Input Class Initialized
INFO - 2018-10-15 15:44:50 --> Language Class Initialized
INFO - 2018-10-15 15:44:50 --> Loader Class Initialized
INFO - 2018-10-15 15:44:50 --> Helper loaded: url_helper
INFO - 2018-10-15 15:44:50 --> Helper loaded: form_helper
INFO - 2018-10-15 15:44:50 --> Helper loaded: language_helper
DEBUG - 2018-10-15 15:44:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-15 15:44:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-15 15:44:50 --> User Agent Class Initialized
INFO - 2018-10-15 15:44:50 --> Controller Class Initialized
INFO - 2018-10-15 15:44:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-15 15:44:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-15 15:44:50 --> Pixel_Model class loaded
INFO - 2018-10-15 15:44:50 --> Database Driver Class Initialized
INFO - 2018-10-15 15:44:50 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:44:50 --> Database Driver Class Initialized
INFO - 2018-10-15 15:44:50 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:44:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-15 15:44:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-15 15:44:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-10-15 15:44:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-15 15:44:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-15 15:44:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-15 15:44:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-15 15:44:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-10-15 15:44:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-15 15:44:50 --> Final output sent to browser
DEBUG - 2018-10-15 15:44:50 --> Total execution time: 0.0405
INFO - 2018-10-15 15:45:11 --> Config Class Initialized
INFO - 2018-10-15 15:45:11 --> Hooks Class Initialized
DEBUG - 2018-10-15 15:45:11 --> UTF-8 Support Enabled
INFO - 2018-10-15 15:45:11 --> Utf8 Class Initialized
INFO - 2018-10-15 15:45:11 --> URI Class Initialized
INFO - 2018-10-15 15:45:11 --> Router Class Initialized
INFO - 2018-10-15 15:45:11 --> Output Class Initialized
INFO - 2018-10-15 15:45:11 --> Security Class Initialized
DEBUG - 2018-10-15 15:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-15 15:45:11 --> CSRF cookie sent
INFO - 2018-10-15 15:45:11 --> CSRF token verified
INFO - 2018-10-15 15:45:11 --> Input Class Initialized
INFO - 2018-10-15 15:45:11 --> Language Class Initialized
INFO - 2018-10-15 15:45:11 --> Loader Class Initialized
INFO - 2018-10-15 15:45:11 --> Helper loaded: url_helper
INFO - 2018-10-15 15:45:11 --> Helper loaded: form_helper
INFO - 2018-10-15 15:45:11 --> Helper loaded: language_helper
DEBUG - 2018-10-15 15:45:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-15 15:45:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-15 15:45:11 --> User Agent Class Initialized
INFO - 2018-10-15 15:45:12 --> Controller Class Initialized
INFO - 2018-10-15 15:45:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-15 15:45:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-15 15:45:12 --> Pixel_Model class loaded
INFO - 2018-10-15 15:45:12 --> Database Driver Class Initialized
INFO - 2018-10-15 15:45:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:45:12 --> Form Validation Class Initialized
INFO - 2018-10-15 15:45:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-15 15:45:12 --> Database Driver Class Initialized
INFO - 2018-10-15 15:45:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:45:12 --> Config Class Initialized
INFO - 2018-10-15 15:45:12 --> Hooks Class Initialized
DEBUG - 2018-10-15 15:45:12 --> UTF-8 Support Enabled
INFO - 2018-10-15 15:45:12 --> Utf8 Class Initialized
INFO - 2018-10-15 15:45:12 --> URI Class Initialized
INFO - 2018-10-15 15:45:12 --> Router Class Initialized
INFO - 2018-10-15 15:45:12 --> Output Class Initialized
INFO - 2018-10-15 15:45:12 --> Security Class Initialized
DEBUG - 2018-10-15 15:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-15 15:45:12 --> CSRF cookie sent
INFO - 2018-10-15 15:45:12 --> Input Class Initialized
INFO - 2018-10-15 15:45:12 --> Language Class Initialized
INFO - 2018-10-15 15:45:12 --> Loader Class Initialized
INFO - 2018-10-15 15:45:12 --> Helper loaded: url_helper
INFO - 2018-10-15 15:45:12 --> Helper loaded: form_helper
INFO - 2018-10-15 15:45:12 --> Helper loaded: language_helper
DEBUG - 2018-10-15 15:45:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-15 15:45:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-15 15:45:12 --> User Agent Class Initialized
INFO - 2018-10-15 15:45:12 --> Controller Class Initialized
INFO - 2018-10-15 15:45:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-15 15:45:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-15 15:45:12 --> Pixel_Model class loaded
INFO - 2018-10-15 15:45:12 --> Database Driver Class Initialized
INFO - 2018-10-15 15:45:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:45:12 --> Database Driver Class Initialized
INFO - 2018-10-15 15:45:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:45:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-15 15:45:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-15 15:45:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-15 15:45:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-15 15:45:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-15 15:45:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-15 15:45:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-15 15:45:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-15 15:45:12 --> Final output sent to browser
DEBUG - 2018-10-15 15:45:12 --> Total execution time: 0.0414
INFO - 2018-10-15 15:45:13 --> Config Class Initialized
INFO - 2018-10-15 15:45:13 --> Hooks Class Initialized
DEBUG - 2018-10-15 15:45:13 --> UTF-8 Support Enabled
INFO - 2018-10-15 15:45:13 --> Utf8 Class Initialized
INFO - 2018-10-15 15:45:13 --> URI Class Initialized
INFO - 2018-10-15 15:45:13 --> Router Class Initialized
INFO - 2018-10-15 15:45:13 --> Output Class Initialized
INFO - 2018-10-15 15:45:13 --> Security Class Initialized
DEBUG - 2018-10-15 15:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-15 15:45:13 --> CSRF cookie sent
INFO - 2018-10-15 15:45:13 --> CSRF token verified
INFO - 2018-10-15 15:45:13 --> Input Class Initialized
INFO - 2018-10-15 15:45:13 --> Language Class Initialized
INFO - 2018-10-15 15:45:13 --> Loader Class Initialized
INFO - 2018-10-15 15:45:13 --> Helper loaded: url_helper
INFO - 2018-10-15 15:45:13 --> Helper loaded: form_helper
INFO - 2018-10-15 15:45:13 --> Helper loaded: language_helper
DEBUG - 2018-10-15 15:45:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-15 15:45:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-15 15:45:13 --> User Agent Class Initialized
INFO - 2018-10-15 15:45:13 --> Controller Class Initialized
INFO - 2018-10-15 15:45:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-15 15:45:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-15 15:45:13 --> Pixel_Model class loaded
INFO - 2018-10-15 15:45:13 --> Database Driver Class Initialized
INFO - 2018-10-15 15:45:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:45:13 --> Form Validation Class Initialized
INFO - 2018-10-15 15:45:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-15 15:45:13 --> Database Driver Class Initialized
INFO - 2018-10-15 15:45:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:45:13 --> Config Class Initialized
INFO - 2018-10-15 15:45:13 --> Hooks Class Initialized
DEBUG - 2018-10-15 15:45:13 --> UTF-8 Support Enabled
INFO - 2018-10-15 15:45:13 --> Utf8 Class Initialized
INFO - 2018-10-15 15:45:13 --> URI Class Initialized
INFO - 2018-10-15 15:45:13 --> Router Class Initialized
INFO - 2018-10-15 15:45:13 --> Output Class Initialized
INFO - 2018-10-15 15:45:13 --> Security Class Initialized
DEBUG - 2018-10-15 15:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-15 15:45:13 --> CSRF cookie sent
INFO - 2018-10-15 15:45:13 --> Input Class Initialized
INFO - 2018-10-15 15:45:13 --> Language Class Initialized
INFO - 2018-10-15 15:45:13 --> Loader Class Initialized
INFO - 2018-10-15 15:45:13 --> Helper loaded: url_helper
INFO - 2018-10-15 15:45:13 --> Helper loaded: form_helper
INFO - 2018-10-15 15:45:13 --> Helper loaded: language_helper
DEBUG - 2018-10-15 15:45:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-15 15:45:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-15 15:45:13 --> User Agent Class Initialized
INFO - 2018-10-15 15:45:13 --> Controller Class Initialized
INFO - 2018-10-15 15:45:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-15 15:45:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-15 15:45:13 --> Pixel_Model class loaded
INFO - 2018-10-15 15:45:13 --> Database Driver Class Initialized
INFO - 2018-10-15 15:45:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:45:13 --> Database Driver Class Initialized
INFO - 2018-10-15 15:45:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:45:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-15 15:45:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-15 15:45:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-15 15:45:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-15 15:45:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-15 15:45:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-15 15:45:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/marriage.php
INFO - 2018-10-15 15:45:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-15 15:45:13 --> Final output sent to browser
DEBUG - 2018-10-15 15:45:13 --> Total execution time: 0.0462
INFO - 2018-10-15 15:45:15 --> Config Class Initialized
INFO - 2018-10-15 15:45:15 --> Hooks Class Initialized
DEBUG - 2018-10-15 15:45:15 --> UTF-8 Support Enabled
INFO - 2018-10-15 15:45:15 --> Utf8 Class Initialized
INFO - 2018-10-15 15:45:15 --> URI Class Initialized
INFO - 2018-10-15 15:45:15 --> Router Class Initialized
INFO - 2018-10-15 15:45:15 --> Output Class Initialized
INFO - 2018-10-15 15:45:15 --> Security Class Initialized
DEBUG - 2018-10-15 15:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-15 15:45:15 --> CSRF cookie sent
INFO - 2018-10-15 15:45:15 --> CSRF token verified
INFO - 2018-10-15 15:45:15 --> Input Class Initialized
INFO - 2018-10-15 15:45:15 --> Language Class Initialized
INFO - 2018-10-15 15:45:15 --> Loader Class Initialized
INFO - 2018-10-15 15:45:15 --> Helper loaded: url_helper
INFO - 2018-10-15 15:45:15 --> Helper loaded: form_helper
INFO - 2018-10-15 15:45:15 --> Helper loaded: language_helper
DEBUG - 2018-10-15 15:45:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-15 15:45:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-15 15:45:15 --> User Agent Class Initialized
INFO - 2018-10-15 15:45:15 --> Controller Class Initialized
INFO - 2018-10-15 15:45:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-15 15:45:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-15 15:45:15 --> Pixel_Model class loaded
INFO - 2018-10-15 15:45:15 --> Database Driver Class Initialized
INFO - 2018-10-15 15:45:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:45:15 --> Form Validation Class Initialized
INFO - 2018-10-15 15:45:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-15 15:45:15 --> Database Driver Class Initialized
INFO - 2018-10-15 15:45:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:45:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-15 15:45:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-15 15:45:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-15 15:45:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-15 15:45:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-15 15:45:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_errors.php
INFO - 2018-10-15 15:45:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-15 15:45:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/marriage.php
INFO - 2018-10-15 15:45:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-15 15:45:15 --> Final output sent to browser
DEBUG - 2018-10-15 15:45:15 --> Total execution time: 0.0438
INFO - 2018-10-15 15:45:22 --> Config Class Initialized
INFO - 2018-10-15 15:45:22 --> Hooks Class Initialized
DEBUG - 2018-10-15 15:45:22 --> UTF-8 Support Enabled
INFO - 2018-10-15 15:45:22 --> Utf8 Class Initialized
INFO - 2018-10-15 15:45:22 --> URI Class Initialized
INFO - 2018-10-15 15:45:22 --> Router Class Initialized
INFO - 2018-10-15 15:45:22 --> Output Class Initialized
INFO - 2018-10-15 15:45:22 --> Security Class Initialized
DEBUG - 2018-10-15 15:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-15 15:45:22 --> CSRF cookie sent
INFO - 2018-10-15 15:45:22 --> CSRF token verified
INFO - 2018-10-15 15:45:22 --> Input Class Initialized
INFO - 2018-10-15 15:45:22 --> Language Class Initialized
INFO - 2018-10-15 15:45:22 --> Loader Class Initialized
INFO - 2018-10-15 15:45:22 --> Helper loaded: url_helper
INFO - 2018-10-15 15:45:22 --> Helper loaded: form_helper
INFO - 2018-10-15 15:45:22 --> Helper loaded: language_helper
DEBUG - 2018-10-15 15:45:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-15 15:45:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-15 15:45:22 --> User Agent Class Initialized
INFO - 2018-10-15 15:45:22 --> Controller Class Initialized
INFO - 2018-10-15 15:45:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-15 15:45:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-15 15:45:22 --> Pixel_Model class loaded
INFO - 2018-10-15 15:45:22 --> Database Driver Class Initialized
INFO - 2018-10-15 15:45:22 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:45:22 --> Form Validation Class Initialized
INFO - 2018-10-15 15:45:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-15 15:45:22 --> Database Driver Class Initialized
INFO - 2018-10-15 15:45:22 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:45:22 --> Config Class Initialized
INFO - 2018-10-15 15:45:22 --> Hooks Class Initialized
DEBUG - 2018-10-15 15:45:22 --> UTF-8 Support Enabled
INFO - 2018-10-15 15:45:22 --> Utf8 Class Initialized
INFO - 2018-10-15 15:45:22 --> URI Class Initialized
INFO - 2018-10-15 15:45:22 --> Router Class Initialized
INFO - 2018-10-15 15:45:22 --> Output Class Initialized
INFO - 2018-10-15 15:45:22 --> Security Class Initialized
DEBUG - 2018-10-15 15:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-15 15:45:22 --> CSRF cookie sent
INFO - 2018-10-15 15:45:22 --> Input Class Initialized
INFO - 2018-10-15 15:45:22 --> Language Class Initialized
INFO - 2018-10-15 15:45:22 --> Loader Class Initialized
INFO - 2018-10-15 15:45:22 --> Helper loaded: url_helper
INFO - 2018-10-15 15:45:22 --> Helper loaded: form_helper
INFO - 2018-10-15 15:45:22 --> Helper loaded: language_helper
DEBUG - 2018-10-15 15:45:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-15 15:45:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-15 15:45:22 --> User Agent Class Initialized
INFO - 2018-10-15 15:45:22 --> Controller Class Initialized
INFO - 2018-10-15 15:45:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-15 15:45:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-15 15:45:22 --> Pixel_Model class loaded
INFO - 2018-10-15 15:45:22 --> Database Driver Class Initialized
INFO - 2018-10-15 15:45:22 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:45:22 --> Database Driver Class Initialized
INFO - 2018-10-15 15:45:22 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:45:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-15 15:45:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-15 15:45:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-15 15:45:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-15 15:45:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-15 15:45:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-15 15:45:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-10-15 15:45:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-15 15:45:22 --> Final output sent to browser
DEBUG - 2018-10-15 15:45:22 --> Total execution time: 0.0422
INFO - 2018-10-15 15:45:28 --> Config Class Initialized
INFO - 2018-10-15 15:45:28 --> Hooks Class Initialized
DEBUG - 2018-10-15 15:45:28 --> UTF-8 Support Enabled
INFO - 2018-10-15 15:45:28 --> Utf8 Class Initialized
INFO - 2018-10-15 15:45:28 --> URI Class Initialized
INFO - 2018-10-15 15:45:28 --> Router Class Initialized
INFO - 2018-10-15 15:45:28 --> Output Class Initialized
INFO - 2018-10-15 15:45:28 --> Security Class Initialized
DEBUG - 2018-10-15 15:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-15 15:45:28 --> CSRF cookie sent
INFO - 2018-10-15 15:45:28 --> Input Class Initialized
INFO - 2018-10-15 15:45:28 --> Language Class Initialized
INFO - 2018-10-15 15:45:28 --> Loader Class Initialized
INFO - 2018-10-15 15:45:28 --> Helper loaded: url_helper
INFO - 2018-10-15 15:45:28 --> Helper loaded: form_helper
INFO - 2018-10-15 15:45:28 --> Helper loaded: language_helper
DEBUG - 2018-10-15 15:45:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-15 15:45:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-15 15:45:28 --> User Agent Class Initialized
INFO - 2018-10-15 15:45:28 --> Controller Class Initialized
INFO - 2018-10-15 15:45:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-15 15:45:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-15 15:45:28 --> Pixel_Model class loaded
INFO - 2018-10-15 15:45:28 --> Database Driver Class Initialized
INFO - 2018-10-15 15:45:28 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:45:28 --> Database Driver Class Initialized
INFO - 2018-10-15 15:45:28 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:45:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-15 15:45:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-15 15:45:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-15 15:45:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-15 15:45:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-10-15 15:45:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-15 15:45:28 --> Final output sent to browser
DEBUG - 2018-10-15 15:45:28 --> Total execution time: 0.0551
INFO - 2018-10-15 15:45:36 --> Config Class Initialized
INFO - 2018-10-15 15:45:36 --> Hooks Class Initialized
DEBUG - 2018-10-15 15:45:36 --> UTF-8 Support Enabled
INFO - 2018-10-15 15:45:36 --> Utf8 Class Initialized
INFO - 2018-10-15 15:45:36 --> URI Class Initialized
INFO - 2018-10-15 15:45:36 --> Router Class Initialized
INFO - 2018-10-15 15:45:36 --> Output Class Initialized
INFO - 2018-10-15 15:45:36 --> Security Class Initialized
DEBUG - 2018-10-15 15:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-15 15:45:36 --> CSRF cookie sent
INFO - 2018-10-15 15:45:36 --> Input Class Initialized
INFO - 2018-10-15 15:45:36 --> Language Class Initialized
INFO - 2018-10-15 15:45:36 --> Loader Class Initialized
INFO - 2018-10-15 15:45:36 --> Helper loaded: url_helper
INFO - 2018-10-15 15:45:36 --> Helper loaded: form_helper
INFO - 2018-10-15 15:45:36 --> Helper loaded: language_helper
DEBUG - 2018-10-15 15:45:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-15 15:45:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-15 15:45:36 --> User Agent Class Initialized
INFO - 2018-10-15 15:45:36 --> Controller Class Initialized
INFO - 2018-10-15 15:45:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-15 15:45:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-15 15:45:36 --> Pixel_Model class loaded
INFO - 2018-10-15 15:45:36 --> Database Driver Class Initialized
INFO - 2018-10-15 15:45:36 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 15:45:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-15 15:45:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-15 15:45:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-15 15:45:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-15 15:45:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/contact_us.php
INFO - 2018-10-15 15:45:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-15 15:45:36 --> Final output sent to browser
DEBUG - 2018-10-15 15:45:36 --> Total execution time: 0.0661
INFO - 2018-10-15 20:41:59 --> Config Class Initialized
INFO - 2018-10-15 20:41:59 --> Hooks Class Initialized
DEBUG - 2018-10-15 20:41:59 --> UTF-8 Support Enabled
INFO - 2018-10-15 20:41:59 --> Utf8 Class Initialized
INFO - 2018-10-15 20:41:59 --> URI Class Initialized
DEBUG - 2018-10-15 20:41:59 --> No URI present. Default controller set.
INFO - 2018-10-15 20:41:59 --> Router Class Initialized
INFO - 2018-10-15 20:41:59 --> Output Class Initialized
INFO - 2018-10-15 20:41:59 --> Security Class Initialized
DEBUG - 2018-10-15 20:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-15 20:41:59 --> CSRF cookie sent
INFO - 2018-10-15 20:41:59 --> Input Class Initialized
INFO - 2018-10-15 20:41:59 --> Language Class Initialized
INFO - 2018-10-15 20:41:59 --> Loader Class Initialized
INFO - 2018-10-15 20:41:59 --> Helper loaded: url_helper
INFO - 2018-10-15 20:41:59 --> Helper loaded: form_helper
INFO - 2018-10-15 20:41:59 --> Helper loaded: language_helper
DEBUG - 2018-10-15 20:41:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-15 20:41:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-15 20:41:59 --> User Agent Class Initialized
INFO - 2018-10-15 20:41:59 --> Controller Class Initialized
INFO - 2018-10-15 20:41:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-15 20:41:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-15 20:41:59 --> Pixel_Model class loaded
INFO - 2018-10-15 20:41:59 --> Database Driver Class Initialized
INFO - 2018-10-15 20:41:59 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 20:41:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-15 20:41:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-15 20:41:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-15 20:41:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-15 20:41:59 --> Final output sent to browser
DEBUG - 2018-10-15 20:41:59 --> Total execution time: 0.0379
INFO - 2018-10-15 20:42:00 --> Config Class Initialized
INFO - 2018-10-15 20:42:00 --> Hooks Class Initialized
DEBUG - 2018-10-15 20:42:00 --> UTF-8 Support Enabled
INFO - 2018-10-15 20:42:00 --> Utf8 Class Initialized
INFO - 2018-10-15 20:42:00 --> URI Class Initialized
DEBUG - 2018-10-15 20:42:00 --> No URI present. Default controller set.
INFO - 2018-10-15 20:42:00 --> Router Class Initialized
INFO - 2018-10-15 20:42:00 --> Output Class Initialized
INFO - 2018-10-15 20:42:00 --> Security Class Initialized
DEBUG - 2018-10-15 20:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-15 20:42:00 --> CSRF cookie sent
INFO - 2018-10-15 20:42:00 --> Input Class Initialized
INFO - 2018-10-15 20:42:00 --> Language Class Initialized
INFO - 2018-10-15 20:42:00 --> Loader Class Initialized
INFO - 2018-10-15 20:42:00 --> Helper loaded: url_helper
INFO - 2018-10-15 20:42:00 --> Helper loaded: form_helper
INFO - 2018-10-15 20:42:00 --> Helper loaded: language_helper
DEBUG - 2018-10-15 20:42:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-15 20:42:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-15 20:42:00 --> User Agent Class Initialized
INFO - 2018-10-15 20:42:00 --> Controller Class Initialized
INFO - 2018-10-15 20:42:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-15 20:42:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-15 20:42:00 --> Pixel_Model class loaded
INFO - 2018-10-15 20:42:00 --> Database Driver Class Initialized
INFO - 2018-10-15 20:42:00 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 20:42:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-15 20:42:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-15 20:42:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-15 20:42:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-15 20:42:00 --> Final output sent to browser
DEBUG - 2018-10-15 20:42:00 --> Total execution time: 0.0372
INFO - 2018-10-15 20:42:04 --> Config Class Initialized
INFO - 2018-10-15 20:42:04 --> Hooks Class Initialized
DEBUG - 2018-10-15 20:42:04 --> UTF-8 Support Enabled
INFO - 2018-10-15 20:42:04 --> Utf8 Class Initialized
INFO - 2018-10-15 20:42:04 --> URI Class Initialized
INFO - 2018-10-15 20:42:04 --> Router Class Initialized
INFO - 2018-10-15 20:42:04 --> Output Class Initialized
INFO - 2018-10-15 20:42:04 --> Security Class Initialized
DEBUG - 2018-10-15 20:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-15 20:42:04 --> CSRF cookie sent
INFO - 2018-10-15 20:42:04 --> CSRF token verified
INFO - 2018-10-15 20:42:04 --> Input Class Initialized
INFO - 2018-10-15 20:42:04 --> Language Class Initialized
INFO - 2018-10-15 20:42:04 --> Loader Class Initialized
INFO - 2018-10-15 20:42:04 --> Helper loaded: url_helper
INFO - 2018-10-15 20:42:04 --> Helper loaded: form_helper
INFO - 2018-10-15 20:42:04 --> Helper loaded: language_helper
DEBUG - 2018-10-15 20:42:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-15 20:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-15 20:42:04 --> User Agent Class Initialized
INFO - 2018-10-15 20:42:04 --> Controller Class Initialized
INFO - 2018-10-15 20:42:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-15 20:42:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-15 20:42:04 --> Pixel_Model class loaded
INFO - 2018-10-15 20:42:04 --> Database Driver Class Initialized
INFO - 2018-10-15 20:42:04 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 20:42:04 --> Form Validation Class Initialized
INFO - 2018-10-15 20:42:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-15 20:42:04 --> Database Driver Class Initialized
INFO - 2018-10-15 20:42:04 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 20:42:04 --> Config Class Initialized
INFO - 2018-10-15 20:42:04 --> Hooks Class Initialized
DEBUG - 2018-10-15 20:42:04 --> UTF-8 Support Enabled
INFO - 2018-10-15 20:42:04 --> Utf8 Class Initialized
INFO - 2018-10-15 20:42:04 --> URI Class Initialized
INFO - 2018-10-15 20:42:04 --> Router Class Initialized
INFO - 2018-10-15 20:42:04 --> Output Class Initialized
INFO - 2018-10-15 20:42:04 --> Security Class Initialized
DEBUG - 2018-10-15 20:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-15 20:42:04 --> CSRF cookie sent
INFO - 2018-10-15 20:42:04 --> Input Class Initialized
INFO - 2018-10-15 20:42:04 --> Language Class Initialized
INFO - 2018-10-15 20:42:04 --> Loader Class Initialized
INFO - 2018-10-15 20:42:04 --> Helper loaded: url_helper
INFO - 2018-10-15 20:42:04 --> Helper loaded: form_helper
INFO - 2018-10-15 20:42:04 --> Helper loaded: language_helper
DEBUG - 2018-10-15 20:42:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-15 20:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-15 20:42:04 --> User Agent Class Initialized
INFO - 2018-10-15 20:42:04 --> Controller Class Initialized
INFO - 2018-10-15 20:42:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-15 20:42:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-15 20:42:04 --> Pixel_Model class loaded
INFO - 2018-10-15 20:42:04 --> Database Driver Class Initialized
INFO - 2018-10-15 20:42:04 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 20:42:04 --> Database Driver Class Initialized
INFO - 2018-10-15 20:42:04 --> Model "QuestionsModel" initialized
INFO - 2018-10-15 20:42:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-15 20:42:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-15 20:42:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-15 20:42:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-15 20:42:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-15 20:42:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-15 20:42:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-15 20:42:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-15 20:42:04 --> Final output sent to browser
DEBUG - 2018-10-15 20:42:04 --> Total execution time: 0.0459

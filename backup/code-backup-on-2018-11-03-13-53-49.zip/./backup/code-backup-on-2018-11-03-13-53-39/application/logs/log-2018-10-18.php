<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-10-18 09:15:32 --> Config Class Initialized
INFO - 2018-10-18 09:15:32 --> Hooks Class Initialized
DEBUG - 2018-10-18 09:15:32 --> UTF-8 Support Enabled
INFO - 2018-10-18 09:15:32 --> Utf8 Class Initialized
INFO - 2018-10-18 09:15:32 --> URI Class Initialized
DEBUG - 2018-10-18 09:15:32 --> No URI present. Default controller set.
INFO - 2018-10-18 09:15:32 --> Router Class Initialized
INFO - 2018-10-18 09:15:32 --> Output Class Initialized
INFO - 2018-10-18 09:15:32 --> Security Class Initialized
DEBUG - 2018-10-18 09:15:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 09:15:32 --> CSRF cookie sent
INFO - 2018-10-18 09:15:32 --> Input Class Initialized
INFO - 2018-10-18 09:15:32 --> Language Class Initialized
INFO - 2018-10-18 09:15:32 --> Loader Class Initialized
INFO - 2018-10-18 09:15:32 --> Helper loaded: url_helper
INFO - 2018-10-18 09:15:32 --> Helper loaded: form_helper
INFO - 2018-10-18 09:15:32 --> Helper loaded: language_helper
DEBUG - 2018-10-18 09:15:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 09:15:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 09:15:32 --> User Agent Class Initialized
INFO - 2018-10-18 09:15:32 --> Controller Class Initialized
INFO - 2018-10-18 09:15:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 09:15:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 09:15:32 --> Pixel_Model class loaded
INFO - 2018-10-18 09:15:32 --> Database Driver Class Initialized
INFO - 2018-10-18 09:15:32 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:15:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 09:15:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 09:15:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-18 09:15:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 09:15:32 --> Final output sent to browser
DEBUG - 2018-10-18 09:15:32 --> Total execution time: 0.0432
INFO - 2018-10-18 09:18:09 --> Config Class Initialized
INFO - 2018-10-18 09:18:09 --> Hooks Class Initialized
DEBUG - 2018-10-18 09:18:09 --> UTF-8 Support Enabled
INFO - 2018-10-18 09:18:09 --> Utf8 Class Initialized
INFO - 2018-10-18 09:18:09 --> URI Class Initialized
INFO - 2018-10-18 09:18:09 --> Router Class Initialized
INFO - 2018-10-18 09:18:09 --> Output Class Initialized
INFO - 2018-10-18 09:18:09 --> Security Class Initialized
DEBUG - 2018-10-18 09:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 09:18:09 --> CSRF cookie sent
INFO - 2018-10-18 09:18:09 --> Input Class Initialized
INFO - 2018-10-18 09:18:09 --> Language Class Initialized
INFO - 2018-10-18 09:18:09 --> Loader Class Initialized
INFO - 2018-10-18 09:18:09 --> Helper loaded: url_helper
INFO - 2018-10-18 09:18:09 --> Helper loaded: form_helper
INFO - 2018-10-18 09:18:09 --> Helper loaded: language_helper
DEBUG - 2018-10-18 09:18:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 09:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 09:18:09 --> User Agent Class Initialized
INFO - 2018-10-18 09:18:09 --> Controller Class Initialized
INFO - 2018-10-18 09:18:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 09:18:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 09:18:09 --> Pixel_Model class loaded
INFO - 2018-10-18 09:18:09 --> Database Driver Class Initialized
INFO - 2018-10-18 09:18:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:18:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 09:18:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 09:18:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 09:18:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 09:18:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 09:18:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 09:18:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-10-18 09:18:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 09:18:09 --> Final output sent to browser
DEBUG - 2018-10-18 09:18:09 --> Total execution time: 0.0520
INFO - 2018-10-18 09:23:21 --> Config Class Initialized
INFO - 2018-10-18 09:23:21 --> Hooks Class Initialized
DEBUG - 2018-10-18 09:23:21 --> UTF-8 Support Enabled
INFO - 2018-10-18 09:23:21 --> Utf8 Class Initialized
INFO - 2018-10-18 09:23:21 --> URI Class Initialized
INFO - 2018-10-18 09:23:21 --> Router Class Initialized
INFO - 2018-10-18 09:23:21 --> Output Class Initialized
INFO - 2018-10-18 09:23:21 --> Security Class Initialized
DEBUG - 2018-10-18 09:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 09:23:21 --> CSRF cookie sent
INFO - 2018-10-18 09:23:21 --> CSRF token verified
INFO - 2018-10-18 09:23:21 --> Input Class Initialized
INFO - 2018-10-18 09:23:21 --> Language Class Initialized
INFO - 2018-10-18 09:23:21 --> Loader Class Initialized
INFO - 2018-10-18 09:23:21 --> Helper loaded: url_helper
INFO - 2018-10-18 09:23:21 --> Helper loaded: form_helper
INFO - 2018-10-18 09:23:21 --> Helper loaded: language_helper
DEBUG - 2018-10-18 09:23:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 09:23:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 09:23:21 --> User Agent Class Initialized
INFO - 2018-10-18 09:23:21 --> Controller Class Initialized
INFO - 2018-10-18 09:23:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 09:23:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 09:23:21 --> Pixel_Model class loaded
INFO - 2018-10-18 09:23:21 --> Database Driver Class Initialized
INFO - 2018-10-18 09:23:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:23:21 --> Form Validation Class Initialized
INFO - 2018-10-18 09:23:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 09:23:21 --> Database Driver Class Initialized
INFO - 2018-10-18 09:23:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:23:21 --> Config Class Initialized
INFO - 2018-10-18 09:23:21 --> Hooks Class Initialized
DEBUG - 2018-10-18 09:23:21 --> UTF-8 Support Enabled
INFO - 2018-10-18 09:23:21 --> Utf8 Class Initialized
INFO - 2018-10-18 09:23:21 --> URI Class Initialized
INFO - 2018-10-18 09:23:21 --> Router Class Initialized
INFO - 2018-10-18 09:23:21 --> Output Class Initialized
INFO - 2018-10-18 09:23:21 --> Security Class Initialized
DEBUG - 2018-10-18 09:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 09:23:21 --> CSRF cookie sent
INFO - 2018-10-18 09:23:21 --> Input Class Initialized
INFO - 2018-10-18 09:23:21 --> Language Class Initialized
INFO - 2018-10-18 09:23:21 --> Loader Class Initialized
INFO - 2018-10-18 09:23:21 --> Helper loaded: url_helper
INFO - 2018-10-18 09:23:21 --> Helper loaded: form_helper
INFO - 2018-10-18 09:23:21 --> Helper loaded: language_helper
DEBUG - 2018-10-18 09:23:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 09:23:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 09:23:21 --> User Agent Class Initialized
INFO - 2018-10-18 09:23:21 --> Controller Class Initialized
INFO - 2018-10-18 09:23:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 09:23:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 09:23:21 --> Pixel_Model class loaded
INFO - 2018-10-18 09:23:21 --> Database Driver Class Initialized
INFO - 2018-10-18 09:23:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:23:21 --> Database Driver Class Initialized
INFO - 2018-10-18 09:23:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:23:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 09:23:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 09:23:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 09:23:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 09:23:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 09:23:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 09:23:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-18 09:23:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 09:23:21 --> Final output sent to browser
DEBUG - 2018-10-18 09:23:21 --> Total execution time: 0.0491
INFO - 2018-10-18 09:23:32 --> Config Class Initialized
INFO - 2018-10-18 09:23:32 --> Hooks Class Initialized
DEBUG - 2018-10-18 09:23:32 --> UTF-8 Support Enabled
INFO - 2018-10-18 09:23:32 --> Utf8 Class Initialized
INFO - 2018-10-18 09:23:32 --> URI Class Initialized
INFO - 2018-10-18 09:23:32 --> Router Class Initialized
INFO - 2018-10-18 09:23:32 --> Output Class Initialized
INFO - 2018-10-18 09:23:32 --> Security Class Initialized
DEBUG - 2018-10-18 09:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 09:23:32 --> CSRF cookie sent
INFO - 2018-10-18 09:23:32 --> CSRF token verified
INFO - 2018-10-18 09:23:32 --> Input Class Initialized
INFO - 2018-10-18 09:23:32 --> Language Class Initialized
INFO - 2018-10-18 09:23:32 --> Loader Class Initialized
INFO - 2018-10-18 09:23:32 --> Helper loaded: url_helper
INFO - 2018-10-18 09:23:32 --> Helper loaded: form_helper
INFO - 2018-10-18 09:23:32 --> Helper loaded: language_helper
DEBUG - 2018-10-18 09:23:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 09:23:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 09:23:32 --> User Agent Class Initialized
INFO - 2018-10-18 09:23:32 --> Controller Class Initialized
INFO - 2018-10-18 09:23:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 09:23:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 09:23:32 --> Pixel_Model class loaded
INFO - 2018-10-18 09:23:32 --> Database Driver Class Initialized
INFO - 2018-10-18 09:23:32 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:23:32 --> Form Validation Class Initialized
INFO - 2018-10-18 09:23:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 09:23:32 --> Database Driver Class Initialized
INFO - 2018-10-18 09:23:32 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:23:32 --> Config Class Initialized
INFO - 2018-10-18 09:23:32 --> Hooks Class Initialized
DEBUG - 2018-10-18 09:23:32 --> UTF-8 Support Enabled
INFO - 2018-10-18 09:23:32 --> Utf8 Class Initialized
INFO - 2018-10-18 09:23:32 --> URI Class Initialized
INFO - 2018-10-18 09:23:32 --> Router Class Initialized
INFO - 2018-10-18 09:23:32 --> Output Class Initialized
INFO - 2018-10-18 09:23:32 --> Security Class Initialized
DEBUG - 2018-10-18 09:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 09:23:32 --> CSRF cookie sent
INFO - 2018-10-18 09:23:32 --> Input Class Initialized
INFO - 2018-10-18 09:23:32 --> Language Class Initialized
INFO - 2018-10-18 09:23:32 --> Loader Class Initialized
INFO - 2018-10-18 09:23:32 --> Helper loaded: url_helper
INFO - 2018-10-18 09:23:32 --> Helper loaded: form_helper
INFO - 2018-10-18 09:23:32 --> Helper loaded: language_helper
DEBUG - 2018-10-18 09:23:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 09:23:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 09:23:32 --> User Agent Class Initialized
INFO - 2018-10-18 09:23:32 --> Controller Class Initialized
INFO - 2018-10-18 09:23:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 09:23:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 09:23:32 --> Pixel_Model class loaded
INFO - 2018-10-18 09:23:32 --> Database Driver Class Initialized
INFO - 2018-10-18 09:23:32 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:23:32 --> Database Driver Class Initialized
INFO - 2018-10-18 09:23:32 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:23:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 09:23:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 09:23:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 09:23:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 09:23:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 09:23:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 09:23:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-10-18 09:23:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 09:23:32 --> Final output sent to browser
DEBUG - 2018-10-18 09:23:32 --> Total execution time: 0.0473
INFO - 2018-10-18 09:23:39 --> Config Class Initialized
INFO - 2018-10-18 09:23:39 --> Hooks Class Initialized
DEBUG - 2018-10-18 09:23:39 --> UTF-8 Support Enabled
INFO - 2018-10-18 09:23:39 --> Utf8 Class Initialized
INFO - 2018-10-18 09:23:39 --> URI Class Initialized
INFO - 2018-10-18 09:23:39 --> Router Class Initialized
INFO - 2018-10-18 09:23:39 --> Output Class Initialized
INFO - 2018-10-18 09:23:39 --> Security Class Initialized
DEBUG - 2018-10-18 09:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 09:23:39 --> CSRF cookie sent
INFO - 2018-10-18 09:23:39 --> CSRF token verified
INFO - 2018-10-18 09:23:39 --> Input Class Initialized
INFO - 2018-10-18 09:23:39 --> Language Class Initialized
INFO - 2018-10-18 09:23:39 --> Loader Class Initialized
INFO - 2018-10-18 09:23:39 --> Helper loaded: url_helper
INFO - 2018-10-18 09:23:39 --> Helper loaded: form_helper
INFO - 2018-10-18 09:23:39 --> Helper loaded: language_helper
DEBUG - 2018-10-18 09:23:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 09:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 09:23:39 --> User Agent Class Initialized
INFO - 2018-10-18 09:23:39 --> Controller Class Initialized
INFO - 2018-10-18 09:23:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 09:23:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 09:23:39 --> Pixel_Model class loaded
INFO - 2018-10-18 09:23:39 --> Database Driver Class Initialized
INFO - 2018-10-18 09:23:39 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:23:39 --> Form Validation Class Initialized
INFO - 2018-10-18 09:23:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 09:23:39 --> Database Driver Class Initialized
INFO - 2018-10-18 09:23:39 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:23:39 --> Config Class Initialized
INFO - 2018-10-18 09:23:39 --> Hooks Class Initialized
DEBUG - 2018-10-18 09:23:39 --> UTF-8 Support Enabled
INFO - 2018-10-18 09:23:39 --> Utf8 Class Initialized
INFO - 2018-10-18 09:23:39 --> URI Class Initialized
INFO - 2018-10-18 09:23:39 --> Router Class Initialized
INFO - 2018-10-18 09:23:39 --> Output Class Initialized
INFO - 2018-10-18 09:23:39 --> Security Class Initialized
DEBUG - 2018-10-18 09:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 09:23:39 --> CSRF cookie sent
INFO - 2018-10-18 09:23:39 --> Input Class Initialized
INFO - 2018-10-18 09:23:39 --> Language Class Initialized
INFO - 2018-10-18 09:23:39 --> Loader Class Initialized
INFO - 2018-10-18 09:23:39 --> Helper loaded: url_helper
INFO - 2018-10-18 09:23:39 --> Helper loaded: form_helper
INFO - 2018-10-18 09:23:39 --> Helper loaded: language_helper
DEBUG - 2018-10-18 09:23:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 09:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 09:23:39 --> User Agent Class Initialized
INFO - 2018-10-18 09:23:40 --> Controller Class Initialized
INFO - 2018-10-18 09:23:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 09:23:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 09:23:40 --> Pixel_Model class loaded
INFO - 2018-10-18 09:23:40 --> Database Driver Class Initialized
INFO - 2018-10-18 09:23:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:23:40 --> Database Driver Class Initialized
INFO - 2018-10-18 09:23:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:23:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 09:23:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 09:23:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-10-18 09:23:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 09:23:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 09:23:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 09:23:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 09:23:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-10-18 09:23:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 09:23:40 --> Final output sent to browser
DEBUG - 2018-10-18 09:23:40 --> Total execution time: 0.0452
INFO - 2018-10-18 09:23:42 --> Config Class Initialized
INFO - 2018-10-18 09:23:42 --> Hooks Class Initialized
DEBUG - 2018-10-18 09:23:42 --> UTF-8 Support Enabled
INFO - 2018-10-18 09:23:42 --> Utf8 Class Initialized
INFO - 2018-10-18 09:23:42 --> URI Class Initialized
INFO - 2018-10-18 09:23:42 --> Router Class Initialized
INFO - 2018-10-18 09:23:42 --> Output Class Initialized
INFO - 2018-10-18 09:23:42 --> Security Class Initialized
DEBUG - 2018-10-18 09:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 09:23:42 --> CSRF cookie sent
INFO - 2018-10-18 09:23:42 --> CSRF token verified
INFO - 2018-10-18 09:23:42 --> Input Class Initialized
INFO - 2018-10-18 09:23:42 --> Language Class Initialized
INFO - 2018-10-18 09:23:42 --> Loader Class Initialized
INFO - 2018-10-18 09:23:42 --> Helper loaded: url_helper
INFO - 2018-10-18 09:23:42 --> Helper loaded: form_helper
INFO - 2018-10-18 09:23:42 --> Helper loaded: language_helper
DEBUG - 2018-10-18 09:23:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 09:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 09:23:42 --> User Agent Class Initialized
INFO - 2018-10-18 09:23:42 --> Controller Class Initialized
INFO - 2018-10-18 09:23:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 09:23:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 09:23:42 --> Pixel_Model class loaded
INFO - 2018-10-18 09:23:42 --> Database Driver Class Initialized
INFO - 2018-10-18 09:23:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:23:42 --> Form Validation Class Initialized
INFO - 2018-10-18 09:23:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 09:23:42 --> Database Driver Class Initialized
INFO - 2018-10-18 09:23:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:23:42 --> Config Class Initialized
INFO - 2018-10-18 09:23:42 --> Hooks Class Initialized
DEBUG - 2018-10-18 09:23:42 --> UTF-8 Support Enabled
INFO - 2018-10-18 09:23:42 --> Utf8 Class Initialized
INFO - 2018-10-18 09:23:42 --> URI Class Initialized
INFO - 2018-10-18 09:23:42 --> Router Class Initialized
INFO - 2018-10-18 09:23:42 --> Output Class Initialized
INFO - 2018-10-18 09:23:42 --> Security Class Initialized
DEBUG - 2018-10-18 09:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 09:23:42 --> CSRF cookie sent
INFO - 2018-10-18 09:23:42 --> Input Class Initialized
INFO - 2018-10-18 09:23:42 --> Language Class Initialized
INFO - 2018-10-18 09:23:42 --> Loader Class Initialized
INFO - 2018-10-18 09:23:42 --> Helper loaded: url_helper
INFO - 2018-10-18 09:23:42 --> Helper loaded: form_helper
INFO - 2018-10-18 09:23:42 --> Helper loaded: language_helper
DEBUG - 2018-10-18 09:23:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 09:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 09:23:42 --> User Agent Class Initialized
INFO - 2018-10-18 09:23:42 --> Controller Class Initialized
INFO - 2018-10-18 09:23:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 09:23:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 09:23:42 --> Pixel_Model class loaded
INFO - 2018-10-18 09:23:42 --> Database Driver Class Initialized
INFO - 2018-10-18 09:23:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:23:42 --> Database Driver Class Initialized
INFO - 2018-10-18 09:23:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:23:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 09:23:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 09:23:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 09:23:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 09:23:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 09:23:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 09:23:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-18 09:23:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 09:23:42 --> Final output sent to browser
DEBUG - 2018-10-18 09:23:42 --> Total execution time: 0.0404
INFO - 2018-10-18 09:23:49 --> Config Class Initialized
INFO - 2018-10-18 09:23:49 --> Hooks Class Initialized
DEBUG - 2018-10-18 09:23:49 --> UTF-8 Support Enabled
INFO - 2018-10-18 09:23:49 --> Utf8 Class Initialized
INFO - 2018-10-18 09:23:49 --> URI Class Initialized
INFO - 2018-10-18 09:23:49 --> Router Class Initialized
INFO - 2018-10-18 09:23:49 --> Output Class Initialized
INFO - 2018-10-18 09:23:49 --> Security Class Initialized
DEBUG - 2018-10-18 09:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 09:23:49 --> CSRF cookie sent
INFO - 2018-10-18 09:23:49 --> Input Class Initialized
INFO - 2018-10-18 09:23:49 --> Language Class Initialized
ERROR - 2018-10-18 09:23:49 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 09:25:13 --> Config Class Initialized
INFO - 2018-10-18 09:25:13 --> Hooks Class Initialized
DEBUG - 2018-10-18 09:25:13 --> UTF-8 Support Enabled
INFO - 2018-10-18 09:25:13 --> Utf8 Class Initialized
INFO - 2018-10-18 09:25:13 --> URI Class Initialized
INFO - 2018-10-18 09:25:13 --> Router Class Initialized
INFO - 2018-10-18 09:25:13 --> Output Class Initialized
INFO - 2018-10-18 09:25:13 --> Security Class Initialized
DEBUG - 2018-10-18 09:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 09:25:13 --> CSRF cookie sent
INFO - 2018-10-18 09:25:13 --> Input Class Initialized
INFO - 2018-10-18 09:25:13 --> Language Class Initialized
INFO - 2018-10-18 09:25:13 --> Loader Class Initialized
INFO - 2018-10-18 09:25:13 --> Helper loaded: url_helper
INFO - 2018-10-18 09:25:13 --> Helper loaded: form_helper
INFO - 2018-10-18 09:25:13 --> Helper loaded: language_helper
DEBUG - 2018-10-18 09:25:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 09:25:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 09:25:13 --> User Agent Class Initialized
INFO - 2018-10-18 09:25:13 --> Controller Class Initialized
INFO - 2018-10-18 09:25:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 09:25:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 09:25:13 --> Pixel_Model class loaded
INFO - 2018-10-18 09:25:13 --> Database Driver Class Initialized
INFO - 2018-10-18 09:25:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:25:13 --> Database Driver Class Initialized
INFO - 2018-10-18 09:25:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:25:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 09:25:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 09:25:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 09:25:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 09:25:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 09:25:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 09:25:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-18 09:25:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 09:25:13 --> Final output sent to browser
DEBUG - 2018-10-18 09:25:13 --> Total execution time: 0.0521
INFO - 2018-10-18 09:25:25 --> Config Class Initialized
INFO - 2018-10-18 09:25:25 --> Hooks Class Initialized
DEBUG - 2018-10-18 09:25:25 --> UTF-8 Support Enabled
INFO - 2018-10-18 09:25:25 --> Utf8 Class Initialized
INFO - 2018-10-18 09:25:25 --> URI Class Initialized
INFO - 2018-10-18 09:25:25 --> Router Class Initialized
INFO - 2018-10-18 09:25:25 --> Output Class Initialized
INFO - 2018-10-18 09:25:25 --> Security Class Initialized
DEBUG - 2018-10-18 09:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 09:25:25 --> CSRF cookie sent
INFO - 2018-10-18 09:25:25 --> Input Class Initialized
INFO - 2018-10-18 09:25:25 --> Language Class Initialized
ERROR - 2018-10-18 09:25:25 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 09:32:45 --> Config Class Initialized
INFO - 2018-10-18 09:32:45 --> Hooks Class Initialized
DEBUG - 2018-10-18 09:32:45 --> UTF-8 Support Enabled
INFO - 2018-10-18 09:32:45 --> Utf8 Class Initialized
INFO - 2018-10-18 09:32:45 --> URI Class Initialized
INFO - 2018-10-18 09:32:45 --> Router Class Initialized
INFO - 2018-10-18 09:32:45 --> Output Class Initialized
INFO - 2018-10-18 09:32:45 --> Security Class Initialized
DEBUG - 2018-10-18 09:32:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 09:32:45 --> CSRF cookie sent
INFO - 2018-10-18 09:32:45 --> Input Class Initialized
INFO - 2018-10-18 09:32:45 --> Language Class Initialized
INFO - 2018-10-18 09:32:45 --> Loader Class Initialized
INFO - 2018-10-18 09:32:45 --> Helper loaded: url_helper
INFO - 2018-10-18 09:32:45 --> Helper loaded: form_helper
INFO - 2018-10-18 09:32:45 --> Helper loaded: language_helper
DEBUG - 2018-10-18 09:32:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 09:32:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 09:32:45 --> User Agent Class Initialized
INFO - 2018-10-18 09:32:45 --> Controller Class Initialized
INFO - 2018-10-18 09:32:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 09:32:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 09:32:45 --> Pixel_Model class loaded
INFO - 2018-10-18 09:32:45 --> Database Driver Class Initialized
INFO - 2018-10-18 09:32:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:32:45 --> Database Driver Class Initialized
INFO - 2018-10-18 09:32:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:32:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 09:32:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 09:32:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 09:32:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 09:32:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 09:32:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 09:32:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-18 09:32:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 09:32:45 --> Final output sent to browser
DEBUG - 2018-10-18 09:32:45 --> Total execution time: 0.0518
INFO - 2018-10-18 09:32:51 --> Config Class Initialized
INFO - 2018-10-18 09:32:51 --> Hooks Class Initialized
DEBUG - 2018-10-18 09:32:51 --> UTF-8 Support Enabled
INFO - 2018-10-18 09:32:51 --> Utf8 Class Initialized
INFO - 2018-10-18 09:32:51 --> URI Class Initialized
INFO - 2018-10-18 09:32:51 --> Router Class Initialized
INFO - 2018-10-18 09:32:51 --> Output Class Initialized
INFO - 2018-10-18 09:32:51 --> Security Class Initialized
DEBUG - 2018-10-18 09:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 09:32:51 --> CSRF cookie sent
INFO - 2018-10-18 09:32:51 --> Input Class Initialized
INFO - 2018-10-18 09:32:51 --> Language Class Initialized
ERROR - 2018-10-18 09:32:51 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 09:33:09 --> Config Class Initialized
INFO - 2018-10-18 09:33:09 --> Hooks Class Initialized
DEBUG - 2018-10-18 09:33:09 --> UTF-8 Support Enabled
INFO - 2018-10-18 09:33:09 --> Utf8 Class Initialized
INFO - 2018-10-18 09:33:09 --> URI Class Initialized
INFO - 2018-10-18 09:33:09 --> Router Class Initialized
INFO - 2018-10-18 09:33:09 --> Output Class Initialized
INFO - 2018-10-18 09:33:09 --> Security Class Initialized
DEBUG - 2018-10-18 09:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 09:33:09 --> CSRF cookie sent
INFO - 2018-10-18 09:33:09 --> Input Class Initialized
INFO - 2018-10-18 09:33:09 --> Language Class Initialized
INFO - 2018-10-18 09:33:09 --> Loader Class Initialized
INFO - 2018-10-18 09:33:09 --> Helper loaded: url_helper
INFO - 2018-10-18 09:33:09 --> Helper loaded: form_helper
INFO - 2018-10-18 09:33:09 --> Helper loaded: language_helper
DEBUG - 2018-10-18 09:33:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 09:33:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 09:33:09 --> User Agent Class Initialized
INFO - 2018-10-18 09:33:09 --> Controller Class Initialized
INFO - 2018-10-18 09:33:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 09:33:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 09:33:09 --> Pixel_Model class loaded
INFO - 2018-10-18 09:33:09 --> Database Driver Class Initialized
INFO - 2018-10-18 09:33:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:33:09 --> Database Driver Class Initialized
INFO - 2018-10-18 09:33:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:33:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 09:33:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 09:33:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 09:33:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 09:33:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 09:33:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 09:33:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-18 09:33:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 09:33:09 --> Final output sent to browser
DEBUG - 2018-10-18 09:33:09 --> Total execution time: 0.0543
INFO - 2018-10-18 09:33:11 --> Config Class Initialized
INFO - 2018-10-18 09:33:11 --> Hooks Class Initialized
DEBUG - 2018-10-18 09:33:11 --> UTF-8 Support Enabled
INFO - 2018-10-18 09:33:11 --> Utf8 Class Initialized
INFO - 2018-10-18 09:33:11 --> URI Class Initialized
INFO - 2018-10-18 09:33:11 --> Router Class Initialized
INFO - 2018-10-18 09:33:11 --> Output Class Initialized
INFO - 2018-10-18 09:33:11 --> Security Class Initialized
DEBUG - 2018-10-18 09:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 09:33:11 --> CSRF cookie sent
INFO - 2018-10-18 09:33:11 --> Input Class Initialized
INFO - 2018-10-18 09:33:11 --> Language Class Initialized
ERROR - 2018-10-18 09:33:11 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 09:34:03 --> Config Class Initialized
INFO - 2018-10-18 09:34:03 --> Hooks Class Initialized
DEBUG - 2018-10-18 09:34:03 --> UTF-8 Support Enabled
INFO - 2018-10-18 09:34:03 --> Utf8 Class Initialized
INFO - 2018-10-18 09:34:03 --> URI Class Initialized
INFO - 2018-10-18 09:34:03 --> Router Class Initialized
INFO - 2018-10-18 09:34:03 --> Output Class Initialized
INFO - 2018-10-18 09:34:03 --> Security Class Initialized
DEBUG - 2018-10-18 09:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 09:34:03 --> CSRF cookie sent
INFO - 2018-10-18 09:34:03 --> Input Class Initialized
INFO - 2018-10-18 09:34:03 --> Language Class Initialized
INFO - 2018-10-18 09:34:03 --> Loader Class Initialized
INFO - 2018-10-18 09:34:03 --> Helper loaded: url_helper
INFO - 2018-10-18 09:34:03 --> Helper loaded: form_helper
INFO - 2018-10-18 09:34:03 --> Helper loaded: language_helper
DEBUG - 2018-10-18 09:34:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 09:34:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 09:34:03 --> User Agent Class Initialized
INFO - 2018-10-18 09:34:03 --> Controller Class Initialized
INFO - 2018-10-18 09:34:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 09:34:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 09:34:03 --> Pixel_Model class loaded
INFO - 2018-10-18 09:34:03 --> Database Driver Class Initialized
INFO - 2018-10-18 09:34:03 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:34:03 --> Database Driver Class Initialized
INFO - 2018-10-18 09:34:03 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:34:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 09:34:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 09:34:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 09:34:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 09:34:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 09:34:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 09:34:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-18 09:34:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 09:34:03 --> Final output sent to browser
DEBUG - 2018-10-18 09:34:03 --> Total execution time: 0.0482
INFO - 2018-10-18 09:34:08 --> Config Class Initialized
INFO - 2018-10-18 09:34:08 --> Hooks Class Initialized
DEBUG - 2018-10-18 09:34:08 --> UTF-8 Support Enabled
INFO - 2018-10-18 09:34:08 --> Utf8 Class Initialized
INFO - 2018-10-18 09:34:08 --> URI Class Initialized
INFO - 2018-10-18 09:34:08 --> Router Class Initialized
INFO - 2018-10-18 09:34:08 --> Output Class Initialized
INFO - 2018-10-18 09:34:08 --> Security Class Initialized
DEBUG - 2018-10-18 09:34:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 09:34:08 --> CSRF cookie sent
INFO - 2018-10-18 09:34:08 --> Input Class Initialized
INFO - 2018-10-18 09:34:08 --> Language Class Initialized
ERROR - 2018-10-18 09:34:08 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 09:34:30 --> Config Class Initialized
INFO - 2018-10-18 09:34:30 --> Hooks Class Initialized
DEBUG - 2018-10-18 09:34:30 --> UTF-8 Support Enabled
INFO - 2018-10-18 09:34:30 --> Utf8 Class Initialized
INFO - 2018-10-18 09:34:30 --> URI Class Initialized
INFO - 2018-10-18 09:34:30 --> Router Class Initialized
INFO - 2018-10-18 09:34:30 --> Output Class Initialized
INFO - 2018-10-18 09:34:30 --> Security Class Initialized
DEBUG - 2018-10-18 09:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 09:34:30 --> CSRF cookie sent
INFO - 2018-10-18 09:34:30 --> Input Class Initialized
INFO - 2018-10-18 09:34:30 --> Language Class Initialized
INFO - 2018-10-18 09:34:30 --> Loader Class Initialized
INFO - 2018-10-18 09:34:30 --> Helper loaded: url_helper
INFO - 2018-10-18 09:34:30 --> Helper loaded: form_helper
INFO - 2018-10-18 09:34:30 --> Helper loaded: language_helper
DEBUG - 2018-10-18 09:34:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 09:34:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 09:34:30 --> User Agent Class Initialized
INFO - 2018-10-18 09:34:30 --> Controller Class Initialized
INFO - 2018-10-18 09:34:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 09:34:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 09:34:30 --> Pixel_Model class loaded
INFO - 2018-10-18 09:34:30 --> Database Driver Class Initialized
INFO - 2018-10-18 09:34:30 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:34:30 --> Database Driver Class Initialized
INFO - 2018-10-18 09:34:30 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:34:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 09:34:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 09:34:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 09:34:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 09:34:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 09:34:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 09:34:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-18 09:34:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 09:34:30 --> Final output sent to browser
DEBUG - 2018-10-18 09:34:30 --> Total execution time: 0.0476
INFO - 2018-10-18 09:34:36 --> Config Class Initialized
INFO - 2018-10-18 09:34:36 --> Hooks Class Initialized
DEBUG - 2018-10-18 09:34:36 --> UTF-8 Support Enabled
INFO - 2018-10-18 09:34:36 --> Utf8 Class Initialized
INFO - 2018-10-18 09:34:36 --> URI Class Initialized
INFO - 2018-10-18 09:34:36 --> Router Class Initialized
INFO - 2018-10-18 09:34:36 --> Output Class Initialized
INFO - 2018-10-18 09:34:36 --> Security Class Initialized
DEBUG - 2018-10-18 09:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 09:34:36 --> CSRF cookie sent
INFO - 2018-10-18 09:34:36 --> Input Class Initialized
INFO - 2018-10-18 09:34:36 --> Language Class Initialized
ERROR - 2018-10-18 09:34:36 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 09:34:41 --> Config Class Initialized
INFO - 2018-10-18 09:34:41 --> Hooks Class Initialized
DEBUG - 2018-10-18 09:34:41 --> UTF-8 Support Enabled
INFO - 2018-10-18 09:34:41 --> Utf8 Class Initialized
INFO - 2018-10-18 09:34:41 --> URI Class Initialized
INFO - 2018-10-18 09:34:41 --> Router Class Initialized
INFO - 2018-10-18 09:34:41 --> Output Class Initialized
INFO - 2018-10-18 09:34:41 --> Security Class Initialized
DEBUG - 2018-10-18 09:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 09:34:41 --> CSRF cookie sent
INFO - 2018-10-18 09:34:41 --> CSRF token verified
INFO - 2018-10-18 09:34:41 --> Input Class Initialized
INFO - 2018-10-18 09:34:41 --> Language Class Initialized
INFO - 2018-10-18 09:34:41 --> Loader Class Initialized
INFO - 2018-10-18 09:34:41 --> Helper loaded: url_helper
INFO - 2018-10-18 09:34:41 --> Helper loaded: form_helper
INFO - 2018-10-18 09:34:41 --> Helper loaded: language_helper
DEBUG - 2018-10-18 09:34:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 09:34:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 09:34:41 --> User Agent Class Initialized
INFO - 2018-10-18 09:34:41 --> Controller Class Initialized
INFO - 2018-10-18 09:34:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 09:34:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 09:34:41 --> Pixel_Model class loaded
INFO - 2018-10-18 09:34:41 --> Database Driver Class Initialized
INFO - 2018-10-18 09:34:41 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:34:41 --> Form Validation Class Initialized
INFO - 2018-10-18 09:34:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 09:34:41 --> Database Driver Class Initialized
INFO - 2018-10-18 09:34:41 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:34:41 --> Config Class Initialized
INFO - 2018-10-18 09:34:41 --> Hooks Class Initialized
DEBUG - 2018-10-18 09:34:41 --> UTF-8 Support Enabled
INFO - 2018-10-18 09:34:41 --> Utf8 Class Initialized
INFO - 2018-10-18 09:34:41 --> URI Class Initialized
INFO - 2018-10-18 09:34:41 --> Router Class Initialized
INFO - 2018-10-18 09:34:41 --> Output Class Initialized
INFO - 2018-10-18 09:34:41 --> Security Class Initialized
DEBUG - 2018-10-18 09:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 09:34:41 --> CSRF cookie sent
INFO - 2018-10-18 09:34:41 --> Input Class Initialized
INFO - 2018-10-18 09:34:41 --> Language Class Initialized
INFO - 2018-10-18 09:34:41 --> Loader Class Initialized
INFO - 2018-10-18 09:34:41 --> Helper loaded: url_helper
INFO - 2018-10-18 09:34:41 --> Helper loaded: form_helper
INFO - 2018-10-18 09:34:41 --> Helper loaded: language_helper
DEBUG - 2018-10-18 09:34:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 09:34:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 09:34:41 --> User Agent Class Initialized
INFO - 2018-10-18 09:34:41 --> Controller Class Initialized
INFO - 2018-10-18 09:34:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 09:34:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 09:34:41 --> Pixel_Model class loaded
INFO - 2018-10-18 09:34:41 --> Database Driver Class Initialized
INFO - 2018-10-18 09:34:41 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:34:41 --> Database Driver Class Initialized
INFO - 2018-10-18 09:34:41 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:34:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 09:34:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 09:34:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 09:34:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 09:34:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 09:34:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 09:34:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-10-18 09:34:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 09:34:41 --> Final output sent to browser
DEBUG - 2018-10-18 09:34:41 --> Total execution time: 0.0486
INFO - 2018-10-18 09:34:44 --> Config Class Initialized
INFO - 2018-10-18 09:34:44 --> Hooks Class Initialized
DEBUG - 2018-10-18 09:34:44 --> UTF-8 Support Enabled
INFO - 2018-10-18 09:34:44 --> Utf8 Class Initialized
INFO - 2018-10-18 09:34:44 --> URI Class Initialized
INFO - 2018-10-18 09:34:44 --> Router Class Initialized
INFO - 2018-10-18 09:34:44 --> Output Class Initialized
INFO - 2018-10-18 09:34:44 --> Security Class Initialized
DEBUG - 2018-10-18 09:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 09:34:44 --> CSRF cookie sent
INFO - 2018-10-18 09:34:44 --> Input Class Initialized
INFO - 2018-10-18 09:34:44 --> Language Class Initialized
ERROR - 2018-10-18 09:34:44 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 09:34:45 --> Config Class Initialized
INFO - 2018-10-18 09:34:45 --> Hooks Class Initialized
DEBUG - 2018-10-18 09:34:45 --> UTF-8 Support Enabled
INFO - 2018-10-18 09:34:45 --> Utf8 Class Initialized
INFO - 2018-10-18 09:34:45 --> URI Class Initialized
INFO - 2018-10-18 09:34:45 --> Router Class Initialized
INFO - 2018-10-18 09:34:45 --> Output Class Initialized
INFO - 2018-10-18 09:34:45 --> Security Class Initialized
DEBUG - 2018-10-18 09:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 09:34:45 --> CSRF cookie sent
INFO - 2018-10-18 09:34:45 --> CSRF token verified
INFO - 2018-10-18 09:34:45 --> Input Class Initialized
INFO - 2018-10-18 09:34:45 --> Language Class Initialized
INFO - 2018-10-18 09:34:45 --> Loader Class Initialized
INFO - 2018-10-18 09:34:45 --> Helper loaded: url_helper
INFO - 2018-10-18 09:34:45 --> Helper loaded: form_helper
INFO - 2018-10-18 09:34:45 --> Helper loaded: language_helper
DEBUG - 2018-10-18 09:34:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 09:34:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 09:34:45 --> User Agent Class Initialized
INFO - 2018-10-18 09:34:45 --> Controller Class Initialized
INFO - 2018-10-18 09:34:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 09:34:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 09:34:45 --> Pixel_Model class loaded
INFO - 2018-10-18 09:34:45 --> Database Driver Class Initialized
INFO - 2018-10-18 09:34:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:34:45 --> Form Validation Class Initialized
INFO - 2018-10-18 09:34:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 09:34:45 --> Database Driver Class Initialized
INFO - 2018-10-18 09:34:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:34:45 --> Config Class Initialized
INFO - 2018-10-18 09:34:45 --> Hooks Class Initialized
DEBUG - 2018-10-18 09:34:45 --> UTF-8 Support Enabled
INFO - 2018-10-18 09:34:45 --> Utf8 Class Initialized
INFO - 2018-10-18 09:34:45 --> URI Class Initialized
INFO - 2018-10-18 09:34:45 --> Router Class Initialized
INFO - 2018-10-18 09:34:45 --> Output Class Initialized
INFO - 2018-10-18 09:34:45 --> Security Class Initialized
DEBUG - 2018-10-18 09:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 09:34:45 --> CSRF cookie sent
INFO - 2018-10-18 09:34:45 --> Input Class Initialized
INFO - 2018-10-18 09:34:45 --> Language Class Initialized
INFO - 2018-10-18 09:34:45 --> Loader Class Initialized
INFO - 2018-10-18 09:34:45 --> Helper loaded: url_helper
INFO - 2018-10-18 09:34:45 --> Helper loaded: form_helper
INFO - 2018-10-18 09:34:45 --> Helper loaded: language_helper
DEBUG - 2018-10-18 09:34:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 09:34:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 09:34:45 --> User Agent Class Initialized
INFO - 2018-10-18 09:34:45 --> Controller Class Initialized
INFO - 2018-10-18 09:34:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 09:34:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 09:34:45 --> Pixel_Model class loaded
INFO - 2018-10-18 09:34:45 --> Database Driver Class Initialized
INFO - 2018-10-18 09:34:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:34:45 --> Database Driver Class Initialized
INFO - 2018-10-18 09:34:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:34:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 09:34:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 09:34:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-10-18 09:34:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 09:34:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 09:34:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 09:34:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 09:34:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-10-18 09:34:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 09:34:45 --> Final output sent to browser
DEBUG - 2018-10-18 09:34:45 --> Total execution time: 0.0499
INFO - 2018-10-18 09:34:48 --> Config Class Initialized
INFO - 2018-10-18 09:34:48 --> Hooks Class Initialized
DEBUG - 2018-10-18 09:34:48 --> UTF-8 Support Enabled
INFO - 2018-10-18 09:34:48 --> Utf8 Class Initialized
INFO - 2018-10-18 09:34:48 --> URI Class Initialized
INFO - 2018-10-18 09:34:48 --> Router Class Initialized
INFO - 2018-10-18 09:34:48 --> Output Class Initialized
INFO - 2018-10-18 09:34:48 --> Security Class Initialized
DEBUG - 2018-10-18 09:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 09:34:48 --> CSRF cookie sent
INFO - 2018-10-18 09:34:48 --> Input Class Initialized
INFO - 2018-10-18 09:34:48 --> Language Class Initialized
ERROR - 2018-10-18 09:34:48 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 09:34:49 --> Config Class Initialized
INFO - 2018-10-18 09:34:49 --> Hooks Class Initialized
DEBUG - 2018-10-18 09:34:49 --> UTF-8 Support Enabled
INFO - 2018-10-18 09:34:49 --> Utf8 Class Initialized
INFO - 2018-10-18 09:34:49 --> URI Class Initialized
INFO - 2018-10-18 09:34:49 --> Router Class Initialized
INFO - 2018-10-18 09:34:49 --> Output Class Initialized
INFO - 2018-10-18 09:34:49 --> Security Class Initialized
DEBUG - 2018-10-18 09:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 09:34:49 --> CSRF cookie sent
INFO - 2018-10-18 09:34:49 --> CSRF token verified
INFO - 2018-10-18 09:34:49 --> Input Class Initialized
INFO - 2018-10-18 09:34:49 --> Language Class Initialized
INFO - 2018-10-18 09:34:49 --> Loader Class Initialized
INFO - 2018-10-18 09:34:49 --> Helper loaded: url_helper
INFO - 2018-10-18 09:34:49 --> Helper loaded: form_helper
INFO - 2018-10-18 09:34:49 --> Helper loaded: language_helper
DEBUG - 2018-10-18 09:34:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 09:34:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 09:34:49 --> User Agent Class Initialized
INFO - 2018-10-18 09:34:49 --> Controller Class Initialized
INFO - 2018-10-18 09:34:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 09:34:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 09:34:49 --> Pixel_Model class loaded
INFO - 2018-10-18 09:34:49 --> Database Driver Class Initialized
INFO - 2018-10-18 09:34:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:34:49 --> Form Validation Class Initialized
INFO - 2018-10-18 09:34:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 09:34:49 --> Database Driver Class Initialized
INFO - 2018-10-18 09:34:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:34:49 --> Config Class Initialized
INFO - 2018-10-18 09:34:49 --> Hooks Class Initialized
DEBUG - 2018-10-18 09:34:49 --> UTF-8 Support Enabled
INFO - 2018-10-18 09:34:49 --> Utf8 Class Initialized
INFO - 2018-10-18 09:34:49 --> URI Class Initialized
INFO - 2018-10-18 09:34:49 --> Router Class Initialized
INFO - 2018-10-18 09:34:49 --> Output Class Initialized
INFO - 2018-10-18 09:34:49 --> Security Class Initialized
DEBUG - 2018-10-18 09:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 09:34:49 --> CSRF cookie sent
INFO - 2018-10-18 09:34:49 --> Input Class Initialized
INFO - 2018-10-18 09:34:49 --> Language Class Initialized
INFO - 2018-10-18 09:34:49 --> Loader Class Initialized
INFO - 2018-10-18 09:34:49 --> Helper loaded: url_helper
INFO - 2018-10-18 09:34:49 --> Helper loaded: form_helper
INFO - 2018-10-18 09:34:49 --> Helper loaded: language_helper
DEBUG - 2018-10-18 09:34:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 09:34:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 09:34:49 --> User Agent Class Initialized
INFO - 2018-10-18 09:34:49 --> Controller Class Initialized
INFO - 2018-10-18 09:34:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 09:34:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 09:34:49 --> Pixel_Model class loaded
INFO - 2018-10-18 09:34:49 --> Database Driver Class Initialized
INFO - 2018-10-18 09:34:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:34:49 --> Database Driver Class Initialized
INFO - 2018-10-18 09:34:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:34:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 09:34:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 09:34:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 09:34:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 09:34:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 09:34:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 09:34:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-18 09:34:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 09:34:49 --> Final output sent to browser
DEBUG - 2018-10-18 09:34:49 --> Total execution time: 0.0578
INFO - 2018-10-18 09:34:52 --> Config Class Initialized
INFO - 2018-10-18 09:34:52 --> Hooks Class Initialized
DEBUG - 2018-10-18 09:34:52 --> UTF-8 Support Enabled
INFO - 2018-10-18 09:34:52 --> Utf8 Class Initialized
INFO - 2018-10-18 09:34:52 --> URI Class Initialized
INFO - 2018-10-18 09:34:52 --> Router Class Initialized
INFO - 2018-10-18 09:34:52 --> Output Class Initialized
INFO - 2018-10-18 09:34:52 --> Security Class Initialized
DEBUG - 2018-10-18 09:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 09:34:52 --> CSRF cookie sent
INFO - 2018-10-18 09:34:52 --> Input Class Initialized
INFO - 2018-10-18 09:34:52 --> Language Class Initialized
ERROR - 2018-10-18 09:34:52 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 09:40:15 --> Config Class Initialized
INFO - 2018-10-18 09:40:15 --> Hooks Class Initialized
DEBUG - 2018-10-18 09:40:15 --> UTF-8 Support Enabled
INFO - 2018-10-18 09:40:15 --> Utf8 Class Initialized
INFO - 2018-10-18 09:40:15 --> URI Class Initialized
INFO - 2018-10-18 09:40:15 --> Router Class Initialized
INFO - 2018-10-18 09:40:15 --> Output Class Initialized
INFO - 2018-10-18 09:40:15 --> Security Class Initialized
DEBUG - 2018-10-18 09:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 09:40:15 --> CSRF cookie sent
INFO - 2018-10-18 09:40:15 --> Input Class Initialized
INFO - 2018-10-18 09:40:15 --> Language Class Initialized
INFO - 2018-10-18 09:40:15 --> Loader Class Initialized
INFO - 2018-10-18 09:40:15 --> Helper loaded: url_helper
INFO - 2018-10-18 09:40:15 --> Helper loaded: form_helper
INFO - 2018-10-18 09:40:15 --> Helper loaded: language_helper
DEBUG - 2018-10-18 09:40:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 09:40:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 09:40:15 --> User Agent Class Initialized
INFO - 2018-10-18 09:40:15 --> Controller Class Initialized
INFO - 2018-10-18 09:40:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 09:40:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 09:40:15 --> Pixel_Model class loaded
INFO - 2018-10-18 09:40:15 --> Database Driver Class Initialized
INFO - 2018-10-18 09:40:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:40:15 --> Database Driver Class Initialized
INFO - 2018-10-18 09:40:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:40:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 09:40:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 09:40:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 09:40:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 09:40:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 09:40:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 09:40:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-18 09:40:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 09:40:15 --> Final output sent to browser
DEBUG - 2018-10-18 09:40:15 --> Total execution time: 0.0490
INFO - 2018-10-18 09:40:20 --> Config Class Initialized
INFO - 2018-10-18 09:40:20 --> Hooks Class Initialized
DEBUG - 2018-10-18 09:40:20 --> UTF-8 Support Enabled
INFO - 2018-10-18 09:40:20 --> Utf8 Class Initialized
INFO - 2018-10-18 09:40:20 --> URI Class Initialized
INFO - 2018-10-18 09:40:20 --> Router Class Initialized
INFO - 2018-10-18 09:40:20 --> Output Class Initialized
INFO - 2018-10-18 09:40:20 --> Security Class Initialized
DEBUG - 2018-10-18 09:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 09:40:20 --> CSRF cookie sent
INFO - 2018-10-18 09:40:20 --> Input Class Initialized
INFO - 2018-10-18 09:40:20 --> Language Class Initialized
ERROR - 2018-10-18 09:40:20 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 09:50:25 --> Config Class Initialized
INFO - 2018-10-18 09:50:25 --> Hooks Class Initialized
DEBUG - 2018-10-18 09:50:25 --> UTF-8 Support Enabled
INFO - 2018-10-18 09:50:25 --> Utf8 Class Initialized
INFO - 2018-10-18 09:50:25 --> URI Class Initialized
INFO - 2018-10-18 09:50:25 --> Router Class Initialized
INFO - 2018-10-18 09:50:25 --> Output Class Initialized
INFO - 2018-10-18 09:50:25 --> Security Class Initialized
DEBUG - 2018-10-18 09:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 09:50:25 --> CSRF cookie sent
INFO - 2018-10-18 09:50:25 --> Input Class Initialized
INFO - 2018-10-18 09:50:25 --> Language Class Initialized
INFO - 2018-10-18 09:50:25 --> Loader Class Initialized
INFO - 2018-10-18 09:50:25 --> Helper loaded: url_helper
INFO - 2018-10-18 09:50:25 --> Helper loaded: form_helper
INFO - 2018-10-18 09:50:25 --> Helper loaded: language_helper
DEBUG - 2018-10-18 09:50:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 09:50:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 09:50:25 --> User Agent Class Initialized
INFO - 2018-10-18 09:50:25 --> Controller Class Initialized
INFO - 2018-10-18 09:50:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 09:50:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 09:50:25 --> Pixel_Model class loaded
INFO - 2018-10-18 09:50:25 --> Database Driver Class Initialized
INFO - 2018-10-18 09:50:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:50:25 --> Database Driver Class Initialized
INFO - 2018-10-18 09:50:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:50:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 09:50:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 09:50:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 09:50:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 09:50:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 09:50:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 09:50:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-18 09:50:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 09:50:25 --> Final output sent to browser
DEBUG - 2018-10-18 09:50:25 --> Total execution time: 0.0430
INFO - 2018-10-18 09:50:30 --> Config Class Initialized
INFO - 2018-10-18 09:50:30 --> Hooks Class Initialized
DEBUG - 2018-10-18 09:50:30 --> UTF-8 Support Enabled
INFO - 2018-10-18 09:50:30 --> Utf8 Class Initialized
INFO - 2018-10-18 09:50:30 --> URI Class Initialized
INFO - 2018-10-18 09:50:30 --> Router Class Initialized
INFO - 2018-10-18 09:50:30 --> Output Class Initialized
INFO - 2018-10-18 09:50:30 --> Security Class Initialized
DEBUG - 2018-10-18 09:50:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 09:50:30 --> CSRF cookie sent
INFO - 2018-10-18 09:50:30 --> Input Class Initialized
INFO - 2018-10-18 09:50:30 --> Language Class Initialized
ERROR - 2018-10-18 09:50:30 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 09:51:09 --> Config Class Initialized
INFO - 2018-10-18 09:51:09 --> Hooks Class Initialized
DEBUG - 2018-10-18 09:51:09 --> UTF-8 Support Enabled
INFO - 2018-10-18 09:51:09 --> Utf8 Class Initialized
INFO - 2018-10-18 09:51:09 --> URI Class Initialized
INFO - 2018-10-18 09:51:09 --> Router Class Initialized
INFO - 2018-10-18 09:51:09 --> Output Class Initialized
INFO - 2018-10-18 09:51:09 --> Security Class Initialized
DEBUG - 2018-10-18 09:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 09:51:09 --> CSRF cookie sent
INFO - 2018-10-18 09:51:09 --> Input Class Initialized
INFO - 2018-10-18 09:51:09 --> Language Class Initialized
INFO - 2018-10-18 09:51:09 --> Loader Class Initialized
INFO - 2018-10-18 09:51:09 --> Helper loaded: url_helper
INFO - 2018-10-18 09:51:09 --> Helper loaded: form_helper
INFO - 2018-10-18 09:51:09 --> Helper loaded: language_helper
DEBUG - 2018-10-18 09:51:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 09:51:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 09:51:09 --> User Agent Class Initialized
INFO - 2018-10-18 09:51:09 --> Controller Class Initialized
INFO - 2018-10-18 09:51:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 09:51:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 09:51:09 --> Pixel_Model class loaded
INFO - 2018-10-18 09:51:09 --> Database Driver Class Initialized
INFO - 2018-10-18 09:51:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:51:09 --> Database Driver Class Initialized
INFO - 2018-10-18 09:51:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:51:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 09:51:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 09:51:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 09:51:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 09:51:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 09:51:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 09:51:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-18 09:51:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 09:51:09 --> Final output sent to browser
DEBUG - 2018-10-18 09:51:09 --> Total execution time: 0.0548
INFO - 2018-10-18 09:59:47 --> Config Class Initialized
INFO - 2018-10-18 09:59:47 --> Hooks Class Initialized
DEBUG - 2018-10-18 09:59:47 --> UTF-8 Support Enabled
INFO - 2018-10-18 09:59:47 --> Utf8 Class Initialized
INFO - 2018-10-18 09:59:47 --> URI Class Initialized
INFO - 2018-10-18 09:59:47 --> Router Class Initialized
INFO - 2018-10-18 09:59:47 --> Output Class Initialized
INFO - 2018-10-18 09:59:47 --> Security Class Initialized
DEBUG - 2018-10-18 09:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 09:59:47 --> CSRF cookie sent
INFO - 2018-10-18 09:59:47 --> Input Class Initialized
INFO - 2018-10-18 09:59:47 --> Language Class Initialized
INFO - 2018-10-18 09:59:47 --> Loader Class Initialized
INFO - 2018-10-18 09:59:47 --> Helper loaded: url_helper
INFO - 2018-10-18 09:59:47 --> Helper loaded: form_helper
INFO - 2018-10-18 09:59:47 --> Helper loaded: language_helper
DEBUG - 2018-10-18 09:59:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 09:59:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 09:59:47 --> User Agent Class Initialized
INFO - 2018-10-18 09:59:47 --> Controller Class Initialized
INFO - 2018-10-18 09:59:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 09:59:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 09:59:47 --> Pixel_Model class loaded
INFO - 2018-10-18 09:59:47 --> Database Driver Class Initialized
INFO - 2018-10-18 09:59:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:59:47 --> Database Driver Class Initialized
INFO - 2018-10-18 09:59:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 09:59:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 09:59:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 09:59:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 09:59:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 09:59:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 09:59:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 09:59:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-18 09:59:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 09:59:47 --> Final output sent to browser
DEBUG - 2018-10-18 09:59:47 --> Total execution time: 0.0475
INFO - 2018-10-18 09:59:53 --> Config Class Initialized
INFO - 2018-10-18 09:59:53 --> Hooks Class Initialized
DEBUG - 2018-10-18 09:59:53 --> UTF-8 Support Enabled
INFO - 2018-10-18 09:59:53 --> Utf8 Class Initialized
INFO - 2018-10-18 09:59:53 --> URI Class Initialized
INFO - 2018-10-18 09:59:53 --> Router Class Initialized
INFO - 2018-10-18 09:59:53 --> Output Class Initialized
INFO - 2018-10-18 09:59:53 --> Security Class Initialized
DEBUG - 2018-10-18 09:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 09:59:53 --> CSRF cookie sent
INFO - 2018-10-18 09:59:53 --> Input Class Initialized
INFO - 2018-10-18 09:59:53 --> Language Class Initialized
ERROR - 2018-10-18 09:59:53 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 10:01:16 --> Config Class Initialized
INFO - 2018-10-18 10:01:16 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:01:16 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:01:16 --> Utf8 Class Initialized
INFO - 2018-10-18 10:01:16 --> URI Class Initialized
INFO - 2018-10-18 10:01:16 --> Router Class Initialized
INFO - 2018-10-18 10:01:16 --> Output Class Initialized
INFO - 2018-10-18 10:01:16 --> Security Class Initialized
DEBUG - 2018-10-18 10:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:01:16 --> CSRF cookie sent
INFO - 2018-10-18 10:01:16 --> Input Class Initialized
INFO - 2018-10-18 10:01:16 --> Language Class Initialized
INFO - 2018-10-18 10:01:16 --> Loader Class Initialized
INFO - 2018-10-18 10:01:16 --> Helper loaded: url_helper
INFO - 2018-10-18 10:01:16 --> Helper loaded: form_helper
INFO - 2018-10-18 10:01:16 --> Helper loaded: language_helper
DEBUG - 2018-10-18 10:01:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 10:01:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 10:01:16 --> User Agent Class Initialized
INFO - 2018-10-18 10:01:16 --> Controller Class Initialized
INFO - 2018-10-18 10:01:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 10:01:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 10:01:16 --> Pixel_Model class loaded
INFO - 2018-10-18 10:01:17 --> Database Driver Class Initialized
INFO - 2018-10-18 10:01:17 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:01:17 --> Database Driver Class Initialized
INFO - 2018-10-18 10:01:17 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:01:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 10:01:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 10:01:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 10:01:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 10:01:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 10:01:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 10:01:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-18 10:01:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 10:01:17 --> Final output sent to browser
DEBUG - 2018-10-18 10:01:17 --> Total execution time: 0.0404
INFO - 2018-10-18 10:01:22 --> Config Class Initialized
INFO - 2018-10-18 10:01:22 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:01:22 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:01:22 --> Utf8 Class Initialized
INFO - 2018-10-18 10:01:22 --> URI Class Initialized
INFO - 2018-10-18 10:01:22 --> Router Class Initialized
INFO - 2018-10-18 10:01:22 --> Output Class Initialized
INFO - 2018-10-18 10:01:22 --> Security Class Initialized
DEBUG - 2018-10-18 10:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:01:22 --> CSRF cookie sent
INFO - 2018-10-18 10:01:22 --> Input Class Initialized
INFO - 2018-10-18 10:01:22 --> Language Class Initialized
ERROR - 2018-10-18 10:01:22 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 10:02:03 --> Config Class Initialized
INFO - 2018-10-18 10:02:03 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:02:03 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:02:03 --> Utf8 Class Initialized
INFO - 2018-10-18 10:02:03 --> URI Class Initialized
INFO - 2018-10-18 10:02:03 --> Router Class Initialized
INFO - 2018-10-18 10:02:03 --> Output Class Initialized
INFO - 2018-10-18 10:02:03 --> Security Class Initialized
DEBUG - 2018-10-18 10:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:02:03 --> CSRF cookie sent
INFO - 2018-10-18 10:02:03 --> Input Class Initialized
INFO - 2018-10-18 10:02:03 --> Language Class Initialized
INFO - 2018-10-18 10:02:03 --> Loader Class Initialized
INFO - 2018-10-18 10:02:03 --> Helper loaded: url_helper
INFO - 2018-10-18 10:02:03 --> Helper loaded: form_helper
INFO - 2018-10-18 10:02:03 --> Helper loaded: language_helper
DEBUG - 2018-10-18 10:02:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 10:02:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 10:02:03 --> User Agent Class Initialized
INFO - 2018-10-18 10:02:03 --> Controller Class Initialized
INFO - 2018-10-18 10:02:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 10:02:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 10:02:03 --> Pixel_Model class loaded
INFO - 2018-10-18 10:02:03 --> Database Driver Class Initialized
INFO - 2018-10-18 10:02:03 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:02:03 --> Database Driver Class Initialized
INFO - 2018-10-18 10:02:03 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:02:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 10:02:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 10:02:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 10:02:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 10:02:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 10:02:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 10:02:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-18 10:02:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 10:02:03 --> Final output sent to browser
DEBUG - 2018-10-18 10:02:03 --> Total execution time: 0.0493
INFO - 2018-10-18 10:02:08 --> Config Class Initialized
INFO - 2018-10-18 10:02:08 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:02:08 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:02:08 --> Utf8 Class Initialized
INFO - 2018-10-18 10:02:08 --> URI Class Initialized
INFO - 2018-10-18 10:02:08 --> Router Class Initialized
INFO - 2018-10-18 10:02:08 --> Output Class Initialized
INFO - 2018-10-18 10:02:08 --> Security Class Initialized
DEBUG - 2018-10-18 10:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:02:08 --> CSRF cookie sent
INFO - 2018-10-18 10:02:08 --> Input Class Initialized
INFO - 2018-10-18 10:02:08 --> Language Class Initialized
ERROR - 2018-10-18 10:02:08 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 10:03:03 --> Config Class Initialized
INFO - 2018-10-18 10:03:03 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:03:03 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:03:03 --> Utf8 Class Initialized
INFO - 2018-10-18 10:03:03 --> URI Class Initialized
INFO - 2018-10-18 10:03:03 --> Router Class Initialized
INFO - 2018-10-18 10:03:03 --> Output Class Initialized
INFO - 2018-10-18 10:03:03 --> Security Class Initialized
DEBUG - 2018-10-18 10:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:03:03 --> CSRF cookie sent
INFO - 2018-10-18 10:03:03 --> Input Class Initialized
INFO - 2018-10-18 10:03:03 --> Language Class Initialized
INFO - 2018-10-18 10:03:03 --> Loader Class Initialized
INFO - 2018-10-18 10:03:03 --> Helper loaded: url_helper
INFO - 2018-10-18 10:03:03 --> Helper loaded: form_helper
INFO - 2018-10-18 10:03:03 --> Helper loaded: language_helper
DEBUG - 2018-10-18 10:03:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 10:03:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 10:03:03 --> User Agent Class Initialized
INFO - 2018-10-18 10:03:03 --> Controller Class Initialized
INFO - 2018-10-18 10:03:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 10:03:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 10:03:03 --> Pixel_Model class loaded
INFO - 2018-10-18 10:03:03 --> Database Driver Class Initialized
INFO - 2018-10-18 10:03:03 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:03:03 --> Database Driver Class Initialized
INFO - 2018-10-18 10:03:03 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:03:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 10:03:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 10:03:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 10:03:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 10:03:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 10:03:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 10:03:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-18 10:03:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 10:03:03 --> Final output sent to browser
DEBUG - 2018-10-18 10:03:03 --> Total execution time: 0.0419
INFO - 2018-10-18 10:03:08 --> Config Class Initialized
INFO - 2018-10-18 10:03:08 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:03:08 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:03:08 --> Utf8 Class Initialized
INFO - 2018-10-18 10:03:08 --> URI Class Initialized
INFO - 2018-10-18 10:03:08 --> Router Class Initialized
INFO - 2018-10-18 10:03:08 --> Output Class Initialized
INFO - 2018-10-18 10:03:08 --> Security Class Initialized
DEBUG - 2018-10-18 10:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:03:08 --> CSRF cookie sent
INFO - 2018-10-18 10:03:08 --> Input Class Initialized
INFO - 2018-10-18 10:03:08 --> Language Class Initialized
ERROR - 2018-10-18 10:03:08 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 10:05:49 --> Config Class Initialized
INFO - 2018-10-18 10:05:49 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:05:49 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:05:49 --> Utf8 Class Initialized
INFO - 2018-10-18 10:05:49 --> URI Class Initialized
INFO - 2018-10-18 10:05:49 --> Router Class Initialized
INFO - 2018-10-18 10:05:49 --> Output Class Initialized
INFO - 2018-10-18 10:05:49 --> Security Class Initialized
DEBUG - 2018-10-18 10:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:05:49 --> CSRF cookie sent
INFO - 2018-10-18 10:05:49 --> Input Class Initialized
INFO - 2018-10-18 10:05:49 --> Language Class Initialized
INFO - 2018-10-18 10:05:49 --> Loader Class Initialized
INFO - 2018-10-18 10:05:49 --> Helper loaded: url_helper
INFO - 2018-10-18 10:05:49 --> Helper loaded: form_helper
INFO - 2018-10-18 10:05:49 --> Helper loaded: language_helper
DEBUG - 2018-10-18 10:05:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 10:05:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 10:05:49 --> User Agent Class Initialized
INFO - 2018-10-18 10:05:49 --> Controller Class Initialized
INFO - 2018-10-18 10:05:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 10:05:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 10:05:49 --> Pixel_Model class loaded
INFO - 2018-10-18 10:05:49 --> Database Driver Class Initialized
INFO - 2018-10-18 10:05:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:05:49 --> Database Driver Class Initialized
INFO - 2018-10-18 10:05:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:05:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 10:05:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 10:05:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 10:05:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 10:05:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 10:05:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 10:05:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-18 10:05:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 10:05:49 --> Final output sent to browser
DEBUG - 2018-10-18 10:05:49 --> Total execution time: 0.0560
INFO - 2018-10-18 10:05:55 --> Config Class Initialized
INFO - 2018-10-18 10:05:55 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:05:55 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:05:55 --> Utf8 Class Initialized
INFO - 2018-10-18 10:05:55 --> URI Class Initialized
INFO - 2018-10-18 10:05:55 --> Router Class Initialized
INFO - 2018-10-18 10:05:55 --> Output Class Initialized
INFO - 2018-10-18 10:05:55 --> Security Class Initialized
DEBUG - 2018-10-18 10:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:05:55 --> CSRF cookie sent
INFO - 2018-10-18 10:05:55 --> Input Class Initialized
INFO - 2018-10-18 10:05:55 --> Language Class Initialized
ERROR - 2018-10-18 10:05:55 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 10:06:10 --> Config Class Initialized
INFO - 2018-10-18 10:06:10 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:06:10 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:06:10 --> Utf8 Class Initialized
INFO - 2018-10-18 10:06:10 --> URI Class Initialized
INFO - 2018-10-18 10:06:10 --> Router Class Initialized
INFO - 2018-10-18 10:06:10 --> Output Class Initialized
INFO - 2018-10-18 10:06:10 --> Security Class Initialized
DEBUG - 2018-10-18 10:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:06:10 --> CSRF cookie sent
INFO - 2018-10-18 10:06:10 --> Input Class Initialized
INFO - 2018-10-18 10:06:10 --> Language Class Initialized
INFO - 2018-10-18 10:06:10 --> Loader Class Initialized
INFO - 2018-10-18 10:06:10 --> Helper loaded: url_helper
INFO - 2018-10-18 10:06:10 --> Helper loaded: form_helper
INFO - 2018-10-18 10:06:10 --> Helper loaded: language_helper
DEBUG - 2018-10-18 10:06:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 10:06:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 10:06:10 --> User Agent Class Initialized
INFO - 2018-10-18 10:06:10 --> Controller Class Initialized
INFO - 2018-10-18 10:06:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 10:06:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 10:06:10 --> Pixel_Model class loaded
INFO - 2018-10-18 10:06:10 --> Database Driver Class Initialized
INFO - 2018-10-18 10:06:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:06:10 --> Database Driver Class Initialized
INFO - 2018-10-18 10:06:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:06:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 10:06:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 10:06:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 10:06:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 10:06:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 10:06:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 10:06:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-18 10:06:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 10:06:10 --> Final output sent to browser
DEBUG - 2018-10-18 10:06:10 --> Total execution time: 0.0539
INFO - 2018-10-18 10:07:11 --> Config Class Initialized
INFO - 2018-10-18 10:07:11 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:07:11 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:07:11 --> Utf8 Class Initialized
INFO - 2018-10-18 10:07:11 --> URI Class Initialized
INFO - 2018-10-18 10:07:11 --> Router Class Initialized
INFO - 2018-10-18 10:07:11 --> Output Class Initialized
INFO - 2018-10-18 10:07:11 --> Security Class Initialized
DEBUG - 2018-10-18 10:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:07:11 --> CSRF cookie sent
INFO - 2018-10-18 10:07:11 --> Input Class Initialized
INFO - 2018-10-18 10:07:11 --> Language Class Initialized
INFO - 2018-10-18 10:07:11 --> Loader Class Initialized
INFO - 2018-10-18 10:07:11 --> Helper loaded: url_helper
INFO - 2018-10-18 10:07:11 --> Helper loaded: form_helper
INFO - 2018-10-18 10:07:11 --> Helper loaded: language_helper
DEBUG - 2018-10-18 10:07:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 10:07:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 10:07:11 --> User Agent Class Initialized
INFO - 2018-10-18 10:07:11 --> Controller Class Initialized
INFO - 2018-10-18 10:07:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 10:07:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 10:07:11 --> Pixel_Model class loaded
INFO - 2018-10-18 10:07:11 --> Database Driver Class Initialized
INFO - 2018-10-18 10:07:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:07:11 --> Database Driver Class Initialized
INFO - 2018-10-18 10:07:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:07:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 10:07:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 10:07:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 10:07:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 10:07:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 10:07:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 10:07:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-18 10:07:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 10:07:11 --> Final output sent to browser
DEBUG - 2018-10-18 10:07:11 --> Total execution time: 0.0591
INFO - 2018-10-18 10:07:21 --> Config Class Initialized
INFO - 2018-10-18 10:07:21 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:07:21 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:07:21 --> Utf8 Class Initialized
INFO - 2018-10-18 10:07:21 --> URI Class Initialized
INFO - 2018-10-18 10:07:21 --> Router Class Initialized
INFO - 2018-10-18 10:07:21 --> Output Class Initialized
INFO - 2018-10-18 10:07:21 --> Security Class Initialized
DEBUG - 2018-10-18 10:07:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:07:21 --> CSRF cookie sent
INFO - 2018-10-18 10:07:21 --> Input Class Initialized
INFO - 2018-10-18 10:07:21 --> Language Class Initialized
INFO - 2018-10-18 10:07:21 --> Loader Class Initialized
INFO - 2018-10-18 10:07:21 --> Helper loaded: url_helper
INFO - 2018-10-18 10:07:21 --> Helper loaded: form_helper
INFO - 2018-10-18 10:07:21 --> Helper loaded: language_helper
DEBUG - 2018-10-18 10:07:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 10:07:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 10:07:21 --> User Agent Class Initialized
INFO - 2018-10-18 10:07:21 --> Controller Class Initialized
INFO - 2018-10-18 10:07:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 10:07:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 10:07:21 --> Pixel_Model class loaded
INFO - 2018-10-18 10:07:21 --> Database Driver Class Initialized
INFO - 2018-10-18 10:07:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:07:21 --> Database Driver Class Initialized
INFO - 2018-10-18 10:07:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:07:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 10:07:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 10:07:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 10:07:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 10:07:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 10:07:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 10:07:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-18 10:07:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 10:07:21 --> Final output sent to browser
DEBUG - 2018-10-18 10:07:21 --> Total execution time: 0.0444
INFO - 2018-10-18 10:07:27 --> Config Class Initialized
INFO - 2018-10-18 10:07:27 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:07:27 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:07:27 --> Utf8 Class Initialized
INFO - 2018-10-18 10:07:27 --> URI Class Initialized
INFO - 2018-10-18 10:07:27 --> Router Class Initialized
INFO - 2018-10-18 10:07:27 --> Output Class Initialized
INFO - 2018-10-18 10:07:27 --> Security Class Initialized
DEBUG - 2018-10-18 10:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:07:27 --> CSRF cookie sent
INFO - 2018-10-18 10:07:27 --> Input Class Initialized
INFO - 2018-10-18 10:07:27 --> Language Class Initialized
ERROR - 2018-10-18 10:07:27 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 10:10:38 --> Config Class Initialized
INFO - 2018-10-18 10:10:38 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:10:38 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:10:38 --> Utf8 Class Initialized
INFO - 2018-10-18 10:10:38 --> URI Class Initialized
INFO - 2018-10-18 10:10:38 --> Router Class Initialized
INFO - 2018-10-18 10:10:38 --> Output Class Initialized
INFO - 2018-10-18 10:10:38 --> Security Class Initialized
DEBUG - 2018-10-18 10:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:10:38 --> CSRF cookie sent
INFO - 2018-10-18 10:10:38 --> Input Class Initialized
INFO - 2018-10-18 10:10:38 --> Language Class Initialized
INFO - 2018-10-18 10:10:38 --> Loader Class Initialized
INFO - 2018-10-18 10:10:38 --> Helper loaded: url_helper
INFO - 2018-10-18 10:10:38 --> Helper loaded: form_helper
INFO - 2018-10-18 10:10:38 --> Helper loaded: language_helper
DEBUG - 2018-10-18 10:10:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 10:10:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 10:10:38 --> User Agent Class Initialized
INFO - 2018-10-18 10:10:38 --> Controller Class Initialized
INFO - 2018-10-18 10:10:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 10:10:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 10:10:38 --> Pixel_Model class loaded
INFO - 2018-10-18 10:10:38 --> Database Driver Class Initialized
INFO - 2018-10-18 10:10:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:10:38 --> Database Driver Class Initialized
INFO - 2018-10-18 10:10:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:10:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 10:10:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 10:10:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 10:10:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 10:10:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 10:10:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 10:10:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-18 10:10:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 10:10:38 --> Final output sent to browser
DEBUG - 2018-10-18 10:10:38 --> Total execution time: 0.0530
INFO - 2018-10-18 10:10:44 --> Config Class Initialized
INFO - 2018-10-18 10:10:44 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:10:44 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:10:44 --> Utf8 Class Initialized
INFO - 2018-10-18 10:10:44 --> URI Class Initialized
INFO - 2018-10-18 10:10:44 --> Router Class Initialized
INFO - 2018-10-18 10:10:44 --> Output Class Initialized
INFO - 2018-10-18 10:10:44 --> Security Class Initialized
DEBUG - 2018-10-18 10:10:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:10:44 --> CSRF cookie sent
INFO - 2018-10-18 10:10:44 --> Input Class Initialized
INFO - 2018-10-18 10:10:44 --> Language Class Initialized
ERROR - 2018-10-18 10:10:44 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 10:11:23 --> Config Class Initialized
INFO - 2018-10-18 10:11:23 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:11:23 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:11:23 --> Utf8 Class Initialized
INFO - 2018-10-18 10:11:23 --> URI Class Initialized
INFO - 2018-10-18 10:11:23 --> Router Class Initialized
INFO - 2018-10-18 10:11:23 --> Output Class Initialized
INFO - 2018-10-18 10:11:23 --> Security Class Initialized
DEBUG - 2018-10-18 10:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:11:23 --> CSRF cookie sent
INFO - 2018-10-18 10:11:23 --> Input Class Initialized
INFO - 2018-10-18 10:11:23 --> Language Class Initialized
INFO - 2018-10-18 10:11:23 --> Loader Class Initialized
INFO - 2018-10-18 10:11:23 --> Helper loaded: url_helper
INFO - 2018-10-18 10:11:23 --> Helper loaded: form_helper
INFO - 2018-10-18 10:11:23 --> Helper loaded: language_helper
DEBUG - 2018-10-18 10:11:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 10:11:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 10:11:23 --> User Agent Class Initialized
INFO - 2018-10-18 10:11:23 --> Controller Class Initialized
INFO - 2018-10-18 10:11:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 10:11:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 10:11:23 --> Pixel_Model class loaded
INFO - 2018-10-18 10:11:23 --> Database Driver Class Initialized
INFO - 2018-10-18 10:11:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:11:23 --> Database Driver Class Initialized
INFO - 2018-10-18 10:11:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:11:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 10:11:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 10:11:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 10:11:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 10:11:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 10:11:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 10:11:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-18 10:11:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 10:11:23 --> Final output sent to browser
DEBUG - 2018-10-18 10:11:23 --> Total execution time: 0.0410
INFO - 2018-10-18 10:11:28 --> Config Class Initialized
INFO - 2018-10-18 10:11:28 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:11:28 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:11:28 --> Utf8 Class Initialized
INFO - 2018-10-18 10:11:28 --> URI Class Initialized
INFO - 2018-10-18 10:11:28 --> Router Class Initialized
INFO - 2018-10-18 10:11:28 --> Output Class Initialized
INFO - 2018-10-18 10:11:28 --> Security Class Initialized
DEBUG - 2018-10-18 10:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:11:28 --> CSRF cookie sent
INFO - 2018-10-18 10:11:28 --> Input Class Initialized
INFO - 2018-10-18 10:11:28 --> Language Class Initialized
ERROR - 2018-10-18 10:11:28 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 10:11:34 --> Config Class Initialized
INFO - 2018-10-18 10:11:34 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:11:34 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:11:34 --> Utf8 Class Initialized
INFO - 2018-10-18 10:11:34 --> URI Class Initialized
INFO - 2018-10-18 10:11:34 --> Router Class Initialized
INFO - 2018-10-18 10:11:34 --> Output Class Initialized
INFO - 2018-10-18 10:11:34 --> Security Class Initialized
DEBUG - 2018-10-18 10:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:11:34 --> CSRF cookie sent
INFO - 2018-10-18 10:11:34 --> Input Class Initialized
INFO - 2018-10-18 10:11:34 --> Language Class Initialized
INFO - 2018-10-18 10:11:34 --> Loader Class Initialized
INFO - 2018-10-18 10:11:34 --> Helper loaded: url_helper
INFO - 2018-10-18 10:11:34 --> Helper loaded: form_helper
INFO - 2018-10-18 10:11:34 --> Helper loaded: language_helper
DEBUG - 2018-10-18 10:11:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 10:11:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 10:11:34 --> User Agent Class Initialized
INFO - 2018-10-18 10:11:34 --> Controller Class Initialized
INFO - 2018-10-18 10:11:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 10:11:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 10:11:34 --> Pixel_Model class loaded
INFO - 2018-10-18 10:11:34 --> Database Driver Class Initialized
INFO - 2018-10-18 10:11:34 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:11:34 --> Database Driver Class Initialized
INFO - 2018-10-18 10:11:34 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:11:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 10:11:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 10:11:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 10:11:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 10:11:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 10:11:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 10:11:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-18 10:11:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 10:11:34 --> Final output sent to browser
DEBUG - 2018-10-18 10:11:34 --> Total execution time: 0.0481
INFO - 2018-10-18 10:11:40 --> Config Class Initialized
INFO - 2018-10-18 10:11:40 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:11:40 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:11:40 --> Utf8 Class Initialized
INFO - 2018-10-18 10:11:40 --> URI Class Initialized
INFO - 2018-10-18 10:11:40 --> Router Class Initialized
INFO - 2018-10-18 10:11:40 --> Output Class Initialized
INFO - 2018-10-18 10:11:40 --> Security Class Initialized
DEBUG - 2018-10-18 10:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:11:40 --> CSRF cookie sent
INFO - 2018-10-18 10:11:40 --> Input Class Initialized
INFO - 2018-10-18 10:11:40 --> Language Class Initialized
INFO - 2018-10-18 10:11:40 --> Loader Class Initialized
INFO - 2018-10-18 10:11:40 --> Helper loaded: url_helper
INFO - 2018-10-18 10:11:40 --> Helper loaded: form_helper
INFO - 2018-10-18 10:11:40 --> Helper loaded: language_helper
DEBUG - 2018-10-18 10:11:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 10:11:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 10:11:40 --> User Agent Class Initialized
INFO - 2018-10-18 10:11:40 --> Controller Class Initialized
INFO - 2018-10-18 10:11:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 10:11:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 10:11:40 --> Pixel_Model class loaded
INFO - 2018-10-18 10:11:40 --> Database Driver Class Initialized
INFO - 2018-10-18 10:11:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:11:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 10:11:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 10:11:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 10:11:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 10:11:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 10:11:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 10:11:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-10-18 10:11:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 10:11:40 --> Final output sent to browser
DEBUG - 2018-10-18 10:11:40 --> Total execution time: 0.0440
INFO - 2018-10-18 10:11:44 --> Config Class Initialized
INFO - 2018-10-18 10:11:44 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:11:44 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:11:44 --> Utf8 Class Initialized
INFO - 2018-10-18 10:11:44 --> URI Class Initialized
INFO - 2018-10-18 10:11:44 --> Router Class Initialized
INFO - 2018-10-18 10:11:44 --> Output Class Initialized
INFO - 2018-10-18 10:11:44 --> Security Class Initialized
DEBUG - 2018-10-18 10:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:11:44 --> CSRF cookie sent
INFO - 2018-10-18 10:11:44 --> CSRF token verified
INFO - 2018-10-18 10:11:44 --> Input Class Initialized
INFO - 2018-10-18 10:11:44 --> Language Class Initialized
INFO - 2018-10-18 10:11:44 --> Loader Class Initialized
INFO - 2018-10-18 10:11:44 --> Helper loaded: url_helper
INFO - 2018-10-18 10:11:44 --> Helper loaded: form_helper
INFO - 2018-10-18 10:11:44 --> Helper loaded: language_helper
DEBUG - 2018-10-18 10:11:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 10:11:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 10:11:44 --> User Agent Class Initialized
INFO - 2018-10-18 10:11:44 --> Controller Class Initialized
INFO - 2018-10-18 10:11:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 10:11:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 10:11:44 --> Pixel_Model class loaded
INFO - 2018-10-18 10:11:44 --> Database Driver Class Initialized
INFO - 2018-10-18 10:11:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:11:44 --> Form Validation Class Initialized
INFO - 2018-10-18 10:11:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 10:11:44 --> Database Driver Class Initialized
INFO - 2018-10-18 10:11:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:11:44 --> Config Class Initialized
INFO - 2018-10-18 10:11:44 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:11:44 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:11:44 --> Utf8 Class Initialized
INFO - 2018-10-18 10:11:44 --> URI Class Initialized
INFO - 2018-10-18 10:11:44 --> Router Class Initialized
INFO - 2018-10-18 10:11:44 --> Output Class Initialized
INFO - 2018-10-18 10:11:44 --> Security Class Initialized
DEBUG - 2018-10-18 10:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:11:44 --> CSRF cookie sent
INFO - 2018-10-18 10:11:44 --> Input Class Initialized
INFO - 2018-10-18 10:11:44 --> Language Class Initialized
INFO - 2018-10-18 10:11:44 --> Loader Class Initialized
INFO - 2018-10-18 10:11:44 --> Helper loaded: url_helper
INFO - 2018-10-18 10:11:44 --> Helper loaded: form_helper
INFO - 2018-10-18 10:11:44 --> Helper loaded: language_helper
DEBUG - 2018-10-18 10:11:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 10:11:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 10:11:44 --> User Agent Class Initialized
INFO - 2018-10-18 10:11:44 --> Controller Class Initialized
INFO - 2018-10-18 10:11:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 10:11:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 10:11:44 --> Pixel_Model class loaded
INFO - 2018-10-18 10:11:44 --> Database Driver Class Initialized
INFO - 2018-10-18 10:11:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:11:44 --> Database Driver Class Initialized
INFO - 2018-10-18 10:11:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:11:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 10:11:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 10:11:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 10:11:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 10:11:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 10:11:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 10:11:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-18 10:11:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 10:11:44 --> Final output sent to browser
DEBUG - 2018-10-18 10:11:44 --> Total execution time: 0.0451
INFO - 2018-10-18 10:11:49 --> Config Class Initialized
INFO - 2018-10-18 10:11:49 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:11:49 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:11:49 --> Utf8 Class Initialized
INFO - 2018-10-18 10:11:49 --> URI Class Initialized
INFO - 2018-10-18 10:11:49 --> Router Class Initialized
INFO - 2018-10-18 10:11:49 --> Output Class Initialized
INFO - 2018-10-18 10:11:49 --> Security Class Initialized
DEBUG - 2018-10-18 10:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:11:49 --> CSRF cookie sent
INFO - 2018-10-18 10:11:49 --> CSRF token verified
INFO - 2018-10-18 10:11:49 --> Input Class Initialized
INFO - 2018-10-18 10:11:49 --> Language Class Initialized
INFO - 2018-10-18 10:11:49 --> Loader Class Initialized
INFO - 2018-10-18 10:11:49 --> Helper loaded: url_helper
INFO - 2018-10-18 10:11:49 --> Helper loaded: form_helper
INFO - 2018-10-18 10:11:49 --> Helper loaded: language_helper
DEBUG - 2018-10-18 10:11:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 10:11:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 10:11:49 --> User Agent Class Initialized
INFO - 2018-10-18 10:11:49 --> Controller Class Initialized
INFO - 2018-10-18 10:11:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 10:11:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 10:11:49 --> Pixel_Model class loaded
INFO - 2018-10-18 10:11:49 --> Database Driver Class Initialized
INFO - 2018-10-18 10:11:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:11:49 --> Form Validation Class Initialized
INFO - 2018-10-18 10:11:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 10:11:49 --> Database Driver Class Initialized
INFO - 2018-10-18 10:11:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:11:49 --> Config Class Initialized
INFO - 2018-10-18 10:11:49 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:11:49 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:11:49 --> Utf8 Class Initialized
INFO - 2018-10-18 10:11:49 --> URI Class Initialized
INFO - 2018-10-18 10:11:49 --> Router Class Initialized
INFO - 2018-10-18 10:11:49 --> Output Class Initialized
INFO - 2018-10-18 10:11:49 --> Security Class Initialized
DEBUG - 2018-10-18 10:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:11:49 --> CSRF cookie sent
INFO - 2018-10-18 10:11:49 --> Input Class Initialized
INFO - 2018-10-18 10:11:49 --> Language Class Initialized
INFO - 2018-10-18 10:11:49 --> Loader Class Initialized
INFO - 2018-10-18 10:11:49 --> Helper loaded: url_helper
INFO - 2018-10-18 10:11:49 --> Helper loaded: form_helper
INFO - 2018-10-18 10:11:49 --> Helper loaded: language_helper
DEBUG - 2018-10-18 10:11:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 10:11:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 10:11:49 --> User Agent Class Initialized
INFO - 2018-10-18 10:11:49 --> Controller Class Initialized
INFO - 2018-10-18 10:11:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 10:11:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 10:11:49 --> Pixel_Model class loaded
INFO - 2018-10-18 10:11:49 --> Database Driver Class Initialized
INFO - 2018-10-18 10:11:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:11:49 --> Database Driver Class Initialized
INFO - 2018-10-18 10:11:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:11:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 10:11:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 10:11:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 10:11:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 10:11:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 10:11:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 10:11:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-10-18 10:11:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 10:11:49 --> Final output sent to browser
DEBUG - 2018-10-18 10:11:49 --> Total execution time: 0.0572
INFO - 2018-10-18 10:11:51 --> Config Class Initialized
INFO - 2018-10-18 10:11:51 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:11:51 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:11:51 --> Utf8 Class Initialized
INFO - 2018-10-18 10:11:51 --> URI Class Initialized
INFO - 2018-10-18 10:11:51 --> Router Class Initialized
INFO - 2018-10-18 10:11:51 --> Output Class Initialized
INFO - 2018-10-18 10:11:51 --> Security Class Initialized
DEBUG - 2018-10-18 10:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:11:51 --> CSRF cookie sent
INFO - 2018-10-18 10:11:51 --> CSRF token verified
INFO - 2018-10-18 10:11:51 --> Input Class Initialized
INFO - 2018-10-18 10:11:51 --> Language Class Initialized
INFO - 2018-10-18 10:11:51 --> Loader Class Initialized
INFO - 2018-10-18 10:11:51 --> Helper loaded: url_helper
INFO - 2018-10-18 10:11:51 --> Helper loaded: form_helper
INFO - 2018-10-18 10:11:51 --> Helper loaded: language_helper
DEBUG - 2018-10-18 10:11:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 10:11:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 10:11:51 --> User Agent Class Initialized
INFO - 2018-10-18 10:11:51 --> Controller Class Initialized
INFO - 2018-10-18 10:11:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 10:11:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 10:11:51 --> Pixel_Model class loaded
INFO - 2018-10-18 10:11:51 --> Database Driver Class Initialized
INFO - 2018-10-18 10:11:51 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:11:51 --> Form Validation Class Initialized
INFO - 2018-10-18 10:11:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 10:11:51 --> Database Driver Class Initialized
INFO - 2018-10-18 10:11:51 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:11:52 --> Config Class Initialized
INFO - 2018-10-18 10:11:52 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:11:52 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:11:52 --> Utf8 Class Initialized
INFO - 2018-10-18 10:11:52 --> URI Class Initialized
INFO - 2018-10-18 10:11:52 --> Router Class Initialized
INFO - 2018-10-18 10:11:52 --> Output Class Initialized
INFO - 2018-10-18 10:11:52 --> Security Class Initialized
DEBUG - 2018-10-18 10:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:11:52 --> CSRF cookie sent
INFO - 2018-10-18 10:11:52 --> Input Class Initialized
INFO - 2018-10-18 10:11:52 --> Language Class Initialized
INFO - 2018-10-18 10:11:52 --> Loader Class Initialized
INFO - 2018-10-18 10:11:52 --> Helper loaded: url_helper
INFO - 2018-10-18 10:11:52 --> Helper loaded: form_helper
INFO - 2018-10-18 10:11:52 --> Helper loaded: language_helper
DEBUG - 2018-10-18 10:11:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 10:11:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 10:11:52 --> User Agent Class Initialized
INFO - 2018-10-18 10:11:52 --> Controller Class Initialized
INFO - 2018-10-18 10:11:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 10:11:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 10:11:52 --> Pixel_Model class loaded
INFO - 2018-10-18 10:11:52 --> Database Driver Class Initialized
INFO - 2018-10-18 10:11:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:11:52 --> Database Driver Class Initialized
INFO - 2018-10-18 10:11:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:11:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 10:11:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 10:11:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-10-18 10:11:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 10:11:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 10:11:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 10:11:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 10:11:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-10-18 10:11:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 10:11:52 --> Final output sent to browser
DEBUG - 2018-10-18 10:11:52 --> Total execution time: 0.0522
INFO - 2018-10-18 10:11:55 --> Config Class Initialized
INFO - 2018-10-18 10:11:55 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:11:55 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:11:55 --> Utf8 Class Initialized
INFO - 2018-10-18 10:11:55 --> URI Class Initialized
INFO - 2018-10-18 10:11:55 --> Router Class Initialized
INFO - 2018-10-18 10:11:55 --> Output Class Initialized
INFO - 2018-10-18 10:11:55 --> Security Class Initialized
DEBUG - 2018-10-18 10:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:11:55 --> CSRF cookie sent
INFO - 2018-10-18 10:11:55 --> CSRF token verified
INFO - 2018-10-18 10:11:55 --> Input Class Initialized
INFO - 2018-10-18 10:11:55 --> Language Class Initialized
INFO - 2018-10-18 10:11:55 --> Loader Class Initialized
INFO - 2018-10-18 10:11:55 --> Helper loaded: url_helper
INFO - 2018-10-18 10:11:55 --> Helper loaded: form_helper
INFO - 2018-10-18 10:11:55 --> Helper loaded: language_helper
DEBUG - 2018-10-18 10:11:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 10:11:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 10:11:55 --> User Agent Class Initialized
INFO - 2018-10-18 10:11:55 --> Controller Class Initialized
INFO - 2018-10-18 10:11:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 10:11:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 10:11:55 --> Pixel_Model class loaded
INFO - 2018-10-18 10:11:55 --> Database Driver Class Initialized
INFO - 2018-10-18 10:11:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:11:55 --> Form Validation Class Initialized
INFO - 2018-10-18 10:11:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 10:11:55 --> Database Driver Class Initialized
INFO - 2018-10-18 10:11:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:11:56 --> Config Class Initialized
INFO - 2018-10-18 10:11:56 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:11:56 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:11:56 --> Utf8 Class Initialized
INFO - 2018-10-18 10:11:56 --> URI Class Initialized
INFO - 2018-10-18 10:11:56 --> Router Class Initialized
INFO - 2018-10-18 10:11:56 --> Output Class Initialized
INFO - 2018-10-18 10:11:56 --> Security Class Initialized
DEBUG - 2018-10-18 10:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:11:56 --> CSRF cookie sent
INFO - 2018-10-18 10:11:56 --> Input Class Initialized
INFO - 2018-10-18 10:11:56 --> Language Class Initialized
INFO - 2018-10-18 10:11:56 --> Loader Class Initialized
INFO - 2018-10-18 10:11:56 --> Helper loaded: url_helper
INFO - 2018-10-18 10:11:56 --> Helper loaded: form_helper
INFO - 2018-10-18 10:11:56 --> Helper loaded: language_helper
DEBUG - 2018-10-18 10:11:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 10:11:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 10:11:56 --> User Agent Class Initialized
INFO - 2018-10-18 10:11:56 --> Controller Class Initialized
INFO - 2018-10-18 10:11:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 10:11:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 10:11:56 --> Pixel_Model class loaded
INFO - 2018-10-18 10:11:56 --> Database Driver Class Initialized
INFO - 2018-10-18 10:11:56 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:11:56 --> Database Driver Class Initialized
INFO - 2018-10-18 10:11:56 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:11:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 10:11:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 10:11:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 10:11:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 10:11:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 10:11:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 10:11:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-18 10:11:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 10:11:56 --> Final output sent to browser
DEBUG - 2018-10-18 10:11:56 --> Total execution time: 0.0370
INFO - 2018-10-18 10:12:39 --> Config Class Initialized
INFO - 2018-10-18 10:12:39 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:12:39 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:12:39 --> Utf8 Class Initialized
INFO - 2018-10-18 10:12:39 --> URI Class Initialized
INFO - 2018-10-18 10:12:39 --> Router Class Initialized
INFO - 2018-10-18 10:12:39 --> Output Class Initialized
INFO - 2018-10-18 10:12:39 --> Security Class Initialized
DEBUG - 2018-10-18 10:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:12:39 --> CSRF cookie sent
INFO - 2018-10-18 10:12:39 --> Input Class Initialized
INFO - 2018-10-18 10:12:39 --> Language Class Initialized
INFO - 2018-10-18 10:12:39 --> Loader Class Initialized
INFO - 2018-10-18 10:12:39 --> Helper loaded: url_helper
INFO - 2018-10-18 10:12:39 --> Helper loaded: form_helper
INFO - 2018-10-18 10:12:39 --> Helper loaded: language_helper
DEBUG - 2018-10-18 10:12:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 10:12:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 10:12:39 --> User Agent Class Initialized
INFO - 2018-10-18 10:12:39 --> Controller Class Initialized
INFO - 2018-10-18 10:12:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 10:12:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 10:12:39 --> Pixel_Model class loaded
INFO - 2018-10-18 10:12:39 --> Database Driver Class Initialized
INFO - 2018-10-18 10:12:39 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:12:39 --> Database Driver Class Initialized
INFO - 2018-10-18 10:12:39 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:12:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 10:12:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 10:12:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 10:12:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 10:12:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 10:12:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 10:12:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-18 10:12:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 10:12:39 --> Final output sent to browser
DEBUG - 2018-10-18 10:12:39 --> Total execution time: 0.0441
INFO - 2018-10-18 10:12:48 --> Config Class Initialized
INFO - 2018-10-18 10:12:48 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:12:48 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:12:48 --> Utf8 Class Initialized
INFO - 2018-10-18 10:12:48 --> URI Class Initialized
INFO - 2018-10-18 10:12:48 --> Router Class Initialized
INFO - 2018-10-18 10:12:48 --> Output Class Initialized
INFO - 2018-10-18 10:12:48 --> Security Class Initialized
DEBUG - 2018-10-18 10:12:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:12:48 --> CSRF cookie sent
INFO - 2018-10-18 10:12:48 --> CSRF token verified
INFO - 2018-10-18 10:12:48 --> Input Class Initialized
INFO - 2018-10-18 10:12:48 --> Language Class Initialized
INFO - 2018-10-18 10:12:48 --> Loader Class Initialized
INFO - 2018-10-18 10:12:48 --> Helper loaded: url_helper
INFO - 2018-10-18 10:12:48 --> Helper loaded: form_helper
INFO - 2018-10-18 10:12:48 --> Helper loaded: language_helper
DEBUG - 2018-10-18 10:12:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 10:12:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 10:12:48 --> User Agent Class Initialized
INFO - 2018-10-18 10:12:48 --> Controller Class Initialized
INFO - 2018-10-18 10:12:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 10:12:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 10:12:48 --> Pixel_Model class loaded
INFO - 2018-10-18 10:12:48 --> Database Driver Class Initialized
INFO - 2018-10-18 10:12:48 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:12:48 --> Form Validation Class Initialized
INFO - 2018-10-18 10:12:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 10:12:48 --> Database Driver Class Initialized
INFO - 2018-10-18 10:12:48 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:12:48 --> Config Class Initialized
INFO - 2018-10-18 10:12:48 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:12:48 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:12:48 --> Utf8 Class Initialized
INFO - 2018-10-18 10:12:48 --> URI Class Initialized
INFO - 2018-10-18 10:12:48 --> Router Class Initialized
INFO - 2018-10-18 10:12:48 --> Output Class Initialized
INFO - 2018-10-18 10:12:48 --> Security Class Initialized
DEBUG - 2018-10-18 10:12:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:12:48 --> CSRF cookie sent
INFO - 2018-10-18 10:12:48 --> Input Class Initialized
INFO - 2018-10-18 10:12:48 --> Language Class Initialized
INFO - 2018-10-18 10:12:48 --> Loader Class Initialized
INFO - 2018-10-18 10:12:48 --> Helper loaded: url_helper
INFO - 2018-10-18 10:12:48 --> Helper loaded: form_helper
INFO - 2018-10-18 10:12:48 --> Helper loaded: language_helper
DEBUG - 2018-10-18 10:12:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 10:12:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 10:12:48 --> User Agent Class Initialized
INFO - 2018-10-18 10:12:48 --> Controller Class Initialized
INFO - 2018-10-18 10:12:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 10:12:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 10:12:48 --> Pixel_Model class loaded
INFO - 2018-10-18 10:12:48 --> Database Driver Class Initialized
INFO - 2018-10-18 10:12:48 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:12:48 --> Database Driver Class Initialized
INFO - 2018-10-18 10:12:48 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:12:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 10:12:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 10:12:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 10:12:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 10:12:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 10:12:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 10:12:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/marriage.php
INFO - 2018-10-18 10:12:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 10:12:48 --> Final output sent to browser
DEBUG - 2018-10-18 10:12:48 --> Total execution time: 0.0390
INFO - 2018-10-18 10:12:53 --> Config Class Initialized
INFO - 2018-10-18 10:12:53 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:12:53 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:12:53 --> Utf8 Class Initialized
INFO - 2018-10-18 10:12:53 --> URI Class Initialized
INFO - 2018-10-18 10:12:53 --> Router Class Initialized
INFO - 2018-10-18 10:12:53 --> Output Class Initialized
INFO - 2018-10-18 10:12:53 --> Security Class Initialized
DEBUG - 2018-10-18 10:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:12:53 --> CSRF cookie sent
INFO - 2018-10-18 10:12:53 --> CSRF token verified
INFO - 2018-10-18 10:12:53 --> Input Class Initialized
INFO - 2018-10-18 10:12:53 --> Language Class Initialized
INFO - 2018-10-18 10:12:53 --> Loader Class Initialized
INFO - 2018-10-18 10:12:53 --> Helper loaded: url_helper
INFO - 2018-10-18 10:12:53 --> Helper loaded: form_helper
INFO - 2018-10-18 10:12:53 --> Helper loaded: language_helper
DEBUG - 2018-10-18 10:12:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 10:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 10:12:53 --> User Agent Class Initialized
INFO - 2018-10-18 10:12:53 --> Controller Class Initialized
INFO - 2018-10-18 10:12:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 10:12:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 10:12:53 --> Pixel_Model class loaded
INFO - 2018-10-18 10:12:53 --> Database Driver Class Initialized
INFO - 2018-10-18 10:12:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:12:53 --> Form Validation Class Initialized
INFO - 2018-10-18 10:12:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 10:12:53 --> Database Driver Class Initialized
INFO - 2018-10-18 10:12:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:12:53 --> Config Class Initialized
INFO - 2018-10-18 10:12:53 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:12:53 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:12:53 --> Utf8 Class Initialized
INFO - 2018-10-18 10:12:53 --> URI Class Initialized
INFO - 2018-10-18 10:12:53 --> Router Class Initialized
INFO - 2018-10-18 10:12:53 --> Output Class Initialized
INFO - 2018-10-18 10:12:53 --> Security Class Initialized
DEBUG - 2018-10-18 10:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:12:53 --> CSRF cookie sent
INFO - 2018-10-18 10:12:53 --> Input Class Initialized
INFO - 2018-10-18 10:12:53 --> Language Class Initialized
INFO - 2018-10-18 10:12:53 --> Loader Class Initialized
INFO - 2018-10-18 10:12:53 --> Helper loaded: url_helper
INFO - 2018-10-18 10:12:53 --> Helper loaded: form_helper
INFO - 2018-10-18 10:12:53 --> Helper loaded: language_helper
DEBUG - 2018-10-18 10:12:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 10:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 10:12:53 --> User Agent Class Initialized
INFO - 2018-10-18 10:12:53 --> Controller Class Initialized
INFO - 2018-10-18 10:12:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 10:12:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 10:12:53 --> Pixel_Model class loaded
INFO - 2018-10-18 10:12:53 --> Database Driver Class Initialized
INFO - 2018-10-18 10:12:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:12:53 --> Database Driver Class Initialized
INFO - 2018-10-18 10:12:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:12:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 10:12:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 10:12:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 10:12:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 10:12:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 10:12:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 10:12:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-10-18 10:12:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 10:12:53 --> Final output sent to browser
DEBUG - 2018-10-18 10:12:53 --> Total execution time: 0.0459
INFO - 2018-10-18 10:12:58 --> Config Class Initialized
INFO - 2018-10-18 10:12:58 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:12:58 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:12:58 --> Utf8 Class Initialized
INFO - 2018-10-18 10:12:58 --> URI Class Initialized
INFO - 2018-10-18 10:12:58 --> Router Class Initialized
INFO - 2018-10-18 10:12:58 --> Output Class Initialized
INFO - 2018-10-18 10:12:58 --> Security Class Initialized
DEBUG - 2018-10-18 10:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:12:58 --> CSRF cookie sent
INFO - 2018-10-18 10:12:58 --> CSRF token verified
INFO - 2018-10-18 10:12:58 --> Input Class Initialized
INFO - 2018-10-18 10:12:58 --> Language Class Initialized
INFO - 2018-10-18 10:12:58 --> Loader Class Initialized
INFO - 2018-10-18 10:12:58 --> Helper loaded: url_helper
INFO - 2018-10-18 10:12:58 --> Helper loaded: form_helper
INFO - 2018-10-18 10:12:58 --> Helper loaded: language_helper
DEBUG - 2018-10-18 10:12:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 10:12:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 10:12:58 --> User Agent Class Initialized
INFO - 2018-10-18 10:12:58 --> Controller Class Initialized
INFO - 2018-10-18 10:12:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 10:12:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 10:12:58 --> Pixel_Model class loaded
INFO - 2018-10-18 10:12:58 --> Database Driver Class Initialized
INFO - 2018-10-18 10:12:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:12:58 --> Form Validation Class Initialized
INFO - 2018-10-18 10:12:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 10:12:58 --> Database Driver Class Initialized
INFO - 2018-10-18 10:12:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:12:58 --> Config Class Initialized
INFO - 2018-10-18 10:12:58 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:12:58 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:12:58 --> Utf8 Class Initialized
INFO - 2018-10-18 10:12:58 --> URI Class Initialized
INFO - 2018-10-18 10:12:58 --> Router Class Initialized
INFO - 2018-10-18 10:12:58 --> Output Class Initialized
INFO - 2018-10-18 10:12:58 --> Security Class Initialized
DEBUG - 2018-10-18 10:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:12:58 --> CSRF cookie sent
INFO - 2018-10-18 10:12:58 --> Input Class Initialized
INFO - 2018-10-18 10:12:58 --> Language Class Initialized
INFO - 2018-10-18 10:12:58 --> Loader Class Initialized
INFO - 2018-10-18 10:12:58 --> Helper loaded: url_helper
INFO - 2018-10-18 10:12:58 --> Helper loaded: form_helper
INFO - 2018-10-18 10:12:58 --> Helper loaded: language_helper
DEBUG - 2018-10-18 10:12:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 10:12:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 10:12:58 --> User Agent Class Initialized
INFO - 2018-10-18 10:12:58 --> Controller Class Initialized
INFO - 2018-10-18 10:12:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 10:12:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 10:12:58 --> Pixel_Model class loaded
INFO - 2018-10-18 10:12:58 --> Database Driver Class Initialized
INFO - 2018-10-18 10:12:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:12:58 --> Database Driver Class Initialized
INFO - 2018-10-18 10:12:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:12:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 10:12:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 10:12:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 10:12:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 10:12:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 10:12:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 10:12:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-10-18 10:12:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 10:12:58 --> Final output sent to browser
DEBUG - 2018-10-18 10:12:58 --> Total execution time: 0.0729
INFO - 2018-10-18 10:14:06 --> Config Class Initialized
INFO - 2018-10-18 10:14:06 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:14:06 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:14:06 --> Utf8 Class Initialized
INFO - 2018-10-18 10:14:06 --> URI Class Initialized
INFO - 2018-10-18 10:14:06 --> Router Class Initialized
INFO - 2018-10-18 10:14:06 --> Output Class Initialized
INFO - 2018-10-18 10:14:06 --> Security Class Initialized
DEBUG - 2018-10-18 10:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:14:06 --> CSRF cookie sent
INFO - 2018-10-18 10:14:06 --> Input Class Initialized
INFO - 2018-10-18 10:14:06 --> Language Class Initialized
INFO - 2018-10-18 10:14:06 --> Loader Class Initialized
INFO - 2018-10-18 10:14:06 --> Helper loaded: url_helper
INFO - 2018-10-18 10:14:06 --> Helper loaded: form_helper
INFO - 2018-10-18 10:14:06 --> Helper loaded: language_helper
DEBUG - 2018-10-18 10:14:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 10:14:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 10:14:06 --> User Agent Class Initialized
INFO - 2018-10-18 10:14:06 --> Controller Class Initialized
INFO - 2018-10-18 10:14:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 10:14:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 10:14:06 --> Pixel_Model class loaded
INFO - 2018-10-18 10:14:06 --> Database Driver Class Initialized
INFO - 2018-10-18 10:14:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:14:06 --> Database Driver Class Initialized
INFO - 2018-10-18 10:14:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:14:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 10:14:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 10:14:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 10:14:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 10:14:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 10:14:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 10:14:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-10-18 10:14:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 10:14:06 --> Final output sent to browser
DEBUG - 2018-10-18 10:14:06 --> Total execution time: 0.0452
INFO - 2018-10-18 10:14:16 --> Config Class Initialized
INFO - 2018-10-18 10:14:16 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:14:16 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:14:16 --> Utf8 Class Initialized
INFO - 2018-10-18 10:14:16 --> URI Class Initialized
INFO - 2018-10-18 10:14:16 --> Router Class Initialized
INFO - 2018-10-18 10:14:16 --> Output Class Initialized
INFO - 2018-10-18 10:14:16 --> Security Class Initialized
DEBUG - 2018-10-18 10:14:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:14:16 --> CSRF cookie sent
INFO - 2018-10-18 10:14:16 --> CSRF token verified
INFO - 2018-10-18 10:14:16 --> Input Class Initialized
INFO - 2018-10-18 10:14:16 --> Language Class Initialized
INFO - 2018-10-18 10:14:16 --> Loader Class Initialized
INFO - 2018-10-18 10:14:16 --> Helper loaded: url_helper
INFO - 2018-10-18 10:14:16 --> Helper loaded: form_helper
INFO - 2018-10-18 10:14:16 --> Helper loaded: language_helper
DEBUG - 2018-10-18 10:14:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 10:14:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 10:14:16 --> User Agent Class Initialized
INFO - 2018-10-18 10:14:16 --> Controller Class Initialized
INFO - 2018-10-18 10:14:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 10:14:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 10:14:16 --> Pixel_Model class loaded
INFO - 2018-10-18 10:14:16 --> Database Driver Class Initialized
INFO - 2018-10-18 10:14:16 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:14:16 --> Form Validation Class Initialized
INFO - 2018-10-18 10:14:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 10:14:16 --> Database Driver Class Initialized
INFO - 2018-10-18 10:14:16 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:14:16 --> Config Class Initialized
INFO - 2018-10-18 10:14:16 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:14:16 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:14:16 --> Utf8 Class Initialized
INFO - 2018-10-18 10:14:16 --> URI Class Initialized
INFO - 2018-10-18 10:14:16 --> Router Class Initialized
INFO - 2018-10-18 10:14:16 --> Output Class Initialized
INFO - 2018-10-18 10:14:16 --> Security Class Initialized
DEBUG - 2018-10-18 10:14:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:14:16 --> CSRF cookie sent
INFO - 2018-10-18 10:14:16 --> Input Class Initialized
INFO - 2018-10-18 10:14:16 --> Language Class Initialized
INFO - 2018-10-18 10:14:17 --> Loader Class Initialized
INFO - 2018-10-18 10:14:17 --> Helper loaded: url_helper
INFO - 2018-10-18 10:14:17 --> Helper loaded: form_helper
INFO - 2018-10-18 10:14:17 --> Helper loaded: language_helper
DEBUG - 2018-10-18 10:14:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 10:14:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 10:14:17 --> User Agent Class Initialized
INFO - 2018-10-18 10:14:17 --> Controller Class Initialized
INFO - 2018-10-18 10:14:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 10:14:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 10:14:17 --> Pixel_Model class loaded
INFO - 2018-10-18 10:14:17 --> Database Driver Class Initialized
INFO - 2018-10-18 10:14:17 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:14:17 --> Database Driver Class Initialized
INFO - 2018-10-18 10:14:17 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:14:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 10:14:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 10:14:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 10:14:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 10:14:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 10:14:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 10:14:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-10-18 10:14:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 10:14:17 --> Final output sent to browser
DEBUG - 2018-10-18 10:14:17 --> Total execution time: 0.0445
INFO - 2018-10-18 10:15:03 --> Config Class Initialized
INFO - 2018-10-18 10:15:03 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:15:03 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:15:03 --> Utf8 Class Initialized
INFO - 2018-10-18 10:15:03 --> URI Class Initialized
INFO - 2018-10-18 10:15:03 --> Router Class Initialized
INFO - 2018-10-18 10:15:03 --> Output Class Initialized
INFO - 2018-10-18 10:15:03 --> Security Class Initialized
DEBUG - 2018-10-18 10:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:15:03 --> CSRF cookie sent
INFO - 2018-10-18 10:15:03 --> Input Class Initialized
INFO - 2018-10-18 10:15:03 --> Language Class Initialized
INFO - 2018-10-18 10:15:03 --> Loader Class Initialized
INFO - 2018-10-18 10:15:03 --> Helper loaded: url_helper
INFO - 2018-10-18 10:15:03 --> Helper loaded: form_helper
INFO - 2018-10-18 10:15:03 --> Helper loaded: language_helper
DEBUG - 2018-10-18 10:15:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 10:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 10:15:03 --> User Agent Class Initialized
INFO - 2018-10-18 10:15:03 --> Controller Class Initialized
INFO - 2018-10-18 10:15:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 10:15:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 10:15:03 --> Pixel_Model class loaded
INFO - 2018-10-18 10:15:03 --> Database Driver Class Initialized
INFO - 2018-10-18 10:15:03 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:15:03 --> Database Driver Class Initialized
INFO - 2018-10-18 10:15:03 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:15:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 10:15:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 10:15:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 10:15:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 10:15:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 10:15:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 10:15:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-10-18 10:15:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 10:15:03 --> Final output sent to browser
DEBUG - 2018-10-18 10:15:03 --> Total execution time: 0.0476
INFO - 2018-10-18 10:15:11 --> Config Class Initialized
INFO - 2018-10-18 10:15:11 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:15:11 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:15:11 --> Utf8 Class Initialized
INFO - 2018-10-18 10:15:11 --> URI Class Initialized
INFO - 2018-10-18 10:15:11 --> Router Class Initialized
INFO - 2018-10-18 10:15:11 --> Output Class Initialized
INFO - 2018-10-18 10:15:11 --> Security Class Initialized
DEBUG - 2018-10-18 10:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:15:11 --> CSRF cookie sent
INFO - 2018-10-18 10:15:11 --> CSRF token verified
INFO - 2018-10-18 10:15:11 --> Input Class Initialized
INFO - 2018-10-18 10:15:11 --> Language Class Initialized
INFO - 2018-10-18 10:15:11 --> Loader Class Initialized
INFO - 2018-10-18 10:15:11 --> Helper loaded: url_helper
INFO - 2018-10-18 10:15:11 --> Helper loaded: form_helper
INFO - 2018-10-18 10:15:11 --> Helper loaded: language_helper
DEBUG - 2018-10-18 10:15:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 10:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 10:15:11 --> User Agent Class Initialized
INFO - 2018-10-18 10:15:11 --> Controller Class Initialized
INFO - 2018-10-18 10:15:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 10:15:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 10:15:11 --> Pixel_Model class loaded
INFO - 2018-10-18 10:15:11 --> Database Driver Class Initialized
INFO - 2018-10-18 10:15:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:15:11 --> Form Validation Class Initialized
INFO - 2018-10-18 10:15:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 10:15:11 --> Database Driver Class Initialized
INFO - 2018-10-18 10:15:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:15:12 --> Config Class Initialized
INFO - 2018-10-18 10:15:12 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:15:12 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:15:12 --> Utf8 Class Initialized
INFO - 2018-10-18 10:15:12 --> URI Class Initialized
INFO - 2018-10-18 10:15:12 --> Router Class Initialized
INFO - 2018-10-18 10:15:12 --> Output Class Initialized
INFO - 2018-10-18 10:15:12 --> Security Class Initialized
DEBUG - 2018-10-18 10:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:15:12 --> CSRF cookie sent
INFO - 2018-10-18 10:15:12 --> Input Class Initialized
INFO - 2018-10-18 10:15:12 --> Language Class Initialized
INFO - 2018-10-18 10:15:12 --> Loader Class Initialized
INFO - 2018-10-18 10:15:12 --> Helper loaded: url_helper
INFO - 2018-10-18 10:15:12 --> Helper loaded: form_helper
INFO - 2018-10-18 10:15:12 --> Helper loaded: language_helper
DEBUG - 2018-10-18 10:15:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 10:15:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 10:15:12 --> User Agent Class Initialized
INFO - 2018-10-18 10:15:12 --> Controller Class Initialized
INFO - 2018-10-18 10:15:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 10:15:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 10:15:12 --> Pixel_Model class loaded
INFO - 2018-10-18 10:15:12 --> Database Driver Class Initialized
INFO - 2018-10-18 10:15:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:15:12 --> Database Driver Class Initialized
INFO - 2018-10-18 10:15:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:15:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 10:15:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 10:15:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 10:15:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 10:15:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 10:15:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 10:15:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-10-18 10:15:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 10:15:12 --> Final output sent to browser
DEBUG - 2018-10-18 10:15:12 --> Total execution time: 0.0606
INFO - 2018-10-18 10:15:16 --> Config Class Initialized
INFO - 2018-10-18 10:15:16 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:15:16 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:15:16 --> Utf8 Class Initialized
INFO - 2018-10-18 10:15:16 --> URI Class Initialized
INFO - 2018-10-18 10:15:16 --> Router Class Initialized
INFO - 2018-10-18 10:15:16 --> Output Class Initialized
INFO - 2018-10-18 10:15:16 --> Security Class Initialized
DEBUG - 2018-10-18 10:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:15:16 --> CSRF cookie sent
INFO - 2018-10-18 10:15:16 --> CSRF token verified
INFO - 2018-10-18 10:15:16 --> Input Class Initialized
INFO - 2018-10-18 10:15:16 --> Language Class Initialized
INFO - 2018-10-18 10:15:16 --> Loader Class Initialized
INFO - 2018-10-18 10:15:16 --> Helper loaded: url_helper
INFO - 2018-10-18 10:15:16 --> Helper loaded: form_helper
INFO - 2018-10-18 10:15:16 --> Helper loaded: language_helper
DEBUG - 2018-10-18 10:15:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 10:15:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 10:15:16 --> User Agent Class Initialized
INFO - 2018-10-18 10:15:16 --> Controller Class Initialized
INFO - 2018-10-18 10:15:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 10:15:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 10:15:16 --> Pixel_Model class loaded
INFO - 2018-10-18 10:15:16 --> Database Driver Class Initialized
INFO - 2018-10-18 10:15:16 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:15:16 --> Form Validation Class Initialized
INFO - 2018-10-18 10:15:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 10:15:16 --> Database Driver Class Initialized
INFO - 2018-10-18 10:15:16 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:15:16 --> Config Class Initialized
INFO - 2018-10-18 10:15:16 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:15:16 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:15:16 --> Utf8 Class Initialized
INFO - 2018-10-18 10:15:16 --> URI Class Initialized
INFO - 2018-10-18 10:15:16 --> Router Class Initialized
INFO - 2018-10-18 10:15:16 --> Output Class Initialized
INFO - 2018-10-18 10:15:16 --> Security Class Initialized
DEBUG - 2018-10-18 10:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:15:16 --> CSRF cookie sent
INFO - 2018-10-18 10:15:16 --> Input Class Initialized
INFO - 2018-10-18 10:15:16 --> Language Class Initialized
INFO - 2018-10-18 10:15:16 --> Loader Class Initialized
INFO - 2018-10-18 10:15:16 --> Helper loaded: url_helper
INFO - 2018-10-18 10:15:16 --> Helper loaded: form_helper
INFO - 2018-10-18 10:15:16 --> Helper loaded: language_helper
DEBUG - 2018-10-18 10:15:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 10:15:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 10:15:16 --> User Agent Class Initialized
INFO - 2018-10-18 10:15:16 --> Controller Class Initialized
INFO - 2018-10-18 10:15:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 10:15:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 10:15:16 --> Pixel_Model class loaded
INFO - 2018-10-18 10:15:16 --> Database Driver Class Initialized
INFO - 2018-10-18 10:15:16 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:15:16 --> Database Driver Class Initialized
INFO - 2018-10-18 10:15:16 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:15:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 10:15:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 10:15:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 10:15:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 10:15:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 10:15:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 10:15:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_owner.php
INFO - 2018-10-18 10:15:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 10:15:16 --> Final output sent to browser
DEBUG - 2018-10-18 10:15:16 --> Total execution time: 0.0435
INFO - 2018-10-18 10:15:18 --> Config Class Initialized
INFO - 2018-10-18 10:15:18 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:15:18 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:15:18 --> Utf8 Class Initialized
INFO - 2018-10-18 10:15:18 --> URI Class Initialized
INFO - 2018-10-18 10:15:18 --> Router Class Initialized
INFO - 2018-10-18 10:15:18 --> Output Class Initialized
INFO - 2018-10-18 10:15:18 --> Security Class Initialized
DEBUG - 2018-10-18 10:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:15:18 --> CSRF cookie sent
INFO - 2018-10-18 10:15:18 --> CSRF token verified
INFO - 2018-10-18 10:15:18 --> Input Class Initialized
INFO - 2018-10-18 10:15:18 --> Language Class Initialized
INFO - 2018-10-18 10:15:18 --> Loader Class Initialized
INFO - 2018-10-18 10:15:18 --> Helper loaded: url_helper
INFO - 2018-10-18 10:15:18 --> Helper loaded: form_helper
INFO - 2018-10-18 10:15:18 --> Helper loaded: language_helper
DEBUG - 2018-10-18 10:15:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 10:15:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 10:15:18 --> User Agent Class Initialized
INFO - 2018-10-18 10:15:18 --> Controller Class Initialized
INFO - 2018-10-18 10:15:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 10:15:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 10:15:18 --> Pixel_Model class loaded
INFO - 2018-10-18 10:15:18 --> Database Driver Class Initialized
INFO - 2018-10-18 10:15:18 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:15:18 --> Form Validation Class Initialized
INFO - 2018-10-18 10:15:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 10:15:18 --> Database Driver Class Initialized
INFO - 2018-10-18 10:15:18 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:15:19 --> Config Class Initialized
INFO - 2018-10-18 10:15:19 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:15:19 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:15:19 --> Utf8 Class Initialized
INFO - 2018-10-18 10:15:19 --> URI Class Initialized
INFO - 2018-10-18 10:15:19 --> Router Class Initialized
INFO - 2018-10-18 10:15:19 --> Output Class Initialized
INFO - 2018-10-18 10:15:19 --> Security Class Initialized
DEBUG - 2018-10-18 10:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:15:19 --> CSRF cookie sent
INFO - 2018-10-18 10:15:19 --> Input Class Initialized
INFO - 2018-10-18 10:15:19 --> Language Class Initialized
INFO - 2018-10-18 10:15:19 --> Loader Class Initialized
INFO - 2018-10-18 10:15:19 --> Helper loaded: url_helper
INFO - 2018-10-18 10:15:19 --> Helper loaded: form_helper
INFO - 2018-10-18 10:15:19 --> Helper loaded: language_helper
DEBUG - 2018-10-18 10:15:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 10:15:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 10:15:19 --> User Agent Class Initialized
INFO - 2018-10-18 10:15:19 --> Controller Class Initialized
INFO - 2018-10-18 10:15:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 10:15:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 10:15:19 --> Pixel_Model class loaded
INFO - 2018-10-18 10:15:19 --> Database Driver Class Initialized
INFO - 2018-10-18 10:15:19 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:15:19 --> Database Driver Class Initialized
INFO - 2018-10-18 10:15:19 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:15:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 10:15:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 10:15:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 10:15:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 10:15:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 10:15:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 10:15:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_value.php
INFO - 2018-10-18 10:15:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 10:15:19 --> Final output sent to browser
DEBUG - 2018-10-18 10:15:19 --> Total execution time: 0.0383
INFO - 2018-10-18 10:15:26 --> Config Class Initialized
INFO - 2018-10-18 10:15:26 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:15:26 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:15:26 --> Utf8 Class Initialized
INFO - 2018-10-18 10:15:26 --> URI Class Initialized
INFO - 2018-10-18 10:15:26 --> Router Class Initialized
INFO - 2018-10-18 10:15:26 --> Output Class Initialized
INFO - 2018-10-18 10:15:26 --> Security Class Initialized
DEBUG - 2018-10-18 10:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:15:26 --> CSRF cookie sent
INFO - 2018-10-18 10:15:26 --> CSRF token verified
INFO - 2018-10-18 10:15:26 --> Input Class Initialized
INFO - 2018-10-18 10:15:26 --> Language Class Initialized
INFO - 2018-10-18 10:15:26 --> Loader Class Initialized
INFO - 2018-10-18 10:15:26 --> Helper loaded: url_helper
INFO - 2018-10-18 10:15:26 --> Helper loaded: form_helper
INFO - 2018-10-18 10:15:26 --> Helper loaded: language_helper
DEBUG - 2018-10-18 10:15:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 10:15:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 10:15:26 --> User Agent Class Initialized
INFO - 2018-10-18 10:15:26 --> Controller Class Initialized
INFO - 2018-10-18 10:15:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 10:15:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 10:15:26 --> Pixel_Model class loaded
INFO - 2018-10-18 10:15:26 --> Database Driver Class Initialized
INFO - 2018-10-18 10:15:26 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:15:26 --> Form Validation Class Initialized
INFO - 2018-10-18 10:15:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 10:15:26 --> Database Driver Class Initialized
INFO - 2018-10-18 10:15:26 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:15:26 --> Config Class Initialized
INFO - 2018-10-18 10:15:26 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:15:26 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:15:26 --> Utf8 Class Initialized
INFO - 2018-10-18 10:15:26 --> URI Class Initialized
INFO - 2018-10-18 10:15:26 --> Router Class Initialized
INFO - 2018-10-18 10:15:26 --> Output Class Initialized
INFO - 2018-10-18 10:15:26 --> Security Class Initialized
DEBUG - 2018-10-18 10:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:15:26 --> CSRF cookie sent
INFO - 2018-10-18 10:15:26 --> Input Class Initialized
INFO - 2018-10-18 10:15:26 --> Language Class Initialized
INFO - 2018-10-18 10:15:26 --> Loader Class Initialized
INFO - 2018-10-18 10:15:26 --> Helper loaded: url_helper
INFO - 2018-10-18 10:15:26 --> Helper loaded: form_helper
INFO - 2018-10-18 10:15:26 --> Helper loaded: language_helper
DEBUG - 2018-10-18 10:15:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 10:15:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 10:15:26 --> User Agent Class Initialized
INFO - 2018-10-18 10:15:26 --> Controller Class Initialized
INFO - 2018-10-18 10:15:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 10:15:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 10:15:26 --> Pixel_Model class loaded
INFO - 2018-10-18 10:15:26 --> Database Driver Class Initialized
INFO - 2018-10-18 10:15:26 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:15:26 --> Database Driver Class Initialized
INFO - 2018-10-18 10:15:26 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:15:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 10:15:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 10:15:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 10:15:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 10:15:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 10:15:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 10:15:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/merriage_home_title.php
INFO - 2018-10-18 10:15:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 10:15:26 --> Final output sent to browser
DEBUG - 2018-10-18 10:15:26 --> Total execution time: 0.0485
INFO - 2018-10-18 10:15:29 --> Config Class Initialized
INFO - 2018-10-18 10:15:29 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:15:29 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:15:29 --> Utf8 Class Initialized
INFO - 2018-10-18 10:15:29 --> URI Class Initialized
INFO - 2018-10-18 10:15:29 --> Router Class Initialized
INFO - 2018-10-18 10:15:29 --> Output Class Initialized
INFO - 2018-10-18 10:15:29 --> Security Class Initialized
DEBUG - 2018-10-18 10:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:15:29 --> CSRF cookie sent
INFO - 2018-10-18 10:15:29 --> CSRF token verified
INFO - 2018-10-18 10:15:29 --> Input Class Initialized
INFO - 2018-10-18 10:15:29 --> Language Class Initialized
INFO - 2018-10-18 10:15:29 --> Loader Class Initialized
INFO - 2018-10-18 10:15:29 --> Helper loaded: url_helper
INFO - 2018-10-18 10:15:29 --> Helper loaded: form_helper
INFO - 2018-10-18 10:15:29 --> Helper loaded: language_helper
DEBUG - 2018-10-18 10:15:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 10:15:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 10:15:29 --> User Agent Class Initialized
INFO - 2018-10-18 10:15:29 --> Controller Class Initialized
INFO - 2018-10-18 10:15:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 10:15:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 10:15:29 --> Pixel_Model class loaded
INFO - 2018-10-18 10:15:29 --> Database Driver Class Initialized
INFO - 2018-10-18 10:15:29 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:15:29 --> Form Validation Class Initialized
INFO - 2018-10-18 10:15:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 10:15:29 --> Database Driver Class Initialized
INFO - 2018-10-18 10:15:29 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:15:29 --> Config Class Initialized
INFO - 2018-10-18 10:15:29 --> Hooks Class Initialized
DEBUG - 2018-10-18 10:15:29 --> UTF-8 Support Enabled
INFO - 2018-10-18 10:15:29 --> Utf8 Class Initialized
INFO - 2018-10-18 10:15:29 --> URI Class Initialized
INFO - 2018-10-18 10:15:29 --> Router Class Initialized
INFO - 2018-10-18 10:15:29 --> Output Class Initialized
INFO - 2018-10-18 10:15:29 --> Security Class Initialized
DEBUG - 2018-10-18 10:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 10:15:29 --> CSRF cookie sent
INFO - 2018-10-18 10:15:29 --> Input Class Initialized
INFO - 2018-10-18 10:15:29 --> Language Class Initialized
INFO - 2018-10-18 10:15:29 --> Loader Class Initialized
INFO - 2018-10-18 10:15:29 --> Helper loaded: url_helper
INFO - 2018-10-18 10:15:29 --> Helper loaded: form_helper
INFO - 2018-10-18 10:15:29 --> Helper loaded: language_helper
DEBUG - 2018-10-18 10:15:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 10:15:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 10:15:29 --> User Agent Class Initialized
INFO - 2018-10-18 10:15:29 --> Controller Class Initialized
INFO - 2018-10-18 10:15:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 10:15:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 10:15:29 --> Pixel_Model class loaded
INFO - 2018-10-18 10:15:29 --> Database Driver Class Initialized
INFO - 2018-10-18 10:15:29 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:15:29 --> Database Driver Class Initialized
INFO - 2018-10-18 10:15:29 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 10:15:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-18 10:15:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-18 10:15:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-18 10:15:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-18 10:15:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-18 10:15:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-18 10:15:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-10-18 10:15:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-18 10:15:29 --> Final output sent to browser
DEBUG - 2018-10-18 10:15:29 --> Total execution time: 0.0421
INFO - 2018-10-18 12:24:40 --> Config Class Initialized
INFO - 2018-10-18 12:24:40 --> Hooks Class Initialized
DEBUG - 2018-10-18 12:24:40 --> UTF-8 Support Enabled
INFO - 2018-10-18 12:24:40 --> Utf8 Class Initialized
INFO - 2018-10-18 12:24:40 --> URI Class Initialized
INFO - 2018-10-18 12:24:40 --> Router Class Initialized
INFO - 2018-10-18 12:24:40 --> Output Class Initialized
INFO - 2018-10-18 12:24:40 --> Security Class Initialized
DEBUG - 2018-10-18 12:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 12:24:40 --> CSRF cookie sent
INFO - 2018-10-18 12:24:40 --> Input Class Initialized
INFO - 2018-10-18 12:24:40 --> Language Class Initialized
INFO - 2018-10-18 12:24:40 --> Loader Class Initialized
INFO - 2018-10-18 12:24:40 --> Helper loaded: url_helper
INFO - 2018-10-18 12:24:40 --> Helper loaded: form_helper
INFO - 2018-10-18 12:24:41 --> Helper loaded: language_helper
DEBUG - 2018-10-18 12:24:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 12:24:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 12:24:41 --> User Agent Class Initialized
INFO - 2018-10-18 12:24:41 --> Controller Class Initialized
INFO - 2018-10-18 12:24:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 12:24:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 12:24:41 --> Pixel_Model class loaded
INFO - 2018-10-18 12:24:41 --> Database Driver Class Initialized
INFO - 2018-10-18 12:24:41 --> Model "QuestionsModel" initialized
ERROR - 2018-10-18 12:24:41 --> Query error: Unknown column 'display_order' in 'order clause' - Invalid query: SELECT *
FROM `select_types`
WHERE `type` = 'relationship_status'
AND `status` = 1
ORDER BY `display_order`
ERROR - 2018-10-18 12:24:41 --> Severity: error --> Exception: Call to a member function num_rows() on boolean F:\xampp\htdocs\famiquity\application\core\Pixel_Model.php 300
INFO - 2018-10-18 12:24:49 --> Config Class Initialized
INFO - 2018-10-18 12:24:49 --> Hooks Class Initialized
DEBUG - 2018-10-18 12:24:49 --> UTF-8 Support Enabled
INFO - 2018-10-18 12:24:49 --> Utf8 Class Initialized
INFO - 2018-10-18 12:24:49 --> URI Class Initialized
DEBUG - 2018-10-18 12:24:49 --> No URI present. Default controller set.
INFO - 2018-10-18 12:24:49 --> Router Class Initialized
INFO - 2018-10-18 12:24:49 --> Output Class Initialized
INFO - 2018-10-18 12:24:49 --> Security Class Initialized
DEBUG - 2018-10-18 12:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 12:24:49 --> CSRF cookie sent
INFO - 2018-10-18 12:24:49 --> Input Class Initialized
INFO - 2018-10-18 12:24:49 --> Language Class Initialized
INFO - 2018-10-18 12:24:49 --> Loader Class Initialized
INFO - 2018-10-18 12:24:49 --> Helper loaded: url_helper
INFO - 2018-10-18 12:24:49 --> Helper loaded: form_helper
INFO - 2018-10-18 12:24:49 --> Helper loaded: language_helper
DEBUG - 2018-10-18 12:24:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 12:24:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 12:24:49 --> User Agent Class Initialized
INFO - 2018-10-18 12:24:49 --> Controller Class Initialized
INFO - 2018-10-18 12:24:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 12:24:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 12:24:50 --> Pixel_Model class loaded
INFO - 2018-10-18 12:24:50 --> Database Driver Class Initialized
INFO - 2018-10-18 12:24:50 --> Model "QuestionsModel" initialized
ERROR - 2018-10-18 12:24:50 --> Query error: Unknown column 'display_order' in 'order clause' - Invalid query: SELECT *
FROM `select_types`
WHERE `type` = 'decisions'
AND `status` = 1
ORDER BY `display_order`
ERROR - 2018-10-18 12:24:50 --> Severity: error --> Exception: Call to a member function num_rows() on boolean F:\xampp\htdocs\famiquity\application\core\Pixel_Model.php 300
INFO - 2018-10-18 12:25:08 --> Config Class Initialized
INFO - 2018-10-18 12:25:08 --> Hooks Class Initialized
DEBUG - 2018-10-18 12:25:08 --> UTF-8 Support Enabled
INFO - 2018-10-18 12:25:08 --> Utf8 Class Initialized
INFO - 2018-10-18 12:25:08 --> URI Class Initialized
DEBUG - 2018-10-18 12:25:08 --> No URI present. Default controller set.
INFO - 2018-10-18 12:25:08 --> Router Class Initialized
INFO - 2018-10-18 12:25:08 --> Output Class Initialized
INFO - 2018-10-18 12:25:08 --> Security Class Initialized
DEBUG - 2018-10-18 12:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 12:25:08 --> CSRF cookie sent
INFO - 2018-10-18 12:25:08 --> Input Class Initialized
INFO - 2018-10-18 12:25:08 --> Language Class Initialized
INFO - 2018-10-18 12:25:08 --> Loader Class Initialized
INFO - 2018-10-18 12:25:09 --> Helper loaded: url_helper
INFO - 2018-10-18 12:25:09 --> Helper loaded: form_helper
INFO - 2018-10-18 12:25:09 --> Helper loaded: language_helper
DEBUG - 2018-10-18 12:25:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 12:25:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 12:25:09 --> User Agent Class Initialized
INFO - 2018-10-18 12:25:09 --> Controller Class Initialized
INFO - 2018-10-18 12:25:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 12:25:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 12:25:09 --> Pixel_Model class loaded
INFO - 2018-10-18 12:25:09 --> Database Driver Class Initialized
INFO - 2018-10-18 12:25:09 --> Model "QuestionsModel" initialized
ERROR - 2018-10-18 12:25:09 --> Query error: Unknown column 'display_order' in 'order clause' - Invalid query: SELECT *
FROM `select_types`
WHERE `type` = 'decisions'
AND `status` = 1
ORDER BY `display_order`
INFO - 2018-10-18 12:25:09 --> Language file loaded: language/english/db_lang.php
INFO - 2018-10-18 12:28:06 --> Config Class Initialized
INFO - 2018-10-18 12:28:06 --> Hooks Class Initialized
DEBUG - 2018-10-18 12:28:06 --> UTF-8 Support Enabled
INFO - 2018-10-18 12:28:06 --> Utf8 Class Initialized
INFO - 2018-10-18 12:28:06 --> URI Class Initialized
DEBUG - 2018-10-18 12:28:06 --> No URI present. Default controller set.
INFO - 2018-10-18 12:28:06 --> Router Class Initialized
INFO - 2018-10-18 12:28:06 --> Output Class Initialized
INFO - 2018-10-18 12:28:06 --> Security Class Initialized
DEBUG - 2018-10-18 12:28:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 12:28:06 --> CSRF cookie sent
INFO - 2018-10-18 12:28:06 --> Input Class Initialized
INFO - 2018-10-18 12:28:06 --> Language Class Initialized
INFO - 2018-10-18 12:28:06 --> Loader Class Initialized
INFO - 2018-10-18 12:28:06 --> Helper loaded: url_helper
INFO - 2018-10-18 12:28:06 --> Helper loaded: form_helper
INFO - 2018-10-18 12:28:06 --> Helper loaded: language_helper
DEBUG - 2018-10-18 12:28:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 12:28:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 12:28:06 --> User Agent Class Initialized
INFO - 2018-10-18 12:28:06 --> Controller Class Initialized
INFO - 2018-10-18 12:28:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 12:28:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 12:28:07 --> Pixel_Model class loaded
INFO - 2018-10-18 12:28:07 --> Database Driver Class Initialized
INFO - 2018-10-18 12:28:07 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 12:28:07 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 12:28:07 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 12:28:07 --> File loaded: F:\xampp\htdocs\famiquity\application\views\home.php
INFO - 2018-10-18 12:28:07 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 12:28:07 --> Final output sent to browser
DEBUG - 2018-10-18 12:28:07 --> Total execution time: 1.3674
INFO - 2018-10-18 12:28:15 --> Config Class Initialized
INFO - 2018-10-18 12:28:15 --> Hooks Class Initialized
DEBUG - 2018-10-18 12:28:15 --> UTF-8 Support Enabled
INFO - 2018-10-18 12:28:15 --> Utf8 Class Initialized
INFO - 2018-10-18 12:28:15 --> URI Class Initialized
INFO - 2018-10-18 12:28:15 --> Router Class Initialized
INFO - 2018-10-18 12:28:15 --> Output Class Initialized
INFO - 2018-10-18 12:28:15 --> Security Class Initialized
DEBUG - 2018-10-18 12:28:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 12:28:15 --> CSRF cookie sent
INFO - 2018-10-18 12:28:15 --> Input Class Initialized
INFO - 2018-10-18 12:28:15 --> Language Class Initialized
ERROR - 2018-10-18 12:28:15 --> 404 Page Not Found: Assets/css
<<<<<<< HEAD
<<<<<<< HEAD
INFO - 2018-10-18 12:32:35 --> Config Class Initialized
INFO - 2018-10-18 12:32:35 --> Hooks Class Initialized
DEBUG - 2018-10-18 12:32:35 --> UTF-8 Support Enabled
INFO - 2018-10-18 12:32:35 --> Utf8 Class Initialized
INFO - 2018-10-18 12:32:35 --> URI Class Initialized
DEBUG - 2018-10-18 12:32:35 --> No URI present. Default controller set.
INFO - 2018-10-18 12:32:35 --> Router Class Initialized
INFO - 2018-10-18 12:32:35 --> Output Class Initialized
INFO - 2018-10-18 12:32:36 --> Security Class Initialized
DEBUG - 2018-10-18 12:32:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 12:32:36 --> CSRF cookie sent
INFO - 2018-10-18 12:32:36 --> Input Class Initialized
INFO - 2018-10-18 12:32:36 --> Language Class Initialized
INFO - 2018-10-18 12:32:36 --> Loader Class Initialized
INFO - 2018-10-18 12:32:36 --> Helper loaded: url_helper
INFO - 2018-10-18 12:32:36 --> Helper loaded: form_helper
INFO - 2018-10-18 12:32:36 --> Helper loaded: language_helper
DEBUG - 2018-10-18 12:32:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 12:32:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 12:32:36 --> User Agent Class Initialized
INFO - 2018-10-18 12:32:36 --> Controller Class Initialized
INFO - 2018-10-18 12:32:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 12:32:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 12:32:36 --> Pixel_Model class loaded
INFO - 2018-10-18 12:32:36 --> Database Driver Class Initialized
INFO - 2018-10-18 12:32:36 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 12:32:36 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 12:32:36 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 12:32:36 --> File loaded: F:\xampp\htdocs\famiquity\application\views\home.php
INFO - 2018-10-18 12:32:36 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 12:32:36 --> Final output sent to browser
DEBUG - 2018-10-18 12:32:36 --> Total execution time: 0.6694
=======
=======
>>>>>>> 4c5a3fb837b72a5ebe34152c40ec6a8ad1b51698
INFO - 2018-10-18 12:42:16 --> Config Class Initialized
INFO - 2018-10-18 12:42:16 --> Hooks Class Initialized
DEBUG - 2018-10-18 12:42:17 --> UTF-8 Support Enabled
INFO - 2018-10-18 12:42:17 --> Utf8 Class Initialized
INFO - 2018-10-18 12:42:17 --> URI Class Initialized
DEBUG - 2018-10-18 12:42:17 --> No URI present. Default controller set.
INFO - 2018-10-18 12:42:17 --> Router Class Initialized
INFO - 2018-10-18 12:42:17 --> Output Class Initialized
INFO - 2018-10-18 12:42:17 --> Security Class Initialized
DEBUG - 2018-10-18 12:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 12:42:17 --> CSRF cookie sent
INFO - 2018-10-18 12:42:17 --> Input Class Initialized
INFO - 2018-10-18 12:42:17 --> Language Class Initialized
INFO - 2018-10-18 12:42:17 --> Loader Class Initialized
INFO - 2018-10-18 12:42:17 --> Helper loaded: url_helper
INFO - 2018-10-18 12:42:17 --> Helper loaded: form_helper
INFO - 2018-10-18 12:42:17 --> Helper loaded: language_helper
DEBUG - 2018-10-18 12:42:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 12:42:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 12:42:17 --> User Agent Class Initialized
INFO - 2018-10-18 12:42:17 --> Controller Class Initialized
INFO - 2018-10-18 12:42:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 12:42:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 12:42:17 --> Pixel_Model class loaded
INFO - 2018-10-18 12:42:17 --> Database Driver Class Initialized
INFO - 2018-10-18 12:42:17 --> Model "QuestionsModel" initialized
ERROR - 2018-10-18 12:42:17 --> Query error: Unknown column 'display_order' in 'order clause' - Invalid query: SELECT *
FROM `select_types`
WHERE `type` = 'decisions'
AND `status` = 1
ORDER BY `display_order`
ERROR - 2018-10-18 12:42:17 --> Severity: error --> Exception: Call to a member function num_rows() on boolean E:\xampp7\htdocs\famiquity\application\core\Pixel_Model.php 300
INFO - 2018-10-18 13:20:50 --> Config Class Initialized
INFO - 2018-10-18 13:20:50 --> Hooks Class Initialized
DEBUG - 2018-10-18 13:20:50 --> UTF-8 Support Enabled
INFO - 2018-10-18 13:20:50 --> Utf8 Class Initialized
INFO - 2018-10-18 13:20:50 --> URI Class Initialized
DEBUG - 2018-10-18 13:20:50 --> No URI present. Default controller set.
INFO - 2018-10-18 13:20:50 --> Router Class Initialized
INFO - 2018-10-18 13:20:50 --> Output Class Initialized
INFO - 2018-10-18 13:20:50 --> Security Class Initialized
DEBUG - 2018-10-18 13:20:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 13:20:50 --> CSRF cookie sent
INFO - 2018-10-18 13:20:50 --> Input Class Initialized
INFO - 2018-10-18 13:20:50 --> Language Class Initialized
INFO - 2018-10-18 13:20:50 --> Loader Class Initialized
INFO - 2018-10-18 13:20:50 --> Helper loaded: url_helper
INFO - 2018-10-18 13:20:50 --> Helper loaded: form_helper
INFO - 2018-10-18 13:20:50 --> Helper loaded: language_helper
DEBUG - 2018-10-18 13:20:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 13:20:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 13:20:50 --> User Agent Class Initialized
INFO - 2018-10-18 13:20:50 --> Controller Class Initialized
INFO - 2018-10-18 13:20:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 13:20:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 13:20:50 --> Pixel_Model class loaded
INFO - 2018-10-18 13:20:50 --> Database Driver Class Initialized
INFO - 2018-10-18 13:20:50 --> Model "QuestionsModel" initialized
ERROR - 2018-10-18 13:20:50 --> Query error: Unknown column 'display_order' in 'order clause' - Invalid query: SELECT *
FROM `select_types`
WHERE `type` = 'decisions'
AND `status` = 1
ORDER BY `display_order`
INFO - 2018-10-18 13:20:50 --> Language file loaded: language/english/db_lang.php
INFO - 2018-10-18 13:26:44 --> Config Class Initialized
INFO - 2018-10-18 13:26:44 --> Hooks Class Initialized
DEBUG - 2018-10-18 13:26:44 --> UTF-8 Support Enabled
INFO - 2018-10-18 13:26:44 --> Utf8 Class Initialized
INFO - 2018-10-18 13:26:44 --> URI Class Initialized
DEBUG - 2018-10-18 13:26:44 --> No URI present. Default controller set.
INFO - 2018-10-18 13:26:44 --> Router Class Initialized
INFO - 2018-10-18 13:26:44 --> Output Class Initialized
INFO - 2018-10-18 13:26:44 --> Security Class Initialized
DEBUG - 2018-10-18 13:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 13:26:44 --> CSRF cookie sent
INFO - 2018-10-18 13:26:44 --> Input Class Initialized
INFO - 2018-10-18 13:26:44 --> Language Class Initialized
INFO - 2018-10-18 13:26:44 --> Loader Class Initialized
INFO - 2018-10-18 13:26:44 --> Helper loaded: url_helper
INFO - 2018-10-18 13:26:44 --> Helper loaded: form_helper
INFO - 2018-10-18 13:26:44 --> Helper loaded: language_helper
DEBUG - 2018-10-18 13:26:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 13:26:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 13:26:44 --> User Agent Class Initialized
INFO - 2018-10-18 13:26:44 --> Controller Class Initialized
INFO - 2018-10-18 13:26:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 13:26:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 13:26:44 --> Pixel_Model class loaded
INFO - 2018-10-18 13:26:44 --> Database Driver Class Initialized
INFO - 2018-10-18 13:26:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 13:26:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 13:26:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 13:26:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-18 13:26:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 13:26:45 --> Final output sent to browser
DEBUG - 2018-10-18 13:26:45 --> Total execution time: 0.9178
INFO - 2018-10-18 13:26:50 --> Config Class Initialized
INFO - 2018-10-18 13:26:50 --> Hooks Class Initialized
DEBUG - 2018-10-18 13:26:50 --> UTF-8 Support Enabled
INFO - 2018-10-18 13:26:50 --> Utf8 Class Initialized
INFO - 2018-10-18 13:26:50 --> URI Class Initialized
INFO - 2018-10-18 13:26:50 --> Router Class Initialized
INFO - 2018-10-18 13:26:50 --> Output Class Initialized
INFO - 2018-10-18 13:26:50 --> Security Class Initialized
DEBUG - 2018-10-18 13:26:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 13:26:50 --> CSRF cookie sent
INFO - 2018-10-18 13:26:50 --> Input Class Initialized
INFO - 2018-10-18 13:26:50 --> Language Class Initialized
INFO - 2018-10-18 13:26:50 --> Loader Class Initialized
INFO - 2018-10-18 13:26:50 --> Helper loaded: url_helper
INFO - 2018-10-18 13:26:50 --> Helper loaded: form_helper
INFO - 2018-10-18 13:26:50 --> Helper loaded: language_helper
DEBUG - 2018-10-18 13:26:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 13:26:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 13:26:50 --> User Agent Class Initialized
INFO - 2018-10-18 13:26:50 --> Controller Class Initialized
INFO - 2018-10-18 13:26:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 13:26:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 13:26:50 --> Pixel_Model class loaded
INFO - 2018-10-18 13:26:50 --> Database Driver Class Initialized
INFO - 2018-10-18 13:26:50 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 13:26:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 13:26:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 13:26:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 13:26:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 13:26:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 13:26:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 13:26:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-18 13:26:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 13:26:50 --> Final output sent to browser
DEBUG - 2018-10-18 13:26:50 --> Total execution time: 0.5152
INFO - 2018-10-18 13:26:53 --> Config Class Initialized
INFO - 2018-10-18 13:26:53 --> Hooks Class Initialized
DEBUG - 2018-10-18 13:26:53 --> UTF-8 Support Enabled
INFO - 2018-10-18 13:26:53 --> Utf8 Class Initialized
INFO - 2018-10-18 13:26:53 --> URI Class Initialized
INFO - 2018-10-18 13:26:53 --> Router Class Initialized
INFO - 2018-10-18 13:26:53 --> Output Class Initialized
INFO - 2018-10-18 13:26:53 --> Security Class Initialized
DEBUG - 2018-10-18 13:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 13:26:53 --> CSRF cookie sent
INFO - 2018-10-18 13:26:53 --> CSRF token verified
INFO - 2018-10-18 13:26:53 --> Input Class Initialized
INFO - 2018-10-18 13:26:53 --> Language Class Initialized
INFO - 2018-10-18 13:26:53 --> Loader Class Initialized
INFO - 2018-10-18 13:26:53 --> Helper loaded: url_helper
INFO - 2018-10-18 13:26:53 --> Helper loaded: form_helper
INFO - 2018-10-18 13:26:53 --> Helper loaded: language_helper
DEBUG - 2018-10-18 13:26:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 13:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 13:26:53 --> User Agent Class Initialized
INFO - 2018-10-18 13:26:53 --> Controller Class Initialized
INFO - 2018-10-18 13:26:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 13:26:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 13:26:53 --> Pixel_Model class loaded
INFO - 2018-10-18 13:26:53 --> Database Driver Class Initialized
INFO - 2018-10-18 13:26:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 13:26:53 --> Form Validation Class Initialized
INFO - 2018-10-18 13:26:53 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-10-18 13:26:53 --> Severity: Notice --> Trying to get property 'id' of non-object E:\xampp7\htdocs\famiquity\application\controllers\QuestionnaireController.php 76
INFO - 2018-10-18 13:26:53 --> Database Driver Class Initialized
INFO - 2018-10-18 13:26:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 13:26:54 --> Config Class Initialized
INFO - 2018-10-18 13:26:54 --> Hooks Class Initialized
DEBUG - 2018-10-18 13:26:54 --> UTF-8 Support Enabled
INFO - 2018-10-18 13:26:54 --> Utf8 Class Initialized
INFO - 2018-10-18 13:26:54 --> URI Class Initialized
INFO - 2018-10-18 13:26:54 --> Router Class Initialized
INFO - 2018-10-18 13:26:54 --> Output Class Initialized
INFO - 2018-10-18 13:26:54 --> Security Class Initialized
DEBUG - 2018-10-18 13:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 13:26:54 --> CSRF cookie sent
INFO - 2018-10-18 13:26:54 --> Input Class Initialized
INFO - 2018-10-18 13:26:54 --> Language Class Initialized
INFO - 2018-10-18 13:26:54 --> Loader Class Initialized
INFO - 2018-10-18 13:26:54 --> Helper loaded: url_helper
INFO - 2018-10-18 13:26:54 --> Helper loaded: form_helper
INFO - 2018-10-18 13:26:54 --> Helper loaded: language_helper
DEBUG - 2018-10-18 13:26:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 13:26:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 13:26:54 --> User Agent Class Initialized
INFO - 2018-10-18 13:26:54 --> Controller Class Initialized
INFO - 2018-10-18 13:26:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 13:26:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 13:26:54 --> Pixel_Model class loaded
INFO - 2018-10-18 13:26:54 --> Database Driver Class Initialized
INFO - 2018-10-18 13:26:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 13:26:54 --> Database Driver Class Initialized
INFO - 2018-10-18 13:26:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 13:26:54 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 13:26:54 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 13:26:54 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 13:26:54 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 13:26:54 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 13:26:54 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 13:26:54 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-18 13:26:54 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 13:26:54 --> Final output sent to browser
DEBUG - 2018-10-18 13:26:54 --> Total execution time: 0.4498
INFO - 2018-10-18 13:26:57 --> Config Class Initialized
INFO - 2018-10-18 13:26:57 --> Hooks Class Initialized
DEBUG - 2018-10-18 13:26:58 --> UTF-8 Support Enabled
INFO - 2018-10-18 13:26:58 --> Utf8 Class Initialized
INFO - 2018-10-18 13:26:58 --> URI Class Initialized
INFO - 2018-10-18 13:26:58 --> Router Class Initialized
INFO - 2018-10-18 13:26:58 --> Output Class Initialized
INFO - 2018-10-18 13:26:58 --> Security Class Initialized
DEBUG - 2018-10-18 13:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 13:26:58 --> CSRF cookie sent
INFO - 2018-10-18 13:26:58 --> CSRF token verified
INFO - 2018-10-18 13:26:58 --> Input Class Initialized
INFO - 2018-10-18 13:26:58 --> Language Class Initialized
INFO - 2018-10-18 13:26:58 --> Loader Class Initialized
INFO - 2018-10-18 13:26:58 --> Helper loaded: url_helper
INFO - 2018-10-18 13:26:58 --> Helper loaded: form_helper
INFO - 2018-10-18 13:26:58 --> Helper loaded: language_helper
DEBUG - 2018-10-18 13:26:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 13:26:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 13:26:58 --> User Agent Class Initialized
INFO - 2018-10-18 13:26:58 --> Controller Class Initialized
INFO - 2018-10-18 13:26:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 13:26:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 13:26:58 --> Pixel_Model class loaded
INFO - 2018-10-18 13:26:58 --> Database Driver Class Initialized
INFO - 2018-10-18 13:26:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 13:26:58 --> Form Validation Class Initialized
INFO - 2018-10-18 13:26:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 13:26:58 --> Database Driver Class Initialized
INFO - 2018-10-18 13:26:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 13:26:58 --> Config Class Initialized
INFO - 2018-10-18 13:26:58 --> Hooks Class Initialized
DEBUG - 2018-10-18 13:26:58 --> UTF-8 Support Enabled
INFO - 2018-10-18 13:26:58 --> Utf8 Class Initialized
INFO - 2018-10-18 13:26:58 --> URI Class Initialized
INFO - 2018-10-18 13:26:58 --> Router Class Initialized
INFO - 2018-10-18 13:26:58 --> Output Class Initialized
INFO - 2018-10-18 13:26:58 --> Security Class Initialized
DEBUG - 2018-10-18 13:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 13:26:58 --> CSRF cookie sent
INFO - 2018-10-18 13:26:58 --> Input Class Initialized
INFO - 2018-10-18 13:26:58 --> Language Class Initialized
INFO - 2018-10-18 13:26:58 --> Loader Class Initialized
INFO - 2018-10-18 13:26:58 --> Helper loaded: url_helper
INFO - 2018-10-18 13:26:58 --> Helper loaded: form_helper
INFO - 2018-10-18 13:26:58 --> Helper loaded: language_helper
DEBUG - 2018-10-18 13:26:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 13:26:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 13:26:58 --> User Agent Class Initialized
INFO - 2018-10-18 13:26:58 --> Controller Class Initialized
INFO - 2018-10-18 13:26:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 13:26:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 13:26:58 --> Pixel_Model class loaded
INFO - 2018-10-18 13:26:58 --> Database Driver Class Initialized
INFO - 2018-10-18 13:26:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 13:26:58 --> Database Driver Class Initialized
INFO - 2018-10-18 13:26:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 13:26:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 13:26:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 13:26:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 13:26:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 13:26:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
ERROR - 2018-10-18 13:26:58 --> Severity: Notice --> Undefined variable: show_assessment E:\xampp7\htdocs\famiquity\application\views\questions\your_job.php 29
INFO - 2018-10-18 13:26:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 13:26:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/your_job.php
INFO - 2018-10-18 13:26:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 13:26:58 --> Final output sent to browser
DEBUG - 2018-10-18 13:26:58 --> Total execution time: 0.4350
INFO - 2018-10-18 13:27:04 --> Config Class Initialized
INFO - 2018-10-18 13:27:04 --> Hooks Class Initialized
DEBUG - 2018-10-18 13:27:04 --> UTF-8 Support Enabled
INFO - 2018-10-18 13:27:04 --> Utf8 Class Initialized
INFO - 2018-10-18 13:27:04 --> URI Class Initialized
INFO - 2018-10-18 13:27:04 --> Router Class Initialized
INFO - 2018-10-18 13:27:04 --> Output Class Initialized
INFO - 2018-10-18 13:27:04 --> Security Class Initialized
DEBUG - 2018-10-18 13:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 13:27:04 --> CSRF cookie sent
INFO - 2018-10-18 13:27:04 --> CSRF token verified
INFO - 2018-10-18 13:27:04 --> Input Class Initialized
INFO - 2018-10-18 13:27:04 --> Language Class Initialized
INFO - 2018-10-18 13:27:04 --> Loader Class Initialized
INFO - 2018-10-18 13:27:04 --> Helper loaded: url_helper
INFO - 2018-10-18 13:27:04 --> Helper loaded: form_helper
INFO - 2018-10-18 13:27:04 --> Helper loaded: language_helper
DEBUG - 2018-10-18 13:27:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 13:27:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 13:27:04 --> User Agent Class Initialized
INFO - 2018-10-18 13:27:05 --> Controller Class Initialized
INFO - 2018-10-18 13:27:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 13:27:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 13:27:05 --> Pixel_Model class loaded
INFO - 2018-10-18 13:27:05 --> Database Driver Class Initialized
INFO - 2018-10-18 13:27:05 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 13:27:05 --> Form Validation Class Initialized
INFO - 2018-10-18 13:27:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 13:27:05 --> Database Driver Class Initialized
INFO - 2018-10-18 13:27:05 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 13:27:05 --> Config Class Initialized
INFO - 2018-10-18 13:27:05 --> Hooks Class Initialized
DEBUG - 2018-10-18 13:27:05 --> UTF-8 Support Enabled
INFO - 2018-10-18 13:27:05 --> Utf8 Class Initialized
INFO - 2018-10-18 13:27:05 --> URI Class Initialized
INFO - 2018-10-18 13:27:05 --> Router Class Initialized
INFO - 2018-10-18 13:27:05 --> Output Class Initialized
INFO - 2018-10-18 13:27:05 --> Security Class Initialized
DEBUG - 2018-10-18 13:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 13:27:05 --> CSRF cookie sent
INFO - 2018-10-18 13:27:05 --> Input Class Initialized
INFO - 2018-10-18 13:27:05 --> Language Class Initialized
INFO - 2018-10-18 13:27:05 --> Loader Class Initialized
INFO - 2018-10-18 13:27:05 --> Helper loaded: url_helper
INFO - 2018-10-18 13:27:05 --> Helper loaded: form_helper
INFO - 2018-10-18 13:27:05 --> Helper loaded: language_helper
DEBUG - 2018-10-18 13:27:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 13:27:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 13:27:05 --> User Agent Class Initialized
INFO - 2018-10-18 13:27:05 --> Controller Class Initialized
INFO - 2018-10-18 13:27:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 13:27:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 13:27:05 --> Pixel_Model class loaded
INFO - 2018-10-18 13:27:05 --> Database Driver Class Initialized
INFO - 2018-10-18 13:27:05 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 13:27:05 --> Database Driver Class Initialized
INFO - 2018-10-18 13:27:05 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 13:27:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 13:27:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 13:27:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner.php
INFO - 2018-10-18 13:27:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 13:27:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 13:27:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
ERROR - 2018-10-18 13:27:05 --> Severity: Notice --> Undefined variable: show_assessment E:\xampp7\htdocs\famiquity\application\views\questions\relation_ship_status.php 30
INFO - 2018-10-18 13:27:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 13:27:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/relation_ship_status.php
INFO - 2018-10-18 13:27:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 13:27:05 --> Final output sent to browser
DEBUG - 2018-10-18 13:27:05 --> Total execution time: 0.4596
INFO - 2018-10-18 13:27:08 --> Config Class Initialized
INFO - 2018-10-18 13:27:08 --> Hooks Class Initialized
DEBUG - 2018-10-18 13:27:08 --> UTF-8 Support Enabled
INFO - 2018-10-18 13:27:08 --> Utf8 Class Initialized
INFO - 2018-10-18 13:27:08 --> URI Class Initialized
INFO - 2018-10-18 13:27:08 --> Router Class Initialized
INFO - 2018-10-18 13:27:08 --> Output Class Initialized
INFO - 2018-10-18 13:27:08 --> Security Class Initialized
DEBUG - 2018-10-18 13:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 13:27:08 --> CSRF cookie sent
INFO - 2018-10-18 13:27:08 --> CSRF token verified
INFO - 2018-10-18 13:27:08 --> Input Class Initialized
INFO - 2018-10-18 13:27:08 --> Language Class Initialized
INFO - 2018-10-18 13:27:08 --> Loader Class Initialized
INFO - 2018-10-18 13:27:08 --> Helper loaded: url_helper
INFO - 2018-10-18 13:27:08 --> Helper loaded: form_helper
INFO - 2018-10-18 13:27:08 --> Helper loaded: language_helper
DEBUG - 2018-10-18 13:27:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 13:27:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 13:27:08 --> User Agent Class Initialized
INFO - 2018-10-18 13:27:08 --> Controller Class Initialized
INFO - 2018-10-18 13:27:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 13:27:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 13:27:08 --> Pixel_Model class loaded
INFO - 2018-10-18 13:27:08 --> Database Driver Class Initialized
INFO - 2018-10-18 13:27:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 13:27:08 --> Form Validation Class Initialized
INFO - 2018-10-18 13:27:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 13:27:08 --> Database Driver Class Initialized
INFO - 2018-10-18 13:27:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 13:27:09 --> Config Class Initialized
INFO - 2018-10-18 13:27:09 --> Hooks Class Initialized
DEBUG - 2018-10-18 13:27:09 --> UTF-8 Support Enabled
INFO - 2018-10-18 13:27:09 --> Utf8 Class Initialized
INFO - 2018-10-18 13:27:09 --> URI Class Initialized
INFO - 2018-10-18 13:27:09 --> Router Class Initialized
INFO - 2018-10-18 13:27:09 --> Output Class Initialized
INFO - 2018-10-18 13:27:09 --> Security Class Initialized
DEBUG - 2018-10-18 13:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 13:27:09 --> CSRF cookie sent
INFO - 2018-10-18 13:27:09 --> Input Class Initialized
INFO - 2018-10-18 13:27:09 --> Language Class Initialized
INFO - 2018-10-18 13:27:09 --> Loader Class Initialized
INFO - 2018-10-18 13:27:09 --> Helper loaded: url_helper
INFO - 2018-10-18 13:27:09 --> Helper loaded: form_helper
INFO - 2018-10-18 13:27:09 --> Helper loaded: language_helper
DEBUG - 2018-10-18 13:27:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 13:27:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 13:27:09 --> User Agent Class Initialized
INFO - 2018-10-18 13:27:09 --> Controller Class Initialized
INFO - 2018-10-18 13:27:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 13:27:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 13:27:09 --> Pixel_Model class loaded
INFO - 2018-10-18 13:27:09 --> Database Driver Class Initialized
INFO - 2018-10-18 13:27:09 --> Model "QuestionsModel" initialized
ERROR - 2018-10-18 13:27:09 --> Severity: Notice --> Undefined variable: spoualfactor E:\xampp7\htdocs\famiquity\application\libraries\Smart.php 642
ERROR - 2018-10-18 13:27:09 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable E:\xampp7\htdocs\famiquity\application\libraries\Smart.php 646
ERROR - 2018-10-18 13:27:09 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable E:\xampp7\htdocs\famiquity\application\libraries\Smart.php 652
INFO - 2018-10-18 13:27:09 --> Database Driver Class Initialized
INFO - 2018-10-18 13:27:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 13:27:09 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 13:27:09 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 13:27:09 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 13:27:09 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 13:27:09 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
ERROR - 2018-10-18 13:27:09 --> Severity: Notice --> Undefined variable: show_assessment E:\xampp7\htdocs\famiquity\application\views\questions\income.php 46
INFO - 2018-10-18 13:27:09 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 13:27:09 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/income.php
INFO - 2018-10-18 13:27:09 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 13:27:09 --> Final output sent to browser
DEBUG - 2018-10-18 13:27:09 --> Total execution time: 0.5345
INFO - 2018-10-18 13:27:22 --> Config Class Initialized
INFO - 2018-10-18 13:27:22 --> Hooks Class Initialized
DEBUG - 2018-10-18 13:27:22 --> UTF-8 Support Enabled
INFO - 2018-10-18 13:27:22 --> Utf8 Class Initialized
INFO - 2018-10-18 13:27:22 --> URI Class Initialized
INFO - 2018-10-18 13:27:22 --> Router Class Initialized
INFO - 2018-10-18 13:27:22 --> Output Class Initialized
INFO - 2018-10-18 13:27:22 --> Security Class Initialized
DEBUG - 2018-10-18 13:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 13:27:22 --> CSRF cookie sent
INFO - 2018-10-18 13:27:22 --> Input Class Initialized
INFO - 2018-10-18 13:27:22 --> Language Class Initialized
INFO - 2018-10-18 13:27:22 --> Loader Class Initialized
INFO - 2018-10-18 13:27:22 --> Helper loaded: url_helper
INFO - 2018-10-18 13:27:22 --> Helper loaded: form_helper
INFO - 2018-10-18 13:27:22 --> Helper loaded: language_helper
DEBUG - 2018-10-18 13:27:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 13:27:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 13:27:22 --> User Agent Class Initialized
INFO - 2018-10-18 13:27:22 --> Controller Class Initialized
INFO - 2018-10-18 13:27:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 13:27:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 13:27:22 --> Pixel_Model class loaded
INFO - 2018-10-18 13:27:22 --> Database Driver Class Initialized
INFO - 2018-10-18 13:27:22 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 13:27:22 --> Database Driver Class Initialized
INFO - 2018-10-18 13:27:22 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 13:27:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 13:27:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 13:27:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 13:27:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 13:27:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 13:27:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 13:27:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/income.php
INFO - 2018-10-18 13:27:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 13:27:22 --> Final output sent to browser
DEBUG - 2018-10-18 13:27:22 --> Total execution time: 0.4351
INFO - 2018-10-18 13:51:46 --> Config Class Initialized
INFO - 2018-10-18 13:51:46 --> Hooks Class Initialized
DEBUG - 2018-10-18 13:51:46 --> UTF-8 Support Enabled
INFO - 2018-10-18 13:51:46 --> Utf8 Class Initialized
INFO - 2018-10-18 13:51:46 --> URI Class Initialized
INFO - 2018-10-18 13:51:46 --> Router Class Initialized
INFO - 2018-10-18 13:51:47 --> Output Class Initialized
INFO - 2018-10-18 13:51:47 --> Security Class Initialized
DEBUG - 2018-10-18 13:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 13:51:47 --> CSRF cookie sent
INFO - 2018-10-18 13:51:47 --> Input Class Initialized
INFO - 2018-10-18 13:51:47 --> Language Class Initialized
INFO - 2018-10-18 13:51:47 --> Loader Class Initialized
INFO - 2018-10-18 13:51:47 --> Helper loaded: url_helper
INFO - 2018-10-18 13:51:47 --> Helper loaded: form_helper
INFO - 2018-10-18 13:51:47 --> Helper loaded: language_helper
DEBUG - 2018-10-18 13:51:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 13:51:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 13:51:47 --> User Agent Class Initialized
INFO - 2018-10-18 13:51:47 --> Controller Class Initialized
INFO - 2018-10-18 13:51:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 13:51:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 13:51:47 --> Pixel_Model class loaded
INFO - 2018-10-18 13:51:47 --> Database Driver Class Initialized
INFO - 2018-10-18 13:51:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 13:51:47 --> Database Driver Class Initialized
INFO - 2018-10-18 13:51:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 13:51:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 13:51:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 13:51:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 13:51:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 13:51:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 13:51:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 13:51:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/income.php
INFO - 2018-10-18 13:51:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 13:51:47 --> Final output sent to browser
DEBUG - 2018-10-18 13:51:47 --> Total execution time: 0.4294
INFO - 2018-10-18 13:51:49 --> Config Class Initialized
INFO - 2018-10-18 13:51:49 --> Hooks Class Initialized
DEBUG - 2018-10-18 13:51:49 --> UTF-8 Support Enabled
INFO - 2018-10-18 13:51:49 --> Utf8 Class Initialized
INFO - 2018-10-18 13:51:49 --> URI Class Initialized
INFO - 2018-10-18 13:51:49 --> Router Class Initialized
INFO - 2018-10-18 13:51:49 --> Output Class Initialized
INFO - 2018-10-18 13:51:49 --> Security Class Initialized
DEBUG - 2018-10-18 13:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 13:51:49 --> CSRF cookie sent
INFO - 2018-10-18 13:51:49 --> Input Class Initialized
INFO - 2018-10-18 13:51:49 --> Language Class Initialized
INFO - 2018-10-18 13:51:49 --> Loader Class Initialized
INFO - 2018-10-18 13:51:49 --> Helper loaded: url_helper
INFO - 2018-10-18 13:51:49 --> Helper loaded: form_helper
INFO - 2018-10-18 13:51:49 --> Helper loaded: language_helper
DEBUG - 2018-10-18 13:51:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 13:51:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 13:51:49 --> User Agent Class Initialized
INFO - 2018-10-18 13:51:49 --> Controller Class Initialized
INFO - 2018-10-18 13:51:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 13:51:49 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-18 13:51:49 --> Config file loaded: E:\xampp7\htdocs\famiquity\application\config/recaptcha.php
INFO - 2018-10-18 13:51:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 13:51:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 13:51:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 13:51:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
ERROR - 2018-10-18 13:51:49 --> Could not find the language line "req_email"
INFO - 2018-10-18 13:51:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\myaccount/signin.php
INFO - 2018-10-18 13:51:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 13:51:49 --> Final output sent to browser
DEBUG - 2018-10-18 13:51:49 --> Total execution time: 0.3390
INFO - 2018-10-18 13:52:58 --> Config Class Initialized
INFO - 2018-10-18 13:52:58 --> Hooks Class Initialized
DEBUG - 2018-10-18 13:52:58 --> UTF-8 Support Enabled
INFO - 2018-10-18 13:52:58 --> Utf8 Class Initialized
INFO - 2018-10-18 13:52:58 --> URI Class Initialized
INFO - 2018-10-18 13:52:58 --> Router Class Initialized
INFO - 2018-10-18 13:52:58 --> Output Class Initialized
INFO - 2018-10-18 13:52:58 --> Security Class Initialized
DEBUG - 2018-10-18 13:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 13:52:58 --> CSRF cookie sent
INFO - 2018-10-18 13:52:58 --> CSRF token verified
INFO - 2018-10-18 13:52:58 --> Input Class Initialized
INFO - 2018-10-18 13:52:58 --> Language Class Initialized
INFO - 2018-10-18 13:52:58 --> Loader Class Initialized
INFO - 2018-10-18 13:52:58 --> Helper loaded: url_helper
INFO - 2018-10-18 13:52:58 --> Helper loaded: form_helper
INFO - 2018-10-18 13:52:58 --> Helper loaded: language_helper
DEBUG - 2018-10-18 13:52:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 13:52:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 13:52:58 --> User Agent Class Initialized
INFO - 2018-10-18 13:52:58 --> Controller Class Initialized
INFO - 2018-10-18 13:52:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 13:52:58 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-18 13:52:58 --> Config file loaded: E:\xampp7\htdocs\famiquity\application\config/recaptcha.php
INFO - 2018-10-18 13:52:58 --> Config Class Initialized
INFO - 2018-10-18 13:52:58 --> Hooks Class Initialized
DEBUG - 2018-10-18 13:52:58 --> UTF-8 Support Enabled
INFO - 2018-10-18 13:52:58 --> Utf8 Class Initialized
INFO - 2018-10-18 13:52:58 --> URI Class Initialized
INFO - 2018-10-18 13:52:58 --> Router Class Initialized
INFO - 2018-10-18 13:52:58 --> Output Class Initialized
INFO - 2018-10-18 13:52:58 --> Security Class Initialized
DEBUG - 2018-10-18 13:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 13:52:58 --> CSRF cookie sent
INFO - 2018-10-18 13:52:58 --> Input Class Initialized
INFO - 2018-10-18 13:52:58 --> Language Class Initialized
INFO - 2018-10-18 13:52:58 --> Loader Class Initialized
INFO - 2018-10-18 13:52:58 --> Helper loaded: url_helper
INFO - 2018-10-18 13:52:58 --> Helper loaded: form_helper
INFO - 2018-10-18 13:52:58 --> Helper loaded: language_helper
DEBUG - 2018-10-18 13:52:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 13:52:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 13:52:58 --> User Agent Class Initialized
INFO - 2018-10-18 13:52:58 --> Controller Class Initialized
INFO - 2018-10-18 13:52:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 13:52:58 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-18 13:52:58 --> Config file loaded: E:\xampp7\htdocs\famiquity\application\config/recaptcha.php
INFO - 2018-10-18 13:52:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 13:52:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 13:52:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 13:52:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 13:52:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_soft_error.php
ERROR - 2018-10-18 13:52:58 --> Could not find the language line "req_email"
INFO - 2018-10-18 13:52:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\myaccount/signin.php
INFO - 2018-10-18 13:52:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 13:52:58 --> Final output sent to browser
DEBUG - 2018-10-18 13:52:58 --> Total execution time: 0.3589
INFO - 2018-10-18 13:53:35 --> Config Class Initialized
INFO - 2018-10-18 13:53:35 --> Hooks Class Initialized
DEBUG - 2018-10-18 13:53:35 --> UTF-8 Support Enabled
INFO - 2018-10-18 13:53:35 --> Utf8 Class Initialized
INFO - 2018-10-18 13:53:35 --> URI Class Initialized
INFO - 2018-10-18 13:53:35 --> Router Class Initialized
INFO - 2018-10-18 13:53:35 --> Output Class Initialized
INFO - 2018-10-18 13:53:35 --> Security Class Initialized
DEBUG - 2018-10-18 13:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 13:53:35 --> CSRF cookie sent
INFO - 2018-10-18 13:53:35 --> CSRF token verified
INFO - 2018-10-18 13:53:35 --> Input Class Initialized
INFO - 2018-10-18 13:53:35 --> Language Class Initialized
INFO - 2018-10-18 13:53:35 --> Loader Class Initialized
INFO - 2018-10-18 13:53:35 --> Helper loaded: url_helper
INFO - 2018-10-18 13:53:35 --> Helper loaded: form_helper
INFO - 2018-10-18 13:53:35 --> Helper loaded: language_helper
DEBUG - 2018-10-18 13:53:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 13:53:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 13:53:35 --> User Agent Class Initialized
INFO - 2018-10-18 13:53:35 --> Controller Class Initialized
INFO - 2018-10-18 13:53:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 13:53:35 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-18 13:53:35 --> Config file loaded: E:\xampp7\htdocs\famiquity\application\config/recaptcha.php
INFO - 2018-10-18 13:53:35 --> Config Class Initialized
INFO - 2018-10-18 13:53:35 --> Hooks Class Initialized
DEBUG - 2018-10-18 13:53:35 --> UTF-8 Support Enabled
INFO - 2018-10-18 13:53:35 --> Utf8 Class Initialized
INFO - 2018-10-18 13:53:35 --> URI Class Initialized
INFO - 2018-10-18 13:53:35 --> Router Class Initialized
INFO - 2018-10-18 13:53:35 --> Output Class Initialized
INFO - 2018-10-18 13:53:35 --> Security Class Initialized
DEBUG - 2018-10-18 13:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 13:53:35 --> CSRF cookie sent
INFO - 2018-10-18 13:53:35 --> Input Class Initialized
INFO - 2018-10-18 13:53:35 --> Language Class Initialized
INFO - 2018-10-18 13:53:35 --> Loader Class Initialized
INFO - 2018-10-18 13:53:35 --> Helper loaded: url_helper
INFO - 2018-10-18 13:53:35 --> Helper loaded: form_helper
INFO - 2018-10-18 13:53:36 --> Helper loaded: language_helper
DEBUG - 2018-10-18 13:53:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 13:53:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 13:53:36 --> User Agent Class Initialized
INFO - 2018-10-18 13:53:36 --> Controller Class Initialized
INFO - 2018-10-18 13:53:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 13:53:36 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-18 13:53:36 --> Config file loaded: E:\xampp7\htdocs\famiquity\application\config/recaptcha.php
INFO - 2018-10-18 13:53:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 13:53:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 13:53:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 13:53:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 13:53:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_soft_error.php
ERROR - 2018-10-18 13:53:36 --> Could not find the language line "req_email"
INFO - 2018-10-18 13:53:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\myaccount/signin.php
INFO - 2018-10-18 13:53:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 13:53:36 --> Final output sent to browser
DEBUG - 2018-10-18 13:53:36 --> Total execution time: 0.3499
INFO - 2018-10-18 13:54:03 --> Config Class Initialized
INFO - 2018-10-18 13:54:03 --> Hooks Class Initialized
DEBUG - 2018-10-18 13:54:03 --> UTF-8 Support Enabled
INFO - 2018-10-18 13:54:03 --> Utf8 Class Initialized
INFO - 2018-10-18 13:54:03 --> URI Class Initialized
INFO - 2018-10-18 13:54:03 --> Router Class Initialized
INFO - 2018-10-18 13:54:03 --> Output Class Initialized
INFO - 2018-10-18 13:54:03 --> Security Class Initialized
DEBUG - 2018-10-18 13:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 13:54:03 --> CSRF cookie sent
INFO - 2018-10-18 13:54:03 --> Input Class Initialized
INFO - 2018-10-18 13:54:03 --> Language Class Initialized
INFO - 2018-10-18 13:54:03 --> Loader Class Initialized
INFO - 2018-10-18 13:54:03 --> Helper loaded: url_helper
INFO - 2018-10-18 13:54:03 --> Helper loaded: form_helper
INFO - 2018-10-18 13:54:03 --> Helper loaded: language_helper
DEBUG - 2018-10-18 13:54:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 13:54:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 13:54:03 --> User Agent Class Initialized
INFO - 2018-10-18 13:54:03 --> Controller Class Initialized
INFO - 2018-10-18 13:54:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 13:54:03 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-18 13:54:03 --> Config file loaded: E:\xampp7\htdocs\famiquity\application\config/recaptcha.php
INFO - 2018-10-18 13:54:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 13:54:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 13:54:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 13:54:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
ERROR - 2018-10-18 13:54:03 --> Could not find the language line "req_email"
INFO - 2018-10-18 13:54:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\myaccount/signin.php
INFO - 2018-10-18 13:54:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 13:54:03 --> Final output sent to browser
DEBUG - 2018-10-18 13:54:03 --> Total execution time: 0.3786
INFO - 2018-10-18 13:54:13 --> Config Class Initialized
INFO - 2018-10-18 13:54:13 --> Hooks Class Initialized
DEBUG - 2018-10-18 13:54:13 --> UTF-8 Support Enabled
INFO - 2018-10-18 13:54:13 --> Utf8 Class Initialized
INFO - 2018-10-18 13:54:13 --> URI Class Initialized
INFO - 2018-10-18 13:54:13 --> Router Class Initialized
INFO - 2018-10-18 13:54:13 --> Output Class Initialized
INFO - 2018-10-18 13:54:13 --> Security Class Initialized
DEBUG - 2018-10-18 13:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 13:54:13 --> CSRF cookie sent
INFO - 2018-10-18 13:54:13 --> CSRF token verified
INFO - 2018-10-18 13:54:13 --> Input Class Initialized
INFO - 2018-10-18 13:54:13 --> Language Class Initialized
INFO - 2018-10-18 13:54:13 --> Loader Class Initialized
INFO - 2018-10-18 13:54:13 --> Helper loaded: url_helper
INFO - 2018-10-18 13:54:13 --> Helper loaded: form_helper
INFO - 2018-10-18 13:54:13 --> Helper loaded: language_helper
DEBUG - 2018-10-18 13:54:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 13:54:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 13:54:14 --> User Agent Class Initialized
INFO - 2018-10-18 13:54:14 --> Controller Class Initialized
INFO - 2018-10-18 13:54:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 13:54:14 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-18 13:54:14 --> Config file loaded: E:\xampp7\htdocs\famiquity\application\config/recaptcha.php
INFO - 2018-10-18 13:54:14 --> Config Class Initialized
INFO - 2018-10-18 13:54:14 --> Hooks Class Initialized
DEBUG - 2018-10-18 13:54:14 --> UTF-8 Support Enabled
INFO - 2018-10-18 13:54:14 --> Utf8 Class Initialized
INFO - 2018-10-18 13:54:14 --> URI Class Initialized
INFO - 2018-10-18 13:54:14 --> Router Class Initialized
INFO - 2018-10-18 13:54:14 --> Output Class Initialized
INFO - 2018-10-18 13:54:14 --> Security Class Initialized
DEBUG - 2018-10-18 13:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 13:54:14 --> CSRF cookie sent
INFO - 2018-10-18 13:54:14 --> Input Class Initialized
INFO - 2018-10-18 13:54:14 --> Language Class Initialized
INFO - 2018-10-18 13:54:14 --> Loader Class Initialized
INFO - 2018-10-18 13:54:14 --> Helper loaded: url_helper
INFO - 2018-10-18 13:54:14 --> Helper loaded: form_helper
INFO - 2018-10-18 13:54:14 --> Helper loaded: language_helper
DEBUG - 2018-10-18 13:54:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 13:54:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 13:54:14 --> User Agent Class Initialized
INFO - 2018-10-18 13:54:14 --> Controller Class Initialized
INFO - 2018-10-18 13:54:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 13:54:14 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-18 13:54:14 --> Config file loaded: E:\xampp7\htdocs\famiquity\application\config/recaptcha.php
INFO - 2018-10-18 13:54:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 13:54:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 13:54:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 13:54:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 13:54:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_soft_error.php
ERROR - 2018-10-18 13:54:14 --> Could not find the language line "req_email"
INFO - 2018-10-18 13:54:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\myaccount/signin.php
INFO - 2018-10-18 13:54:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 13:54:14 --> Final output sent to browser
DEBUG - 2018-10-18 13:54:14 --> Total execution time: 0.3583
INFO - 2018-10-18 13:54:48 --> Config Class Initialized
INFO - 2018-10-18 13:54:48 --> Hooks Class Initialized
DEBUG - 2018-10-18 13:54:48 --> UTF-8 Support Enabled
INFO - 2018-10-18 13:54:48 --> Utf8 Class Initialized
INFO - 2018-10-18 13:54:48 --> URI Class Initialized
INFO - 2018-10-18 13:54:48 --> Router Class Initialized
INFO - 2018-10-18 13:54:48 --> Output Class Initialized
INFO - 2018-10-18 13:54:48 --> Security Class Initialized
DEBUG - 2018-10-18 13:54:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 13:54:48 --> CSRF cookie sent
INFO - 2018-10-18 13:54:48 --> Input Class Initialized
INFO - 2018-10-18 13:54:48 --> Language Class Initialized
INFO - 2018-10-18 13:54:48 --> Loader Class Initialized
INFO - 2018-10-18 13:54:48 --> Helper loaded: url_helper
INFO - 2018-10-18 13:54:48 --> Helper loaded: form_helper
INFO - 2018-10-18 13:54:48 --> Helper loaded: language_helper
DEBUG - 2018-10-18 13:54:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 13:54:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 13:54:48 --> User Agent Class Initialized
INFO - 2018-10-18 13:54:48 --> Controller Class Initialized
INFO - 2018-10-18 13:54:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 13:54:48 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-18 13:54:49 --> Config file loaded: E:\xampp7\htdocs\famiquity\application\config/recaptcha.php
INFO - 2018-10-18 13:54:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 13:54:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 13:54:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 13:54:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
ERROR - 2018-10-18 13:54:49 --> Could not find the language line "req_email"
INFO - 2018-10-18 13:54:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\myaccount/signin.php
INFO - 2018-10-18 13:54:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 13:54:49 --> Final output sent to browser
DEBUG - 2018-10-18 13:54:49 --> Total execution time: 0.3688
INFO - 2018-10-18 13:55:00 --> Config Class Initialized
INFO - 2018-10-18 13:55:00 --> Hooks Class Initialized
DEBUG - 2018-10-18 13:55:00 --> UTF-8 Support Enabled
INFO - 2018-10-18 13:55:00 --> Utf8 Class Initialized
INFO - 2018-10-18 13:55:00 --> URI Class Initialized
INFO - 2018-10-18 13:55:00 --> Router Class Initialized
INFO - 2018-10-18 13:55:00 --> Output Class Initialized
INFO - 2018-10-18 13:55:00 --> Security Class Initialized
DEBUG - 2018-10-18 13:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 13:55:00 --> CSRF cookie sent
INFO - 2018-10-18 13:55:00 --> CSRF token verified
INFO - 2018-10-18 13:55:00 --> Input Class Initialized
INFO - 2018-10-18 13:55:00 --> Language Class Initialized
INFO - 2018-10-18 13:55:00 --> Loader Class Initialized
INFO - 2018-10-18 13:55:00 --> Helper loaded: url_helper
INFO - 2018-10-18 13:55:00 --> Helper loaded: form_helper
INFO - 2018-10-18 13:55:00 --> Helper loaded: language_helper
DEBUG - 2018-10-18 13:55:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 13:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 13:55:00 --> User Agent Class Initialized
INFO - 2018-10-18 13:55:00 --> Controller Class Initialized
INFO - 2018-10-18 13:55:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 13:55:00 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-18 13:55:00 --> Config file loaded: E:\xampp7\htdocs\famiquity\application\config/recaptcha.php
INFO - 2018-10-18 13:55:00 --> Config Class Initialized
INFO - 2018-10-18 13:55:00 --> Hooks Class Initialized
DEBUG - 2018-10-18 13:55:00 --> UTF-8 Support Enabled
INFO - 2018-10-18 13:55:00 --> Utf8 Class Initialized
INFO - 2018-10-18 13:55:00 --> URI Class Initialized
INFO - 2018-10-18 13:55:00 --> Router Class Initialized
INFO - 2018-10-18 13:55:00 --> Output Class Initialized
INFO - 2018-10-18 13:55:00 --> Security Class Initialized
DEBUG - 2018-10-18 13:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 13:55:00 --> CSRF cookie sent
INFO - 2018-10-18 13:55:00 --> Input Class Initialized
INFO - 2018-10-18 13:55:00 --> Language Class Initialized
INFO - 2018-10-18 13:55:00 --> Loader Class Initialized
INFO - 2018-10-18 13:55:00 --> Helper loaded: url_helper
INFO - 2018-10-18 13:55:00 --> Helper loaded: form_helper
INFO - 2018-10-18 13:55:00 --> Helper loaded: language_helper
DEBUG - 2018-10-18 13:55:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 13:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 13:55:00 --> User Agent Class Initialized
INFO - 2018-10-18 13:55:00 --> Controller Class Initialized
INFO - 2018-10-18 13:55:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 13:55:00 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-18 13:55:00 --> Config file loaded: E:\xampp7\htdocs\famiquity\application\config/recaptcha.php
INFO - 2018-10-18 13:55:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 13:55:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 13:55:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 13:55:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 13:55:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_soft_error.php
ERROR - 2018-10-18 13:55:00 --> Could not find the language line "req_email"
INFO - 2018-10-18 13:55:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\myaccount/signin.php
INFO - 2018-10-18 13:55:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 13:55:00 --> Final output sent to browser
DEBUG - 2018-10-18 13:55:00 --> Total execution time: 0.3487
INFO - 2018-10-18 13:57:07 --> Config Class Initialized
INFO - 2018-10-18 13:57:07 --> Hooks Class Initialized
DEBUG - 2018-10-18 13:57:07 --> UTF-8 Support Enabled
INFO - 2018-10-18 13:57:07 --> Utf8 Class Initialized
INFO - 2018-10-18 13:57:07 --> URI Class Initialized
INFO - 2018-10-18 13:57:07 --> Router Class Initialized
INFO - 2018-10-18 13:57:07 --> Output Class Initialized
INFO - 2018-10-18 13:57:07 --> Security Class Initialized
DEBUG - 2018-10-18 13:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 13:57:07 --> CSRF cookie sent
INFO - 2018-10-18 13:57:08 --> Input Class Initialized
INFO - 2018-10-18 13:57:08 --> Language Class Initialized
INFO - 2018-10-18 13:57:08 --> Loader Class Initialized
INFO - 2018-10-18 13:57:08 --> Helper loaded: url_helper
INFO - 2018-10-18 13:57:08 --> Helper loaded: form_helper
INFO - 2018-10-18 13:57:08 --> Helper loaded: language_helper
DEBUG - 2018-10-18 13:57:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 13:57:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 13:57:08 --> User Agent Class Initialized
INFO - 2018-10-18 13:57:08 --> Controller Class Initialized
INFO - 2018-10-18 13:57:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 13:57:08 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-18 13:57:08 --> Config file loaded: E:\xampp7\htdocs\famiquity\application\config/recaptcha.php
INFO - 2018-10-18 13:57:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 13:57:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 13:57:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 13:57:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
ERROR - 2018-10-18 13:57:08 --> Could not find the language line "req_email"
INFO - 2018-10-18 13:57:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\myaccount/signin.php
INFO - 2018-10-18 13:57:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 13:57:08 --> Final output sent to browser
DEBUG - 2018-10-18 13:57:08 --> Total execution time: 0.3667
INFO - 2018-10-18 13:57:14 --> Config Class Initialized
INFO - 2018-10-18 13:57:14 --> Hooks Class Initialized
DEBUG - 2018-10-18 13:57:14 --> UTF-8 Support Enabled
INFO - 2018-10-18 13:57:14 --> Utf8 Class Initialized
INFO - 2018-10-18 13:57:14 --> URI Class Initialized
INFO - 2018-10-18 13:57:14 --> Router Class Initialized
INFO - 2018-10-18 13:57:14 --> Output Class Initialized
INFO - 2018-10-18 13:57:14 --> Security Class Initialized
DEBUG - 2018-10-18 13:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 13:57:14 --> CSRF cookie sent
INFO - 2018-10-18 13:57:14 --> Input Class Initialized
INFO - 2018-10-18 13:57:14 --> Language Class Initialized
INFO - 2018-10-18 13:57:14 --> Loader Class Initialized
INFO - 2018-10-18 13:57:14 --> Helper loaded: url_helper
INFO - 2018-10-18 13:57:14 --> Helper loaded: form_helper
INFO - 2018-10-18 13:57:14 --> Helper loaded: language_helper
DEBUG - 2018-10-18 13:57:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 13:57:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 13:57:14 --> User Agent Class Initialized
INFO - 2018-10-18 13:57:14 --> Controller Class Initialized
INFO - 2018-10-18 13:57:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 13:57:14 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-18 13:57:14 --> Config file loaded: E:\xampp7\htdocs\famiquity\application\config/recaptcha.php
INFO - 2018-10-18 13:57:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 13:57:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 13:57:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 13:57:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
ERROR - 2018-10-18 13:57:14 --> Could not find the language line "req_email"
INFO - 2018-10-18 13:57:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\myaccount/signin.php
INFO - 2018-10-18 13:57:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 13:57:14 --> Final output sent to browser
DEBUG - 2018-10-18 13:57:14 --> Total execution time: 0.3645
INFO - 2018-10-18 13:58:28 --> Config Class Initialized
INFO - 2018-10-18 13:58:28 --> Hooks Class Initialized
DEBUG - 2018-10-18 13:58:28 --> UTF-8 Support Enabled
INFO - 2018-10-18 13:58:28 --> Utf8 Class Initialized
INFO - 2018-10-18 13:58:28 --> URI Class Initialized
INFO - 2018-10-18 13:58:28 --> Router Class Initialized
INFO - 2018-10-18 13:58:28 --> Output Class Initialized
INFO - 2018-10-18 13:58:28 --> Security Class Initialized
DEBUG - 2018-10-18 13:58:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 13:58:28 --> CSRF cookie sent
INFO - 2018-10-18 13:58:28 --> CSRF token verified
INFO - 2018-10-18 13:58:28 --> Input Class Initialized
INFO - 2018-10-18 13:58:28 --> Language Class Initialized
INFO - 2018-10-18 13:58:28 --> Loader Class Initialized
INFO - 2018-10-18 13:58:28 --> Helper loaded: url_helper
INFO - 2018-10-18 13:58:28 --> Helper loaded: form_helper
INFO - 2018-10-18 13:58:28 --> Helper loaded: language_helper
DEBUG - 2018-10-18 13:58:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 13:58:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 13:58:28 --> User Agent Class Initialized
INFO - 2018-10-18 13:58:28 --> Controller Class Initialized
INFO - 2018-10-18 13:58:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 13:58:28 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-18 13:58:28 --> Config file loaded: E:\xampp7\htdocs\famiquity\application\config/recaptcha.php
INFO - 2018-10-18 13:58:28 --> Config Class Initialized
INFO - 2018-10-18 13:58:28 --> Hooks Class Initialized
DEBUG - 2018-10-18 13:58:28 --> UTF-8 Support Enabled
INFO - 2018-10-18 13:58:28 --> Utf8 Class Initialized
INFO - 2018-10-18 13:58:28 --> URI Class Initialized
INFO - 2018-10-18 13:58:28 --> Router Class Initialized
INFO - 2018-10-18 13:58:28 --> Output Class Initialized
INFO - 2018-10-18 13:58:28 --> Security Class Initialized
DEBUG - 2018-10-18 13:58:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 13:58:28 --> CSRF cookie sent
INFO - 2018-10-18 13:58:28 --> Input Class Initialized
INFO - 2018-10-18 13:58:28 --> Language Class Initialized
INFO - 2018-10-18 13:58:28 --> Loader Class Initialized
INFO - 2018-10-18 13:58:28 --> Helper loaded: url_helper
INFO - 2018-10-18 13:58:29 --> Helper loaded: form_helper
INFO - 2018-10-18 13:58:29 --> Helper loaded: language_helper
DEBUG - 2018-10-18 13:58:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 13:58:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 13:58:29 --> User Agent Class Initialized
INFO - 2018-10-18 13:58:29 --> Controller Class Initialized
INFO - 2018-10-18 13:58:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 13:58:29 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-18 13:58:29 --> Config file loaded: E:\xampp7\htdocs\famiquity\application\config/recaptcha.php
INFO - 2018-10-18 13:58:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 13:58:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 13:58:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 13:58:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 13:58:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_soft_error.php
ERROR - 2018-10-18 13:58:29 --> Could not find the language line "req_email"
INFO - 2018-10-18 13:58:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\myaccount/signin.php
INFO - 2018-10-18 13:58:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 13:58:29 --> Final output sent to browser
DEBUG - 2018-10-18 13:58:29 --> Total execution time: 0.3544
INFO - 2018-10-18 13:59:17 --> Config Class Initialized
INFO - 2018-10-18 13:59:17 --> Hooks Class Initialized
DEBUG - 2018-10-18 13:59:17 --> UTF-8 Support Enabled
INFO - 2018-10-18 13:59:17 --> Utf8 Class Initialized
INFO - 2018-10-18 13:59:17 --> URI Class Initialized
INFO - 2018-10-18 13:59:17 --> Router Class Initialized
INFO - 2018-10-18 13:59:17 --> Output Class Initialized
INFO - 2018-10-18 13:59:17 --> Security Class Initialized
DEBUG - 2018-10-18 13:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 13:59:17 --> CSRF cookie sent
INFO - 2018-10-18 13:59:17 --> Input Class Initialized
INFO - 2018-10-18 13:59:17 --> Language Class Initialized
INFO - 2018-10-18 13:59:17 --> Loader Class Initialized
INFO - 2018-10-18 13:59:17 --> Helper loaded: url_helper
INFO - 2018-10-18 13:59:17 --> Helper loaded: form_helper
INFO - 2018-10-18 13:59:17 --> Helper loaded: language_helper
DEBUG - 2018-10-18 13:59:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 13:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 13:59:17 --> User Agent Class Initialized
INFO - 2018-10-18 13:59:17 --> Controller Class Initialized
INFO - 2018-10-18 13:59:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 13:59:17 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-18 13:59:17 --> Config file loaded: E:\xampp7\htdocs\famiquity\application\config/recaptcha.php
INFO - 2018-10-18 13:59:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 13:59:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 13:59:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 13:59:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
ERROR - 2018-10-18 13:59:17 --> Could not find the language line "req_email"
INFO - 2018-10-18 13:59:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\myaccount/signin.php
INFO - 2018-10-18 13:59:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 13:59:17 --> Final output sent to browser
DEBUG - 2018-10-18 13:59:17 --> Total execution time: 0.3572
INFO - 2018-10-18 13:59:26 --> Config Class Initialized
INFO - 2018-10-18 13:59:26 --> Hooks Class Initialized
DEBUG - 2018-10-18 13:59:26 --> UTF-8 Support Enabled
INFO - 2018-10-18 13:59:26 --> Utf8 Class Initialized
INFO - 2018-10-18 13:59:26 --> URI Class Initialized
INFO - 2018-10-18 13:59:26 --> Router Class Initialized
INFO - 2018-10-18 13:59:26 --> Output Class Initialized
INFO - 2018-10-18 13:59:26 --> Security Class Initialized
DEBUG - 2018-10-18 13:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 13:59:26 --> CSRF cookie sent
INFO - 2018-10-18 13:59:26 --> CSRF token verified
INFO - 2018-10-18 13:59:26 --> Input Class Initialized
INFO - 2018-10-18 13:59:26 --> Language Class Initialized
INFO - 2018-10-18 13:59:26 --> Loader Class Initialized
INFO - 2018-10-18 13:59:26 --> Helper loaded: url_helper
INFO - 2018-10-18 13:59:26 --> Helper loaded: form_helper
INFO - 2018-10-18 13:59:26 --> Helper loaded: language_helper
DEBUG - 2018-10-18 13:59:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 13:59:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 13:59:26 --> User Agent Class Initialized
INFO - 2018-10-18 13:59:26 --> Controller Class Initialized
INFO - 2018-10-18 13:59:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 13:59:26 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-18 13:59:26 --> Config file loaded: E:\xampp7\htdocs\famiquity\application\config/recaptcha.php
INFO - 2018-10-18 13:59:26 --> Config Class Initialized
INFO - 2018-10-18 13:59:26 --> Hooks Class Initialized
DEBUG - 2018-10-18 13:59:26 --> UTF-8 Support Enabled
INFO - 2018-10-18 13:59:26 --> Utf8 Class Initialized
INFO - 2018-10-18 13:59:26 --> URI Class Initialized
INFO - 2018-10-18 13:59:26 --> Router Class Initialized
INFO - 2018-10-18 13:59:26 --> Output Class Initialized
INFO - 2018-10-18 13:59:26 --> Security Class Initialized
DEBUG - 2018-10-18 13:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 13:59:26 --> CSRF cookie sent
INFO - 2018-10-18 13:59:26 --> Input Class Initialized
INFO - 2018-10-18 13:59:26 --> Language Class Initialized
INFO - 2018-10-18 13:59:26 --> Loader Class Initialized
INFO - 2018-10-18 13:59:26 --> Helper loaded: url_helper
INFO - 2018-10-18 13:59:26 --> Helper loaded: form_helper
INFO - 2018-10-18 13:59:26 --> Helper loaded: language_helper
DEBUG - 2018-10-18 13:59:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 13:59:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 13:59:27 --> User Agent Class Initialized
INFO - 2018-10-18 13:59:27 --> Controller Class Initialized
INFO - 2018-10-18 13:59:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 13:59:27 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-18 13:59:27 --> Config file loaded: E:\xampp7\htdocs\famiquity\application\config/recaptcha.php
INFO - 2018-10-18 13:59:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 13:59:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 13:59:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 13:59:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 13:59:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_soft_error.php
ERROR - 2018-10-18 13:59:27 --> Could not find the language line "req_email"
INFO - 2018-10-18 13:59:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\myaccount/signin.php
INFO - 2018-10-18 13:59:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 13:59:27 --> Final output sent to browser
DEBUG - 2018-10-18 13:59:27 --> Total execution time: 0.3647
INFO - 2018-10-18 13:59:55 --> Config Class Initialized
INFO - 2018-10-18 13:59:55 --> Hooks Class Initialized
DEBUG - 2018-10-18 13:59:55 --> UTF-8 Support Enabled
INFO - 2018-10-18 13:59:55 --> Utf8 Class Initialized
INFO - 2018-10-18 13:59:55 --> URI Class Initialized
INFO - 2018-10-18 13:59:55 --> Router Class Initialized
INFO - 2018-10-18 13:59:55 --> Output Class Initialized
INFO - 2018-10-18 13:59:55 --> Security Class Initialized
DEBUG - 2018-10-18 13:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 13:59:55 --> CSRF cookie sent
INFO - 2018-10-18 13:59:55 --> CSRF token verified
INFO - 2018-10-18 13:59:55 --> Input Class Initialized
INFO - 2018-10-18 13:59:55 --> Language Class Initialized
INFO - 2018-10-18 13:59:55 --> Loader Class Initialized
INFO - 2018-10-18 13:59:55 --> Helper loaded: url_helper
INFO - 2018-10-18 13:59:55 --> Helper loaded: form_helper
INFO - 2018-10-18 13:59:55 --> Helper loaded: language_helper
DEBUG - 2018-10-18 13:59:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 13:59:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 13:59:55 --> User Agent Class Initialized
INFO - 2018-10-18 13:59:55 --> Controller Class Initialized
INFO - 2018-10-18 13:59:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 13:59:55 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-18 13:59:55 --> Config file loaded: E:\xampp7\htdocs\famiquity\application\config/recaptcha.php
INFO - 2018-10-18 13:59:55 --> Config Class Initialized
INFO - 2018-10-18 13:59:55 --> Hooks Class Initialized
DEBUG - 2018-10-18 13:59:55 --> UTF-8 Support Enabled
INFO - 2018-10-18 13:59:55 --> Utf8 Class Initialized
INFO - 2018-10-18 13:59:55 --> URI Class Initialized
INFO - 2018-10-18 13:59:55 --> Router Class Initialized
INFO - 2018-10-18 13:59:55 --> Output Class Initialized
INFO - 2018-10-18 13:59:55 --> Security Class Initialized
DEBUG - 2018-10-18 13:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 13:59:55 --> CSRF cookie sent
INFO - 2018-10-18 13:59:55 --> Input Class Initialized
INFO - 2018-10-18 13:59:55 --> Language Class Initialized
INFO - 2018-10-18 13:59:55 --> Loader Class Initialized
INFO - 2018-10-18 13:59:55 --> Helper loaded: url_helper
INFO - 2018-10-18 13:59:55 --> Helper loaded: form_helper
INFO - 2018-10-18 13:59:55 --> Helper loaded: language_helper
DEBUG - 2018-10-18 13:59:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 13:59:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 13:59:55 --> User Agent Class Initialized
INFO - 2018-10-18 13:59:56 --> Controller Class Initialized
INFO - 2018-10-18 13:59:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 13:59:56 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-18 13:59:56 --> Config file loaded: E:\xampp7\htdocs\famiquity\application\config/recaptcha.php
INFO - 2018-10-18 13:59:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 13:59:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 13:59:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 13:59:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 13:59:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_soft_error.php
ERROR - 2018-10-18 13:59:56 --> Could not find the language line "req_email"
INFO - 2018-10-18 13:59:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\myaccount/signin.php
INFO - 2018-10-18 13:59:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 13:59:56 --> Final output sent to browser
DEBUG - 2018-10-18 13:59:56 --> Total execution time: 0.3639
INFO - 2018-10-18 14:00:40 --> Config Class Initialized
INFO - 2018-10-18 14:00:40 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:00:40 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:00:40 --> Utf8 Class Initialized
INFO - 2018-10-18 14:00:40 --> URI Class Initialized
INFO - 2018-10-18 14:00:40 --> Router Class Initialized
INFO - 2018-10-18 14:00:40 --> Output Class Initialized
INFO - 2018-10-18 14:00:40 --> Security Class Initialized
DEBUG - 2018-10-18 14:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:00:40 --> CSRF cookie sent
INFO - 2018-10-18 14:00:40 --> Input Class Initialized
INFO - 2018-10-18 14:00:40 --> Language Class Initialized
INFO - 2018-10-18 14:00:40 --> Loader Class Initialized
INFO - 2018-10-18 14:00:40 --> Helper loaded: url_helper
INFO - 2018-10-18 14:00:40 --> Helper loaded: form_helper
INFO - 2018-10-18 14:00:40 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:00:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:00:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:00:40 --> User Agent Class Initialized
INFO - 2018-10-18 14:00:40 --> Controller Class Initialized
INFO - 2018-10-18 14:00:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:00:40 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-18 14:00:40 --> Config file loaded: E:\xampp7\htdocs\famiquity\application\config/recaptcha.php
INFO - 2018-10-18 14:00:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:00:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:00:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:00:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
ERROR - 2018-10-18 14:00:41 --> Could not find the language line "req_email"
INFO - 2018-10-18 14:00:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\myaccount/signin.php
INFO - 2018-10-18 14:00:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:00:41 --> Final output sent to browser
DEBUG - 2018-10-18 14:00:41 --> Total execution time: 0.3933
INFO - 2018-10-18 14:00:48 --> Config Class Initialized
INFO - 2018-10-18 14:00:48 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:00:48 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:00:48 --> Utf8 Class Initialized
INFO - 2018-10-18 14:00:48 --> URI Class Initialized
INFO - 2018-10-18 14:00:48 --> Router Class Initialized
INFO - 2018-10-18 14:00:48 --> Output Class Initialized
INFO - 2018-10-18 14:00:48 --> Security Class Initialized
DEBUG - 2018-10-18 14:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:00:48 --> CSRF cookie sent
INFO - 2018-10-18 14:00:48 --> CSRF token verified
INFO - 2018-10-18 14:00:48 --> Input Class Initialized
INFO - 2018-10-18 14:00:48 --> Language Class Initialized
INFO - 2018-10-18 14:00:48 --> Loader Class Initialized
INFO - 2018-10-18 14:00:48 --> Helper loaded: url_helper
INFO - 2018-10-18 14:00:48 --> Helper loaded: form_helper
INFO - 2018-10-18 14:00:48 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:00:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:00:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:00:48 --> User Agent Class Initialized
INFO - 2018-10-18 14:00:48 --> Controller Class Initialized
INFO - 2018-10-18 14:00:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:00:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:00:48 --> Form Validation Class Initialized
INFO - 2018-10-18 14:00:48 --> Pixel_Model class loaded
INFO - 2018-10-18 14:00:48 --> Database Driver Class Initialized
INFO - 2018-10-18 14:00:48 --> Model "AuthenticationModel" initialized
INFO - 2018-10-18 14:00:48 --> Config Class Initialized
INFO - 2018-10-18 14:00:48 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:00:48 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:00:48 --> Utf8 Class Initialized
INFO - 2018-10-18 14:00:48 --> URI Class Initialized
DEBUG - 2018-10-18 14:00:48 --> No URI present. Default controller set.
INFO - 2018-10-18 14:00:48 --> Router Class Initialized
INFO - 2018-10-18 14:00:48 --> Output Class Initialized
INFO - 2018-10-18 14:00:48 --> Security Class Initialized
DEBUG - 2018-10-18 14:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:00:48 --> CSRF cookie sent
INFO - 2018-10-18 14:00:48 --> Input Class Initialized
INFO - 2018-10-18 14:00:48 --> Language Class Initialized
INFO - 2018-10-18 14:00:48 --> Loader Class Initialized
INFO - 2018-10-18 14:00:48 --> Helper loaded: url_helper
INFO - 2018-10-18 14:00:48 --> Helper loaded: form_helper
INFO - 2018-10-18 14:00:48 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:00:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:00:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:00:48 --> User Agent Class Initialized
INFO - 2018-10-18 14:00:48 --> Controller Class Initialized
INFO - 2018-10-18 14:00:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:00:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:00:48 --> Pixel_Model class loaded
INFO - 2018-10-18 14:00:48 --> Database Driver Class Initialized
INFO - 2018-10-18 14:00:48 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:00:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:00:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:00:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-18 14:00:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:00:49 --> Final output sent to browser
DEBUG - 2018-10-18 14:00:49 --> Total execution time: 0.3821
INFO - 2018-10-18 14:00:51 --> Config Class Initialized
INFO - 2018-10-18 14:00:51 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:00:51 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:00:51 --> Utf8 Class Initialized
INFO - 2018-10-18 14:00:51 --> URI Class Initialized
INFO - 2018-10-18 14:00:51 --> Router Class Initialized
INFO - 2018-10-18 14:00:51 --> Output Class Initialized
INFO - 2018-10-18 14:00:51 --> Security Class Initialized
DEBUG - 2018-10-18 14:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:00:51 --> CSRF cookie sent
INFO - 2018-10-18 14:00:51 --> Input Class Initialized
INFO - 2018-10-18 14:00:51 --> Language Class Initialized
INFO - 2018-10-18 14:00:51 --> Loader Class Initialized
INFO - 2018-10-18 14:00:51 --> Helper loaded: url_helper
INFO - 2018-10-18 14:00:51 --> Helper loaded: form_helper
INFO - 2018-10-18 14:00:51 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:00:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:00:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:00:51 --> User Agent Class Initialized
INFO - 2018-10-18 14:00:51 --> Controller Class Initialized
INFO - 2018-10-18 14:00:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:00:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:00:51 --> Pixel_Model class loaded
INFO - 2018-10-18 14:00:51 --> Database Driver Class Initialized
INFO - 2018-10-18 14:00:51 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:00:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:00:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:00:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:00:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:00:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:00:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:00:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-18 14:00:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:00:51 --> Final output sent to browser
DEBUG - 2018-10-18 14:00:51 --> Total execution time: 0.5175
INFO - 2018-10-18 14:01:14 --> Config Class Initialized
INFO - 2018-10-18 14:01:14 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:01:14 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:01:14 --> Utf8 Class Initialized
INFO - 2018-10-18 14:01:14 --> URI Class Initialized
INFO - 2018-10-18 14:01:14 --> Router Class Initialized
INFO - 2018-10-18 14:01:14 --> Output Class Initialized
INFO - 2018-10-18 14:01:14 --> Security Class Initialized
DEBUG - 2018-10-18 14:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:01:14 --> CSRF cookie sent
INFO - 2018-10-18 14:01:14 --> Input Class Initialized
INFO - 2018-10-18 14:01:14 --> Language Class Initialized
INFO - 2018-10-18 14:01:14 --> Loader Class Initialized
INFO - 2018-10-18 14:01:14 --> Helper loaded: url_helper
INFO - 2018-10-18 14:01:14 --> Helper loaded: form_helper
INFO - 2018-10-18 14:01:14 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:01:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:01:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:01:14 --> User Agent Class Initialized
INFO - 2018-10-18 14:01:14 --> Controller Class Initialized
INFO - 2018-10-18 14:01:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:01:14 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-18 14:01:14 --> Config file loaded: E:\xampp7\htdocs\famiquity\application\config/recaptcha.php
INFO - 2018-10-18 14:01:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:01:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:01:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:01:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
ERROR - 2018-10-18 14:01:14 --> Could not find the language line "req_email"
INFO - 2018-10-18 14:01:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\myaccount/signin.php
INFO - 2018-10-18 14:01:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:01:14 --> Final output sent to browser
DEBUG - 2018-10-18 14:01:14 --> Total execution time: 0.3596
INFO - 2018-10-18 14:01:25 --> Config Class Initialized
INFO - 2018-10-18 14:01:25 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:01:25 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:01:25 --> Utf8 Class Initialized
INFO - 2018-10-18 14:01:25 --> URI Class Initialized
INFO - 2018-10-18 14:01:25 --> Router Class Initialized
INFO - 2018-10-18 14:01:25 --> Output Class Initialized
INFO - 2018-10-18 14:01:25 --> Security Class Initialized
DEBUG - 2018-10-18 14:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:01:25 --> CSRF cookie sent
INFO - 2018-10-18 14:01:25 --> CSRF token verified
INFO - 2018-10-18 14:01:25 --> Input Class Initialized
INFO - 2018-10-18 14:01:25 --> Language Class Initialized
INFO - 2018-10-18 14:01:25 --> Loader Class Initialized
INFO - 2018-10-18 14:01:25 --> Helper loaded: url_helper
INFO - 2018-10-18 14:01:25 --> Helper loaded: form_helper
INFO - 2018-10-18 14:01:25 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:01:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:01:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:01:25 --> User Agent Class Initialized
INFO - 2018-10-18 14:01:25 --> Controller Class Initialized
INFO - 2018-10-18 14:01:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:01:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:01:25 --> Form Validation Class Initialized
INFO - 2018-10-18 14:01:25 --> Config Class Initialized
INFO - 2018-10-18 14:01:25 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:01:25 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:01:25 --> Utf8 Class Initialized
INFO - 2018-10-18 14:01:25 --> URI Class Initialized
INFO - 2018-10-18 14:01:25 --> Router Class Initialized
INFO - 2018-10-18 14:01:25 --> Output Class Initialized
INFO - 2018-10-18 14:01:25 --> Security Class Initialized
DEBUG - 2018-10-18 14:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:01:25 --> CSRF cookie sent
INFO - 2018-10-18 14:01:25 --> Input Class Initialized
INFO - 2018-10-18 14:01:25 --> Language Class Initialized
INFO - 2018-10-18 14:01:25 --> Loader Class Initialized
INFO - 2018-10-18 14:01:25 --> Helper loaded: url_helper
INFO - 2018-10-18 14:01:25 --> Helper loaded: form_helper
INFO - 2018-10-18 14:01:25 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:01:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:01:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:01:25 --> User Agent Class Initialized
INFO - 2018-10-18 14:01:25 --> Controller Class Initialized
INFO - 2018-10-18 14:01:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:01:25 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-18 14:01:25 --> Config file loaded: E:\xampp7\htdocs\famiquity\application\config/recaptcha.php
INFO - 2018-10-18 14:01:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:01:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:01:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:01:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
ERROR - 2018-10-18 14:01:25 --> Could not find the language line "req_email"
INFO - 2018-10-18 14:01:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\myaccount/signin.php
INFO - 2018-10-18 14:01:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:01:25 --> Final output sent to browser
DEBUG - 2018-10-18 14:01:25 --> Total execution time: 0.3522
INFO - 2018-10-18 14:01:28 --> Config Class Initialized
INFO - 2018-10-18 14:01:28 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:01:28 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:01:28 --> Utf8 Class Initialized
INFO - 2018-10-18 14:01:28 --> URI Class Initialized
INFO - 2018-10-18 14:01:28 --> Router Class Initialized
INFO - 2018-10-18 14:01:28 --> Output Class Initialized
INFO - 2018-10-18 14:01:28 --> Security Class Initialized
DEBUG - 2018-10-18 14:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:01:28 --> CSRF cookie sent
INFO - 2018-10-18 14:01:28 --> Input Class Initialized
INFO - 2018-10-18 14:01:29 --> Language Class Initialized
INFO - 2018-10-18 14:01:29 --> Loader Class Initialized
INFO - 2018-10-18 14:01:29 --> Helper loaded: url_helper
INFO - 2018-10-18 14:01:29 --> Helper loaded: form_helper
INFO - 2018-10-18 14:01:29 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:01:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:01:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:01:29 --> User Agent Class Initialized
INFO - 2018-10-18 14:01:29 --> Controller Class Initialized
INFO - 2018-10-18 14:01:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:01:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:01:29 --> Pixel_Model class loaded
INFO - 2018-10-18 14:01:29 --> Database Driver Class Initialized
INFO - 2018-10-18 14:01:29 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:01:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:01:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:01:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:01:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:01:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:01:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:01:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-18 14:01:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:01:29 --> Final output sent to browser
DEBUG - 2018-10-18 14:01:29 --> Total execution time: 0.4277
INFO - 2018-10-18 14:01:32 --> Config Class Initialized
INFO - 2018-10-18 14:01:32 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:01:32 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:01:32 --> Utf8 Class Initialized
INFO - 2018-10-18 14:01:32 --> URI Class Initialized
INFO - 2018-10-18 14:01:32 --> Router Class Initialized
INFO - 2018-10-18 14:01:32 --> Output Class Initialized
INFO - 2018-10-18 14:01:32 --> Security Class Initialized
DEBUG - 2018-10-18 14:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:01:32 --> CSRF cookie sent
INFO - 2018-10-18 14:01:32 --> CSRF token verified
INFO - 2018-10-18 14:01:32 --> Input Class Initialized
INFO - 2018-10-18 14:01:32 --> Language Class Initialized
INFO - 2018-10-18 14:01:32 --> Loader Class Initialized
INFO - 2018-10-18 14:01:32 --> Helper loaded: url_helper
INFO - 2018-10-18 14:01:32 --> Helper loaded: form_helper
INFO - 2018-10-18 14:01:32 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:01:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:01:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:01:32 --> User Agent Class Initialized
INFO - 2018-10-18 14:01:32 --> Controller Class Initialized
INFO - 2018-10-18 14:01:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:01:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:01:32 --> Pixel_Model class loaded
INFO - 2018-10-18 14:01:32 --> Database Driver Class Initialized
INFO - 2018-10-18 14:01:32 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:01:32 --> Form Validation Class Initialized
INFO - 2018-10-18 14:01:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 14:01:32 --> Database Driver Class Initialized
INFO - 2018-10-18 14:01:32 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:01:32 --> Config Class Initialized
INFO - 2018-10-18 14:01:32 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:01:32 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:01:32 --> Utf8 Class Initialized
INFO - 2018-10-18 14:01:32 --> URI Class Initialized
INFO - 2018-10-18 14:01:32 --> Router Class Initialized
INFO - 2018-10-18 14:01:32 --> Output Class Initialized
INFO - 2018-10-18 14:01:32 --> Security Class Initialized
DEBUG - 2018-10-18 14:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:01:32 --> CSRF cookie sent
INFO - 2018-10-18 14:01:32 --> Input Class Initialized
INFO - 2018-10-18 14:01:32 --> Language Class Initialized
INFO - 2018-10-18 14:01:32 --> Loader Class Initialized
INFO - 2018-10-18 14:01:32 --> Helper loaded: url_helper
INFO - 2018-10-18 14:01:32 --> Helper loaded: form_helper
INFO - 2018-10-18 14:01:32 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:01:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:01:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:01:32 --> User Agent Class Initialized
INFO - 2018-10-18 14:01:32 --> Controller Class Initialized
INFO - 2018-10-18 14:01:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:01:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:01:33 --> Pixel_Model class loaded
INFO - 2018-10-18 14:01:33 --> Database Driver Class Initialized
INFO - 2018-10-18 14:01:33 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:01:33 --> Database Driver Class Initialized
INFO - 2018-10-18 14:01:33 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:01:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:01:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:01:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:01:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:01:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:01:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:01:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-18 14:01:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:01:33 --> Final output sent to browser
DEBUG - 2018-10-18 14:01:33 --> Total execution time: 0.4285
INFO - 2018-10-18 14:01:36 --> Config Class Initialized
INFO - 2018-10-18 14:01:36 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:01:36 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:01:36 --> Utf8 Class Initialized
INFO - 2018-10-18 14:01:36 --> URI Class Initialized
INFO - 2018-10-18 14:01:36 --> Router Class Initialized
INFO - 2018-10-18 14:01:36 --> Output Class Initialized
INFO - 2018-10-18 14:01:36 --> Security Class Initialized
DEBUG - 2018-10-18 14:01:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:01:36 --> CSRF cookie sent
INFO - 2018-10-18 14:01:36 --> CSRF token verified
INFO - 2018-10-18 14:01:36 --> Input Class Initialized
INFO - 2018-10-18 14:01:36 --> Language Class Initialized
INFO - 2018-10-18 14:01:36 --> Loader Class Initialized
INFO - 2018-10-18 14:01:36 --> Helper loaded: url_helper
INFO - 2018-10-18 14:01:36 --> Helper loaded: form_helper
INFO - 2018-10-18 14:01:36 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:01:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:01:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:01:36 --> User Agent Class Initialized
INFO - 2018-10-18 14:01:36 --> Controller Class Initialized
INFO - 2018-10-18 14:01:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:01:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:01:36 --> Pixel_Model class loaded
INFO - 2018-10-18 14:01:36 --> Database Driver Class Initialized
INFO - 2018-10-18 14:01:36 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:01:36 --> Form Validation Class Initialized
INFO - 2018-10-18 14:01:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 14:01:36 --> Database Driver Class Initialized
INFO - 2018-10-18 14:01:36 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:01:36 --> Config Class Initialized
INFO - 2018-10-18 14:01:36 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:01:36 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:01:36 --> Utf8 Class Initialized
INFO - 2018-10-18 14:01:36 --> URI Class Initialized
INFO - 2018-10-18 14:01:36 --> Router Class Initialized
INFO - 2018-10-18 14:01:36 --> Output Class Initialized
INFO - 2018-10-18 14:01:36 --> Security Class Initialized
DEBUG - 2018-10-18 14:01:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:01:36 --> CSRF cookie sent
INFO - 2018-10-18 14:01:36 --> Input Class Initialized
INFO - 2018-10-18 14:01:36 --> Language Class Initialized
INFO - 2018-10-18 14:01:36 --> Loader Class Initialized
INFO - 2018-10-18 14:01:36 --> Helper loaded: url_helper
INFO - 2018-10-18 14:01:36 --> Helper loaded: form_helper
INFO - 2018-10-18 14:01:37 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:01:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:01:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:01:37 --> User Agent Class Initialized
INFO - 2018-10-18 14:01:37 --> Controller Class Initialized
INFO - 2018-10-18 14:01:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:01:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:01:37 --> Pixel_Model class loaded
INFO - 2018-10-18 14:01:37 --> Database Driver Class Initialized
INFO - 2018-10-18 14:01:37 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:01:37 --> Database Driver Class Initialized
INFO - 2018-10-18 14:01:37 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:01:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:01:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:01:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:01:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:01:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:01:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:01:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/your_job.php
INFO - 2018-10-18 14:01:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:01:37 --> Final output sent to browser
DEBUG - 2018-10-18 14:01:37 --> Total execution time: 0.4851
INFO - 2018-10-18 14:01:41 --> Config Class Initialized
INFO - 2018-10-18 14:01:41 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:01:41 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:01:41 --> Utf8 Class Initialized
INFO - 2018-10-18 14:01:41 --> URI Class Initialized
INFO - 2018-10-18 14:01:41 --> Router Class Initialized
INFO - 2018-10-18 14:01:41 --> Output Class Initialized
INFO - 2018-10-18 14:01:41 --> Security Class Initialized
DEBUG - 2018-10-18 14:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:01:41 --> CSRF cookie sent
INFO - 2018-10-18 14:01:41 --> CSRF token verified
INFO - 2018-10-18 14:01:41 --> Input Class Initialized
INFO - 2018-10-18 14:01:41 --> Language Class Initialized
INFO - 2018-10-18 14:01:41 --> Loader Class Initialized
INFO - 2018-10-18 14:01:41 --> Helper loaded: url_helper
INFO - 2018-10-18 14:01:41 --> Helper loaded: form_helper
INFO - 2018-10-18 14:01:41 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:01:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:01:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:01:41 --> User Agent Class Initialized
INFO - 2018-10-18 14:01:41 --> Controller Class Initialized
INFO - 2018-10-18 14:01:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:01:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:01:41 --> Pixel_Model class loaded
INFO - 2018-10-18 14:01:41 --> Database Driver Class Initialized
INFO - 2018-10-18 14:01:41 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:01:41 --> Form Validation Class Initialized
INFO - 2018-10-18 14:01:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 14:01:41 --> Database Driver Class Initialized
INFO - 2018-10-18 14:01:41 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:01:41 --> Config Class Initialized
INFO - 2018-10-18 14:01:41 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:01:41 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:01:41 --> Utf8 Class Initialized
INFO - 2018-10-18 14:01:41 --> URI Class Initialized
INFO - 2018-10-18 14:01:41 --> Router Class Initialized
INFO - 2018-10-18 14:01:41 --> Output Class Initialized
INFO - 2018-10-18 14:01:41 --> Security Class Initialized
DEBUG - 2018-10-18 14:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:01:41 --> CSRF cookie sent
INFO - 2018-10-18 14:01:41 --> Input Class Initialized
INFO - 2018-10-18 14:01:41 --> Language Class Initialized
INFO - 2018-10-18 14:01:41 --> Loader Class Initialized
INFO - 2018-10-18 14:01:41 --> Helper loaded: url_helper
INFO - 2018-10-18 14:01:41 --> Helper loaded: form_helper
INFO - 2018-10-18 14:01:41 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:01:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:01:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:01:41 --> User Agent Class Initialized
INFO - 2018-10-18 14:01:41 --> Controller Class Initialized
INFO - 2018-10-18 14:01:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:01:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:01:41 --> Pixel_Model class loaded
INFO - 2018-10-18 14:01:41 --> Database Driver Class Initialized
INFO - 2018-10-18 14:01:41 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:01:41 --> Database Driver Class Initialized
INFO - 2018-10-18 14:01:41 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:01:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:01:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:01:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner.php
INFO - 2018-10-18 14:01:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:01:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:01:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:01:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:01:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/relation_ship_status.php
INFO - 2018-10-18 14:01:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:01:42 --> Final output sent to browser
DEBUG - 2018-10-18 14:01:42 --> Total execution time: 0.4574
INFO - 2018-10-18 14:01:43 --> Config Class Initialized
INFO - 2018-10-18 14:01:43 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:01:43 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:01:43 --> Utf8 Class Initialized
INFO - 2018-10-18 14:01:43 --> URI Class Initialized
INFO - 2018-10-18 14:01:43 --> Router Class Initialized
INFO - 2018-10-18 14:01:43 --> Output Class Initialized
INFO - 2018-10-18 14:01:43 --> Security Class Initialized
DEBUG - 2018-10-18 14:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:01:43 --> CSRF cookie sent
INFO - 2018-10-18 14:01:43 --> CSRF token verified
INFO - 2018-10-18 14:01:43 --> Input Class Initialized
INFO - 2018-10-18 14:01:43 --> Language Class Initialized
INFO - 2018-10-18 14:01:43 --> Loader Class Initialized
INFO - 2018-10-18 14:01:43 --> Helper loaded: url_helper
INFO - 2018-10-18 14:01:43 --> Helper loaded: form_helper
INFO - 2018-10-18 14:01:43 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:01:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:01:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:01:43 --> User Agent Class Initialized
INFO - 2018-10-18 14:01:43 --> Controller Class Initialized
INFO - 2018-10-18 14:01:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:01:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:01:43 --> Pixel_Model class loaded
INFO - 2018-10-18 14:01:43 --> Database Driver Class Initialized
INFO - 2018-10-18 14:01:43 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:01:43 --> Form Validation Class Initialized
INFO - 2018-10-18 14:01:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 14:01:43 --> Database Driver Class Initialized
INFO - 2018-10-18 14:01:43 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:01:43 --> Config Class Initialized
INFO - 2018-10-18 14:01:43 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:01:43 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:01:43 --> Utf8 Class Initialized
INFO - 2018-10-18 14:01:43 --> URI Class Initialized
INFO - 2018-10-18 14:01:43 --> Router Class Initialized
INFO - 2018-10-18 14:01:43 --> Output Class Initialized
INFO - 2018-10-18 14:01:43 --> Security Class Initialized
DEBUG - 2018-10-18 14:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:01:43 --> CSRF cookie sent
INFO - 2018-10-18 14:01:43 --> Input Class Initialized
INFO - 2018-10-18 14:01:43 --> Language Class Initialized
INFO - 2018-10-18 14:01:43 --> Loader Class Initialized
INFO - 2018-10-18 14:01:43 --> Helper loaded: url_helper
INFO - 2018-10-18 14:01:43 --> Helper loaded: form_helper
INFO - 2018-10-18 14:01:43 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:01:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:01:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:01:43 --> User Agent Class Initialized
INFO - 2018-10-18 14:01:43 --> Controller Class Initialized
INFO - 2018-10-18 14:01:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:01:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:01:43 --> Pixel_Model class loaded
INFO - 2018-10-18 14:01:43 --> Database Driver Class Initialized
INFO - 2018-10-18 14:01:43 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:01:43 --> Database Driver Class Initialized
INFO - 2018-10-18 14:01:43 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:01:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:01:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:01:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:01:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:01:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:01:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:01:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/income.php
INFO - 2018-10-18 14:01:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:01:44 --> Final output sent to browser
DEBUG - 2018-10-18 14:01:44 --> Total execution time: 0.4431
INFO - 2018-10-18 14:01:45 --> Config Class Initialized
INFO - 2018-10-18 14:01:45 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:01:45 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:01:45 --> Utf8 Class Initialized
INFO - 2018-10-18 14:01:45 --> URI Class Initialized
INFO - 2018-10-18 14:01:45 --> Router Class Initialized
INFO - 2018-10-18 14:01:45 --> Output Class Initialized
INFO - 2018-10-18 14:01:45 --> Security Class Initialized
DEBUG - 2018-10-18 14:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:01:45 --> CSRF cookie sent
INFO - 2018-10-18 14:01:45 --> CSRF token verified
INFO - 2018-10-18 14:01:45 --> Input Class Initialized
INFO - 2018-10-18 14:01:45 --> Language Class Initialized
INFO - 2018-10-18 14:01:45 --> Loader Class Initialized
INFO - 2018-10-18 14:01:45 --> Helper loaded: url_helper
INFO - 2018-10-18 14:01:45 --> Helper loaded: form_helper
INFO - 2018-10-18 14:01:45 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:01:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:01:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:01:45 --> User Agent Class Initialized
INFO - 2018-10-18 14:01:45 --> Controller Class Initialized
INFO - 2018-10-18 14:01:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:01:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:01:45 --> Pixel_Model class loaded
INFO - 2018-10-18 14:01:45 --> Database Driver Class Initialized
INFO - 2018-10-18 14:01:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:01:45 --> Form Validation Class Initialized
INFO - 2018-10-18 14:01:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 14:01:45 --> Database Driver Class Initialized
INFO - 2018-10-18 14:01:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:01:45 --> Config Class Initialized
INFO - 2018-10-18 14:01:45 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:01:45 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:01:45 --> Utf8 Class Initialized
INFO - 2018-10-18 14:01:45 --> URI Class Initialized
INFO - 2018-10-18 14:01:45 --> Router Class Initialized
INFO - 2018-10-18 14:01:45 --> Output Class Initialized
INFO - 2018-10-18 14:01:45 --> Security Class Initialized
DEBUG - 2018-10-18 14:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:01:45 --> CSRF cookie sent
INFO - 2018-10-18 14:01:45 --> Input Class Initialized
INFO - 2018-10-18 14:01:46 --> Language Class Initialized
INFO - 2018-10-18 14:01:46 --> Loader Class Initialized
INFO - 2018-10-18 14:01:46 --> Helper loaded: url_helper
INFO - 2018-10-18 14:01:46 --> Helper loaded: form_helper
INFO - 2018-10-18 14:01:46 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:01:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:01:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:01:46 --> User Agent Class Initialized
INFO - 2018-10-18 14:01:46 --> Controller Class Initialized
INFO - 2018-10-18 14:01:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:01:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:01:46 --> Pixel_Model class loaded
INFO - 2018-10-18 14:01:46 --> Database Driver Class Initialized
INFO - 2018-10-18 14:01:46 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:01:46 --> Database Driver Class Initialized
INFO - 2018-10-18 14:01:46 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:01:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:01:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:01:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:01:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:01:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:01:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:01:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/marriage.php
INFO - 2018-10-18 14:01:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:01:46 --> Final output sent to browser
DEBUG - 2018-10-18 14:01:46 --> Total execution time: 0.4578
INFO - 2018-10-18 14:01:47 --> Config Class Initialized
INFO - 2018-10-18 14:01:47 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:01:47 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:01:47 --> Utf8 Class Initialized
INFO - 2018-10-18 14:01:47 --> URI Class Initialized
INFO - 2018-10-18 14:01:47 --> Router Class Initialized
INFO - 2018-10-18 14:01:47 --> Output Class Initialized
INFO - 2018-10-18 14:01:47 --> Security Class Initialized
DEBUG - 2018-10-18 14:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:01:47 --> CSRF cookie sent
INFO - 2018-10-18 14:01:47 --> CSRF token verified
INFO - 2018-10-18 14:01:47 --> Input Class Initialized
INFO - 2018-10-18 14:01:47 --> Language Class Initialized
INFO - 2018-10-18 14:01:47 --> Loader Class Initialized
INFO - 2018-10-18 14:01:47 --> Helper loaded: url_helper
INFO - 2018-10-18 14:01:47 --> Helper loaded: form_helper
INFO - 2018-10-18 14:01:47 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:01:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:01:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:01:47 --> User Agent Class Initialized
INFO - 2018-10-18 14:01:47 --> Controller Class Initialized
INFO - 2018-10-18 14:01:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:01:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:01:47 --> Pixel_Model class loaded
INFO - 2018-10-18 14:01:47 --> Database Driver Class Initialized
INFO - 2018-10-18 14:01:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:01:47 --> Form Validation Class Initialized
INFO - 2018-10-18 14:01:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 14:01:47 --> Database Driver Class Initialized
INFO - 2018-10-18 14:01:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:01:47 --> Config Class Initialized
INFO - 2018-10-18 14:01:48 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:01:48 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:01:48 --> Utf8 Class Initialized
INFO - 2018-10-18 14:01:48 --> URI Class Initialized
INFO - 2018-10-18 14:01:48 --> Router Class Initialized
INFO - 2018-10-18 14:01:48 --> Output Class Initialized
INFO - 2018-10-18 14:01:48 --> Security Class Initialized
DEBUG - 2018-10-18 14:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:01:48 --> CSRF cookie sent
INFO - 2018-10-18 14:01:48 --> Input Class Initialized
INFO - 2018-10-18 14:01:48 --> Language Class Initialized
INFO - 2018-10-18 14:01:48 --> Loader Class Initialized
INFO - 2018-10-18 14:01:48 --> Helper loaded: url_helper
INFO - 2018-10-18 14:01:48 --> Helper loaded: form_helper
INFO - 2018-10-18 14:01:48 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:01:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:01:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:01:48 --> User Agent Class Initialized
INFO - 2018-10-18 14:01:48 --> Controller Class Initialized
INFO - 2018-10-18 14:01:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:01:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:01:48 --> Pixel_Model class loaded
INFO - 2018-10-18 14:01:48 --> Database Driver Class Initialized
INFO - 2018-10-18 14:01:48 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:01:48 --> Database Driver Class Initialized
INFO - 2018-10-18 14:01:48 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:01:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:01:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:01:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:01:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:01:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:01:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:01:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/kids.php
INFO - 2018-10-18 14:01:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:01:48 --> Final output sent to browser
DEBUG - 2018-10-18 14:01:48 --> Total execution time: 0.4730
INFO - 2018-10-18 14:01:49 --> Config Class Initialized
INFO - 2018-10-18 14:01:49 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:01:49 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:01:49 --> Utf8 Class Initialized
INFO - 2018-10-18 14:01:49 --> URI Class Initialized
INFO - 2018-10-18 14:01:49 --> Router Class Initialized
INFO - 2018-10-18 14:01:49 --> Output Class Initialized
INFO - 2018-10-18 14:01:49 --> Security Class Initialized
DEBUG - 2018-10-18 14:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:01:49 --> CSRF cookie sent
INFO - 2018-10-18 14:01:49 --> CSRF token verified
INFO - 2018-10-18 14:01:49 --> Input Class Initialized
INFO - 2018-10-18 14:01:49 --> Language Class Initialized
INFO - 2018-10-18 14:01:49 --> Loader Class Initialized
INFO - 2018-10-18 14:01:50 --> Helper loaded: url_helper
INFO - 2018-10-18 14:01:50 --> Helper loaded: form_helper
INFO - 2018-10-18 14:01:50 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:01:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:01:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:01:50 --> User Agent Class Initialized
INFO - 2018-10-18 14:01:50 --> Controller Class Initialized
INFO - 2018-10-18 14:01:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:01:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:01:50 --> Pixel_Model class loaded
INFO - 2018-10-18 14:01:50 --> Database Driver Class Initialized
INFO - 2018-10-18 14:01:50 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:01:50 --> Form Validation Class Initialized
INFO - 2018-10-18 14:01:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 14:01:50 --> Database Driver Class Initialized
INFO - 2018-10-18 14:01:50 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:01:50 --> Config Class Initialized
INFO - 2018-10-18 14:01:50 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:01:50 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:01:50 --> Utf8 Class Initialized
INFO - 2018-10-18 14:01:50 --> URI Class Initialized
INFO - 2018-10-18 14:01:50 --> Router Class Initialized
INFO - 2018-10-18 14:01:50 --> Output Class Initialized
INFO - 2018-10-18 14:01:50 --> Security Class Initialized
DEBUG - 2018-10-18 14:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:01:50 --> CSRF cookie sent
INFO - 2018-10-18 14:01:50 --> Input Class Initialized
INFO - 2018-10-18 14:01:50 --> Language Class Initialized
INFO - 2018-10-18 14:01:50 --> Loader Class Initialized
INFO - 2018-10-18 14:01:50 --> Helper loaded: url_helper
INFO - 2018-10-18 14:01:50 --> Helper loaded: form_helper
INFO - 2018-10-18 14:01:50 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:01:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:01:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:01:50 --> User Agent Class Initialized
INFO - 2018-10-18 14:01:50 --> Controller Class Initialized
INFO - 2018-10-18 14:01:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:01:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:01:50 --> Pixel_Model class loaded
INFO - 2018-10-18 14:01:50 --> Database Driver Class Initialized
INFO - 2018-10-18 14:01:50 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:01:50 --> Database Driver Class Initialized
INFO - 2018-10-18 14:01:50 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:01:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:01:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:01:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:01:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:01:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:01:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:01:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/pension.php
INFO - 2018-10-18 14:01:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:01:50 --> Final output sent to browser
DEBUG - 2018-10-18 14:01:50 --> Total execution time: 0.4493
INFO - 2018-10-18 14:01:51 --> Config Class Initialized
INFO - 2018-10-18 14:01:51 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:01:51 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:01:51 --> Utf8 Class Initialized
INFO - 2018-10-18 14:01:51 --> URI Class Initialized
INFO - 2018-10-18 14:01:51 --> Router Class Initialized
INFO - 2018-10-18 14:01:51 --> Output Class Initialized
INFO - 2018-10-18 14:01:51 --> Security Class Initialized
DEBUG - 2018-10-18 14:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:01:52 --> CSRF cookie sent
INFO - 2018-10-18 14:01:52 --> CSRF token verified
INFO - 2018-10-18 14:01:52 --> Input Class Initialized
INFO - 2018-10-18 14:01:52 --> Language Class Initialized
INFO - 2018-10-18 14:01:52 --> Loader Class Initialized
INFO - 2018-10-18 14:01:52 --> Helper loaded: url_helper
INFO - 2018-10-18 14:01:52 --> Helper loaded: form_helper
INFO - 2018-10-18 14:01:52 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:01:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:01:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:01:52 --> User Agent Class Initialized
INFO - 2018-10-18 14:01:52 --> Controller Class Initialized
INFO - 2018-10-18 14:01:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:01:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:01:52 --> Pixel_Model class loaded
INFO - 2018-10-18 14:01:52 --> Database Driver Class Initialized
INFO - 2018-10-18 14:01:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:01:52 --> Form Validation Class Initialized
INFO - 2018-10-18 14:01:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 14:01:52 --> Database Driver Class Initialized
INFO - 2018-10-18 14:01:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:01:52 --> Config Class Initialized
INFO - 2018-10-18 14:01:52 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:01:52 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:01:52 --> Utf8 Class Initialized
INFO - 2018-10-18 14:01:52 --> URI Class Initialized
INFO - 2018-10-18 14:01:52 --> Router Class Initialized
INFO - 2018-10-18 14:01:52 --> Output Class Initialized
INFO - 2018-10-18 14:01:52 --> Security Class Initialized
DEBUG - 2018-10-18 14:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:01:52 --> CSRF cookie sent
INFO - 2018-10-18 14:01:52 --> Input Class Initialized
INFO - 2018-10-18 14:01:52 --> Language Class Initialized
INFO - 2018-10-18 14:01:52 --> Loader Class Initialized
INFO - 2018-10-18 14:01:52 --> Helper loaded: url_helper
INFO - 2018-10-18 14:01:52 --> Helper loaded: form_helper
INFO - 2018-10-18 14:01:52 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:01:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:01:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:01:52 --> User Agent Class Initialized
INFO - 2018-10-18 14:01:52 --> Controller Class Initialized
INFO - 2018-10-18 14:01:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:01:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:01:52 --> Pixel_Model class loaded
INFO - 2018-10-18 14:01:52 --> Database Driver Class Initialized
INFO - 2018-10-18 14:01:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:01:52 --> Database Driver Class Initialized
INFO - 2018-10-18 14:01:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:01:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:01:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:01:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:01:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:01:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:01:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:01:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/inheritance.php
INFO - 2018-10-18 14:01:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:01:52 --> Final output sent to browser
DEBUG - 2018-10-18 14:01:52 --> Total execution time: 0.4679
INFO - 2018-10-18 14:01:53 --> Config Class Initialized
INFO - 2018-10-18 14:01:53 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:01:53 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:01:53 --> Utf8 Class Initialized
INFO - 2018-10-18 14:01:53 --> URI Class Initialized
INFO - 2018-10-18 14:01:53 --> Router Class Initialized
INFO - 2018-10-18 14:01:53 --> Output Class Initialized
INFO - 2018-10-18 14:01:53 --> Security Class Initialized
DEBUG - 2018-10-18 14:01:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:01:54 --> CSRF cookie sent
INFO - 2018-10-18 14:01:54 --> CSRF token verified
INFO - 2018-10-18 14:01:54 --> Input Class Initialized
INFO - 2018-10-18 14:01:54 --> Language Class Initialized
INFO - 2018-10-18 14:01:54 --> Loader Class Initialized
INFO - 2018-10-18 14:01:54 --> Helper loaded: url_helper
INFO - 2018-10-18 14:01:54 --> Helper loaded: form_helper
INFO - 2018-10-18 14:01:54 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:01:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:01:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:01:54 --> User Agent Class Initialized
INFO - 2018-10-18 14:01:54 --> Controller Class Initialized
INFO - 2018-10-18 14:01:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:01:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:01:54 --> Pixel_Model class loaded
INFO - 2018-10-18 14:01:54 --> Database Driver Class Initialized
INFO - 2018-10-18 14:01:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:01:54 --> Form Validation Class Initialized
INFO - 2018-10-18 14:01:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 14:01:54 --> Database Driver Class Initialized
INFO - 2018-10-18 14:01:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:01:54 --> Config Class Initialized
INFO - 2018-10-18 14:01:54 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:01:54 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:01:54 --> Utf8 Class Initialized
INFO - 2018-10-18 14:01:54 --> URI Class Initialized
INFO - 2018-10-18 14:01:54 --> Router Class Initialized
INFO - 2018-10-18 14:01:54 --> Output Class Initialized
INFO - 2018-10-18 14:01:54 --> Security Class Initialized
DEBUG - 2018-10-18 14:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:01:54 --> CSRF cookie sent
INFO - 2018-10-18 14:01:54 --> Input Class Initialized
INFO - 2018-10-18 14:01:54 --> Language Class Initialized
INFO - 2018-10-18 14:01:54 --> Loader Class Initialized
INFO - 2018-10-18 14:01:54 --> Helper loaded: url_helper
INFO - 2018-10-18 14:01:54 --> Helper loaded: form_helper
INFO - 2018-10-18 14:01:54 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:01:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:01:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:01:54 --> User Agent Class Initialized
INFO - 2018-10-18 14:01:54 --> Controller Class Initialized
INFO - 2018-10-18 14:01:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:01:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:01:54 --> Pixel_Model class loaded
INFO - 2018-10-18 14:01:54 --> Database Driver Class Initialized
INFO - 2018-10-18 14:01:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:01:54 --> Database Driver Class Initialized
INFO - 2018-10-18 14:01:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:01:54 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:01:54 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:01:54 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:01:54 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:01:54 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:01:54 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:01:54 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/inheritance_maintained.php
INFO - 2018-10-18 14:01:54 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:01:54 --> Final output sent to browser
DEBUG - 2018-10-18 14:01:54 --> Total execution time: 0.4766
INFO - 2018-10-18 14:01:55 --> Config Class Initialized
INFO - 2018-10-18 14:01:55 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:01:55 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:01:55 --> Utf8 Class Initialized
INFO - 2018-10-18 14:01:55 --> URI Class Initialized
INFO - 2018-10-18 14:01:55 --> Router Class Initialized
INFO - 2018-10-18 14:01:55 --> Output Class Initialized
INFO - 2018-10-18 14:01:55 --> Security Class Initialized
DEBUG - 2018-10-18 14:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:01:55 --> CSRF cookie sent
INFO - 2018-10-18 14:01:55 --> CSRF token verified
INFO - 2018-10-18 14:01:55 --> Input Class Initialized
INFO - 2018-10-18 14:01:55 --> Language Class Initialized
INFO - 2018-10-18 14:01:55 --> Loader Class Initialized
INFO - 2018-10-18 14:01:55 --> Helper loaded: url_helper
INFO - 2018-10-18 14:01:55 --> Helper loaded: form_helper
INFO - 2018-10-18 14:01:55 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:01:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:01:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:01:56 --> User Agent Class Initialized
INFO - 2018-10-18 14:01:56 --> Controller Class Initialized
INFO - 2018-10-18 14:01:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:01:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:01:56 --> Pixel_Model class loaded
INFO - 2018-10-18 14:01:56 --> Database Driver Class Initialized
INFO - 2018-10-18 14:01:56 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:01:56 --> Form Validation Class Initialized
INFO - 2018-10-18 14:01:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 14:01:56 --> Database Driver Class Initialized
INFO - 2018-10-18 14:01:56 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:01:56 --> Config Class Initialized
INFO - 2018-10-18 14:01:56 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:01:56 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:01:56 --> Utf8 Class Initialized
INFO - 2018-10-18 14:01:56 --> URI Class Initialized
INFO - 2018-10-18 14:01:56 --> Router Class Initialized
INFO - 2018-10-18 14:01:56 --> Output Class Initialized
INFO - 2018-10-18 14:01:56 --> Security Class Initialized
DEBUG - 2018-10-18 14:01:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:01:56 --> CSRF cookie sent
INFO - 2018-10-18 14:01:56 --> Input Class Initialized
INFO - 2018-10-18 14:01:56 --> Language Class Initialized
INFO - 2018-10-18 14:01:56 --> Loader Class Initialized
INFO - 2018-10-18 14:01:56 --> Helper loaded: url_helper
INFO - 2018-10-18 14:01:56 --> Helper loaded: form_helper
INFO - 2018-10-18 14:01:56 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:01:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:01:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:01:56 --> User Agent Class Initialized
INFO - 2018-10-18 14:01:56 --> Controller Class Initialized
INFO - 2018-10-18 14:01:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:01:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:01:56 --> Pixel_Model class loaded
INFO - 2018-10-18 14:01:56 --> Database Driver Class Initialized
INFO - 2018-10-18 14:01:56 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:01:56 --> Database Driver Class Initialized
INFO - 2018-10-18 14:01:56 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:01:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:01:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:01:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:01:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:01:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:01:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:01:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/home_owner.php
INFO - 2018-10-18 14:01:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:01:56 --> Final output sent to browser
DEBUG - 2018-10-18 14:01:56 --> Total execution time: 0.4676
INFO - 2018-10-18 14:01:57 --> Config Class Initialized
INFO - 2018-10-18 14:01:57 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:01:57 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:01:57 --> Utf8 Class Initialized
INFO - 2018-10-18 14:01:57 --> URI Class Initialized
INFO - 2018-10-18 14:01:57 --> Router Class Initialized
INFO - 2018-10-18 14:01:57 --> Output Class Initialized
INFO - 2018-10-18 14:01:57 --> Security Class Initialized
DEBUG - 2018-10-18 14:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:01:57 --> CSRF cookie sent
INFO - 2018-10-18 14:01:57 --> CSRF token verified
INFO - 2018-10-18 14:01:58 --> Input Class Initialized
INFO - 2018-10-18 14:01:58 --> Language Class Initialized
INFO - 2018-10-18 14:01:58 --> Loader Class Initialized
INFO - 2018-10-18 14:01:58 --> Helper loaded: url_helper
INFO - 2018-10-18 14:01:58 --> Helper loaded: form_helper
INFO - 2018-10-18 14:01:58 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:01:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:01:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:01:58 --> User Agent Class Initialized
INFO - 2018-10-18 14:01:58 --> Controller Class Initialized
INFO - 2018-10-18 14:01:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:01:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:01:58 --> Pixel_Model class loaded
INFO - 2018-10-18 14:01:58 --> Database Driver Class Initialized
INFO - 2018-10-18 14:01:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:01:58 --> Form Validation Class Initialized
INFO - 2018-10-18 14:01:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 14:01:58 --> Database Driver Class Initialized
INFO - 2018-10-18 14:01:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:01:58 --> Config Class Initialized
INFO - 2018-10-18 14:01:58 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:01:58 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:01:58 --> Utf8 Class Initialized
INFO - 2018-10-18 14:01:58 --> URI Class Initialized
INFO - 2018-10-18 14:01:58 --> Router Class Initialized
INFO - 2018-10-18 14:01:58 --> Output Class Initialized
INFO - 2018-10-18 14:01:58 --> Security Class Initialized
DEBUG - 2018-10-18 14:01:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:01:58 --> CSRF cookie sent
INFO - 2018-10-18 14:01:58 --> Input Class Initialized
INFO - 2018-10-18 14:01:58 --> Language Class Initialized
INFO - 2018-10-18 14:01:58 --> Loader Class Initialized
INFO - 2018-10-18 14:01:58 --> Helper loaded: url_helper
INFO - 2018-10-18 14:01:58 --> Helper loaded: form_helper
INFO - 2018-10-18 14:01:58 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:01:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:01:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:01:58 --> User Agent Class Initialized
INFO - 2018-10-18 14:01:58 --> Controller Class Initialized
INFO - 2018-10-18 14:01:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:01:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:01:58 --> Pixel_Model class loaded
INFO - 2018-10-18 14:01:58 --> Database Driver Class Initialized
INFO - 2018-10-18 14:01:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:01:58 --> Database Driver Class Initialized
INFO - 2018-10-18 14:01:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:01:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:01:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:01:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:01:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:01:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:01:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:01:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/home_value.php
INFO - 2018-10-18 14:01:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:01:58 --> Final output sent to browser
DEBUG - 2018-10-18 14:01:58 --> Total execution time: 0.4964
INFO - 2018-10-18 14:02:03 --> Config Class Initialized
INFO - 2018-10-18 14:02:03 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:02:04 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:02:04 --> Utf8 Class Initialized
INFO - 2018-10-18 14:02:04 --> URI Class Initialized
INFO - 2018-10-18 14:02:04 --> Router Class Initialized
INFO - 2018-10-18 14:02:04 --> Output Class Initialized
INFO - 2018-10-18 14:02:04 --> Security Class Initialized
DEBUG - 2018-10-18 14:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:02:04 --> CSRF cookie sent
INFO - 2018-10-18 14:02:04 --> CSRF token verified
INFO - 2018-10-18 14:02:04 --> Input Class Initialized
INFO - 2018-10-18 14:02:04 --> Language Class Initialized
INFO - 2018-10-18 14:02:04 --> Loader Class Initialized
INFO - 2018-10-18 14:02:04 --> Helper loaded: url_helper
INFO - 2018-10-18 14:02:04 --> Helper loaded: form_helper
INFO - 2018-10-18 14:02:04 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:02:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:02:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:02:04 --> User Agent Class Initialized
INFO - 2018-10-18 14:02:04 --> Controller Class Initialized
INFO - 2018-10-18 14:02:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:02:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:02:04 --> Pixel_Model class loaded
INFO - 2018-10-18 14:02:04 --> Database Driver Class Initialized
INFO - 2018-10-18 14:02:04 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:02:04 --> Form Validation Class Initialized
INFO - 2018-10-18 14:02:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 14:02:04 --> Database Driver Class Initialized
INFO - 2018-10-18 14:02:04 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:02:04 --> Config Class Initialized
INFO - 2018-10-18 14:02:04 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:02:04 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:02:04 --> Utf8 Class Initialized
INFO - 2018-10-18 14:02:04 --> URI Class Initialized
INFO - 2018-10-18 14:02:04 --> Router Class Initialized
INFO - 2018-10-18 14:02:04 --> Output Class Initialized
INFO - 2018-10-18 14:02:04 --> Security Class Initialized
DEBUG - 2018-10-18 14:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:02:04 --> CSRF cookie sent
INFO - 2018-10-18 14:02:04 --> Input Class Initialized
INFO - 2018-10-18 14:02:04 --> Language Class Initialized
INFO - 2018-10-18 14:02:04 --> Loader Class Initialized
INFO - 2018-10-18 14:02:04 --> Helper loaded: url_helper
INFO - 2018-10-18 14:02:04 --> Helper loaded: form_helper
INFO - 2018-10-18 14:02:04 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:02:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:02:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:02:04 --> User Agent Class Initialized
INFO - 2018-10-18 14:02:04 --> Controller Class Initialized
INFO - 2018-10-18 14:02:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:02:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:02:04 --> Pixel_Model class loaded
INFO - 2018-10-18 14:02:04 --> Database Driver Class Initialized
INFO - 2018-10-18 14:02:04 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:02:04 --> Database Driver Class Initialized
INFO - 2018-10-18 14:02:04 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:02:04 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:02:04 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:02:04 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:02:04 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:02:04 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:02:04 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:02:04 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/merriage_home_title.php
INFO - 2018-10-18 14:02:04 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:02:04 --> Final output sent to browser
DEBUG - 2018-10-18 14:02:04 --> Total execution time: 0.4830
INFO - 2018-10-18 14:02:06 --> Config Class Initialized
INFO - 2018-10-18 14:02:06 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:02:06 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:02:06 --> Utf8 Class Initialized
INFO - 2018-10-18 14:02:06 --> URI Class Initialized
INFO - 2018-10-18 14:02:06 --> Router Class Initialized
INFO - 2018-10-18 14:02:06 --> Output Class Initialized
INFO - 2018-10-18 14:02:06 --> Security Class Initialized
DEBUG - 2018-10-18 14:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:02:06 --> CSRF cookie sent
INFO - 2018-10-18 14:02:06 --> CSRF token verified
INFO - 2018-10-18 14:02:06 --> Input Class Initialized
INFO - 2018-10-18 14:02:06 --> Language Class Initialized
INFO - 2018-10-18 14:02:06 --> Loader Class Initialized
INFO - 2018-10-18 14:02:06 --> Helper loaded: url_helper
INFO - 2018-10-18 14:02:06 --> Helper loaded: form_helper
INFO - 2018-10-18 14:02:06 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:02:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:02:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:02:06 --> User Agent Class Initialized
INFO - 2018-10-18 14:02:06 --> Controller Class Initialized
INFO - 2018-10-18 14:02:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:02:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:02:06 --> Pixel_Model class loaded
INFO - 2018-10-18 14:02:06 --> Database Driver Class Initialized
INFO - 2018-10-18 14:02:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:02:06 --> Form Validation Class Initialized
INFO - 2018-10-18 14:02:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 14:02:06 --> Database Driver Class Initialized
INFO - 2018-10-18 14:02:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:02:06 --> Config Class Initialized
INFO - 2018-10-18 14:02:06 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:02:06 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:02:06 --> Utf8 Class Initialized
INFO - 2018-10-18 14:02:06 --> URI Class Initialized
INFO - 2018-10-18 14:02:06 --> Router Class Initialized
INFO - 2018-10-18 14:02:06 --> Output Class Initialized
INFO - 2018-10-18 14:02:06 --> Security Class Initialized
DEBUG - 2018-10-18 14:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:02:06 --> CSRF cookie sent
INFO - 2018-10-18 14:02:06 --> Input Class Initialized
INFO - 2018-10-18 14:02:06 --> Language Class Initialized
INFO - 2018-10-18 14:02:06 --> Loader Class Initialized
INFO - 2018-10-18 14:02:06 --> Helper loaded: url_helper
INFO - 2018-10-18 14:02:06 --> Helper loaded: form_helper
INFO - 2018-10-18 14:02:06 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:02:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:02:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:02:06 --> User Agent Class Initialized
INFO - 2018-10-18 14:02:06 --> Controller Class Initialized
INFO - 2018-10-18 14:02:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:02:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:02:06 --> Pixel_Model class loaded
INFO - 2018-10-18 14:02:06 --> Database Driver Class Initialized
INFO - 2018-10-18 14:02:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:02:06 --> Database Driver Class Initialized
INFO - 2018-10-18 14:02:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:02:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:02:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:02:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:02:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:02:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:02:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:02:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/financial.php
INFO - 2018-10-18 14:02:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:02:06 --> Final output sent to browser
DEBUG - 2018-10-18 14:02:07 --> Total execution time: 0.4779
INFO - 2018-10-18 14:02:08 --> Config Class Initialized
INFO - 2018-10-18 14:02:08 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:02:08 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:02:08 --> Utf8 Class Initialized
INFO - 2018-10-18 14:02:08 --> URI Class Initialized
INFO - 2018-10-18 14:02:08 --> Router Class Initialized
INFO - 2018-10-18 14:02:08 --> Output Class Initialized
INFO - 2018-10-18 14:02:08 --> Security Class Initialized
DEBUG - 2018-10-18 14:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:02:08 --> CSRF cookie sent
INFO - 2018-10-18 14:02:08 --> CSRF token verified
INFO - 2018-10-18 14:02:08 --> Input Class Initialized
INFO - 2018-10-18 14:02:08 --> Language Class Initialized
INFO - 2018-10-18 14:02:08 --> Loader Class Initialized
INFO - 2018-10-18 14:02:08 --> Helper loaded: url_helper
INFO - 2018-10-18 14:02:08 --> Helper loaded: form_helper
INFO - 2018-10-18 14:02:08 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:02:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:02:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:02:08 --> User Agent Class Initialized
INFO - 2018-10-18 14:02:08 --> Controller Class Initialized
INFO - 2018-10-18 14:02:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:02:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:02:08 --> Pixel_Model class loaded
INFO - 2018-10-18 14:02:08 --> Database Driver Class Initialized
INFO - 2018-10-18 14:02:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:02:08 --> Form Validation Class Initialized
INFO - 2018-10-18 14:02:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 14:02:08 --> Database Driver Class Initialized
INFO - 2018-10-18 14:02:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:02:08 --> Config Class Initialized
INFO - 2018-10-18 14:02:08 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:02:08 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:02:08 --> Utf8 Class Initialized
INFO - 2018-10-18 14:02:08 --> URI Class Initialized
INFO - 2018-10-18 14:02:08 --> Router Class Initialized
INFO - 2018-10-18 14:02:08 --> Output Class Initialized
INFO - 2018-10-18 14:02:08 --> Security Class Initialized
DEBUG - 2018-10-18 14:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:02:08 --> CSRF cookie sent
INFO - 2018-10-18 14:02:08 --> Input Class Initialized
INFO - 2018-10-18 14:02:08 --> Language Class Initialized
INFO - 2018-10-18 14:02:08 --> Loader Class Initialized
INFO - 2018-10-18 14:02:09 --> Helper loaded: url_helper
INFO - 2018-10-18 14:02:09 --> Helper loaded: form_helper
INFO - 2018-10-18 14:02:09 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:02:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:02:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:02:09 --> User Agent Class Initialized
INFO - 2018-10-18 14:02:09 --> Controller Class Initialized
INFO - 2018-10-18 14:02:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:02:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:02:09 --> Pixel_Model class loaded
INFO - 2018-10-18 14:02:09 --> Database Driver Class Initialized
INFO - 2018-10-18 14:02:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:02:09 --> Database Driver Class Initialized
INFO - 2018-10-18 14:02:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:02:09 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:02:09 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:02:09 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:02:09 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:02:09 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:02:09 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:02:09 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/kids_info.php
INFO - 2018-10-18 14:02:09 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:02:09 --> Final output sent to browser
DEBUG - 2018-10-18 14:02:09 --> Total execution time: 0.5350
INFO - 2018-10-18 14:02:20 --> Config Class Initialized
INFO - 2018-10-18 14:02:20 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:02:20 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:02:20 --> Utf8 Class Initialized
INFO - 2018-10-18 14:02:20 --> URI Class Initialized
INFO - 2018-10-18 14:02:20 --> Router Class Initialized
INFO - 2018-10-18 14:02:20 --> Output Class Initialized
INFO - 2018-10-18 14:02:20 --> Security Class Initialized
DEBUG - 2018-10-18 14:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:02:20 --> CSRF cookie sent
INFO - 2018-10-18 14:02:20 --> CSRF token verified
INFO - 2018-10-18 14:02:20 --> Input Class Initialized
INFO - 2018-10-18 14:02:20 --> Language Class Initialized
INFO - 2018-10-18 14:02:20 --> Loader Class Initialized
INFO - 2018-10-18 14:02:20 --> Helper loaded: url_helper
INFO - 2018-10-18 14:02:20 --> Helper loaded: form_helper
INFO - 2018-10-18 14:02:20 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:02:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:02:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:02:20 --> User Agent Class Initialized
INFO - 2018-10-18 14:02:20 --> Controller Class Initialized
INFO - 2018-10-18 14:02:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:02:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:02:20 --> Pixel_Model class loaded
INFO - 2018-10-18 14:02:20 --> Database Driver Class Initialized
INFO - 2018-10-18 14:02:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:02:20 --> Form Validation Class Initialized
INFO - 2018-10-18 14:02:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 14:02:20 --> Database Driver Class Initialized
INFO - 2018-10-18 14:02:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:02:20 --> Config Class Initialized
INFO - 2018-10-18 14:02:20 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:02:20 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:02:20 --> Utf8 Class Initialized
INFO - 2018-10-18 14:02:20 --> URI Class Initialized
INFO - 2018-10-18 14:02:20 --> Router Class Initialized
INFO - 2018-10-18 14:02:20 --> Output Class Initialized
INFO - 2018-10-18 14:02:20 --> Security Class Initialized
DEBUG - 2018-10-18 14:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:02:20 --> CSRF cookie sent
INFO - 2018-10-18 14:02:20 --> Input Class Initialized
INFO - 2018-10-18 14:02:21 --> Language Class Initialized
INFO - 2018-10-18 14:02:21 --> Loader Class Initialized
INFO - 2018-10-18 14:02:21 --> Helper loaded: url_helper
INFO - 2018-10-18 14:02:21 --> Helper loaded: form_helper
INFO - 2018-10-18 14:02:21 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:02:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:02:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:02:21 --> User Agent Class Initialized
INFO - 2018-10-18 14:02:21 --> Controller Class Initialized
INFO - 2018-10-18 14:02:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:02:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:02:21 --> Pixel_Model class loaded
INFO - 2018-10-18 14:02:21 --> Database Driver Class Initialized
INFO - 2018-10-18 14:02:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:02:21 --> Database Driver Class Initialized
INFO - 2018-10-18 14:02:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:02:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:02:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:02:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:02:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:02:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:02:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:02:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/other_kids.php
INFO - 2018-10-18 14:02:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:02:21 --> Final output sent to browser
DEBUG - 2018-10-18 14:02:21 --> Total execution time: 0.5143
INFO - 2018-10-18 14:02:23 --> Config Class Initialized
INFO - 2018-10-18 14:02:23 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:02:23 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:02:23 --> Utf8 Class Initialized
INFO - 2018-10-18 14:02:23 --> URI Class Initialized
INFO - 2018-10-18 14:02:23 --> Router Class Initialized
INFO - 2018-10-18 14:02:23 --> Output Class Initialized
INFO - 2018-10-18 14:02:23 --> Security Class Initialized
DEBUG - 2018-10-18 14:02:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:02:23 --> CSRF cookie sent
INFO - 2018-10-18 14:02:23 --> CSRF token verified
INFO - 2018-10-18 14:02:23 --> Input Class Initialized
INFO - 2018-10-18 14:02:23 --> Language Class Initialized
INFO - 2018-10-18 14:02:23 --> Loader Class Initialized
INFO - 2018-10-18 14:02:23 --> Helper loaded: url_helper
INFO - 2018-10-18 14:02:23 --> Helper loaded: form_helper
INFO - 2018-10-18 14:02:23 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:02:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:02:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:02:23 --> User Agent Class Initialized
INFO - 2018-10-18 14:02:23 --> Controller Class Initialized
INFO - 2018-10-18 14:02:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:02:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:02:23 --> Pixel_Model class loaded
INFO - 2018-10-18 14:02:23 --> Database Driver Class Initialized
INFO - 2018-10-18 14:02:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:02:23 --> Form Validation Class Initialized
INFO - 2018-10-18 14:02:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 14:02:23 --> Database Driver Class Initialized
INFO - 2018-10-18 14:02:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:02:24 --> Config Class Initialized
INFO - 2018-10-18 14:02:24 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:02:24 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:02:24 --> Utf8 Class Initialized
INFO - 2018-10-18 14:02:24 --> URI Class Initialized
INFO - 2018-10-18 14:02:24 --> Router Class Initialized
INFO - 2018-10-18 14:02:24 --> Output Class Initialized
INFO - 2018-10-18 14:02:24 --> Security Class Initialized
DEBUG - 2018-10-18 14:02:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:02:24 --> CSRF cookie sent
INFO - 2018-10-18 14:02:24 --> Input Class Initialized
INFO - 2018-10-18 14:02:24 --> Language Class Initialized
INFO - 2018-10-18 14:02:24 --> Loader Class Initialized
INFO - 2018-10-18 14:02:24 --> Helper loaded: url_helper
INFO - 2018-10-18 14:02:24 --> Helper loaded: form_helper
INFO - 2018-10-18 14:02:24 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:02:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:02:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:02:24 --> User Agent Class Initialized
INFO - 2018-10-18 14:02:24 --> Controller Class Initialized
INFO - 2018-10-18 14:02:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:02:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:02:24 --> Pixel_Model class loaded
INFO - 2018-10-18 14:02:24 --> Database Driver Class Initialized
INFO - 2018-10-18 14:02:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:02:24 --> Database Driver Class Initialized
INFO - 2018-10-18 14:02:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:02:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:02:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:02:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:02:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:02:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:02:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:02:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/kids_activities.php
INFO - 2018-10-18 14:02:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:02:24 --> Final output sent to browser
DEBUG - 2018-10-18 14:02:24 --> Total execution time: 0.4914
INFO - 2018-10-18 14:02:35 --> Config Class Initialized
INFO - 2018-10-18 14:02:35 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:02:35 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:02:35 --> Utf8 Class Initialized
INFO - 2018-10-18 14:02:35 --> URI Class Initialized
INFO - 2018-10-18 14:02:35 --> Router Class Initialized
INFO - 2018-10-18 14:02:35 --> Output Class Initialized
INFO - 2018-10-18 14:02:35 --> Security Class Initialized
DEBUG - 2018-10-18 14:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:02:35 --> CSRF cookie sent
INFO - 2018-10-18 14:02:35 --> Input Class Initialized
INFO - 2018-10-18 14:02:35 --> Language Class Initialized
ERROR - 2018-10-18 14:02:35 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 14:03:07 --> Config Class Initialized
INFO - 2018-10-18 14:03:07 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:03:07 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:03:07 --> Utf8 Class Initialized
INFO - 2018-10-18 14:03:07 --> URI Class Initialized
INFO - 2018-10-18 14:03:07 --> Router Class Initialized
INFO - 2018-10-18 14:03:07 --> Output Class Initialized
INFO - 2018-10-18 14:03:07 --> Security Class Initialized
DEBUG - 2018-10-18 14:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:03:07 --> CSRF cookie sent
INFO - 2018-10-18 14:03:07 --> CSRF token verified
INFO - 2018-10-18 14:03:07 --> Input Class Initialized
INFO - 2018-10-18 14:03:07 --> Language Class Initialized
INFO - 2018-10-18 14:03:07 --> Loader Class Initialized
INFO - 2018-10-18 14:03:07 --> Helper loaded: url_helper
INFO - 2018-10-18 14:03:07 --> Helper loaded: form_helper
INFO - 2018-10-18 14:03:07 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:03:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:03:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:03:07 --> User Agent Class Initialized
INFO - 2018-10-18 14:03:07 --> Controller Class Initialized
INFO - 2018-10-18 14:03:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:03:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:03:07 --> Pixel_Model class loaded
INFO - 2018-10-18 14:03:07 --> Database Driver Class Initialized
INFO - 2018-10-18 14:03:07 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:03:07 --> Form Validation Class Initialized
INFO - 2018-10-18 14:03:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 14:03:07 --> Database Driver Class Initialized
INFO - 2018-10-18 14:03:07 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:03:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:03:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:03:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:03:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:03:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:03:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_errors.php
INFO - 2018-10-18 14:03:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:03:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/kids_activities.php
INFO - 2018-10-18 14:03:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:03:07 --> Final output sent to browser
DEBUG - 2018-10-18 14:03:07 --> Total execution time: 0.6082
INFO - 2018-10-18 14:03:08 --> Config Class Initialized
INFO - 2018-10-18 14:03:08 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:03:08 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:03:08 --> Utf8 Class Initialized
INFO - 2018-10-18 14:03:08 --> URI Class Initialized
INFO - 2018-10-18 14:03:08 --> Router Class Initialized
INFO - 2018-10-18 14:03:08 --> Output Class Initialized
INFO - 2018-10-18 14:03:08 --> Security Class Initialized
DEBUG - 2018-10-18 14:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:03:08 --> CSRF cookie sent
INFO - 2018-10-18 14:03:08 --> Input Class Initialized
INFO - 2018-10-18 14:03:08 --> Language Class Initialized
ERROR - 2018-10-18 14:03:08 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 14:03:11 --> Config Class Initialized
INFO - 2018-10-18 14:03:11 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:03:11 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:03:11 --> Utf8 Class Initialized
INFO - 2018-10-18 14:03:11 --> URI Class Initialized
INFO - 2018-10-18 14:03:11 --> Router Class Initialized
INFO - 2018-10-18 14:03:11 --> Output Class Initialized
INFO - 2018-10-18 14:03:11 --> Security Class Initialized
DEBUG - 2018-10-18 14:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:03:11 --> CSRF cookie sent
INFO - 2018-10-18 14:03:12 --> CSRF token verified
INFO - 2018-10-18 14:03:12 --> Input Class Initialized
INFO - 2018-10-18 14:03:12 --> Language Class Initialized
INFO - 2018-10-18 14:03:12 --> Loader Class Initialized
INFO - 2018-10-18 14:03:12 --> Helper loaded: url_helper
INFO - 2018-10-18 14:03:12 --> Helper loaded: form_helper
INFO - 2018-10-18 14:03:12 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:03:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:03:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:03:12 --> User Agent Class Initialized
INFO - 2018-10-18 14:03:12 --> Controller Class Initialized
INFO - 2018-10-18 14:03:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:03:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:03:12 --> Pixel_Model class loaded
INFO - 2018-10-18 14:03:12 --> Database Driver Class Initialized
INFO - 2018-10-18 14:03:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:03:12 --> Form Validation Class Initialized
INFO - 2018-10-18 14:03:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 14:03:12 --> Database Driver Class Initialized
INFO - 2018-10-18 14:03:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:03:12 --> Config Class Initialized
INFO - 2018-10-18 14:03:12 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:03:12 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:03:12 --> Utf8 Class Initialized
INFO - 2018-10-18 14:03:12 --> URI Class Initialized
INFO - 2018-10-18 14:03:12 --> Router Class Initialized
INFO - 2018-10-18 14:03:12 --> Output Class Initialized
INFO - 2018-10-18 14:03:12 --> Security Class Initialized
DEBUG - 2018-10-18 14:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:03:12 --> CSRF cookie sent
INFO - 2018-10-18 14:03:12 --> Input Class Initialized
INFO - 2018-10-18 14:03:12 --> Language Class Initialized
INFO - 2018-10-18 14:03:12 --> Loader Class Initialized
INFO - 2018-10-18 14:03:12 --> Helper loaded: url_helper
INFO - 2018-10-18 14:03:12 --> Helper loaded: form_helper
INFO - 2018-10-18 14:03:12 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:03:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:03:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:03:12 --> User Agent Class Initialized
INFO - 2018-10-18 14:03:12 --> Controller Class Initialized
INFO - 2018-10-18 14:03:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:03:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:03:12 --> Pixel_Model class loaded
INFO - 2018-10-18 14:03:12 --> Database Driver Class Initialized
INFO - 2018-10-18 14:03:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:03:12 --> Database Driver Class Initialized
INFO - 2018-10-18 14:03:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:03:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:03:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:03:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:03:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:03:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:03:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:03:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/kids_communicate.php
INFO - 2018-10-18 14:03:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:03:12 --> Final output sent to browser
DEBUG - 2018-10-18 14:03:12 --> Total execution time: 0.5062
INFO - 2018-10-18 14:03:14 --> Config Class Initialized
INFO - 2018-10-18 14:03:14 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:03:14 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:03:14 --> Utf8 Class Initialized
INFO - 2018-10-18 14:03:14 --> URI Class Initialized
INFO - 2018-10-18 14:03:14 --> Router Class Initialized
INFO - 2018-10-18 14:03:14 --> Output Class Initialized
INFO - 2018-10-18 14:03:14 --> Security Class Initialized
DEBUG - 2018-10-18 14:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:03:15 --> CSRF cookie sent
INFO - 2018-10-18 14:03:15 --> CSRF token verified
INFO - 2018-10-18 14:03:15 --> Input Class Initialized
INFO - 2018-10-18 14:03:15 --> Language Class Initialized
INFO - 2018-10-18 14:03:15 --> Loader Class Initialized
INFO - 2018-10-18 14:03:15 --> Helper loaded: url_helper
INFO - 2018-10-18 14:03:15 --> Helper loaded: form_helper
INFO - 2018-10-18 14:03:15 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:03:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:03:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:03:15 --> User Agent Class Initialized
INFO - 2018-10-18 14:03:15 --> Controller Class Initialized
INFO - 2018-10-18 14:03:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:03:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:03:15 --> Pixel_Model class loaded
INFO - 2018-10-18 14:03:15 --> Database Driver Class Initialized
INFO - 2018-10-18 14:03:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:03:15 --> Form Validation Class Initialized
INFO - 2018-10-18 14:03:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 14:03:15 --> Database Driver Class Initialized
INFO - 2018-10-18 14:03:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:03:15 --> Config Class Initialized
INFO - 2018-10-18 14:03:15 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:03:15 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:03:15 --> Utf8 Class Initialized
INFO - 2018-10-18 14:03:15 --> URI Class Initialized
INFO - 2018-10-18 14:03:15 --> Router Class Initialized
INFO - 2018-10-18 14:03:15 --> Output Class Initialized
INFO - 2018-10-18 14:03:15 --> Security Class Initialized
DEBUG - 2018-10-18 14:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:03:15 --> CSRF cookie sent
INFO - 2018-10-18 14:03:15 --> Input Class Initialized
INFO - 2018-10-18 14:03:15 --> Language Class Initialized
INFO - 2018-10-18 14:03:15 --> Loader Class Initialized
INFO - 2018-10-18 14:03:15 --> Helper loaded: url_helper
INFO - 2018-10-18 14:03:15 --> Helper loaded: form_helper
INFO - 2018-10-18 14:03:15 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:03:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:03:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:03:15 --> User Agent Class Initialized
INFO - 2018-10-18 14:03:15 --> Controller Class Initialized
INFO - 2018-10-18 14:03:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:03:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:03:15 --> Pixel_Model class loaded
INFO - 2018-10-18 14:03:15 --> Database Driver Class Initialized
INFO - 2018-10-18 14:03:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:03:15 --> Database Driver Class Initialized
INFO - 2018-10-18 14:03:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:03:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:03:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:03:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:03:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:03:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:03:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:03:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/kids_dinner.php
INFO - 2018-10-18 14:03:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:03:15 --> Final output sent to browser
DEBUG - 2018-10-18 14:03:16 --> Total execution time: 0.5214
INFO - 2018-10-18 14:03:16 --> Config Class Initialized
INFO - 2018-10-18 14:03:16 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:03:16 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:03:16 --> Utf8 Class Initialized
INFO - 2018-10-18 14:03:16 --> URI Class Initialized
INFO - 2018-10-18 14:03:16 --> Router Class Initialized
INFO - 2018-10-18 14:03:16 --> Output Class Initialized
INFO - 2018-10-18 14:03:16 --> Security Class Initialized
DEBUG - 2018-10-18 14:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:03:16 --> CSRF cookie sent
INFO - 2018-10-18 14:03:16 --> CSRF token verified
INFO - 2018-10-18 14:03:16 --> Input Class Initialized
INFO - 2018-10-18 14:03:16 --> Language Class Initialized
INFO - 2018-10-18 14:03:16 --> Loader Class Initialized
INFO - 2018-10-18 14:03:16 --> Helper loaded: url_helper
INFO - 2018-10-18 14:03:16 --> Helper loaded: form_helper
INFO - 2018-10-18 14:03:16 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:03:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:03:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:03:16 --> User Agent Class Initialized
INFO - 2018-10-18 14:03:16 --> Controller Class Initialized
INFO - 2018-10-18 14:03:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:03:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:03:16 --> Pixel_Model class loaded
INFO - 2018-10-18 14:03:16 --> Database Driver Class Initialized
INFO - 2018-10-18 14:03:17 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:03:17 --> Form Validation Class Initialized
INFO - 2018-10-18 14:03:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 14:03:17 --> Database Driver Class Initialized
INFO - 2018-10-18 14:03:17 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:03:17 --> Config Class Initialized
INFO - 2018-10-18 14:03:17 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:03:17 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:03:17 --> Utf8 Class Initialized
INFO - 2018-10-18 14:03:17 --> URI Class Initialized
INFO - 2018-10-18 14:03:17 --> Router Class Initialized
INFO - 2018-10-18 14:03:17 --> Output Class Initialized
INFO - 2018-10-18 14:03:17 --> Security Class Initialized
DEBUG - 2018-10-18 14:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:03:17 --> CSRF cookie sent
INFO - 2018-10-18 14:03:17 --> Input Class Initialized
INFO - 2018-10-18 14:03:17 --> Language Class Initialized
INFO - 2018-10-18 14:03:17 --> Loader Class Initialized
INFO - 2018-10-18 14:03:17 --> Helper loaded: url_helper
INFO - 2018-10-18 14:03:17 --> Helper loaded: form_helper
INFO - 2018-10-18 14:03:17 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:03:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:03:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:03:17 --> User Agent Class Initialized
INFO - 2018-10-18 14:03:17 --> Controller Class Initialized
INFO - 2018-10-18 14:03:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:03:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:03:17 --> Pixel_Model class loaded
INFO - 2018-10-18 14:03:17 --> Database Driver Class Initialized
INFO - 2018-10-18 14:03:17 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:03:17 --> Database Driver Class Initialized
INFO - 2018-10-18 14:03:17 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:03:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:03:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:03:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:03:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:03:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:03:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:03:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/kids_homework.php
INFO - 2018-10-18 14:03:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:03:17 --> Final output sent to browser
DEBUG - 2018-10-18 14:03:17 --> Total execution time: 0.5009
INFO - 2018-10-18 14:03:18 --> Config Class Initialized
INFO - 2018-10-18 14:03:18 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:03:18 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:03:18 --> Utf8 Class Initialized
INFO - 2018-10-18 14:03:18 --> URI Class Initialized
INFO - 2018-10-18 14:03:18 --> Router Class Initialized
INFO - 2018-10-18 14:03:18 --> Output Class Initialized
INFO - 2018-10-18 14:03:18 --> Security Class Initialized
DEBUG - 2018-10-18 14:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:03:18 --> CSRF cookie sent
INFO - 2018-10-18 14:03:18 --> CSRF token verified
INFO - 2018-10-18 14:03:18 --> Input Class Initialized
INFO - 2018-10-18 14:03:18 --> Language Class Initialized
INFO - 2018-10-18 14:03:18 --> Loader Class Initialized
INFO - 2018-10-18 14:03:18 --> Helper loaded: url_helper
INFO - 2018-10-18 14:03:18 --> Helper loaded: form_helper
INFO - 2018-10-18 14:03:18 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:03:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:03:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:03:18 --> User Agent Class Initialized
INFO - 2018-10-18 14:03:18 --> Controller Class Initialized
INFO - 2018-10-18 14:03:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:03:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:03:18 --> Pixel_Model class loaded
INFO - 2018-10-18 14:03:18 --> Database Driver Class Initialized
INFO - 2018-10-18 14:03:18 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:03:18 --> Form Validation Class Initialized
INFO - 2018-10-18 14:03:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 14:03:18 --> Database Driver Class Initialized
INFO - 2018-10-18 14:03:18 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:03:18 --> Config Class Initialized
INFO - 2018-10-18 14:03:18 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:03:18 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:03:18 --> Utf8 Class Initialized
INFO - 2018-10-18 14:03:18 --> URI Class Initialized
INFO - 2018-10-18 14:03:18 --> Router Class Initialized
INFO - 2018-10-18 14:03:18 --> Output Class Initialized
INFO - 2018-10-18 14:03:18 --> Security Class Initialized
DEBUG - 2018-10-18 14:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:03:18 --> CSRF cookie sent
INFO - 2018-10-18 14:03:18 --> Input Class Initialized
INFO - 2018-10-18 14:03:18 --> Language Class Initialized
INFO - 2018-10-18 14:03:18 --> Loader Class Initialized
INFO - 2018-10-18 14:03:18 --> Helper loaded: url_helper
INFO - 2018-10-18 14:03:18 --> Helper loaded: form_helper
INFO - 2018-10-18 14:03:18 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:03:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:03:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:03:18 --> User Agent Class Initialized
INFO - 2018-10-18 14:03:19 --> Controller Class Initialized
INFO - 2018-10-18 14:03:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:03:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:03:19 --> Pixel_Model class loaded
INFO - 2018-10-18 14:03:19 --> Database Driver Class Initialized
INFO - 2018-10-18 14:03:19 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:03:19 --> Database Driver Class Initialized
INFO - 2018-10-18 14:03:19 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:03:19 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:03:19 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:03:19 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:03:19 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:03:19 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:03:19 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:03:19 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/kids_doctor.php
INFO - 2018-10-18 14:03:19 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:03:19 --> Final output sent to browser
DEBUG - 2018-10-18 14:03:19 --> Total execution time: 0.5279
INFO - 2018-10-18 14:03:19 --> Config Class Initialized
INFO - 2018-10-18 14:03:19 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:03:19 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:03:19 --> Utf8 Class Initialized
INFO - 2018-10-18 14:03:19 --> URI Class Initialized
INFO - 2018-10-18 14:03:19 --> Router Class Initialized
INFO - 2018-10-18 14:03:19 --> Output Class Initialized
INFO - 2018-10-18 14:03:19 --> Security Class Initialized
DEBUG - 2018-10-18 14:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:03:19 --> CSRF cookie sent
INFO - 2018-10-18 14:03:19 --> CSRF token verified
INFO - 2018-10-18 14:03:20 --> Input Class Initialized
INFO - 2018-10-18 14:03:20 --> Language Class Initialized
INFO - 2018-10-18 14:03:20 --> Loader Class Initialized
INFO - 2018-10-18 14:03:20 --> Helper loaded: url_helper
INFO - 2018-10-18 14:03:20 --> Helper loaded: form_helper
INFO - 2018-10-18 14:03:20 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:03:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:03:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:03:20 --> User Agent Class Initialized
INFO - 2018-10-18 14:03:20 --> Controller Class Initialized
INFO - 2018-10-18 14:03:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:03:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:03:20 --> Pixel_Model class loaded
INFO - 2018-10-18 14:03:20 --> Database Driver Class Initialized
INFO - 2018-10-18 14:03:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:03:20 --> Form Validation Class Initialized
INFO - 2018-10-18 14:03:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 14:03:20 --> Database Driver Class Initialized
INFO - 2018-10-18 14:03:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:03:20 --> Config Class Initialized
INFO - 2018-10-18 14:03:20 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:03:20 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:03:20 --> Utf8 Class Initialized
INFO - 2018-10-18 14:03:20 --> URI Class Initialized
INFO - 2018-10-18 14:03:20 --> Router Class Initialized
INFO - 2018-10-18 14:03:20 --> Output Class Initialized
INFO - 2018-10-18 14:03:20 --> Security Class Initialized
DEBUG - 2018-10-18 14:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:03:20 --> CSRF cookie sent
INFO - 2018-10-18 14:03:20 --> Input Class Initialized
INFO - 2018-10-18 14:03:20 --> Language Class Initialized
INFO - 2018-10-18 14:03:20 --> Loader Class Initialized
INFO - 2018-10-18 14:03:20 --> Helper loaded: url_helper
INFO - 2018-10-18 14:03:20 --> Helper loaded: form_helper
INFO - 2018-10-18 14:03:20 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:03:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:03:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:03:20 --> User Agent Class Initialized
INFO - 2018-10-18 14:03:20 --> Controller Class Initialized
INFO - 2018-10-18 14:03:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:03:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:03:20 --> Pixel_Model class loaded
INFO - 2018-10-18 14:03:20 --> Database Driver Class Initialized
INFO - 2018-10-18 14:03:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:03:20 --> Database Driver Class Initialized
INFO - 2018-10-18 14:03:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:03:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:03:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:03:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:03:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:03:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:03:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:03:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/kids_help_complaint.php
INFO - 2018-10-18 14:03:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:03:20 --> Final output sent to browser
DEBUG - 2018-10-18 14:03:20 --> Total execution time: 0.4884
INFO - 2018-10-18 14:03:21 --> Config Class Initialized
INFO - 2018-10-18 14:03:21 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:03:21 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:03:21 --> Utf8 Class Initialized
INFO - 2018-10-18 14:03:21 --> URI Class Initialized
INFO - 2018-10-18 14:03:21 --> Router Class Initialized
INFO - 2018-10-18 14:03:21 --> Output Class Initialized
INFO - 2018-10-18 14:03:21 --> Security Class Initialized
DEBUG - 2018-10-18 14:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:03:21 --> CSRF cookie sent
INFO - 2018-10-18 14:03:21 --> CSRF token verified
INFO - 2018-10-18 14:03:21 --> Input Class Initialized
INFO - 2018-10-18 14:03:21 --> Language Class Initialized
INFO - 2018-10-18 14:03:21 --> Loader Class Initialized
INFO - 2018-10-18 14:03:22 --> Helper loaded: url_helper
INFO - 2018-10-18 14:03:22 --> Helper loaded: form_helper
INFO - 2018-10-18 14:03:22 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:03:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:03:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:03:22 --> User Agent Class Initialized
INFO - 2018-10-18 14:03:22 --> Controller Class Initialized
INFO - 2018-10-18 14:03:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:03:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:03:22 --> Pixel_Model class loaded
INFO - 2018-10-18 14:03:22 --> Database Driver Class Initialized
INFO - 2018-10-18 14:03:22 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:03:22 --> Form Validation Class Initialized
INFO - 2018-10-18 14:03:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 14:03:22 --> Database Driver Class Initialized
INFO - 2018-10-18 14:03:22 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:03:22 --> Config Class Initialized
INFO - 2018-10-18 14:03:22 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:03:22 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:03:22 --> Utf8 Class Initialized
INFO - 2018-10-18 14:03:22 --> URI Class Initialized
INFO - 2018-10-18 14:03:22 --> Router Class Initialized
INFO - 2018-10-18 14:03:22 --> Output Class Initialized
INFO - 2018-10-18 14:03:22 --> Security Class Initialized
DEBUG - 2018-10-18 14:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:03:22 --> CSRF cookie sent
INFO - 2018-10-18 14:03:22 --> Input Class Initialized
INFO - 2018-10-18 14:03:22 --> Language Class Initialized
INFO - 2018-10-18 14:03:22 --> Loader Class Initialized
INFO - 2018-10-18 14:03:22 --> Helper loaded: url_helper
INFO - 2018-10-18 14:03:22 --> Helper loaded: form_helper
INFO - 2018-10-18 14:03:22 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:03:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:03:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:03:22 --> User Agent Class Initialized
INFO - 2018-10-18 14:03:22 --> Controller Class Initialized
INFO - 2018-10-18 14:03:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:03:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:03:22 --> Pixel_Model class loaded
INFO - 2018-10-18 14:03:22 --> Database Driver Class Initialized
INFO - 2018-10-18 14:03:22 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:03:22 --> Database Driver Class Initialized
INFO - 2018-10-18 14:03:22 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:03:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:03:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:03:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:03:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:03:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:03:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:03:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/spouse_info.php
INFO - 2018-10-18 14:03:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:03:22 --> Final output sent to browser
DEBUG - 2018-10-18 14:03:22 --> Total execution time: 0.5018
INFO - 2018-10-18 14:03:26 --> Config Class Initialized
INFO - 2018-10-18 14:03:26 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:03:26 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:03:26 --> Utf8 Class Initialized
INFO - 2018-10-18 14:03:26 --> URI Class Initialized
INFO - 2018-10-18 14:03:26 --> Router Class Initialized
INFO - 2018-10-18 14:03:26 --> Output Class Initialized
INFO - 2018-10-18 14:03:26 --> Security Class Initialized
DEBUG - 2018-10-18 14:03:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:03:26 --> CSRF cookie sent
INFO - 2018-10-18 14:03:26 --> CSRF token verified
INFO - 2018-10-18 14:03:26 --> Input Class Initialized
INFO - 2018-10-18 14:03:26 --> Language Class Initialized
INFO - 2018-10-18 14:03:26 --> Loader Class Initialized
INFO - 2018-10-18 14:03:26 --> Helper loaded: url_helper
INFO - 2018-10-18 14:03:26 --> Helper loaded: form_helper
INFO - 2018-10-18 14:03:26 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:03:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:03:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:03:26 --> User Agent Class Initialized
INFO - 2018-10-18 14:03:26 --> Controller Class Initialized
INFO - 2018-10-18 14:03:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:03:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:03:26 --> Pixel_Model class loaded
INFO - 2018-10-18 14:03:26 --> Database Driver Class Initialized
INFO - 2018-10-18 14:03:26 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:03:26 --> Form Validation Class Initialized
INFO - 2018-10-18 14:03:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 14:03:26 --> Database Driver Class Initialized
INFO - 2018-10-18 14:03:26 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:03:26 --> Config Class Initialized
INFO - 2018-10-18 14:03:27 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:03:27 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:03:27 --> Utf8 Class Initialized
INFO - 2018-10-18 14:03:27 --> URI Class Initialized
INFO - 2018-10-18 14:03:27 --> Router Class Initialized
INFO - 2018-10-18 14:03:27 --> Output Class Initialized
INFO - 2018-10-18 14:03:27 --> Security Class Initialized
DEBUG - 2018-10-18 14:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:03:27 --> CSRF cookie sent
INFO - 2018-10-18 14:03:27 --> Input Class Initialized
INFO - 2018-10-18 14:03:27 --> Language Class Initialized
INFO - 2018-10-18 14:03:27 --> Loader Class Initialized
INFO - 2018-10-18 14:03:27 --> Helper loaded: url_helper
INFO - 2018-10-18 14:03:27 --> Helper loaded: form_helper
INFO - 2018-10-18 14:03:27 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:03:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:03:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:03:27 --> User Agent Class Initialized
INFO - 2018-10-18 14:03:27 --> Controller Class Initialized
INFO - 2018-10-18 14:03:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:03:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:03:27 --> Pixel_Model class loaded
INFO - 2018-10-18 14:03:27 --> Database Driver Class Initialized
INFO - 2018-10-18 14:03:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:03:27 --> Database Driver Class Initialized
INFO - 2018-10-18 14:03:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:03:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:03:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:03:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:03:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:03:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:03:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:03:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/spouse_job.php
INFO - 2018-10-18 14:03:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:03:27 --> Final output sent to browser
DEBUG - 2018-10-18 14:03:27 --> Total execution time: 0.5134
INFO - 2018-10-18 14:03:28 --> Config Class Initialized
INFO - 2018-10-18 14:03:28 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:03:28 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:03:28 --> Utf8 Class Initialized
INFO - 2018-10-18 14:03:28 --> URI Class Initialized
INFO - 2018-10-18 14:03:28 --> Router Class Initialized
INFO - 2018-10-18 14:03:28 --> Output Class Initialized
INFO - 2018-10-18 14:03:28 --> Security Class Initialized
DEBUG - 2018-10-18 14:03:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:03:28 --> CSRF cookie sent
INFO - 2018-10-18 14:03:28 --> CSRF token verified
INFO - 2018-10-18 14:03:28 --> Input Class Initialized
INFO - 2018-10-18 14:03:28 --> Language Class Initialized
INFO - 2018-10-18 14:03:28 --> Loader Class Initialized
INFO - 2018-10-18 14:03:28 --> Helper loaded: url_helper
INFO - 2018-10-18 14:03:28 --> Helper loaded: form_helper
INFO - 2018-10-18 14:03:28 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:03:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:03:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:03:28 --> User Agent Class Initialized
INFO - 2018-10-18 14:03:28 --> Controller Class Initialized
INFO - 2018-10-18 14:03:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:03:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:03:28 --> Pixel_Model class loaded
INFO - 2018-10-18 14:03:28 --> Database Driver Class Initialized
INFO - 2018-10-18 14:03:28 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:03:28 --> Form Validation Class Initialized
INFO - 2018-10-18 14:03:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 14:03:28 --> Database Driver Class Initialized
INFO - 2018-10-18 14:03:28 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:03:28 --> Config Class Initialized
INFO - 2018-10-18 14:03:28 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:03:29 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:03:29 --> Utf8 Class Initialized
INFO - 2018-10-18 14:03:29 --> URI Class Initialized
INFO - 2018-10-18 14:03:29 --> Router Class Initialized
INFO - 2018-10-18 14:03:29 --> Output Class Initialized
INFO - 2018-10-18 14:03:29 --> Security Class Initialized
DEBUG - 2018-10-18 14:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:03:29 --> CSRF cookie sent
INFO - 2018-10-18 14:03:29 --> Input Class Initialized
INFO - 2018-10-18 14:03:29 --> Language Class Initialized
INFO - 2018-10-18 14:03:29 --> Loader Class Initialized
INFO - 2018-10-18 14:03:29 --> Helper loaded: url_helper
INFO - 2018-10-18 14:03:29 --> Helper loaded: form_helper
INFO - 2018-10-18 14:03:29 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:03:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:03:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:03:29 --> User Agent Class Initialized
INFO - 2018-10-18 14:03:29 --> Controller Class Initialized
INFO - 2018-10-18 14:03:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:03:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:03:29 --> Pixel_Model class loaded
INFO - 2018-10-18 14:03:29 --> Database Driver Class Initialized
INFO - 2018-10-18 14:03:29 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:03:29 --> Database Driver Class Initialized
INFO - 2018-10-18 14:03:29 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:03:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:03:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:03:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:03:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:03:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:03:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:03:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/affectionate_salutation.php
INFO - 2018-10-18 14:03:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:03:29 --> Final output sent to browser
DEBUG - 2018-10-18 14:03:29 --> Total execution time: 0.5070
INFO - 2018-10-18 14:03:38 --> Config Class Initialized
INFO - 2018-10-18 14:03:38 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:03:38 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:03:38 --> Utf8 Class Initialized
INFO - 2018-10-18 14:03:38 --> URI Class Initialized
INFO - 2018-10-18 14:03:38 --> Router Class Initialized
INFO - 2018-10-18 14:03:38 --> Output Class Initialized
INFO - 2018-10-18 14:03:38 --> Security Class Initialized
DEBUG - 2018-10-18 14:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:03:38 --> CSRF cookie sent
INFO - 2018-10-18 14:03:38 --> Input Class Initialized
INFO - 2018-10-18 14:03:38 --> Language Class Initialized
INFO - 2018-10-18 14:03:38 --> Loader Class Initialized
INFO - 2018-10-18 14:03:38 --> Helper loaded: url_helper
INFO - 2018-10-18 14:03:38 --> Helper loaded: form_helper
INFO - 2018-10-18 14:03:38 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:03:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:03:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:03:38 --> User Agent Class Initialized
INFO - 2018-10-18 14:03:38 --> Controller Class Initialized
INFO - 2018-10-18 14:03:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:03:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:03:38 --> Pixel_Model class loaded
INFO - 2018-10-18 14:03:38 --> Database Driver Class Initialized
INFO - 2018-10-18 14:03:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:03:38 --> Database Driver Class Initialized
INFO - 2018-10-18 14:03:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:03:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:03:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:03:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:03:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:03:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:03:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:03:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/affectionate_salutation.php
INFO - 2018-10-18 14:03:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:03:39 --> Final output sent to browser
DEBUG - 2018-10-18 14:03:39 --> Total execution time: 0.5633
INFO - 2018-10-18 14:03:40 --> Config Class Initialized
INFO - 2018-10-18 14:03:40 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:03:40 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:03:40 --> Utf8 Class Initialized
INFO - 2018-10-18 14:03:40 --> URI Class Initialized
INFO - 2018-10-18 14:03:40 --> Router Class Initialized
INFO - 2018-10-18 14:03:40 --> Output Class Initialized
INFO - 2018-10-18 14:03:40 --> Security Class Initialized
DEBUG - 2018-10-18 14:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:03:40 --> CSRF cookie sent
INFO - 2018-10-18 14:03:40 --> CSRF token verified
INFO - 2018-10-18 14:03:40 --> Input Class Initialized
INFO - 2018-10-18 14:03:40 --> Language Class Initialized
INFO - 2018-10-18 14:03:41 --> Loader Class Initialized
INFO - 2018-10-18 14:03:41 --> Helper loaded: url_helper
INFO - 2018-10-18 14:03:41 --> Helper loaded: form_helper
INFO - 2018-10-18 14:03:41 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:03:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:03:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:03:41 --> User Agent Class Initialized
INFO - 2018-10-18 14:03:41 --> Controller Class Initialized
INFO - 2018-10-18 14:03:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:03:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:03:41 --> Pixel_Model class loaded
INFO - 2018-10-18 14:03:41 --> Database Driver Class Initialized
INFO - 2018-10-18 14:03:41 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:03:41 --> Form Validation Class Initialized
INFO - 2018-10-18 14:03:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 14:03:41 --> Database Driver Class Initialized
INFO - 2018-10-18 14:03:41 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:03:41 --> Config Class Initialized
INFO - 2018-10-18 14:03:41 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:03:41 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:03:41 --> Utf8 Class Initialized
INFO - 2018-10-18 14:03:41 --> URI Class Initialized
INFO - 2018-10-18 14:03:41 --> Router Class Initialized
INFO - 2018-10-18 14:03:41 --> Output Class Initialized
INFO - 2018-10-18 14:03:41 --> Security Class Initialized
DEBUG - 2018-10-18 14:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:03:41 --> CSRF cookie sent
INFO - 2018-10-18 14:03:41 --> Input Class Initialized
INFO - 2018-10-18 14:03:41 --> Language Class Initialized
INFO - 2018-10-18 14:03:41 --> Loader Class Initialized
INFO - 2018-10-18 14:03:41 --> Helper loaded: url_helper
INFO - 2018-10-18 14:03:41 --> Helper loaded: form_helper
INFO - 2018-10-18 14:03:41 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:03:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:03:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:03:41 --> User Agent Class Initialized
INFO - 2018-10-18 14:03:41 --> Controller Class Initialized
INFO - 2018-10-18 14:03:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:03:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:03:41 --> Pixel_Model class loaded
INFO - 2018-10-18 14:03:41 --> Database Driver Class Initialized
INFO - 2018-10-18 14:03:41 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:03:41 --> Database Driver Class Initialized
INFO - 2018-10-18 14:03:41 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:03:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:03:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:03:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:03:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:03:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:03:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:03:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/additional_business_info.php
INFO - 2018-10-18 14:03:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:03:41 --> Final output sent to browser
DEBUG - 2018-10-18 14:03:41 --> Total execution time: 0.4967
INFO - 2018-10-18 14:03:44 --> Config Class Initialized
INFO - 2018-10-18 14:03:44 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:03:44 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:03:44 --> Utf8 Class Initialized
INFO - 2018-10-18 14:03:44 --> URI Class Initialized
INFO - 2018-10-18 14:03:44 --> Router Class Initialized
INFO - 2018-10-18 14:03:44 --> Output Class Initialized
INFO - 2018-10-18 14:03:44 --> Security Class Initialized
DEBUG - 2018-10-18 14:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:03:44 --> CSRF cookie sent
INFO - 2018-10-18 14:03:44 --> Input Class Initialized
INFO - 2018-10-18 14:03:44 --> Language Class Initialized
INFO - 2018-10-18 14:03:44 --> Loader Class Initialized
INFO - 2018-10-18 14:03:44 --> Helper loaded: url_helper
INFO - 2018-10-18 14:03:44 --> Helper loaded: form_helper
INFO - 2018-10-18 14:03:44 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:03:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:03:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:03:44 --> User Agent Class Initialized
INFO - 2018-10-18 14:03:44 --> Controller Class Initialized
INFO - 2018-10-18 14:03:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:03:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:03:44 --> Pixel_Model class loaded
INFO - 2018-10-18 14:03:44 --> Database Driver Class Initialized
INFO - 2018-10-18 14:03:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:03:44 --> Database Driver Class Initialized
INFO - 2018-10-18 14:03:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:03:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:03:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:03:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:03:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:03:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:03:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:03:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/affectionate_salutation.php
INFO - 2018-10-18 14:03:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:03:44 --> Final output sent to browser
DEBUG - 2018-10-18 14:03:44 --> Total execution time: 0.5212
INFO - 2018-10-18 14:03:49 --> Config Class Initialized
INFO - 2018-10-18 14:03:49 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:03:49 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:03:49 --> Utf8 Class Initialized
INFO - 2018-10-18 14:03:49 --> URI Class Initialized
INFO - 2018-10-18 14:03:49 --> Router Class Initialized
INFO - 2018-10-18 14:03:49 --> Output Class Initialized
INFO - 2018-10-18 14:03:49 --> Security Class Initialized
DEBUG - 2018-10-18 14:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:03:49 --> CSRF cookie sent
INFO - 2018-10-18 14:03:49 --> Input Class Initialized
INFO - 2018-10-18 14:03:49 --> Language Class Initialized
ERROR - 2018-10-18 14:03:49 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 14:04:00 --> Config Class Initialized
INFO - 2018-10-18 14:04:00 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:04:00 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:04:00 --> Utf8 Class Initialized
INFO - 2018-10-18 14:04:00 --> URI Class Initialized
INFO - 2018-10-18 14:04:00 --> Router Class Initialized
INFO - 2018-10-18 14:04:00 --> Output Class Initialized
INFO - 2018-10-18 14:04:00 --> Security Class Initialized
DEBUG - 2018-10-18 14:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:04:00 --> CSRF cookie sent
INFO - 2018-10-18 14:04:00 --> CSRF token verified
INFO - 2018-10-18 14:04:00 --> Input Class Initialized
INFO - 2018-10-18 14:04:00 --> Language Class Initialized
INFO - 2018-10-18 14:04:00 --> Loader Class Initialized
INFO - 2018-10-18 14:04:00 --> Helper loaded: url_helper
INFO - 2018-10-18 14:04:00 --> Helper loaded: form_helper
INFO - 2018-10-18 14:04:00 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:04:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:04:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:04:00 --> User Agent Class Initialized
INFO - 2018-10-18 14:04:00 --> Controller Class Initialized
INFO - 2018-10-18 14:04:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:04:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:04:00 --> Pixel_Model class loaded
INFO - 2018-10-18 14:04:00 --> Database Driver Class Initialized
INFO - 2018-10-18 14:04:00 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:04:00 --> Form Validation Class Initialized
INFO - 2018-10-18 14:04:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 14:04:00 --> Database Driver Class Initialized
INFO - 2018-10-18 14:04:00 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:04:01 --> Config Class Initialized
INFO - 2018-10-18 14:04:01 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:04:01 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:04:01 --> Utf8 Class Initialized
INFO - 2018-10-18 14:04:01 --> URI Class Initialized
INFO - 2018-10-18 14:04:01 --> Router Class Initialized
INFO - 2018-10-18 14:04:01 --> Output Class Initialized
INFO - 2018-10-18 14:04:01 --> Security Class Initialized
DEBUG - 2018-10-18 14:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:04:01 --> CSRF cookie sent
INFO - 2018-10-18 14:04:01 --> Input Class Initialized
INFO - 2018-10-18 14:04:01 --> Language Class Initialized
INFO - 2018-10-18 14:04:01 --> Loader Class Initialized
INFO - 2018-10-18 14:04:01 --> Helper loaded: url_helper
INFO - 2018-10-18 14:04:01 --> Helper loaded: form_helper
INFO - 2018-10-18 14:04:01 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:04:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:04:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:04:01 --> User Agent Class Initialized
INFO - 2018-10-18 14:04:01 --> Controller Class Initialized
INFO - 2018-10-18 14:04:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:04:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:04:01 --> Pixel_Model class loaded
INFO - 2018-10-18 14:04:01 --> Database Driver Class Initialized
INFO - 2018-10-18 14:04:01 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:04:01 --> Database Driver Class Initialized
INFO - 2018-10-18 14:04:01 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:04:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:04:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:04:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:04:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:04:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:04:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:04:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/additional_business_info.php
INFO - 2018-10-18 14:04:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:04:01 --> Final output sent to browser
DEBUG - 2018-10-18 14:04:01 --> Total execution time: 0.5472
INFO - 2018-10-18 14:04:01 --> Config Class Initialized
INFO - 2018-10-18 14:04:01 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:04:01 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:04:01 --> Utf8 Class Initialized
INFO - 2018-10-18 14:04:01 --> URI Class Initialized
INFO - 2018-10-18 14:04:01 --> Router Class Initialized
INFO - 2018-10-18 14:04:01 --> Output Class Initialized
INFO - 2018-10-18 14:04:01 --> Security Class Initialized
DEBUG - 2018-10-18 14:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:04:01 --> CSRF cookie sent
INFO - 2018-10-18 14:04:02 --> Input Class Initialized
INFO - 2018-10-18 14:04:02 --> Language Class Initialized
ERROR - 2018-10-18 14:04:02 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 14:04:02 --> Config Class Initialized
INFO - 2018-10-18 14:04:02 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:04:02 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:04:02 --> Utf8 Class Initialized
INFO - 2018-10-18 14:04:02 --> URI Class Initialized
INFO - 2018-10-18 14:04:02 --> Router Class Initialized
INFO - 2018-10-18 14:04:02 --> Output Class Initialized
INFO - 2018-10-18 14:04:02 --> Security Class Initialized
DEBUG - 2018-10-18 14:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:04:02 --> CSRF cookie sent
INFO - 2018-10-18 14:04:03 --> CSRF token verified
INFO - 2018-10-18 14:04:03 --> Input Class Initialized
INFO - 2018-10-18 14:04:03 --> Language Class Initialized
INFO - 2018-10-18 14:04:03 --> Loader Class Initialized
INFO - 2018-10-18 14:04:03 --> Helper loaded: url_helper
INFO - 2018-10-18 14:04:03 --> Helper loaded: form_helper
INFO - 2018-10-18 14:04:03 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:04:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:04:03 --> User Agent Class Initialized
INFO - 2018-10-18 14:04:03 --> Controller Class Initialized
INFO - 2018-10-18 14:04:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:04:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:04:03 --> Pixel_Model class loaded
INFO - 2018-10-18 14:04:03 --> Database Driver Class Initialized
INFO - 2018-10-18 14:04:03 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:04:03 --> Form Validation Class Initialized
INFO - 2018-10-18 14:04:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 14:04:03 --> Database Driver Class Initialized
INFO - 2018-10-18 14:04:03 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:04:03 --> Config Class Initialized
INFO - 2018-10-18 14:04:03 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:04:03 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:04:03 --> Utf8 Class Initialized
INFO - 2018-10-18 14:04:03 --> URI Class Initialized
INFO - 2018-10-18 14:04:03 --> Router Class Initialized
INFO - 2018-10-18 14:04:03 --> Output Class Initialized
INFO - 2018-10-18 14:04:03 --> Security Class Initialized
DEBUG - 2018-10-18 14:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:04:03 --> CSRF cookie sent
INFO - 2018-10-18 14:04:03 --> Input Class Initialized
INFO - 2018-10-18 14:04:03 --> Language Class Initialized
INFO - 2018-10-18 14:04:03 --> Loader Class Initialized
INFO - 2018-10-18 14:04:03 --> Helper loaded: url_helper
INFO - 2018-10-18 14:04:03 --> Helper loaded: form_helper
INFO - 2018-10-18 14:04:03 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:04:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:04:03 --> User Agent Class Initialized
INFO - 2018-10-18 14:04:03 --> Controller Class Initialized
INFO - 2018-10-18 14:04:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:04:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:04:03 --> Pixel_Model class loaded
INFO - 2018-10-18 14:04:03 --> Database Driver Class Initialized
INFO - 2018-10-18 14:04:03 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:04:03 --> Database Driver Class Initialized
INFO - 2018-10-18 14:04:03 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:04:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:04:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:04:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:04:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:04:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:04:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:04:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/business_tax_info.php
INFO - 2018-10-18 14:04:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:04:03 --> Final output sent to browser
DEBUG - 2018-10-18 14:04:03 --> Total execution time: 0.5484
INFO - 2018-10-18 14:04:04 --> Config Class Initialized
INFO - 2018-10-18 14:04:04 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:04:04 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:04:04 --> Utf8 Class Initialized
INFO - 2018-10-18 14:04:04 --> URI Class Initialized
INFO - 2018-10-18 14:04:04 --> Router Class Initialized
INFO - 2018-10-18 14:04:04 --> Output Class Initialized
INFO - 2018-10-18 14:04:04 --> Security Class Initialized
DEBUG - 2018-10-18 14:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:04:04 --> CSRF cookie sent
INFO - 2018-10-18 14:04:04 --> Input Class Initialized
INFO - 2018-10-18 14:04:04 --> Language Class Initialized
ERROR - 2018-10-18 14:04:04 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 14:04:07 --> Config Class Initialized
INFO - 2018-10-18 14:04:07 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:04:07 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:04:07 --> Utf8 Class Initialized
INFO - 2018-10-18 14:04:07 --> URI Class Initialized
INFO - 2018-10-18 14:04:07 --> Router Class Initialized
INFO - 2018-10-18 14:04:07 --> Output Class Initialized
INFO - 2018-10-18 14:04:07 --> Security Class Initialized
DEBUG - 2018-10-18 14:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:04:07 --> CSRF cookie sent
INFO - 2018-10-18 14:04:07 --> CSRF token verified
INFO - 2018-10-18 14:04:07 --> Input Class Initialized
INFO - 2018-10-18 14:04:07 --> Language Class Initialized
INFO - 2018-10-18 14:04:07 --> Loader Class Initialized
INFO - 2018-10-18 14:04:07 --> Helper loaded: url_helper
INFO - 2018-10-18 14:04:07 --> Helper loaded: form_helper
INFO - 2018-10-18 14:04:07 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:04:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:04:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:04:07 --> User Agent Class Initialized
INFO - 2018-10-18 14:04:07 --> Controller Class Initialized
INFO - 2018-10-18 14:04:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:04:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:04:08 --> Pixel_Model class loaded
INFO - 2018-10-18 14:04:08 --> Database Driver Class Initialized
INFO - 2018-10-18 14:04:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:04:08 --> Form Validation Class Initialized
INFO - 2018-10-18 14:04:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 14:04:08 --> Database Driver Class Initialized
INFO - 2018-10-18 14:04:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:04:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:04:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:04:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:04:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:04:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:04:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_errors.php
INFO - 2018-10-18 14:04:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:04:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/business_tax_info.php
INFO - 2018-10-18 14:04:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:04:08 --> Final output sent to browser
DEBUG - 2018-10-18 14:04:08 --> Total execution time: 0.6412
INFO - 2018-10-18 14:04:08 --> Config Class Initialized
INFO - 2018-10-18 14:04:08 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:04:08 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:04:08 --> Utf8 Class Initialized
INFO - 2018-10-18 14:04:08 --> URI Class Initialized
INFO - 2018-10-18 14:04:08 --> Router Class Initialized
INFO - 2018-10-18 14:04:08 --> Output Class Initialized
INFO - 2018-10-18 14:04:08 --> Security Class Initialized
DEBUG - 2018-10-18 14:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:04:08 --> CSRF cookie sent
INFO - 2018-10-18 14:04:08 --> Input Class Initialized
INFO - 2018-10-18 14:04:08 --> Language Class Initialized
ERROR - 2018-10-18 14:04:08 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 14:04:12 --> Config Class Initialized
INFO - 2018-10-18 14:04:12 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:04:12 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:04:12 --> Utf8 Class Initialized
INFO - 2018-10-18 14:04:12 --> URI Class Initialized
INFO - 2018-10-18 14:04:12 --> Router Class Initialized
INFO - 2018-10-18 14:04:12 --> Output Class Initialized
INFO - 2018-10-18 14:04:12 --> Security Class Initialized
DEBUG - 2018-10-18 14:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:04:12 --> CSRF cookie sent
INFO - 2018-10-18 14:04:12 --> CSRF token verified
INFO - 2018-10-18 14:04:12 --> Input Class Initialized
INFO - 2018-10-18 14:04:12 --> Language Class Initialized
INFO - 2018-10-18 14:04:12 --> Loader Class Initialized
INFO - 2018-10-18 14:04:12 --> Helper loaded: url_helper
INFO - 2018-10-18 14:04:12 --> Helper loaded: form_helper
INFO - 2018-10-18 14:04:12 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:04:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:04:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:04:12 --> User Agent Class Initialized
INFO - 2018-10-18 14:04:12 --> Controller Class Initialized
INFO - 2018-10-18 14:04:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:04:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:04:12 --> Pixel_Model class loaded
INFO - 2018-10-18 14:04:12 --> Database Driver Class Initialized
INFO - 2018-10-18 14:04:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:04:12 --> Form Validation Class Initialized
INFO - 2018-10-18 14:04:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 14:04:12 --> Database Driver Class Initialized
INFO - 2018-10-18 14:04:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:04:12 --> Config Class Initialized
INFO - 2018-10-18 14:04:12 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:04:12 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:04:12 --> Utf8 Class Initialized
INFO - 2018-10-18 14:04:12 --> URI Class Initialized
INFO - 2018-10-18 14:04:12 --> Router Class Initialized
INFO - 2018-10-18 14:04:13 --> Output Class Initialized
INFO - 2018-10-18 14:04:13 --> Security Class Initialized
DEBUG - 2018-10-18 14:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:04:13 --> CSRF cookie sent
INFO - 2018-10-18 14:04:13 --> Input Class Initialized
INFO - 2018-10-18 14:04:13 --> Language Class Initialized
INFO - 2018-10-18 14:04:13 --> Loader Class Initialized
INFO - 2018-10-18 14:04:13 --> Helper loaded: url_helper
INFO - 2018-10-18 14:04:13 --> Helper loaded: form_helper
INFO - 2018-10-18 14:04:13 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:04:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:04:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:04:13 --> User Agent Class Initialized
INFO - 2018-10-18 14:04:13 --> Controller Class Initialized
INFO - 2018-10-18 14:04:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:04:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:04:13 --> Pixel_Model class loaded
INFO - 2018-10-18 14:04:13 --> Database Driver Class Initialized
INFO - 2018-10-18 14:04:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:04:13 --> Database Driver Class Initialized
INFO - 2018-10-18 14:04:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:04:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:04:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:04:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:04:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:04:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:04:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:04:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/trust_info.php
INFO - 2018-10-18 14:04:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:04:13 --> Final output sent to browser
DEBUG - 2018-10-18 14:04:13 --> Total execution time: 0.5617
INFO - 2018-10-18 14:04:13 --> Config Class Initialized
INFO - 2018-10-18 14:04:13 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:04:13 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:04:13 --> Utf8 Class Initialized
INFO - 2018-10-18 14:04:13 --> URI Class Initialized
INFO - 2018-10-18 14:04:13 --> Router Class Initialized
INFO - 2018-10-18 14:04:13 --> Output Class Initialized
INFO - 2018-10-18 14:04:13 --> Security Class Initialized
DEBUG - 2018-10-18 14:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:04:13 --> CSRF cookie sent
INFO - 2018-10-18 14:04:13 --> Input Class Initialized
INFO - 2018-10-18 14:04:13 --> Language Class Initialized
ERROR - 2018-10-18 14:04:13 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 14:04:17 --> Config Class Initialized
INFO - 2018-10-18 14:04:17 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:04:17 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:04:18 --> Utf8 Class Initialized
INFO - 2018-10-18 14:04:18 --> URI Class Initialized
INFO - 2018-10-18 14:04:18 --> Router Class Initialized
INFO - 2018-10-18 14:04:18 --> Output Class Initialized
INFO - 2018-10-18 14:04:18 --> Security Class Initialized
DEBUG - 2018-10-18 14:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:04:18 --> CSRF cookie sent
INFO - 2018-10-18 14:04:18 --> CSRF token verified
INFO - 2018-10-18 14:04:18 --> Input Class Initialized
INFO - 2018-10-18 14:04:18 --> Language Class Initialized
INFO - 2018-10-18 14:04:18 --> Loader Class Initialized
INFO - 2018-10-18 14:04:18 --> Helper loaded: url_helper
INFO - 2018-10-18 14:04:18 --> Helper loaded: form_helper
INFO - 2018-10-18 14:04:18 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:04:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:04:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:04:18 --> User Agent Class Initialized
INFO - 2018-10-18 14:04:18 --> Controller Class Initialized
INFO - 2018-10-18 14:04:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:04:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:04:18 --> Pixel_Model class loaded
INFO - 2018-10-18 14:04:18 --> Database Driver Class Initialized
INFO - 2018-10-18 14:04:18 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:04:18 --> Form Validation Class Initialized
INFO - 2018-10-18 14:04:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 14:04:18 --> Database Driver Class Initialized
INFO - 2018-10-18 14:04:18 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:04:18 --> Config Class Initialized
INFO - 2018-10-18 14:04:18 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:04:18 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:04:18 --> Utf8 Class Initialized
INFO - 2018-10-18 14:04:18 --> URI Class Initialized
INFO - 2018-10-18 14:04:18 --> Router Class Initialized
INFO - 2018-10-18 14:04:18 --> Output Class Initialized
INFO - 2018-10-18 14:04:18 --> Security Class Initialized
DEBUG - 2018-10-18 14:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:04:18 --> CSRF cookie sent
INFO - 2018-10-18 14:04:18 --> Input Class Initialized
INFO - 2018-10-18 14:04:18 --> Language Class Initialized
INFO - 2018-10-18 14:04:18 --> Loader Class Initialized
INFO - 2018-10-18 14:04:18 --> Helper loaded: url_helper
INFO - 2018-10-18 14:04:18 --> Helper loaded: form_helper
INFO - 2018-10-18 14:04:18 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:04:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:04:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:04:18 --> User Agent Class Initialized
INFO - 2018-10-18 14:04:18 --> Controller Class Initialized
INFO - 2018-10-18 14:04:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:04:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:04:18 --> Pixel_Model class loaded
INFO - 2018-10-18 14:04:18 --> Database Driver Class Initialized
INFO - 2018-10-18 14:04:18 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:04:18 --> Database Driver Class Initialized
INFO - 2018-10-18 14:04:18 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:04:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:04:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:04:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:04:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:04:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:04:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:04:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/inherited_income.php
INFO - 2018-10-18 14:04:19 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:04:19 --> Final output sent to browser
DEBUG - 2018-10-18 14:04:19 --> Total execution time: 0.5432
INFO - 2018-10-18 14:04:19 --> Config Class Initialized
INFO - 2018-10-18 14:04:19 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:04:19 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:04:19 --> Utf8 Class Initialized
INFO - 2018-10-18 14:04:19 --> URI Class Initialized
INFO - 2018-10-18 14:04:19 --> Router Class Initialized
INFO - 2018-10-18 14:04:19 --> Output Class Initialized
INFO - 2018-10-18 14:04:19 --> Security Class Initialized
DEBUG - 2018-10-18 14:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:04:19 --> CSRF cookie sent
INFO - 2018-10-18 14:04:19 --> Input Class Initialized
INFO - 2018-10-18 14:04:19 --> Language Class Initialized
ERROR - 2018-10-18 14:04:19 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 14:04:20 --> Config Class Initialized
INFO - 2018-10-18 14:04:20 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:04:20 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:04:20 --> Utf8 Class Initialized
INFO - 2018-10-18 14:04:20 --> URI Class Initialized
INFO - 2018-10-18 14:04:20 --> Router Class Initialized
INFO - 2018-10-18 14:04:20 --> Output Class Initialized
INFO - 2018-10-18 14:04:21 --> Security Class Initialized
DEBUG - 2018-10-18 14:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:04:21 --> CSRF cookie sent
INFO - 2018-10-18 14:04:21 --> CSRF token verified
INFO - 2018-10-18 14:04:21 --> Input Class Initialized
INFO - 2018-10-18 14:04:21 --> Language Class Initialized
INFO - 2018-10-18 14:04:21 --> Loader Class Initialized
INFO - 2018-10-18 14:04:21 --> Helper loaded: url_helper
INFO - 2018-10-18 14:04:21 --> Helper loaded: form_helper
INFO - 2018-10-18 14:04:21 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:04:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:04:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:04:21 --> User Agent Class Initialized
INFO - 2018-10-18 14:04:21 --> Controller Class Initialized
INFO - 2018-10-18 14:04:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:04:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:04:21 --> Pixel_Model class loaded
INFO - 2018-10-18 14:04:21 --> Database Driver Class Initialized
INFO - 2018-10-18 14:04:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:04:21 --> Form Validation Class Initialized
INFO - 2018-10-18 14:04:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 14:04:21 --> Database Driver Class Initialized
INFO - 2018-10-18 14:04:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:04:21 --> Config Class Initialized
INFO - 2018-10-18 14:04:21 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:04:21 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:04:21 --> Utf8 Class Initialized
INFO - 2018-10-18 14:04:21 --> URI Class Initialized
INFO - 2018-10-18 14:04:21 --> Router Class Initialized
INFO - 2018-10-18 14:04:21 --> Output Class Initialized
INFO - 2018-10-18 14:04:21 --> Security Class Initialized
DEBUG - 2018-10-18 14:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:04:21 --> CSRF cookie sent
INFO - 2018-10-18 14:04:21 --> Input Class Initialized
INFO - 2018-10-18 14:04:21 --> Language Class Initialized
INFO - 2018-10-18 14:04:21 --> Loader Class Initialized
INFO - 2018-10-18 14:04:21 --> Helper loaded: url_helper
INFO - 2018-10-18 14:04:21 --> Helper loaded: form_helper
INFO - 2018-10-18 14:04:21 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:04:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:04:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:04:21 --> User Agent Class Initialized
INFO - 2018-10-18 14:04:21 --> Controller Class Initialized
INFO - 2018-10-18 14:04:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:04:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:04:21 --> Pixel_Model class loaded
INFO - 2018-10-18 14:04:21 --> Database Driver Class Initialized
INFO - 2018-10-18 14:04:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:04:21 --> Database Driver Class Initialized
INFO - 2018-10-18 14:04:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:04:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:04:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:04:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:04:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:04:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:04:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:04:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/shift_work.php
INFO - 2018-10-18 14:04:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:04:21 --> Final output sent to browser
DEBUG - 2018-10-18 14:04:22 --> Total execution time: 0.5400
INFO - 2018-10-18 14:04:22 --> Config Class Initialized
INFO - 2018-10-18 14:04:22 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:04:22 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:04:22 --> Utf8 Class Initialized
INFO - 2018-10-18 14:04:22 --> URI Class Initialized
INFO - 2018-10-18 14:04:22 --> Router Class Initialized
INFO - 2018-10-18 14:04:22 --> Output Class Initialized
INFO - 2018-10-18 14:04:22 --> Security Class Initialized
DEBUG - 2018-10-18 14:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:04:22 --> CSRF cookie sent
INFO - 2018-10-18 14:04:22 --> Input Class Initialized
INFO - 2018-10-18 14:04:22 --> Language Class Initialized
ERROR - 2018-10-18 14:04:22 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 14:04:23 --> Config Class Initialized
INFO - 2018-10-18 14:04:23 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:04:23 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:04:23 --> Utf8 Class Initialized
INFO - 2018-10-18 14:04:23 --> URI Class Initialized
INFO - 2018-10-18 14:04:23 --> Router Class Initialized
INFO - 2018-10-18 14:04:23 --> Output Class Initialized
INFO - 2018-10-18 14:04:23 --> Security Class Initialized
DEBUG - 2018-10-18 14:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:04:23 --> CSRF cookie sent
INFO - 2018-10-18 14:04:23 --> CSRF token verified
INFO - 2018-10-18 14:04:23 --> Input Class Initialized
INFO - 2018-10-18 14:04:23 --> Language Class Initialized
INFO - 2018-10-18 14:04:23 --> Loader Class Initialized
INFO - 2018-10-18 14:04:23 --> Helper loaded: url_helper
INFO - 2018-10-18 14:04:23 --> Helper loaded: form_helper
INFO - 2018-10-18 14:04:23 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:04:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:04:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:04:23 --> User Agent Class Initialized
INFO - 2018-10-18 14:04:23 --> Controller Class Initialized
INFO - 2018-10-18 14:04:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:04:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:04:24 --> Pixel_Model class loaded
INFO - 2018-10-18 14:04:24 --> Database Driver Class Initialized
INFO - 2018-10-18 14:04:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:04:24 --> Form Validation Class Initialized
INFO - 2018-10-18 14:04:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 14:04:24 --> Database Driver Class Initialized
INFO - 2018-10-18 14:04:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:04:24 --> Config Class Initialized
INFO - 2018-10-18 14:04:24 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:04:24 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:04:24 --> Utf8 Class Initialized
INFO - 2018-10-18 14:04:24 --> URI Class Initialized
INFO - 2018-10-18 14:04:24 --> Router Class Initialized
INFO - 2018-10-18 14:04:24 --> Output Class Initialized
INFO - 2018-10-18 14:04:24 --> Security Class Initialized
DEBUG - 2018-10-18 14:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:04:24 --> CSRF cookie sent
INFO - 2018-10-18 14:04:24 --> Input Class Initialized
INFO - 2018-10-18 14:04:24 --> Language Class Initialized
INFO - 2018-10-18 14:04:24 --> Loader Class Initialized
INFO - 2018-10-18 14:04:24 --> Helper loaded: url_helper
INFO - 2018-10-18 14:04:24 --> Helper loaded: form_helper
INFO - 2018-10-18 14:04:24 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:04:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:04:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:04:24 --> User Agent Class Initialized
INFO - 2018-10-18 14:04:24 --> Controller Class Initialized
INFO - 2018-10-18 14:04:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:04:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:04:24 --> Pixel_Model class loaded
INFO - 2018-10-18 14:04:24 --> Database Driver Class Initialized
INFO - 2018-10-18 14:04:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:04:24 --> Database Driver Class Initialized
INFO - 2018-10-18 14:04:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:04:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:04:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:04:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:04:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:04:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:04:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:04:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/night_without_s.php
INFO - 2018-10-18 14:04:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:04:24 --> Final output sent to browser
DEBUG - 2018-10-18 14:04:24 --> Total execution time: 0.5408
INFO - 2018-10-18 14:04:25 --> Config Class Initialized
INFO - 2018-10-18 14:04:25 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:04:25 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:04:25 --> Utf8 Class Initialized
INFO - 2018-10-18 14:04:25 --> URI Class Initialized
INFO - 2018-10-18 14:04:25 --> Router Class Initialized
INFO - 2018-10-18 14:04:25 --> Output Class Initialized
INFO - 2018-10-18 14:04:25 --> Security Class Initialized
DEBUG - 2018-10-18 14:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:04:25 --> CSRF cookie sent
INFO - 2018-10-18 14:04:25 --> Input Class Initialized
INFO - 2018-10-18 14:04:25 --> Language Class Initialized
ERROR - 2018-10-18 14:04:25 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 14:04:27 --> Config Class Initialized
INFO - 2018-10-18 14:04:27 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:04:27 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:04:27 --> Utf8 Class Initialized
INFO - 2018-10-18 14:04:27 --> URI Class Initialized
INFO - 2018-10-18 14:04:27 --> Router Class Initialized
INFO - 2018-10-18 14:04:27 --> Output Class Initialized
INFO - 2018-10-18 14:04:27 --> Security Class Initialized
DEBUG - 2018-10-18 14:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:04:27 --> CSRF cookie sent
INFO - 2018-10-18 14:04:27 --> CSRF token verified
INFO - 2018-10-18 14:04:27 --> Input Class Initialized
INFO - 2018-10-18 14:04:27 --> Language Class Initialized
INFO - 2018-10-18 14:04:27 --> Loader Class Initialized
INFO - 2018-10-18 14:04:27 --> Helper loaded: url_helper
INFO - 2018-10-18 14:04:27 --> Helper loaded: form_helper
INFO - 2018-10-18 14:04:28 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:04:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:04:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:04:28 --> User Agent Class Initialized
INFO - 2018-10-18 14:04:28 --> Controller Class Initialized
INFO - 2018-10-18 14:04:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:04:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:04:28 --> Pixel_Model class loaded
INFO - 2018-10-18 14:04:28 --> Database Driver Class Initialized
INFO - 2018-10-18 14:04:28 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:04:28 --> Form Validation Class Initialized
INFO - 2018-10-18 14:04:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 14:04:28 --> Database Driver Class Initialized
INFO - 2018-10-18 14:04:28 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:04:28 --> Config Class Initialized
INFO - 2018-10-18 14:04:28 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:04:28 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:04:28 --> Utf8 Class Initialized
INFO - 2018-10-18 14:04:28 --> URI Class Initialized
INFO - 2018-10-18 14:04:28 --> Router Class Initialized
INFO - 2018-10-18 14:04:28 --> Output Class Initialized
INFO - 2018-10-18 14:04:28 --> Security Class Initialized
DEBUG - 2018-10-18 14:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:04:28 --> CSRF cookie sent
INFO - 2018-10-18 14:04:28 --> Input Class Initialized
INFO - 2018-10-18 14:04:28 --> Language Class Initialized
INFO - 2018-10-18 14:04:28 --> Loader Class Initialized
INFO - 2018-10-18 14:04:28 --> Helper loaded: url_helper
INFO - 2018-10-18 14:04:28 --> Helper loaded: form_helper
INFO - 2018-10-18 14:04:28 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:04:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:04:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:04:28 --> User Agent Class Initialized
INFO - 2018-10-18 14:04:28 --> Controller Class Initialized
INFO - 2018-10-18 14:04:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:04:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:04:28 --> Pixel_Model class loaded
INFO - 2018-10-18 14:04:28 --> Database Driver Class Initialized
INFO - 2018-10-18 14:04:28 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:04:28 --> Database Driver Class Initialized
INFO - 2018-10-18 14:04:28 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:04:28 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:04:28 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:04:28 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:04:28 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:04:28 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:04:28 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:04:28 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/have_date.php
INFO - 2018-10-18 14:04:28 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:04:28 --> Final output sent to browser
DEBUG - 2018-10-18 14:04:28 --> Total execution time: 0.5438
INFO - 2018-10-18 14:04:29 --> Config Class Initialized
INFO - 2018-10-18 14:04:29 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:04:29 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:04:29 --> Utf8 Class Initialized
INFO - 2018-10-18 14:04:29 --> URI Class Initialized
INFO - 2018-10-18 14:04:29 --> Router Class Initialized
INFO - 2018-10-18 14:04:29 --> Output Class Initialized
INFO - 2018-10-18 14:04:29 --> Security Class Initialized
DEBUG - 2018-10-18 14:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:04:29 --> CSRF cookie sent
INFO - 2018-10-18 14:04:29 --> Input Class Initialized
INFO - 2018-10-18 14:04:29 --> Language Class Initialized
ERROR - 2018-10-18 14:04:29 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 14:04:30 --> Config Class Initialized
INFO - 2018-10-18 14:04:30 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:04:30 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:04:30 --> Utf8 Class Initialized
INFO - 2018-10-18 14:04:30 --> URI Class Initialized
INFO - 2018-10-18 14:04:30 --> Router Class Initialized
INFO - 2018-10-18 14:04:30 --> Output Class Initialized
INFO - 2018-10-18 14:04:31 --> Security Class Initialized
DEBUG - 2018-10-18 14:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:04:31 --> CSRF cookie sent
INFO - 2018-10-18 14:04:31 --> CSRF token verified
INFO - 2018-10-18 14:04:31 --> Input Class Initialized
INFO - 2018-10-18 14:04:31 --> Language Class Initialized
INFO - 2018-10-18 14:04:31 --> Loader Class Initialized
INFO - 2018-10-18 14:04:31 --> Helper loaded: url_helper
INFO - 2018-10-18 14:04:31 --> Helper loaded: form_helper
INFO - 2018-10-18 14:04:31 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:04:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:04:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:04:31 --> User Agent Class Initialized
INFO - 2018-10-18 14:04:31 --> Controller Class Initialized
INFO - 2018-10-18 14:04:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:04:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:04:31 --> Pixel_Model class loaded
INFO - 2018-10-18 14:04:31 --> Database Driver Class Initialized
INFO - 2018-10-18 14:04:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:04:31 --> Form Validation Class Initialized
INFO - 2018-10-18 14:04:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 14:04:31 --> Database Driver Class Initialized
INFO - 2018-10-18 14:04:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:04:31 --> Config Class Initialized
INFO - 2018-10-18 14:04:31 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:04:31 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:04:31 --> Utf8 Class Initialized
INFO - 2018-10-18 14:04:31 --> URI Class Initialized
INFO - 2018-10-18 14:04:31 --> Router Class Initialized
INFO - 2018-10-18 14:04:31 --> Output Class Initialized
INFO - 2018-10-18 14:04:31 --> Security Class Initialized
DEBUG - 2018-10-18 14:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:04:31 --> CSRF cookie sent
INFO - 2018-10-18 14:04:31 --> Input Class Initialized
INFO - 2018-10-18 14:04:31 --> Language Class Initialized
INFO - 2018-10-18 14:04:31 --> Loader Class Initialized
INFO - 2018-10-18 14:04:31 --> Helper loaded: url_helper
INFO - 2018-10-18 14:04:31 --> Helper loaded: form_helper
INFO - 2018-10-18 14:04:31 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:04:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:04:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:04:31 --> User Agent Class Initialized
INFO - 2018-10-18 14:04:31 --> Controller Class Initialized
INFO - 2018-10-18 14:04:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:04:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:04:31 --> Pixel_Model class loaded
INFO - 2018-10-18 14:04:31 --> Database Driver Class Initialized
INFO - 2018-10-18 14:04:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:04:31 --> Database Driver Class Initialized
INFO - 2018-10-18 14:04:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:04:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:04:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:04:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:04:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:04:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:04:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:04:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/nights_not_home.php
INFO - 2018-10-18 14:04:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:04:31 --> Final output sent to browser
DEBUG - 2018-10-18 14:04:32 --> Total execution time: 0.5371
INFO - 2018-10-18 14:04:32 --> Config Class Initialized
INFO - 2018-10-18 14:04:32 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:04:32 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:04:32 --> Utf8 Class Initialized
INFO - 2018-10-18 14:04:32 --> URI Class Initialized
INFO - 2018-10-18 14:04:32 --> Router Class Initialized
INFO - 2018-10-18 14:04:32 --> Output Class Initialized
INFO - 2018-10-18 14:04:32 --> Security Class Initialized
DEBUG - 2018-10-18 14:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:04:32 --> CSRF cookie sent
INFO - 2018-10-18 14:04:32 --> Input Class Initialized
INFO - 2018-10-18 14:04:32 --> Language Class Initialized
ERROR - 2018-10-18 14:04:32 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 14:04:34 --> Config Class Initialized
INFO - 2018-10-18 14:04:34 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:04:34 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:04:34 --> Utf8 Class Initialized
INFO - 2018-10-18 14:04:34 --> URI Class Initialized
INFO - 2018-10-18 14:04:34 --> Router Class Initialized
INFO - 2018-10-18 14:04:34 --> Output Class Initialized
INFO - 2018-10-18 14:04:34 --> Security Class Initialized
DEBUG - 2018-10-18 14:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:04:34 --> CSRF cookie sent
INFO - 2018-10-18 14:04:34 --> CSRF token verified
INFO - 2018-10-18 14:04:34 --> Input Class Initialized
INFO - 2018-10-18 14:04:34 --> Language Class Initialized
INFO - 2018-10-18 14:04:34 --> Loader Class Initialized
INFO - 2018-10-18 14:04:34 --> Helper loaded: url_helper
INFO - 2018-10-18 14:04:34 --> Helper loaded: form_helper
INFO - 2018-10-18 14:04:34 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:04:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:04:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:04:34 --> User Agent Class Initialized
INFO - 2018-10-18 14:04:34 --> Controller Class Initialized
INFO - 2018-10-18 14:04:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:04:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:04:34 --> Pixel_Model class loaded
INFO - 2018-10-18 14:04:35 --> Database Driver Class Initialized
INFO - 2018-10-18 14:04:35 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:04:35 --> Form Validation Class Initialized
INFO - 2018-10-18 14:04:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 14:04:35 --> Database Driver Class Initialized
INFO - 2018-10-18 14:04:35 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:04:35 --> Config Class Initialized
INFO - 2018-10-18 14:04:35 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:04:35 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:04:35 --> Utf8 Class Initialized
INFO - 2018-10-18 14:04:35 --> URI Class Initialized
INFO - 2018-10-18 14:04:35 --> Router Class Initialized
INFO - 2018-10-18 14:04:35 --> Output Class Initialized
INFO - 2018-10-18 14:04:35 --> Security Class Initialized
DEBUG - 2018-10-18 14:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:04:35 --> CSRF cookie sent
INFO - 2018-10-18 14:04:35 --> Input Class Initialized
INFO - 2018-10-18 14:04:35 --> Language Class Initialized
INFO - 2018-10-18 14:04:35 --> Loader Class Initialized
INFO - 2018-10-18 14:04:35 --> Helper loaded: url_helper
INFO - 2018-10-18 14:04:35 --> Helper loaded: form_helper
INFO - 2018-10-18 14:04:35 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:04:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:04:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:04:35 --> User Agent Class Initialized
INFO - 2018-10-18 14:04:35 --> Controller Class Initialized
INFO - 2018-10-18 14:04:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:04:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:04:35 --> Pixel_Model class loaded
INFO - 2018-10-18 14:04:35 --> Database Driver Class Initialized
INFO - 2018-10-18 14:04:35 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:04:35 --> Database Driver Class Initialized
INFO - 2018-10-18 14:04:35 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:04:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:04:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:04:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:04:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:04:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:04:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:04:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/s_nights_not_home.php
INFO - 2018-10-18 14:04:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:04:35 --> Final output sent to browser
DEBUG - 2018-10-18 14:04:35 --> Total execution time: 0.5510
INFO - 2018-10-18 14:04:36 --> Config Class Initialized
INFO - 2018-10-18 14:04:36 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:04:36 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:04:36 --> Utf8 Class Initialized
INFO - 2018-10-18 14:04:36 --> URI Class Initialized
INFO - 2018-10-18 14:04:36 --> Router Class Initialized
INFO - 2018-10-18 14:04:36 --> Output Class Initialized
INFO - 2018-10-18 14:04:36 --> Security Class Initialized
DEBUG - 2018-10-18 14:04:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:04:36 --> CSRF cookie sent
INFO - 2018-10-18 14:04:36 --> Input Class Initialized
INFO - 2018-10-18 14:04:36 --> Language Class Initialized
ERROR - 2018-10-18 14:04:36 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 14:04:37 --> Config Class Initialized
INFO - 2018-10-18 14:04:37 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:04:37 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:04:37 --> Utf8 Class Initialized
INFO - 2018-10-18 14:04:37 --> URI Class Initialized
INFO - 2018-10-18 14:04:37 --> Router Class Initialized
INFO - 2018-10-18 14:04:37 --> Output Class Initialized
INFO - 2018-10-18 14:04:37 --> Security Class Initialized
DEBUG - 2018-10-18 14:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:04:37 --> CSRF cookie sent
INFO - 2018-10-18 14:04:37 --> CSRF token verified
INFO - 2018-10-18 14:04:37 --> Input Class Initialized
INFO - 2018-10-18 14:04:37 --> Language Class Initialized
INFO - 2018-10-18 14:04:37 --> Loader Class Initialized
INFO - 2018-10-18 14:04:37 --> Helper loaded: url_helper
INFO - 2018-10-18 14:04:37 --> Helper loaded: form_helper
INFO - 2018-10-18 14:04:37 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:04:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:04:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:04:37 --> User Agent Class Initialized
INFO - 2018-10-18 14:04:37 --> Controller Class Initialized
INFO - 2018-10-18 14:04:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:04:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:04:37 --> Pixel_Model class loaded
INFO - 2018-10-18 14:04:37 --> Database Driver Class Initialized
INFO - 2018-10-18 14:04:37 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:04:37 --> Form Validation Class Initialized
INFO - 2018-10-18 14:04:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 14:04:37 --> Database Driver Class Initialized
INFO - 2018-10-18 14:04:37 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:04:37 --> Config Class Initialized
INFO - 2018-10-18 14:04:37 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:04:38 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:04:38 --> Utf8 Class Initialized
INFO - 2018-10-18 14:04:38 --> URI Class Initialized
INFO - 2018-10-18 14:04:38 --> Router Class Initialized
INFO - 2018-10-18 14:04:38 --> Output Class Initialized
INFO - 2018-10-18 14:04:38 --> Security Class Initialized
DEBUG - 2018-10-18 14:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:04:38 --> CSRF cookie sent
INFO - 2018-10-18 14:04:38 --> Input Class Initialized
INFO - 2018-10-18 14:04:38 --> Language Class Initialized
INFO - 2018-10-18 14:04:38 --> Loader Class Initialized
INFO - 2018-10-18 14:04:38 --> Helper loaded: url_helper
INFO - 2018-10-18 14:04:38 --> Helper loaded: form_helper
INFO - 2018-10-18 14:04:38 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:04:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:04:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:04:38 --> User Agent Class Initialized
INFO - 2018-10-18 14:04:38 --> Controller Class Initialized
INFO - 2018-10-18 14:04:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:04:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:04:38 --> Pixel_Model class loaded
INFO - 2018-10-18 14:04:38 --> Database Driver Class Initialized
INFO - 2018-10-18 14:04:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:04:38 --> Database Driver Class Initialized
INFO - 2018-10-18 14:04:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:04:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:04:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:04:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:04:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:04:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:04:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:04:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/s_nights_without_you.php
INFO - 2018-10-18 14:04:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:04:38 --> Final output sent to browser
DEBUG - 2018-10-18 14:04:38 --> Total execution time: 0.5429
INFO - 2018-10-18 14:04:38 --> Config Class Initialized
INFO - 2018-10-18 14:04:38 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:04:38 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:04:38 --> Utf8 Class Initialized
INFO - 2018-10-18 14:04:38 --> URI Class Initialized
INFO - 2018-10-18 14:04:38 --> Router Class Initialized
INFO - 2018-10-18 14:04:38 --> Output Class Initialized
INFO - 2018-10-18 14:04:38 --> Security Class Initialized
DEBUG - 2018-10-18 14:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:04:38 --> CSRF cookie sent
INFO - 2018-10-18 14:04:38 --> Input Class Initialized
INFO - 2018-10-18 14:04:38 --> Language Class Initialized
ERROR - 2018-10-18 14:04:39 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 14:04:39 --> Config Class Initialized
INFO - 2018-10-18 14:04:39 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:04:39 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:04:39 --> Utf8 Class Initialized
INFO - 2018-10-18 14:04:39 --> URI Class Initialized
INFO - 2018-10-18 14:04:39 --> Router Class Initialized
INFO - 2018-10-18 14:04:39 --> Output Class Initialized
INFO - 2018-10-18 14:04:40 --> Security Class Initialized
DEBUG - 2018-10-18 14:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:04:40 --> CSRF cookie sent
INFO - 2018-10-18 14:04:40 --> CSRF token verified
INFO - 2018-10-18 14:04:40 --> Input Class Initialized
INFO - 2018-10-18 14:04:40 --> Language Class Initialized
INFO - 2018-10-18 14:04:40 --> Loader Class Initialized
INFO - 2018-10-18 14:04:40 --> Helper loaded: url_helper
INFO - 2018-10-18 14:04:40 --> Helper loaded: form_helper
INFO - 2018-10-18 14:04:40 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:04:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:04:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:04:40 --> User Agent Class Initialized
INFO - 2018-10-18 14:04:40 --> Controller Class Initialized
INFO - 2018-10-18 14:04:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:04:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:04:40 --> Pixel_Model class loaded
INFO - 2018-10-18 14:04:40 --> Database Driver Class Initialized
INFO - 2018-10-18 14:04:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:04:40 --> Form Validation Class Initialized
INFO - 2018-10-18 14:04:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 14:04:40 --> Database Driver Class Initialized
INFO - 2018-10-18 14:04:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:04:40 --> Config Class Initialized
INFO - 2018-10-18 14:04:40 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:04:40 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:04:40 --> Utf8 Class Initialized
INFO - 2018-10-18 14:04:40 --> URI Class Initialized
INFO - 2018-10-18 14:04:40 --> Router Class Initialized
INFO - 2018-10-18 14:04:40 --> Output Class Initialized
INFO - 2018-10-18 14:04:40 --> Security Class Initialized
DEBUG - 2018-10-18 14:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:04:40 --> CSRF cookie sent
INFO - 2018-10-18 14:04:40 --> Input Class Initialized
INFO - 2018-10-18 14:04:40 --> Language Class Initialized
INFO - 2018-10-18 14:04:40 --> Loader Class Initialized
INFO - 2018-10-18 14:04:40 --> Helper loaded: url_helper
INFO - 2018-10-18 14:04:40 --> Helper loaded: form_helper
INFO - 2018-10-18 14:04:40 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:04:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:04:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:04:40 --> User Agent Class Initialized
INFO - 2018-10-18 14:04:40 --> Controller Class Initialized
INFO - 2018-10-18 14:04:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:04:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:04:40 --> Pixel_Model class loaded
INFO - 2018-10-18 14:04:40 --> Database Driver Class Initialized
INFO - 2018-10-18 14:04:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:04:40 --> Database Driver Class Initialized
INFO - 2018-10-18 14:04:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:04:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:04:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:04:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:04:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:04:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:04:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:04:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/alcoholic_drinks_per_week.php
INFO - 2018-10-18 14:04:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:04:40 --> Final output sent to browser
DEBUG - 2018-10-18 14:04:41 --> Total execution time: 0.5582
INFO - 2018-10-18 14:04:41 --> Config Class Initialized
INFO - 2018-10-18 14:04:41 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:04:41 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:04:41 --> Utf8 Class Initialized
INFO - 2018-10-18 14:04:41 --> URI Class Initialized
INFO - 2018-10-18 14:04:41 --> Router Class Initialized
INFO - 2018-10-18 14:04:41 --> Output Class Initialized
INFO - 2018-10-18 14:04:41 --> Security Class Initialized
DEBUG - 2018-10-18 14:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:04:41 --> CSRF cookie sent
INFO - 2018-10-18 14:04:41 --> Input Class Initialized
INFO - 2018-10-18 14:04:41 --> Language Class Initialized
ERROR - 2018-10-18 14:04:41 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 14:04:43 --> Config Class Initialized
INFO - 2018-10-18 14:04:43 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:04:43 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:04:43 --> Utf8 Class Initialized
INFO - 2018-10-18 14:04:43 --> URI Class Initialized
INFO - 2018-10-18 14:04:43 --> Router Class Initialized
INFO - 2018-10-18 14:04:43 --> Output Class Initialized
INFO - 2018-10-18 14:04:43 --> Security Class Initialized
DEBUG - 2018-10-18 14:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:04:43 --> CSRF cookie sent
INFO - 2018-10-18 14:04:43 --> CSRF token verified
INFO - 2018-10-18 14:04:44 --> Input Class Initialized
INFO - 2018-10-18 14:04:44 --> Language Class Initialized
INFO - 2018-10-18 14:04:44 --> Loader Class Initialized
INFO - 2018-10-18 14:04:44 --> Helper loaded: url_helper
INFO - 2018-10-18 14:04:44 --> Helper loaded: form_helper
INFO - 2018-10-18 14:04:44 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:04:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:04:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:04:44 --> User Agent Class Initialized
INFO - 2018-10-18 14:04:44 --> Controller Class Initialized
INFO - 2018-10-18 14:04:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:04:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:04:44 --> Pixel_Model class loaded
INFO - 2018-10-18 14:04:44 --> Database Driver Class Initialized
INFO - 2018-10-18 14:04:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:04:44 --> Form Validation Class Initialized
INFO - 2018-10-18 14:04:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 14:04:44 --> Database Driver Class Initialized
INFO - 2018-10-18 14:04:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:04:44 --> Config Class Initialized
INFO - 2018-10-18 14:04:44 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:04:44 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:04:44 --> Utf8 Class Initialized
INFO - 2018-10-18 14:04:44 --> URI Class Initialized
INFO - 2018-10-18 14:04:44 --> Router Class Initialized
INFO - 2018-10-18 14:04:44 --> Output Class Initialized
INFO - 2018-10-18 14:04:44 --> Security Class Initialized
DEBUG - 2018-10-18 14:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:04:44 --> CSRF cookie sent
INFO - 2018-10-18 14:04:44 --> Input Class Initialized
INFO - 2018-10-18 14:04:44 --> Language Class Initialized
INFO - 2018-10-18 14:04:44 --> Loader Class Initialized
INFO - 2018-10-18 14:04:44 --> Helper loaded: url_helper
INFO - 2018-10-18 14:04:44 --> Helper loaded: form_helper
INFO - 2018-10-18 14:04:44 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:04:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:04:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:04:44 --> User Agent Class Initialized
INFO - 2018-10-18 14:04:44 --> Controller Class Initialized
INFO - 2018-10-18 14:04:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:04:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:04:44 --> Pixel_Model class loaded
INFO - 2018-10-18 14:04:44 --> Database Driver Class Initialized
INFO - 2018-10-18 14:04:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:04:44 --> Database Driver Class Initialized
INFO - 2018-10-18 14:04:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:04:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:04:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:04:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:04:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:04:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:04:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:04:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/have_drugs.php
INFO - 2018-10-18 14:04:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:04:44 --> Final output sent to browser
DEBUG - 2018-10-18 14:04:44 --> Total execution time: 0.5595
INFO - 2018-10-18 14:04:45 --> Config Class Initialized
INFO - 2018-10-18 14:04:45 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:04:45 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:04:45 --> Utf8 Class Initialized
INFO - 2018-10-18 14:04:45 --> URI Class Initialized
INFO - 2018-10-18 14:04:45 --> Router Class Initialized
INFO - 2018-10-18 14:04:45 --> Output Class Initialized
INFO - 2018-10-18 14:04:45 --> Security Class Initialized
DEBUG - 2018-10-18 14:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:04:45 --> CSRF cookie sent
INFO - 2018-10-18 14:04:45 --> Input Class Initialized
INFO - 2018-10-18 14:04:45 --> Language Class Initialized
ERROR - 2018-10-18 14:04:45 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 14:04:46 --> Config Class Initialized
INFO - 2018-10-18 14:04:46 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:04:46 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:04:46 --> Utf8 Class Initialized
INFO - 2018-10-18 14:04:46 --> URI Class Initialized
INFO - 2018-10-18 14:04:46 --> Router Class Initialized
INFO - 2018-10-18 14:04:46 --> Output Class Initialized
INFO - 2018-10-18 14:04:46 --> Security Class Initialized
DEBUG - 2018-10-18 14:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:04:46 --> CSRF cookie sent
INFO - 2018-10-18 14:04:46 --> CSRF token verified
INFO - 2018-10-18 14:04:46 --> Input Class Initialized
INFO - 2018-10-18 14:04:46 --> Language Class Initialized
INFO - 2018-10-18 14:04:46 --> Loader Class Initialized
INFO - 2018-10-18 14:04:46 --> Helper loaded: url_helper
INFO - 2018-10-18 14:04:46 --> Helper loaded: form_helper
INFO - 2018-10-18 14:04:46 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:04:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:04:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:04:46 --> User Agent Class Initialized
INFO - 2018-10-18 14:04:46 --> Controller Class Initialized
INFO - 2018-10-18 14:04:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:04:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:04:46 --> Pixel_Model class loaded
INFO - 2018-10-18 14:04:46 --> Database Driver Class Initialized
INFO - 2018-10-18 14:04:46 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:04:46 --> Form Validation Class Initialized
INFO - 2018-10-18 14:04:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 14:04:46 --> Database Driver Class Initialized
INFO - 2018-10-18 14:04:46 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:04:46 --> Config Class Initialized
INFO - 2018-10-18 14:04:46 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:04:46 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:04:46 --> Utf8 Class Initialized
INFO - 2018-10-18 14:04:46 --> URI Class Initialized
INFO - 2018-10-18 14:04:46 --> Router Class Initialized
INFO - 2018-10-18 14:04:46 --> Output Class Initialized
INFO - 2018-10-18 14:04:46 --> Security Class Initialized
DEBUG - 2018-10-18 14:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:04:47 --> CSRF cookie sent
INFO - 2018-10-18 14:04:47 --> Input Class Initialized
INFO - 2018-10-18 14:04:47 --> Language Class Initialized
INFO - 2018-10-18 14:04:47 --> Loader Class Initialized
INFO - 2018-10-18 14:04:47 --> Helper loaded: url_helper
INFO - 2018-10-18 14:04:47 --> Helper loaded: form_helper
INFO - 2018-10-18 14:04:47 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:04:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:04:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:04:47 --> User Agent Class Initialized
INFO - 2018-10-18 14:04:47 --> Controller Class Initialized
INFO - 2018-10-18 14:04:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:04:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:04:47 --> Pixel_Model class loaded
INFO - 2018-10-18 14:04:47 --> Database Driver Class Initialized
INFO - 2018-10-18 14:04:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:04:47 --> Database Driver Class Initialized
INFO - 2018-10-18 14:04:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:04:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:04:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:04:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:04:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:04:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:04:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:04:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/has_addiction_problem.php
INFO - 2018-10-18 14:04:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:04:47 --> Final output sent to browser
DEBUG - 2018-10-18 14:04:47 --> Total execution time: 0.5619
INFO - 2018-10-18 14:04:47 --> Config Class Initialized
INFO - 2018-10-18 14:04:47 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:04:47 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:04:47 --> Utf8 Class Initialized
INFO - 2018-10-18 14:04:47 --> URI Class Initialized
INFO - 2018-10-18 14:04:47 --> Router Class Initialized
INFO - 2018-10-18 14:04:47 --> Output Class Initialized
INFO - 2018-10-18 14:04:47 --> Security Class Initialized
DEBUG - 2018-10-18 14:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:04:47 --> CSRF cookie sent
INFO - 2018-10-18 14:04:47 --> Input Class Initialized
INFO - 2018-10-18 14:04:47 --> Language Class Initialized
ERROR - 2018-10-18 14:04:47 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 14:04:48 --> Config Class Initialized
INFO - 2018-10-18 14:04:48 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:04:48 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:04:48 --> Utf8 Class Initialized
INFO - 2018-10-18 14:04:48 --> URI Class Initialized
INFO - 2018-10-18 14:04:48 --> Router Class Initialized
INFO - 2018-10-18 14:04:48 --> Output Class Initialized
INFO - 2018-10-18 14:04:48 --> Security Class Initialized
DEBUG - 2018-10-18 14:04:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:04:49 --> CSRF cookie sent
INFO - 2018-10-18 14:04:49 --> CSRF token verified
INFO - 2018-10-18 14:04:49 --> Input Class Initialized
INFO - 2018-10-18 14:04:49 --> Language Class Initialized
INFO - 2018-10-18 14:04:49 --> Loader Class Initialized
INFO - 2018-10-18 14:04:49 --> Helper loaded: url_helper
INFO - 2018-10-18 14:04:49 --> Helper loaded: form_helper
INFO - 2018-10-18 14:04:49 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:04:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:04:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:04:49 --> User Agent Class Initialized
INFO - 2018-10-18 14:04:49 --> Controller Class Initialized
INFO - 2018-10-18 14:04:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:04:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:04:49 --> Pixel_Model class loaded
INFO - 2018-10-18 14:04:49 --> Database Driver Class Initialized
INFO - 2018-10-18 14:04:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:04:49 --> Form Validation Class Initialized
INFO - 2018-10-18 14:04:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 14:04:49 --> Database Driver Class Initialized
INFO - 2018-10-18 14:04:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:04:49 --> Config Class Initialized
INFO - 2018-10-18 14:04:49 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:04:49 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:04:49 --> Utf8 Class Initialized
INFO - 2018-10-18 14:04:49 --> URI Class Initialized
INFO - 2018-10-18 14:04:49 --> Router Class Initialized
INFO - 2018-10-18 14:04:49 --> Output Class Initialized
INFO - 2018-10-18 14:04:49 --> Security Class Initialized
DEBUG - 2018-10-18 14:04:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:04:49 --> CSRF cookie sent
INFO - 2018-10-18 14:04:49 --> Input Class Initialized
INFO - 2018-10-18 14:04:49 --> Language Class Initialized
INFO - 2018-10-18 14:04:49 --> Loader Class Initialized
INFO - 2018-10-18 14:04:49 --> Helper loaded: url_helper
INFO - 2018-10-18 14:04:49 --> Helper loaded: form_helper
INFO - 2018-10-18 14:04:49 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:04:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:04:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:04:49 --> User Agent Class Initialized
INFO - 2018-10-18 14:04:49 --> Controller Class Initialized
INFO - 2018-10-18 14:04:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:04:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:04:49 --> Pixel_Model class loaded
INFO - 2018-10-18 14:04:49 --> Database Driver Class Initialized
INFO - 2018-10-18 14:04:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:04:49 --> Database Driver Class Initialized
INFO - 2018-10-18 14:04:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:04:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:04:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:04:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:04:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:04:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:04:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:04:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/have_hit_s.php
INFO - 2018-10-18 14:04:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:04:49 --> Final output sent to browser
DEBUG - 2018-10-18 14:04:50 --> Total execution time: 0.5807
INFO - 2018-10-18 14:04:50 --> Config Class Initialized
INFO - 2018-10-18 14:04:50 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:04:50 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:04:50 --> Utf8 Class Initialized
INFO - 2018-10-18 14:04:50 --> URI Class Initialized
INFO - 2018-10-18 14:04:50 --> Router Class Initialized
INFO - 2018-10-18 14:04:50 --> Output Class Initialized
INFO - 2018-10-18 14:04:50 --> Security Class Initialized
DEBUG - 2018-10-18 14:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:04:50 --> CSRF cookie sent
INFO - 2018-10-18 14:04:50 --> Input Class Initialized
INFO - 2018-10-18 14:04:50 --> Language Class Initialized
ERROR - 2018-10-18 14:04:50 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 14:04:52 --> Config Class Initialized
INFO - 2018-10-18 14:04:52 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:04:52 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:04:52 --> Utf8 Class Initialized
INFO - 2018-10-18 14:04:52 --> URI Class Initialized
INFO - 2018-10-18 14:04:52 --> Router Class Initialized
INFO - 2018-10-18 14:04:52 --> Output Class Initialized
INFO - 2018-10-18 14:04:52 --> Security Class Initialized
DEBUG - 2018-10-18 14:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:04:52 --> CSRF cookie sent
INFO - 2018-10-18 14:04:52 --> CSRF token verified
INFO - 2018-10-18 14:04:52 --> Input Class Initialized
INFO - 2018-10-18 14:04:52 --> Language Class Initialized
INFO - 2018-10-18 14:04:52 --> Loader Class Initialized
INFO - 2018-10-18 14:04:52 --> Helper loaded: url_helper
INFO - 2018-10-18 14:04:52 --> Helper loaded: form_helper
INFO - 2018-10-18 14:04:52 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:04:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:04:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:04:52 --> User Agent Class Initialized
INFO - 2018-10-18 14:04:52 --> Controller Class Initialized
INFO - 2018-10-18 14:04:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:04:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:04:52 --> Pixel_Model class loaded
INFO - 2018-10-18 14:04:52 --> Database Driver Class Initialized
INFO - 2018-10-18 14:04:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:04:52 --> Form Validation Class Initialized
INFO - 2018-10-18 14:04:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 14:04:52 --> Database Driver Class Initialized
INFO - 2018-10-18 14:04:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:04:52 --> Config Class Initialized
INFO - 2018-10-18 14:04:52 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:04:52 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:04:52 --> Utf8 Class Initialized
INFO - 2018-10-18 14:04:52 --> URI Class Initialized
INFO - 2018-10-18 14:04:52 --> Router Class Initialized
INFO - 2018-10-18 14:04:52 --> Output Class Initialized
INFO - 2018-10-18 14:04:52 --> Security Class Initialized
DEBUG - 2018-10-18 14:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:04:52 --> CSRF cookie sent
INFO - 2018-10-18 14:04:52 --> Input Class Initialized
INFO - 2018-10-18 14:04:52 --> Language Class Initialized
INFO - 2018-10-18 14:04:52 --> Loader Class Initialized
INFO - 2018-10-18 14:04:52 --> Helper loaded: url_helper
INFO - 2018-10-18 14:04:52 --> Helper loaded: form_helper
INFO - 2018-10-18 14:04:52 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:04:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:04:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:04:52 --> User Agent Class Initialized
INFO - 2018-10-18 14:04:52 --> Controller Class Initialized
INFO - 2018-10-18 14:04:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:04:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:04:52 --> Pixel_Model class loaded
INFO - 2018-10-18 14:04:52 --> Database Driver Class Initialized
INFO - 2018-10-18 14:04:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:04:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:04:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:04:53 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:04:53 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:04:53 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/suspension.php
INFO - 2018-10-18 14:04:53 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:04:53 --> Final output sent to browser
DEBUG - 2018-10-18 14:04:53 --> Total execution time: 0.5214
INFO - 2018-10-18 14:04:53 --> Config Class Initialized
INFO - 2018-10-18 14:04:53 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:04:53 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:04:53 --> Utf8 Class Initialized
INFO - 2018-10-18 14:04:53 --> URI Class Initialized
INFO - 2018-10-18 14:04:53 --> Router Class Initialized
INFO - 2018-10-18 14:04:53 --> Output Class Initialized
INFO - 2018-10-18 14:04:53 --> Security Class Initialized
DEBUG - 2018-10-18 14:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:04:53 --> CSRF cookie sent
INFO - 2018-10-18 14:04:53 --> Input Class Initialized
INFO - 2018-10-18 14:04:53 --> Language Class Initialized
ERROR - 2018-10-18 14:04:53 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 14:04:58 --> Config Class Initialized
INFO - 2018-10-18 14:04:58 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:04:58 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:04:58 --> Utf8 Class Initialized
INFO - 2018-10-18 14:04:58 --> URI Class Initialized
INFO - 2018-10-18 14:04:58 --> Router Class Initialized
INFO - 2018-10-18 14:04:58 --> Output Class Initialized
INFO - 2018-10-18 14:04:58 --> Security Class Initialized
DEBUG - 2018-10-18 14:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:04:58 --> CSRF cookie sent
INFO - 2018-10-18 14:04:58 --> Input Class Initialized
INFO - 2018-10-18 14:04:58 --> Language Class Initialized
INFO - 2018-10-18 14:04:58 --> Loader Class Initialized
INFO - 2018-10-18 14:04:58 --> Helper loaded: url_helper
INFO - 2018-10-18 14:04:58 --> Helper loaded: form_helper
INFO - 2018-10-18 14:04:58 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:04:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:04:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:04:58 --> User Agent Class Initialized
INFO - 2018-10-18 14:04:58 --> Controller Class Initialized
INFO - 2018-10-18 14:04:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:04:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:04:58 --> Pixel_Model class loaded
INFO - 2018-10-18 14:04:58 --> Database Driver Class Initialized
INFO - 2018-10-18 14:04:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:04:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:04:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:04:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:04:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:04:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:04:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:04:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-18 14:04:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:04:58 --> Final output sent to browser
DEBUG - 2018-10-18 14:04:59 --> Total execution time: 0.5517
INFO - 2018-10-18 14:04:59 --> Config Class Initialized
INFO - 2018-10-18 14:04:59 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:04:59 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:04:59 --> Utf8 Class Initialized
INFO - 2018-10-18 14:04:59 --> URI Class Initialized
INFO - 2018-10-18 14:04:59 --> Router Class Initialized
INFO - 2018-10-18 14:04:59 --> Output Class Initialized
INFO - 2018-10-18 14:04:59 --> Security Class Initialized
DEBUG - 2018-10-18 14:04:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:04:59 --> CSRF cookie sent
INFO - 2018-10-18 14:04:59 --> Input Class Initialized
INFO - 2018-10-18 14:04:59 --> Language Class Initialized
ERROR - 2018-10-18 14:04:59 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 14:05:01 --> Config Class Initialized
INFO - 2018-10-18 14:05:01 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:05:01 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:05:01 --> Utf8 Class Initialized
INFO - 2018-10-18 14:05:01 --> URI Class Initialized
INFO - 2018-10-18 14:05:01 --> Router Class Initialized
INFO - 2018-10-18 14:05:01 --> Output Class Initialized
INFO - 2018-10-18 14:05:01 --> Security Class Initialized
DEBUG - 2018-10-18 14:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:05:01 --> CSRF cookie sent
INFO - 2018-10-18 14:05:01 --> CSRF token verified
INFO - 2018-10-18 14:05:01 --> Input Class Initialized
INFO - 2018-10-18 14:05:01 --> Language Class Initialized
INFO - 2018-10-18 14:05:02 --> Loader Class Initialized
INFO - 2018-10-18 14:05:02 --> Helper loaded: url_helper
INFO - 2018-10-18 14:05:02 --> Helper loaded: form_helper
INFO - 2018-10-18 14:05:02 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:05:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:05:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:05:02 --> User Agent Class Initialized
INFO - 2018-10-18 14:05:02 --> Controller Class Initialized
INFO - 2018-10-18 14:05:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:05:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:05:02 --> Pixel_Model class loaded
INFO - 2018-10-18 14:05:02 --> Database Driver Class Initialized
INFO - 2018-10-18 14:05:02 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:05:02 --> Form Validation Class Initialized
INFO - 2018-10-18 14:05:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 14:05:02 --> Database Driver Class Initialized
INFO - 2018-10-18 14:05:02 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:05:02 --> Config Class Initialized
INFO - 2018-10-18 14:05:02 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:05:02 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:05:02 --> Utf8 Class Initialized
INFO - 2018-10-18 14:05:02 --> URI Class Initialized
INFO - 2018-10-18 14:05:02 --> Router Class Initialized
INFO - 2018-10-18 14:05:02 --> Output Class Initialized
INFO - 2018-10-18 14:05:02 --> Security Class Initialized
DEBUG - 2018-10-18 14:05:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:05:02 --> CSRF cookie sent
INFO - 2018-10-18 14:05:02 --> Input Class Initialized
INFO - 2018-10-18 14:05:02 --> Language Class Initialized
INFO - 2018-10-18 14:05:02 --> Loader Class Initialized
INFO - 2018-10-18 14:05:02 --> Helper loaded: url_helper
INFO - 2018-10-18 14:05:02 --> Helper loaded: form_helper
INFO - 2018-10-18 14:05:02 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:05:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:05:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:05:02 --> User Agent Class Initialized
INFO - 2018-10-18 14:05:02 --> Controller Class Initialized
INFO - 2018-10-18 14:05:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:05:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:05:02 --> Pixel_Model class loaded
INFO - 2018-10-18 14:05:02 --> Database Driver Class Initialized
INFO - 2018-10-18 14:05:02 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:05:02 --> Database Driver Class Initialized
INFO - 2018-10-18 14:05:02 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:05:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:05:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:05:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:05:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:05:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:05:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:05:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-18 14:05:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:05:02 --> Final output sent to browser
DEBUG - 2018-10-18 14:05:02 --> Total execution time: 0.5708
INFO - 2018-10-18 14:05:03 --> Config Class Initialized
INFO - 2018-10-18 14:05:03 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:05:03 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:05:03 --> Utf8 Class Initialized
INFO - 2018-10-18 14:05:03 --> URI Class Initialized
INFO - 2018-10-18 14:05:03 --> Router Class Initialized
INFO - 2018-10-18 14:05:03 --> Output Class Initialized
INFO - 2018-10-18 14:05:03 --> Security Class Initialized
DEBUG - 2018-10-18 14:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:05:03 --> CSRF cookie sent
INFO - 2018-10-18 14:05:03 --> Input Class Initialized
INFO - 2018-10-18 14:05:03 --> Language Class Initialized
ERROR - 2018-10-18 14:05:03 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 14:05:06 --> Config Class Initialized
INFO - 2018-10-18 14:05:06 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:05:06 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:05:06 --> Utf8 Class Initialized
INFO - 2018-10-18 14:05:06 --> URI Class Initialized
INFO - 2018-10-18 14:05:07 --> Router Class Initialized
INFO - 2018-10-18 14:05:07 --> Output Class Initialized
INFO - 2018-10-18 14:05:07 --> Security Class Initialized
DEBUG - 2018-10-18 14:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:05:07 --> CSRF cookie sent
INFO - 2018-10-18 14:05:07 --> CSRF token verified
INFO - 2018-10-18 14:05:07 --> Input Class Initialized
INFO - 2018-10-18 14:05:07 --> Language Class Initialized
INFO - 2018-10-18 14:05:07 --> Loader Class Initialized
INFO - 2018-10-18 14:05:07 --> Helper loaded: url_helper
INFO - 2018-10-18 14:05:07 --> Helper loaded: form_helper
INFO - 2018-10-18 14:05:07 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:05:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:05:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:05:07 --> User Agent Class Initialized
INFO - 2018-10-18 14:05:07 --> Controller Class Initialized
INFO - 2018-10-18 14:05:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:05:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:05:07 --> Pixel_Model class loaded
INFO - 2018-10-18 14:05:07 --> Database Driver Class Initialized
INFO - 2018-10-18 14:05:07 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:05:07 --> Form Validation Class Initialized
INFO - 2018-10-18 14:05:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 14:05:07 --> Database Driver Class Initialized
INFO - 2018-10-18 14:05:07 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:05:07 --> Config Class Initialized
INFO - 2018-10-18 14:05:07 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:05:07 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:05:07 --> Utf8 Class Initialized
INFO - 2018-10-18 14:05:07 --> URI Class Initialized
INFO - 2018-10-18 14:05:07 --> Router Class Initialized
INFO - 2018-10-18 14:05:07 --> Output Class Initialized
INFO - 2018-10-18 14:05:07 --> Security Class Initialized
DEBUG - 2018-10-18 14:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:05:07 --> CSRF cookie sent
INFO - 2018-10-18 14:05:07 --> Input Class Initialized
INFO - 2018-10-18 14:05:07 --> Language Class Initialized
INFO - 2018-10-18 14:05:07 --> Loader Class Initialized
INFO - 2018-10-18 14:05:07 --> Helper loaded: url_helper
INFO - 2018-10-18 14:05:07 --> Helper loaded: form_helper
INFO - 2018-10-18 14:05:07 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:05:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:05:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:05:07 --> User Agent Class Initialized
INFO - 2018-10-18 14:05:07 --> Controller Class Initialized
INFO - 2018-10-18 14:05:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:05:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:05:07 --> Pixel_Model class loaded
INFO - 2018-10-18 14:05:07 --> Database Driver Class Initialized
INFO - 2018-10-18 14:05:07 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:05:07 --> Database Driver Class Initialized
INFO - 2018-10-18 14:05:07 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:05:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:05:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:05:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:05:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:05:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:05:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:05:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/your_job.php
INFO - 2018-10-18 14:05:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:05:08 --> Final output sent to browser
DEBUG - 2018-10-18 14:05:08 --> Total execution time: 0.6027
INFO - 2018-10-18 14:05:08 --> Config Class Initialized
INFO - 2018-10-18 14:05:08 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:05:08 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:05:08 --> Utf8 Class Initialized
INFO - 2018-10-18 14:05:08 --> URI Class Initialized
INFO - 2018-10-18 14:05:08 --> Router Class Initialized
INFO - 2018-10-18 14:05:08 --> Output Class Initialized
INFO - 2018-10-18 14:05:08 --> Security Class Initialized
DEBUG - 2018-10-18 14:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:05:08 --> CSRF cookie sent
INFO - 2018-10-18 14:05:08 --> Input Class Initialized
INFO - 2018-10-18 14:05:08 --> Language Class Initialized
ERROR - 2018-10-18 14:05:08 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 14:05:10 --> Config Class Initialized
INFO - 2018-10-18 14:05:10 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:05:10 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:05:10 --> Utf8 Class Initialized
INFO - 2018-10-18 14:05:10 --> URI Class Initialized
INFO - 2018-10-18 14:05:10 --> Router Class Initialized
INFO - 2018-10-18 14:05:10 --> Output Class Initialized
INFO - 2018-10-18 14:05:10 --> Security Class Initialized
DEBUG - 2018-10-18 14:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:05:10 --> CSRF cookie sent
INFO - 2018-10-18 14:05:10 --> CSRF token verified
INFO - 2018-10-18 14:05:10 --> Input Class Initialized
INFO - 2018-10-18 14:05:10 --> Language Class Initialized
INFO - 2018-10-18 14:05:10 --> Loader Class Initialized
INFO - 2018-10-18 14:05:10 --> Helper loaded: url_helper
INFO - 2018-10-18 14:05:10 --> Helper loaded: form_helper
INFO - 2018-10-18 14:05:10 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:05:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:05:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:05:10 --> User Agent Class Initialized
INFO - 2018-10-18 14:05:10 --> Controller Class Initialized
INFO - 2018-10-18 14:05:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:05:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:05:10 --> Pixel_Model class loaded
INFO - 2018-10-18 14:05:10 --> Database Driver Class Initialized
INFO - 2018-10-18 14:05:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:05:10 --> Form Validation Class Initialized
INFO - 2018-10-18 14:05:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 14:05:10 --> Database Driver Class Initialized
INFO - 2018-10-18 14:05:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:05:10 --> Config Class Initialized
INFO - 2018-10-18 14:05:10 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:05:10 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:05:10 --> Utf8 Class Initialized
INFO - 2018-10-18 14:05:10 --> URI Class Initialized
INFO - 2018-10-18 14:05:10 --> Router Class Initialized
INFO - 2018-10-18 14:05:10 --> Output Class Initialized
INFO - 2018-10-18 14:05:10 --> Security Class Initialized
DEBUG - 2018-10-18 14:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:05:10 --> CSRF cookie sent
INFO - 2018-10-18 14:05:10 --> Input Class Initialized
INFO - 2018-10-18 14:05:10 --> Language Class Initialized
INFO - 2018-10-18 14:05:10 --> Loader Class Initialized
INFO - 2018-10-18 14:05:10 --> Helper loaded: url_helper
INFO - 2018-10-18 14:05:10 --> Helper loaded: form_helper
INFO - 2018-10-18 14:05:10 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:05:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:05:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:05:10 --> User Agent Class Initialized
INFO - 2018-10-18 14:05:10 --> Controller Class Initialized
INFO - 2018-10-18 14:05:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:05:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:05:11 --> Pixel_Model class loaded
INFO - 2018-10-18 14:05:11 --> Database Driver Class Initialized
INFO - 2018-10-18 14:05:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:05:11 --> Database Driver Class Initialized
INFO - 2018-10-18 14:05:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:05:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:05:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:05:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner.php
INFO - 2018-10-18 14:05:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:05:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:05:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:05:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:05:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/relation_ship_status.php
INFO - 2018-10-18 14:05:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:05:11 --> Final output sent to browser
DEBUG - 2018-10-18 14:05:11 --> Total execution time: 0.5927
INFO - 2018-10-18 14:05:11 --> Config Class Initialized
INFO - 2018-10-18 14:05:11 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:05:11 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:05:11 --> Utf8 Class Initialized
INFO - 2018-10-18 14:05:11 --> URI Class Initialized
INFO - 2018-10-18 14:05:11 --> Router Class Initialized
INFO - 2018-10-18 14:05:11 --> Output Class Initialized
INFO - 2018-10-18 14:05:11 --> Security Class Initialized
DEBUG - 2018-10-18 14:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:05:11 --> CSRF cookie sent
INFO - 2018-10-18 14:05:11 --> Input Class Initialized
INFO - 2018-10-18 14:05:11 --> Language Class Initialized
ERROR - 2018-10-18 14:05:11 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 14:05:13 --> Config Class Initialized
INFO - 2018-10-18 14:05:13 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:05:13 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:05:13 --> Utf8 Class Initialized
INFO - 2018-10-18 14:05:13 --> URI Class Initialized
INFO - 2018-10-18 14:05:13 --> Router Class Initialized
INFO - 2018-10-18 14:05:13 --> Output Class Initialized
INFO - 2018-10-18 14:05:13 --> Security Class Initialized
DEBUG - 2018-10-18 14:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:05:13 --> CSRF cookie sent
INFO - 2018-10-18 14:05:13 --> CSRF token verified
INFO - 2018-10-18 14:05:13 --> Input Class Initialized
INFO - 2018-10-18 14:05:13 --> Language Class Initialized
INFO - 2018-10-18 14:05:13 --> Loader Class Initialized
INFO - 2018-10-18 14:05:13 --> Helper loaded: url_helper
INFO - 2018-10-18 14:05:14 --> Helper loaded: form_helper
INFO - 2018-10-18 14:05:14 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:05:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:05:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:05:14 --> User Agent Class Initialized
INFO - 2018-10-18 14:05:14 --> Controller Class Initialized
INFO - 2018-10-18 14:05:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:05:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:05:14 --> Pixel_Model class loaded
INFO - 2018-10-18 14:05:14 --> Database Driver Class Initialized
INFO - 2018-10-18 14:05:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:05:14 --> Form Validation Class Initialized
INFO - 2018-10-18 14:05:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 14:05:14 --> Database Driver Class Initialized
INFO - 2018-10-18 14:05:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:05:14 --> Config Class Initialized
INFO - 2018-10-18 14:05:14 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:05:14 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:05:14 --> Utf8 Class Initialized
INFO - 2018-10-18 14:05:14 --> URI Class Initialized
INFO - 2018-10-18 14:05:14 --> Router Class Initialized
INFO - 2018-10-18 14:05:14 --> Output Class Initialized
INFO - 2018-10-18 14:05:14 --> Security Class Initialized
DEBUG - 2018-10-18 14:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:05:14 --> CSRF cookie sent
INFO - 2018-10-18 14:05:14 --> Input Class Initialized
INFO - 2018-10-18 14:05:14 --> Language Class Initialized
INFO - 2018-10-18 14:05:14 --> Loader Class Initialized
INFO - 2018-10-18 14:05:14 --> Helper loaded: url_helper
INFO - 2018-10-18 14:05:14 --> Helper loaded: form_helper
INFO - 2018-10-18 14:05:14 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:05:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:05:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:05:14 --> User Agent Class Initialized
INFO - 2018-10-18 14:05:14 --> Controller Class Initialized
INFO - 2018-10-18 14:05:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:05:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:05:14 --> Pixel_Model class loaded
INFO - 2018-10-18 14:05:14 --> Database Driver Class Initialized
INFO - 2018-10-18 14:05:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:05:14 --> Database Driver Class Initialized
INFO - 2018-10-18 14:05:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:05:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:05:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:05:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:05:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:05:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:05:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:05:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/income.php
INFO - 2018-10-18 14:05:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:05:14 --> Final output sent to browser
DEBUG - 2018-10-18 14:05:14 --> Total execution time: 0.5933
INFO - 2018-10-18 14:05:15 --> Config Class Initialized
INFO - 2018-10-18 14:05:15 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:05:15 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:05:15 --> Utf8 Class Initialized
INFO - 2018-10-18 14:05:15 --> URI Class Initialized
INFO - 2018-10-18 14:05:15 --> Router Class Initialized
INFO - 2018-10-18 14:05:15 --> Output Class Initialized
INFO - 2018-10-18 14:05:15 --> Security Class Initialized
DEBUG - 2018-10-18 14:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:05:15 --> CSRF cookie sent
INFO - 2018-10-18 14:05:15 --> Input Class Initialized
INFO - 2018-10-18 14:05:15 --> Language Class Initialized
ERROR - 2018-10-18 14:05:15 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 14:05:19 --> Config Class Initialized
INFO - 2018-10-18 14:05:19 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:05:19 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:05:19 --> Utf8 Class Initialized
INFO - 2018-10-18 14:05:19 --> URI Class Initialized
INFO - 2018-10-18 14:05:19 --> Router Class Initialized
INFO - 2018-10-18 14:05:19 --> Output Class Initialized
INFO - 2018-10-18 14:05:19 --> Security Class Initialized
DEBUG - 2018-10-18 14:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:05:19 --> CSRF cookie sent
INFO - 2018-10-18 14:05:19 --> CSRF token verified
INFO - 2018-10-18 14:05:19 --> Input Class Initialized
INFO - 2018-10-18 14:05:19 --> Language Class Initialized
INFO - 2018-10-18 14:05:19 --> Loader Class Initialized
INFO - 2018-10-18 14:05:19 --> Helper loaded: url_helper
INFO - 2018-10-18 14:05:19 --> Helper loaded: form_helper
INFO - 2018-10-18 14:05:19 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:05:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:05:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:05:19 --> User Agent Class Initialized
INFO - 2018-10-18 14:05:19 --> Controller Class Initialized
INFO - 2018-10-18 14:05:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:05:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:05:19 --> Pixel_Model class loaded
INFO - 2018-10-18 14:05:19 --> Database Driver Class Initialized
INFO - 2018-10-18 14:05:19 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:05:19 --> Form Validation Class Initialized
INFO - 2018-10-18 14:05:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 14:05:19 --> Database Driver Class Initialized
INFO - 2018-10-18 14:05:19 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:05:19 --> Config Class Initialized
INFO - 2018-10-18 14:05:19 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:05:19 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:05:19 --> Utf8 Class Initialized
INFO - 2018-10-18 14:05:19 --> URI Class Initialized
INFO - 2018-10-18 14:05:19 --> Router Class Initialized
INFO - 2018-10-18 14:05:19 --> Output Class Initialized
INFO - 2018-10-18 14:05:19 --> Security Class Initialized
DEBUG - 2018-10-18 14:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:05:19 --> CSRF cookie sent
INFO - 2018-10-18 14:05:19 --> Input Class Initialized
INFO - 2018-10-18 14:05:19 --> Language Class Initialized
INFO - 2018-10-18 14:05:19 --> Loader Class Initialized
INFO - 2018-10-18 14:05:19 --> Helper loaded: url_helper
INFO - 2018-10-18 14:05:19 --> Helper loaded: form_helper
INFO - 2018-10-18 14:05:19 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:05:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:05:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:05:20 --> User Agent Class Initialized
INFO - 2018-10-18 14:05:20 --> Controller Class Initialized
INFO - 2018-10-18 14:05:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:05:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:05:20 --> Pixel_Model class loaded
INFO - 2018-10-18 14:05:20 --> Database Driver Class Initialized
INFO - 2018-10-18 14:05:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:05:20 --> Database Driver Class Initialized
INFO - 2018-10-18 14:05:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:05:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:05:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:05:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:05:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:05:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:05:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:05:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/marriage.php
INFO - 2018-10-18 14:05:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:05:20 --> Final output sent to browser
DEBUG - 2018-10-18 14:05:20 --> Total execution time: 0.5754
INFO - 2018-10-18 14:05:20 --> Config Class Initialized
INFO - 2018-10-18 14:05:20 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:05:20 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:05:20 --> Utf8 Class Initialized
INFO - 2018-10-18 14:05:20 --> URI Class Initialized
INFO - 2018-10-18 14:05:20 --> Router Class Initialized
INFO - 2018-10-18 14:05:20 --> Output Class Initialized
INFO - 2018-10-18 14:05:20 --> Security Class Initialized
DEBUG - 2018-10-18 14:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:05:20 --> CSRF cookie sent
INFO - 2018-10-18 14:05:20 --> Input Class Initialized
INFO - 2018-10-18 14:05:20 --> Language Class Initialized
ERROR - 2018-10-18 14:05:20 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 14:05:33 --> Config Class Initialized
INFO - 2018-10-18 14:05:33 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:05:33 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:05:33 --> Utf8 Class Initialized
INFO - 2018-10-18 14:05:33 --> URI Class Initialized
INFO - 2018-10-18 14:05:33 --> Router Class Initialized
INFO - 2018-10-18 14:05:33 --> Output Class Initialized
INFO - 2018-10-18 14:05:33 --> Security Class Initialized
DEBUG - 2018-10-18 14:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:05:33 --> CSRF cookie sent
INFO - 2018-10-18 14:05:33 --> CSRF token verified
INFO - 2018-10-18 14:05:33 --> Input Class Initialized
INFO - 2018-10-18 14:05:33 --> Language Class Initialized
INFO - 2018-10-18 14:05:33 --> Loader Class Initialized
INFO - 2018-10-18 14:05:33 --> Helper loaded: url_helper
INFO - 2018-10-18 14:05:33 --> Helper loaded: form_helper
INFO - 2018-10-18 14:05:33 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:05:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:05:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:05:33 --> User Agent Class Initialized
INFO - 2018-10-18 14:05:33 --> Controller Class Initialized
INFO - 2018-10-18 14:05:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:05:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:05:33 --> Pixel_Model class loaded
INFO - 2018-10-18 14:05:33 --> Database Driver Class Initialized
INFO - 2018-10-18 14:05:33 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:05:33 --> Form Validation Class Initialized
INFO - 2018-10-18 14:05:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 14:05:33 --> Database Driver Class Initialized
INFO - 2018-10-18 14:05:33 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:05:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:05:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:05:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:05:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:05:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:05:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_errors.php
INFO - 2018-10-18 14:05:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:05:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/marriage.php
INFO - 2018-10-18 14:05:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:05:33 --> Final output sent to browser
DEBUG - 2018-10-18 14:05:33 --> Total execution time: 0.6440
INFO - 2018-10-18 14:05:34 --> Config Class Initialized
INFO - 2018-10-18 14:05:34 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:05:34 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:05:34 --> Utf8 Class Initialized
INFO - 2018-10-18 14:05:34 --> URI Class Initialized
INFO - 2018-10-18 14:05:34 --> Router Class Initialized
INFO - 2018-10-18 14:05:34 --> Output Class Initialized
INFO - 2018-10-18 14:05:34 --> Security Class Initialized
DEBUG - 2018-10-18 14:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:05:34 --> CSRF cookie sent
INFO - 2018-10-18 14:05:34 --> Input Class Initialized
INFO - 2018-10-18 14:05:34 --> Language Class Initialized
ERROR - 2018-10-18 14:05:34 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 14:05:37 --> Config Class Initialized
INFO - 2018-10-18 14:05:37 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:05:37 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:05:37 --> Utf8 Class Initialized
INFO - 2018-10-18 14:05:37 --> URI Class Initialized
INFO - 2018-10-18 14:05:37 --> Router Class Initialized
INFO - 2018-10-18 14:05:37 --> Output Class Initialized
INFO - 2018-10-18 14:05:37 --> Security Class Initialized
DEBUG - 2018-10-18 14:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:05:38 --> CSRF cookie sent
INFO - 2018-10-18 14:05:38 --> CSRF token verified
INFO - 2018-10-18 14:05:38 --> Input Class Initialized
INFO - 2018-10-18 14:05:38 --> Language Class Initialized
INFO - 2018-10-18 14:05:38 --> Loader Class Initialized
INFO - 2018-10-18 14:05:38 --> Helper loaded: url_helper
INFO - 2018-10-18 14:05:38 --> Helper loaded: form_helper
INFO - 2018-10-18 14:05:38 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:05:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:05:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:05:38 --> User Agent Class Initialized
INFO - 2018-10-18 14:05:38 --> Controller Class Initialized
INFO - 2018-10-18 14:05:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:05:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:05:38 --> Pixel_Model class loaded
INFO - 2018-10-18 14:05:38 --> Database Driver Class Initialized
INFO - 2018-10-18 14:05:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:05:38 --> Form Validation Class Initialized
INFO - 2018-10-18 14:05:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 14:05:38 --> Database Driver Class Initialized
INFO - 2018-10-18 14:05:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:05:38 --> Config Class Initialized
INFO - 2018-10-18 14:05:38 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:05:38 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:05:38 --> Utf8 Class Initialized
INFO - 2018-10-18 14:05:38 --> URI Class Initialized
INFO - 2018-10-18 14:05:38 --> Router Class Initialized
INFO - 2018-10-18 14:05:38 --> Output Class Initialized
INFO - 2018-10-18 14:05:38 --> Security Class Initialized
DEBUG - 2018-10-18 14:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:05:38 --> CSRF cookie sent
INFO - 2018-10-18 14:05:38 --> Input Class Initialized
INFO - 2018-10-18 14:05:38 --> Language Class Initialized
INFO - 2018-10-18 14:05:38 --> Loader Class Initialized
INFO - 2018-10-18 14:05:38 --> Helper loaded: url_helper
INFO - 2018-10-18 14:05:38 --> Helper loaded: form_helper
INFO - 2018-10-18 14:05:38 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:05:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:05:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:05:38 --> User Agent Class Initialized
INFO - 2018-10-18 14:05:38 --> Controller Class Initialized
INFO - 2018-10-18 14:05:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:05:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:05:38 --> Pixel_Model class loaded
INFO - 2018-10-18 14:05:38 --> Database Driver Class Initialized
INFO - 2018-10-18 14:05:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:05:38 --> Database Driver Class Initialized
INFO - 2018-10-18 14:05:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:05:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:05:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:05:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:05:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:05:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:05:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:05:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/kids.php
INFO - 2018-10-18 14:05:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:05:39 --> Final output sent to browser
DEBUG - 2018-10-18 14:05:39 --> Total execution time: 0.5713
INFO - 2018-10-18 14:05:39 --> Config Class Initialized
INFO - 2018-10-18 14:05:39 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:05:39 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:05:39 --> Utf8 Class Initialized
INFO - 2018-10-18 14:05:39 --> URI Class Initialized
INFO - 2018-10-18 14:05:39 --> Router Class Initialized
INFO - 2018-10-18 14:05:39 --> Output Class Initialized
INFO - 2018-10-18 14:05:39 --> Security Class Initialized
DEBUG - 2018-10-18 14:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:05:39 --> CSRF cookie sent
INFO - 2018-10-18 14:05:39 --> Input Class Initialized
INFO - 2018-10-18 14:05:39 --> Language Class Initialized
ERROR - 2018-10-18 14:05:39 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 14:05:48 --> Config Class Initialized
INFO - 2018-10-18 14:05:48 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:05:48 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:05:48 --> Utf8 Class Initialized
INFO - 2018-10-18 14:05:48 --> URI Class Initialized
INFO - 2018-10-18 14:05:48 --> Router Class Initialized
INFO - 2018-10-18 14:05:48 --> Output Class Initialized
INFO - 2018-10-18 14:05:48 --> Security Class Initialized
DEBUG - 2018-10-18 14:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:05:48 --> CSRF cookie sent
INFO - 2018-10-18 14:05:48 --> CSRF token verified
INFO - 2018-10-18 14:05:48 --> Input Class Initialized
INFO - 2018-10-18 14:05:48 --> Language Class Initialized
INFO - 2018-10-18 14:05:48 --> Loader Class Initialized
INFO - 2018-10-18 14:05:48 --> Helper loaded: url_helper
INFO - 2018-10-18 14:05:48 --> Helper loaded: form_helper
INFO - 2018-10-18 14:05:48 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:05:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:05:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:05:48 --> User Agent Class Initialized
INFO - 2018-10-18 14:05:48 --> Controller Class Initialized
INFO - 2018-10-18 14:05:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:05:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:05:48 --> Pixel_Model class loaded
INFO - 2018-10-18 14:05:48 --> Database Driver Class Initialized
INFO - 2018-10-18 14:05:48 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:05:48 --> Form Validation Class Initialized
INFO - 2018-10-18 14:05:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 14:05:48 --> Database Driver Class Initialized
INFO - 2018-10-18 14:05:48 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:05:48 --> Config Class Initialized
INFO - 2018-10-18 14:05:48 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:05:49 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:05:49 --> Utf8 Class Initialized
INFO - 2018-10-18 14:05:49 --> URI Class Initialized
INFO - 2018-10-18 14:05:49 --> Router Class Initialized
INFO - 2018-10-18 14:05:49 --> Output Class Initialized
INFO - 2018-10-18 14:05:49 --> Security Class Initialized
DEBUG - 2018-10-18 14:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:05:49 --> CSRF cookie sent
INFO - 2018-10-18 14:05:49 --> Input Class Initialized
INFO - 2018-10-18 14:05:49 --> Language Class Initialized
INFO - 2018-10-18 14:05:49 --> Loader Class Initialized
INFO - 2018-10-18 14:05:49 --> Helper loaded: url_helper
INFO - 2018-10-18 14:05:49 --> Helper loaded: form_helper
INFO - 2018-10-18 14:05:49 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:05:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:05:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:05:49 --> User Agent Class Initialized
INFO - 2018-10-18 14:05:49 --> Controller Class Initialized
INFO - 2018-10-18 14:05:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:05:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:05:49 --> Pixel_Model class loaded
INFO - 2018-10-18 14:05:49 --> Database Driver Class Initialized
INFO - 2018-10-18 14:05:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:05:49 --> Database Driver Class Initialized
INFO - 2018-10-18 14:05:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:05:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:05:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:05:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:05:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:05:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:05:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:05:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/pension.php
INFO - 2018-10-18 14:05:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:05:49 --> Final output sent to browser
DEBUG - 2018-10-18 14:05:49 --> Total execution time: 0.5647
INFO - 2018-10-18 14:05:49 --> Config Class Initialized
INFO - 2018-10-18 14:05:49 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:05:49 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:05:49 --> Utf8 Class Initialized
INFO - 2018-10-18 14:05:49 --> URI Class Initialized
INFO - 2018-10-18 14:05:49 --> Router Class Initialized
INFO - 2018-10-18 14:05:49 --> Output Class Initialized
INFO - 2018-10-18 14:05:49 --> Security Class Initialized
DEBUG - 2018-10-18 14:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:05:50 --> CSRF cookie sent
INFO - 2018-10-18 14:05:50 --> Input Class Initialized
INFO - 2018-10-18 14:05:50 --> Language Class Initialized
ERROR - 2018-10-18 14:05:50 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 14:05:54 --> Config Class Initialized
INFO - 2018-10-18 14:05:54 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:05:54 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:05:54 --> Utf8 Class Initialized
INFO - 2018-10-18 14:05:54 --> URI Class Initialized
INFO - 2018-10-18 14:05:54 --> Router Class Initialized
INFO - 2018-10-18 14:05:54 --> Output Class Initialized
INFO - 2018-10-18 14:05:54 --> Security Class Initialized
DEBUG - 2018-10-18 14:05:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:05:54 --> CSRF cookie sent
INFO - 2018-10-18 14:05:54 --> CSRF token verified
INFO - 2018-10-18 14:05:54 --> Input Class Initialized
INFO - 2018-10-18 14:05:54 --> Language Class Initialized
INFO - 2018-10-18 14:05:54 --> Loader Class Initialized
INFO - 2018-10-18 14:05:54 --> Helper loaded: url_helper
INFO - 2018-10-18 14:05:54 --> Helper loaded: form_helper
INFO - 2018-10-18 14:05:54 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:05:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:05:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:05:54 --> User Agent Class Initialized
INFO - 2018-10-18 14:05:54 --> Controller Class Initialized
INFO - 2018-10-18 14:05:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:05:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:05:54 --> Pixel_Model class loaded
INFO - 2018-10-18 14:05:54 --> Database Driver Class Initialized
INFO - 2018-10-18 14:05:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:05:54 --> Form Validation Class Initialized
INFO - 2018-10-18 14:05:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 14:05:54 --> Database Driver Class Initialized
INFO - 2018-10-18 14:05:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:05:55 --> Config Class Initialized
INFO - 2018-10-18 14:05:55 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:05:55 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:05:55 --> Utf8 Class Initialized
INFO - 2018-10-18 14:05:55 --> URI Class Initialized
INFO - 2018-10-18 14:05:55 --> Router Class Initialized
INFO - 2018-10-18 14:05:55 --> Output Class Initialized
INFO - 2018-10-18 14:05:55 --> Security Class Initialized
DEBUG - 2018-10-18 14:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:05:55 --> CSRF cookie sent
INFO - 2018-10-18 14:05:55 --> Input Class Initialized
INFO - 2018-10-18 14:05:55 --> Language Class Initialized
INFO - 2018-10-18 14:05:55 --> Loader Class Initialized
INFO - 2018-10-18 14:05:55 --> Helper loaded: url_helper
INFO - 2018-10-18 14:05:55 --> Helper loaded: form_helper
INFO - 2018-10-18 14:05:55 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:05:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:05:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:05:55 --> User Agent Class Initialized
INFO - 2018-10-18 14:05:55 --> Controller Class Initialized
INFO - 2018-10-18 14:05:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:05:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:05:55 --> Pixel_Model class loaded
INFO - 2018-10-18 14:05:55 --> Database Driver Class Initialized
INFO - 2018-10-18 14:05:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:05:55 --> Database Driver Class Initialized
INFO - 2018-10-18 14:05:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:05:55 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:05:55 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:05:55 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:05:55 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:05:55 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:05:55 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:05:55 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/inheritance.php
INFO - 2018-10-18 14:05:55 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:05:55 --> Final output sent to browser
DEBUG - 2018-10-18 14:05:55 --> Total execution time: 0.5572
INFO - 2018-10-18 14:05:55 --> Config Class Initialized
INFO - 2018-10-18 14:05:55 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:05:55 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:05:55 --> Utf8 Class Initialized
INFO - 2018-10-18 14:05:55 --> URI Class Initialized
INFO - 2018-10-18 14:05:55 --> Router Class Initialized
INFO - 2018-10-18 14:05:55 --> Output Class Initialized
INFO - 2018-10-18 14:05:55 --> Security Class Initialized
DEBUG - 2018-10-18 14:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:05:56 --> CSRF cookie sent
INFO - 2018-10-18 14:05:56 --> Input Class Initialized
INFO - 2018-10-18 14:05:56 --> Language Class Initialized
ERROR - 2018-10-18 14:05:56 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 14:06:02 --> Config Class Initialized
INFO - 2018-10-18 14:06:02 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:06:02 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:06:02 --> Utf8 Class Initialized
INFO - 2018-10-18 14:06:02 --> URI Class Initialized
INFO - 2018-10-18 14:06:02 --> Router Class Initialized
INFO - 2018-10-18 14:06:02 --> Output Class Initialized
INFO - 2018-10-18 14:06:02 --> Security Class Initialized
DEBUG - 2018-10-18 14:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:06:02 --> CSRF cookie sent
INFO - 2018-10-18 14:06:02 --> CSRF token verified
INFO - 2018-10-18 14:06:02 --> Input Class Initialized
INFO - 2018-10-18 14:06:02 --> Language Class Initialized
INFO - 2018-10-18 14:06:02 --> Loader Class Initialized
INFO - 2018-10-18 14:06:02 --> Helper loaded: url_helper
INFO - 2018-10-18 14:06:02 --> Helper loaded: form_helper
INFO - 2018-10-18 14:06:02 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:06:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:06:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:06:02 --> User Agent Class Initialized
INFO - 2018-10-18 14:06:02 --> Controller Class Initialized
INFO - 2018-10-18 14:06:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:06:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:06:02 --> Pixel_Model class loaded
INFO - 2018-10-18 14:06:02 --> Database Driver Class Initialized
INFO - 2018-10-18 14:06:02 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:06:02 --> Form Validation Class Initialized
INFO - 2018-10-18 14:06:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 14:06:02 --> Database Driver Class Initialized
INFO - 2018-10-18 14:06:02 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:06:02 --> Config Class Initialized
INFO - 2018-10-18 14:06:02 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:06:02 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:06:02 --> Utf8 Class Initialized
INFO - 2018-10-18 14:06:02 --> URI Class Initialized
INFO - 2018-10-18 14:06:02 --> Router Class Initialized
INFO - 2018-10-18 14:06:02 --> Output Class Initialized
INFO - 2018-10-18 14:06:02 --> Security Class Initialized
DEBUG - 2018-10-18 14:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:06:02 --> CSRF cookie sent
INFO - 2018-10-18 14:06:02 --> Input Class Initialized
INFO - 2018-10-18 14:06:02 --> Language Class Initialized
INFO - 2018-10-18 14:06:02 --> Loader Class Initialized
INFO - 2018-10-18 14:06:02 --> Helper loaded: url_helper
INFO - 2018-10-18 14:06:02 --> Helper loaded: form_helper
INFO - 2018-10-18 14:06:02 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:06:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:06:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:06:03 --> User Agent Class Initialized
INFO - 2018-10-18 14:06:03 --> Controller Class Initialized
INFO - 2018-10-18 14:06:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:06:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:06:03 --> Pixel_Model class loaded
INFO - 2018-10-18 14:06:03 --> Database Driver Class Initialized
INFO - 2018-10-18 14:06:03 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:06:03 --> Database Driver Class Initialized
INFO - 2018-10-18 14:06:03 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:06:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:06:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:06:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:06:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:06:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:06:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:06:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/inheritance_maintained.php
INFO - 2018-10-18 14:06:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:06:03 --> Final output sent to browser
DEBUG - 2018-10-18 14:06:03 --> Total execution time: 0.5591
INFO - 2018-10-18 14:06:03 --> Config Class Initialized
INFO - 2018-10-18 14:06:03 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:06:03 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:06:03 --> Utf8 Class Initialized
INFO - 2018-10-18 14:06:03 --> URI Class Initialized
INFO - 2018-10-18 14:06:03 --> Router Class Initialized
INFO - 2018-10-18 14:06:03 --> Output Class Initialized
INFO - 2018-10-18 14:06:03 --> Security Class Initialized
DEBUG - 2018-10-18 14:06:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:06:03 --> CSRF cookie sent
INFO - 2018-10-18 14:06:03 --> Input Class Initialized
INFO - 2018-10-18 14:06:03 --> Language Class Initialized
ERROR - 2018-10-18 14:06:03 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 14:06:05 --> Config Class Initialized
INFO - 2018-10-18 14:06:05 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:06:05 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:06:05 --> Utf8 Class Initialized
INFO - 2018-10-18 14:06:05 --> URI Class Initialized
INFO - 2018-10-18 14:06:05 --> Router Class Initialized
INFO - 2018-10-18 14:06:05 --> Output Class Initialized
INFO - 2018-10-18 14:06:05 --> Security Class Initialized
DEBUG - 2018-10-18 14:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:06:05 --> CSRF cookie sent
INFO - 2018-10-18 14:06:05 --> CSRF token verified
INFO - 2018-10-18 14:06:05 --> Input Class Initialized
INFO - 2018-10-18 14:06:05 --> Language Class Initialized
INFO - 2018-10-18 14:06:05 --> Loader Class Initialized
INFO - 2018-10-18 14:06:05 --> Helper loaded: url_helper
INFO - 2018-10-18 14:06:05 --> Helper loaded: form_helper
INFO - 2018-10-18 14:06:05 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:06:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:06:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:06:05 --> User Agent Class Initialized
INFO - 2018-10-18 14:06:05 --> Controller Class Initialized
INFO - 2018-10-18 14:06:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:06:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:06:05 --> Pixel_Model class loaded
INFO - 2018-10-18 14:06:05 --> Database Driver Class Initialized
INFO - 2018-10-18 14:06:05 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:06:05 --> Form Validation Class Initialized
INFO - 2018-10-18 14:06:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 14:06:05 --> Database Driver Class Initialized
INFO - 2018-10-18 14:06:05 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:06:05 --> Config Class Initialized
INFO - 2018-10-18 14:06:05 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:06:05 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:06:05 --> Utf8 Class Initialized
INFO - 2018-10-18 14:06:05 --> URI Class Initialized
INFO - 2018-10-18 14:06:05 --> Router Class Initialized
INFO - 2018-10-18 14:06:05 --> Output Class Initialized
INFO - 2018-10-18 14:06:05 --> Security Class Initialized
DEBUG - 2018-10-18 14:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:06:05 --> CSRF cookie sent
INFO - 2018-10-18 14:06:05 --> Input Class Initialized
INFO - 2018-10-18 14:06:05 --> Language Class Initialized
INFO - 2018-10-18 14:06:05 --> Loader Class Initialized
INFO - 2018-10-18 14:06:05 --> Helper loaded: url_helper
INFO - 2018-10-18 14:06:05 --> Helper loaded: form_helper
INFO - 2018-10-18 14:06:05 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:06:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:06:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:06:05 --> User Agent Class Initialized
INFO - 2018-10-18 14:06:05 --> Controller Class Initialized
INFO - 2018-10-18 14:06:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:06:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:06:05 --> Pixel_Model class loaded
INFO - 2018-10-18 14:06:05 --> Database Driver Class Initialized
INFO - 2018-10-18 14:06:05 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:06:05 --> Database Driver Class Initialized
INFO - 2018-10-18 14:06:05 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:06:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:06:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:06:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:06:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:06:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:06:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:06:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/home_owner.php
INFO - 2018-10-18 14:06:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:06:06 --> Final output sent to browser
DEBUG - 2018-10-18 14:06:06 --> Total execution time: 0.5615
INFO - 2018-10-18 14:06:06 --> Config Class Initialized
INFO - 2018-10-18 14:06:06 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:06:06 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:06:06 --> Utf8 Class Initialized
INFO - 2018-10-18 14:06:06 --> URI Class Initialized
INFO - 2018-10-18 14:06:06 --> Router Class Initialized
INFO - 2018-10-18 14:06:06 --> Output Class Initialized
INFO - 2018-10-18 14:06:06 --> Security Class Initialized
DEBUG - 2018-10-18 14:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:06:06 --> CSRF cookie sent
INFO - 2018-10-18 14:06:06 --> Input Class Initialized
INFO - 2018-10-18 14:06:06 --> Language Class Initialized
ERROR - 2018-10-18 14:06:06 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 14:06:11 --> Config Class Initialized
INFO - 2018-10-18 14:06:11 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:06:11 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:06:11 --> Utf8 Class Initialized
INFO - 2018-10-18 14:06:11 --> URI Class Initialized
INFO - 2018-10-18 14:06:11 --> Router Class Initialized
INFO - 2018-10-18 14:06:11 --> Output Class Initialized
INFO - 2018-10-18 14:06:11 --> Security Class Initialized
DEBUG - 2018-10-18 14:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:06:11 --> CSRF cookie sent
INFO - 2018-10-18 14:06:11 --> CSRF token verified
INFO - 2018-10-18 14:06:12 --> Input Class Initialized
INFO - 2018-10-18 14:06:12 --> Language Class Initialized
INFO - 2018-10-18 14:06:12 --> Loader Class Initialized
INFO - 2018-10-18 14:06:12 --> Helper loaded: url_helper
INFO - 2018-10-18 14:06:12 --> Helper loaded: form_helper
INFO - 2018-10-18 14:06:12 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:06:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:06:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:06:12 --> User Agent Class Initialized
INFO - 2018-10-18 14:06:12 --> Controller Class Initialized
INFO - 2018-10-18 14:06:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:06:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:06:12 --> Pixel_Model class loaded
INFO - 2018-10-18 14:06:12 --> Database Driver Class Initialized
INFO - 2018-10-18 14:06:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:06:12 --> Form Validation Class Initialized
INFO - 2018-10-18 14:06:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 14:06:12 --> Database Driver Class Initialized
INFO - 2018-10-18 14:06:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:06:12 --> Config Class Initialized
INFO - 2018-10-18 14:06:12 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:06:12 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:06:12 --> Utf8 Class Initialized
INFO - 2018-10-18 14:06:12 --> URI Class Initialized
INFO - 2018-10-18 14:06:12 --> Router Class Initialized
INFO - 2018-10-18 14:06:12 --> Output Class Initialized
INFO - 2018-10-18 14:06:12 --> Security Class Initialized
DEBUG - 2018-10-18 14:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:06:12 --> CSRF cookie sent
INFO - 2018-10-18 14:06:12 --> Input Class Initialized
INFO - 2018-10-18 14:06:12 --> Language Class Initialized
INFO - 2018-10-18 14:06:12 --> Loader Class Initialized
INFO - 2018-10-18 14:06:12 --> Helper loaded: url_helper
INFO - 2018-10-18 14:06:12 --> Helper loaded: form_helper
INFO - 2018-10-18 14:06:12 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:06:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:06:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:06:12 --> User Agent Class Initialized
INFO - 2018-10-18 14:06:12 --> Controller Class Initialized
INFO - 2018-10-18 14:06:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:06:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:06:12 --> Pixel_Model class loaded
INFO - 2018-10-18 14:06:12 --> Database Driver Class Initialized
INFO - 2018-10-18 14:06:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:06:12 --> Database Driver Class Initialized
INFO - 2018-10-18 14:06:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:06:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:06:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:06:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:06:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:06:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:06:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:06:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/home_value.php
INFO - 2018-10-18 14:06:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:06:12 --> Final output sent to browser
DEBUG - 2018-10-18 14:06:12 --> Total execution time: 0.5710
INFO - 2018-10-18 14:06:13 --> Config Class Initialized
INFO - 2018-10-18 14:06:13 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:06:13 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:06:13 --> Utf8 Class Initialized
INFO - 2018-10-18 14:06:13 --> URI Class Initialized
INFO - 2018-10-18 14:06:13 --> Router Class Initialized
INFO - 2018-10-18 14:06:13 --> Output Class Initialized
INFO - 2018-10-18 14:06:13 --> Security Class Initialized
DEBUG - 2018-10-18 14:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:06:13 --> CSRF cookie sent
INFO - 2018-10-18 14:06:13 --> Input Class Initialized
INFO - 2018-10-18 14:06:13 --> Language Class Initialized
ERROR - 2018-10-18 14:06:13 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 14:06:22 --> Config Class Initialized
INFO - 2018-10-18 14:06:22 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:06:22 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:06:22 --> Utf8 Class Initialized
INFO - 2018-10-18 14:06:22 --> URI Class Initialized
INFO - 2018-10-18 14:06:22 --> Router Class Initialized
INFO - 2018-10-18 14:06:22 --> Output Class Initialized
INFO - 2018-10-18 14:06:22 --> Security Class Initialized
DEBUG - 2018-10-18 14:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:06:22 --> CSRF cookie sent
INFO - 2018-10-18 14:06:22 --> CSRF token verified
INFO - 2018-10-18 14:06:22 --> Input Class Initialized
INFO - 2018-10-18 14:06:22 --> Language Class Initialized
INFO - 2018-10-18 14:06:22 --> Loader Class Initialized
INFO - 2018-10-18 14:06:22 --> Helper loaded: url_helper
INFO - 2018-10-18 14:06:22 --> Helper loaded: form_helper
INFO - 2018-10-18 14:06:22 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:06:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:06:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:06:22 --> User Agent Class Initialized
INFO - 2018-10-18 14:06:22 --> Controller Class Initialized
INFO - 2018-10-18 14:06:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:06:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:06:22 --> Pixel_Model class loaded
INFO - 2018-10-18 14:06:22 --> Database Driver Class Initialized
INFO - 2018-10-18 14:06:22 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:06:22 --> Form Validation Class Initialized
INFO - 2018-10-18 14:06:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 14:06:22 --> Database Driver Class Initialized
INFO - 2018-10-18 14:06:22 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:06:22 --> Config Class Initialized
INFO - 2018-10-18 14:06:22 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:06:22 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:06:22 --> Utf8 Class Initialized
INFO - 2018-10-18 14:06:22 --> URI Class Initialized
INFO - 2018-10-18 14:06:22 --> Router Class Initialized
INFO - 2018-10-18 14:06:22 --> Output Class Initialized
INFO - 2018-10-18 14:06:22 --> Security Class Initialized
DEBUG - 2018-10-18 14:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:06:22 --> CSRF cookie sent
INFO - 2018-10-18 14:06:22 --> Input Class Initialized
INFO - 2018-10-18 14:06:22 --> Language Class Initialized
INFO - 2018-10-18 14:06:22 --> Loader Class Initialized
INFO - 2018-10-18 14:06:22 --> Helper loaded: url_helper
INFO - 2018-10-18 14:06:22 --> Helper loaded: form_helper
INFO - 2018-10-18 14:06:22 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:06:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:06:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:06:22 --> User Agent Class Initialized
INFO - 2018-10-18 14:06:22 --> Controller Class Initialized
INFO - 2018-10-18 14:06:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:06:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:06:23 --> Pixel_Model class loaded
INFO - 2018-10-18 14:06:23 --> Database Driver Class Initialized
INFO - 2018-10-18 14:06:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:06:23 --> Database Driver Class Initialized
INFO - 2018-10-18 14:06:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:06:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:06:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:06:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:06:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:06:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:06:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:06:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/merriage_home_title.php
INFO - 2018-10-18 14:06:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:06:23 --> Final output sent to browser
DEBUG - 2018-10-18 14:06:23 --> Total execution time: 0.5964
INFO - 2018-10-18 14:06:23 --> Config Class Initialized
INFO - 2018-10-18 14:06:23 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:06:23 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:06:23 --> Utf8 Class Initialized
INFO - 2018-10-18 14:06:23 --> URI Class Initialized
INFO - 2018-10-18 14:06:23 --> Router Class Initialized
INFO - 2018-10-18 14:06:23 --> Output Class Initialized
INFO - 2018-10-18 14:06:23 --> Security Class Initialized
DEBUG - 2018-10-18 14:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:06:23 --> CSRF cookie sent
INFO - 2018-10-18 14:06:23 --> Input Class Initialized
INFO - 2018-10-18 14:06:23 --> Language Class Initialized
ERROR - 2018-10-18 14:06:23 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 14:06:25 --> Config Class Initialized
INFO - 2018-10-18 14:06:25 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:06:25 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:06:25 --> Utf8 Class Initialized
INFO - 2018-10-18 14:06:25 --> URI Class Initialized
INFO - 2018-10-18 14:06:25 --> Router Class Initialized
INFO - 2018-10-18 14:06:25 --> Output Class Initialized
INFO - 2018-10-18 14:06:25 --> Security Class Initialized
DEBUG - 2018-10-18 14:06:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:06:25 --> CSRF cookie sent
INFO - 2018-10-18 14:06:25 --> CSRF token verified
INFO - 2018-10-18 14:06:25 --> Input Class Initialized
INFO - 2018-10-18 14:06:25 --> Language Class Initialized
INFO - 2018-10-18 14:06:25 --> Loader Class Initialized
INFO - 2018-10-18 14:06:25 --> Helper loaded: url_helper
INFO - 2018-10-18 14:06:25 --> Helper loaded: form_helper
INFO - 2018-10-18 14:06:25 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:06:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:06:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:06:25 --> User Agent Class Initialized
INFO - 2018-10-18 14:06:25 --> Controller Class Initialized
INFO - 2018-10-18 14:06:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:06:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:06:25 --> Pixel_Model class loaded
INFO - 2018-10-18 14:06:25 --> Database Driver Class Initialized
INFO - 2018-10-18 14:06:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:06:25 --> Form Validation Class Initialized
INFO - 2018-10-18 14:06:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 14:06:25 --> Database Driver Class Initialized
INFO - 2018-10-18 14:06:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:06:25 --> Config Class Initialized
INFO - 2018-10-18 14:06:25 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:06:25 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:06:25 --> Utf8 Class Initialized
INFO - 2018-10-18 14:06:25 --> URI Class Initialized
INFO - 2018-10-18 14:06:25 --> Router Class Initialized
INFO - 2018-10-18 14:06:25 --> Output Class Initialized
INFO - 2018-10-18 14:06:25 --> Security Class Initialized
DEBUG - 2018-10-18 14:06:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:06:25 --> CSRF cookie sent
INFO - 2018-10-18 14:06:25 --> Input Class Initialized
INFO - 2018-10-18 14:06:25 --> Language Class Initialized
INFO - 2018-10-18 14:06:25 --> Loader Class Initialized
INFO - 2018-10-18 14:06:25 --> Helper loaded: url_helper
INFO - 2018-10-18 14:06:25 --> Helper loaded: form_helper
INFO - 2018-10-18 14:06:25 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:06:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:06:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:06:25 --> User Agent Class Initialized
INFO - 2018-10-18 14:06:25 --> Controller Class Initialized
INFO - 2018-10-18 14:06:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:06:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:06:25 --> Pixel_Model class loaded
INFO - 2018-10-18 14:06:25 --> Database Driver Class Initialized
INFO - 2018-10-18 14:06:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:06:26 --> Database Driver Class Initialized
INFO - 2018-10-18 14:06:26 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:06:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:06:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:06:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:06:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:06:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:06:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:06:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/financial.php
INFO - 2018-10-18 14:06:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:06:26 --> Final output sent to browser
DEBUG - 2018-10-18 14:06:26 --> Total execution time: 0.5854
INFO - 2018-10-18 14:06:26 --> Config Class Initialized
INFO - 2018-10-18 14:06:26 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:06:26 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:06:26 --> Utf8 Class Initialized
INFO - 2018-10-18 14:06:26 --> URI Class Initialized
INFO - 2018-10-18 14:06:26 --> Router Class Initialized
INFO - 2018-10-18 14:06:26 --> Output Class Initialized
INFO - 2018-10-18 14:06:26 --> Security Class Initialized
DEBUG - 2018-10-18 14:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:06:26 --> CSRF cookie sent
INFO - 2018-10-18 14:06:26 --> Input Class Initialized
INFO - 2018-10-18 14:06:26 --> Language Class Initialized
ERROR - 2018-10-18 14:06:26 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 14:06:29 --> Config Class Initialized
INFO - 2018-10-18 14:06:29 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:06:29 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:06:29 --> Utf8 Class Initialized
INFO - 2018-10-18 14:06:29 --> URI Class Initialized
INFO - 2018-10-18 14:06:29 --> Router Class Initialized
INFO - 2018-10-18 14:06:29 --> Output Class Initialized
INFO - 2018-10-18 14:06:29 --> Security Class Initialized
DEBUG - 2018-10-18 14:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:06:29 --> CSRF cookie sent
INFO - 2018-10-18 14:06:29 --> Input Class Initialized
INFO - 2018-10-18 14:06:29 --> Language Class Initialized
INFO - 2018-10-18 14:06:29 --> Loader Class Initialized
INFO - 2018-10-18 14:06:29 --> Helper loaded: url_helper
INFO - 2018-10-18 14:06:29 --> Helper loaded: form_helper
INFO - 2018-10-18 14:06:29 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:06:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:06:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:06:29 --> User Agent Class Initialized
INFO - 2018-10-18 14:06:29 --> Controller Class Initialized
INFO - 2018-10-18 14:06:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:06:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:06:29 --> Pixel_Model class loaded
INFO - 2018-10-18 14:06:29 --> Database Driver Class Initialized
INFO - 2018-10-18 14:06:29 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:06:29 --> Database Driver Class Initialized
INFO - 2018-10-18 14:06:29 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:06:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:06:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:06:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:06:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:06:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:06:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:06:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/merriage_home_title.php
INFO - 2018-10-18 14:06:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:06:29 --> Final output sent to browser
DEBUG - 2018-10-18 14:06:29 --> Total execution time: 0.6113
INFO - 2018-10-18 14:06:30 --> Config Class Initialized
INFO - 2018-10-18 14:06:30 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:06:30 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:06:30 --> Utf8 Class Initialized
INFO - 2018-10-18 14:06:30 --> URI Class Initialized
INFO - 2018-10-18 14:06:30 --> Router Class Initialized
INFO - 2018-10-18 14:06:30 --> Output Class Initialized
INFO - 2018-10-18 14:06:30 --> Security Class Initialized
DEBUG - 2018-10-18 14:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:06:30 --> CSRF cookie sent
INFO - 2018-10-18 14:06:30 --> Input Class Initialized
INFO - 2018-10-18 14:06:30 --> Language Class Initialized
ERROR - 2018-10-18 14:06:30 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 14:06:36 --> Config Class Initialized
INFO - 2018-10-18 14:06:36 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:06:36 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:06:36 --> Utf8 Class Initialized
INFO - 2018-10-18 14:06:36 --> URI Class Initialized
INFO - 2018-10-18 14:06:36 --> Router Class Initialized
INFO - 2018-10-18 14:06:36 --> Output Class Initialized
INFO - 2018-10-18 14:06:36 --> Security Class Initialized
DEBUG - 2018-10-18 14:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:06:36 --> CSRF cookie sent
INFO - 2018-10-18 14:06:36 --> CSRF token verified
INFO - 2018-10-18 14:06:36 --> Input Class Initialized
INFO - 2018-10-18 14:06:36 --> Language Class Initialized
INFO - 2018-10-18 14:06:36 --> Loader Class Initialized
INFO - 2018-10-18 14:06:36 --> Helper loaded: url_helper
INFO - 2018-10-18 14:06:36 --> Helper loaded: form_helper
INFO - 2018-10-18 14:06:36 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:06:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:06:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:06:36 --> User Agent Class Initialized
INFO - 2018-10-18 14:06:36 --> Controller Class Initialized
INFO - 2018-10-18 14:06:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:06:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:06:36 --> Pixel_Model class loaded
INFO - 2018-10-18 14:06:36 --> Database Driver Class Initialized
INFO - 2018-10-18 14:06:36 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:06:36 --> Form Validation Class Initialized
INFO - 2018-10-18 14:06:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 14:06:36 --> Database Driver Class Initialized
INFO - 2018-10-18 14:06:36 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:06:36 --> Config Class Initialized
INFO - 2018-10-18 14:06:36 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:06:36 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:06:36 --> Utf8 Class Initialized
INFO - 2018-10-18 14:06:37 --> URI Class Initialized
INFO - 2018-10-18 14:06:37 --> Router Class Initialized
INFO - 2018-10-18 14:06:37 --> Output Class Initialized
INFO - 2018-10-18 14:06:37 --> Security Class Initialized
DEBUG - 2018-10-18 14:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:06:37 --> CSRF cookie sent
INFO - 2018-10-18 14:06:37 --> Input Class Initialized
INFO - 2018-10-18 14:06:37 --> Language Class Initialized
INFO - 2018-10-18 14:06:37 --> Loader Class Initialized
INFO - 2018-10-18 14:06:37 --> Helper loaded: url_helper
INFO - 2018-10-18 14:06:37 --> Helper loaded: form_helper
INFO - 2018-10-18 14:06:37 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:06:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:06:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:06:37 --> User Agent Class Initialized
INFO - 2018-10-18 14:06:37 --> Controller Class Initialized
INFO - 2018-10-18 14:06:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:06:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:06:37 --> Pixel_Model class loaded
INFO - 2018-10-18 14:06:37 --> Database Driver Class Initialized
INFO - 2018-10-18 14:06:37 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:06:37 --> Database Driver Class Initialized
INFO - 2018-10-18 14:06:37 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:06:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:06:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:06:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:06:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:06:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:06:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:06:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/financial.php
INFO - 2018-10-18 14:06:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:06:37 --> Final output sent to browser
DEBUG - 2018-10-18 14:06:37 --> Total execution time: 0.5869
INFO - 2018-10-18 14:06:37 --> Config Class Initialized
INFO - 2018-10-18 14:06:37 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:06:37 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:06:37 --> Utf8 Class Initialized
INFO - 2018-10-18 14:06:37 --> URI Class Initialized
INFO - 2018-10-18 14:06:37 --> Router Class Initialized
INFO - 2018-10-18 14:06:37 --> Output Class Initialized
INFO - 2018-10-18 14:06:37 --> Security Class Initialized
DEBUG - 2018-10-18 14:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:06:37 --> CSRF cookie sent
INFO - 2018-10-18 14:06:38 --> Input Class Initialized
INFO - 2018-10-18 14:06:38 --> Language Class Initialized
ERROR - 2018-10-18 14:06:38 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 14:06:41 --> Config Class Initialized
INFO - 2018-10-18 14:06:41 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:06:41 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:06:41 --> Utf8 Class Initialized
INFO - 2018-10-18 14:06:41 --> URI Class Initialized
INFO - 2018-10-18 14:06:41 --> Router Class Initialized
INFO - 2018-10-18 14:06:41 --> Output Class Initialized
INFO - 2018-10-18 14:06:41 --> Security Class Initialized
DEBUG - 2018-10-18 14:06:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:06:41 --> CSRF cookie sent
INFO - 2018-10-18 14:06:42 --> CSRF token verified
INFO - 2018-10-18 14:06:42 --> Input Class Initialized
INFO - 2018-10-18 14:06:42 --> Language Class Initialized
INFO - 2018-10-18 14:06:42 --> Loader Class Initialized
INFO - 2018-10-18 14:06:42 --> Helper loaded: url_helper
INFO - 2018-10-18 14:06:42 --> Helper loaded: form_helper
INFO - 2018-10-18 14:06:42 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:06:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:06:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:06:42 --> User Agent Class Initialized
INFO - 2018-10-18 14:06:42 --> Controller Class Initialized
INFO - 2018-10-18 14:06:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:06:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:06:42 --> Pixel_Model class loaded
INFO - 2018-10-18 14:06:42 --> Database Driver Class Initialized
INFO - 2018-10-18 14:06:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:06:42 --> Form Validation Class Initialized
INFO - 2018-10-18 14:06:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 14:06:42 --> Database Driver Class Initialized
INFO - 2018-10-18 14:06:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:06:42 --> Config Class Initialized
INFO - 2018-10-18 14:06:42 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:06:42 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:06:42 --> Utf8 Class Initialized
INFO - 2018-10-18 14:06:42 --> URI Class Initialized
INFO - 2018-10-18 14:06:42 --> Router Class Initialized
INFO - 2018-10-18 14:06:42 --> Output Class Initialized
INFO - 2018-10-18 14:06:42 --> Security Class Initialized
DEBUG - 2018-10-18 14:06:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:06:42 --> CSRF cookie sent
INFO - 2018-10-18 14:06:42 --> Input Class Initialized
INFO - 2018-10-18 14:06:42 --> Language Class Initialized
INFO - 2018-10-18 14:06:42 --> Loader Class Initialized
INFO - 2018-10-18 14:06:42 --> Helper loaded: url_helper
INFO - 2018-10-18 14:06:42 --> Helper loaded: form_helper
INFO - 2018-10-18 14:06:42 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:06:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:06:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:06:42 --> User Agent Class Initialized
INFO - 2018-10-18 14:06:42 --> Controller Class Initialized
INFO - 2018-10-18 14:06:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:06:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:06:42 --> Pixel_Model class loaded
INFO - 2018-10-18 14:06:42 --> Database Driver Class Initialized
INFO - 2018-10-18 14:06:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:06:42 --> Database Driver Class Initialized
INFO - 2018-10-18 14:06:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:06:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:06:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:06:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:06:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:06:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:06:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:06:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/spouse_info.php
INFO - 2018-10-18 14:06:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:06:43 --> Final output sent to browser
DEBUG - 2018-10-18 14:06:43 --> Total execution time: 0.5856
INFO - 2018-10-18 14:06:43 --> Config Class Initialized
INFO - 2018-10-18 14:06:43 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:06:43 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:06:43 --> Utf8 Class Initialized
INFO - 2018-10-18 14:06:43 --> URI Class Initialized
INFO - 2018-10-18 14:06:43 --> Router Class Initialized
INFO - 2018-10-18 14:06:43 --> Output Class Initialized
INFO - 2018-10-18 14:06:43 --> Security Class Initialized
DEBUG - 2018-10-18 14:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:06:43 --> CSRF cookie sent
INFO - 2018-10-18 14:06:43 --> Input Class Initialized
INFO - 2018-10-18 14:06:43 --> Language Class Initialized
ERROR - 2018-10-18 14:06:43 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 14:06:48 --> Config Class Initialized
INFO - 2018-10-18 14:06:48 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:06:48 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:06:48 --> Utf8 Class Initialized
INFO - 2018-10-18 14:06:48 --> URI Class Initialized
INFO - 2018-10-18 14:06:48 --> Router Class Initialized
INFO - 2018-10-18 14:06:48 --> Output Class Initialized
INFO - 2018-10-18 14:06:48 --> Security Class Initialized
DEBUG - 2018-10-18 14:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:06:48 --> CSRF cookie sent
INFO - 2018-10-18 14:06:48 --> CSRF token verified
INFO - 2018-10-18 14:06:48 --> Input Class Initialized
INFO - 2018-10-18 14:06:48 --> Language Class Initialized
INFO - 2018-10-18 14:06:48 --> Loader Class Initialized
INFO - 2018-10-18 14:06:48 --> Helper loaded: url_helper
INFO - 2018-10-18 14:06:48 --> Helper loaded: form_helper
INFO - 2018-10-18 14:06:48 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:06:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:06:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:06:48 --> User Agent Class Initialized
INFO - 2018-10-18 14:06:48 --> Controller Class Initialized
INFO - 2018-10-18 14:06:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:06:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:06:48 --> Pixel_Model class loaded
INFO - 2018-10-18 14:06:48 --> Database Driver Class Initialized
INFO - 2018-10-18 14:06:48 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:06:48 --> Form Validation Class Initialized
INFO - 2018-10-18 14:06:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 14:06:48 --> Database Driver Class Initialized
INFO - 2018-10-18 14:06:48 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:06:48 --> Config Class Initialized
INFO - 2018-10-18 14:06:48 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:06:48 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:06:48 --> Utf8 Class Initialized
INFO - 2018-10-18 14:06:48 --> URI Class Initialized
INFO - 2018-10-18 14:06:48 --> Router Class Initialized
INFO - 2018-10-18 14:06:48 --> Output Class Initialized
INFO - 2018-10-18 14:06:48 --> Security Class Initialized
DEBUG - 2018-10-18 14:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:06:48 --> CSRF cookie sent
INFO - 2018-10-18 14:06:49 --> Input Class Initialized
INFO - 2018-10-18 14:06:49 --> Language Class Initialized
INFO - 2018-10-18 14:06:49 --> Loader Class Initialized
INFO - 2018-10-18 14:06:49 --> Helper loaded: url_helper
INFO - 2018-10-18 14:06:49 --> Helper loaded: form_helper
INFO - 2018-10-18 14:06:49 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:06:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:06:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:06:49 --> User Agent Class Initialized
INFO - 2018-10-18 14:06:49 --> Controller Class Initialized
INFO - 2018-10-18 14:06:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:06:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:06:49 --> Pixel_Model class loaded
INFO - 2018-10-18 14:06:49 --> Database Driver Class Initialized
INFO - 2018-10-18 14:06:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:06:49 --> Database Driver Class Initialized
INFO - 2018-10-18 14:06:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:06:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:06:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:06:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:06:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:06:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:06:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:06:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/spouse_job.php
INFO - 2018-10-18 14:06:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:06:49 --> Final output sent to browser
DEBUG - 2018-10-18 14:06:49 --> Total execution time: 0.5813
INFO - 2018-10-18 14:06:49 --> Config Class Initialized
INFO - 2018-10-18 14:06:49 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:06:49 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:06:49 --> Utf8 Class Initialized
INFO - 2018-10-18 14:06:49 --> URI Class Initialized
INFO - 2018-10-18 14:06:49 --> Router Class Initialized
INFO - 2018-10-18 14:06:49 --> Output Class Initialized
INFO - 2018-10-18 14:06:49 --> Security Class Initialized
DEBUG - 2018-10-18 14:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:06:49 --> CSRF cookie sent
INFO - 2018-10-18 14:06:49 --> Input Class Initialized
INFO - 2018-10-18 14:06:49 --> Language Class Initialized
ERROR - 2018-10-18 14:06:49 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 14:06:51 --> Config Class Initialized
INFO - 2018-10-18 14:06:51 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:06:51 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:06:51 --> Utf8 Class Initialized
INFO - 2018-10-18 14:06:51 --> URI Class Initialized
INFO - 2018-10-18 14:06:51 --> Router Class Initialized
INFO - 2018-10-18 14:06:51 --> Output Class Initialized
INFO - 2018-10-18 14:06:51 --> Security Class Initialized
DEBUG - 2018-10-18 14:06:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:06:51 --> CSRF cookie sent
INFO - 2018-10-18 14:06:51 --> CSRF token verified
INFO - 2018-10-18 14:06:51 --> Input Class Initialized
INFO - 2018-10-18 14:06:51 --> Language Class Initialized
INFO - 2018-10-18 14:06:51 --> Loader Class Initialized
INFO - 2018-10-18 14:06:51 --> Helper loaded: url_helper
INFO - 2018-10-18 14:06:51 --> Helper loaded: form_helper
INFO - 2018-10-18 14:06:51 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:06:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:06:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:06:51 --> User Agent Class Initialized
INFO - 2018-10-18 14:06:51 --> Controller Class Initialized
INFO - 2018-10-18 14:06:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:06:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:06:51 --> Pixel_Model class loaded
INFO - 2018-10-18 14:06:51 --> Database Driver Class Initialized
INFO - 2018-10-18 14:06:51 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:06:51 --> Form Validation Class Initialized
INFO - 2018-10-18 14:06:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 14:06:51 --> Database Driver Class Initialized
INFO - 2018-10-18 14:06:51 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:06:51 --> Config Class Initialized
INFO - 2018-10-18 14:06:51 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:06:51 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:06:51 --> Utf8 Class Initialized
INFO - 2018-10-18 14:06:51 --> URI Class Initialized
INFO - 2018-10-18 14:06:51 --> Router Class Initialized
INFO - 2018-10-18 14:06:51 --> Output Class Initialized
INFO - 2018-10-18 14:06:51 --> Security Class Initialized
DEBUG - 2018-10-18 14:06:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:06:51 --> CSRF cookie sent
INFO - 2018-10-18 14:06:51 --> Input Class Initialized
INFO - 2018-10-18 14:06:51 --> Language Class Initialized
INFO - 2018-10-18 14:06:51 --> Loader Class Initialized
INFO - 2018-10-18 14:06:51 --> Helper loaded: url_helper
INFO - 2018-10-18 14:06:51 --> Helper loaded: form_helper
INFO - 2018-10-18 14:06:52 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:06:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:06:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:06:52 --> User Agent Class Initialized
INFO - 2018-10-18 14:06:52 --> Controller Class Initialized
INFO - 2018-10-18 14:06:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:06:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:06:52 --> Pixel_Model class loaded
INFO - 2018-10-18 14:06:52 --> Database Driver Class Initialized
INFO - 2018-10-18 14:06:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:06:52 --> Database Driver Class Initialized
INFO - 2018-10-18 14:06:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:06:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:06:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:06:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:06:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:06:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:06:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:06:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/affectionate_salutation.php
INFO - 2018-10-18 14:06:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:06:52 --> Final output sent to browser
DEBUG - 2018-10-18 14:06:52 --> Total execution time: 0.5710
INFO - 2018-10-18 14:06:52 --> Config Class Initialized
INFO - 2018-10-18 14:06:52 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:06:52 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:06:52 --> Utf8 Class Initialized
INFO - 2018-10-18 14:06:52 --> URI Class Initialized
INFO - 2018-10-18 14:06:52 --> Router Class Initialized
INFO - 2018-10-18 14:06:52 --> Output Class Initialized
INFO - 2018-10-18 14:06:52 --> Security Class Initialized
DEBUG - 2018-10-18 14:06:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:06:52 --> CSRF cookie sent
INFO - 2018-10-18 14:06:52 --> Input Class Initialized
INFO - 2018-10-18 14:06:52 --> Language Class Initialized
ERROR - 2018-10-18 14:06:52 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 14:06:55 --> Config Class Initialized
INFO - 2018-10-18 14:06:55 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:06:55 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:06:55 --> Utf8 Class Initialized
INFO - 2018-10-18 14:06:55 --> URI Class Initialized
INFO - 2018-10-18 14:06:55 --> Router Class Initialized
INFO - 2018-10-18 14:06:55 --> Output Class Initialized
INFO - 2018-10-18 14:06:55 --> Security Class Initialized
DEBUG - 2018-10-18 14:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:06:55 --> CSRF cookie sent
INFO - 2018-10-18 14:06:55 --> CSRF token verified
INFO - 2018-10-18 14:06:55 --> Input Class Initialized
INFO - 2018-10-18 14:06:56 --> Language Class Initialized
INFO - 2018-10-18 14:06:56 --> Loader Class Initialized
INFO - 2018-10-18 14:06:56 --> Helper loaded: url_helper
INFO - 2018-10-18 14:06:56 --> Helper loaded: form_helper
INFO - 2018-10-18 14:06:56 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:06:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:06:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:06:56 --> User Agent Class Initialized
INFO - 2018-10-18 14:06:56 --> Controller Class Initialized
INFO - 2018-10-18 14:06:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:06:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:06:56 --> Pixel_Model class loaded
INFO - 2018-10-18 14:06:56 --> Database Driver Class Initialized
INFO - 2018-10-18 14:06:56 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:06:56 --> Form Validation Class Initialized
INFO - 2018-10-18 14:06:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 14:06:56 --> Database Driver Class Initialized
INFO - 2018-10-18 14:06:56 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:06:56 --> Config Class Initialized
INFO - 2018-10-18 14:06:56 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:06:56 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:06:56 --> Utf8 Class Initialized
INFO - 2018-10-18 14:06:56 --> URI Class Initialized
INFO - 2018-10-18 14:06:56 --> Router Class Initialized
INFO - 2018-10-18 14:06:56 --> Output Class Initialized
INFO - 2018-10-18 14:06:56 --> Security Class Initialized
DEBUG - 2018-10-18 14:06:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:06:56 --> CSRF cookie sent
INFO - 2018-10-18 14:06:56 --> Input Class Initialized
INFO - 2018-10-18 14:06:56 --> Language Class Initialized
INFO - 2018-10-18 14:06:56 --> Loader Class Initialized
INFO - 2018-10-18 14:06:56 --> Helper loaded: url_helper
INFO - 2018-10-18 14:06:56 --> Helper loaded: form_helper
INFO - 2018-10-18 14:06:56 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:06:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:06:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:06:56 --> User Agent Class Initialized
INFO - 2018-10-18 14:06:56 --> Controller Class Initialized
INFO - 2018-10-18 14:06:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:06:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:06:56 --> Pixel_Model class loaded
INFO - 2018-10-18 14:06:56 --> Database Driver Class Initialized
INFO - 2018-10-18 14:06:56 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:06:56 --> Database Driver Class Initialized
INFO - 2018-10-18 14:06:56 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:06:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:06:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:06:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:06:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:06:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:06:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:06:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/additional_business_info.php
INFO - 2018-10-18 14:06:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:06:57 --> Final output sent to browser
DEBUG - 2018-10-18 14:06:57 --> Total execution time: 0.6221
INFO - 2018-10-18 14:06:57 --> Config Class Initialized
INFO - 2018-10-18 14:06:57 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:06:57 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:06:57 --> Utf8 Class Initialized
INFO - 2018-10-18 14:06:57 --> URI Class Initialized
INFO - 2018-10-18 14:06:57 --> Router Class Initialized
INFO - 2018-10-18 14:06:57 --> Output Class Initialized
INFO - 2018-10-18 14:06:57 --> Security Class Initialized
DEBUG - 2018-10-18 14:06:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:06:57 --> CSRF cookie sent
INFO - 2018-10-18 14:06:57 --> Input Class Initialized
INFO - 2018-10-18 14:06:57 --> Language Class Initialized
ERROR - 2018-10-18 14:06:57 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 14:06:58 --> Config Class Initialized
INFO - 2018-10-18 14:06:58 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:06:58 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:06:58 --> Utf8 Class Initialized
INFO - 2018-10-18 14:06:58 --> URI Class Initialized
INFO - 2018-10-18 14:06:58 --> Router Class Initialized
INFO - 2018-10-18 14:06:58 --> Output Class Initialized
INFO - 2018-10-18 14:06:58 --> Security Class Initialized
DEBUG - 2018-10-18 14:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:06:58 --> CSRF cookie sent
INFO - 2018-10-18 14:06:58 --> CSRF token verified
INFO - 2018-10-18 14:06:58 --> Input Class Initialized
INFO - 2018-10-18 14:06:58 --> Language Class Initialized
INFO - 2018-10-18 14:06:58 --> Loader Class Initialized
INFO - 2018-10-18 14:06:58 --> Helper loaded: url_helper
INFO - 2018-10-18 14:06:58 --> Helper loaded: form_helper
INFO - 2018-10-18 14:06:58 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:06:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:06:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:06:58 --> User Agent Class Initialized
INFO - 2018-10-18 14:06:58 --> Controller Class Initialized
INFO - 2018-10-18 14:06:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:06:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:06:59 --> Pixel_Model class loaded
INFO - 2018-10-18 14:06:59 --> Database Driver Class Initialized
INFO - 2018-10-18 14:06:59 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:06:59 --> Form Validation Class Initialized
INFO - 2018-10-18 14:06:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 14:06:59 --> Database Driver Class Initialized
INFO - 2018-10-18 14:06:59 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:06:59 --> Config Class Initialized
INFO - 2018-10-18 14:06:59 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:06:59 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:06:59 --> Utf8 Class Initialized
INFO - 2018-10-18 14:06:59 --> URI Class Initialized
INFO - 2018-10-18 14:06:59 --> Router Class Initialized
INFO - 2018-10-18 14:06:59 --> Output Class Initialized
INFO - 2018-10-18 14:06:59 --> Security Class Initialized
DEBUG - 2018-10-18 14:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:06:59 --> CSRF cookie sent
INFO - 2018-10-18 14:06:59 --> Input Class Initialized
INFO - 2018-10-18 14:06:59 --> Language Class Initialized
INFO - 2018-10-18 14:06:59 --> Loader Class Initialized
INFO - 2018-10-18 14:06:59 --> Helper loaded: url_helper
INFO - 2018-10-18 14:06:59 --> Helper loaded: form_helper
INFO - 2018-10-18 14:06:59 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:06:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:06:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:06:59 --> User Agent Class Initialized
INFO - 2018-10-18 14:06:59 --> Controller Class Initialized
INFO - 2018-10-18 14:06:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:06:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:06:59 --> Pixel_Model class loaded
INFO - 2018-10-18 14:06:59 --> Database Driver Class Initialized
INFO - 2018-10-18 14:06:59 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:06:59 --> Database Driver Class Initialized
INFO - 2018-10-18 14:06:59 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:06:59 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:06:59 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:06:59 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:06:59 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:06:59 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:06:59 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:06:59 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/business_tax_info.php
INFO - 2018-10-18 14:06:59 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:06:59 --> Final output sent to browser
DEBUG - 2018-10-18 14:06:59 --> Total execution time: 0.5880
INFO - 2018-10-18 14:07:00 --> Config Class Initialized
INFO - 2018-10-18 14:07:00 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:07:00 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:07:00 --> Utf8 Class Initialized
INFO - 2018-10-18 14:07:00 --> URI Class Initialized
INFO - 2018-10-18 14:07:00 --> Router Class Initialized
INFO - 2018-10-18 14:07:00 --> Output Class Initialized
INFO - 2018-10-18 14:07:00 --> Security Class Initialized
DEBUG - 2018-10-18 14:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:07:00 --> CSRF cookie sent
INFO - 2018-10-18 14:07:00 --> Input Class Initialized
INFO - 2018-10-18 14:07:00 --> Language Class Initialized
ERROR - 2018-10-18 14:07:00 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 14:07:04 --> Config Class Initialized
INFO - 2018-10-18 14:07:04 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:07:05 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:07:05 --> Utf8 Class Initialized
INFO - 2018-10-18 14:07:05 --> URI Class Initialized
INFO - 2018-10-18 14:07:05 --> Router Class Initialized
INFO - 2018-10-18 14:07:05 --> Output Class Initialized
INFO - 2018-10-18 14:07:05 --> Security Class Initialized
DEBUG - 2018-10-18 14:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:07:05 --> CSRF cookie sent
INFO - 2018-10-18 14:07:05 --> CSRF token verified
INFO - 2018-10-18 14:07:05 --> Input Class Initialized
INFO - 2018-10-18 14:07:05 --> Language Class Initialized
INFO - 2018-10-18 14:07:05 --> Loader Class Initialized
INFO - 2018-10-18 14:07:05 --> Helper loaded: url_helper
INFO - 2018-10-18 14:07:05 --> Helper loaded: form_helper
INFO - 2018-10-18 14:07:05 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:07:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:07:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:07:05 --> User Agent Class Initialized
INFO - 2018-10-18 14:07:05 --> Controller Class Initialized
INFO - 2018-10-18 14:07:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:07:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:07:05 --> Pixel_Model class loaded
INFO - 2018-10-18 14:07:05 --> Database Driver Class Initialized
INFO - 2018-10-18 14:07:05 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:07:05 --> Form Validation Class Initialized
INFO - 2018-10-18 14:07:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 14:07:05 --> Database Driver Class Initialized
INFO - 2018-10-18 14:07:05 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:07:05 --> Config Class Initialized
INFO - 2018-10-18 14:07:05 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:07:05 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:07:05 --> Utf8 Class Initialized
INFO - 2018-10-18 14:07:05 --> URI Class Initialized
INFO - 2018-10-18 14:07:05 --> Router Class Initialized
INFO - 2018-10-18 14:07:05 --> Output Class Initialized
INFO - 2018-10-18 14:07:05 --> Security Class Initialized
DEBUG - 2018-10-18 14:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:07:05 --> CSRF cookie sent
INFO - 2018-10-18 14:07:05 --> Input Class Initialized
INFO - 2018-10-18 14:07:05 --> Language Class Initialized
INFO - 2018-10-18 14:07:05 --> Loader Class Initialized
INFO - 2018-10-18 14:07:05 --> Helper loaded: url_helper
INFO - 2018-10-18 14:07:05 --> Helper loaded: form_helper
INFO - 2018-10-18 14:07:05 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:07:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:07:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:07:05 --> User Agent Class Initialized
INFO - 2018-10-18 14:07:05 --> Controller Class Initialized
INFO - 2018-10-18 14:07:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:07:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:07:05 --> Pixel_Model class loaded
INFO - 2018-10-18 14:07:05 --> Database Driver Class Initialized
INFO - 2018-10-18 14:07:05 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:07:05 --> Database Driver Class Initialized
INFO - 2018-10-18 14:07:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:07:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:07:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:07:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:07:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:07:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:07:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:07:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/trust_info.php
INFO - 2018-10-18 14:07:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:07:06 --> Final output sent to browser
DEBUG - 2018-10-18 14:07:06 --> Total execution time: 0.6102
INFO - 2018-10-18 14:07:06 --> Config Class Initialized
INFO - 2018-10-18 14:07:06 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:07:06 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:07:06 --> Utf8 Class Initialized
INFO - 2018-10-18 14:07:06 --> URI Class Initialized
INFO - 2018-10-18 14:07:06 --> Router Class Initialized
INFO - 2018-10-18 14:07:06 --> Output Class Initialized
INFO - 2018-10-18 14:07:06 --> Security Class Initialized
DEBUG - 2018-10-18 14:07:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:07:06 --> CSRF cookie sent
INFO - 2018-10-18 14:07:06 --> Input Class Initialized
INFO - 2018-10-18 14:07:06 --> Language Class Initialized
ERROR - 2018-10-18 14:07:06 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 14:07:09 --> Config Class Initialized
INFO - 2018-10-18 14:07:09 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:07:09 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:07:09 --> Utf8 Class Initialized
INFO - 2018-10-18 14:07:09 --> URI Class Initialized
INFO - 2018-10-18 14:07:09 --> Router Class Initialized
INFO - 2018-10-18 14:07:09 --> Output Class Initialized
INFO - 2018-10-18 14:07:09 --> Security Class Initialized
DEBUG - 2018-10-18 14:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:07:09 --> CSRF cookie sent
INFO - 2018-10-18 14:07:09 --> CSRF token verified
INFO - 2018-10-18 14:07:09 --> Input Class Initialized
INFO - 2018-10-18 14:07:09 --> Language Class Initialized
INFO - 2018-10-18 14:07:10 --> Loader Class Initialized
INFO - 2018-10-18 14:07:10 --> Helper loaded: url_helper
INFO - 2018-10-18 14:07:10 --> Helper loaded: form_helper
INFO - 2018-10-18 14:07:10 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:07:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:07:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:07:10 --> User Agent Class Initialized
INFO - 2018-10-18 14:07:10 --> Controller Class Initialized
INFO - 2018-10-18 14:07:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:07:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:07:10 --> Pixel_Model class loaded
INFO - 2018-10-18 14:07:10 --> Database Driver Class Initialized
INFO - 2018-10-18 14:07:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:07:10 --> Form Validation Class Initialized
INFO - 2018-10-18 14:07:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 14:07:10 --> Database Driver Class Initialized
INFO - 2018-10-18 14:07:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:07:10 --> Config Class Initialized
INFO - 2018-10-18 14:07:10 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:07:10 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:07:10 --> Utf8 Class Initialized
INFO - 2018-10-18 14:07:10 --> URI Class Initialized
INFO - 2018-10-18 14:07:10 --> Router Class Initialized
INFO - 2018-10-18 14:07:10 --> Output Class Initialized
INFO - 2018-10-18 14:07:10 --> Security Class Initialized
DEBUG - 2018-10-18 14:07:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:07:10 --> CSRF cookie sent
INFO - 2018-10-18 14:07:10 --> Input Class Initialized
INFO - 2018-10-18 14:07:10 --> Language Class Initialized
INFO - 2018-10-18 14:07:10 --> Loader Class Initialized
INFO - 2018-10-18 14:07:10 --> Helper loaded: url_helper
INFO - 2018-10-18 14:07:10 --> Helper loaded: form_helper
INFO - 2018-10-18 14:07:10 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:07:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:07:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:07:10 --> User Agent Class Initialized
INFO - 2018-10-18 14:07:10 --> Controller Class Initialized
INFO - 2018-10-18 14:07:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:07:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:07:10 --> Pixel_Model class loaded
INFO - 2018-10-18 14:07:10 --> Database Driver Class Initialized
INFO - 2018-10-18 14:07:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:07:10 --> Database Driver Class Initialized
INFO - 2018-10-18 14:07:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:07:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:07:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:07:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:07:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:07:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:07:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:07:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/inherited_income.php
INFO - 2018-10-18 14:07:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:07:11 --> Final output sent to browser
DEBUG - 2018-10-18 14:07:11 --> Total execution time: 0.6592
INFO - 2018-10-18 14:07:11 --> Config Class Initialized
INFO - 2018-10-18 14:07:11 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:07:11 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:07:11 --> Utf8 Class Initialized
INFO - 2018-10-18 14:07:11 --> URI Class Initialized
INFO - 2018-10-18 14:07:11 --> Router Class Initialized
INFO - 2018-10-18 14:07:11 --> Output Class Initialized
INFO - 2018-10-18 14:07:11 --> Security Class Initialized
DEBUG - 2018-10-18 14:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:07:11 --> CSRF cookie sent
INFO - 2018-10-18 14:07:11 --> Input Class Initialized
INFO - 2018-10-18 14:07:11 --> Language Class Initialized
ERROR - 2018-10-18 14:07:11 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 14:07:12 --> Config Class Initialized
INFO - 2018-10-18 14:07:12 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:07:12 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:07:12 --> Utf8 Class Initialized
INFO - 2018-10-18 14:07:12 --> URI Class Initialized
INFO - 2018-10-18 14:07:12 --> Router Class Initialized
INFO - 2018-10-18 14:07:12 --> Output Class Initialized
INFO - 2018-10-18 14:07:12 --> Security Class Initialized
DEBUG - 2018-10-18 14:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:07:13 --> CSRF cookie sent
INFO - 2018-10-18 14:07:13 --> CSRF token verified
INFO - 2018-10-18 14:07:13 --> Input Class Initialized
INFO - 2018-10-18 14:07:13 --> Language Class Initialized
INFO - 2018-10-18 14:07:13 --> Loader Class Initialized
INFO - 2018-10-18 14:07:13 --> Helper loaded: url_helper
INFO - 2018-10-18 14:07:13 --> Helper loaded: form_helper
INFO - 2018-10-18 14:07:13 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:07:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:07:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:07:13 --> User Agent Class Initialized
INFO - 2018-10-18 14:07:13 --> Controller Class Initialized
INFO - 2018-10-18 14:07:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:07:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:07:13 --> Pixel_Model class loaded
INFO - 2018-10-18 14:07:13 --> Database Driver Class Initialized
INFO - 2018-10-18 14:07:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:07:13 --> Form Validation Class Initialized
INFO - 2018-10-18 14:07:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 14:07:13 --> Database Driver Class Initialized
INFO - 2018-10-18 14:07:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:07:13 --> Config Class Initialized
INFO - 2018-10-18 14:07:13 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:07:13 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:07:13 --> Utf8 Class Initialized
INFO - 2018-10-18 14:07:13 --> URI Class Initialized
INFO - 2018-10-18 14:07:13 --> Router Class Initialized
INFO - 2018-10-18 14:07:13 --> Output Class Initialized
INFO - 2018-10-18 14:07:13 --> Security Class Initialized
DEBUG - 2018-10-18 14:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:07:13 --> CSRF cookie sent
INFO - 2018-10-18 14:07:13 --> Input Class Initialized
INFO - 2018-10-18 14:07:13 --> Language Class Initialized
INFO - 2018-10-18 14:07:13 --> Loader Class Initialized
INFO - 2018-10-18 14:07:13 --> Helper loaded: url_helper
INFO - 2018-10-18 14:07:13 --> Helper loaded: form_helper
INFO - 2018-10-18 14:07:13 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:07:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:07:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:07:13 --> User Agent Class Initialized
INFO - 2018-10-18 14:07:13 --> Controller Class Initialized
INFO - 2018-10-18 14:07:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:07:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:07:13 --> Pixel_Model class loaded
INFO - 2018-10-18 14:07:13 --> Database Driver Class Initialized
INFO - 2018-10-18 14:07:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:07:13 --> Database Driver Class Initialized
INFO - 2018-10-18 14:07:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:07:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:07:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:07:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:07:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:07:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:07:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:07:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/shift_work.php
INFO - 2018-10-18 14:07:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:07:14 --> Final output sent to browser
DEBUG - 2018-10-18 14:07:14 --> Total execution time: 0.6302
INFO - 2018-10-18 14:07:14 --> Config Class Initialized
INFO - 2018-10-18 14:07:14 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:07:14 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:07:14 --> Utf8 Class Initialized
INFO - 2018-10-18 14:07:14 --> URI Class Initialized
INFO - 2018-10-18 14:07:14 --> Router Class Initialized
INFO - 2018-10-18 14:07:14 --> Output Class Initialized
INFO - 2018-10-18 14:07:14 --> Security Class Initialized
DEBUG - 2018-10-18 14:07:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:07:14 --> CSRF cookie sent
INFO - 2018-10-18 14:07:14 --> Input Class Initialized
INFO - 2018-10-18 14:07:14 --> Language Class Initialized
ERROR - 2018-10-18 14:07:14 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 14:07:16 --> Config Class Initialized
INFO - 2018-10-18 14:07:16 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:07:16 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:07:16 --> Utf8 Class Initialized
INFO - 2018-10-18 14:07:16 --> URI Class Initialized
INFO - 2018-10-18 14:07:16 --> Router Class Initialized
INFO - 2018-10-18 14:07:16 --> Output Class Initialized
INFO - 2018-10-18 14:07:16 --> Security Class Initialized
DEBUG - 2018-10-18 14:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:07:16 --> CSRF cookie sent
INFO - 2018-10-18 14:07:16 --> CSRF token verified
INFO - 2018-10-18 14:07:16 --> Input Class Initialized
INFO - 2018-10-18 14:07:16 --> Language Class Initialized
INFO - 2018-10-18 14:07:16 --> Loader Class Initialized
INFO - 2018-10-18 14:07:16 --> Helper loaded: url_helper
INFO - 2018-10-18 14:07:16 --> Helper loaded: form_helper
INFO - 2018-10-18 14:07:16 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:07:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:07:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:07:16 --> User Agent Class Initialized
INFO - 2018-10-18 14:07:16 --> Controller Class Initialized
INFO - 2018-10-18 14:07:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:07:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:07:16 --> Pixel_Model class loaded
INFO - 2018-10-18 14:07:16 --> Database Driver Class Initialized
INFO - 2018-10-18 14:07:16 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:07:16 --> Form Validation Class Initialized
INFO - 2018-10-18 14:07:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 14:07:16 --> Database Driver Class Initialized
INFO - 2018-10-18 14:07:16 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:07:16 --> Config Class Initialized
INFO - 2018-10-18 14:07:16 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:07:16 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:07:16 --> Utf8 Class Initialized
INFO - 2018-10-18 14:07:16 --> URI Class Initialized
INFO - 2018-10-18 14:07:16 --> Router Class Initialized
INFO - 2018-10-18 14:07:16 --> Output Class Initialized
INFO - 2018-10-18 14:07:16 --> Security Class Initialized
DEBUG - 2018-10-18 14:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:07:16 --> CSRF cookie sent
INFO - 2018-10-18 14:07:16 --> Input Class Initialized
INFO - 2018-10-18 14:07:16 --> Language Class Initialized
INFO - 2018-10-18 14:07:16 --> Loader Class Initialized
INFO - 2018-10-18 14:07:16 --> Helper loaded: url_helper
INFO - 2018-10-18 14:07:16 --> Helper loaded: form_helper
INFO - 2018-10-18 14:07:16 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:07:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:07:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:07:16 --> User Agent Class Initialized
INFO - 2018-10-18 14:07:17 --> Controller Class Initialized
INFO - 2018-10-18 14:07:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:07:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:07:17 --> Pixel_Model class loaded
INFO - 2018-10-18 14:07:17 --> Database Driver Class Initialized
INFO - 2018-10-18 14:07:17 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:07:17 --> Database Driver Class Initialized
INFO - 2018-10-18 14:07:17 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:07:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:07:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:07:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:07:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:07:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:07:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:07:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/night_without_s.php
INFO - 2018-10-18 14:07:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:07:17 --> Final output sent to browser
DEBUG - 2018-10-18 14:07:17 --> Total execution time: 0.6063
INFO - 2018-10-18 14:07:17 --> Config Class Initialized
INFO - 2018-10-18 14:07:17 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:07:17 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:07:17 --> Utf8 Class Initialized
INFO - 2018-10-18 14:07:17 --> URI Class Initialized
INFO - 2018-10-18 14:07:17 --> Router Class Initialized
INFO - 2018-10-18 14:07:17 --> Output Class Initialized
INFO - 2018-10-18 14:07:17 --> Security Class Initialized
DEBUG - 2018-10-18 14:07:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:07:17 --> CSRF cookie sent
INFO - 2018-10-18 14:07:17 --> Input Class Initialized
INFO - 2018-10-18 14:07:17 --> Language Class Initialized
ERROR - 2018-10-18 14:07:17 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 14:07:20 --> Config Class Initialized
INFO - 2018-10-18 14:07:20 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:07:20 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:07:20 --> Utf8 Class Initialized
INFO - 2018-10-18 14:07:20 --> URI Class Initialized
INFO - 2018-10-18 14:07:20 --> Router Class Initialized
INFO - 2018-10-18 14:07:20 --> Output Class Initialized
INFO - 2018-10-18 14:07:20 --> Security Class Initialized
DEBUG - 2018-10-18 14:07:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:07:20 --> CSRF cookie sent
INFO - 2018-10-18 14:07:20 --> CSRF token verified
INFO - 2018-10-18 14:07:20 --> Input Class Initialized
INFO - 2018-10-18 14:07:20 --> Language Class Initialized
INFO - 2018-10-18 14:07:20 --> Loader Class Initialized
INFO - 2018-10-18 14:07:20 --> Helper loaded: url_helper
INFO - 2018-10-18 14:07:20 --> Helper loaded: form_helper
INFO - 2018-10-18 14:07:20 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:07:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:07:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:07:20 --> User Agent Class Initialized
INFO - 2018-10-18 14:07:20 --> Controller Class Initialized
INFO - 2018-10-18 14:07:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:07:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:07:20 --> Pixel_Model class loaded
INFO - 2018-10-18 14:07:20 --> Database Driver Class Initialized
INFO - 2018-10-18 14:07:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:07:20 --> Form Validation Class Initialized
INFO - 2018-10-18 14:07:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 14:07:20 --> Database Driver Class Initialized
INFO - 2018-10-18 14:07:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:07:20 --> Config Class Initialized
INFO - 2018-10-18 14:07:20 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:07:20 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:07:20 --> Utf8 Class Initialized
INFO - 2018-10-18 14:07:20 --> URI Class Initialized
INFO - 2018-10-18 14:07:20 --> Router Class Initialized
INFO - 2018-10-18 14:07:20 --> Output Class Initialized
INFO - 2018-10-18 14:07:20 --> Security Class Initialized
DEBUG - 2018-10-18 14:07:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:07:20 --> CSRF cookie sent
INFO - 2018-10-18 14:07:20 --> Input Class Initialized
INFO - 2018-10-18 14:07:20 --> Language Class Initialized
INFO - 2018-10-18 14:07:20 --> Loader Class Initialized
INFO - 2018-10-18 14:07:20 --> Helper loaded: url_helper
INFO - 2018-10-18 14:07:20 --> Helper loaded: form_helper
INFO - 2018-10-18 14:07:20 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:07:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:07:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:07:20 --> User Agent Class Initialized
INFO - 2018-10-18 14:07:20 --> Controller Class Initialized
INFO - 2018-10-18 14:07:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:07:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:07:20 --> Pixel_Model class loaded
INFO - 2018-10-18 14:07:21 --> Database Driver Class Initialized
INFO - 2018-10-18 14:07:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:07:21 --> Database Driver Class Initialized
INFO - 2018-10-18 14:07:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:07:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:07:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:07:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:07:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:07:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:07:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:07:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/have_date.php
INFO - 2018-10-18 14:07:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:07:21 --> Final output sent to browser
DEBUG - 2018-10-18 14:07:21 --> Total execution time: 0.6211
INFO - 2018-10-18 14:07:21 --> Config Class Initialized
INFO - 2018-10-18 14:07:21 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:07:21 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:07:21 --> Utf8 Class Initialized
INFO - 2018-10-18 14:07:21 --> URI Class Initialized
INFO - 2018-10-18 14:07:21 --> Router Class Initialized
INFO - 2018-10-18 14:07:21 --> Output Class Initialized
INFO - 2018-10-18 14:07:21 --> Security Class Initialized
DEBUG - 2018-10-18 14:07:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:07:21 --> CSRF cookie sent
INFO - 2018-10-18 14:07:21 --> Input Class Initialized
INFO - 2018-10-18 14:07:21 --> Language Class Initialized
ERROR - 2018-10-18 14:07:21 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 14:07:23 --> Config Class Initialized
INFO - 2018-10-18 14:07:23 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:07:23 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:07:23 --> Utf8 Class Initialized
INFO - 2018-10-18 14:07:23 --> URI Class Initialized
INFO - 2018-10-18 14:07:23 --> Router Class Initialized
INFO - 2018-10-18 14:07:23 --> Output Class Initialized
INFO - 2018-10-18 14:07:23 --> Security Class Initialized
DEBUG - 2018-10-18 14:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:07:23 --> CSRF cookie sent
INFO - 2018-10-18 14:07:23 --> CSRF token verified
INFO - 2018-10-18 14:07:23 --> Input Class Initialized
INFO - 2018-10-18 14:07:23 --> Language Class Initialized
INFO - 2018-10-18 14:07:23 --> Loader Class Initialized
INFO - 2018-10-18 14:07:23 --> Helper loaded: url_helper
INFO - 2018-10-18 14:07:23 --> Helper loaded: form_helper
INFO - 2018-10-18 14:07:23 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:07:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:07:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:07:23 --> User Agent Class Initialized
INFO - 2018-10-18 14:07:23 --> Controller Class Initialized
INFO - 2018-10-18 14:07:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:07:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:07:23 --> Pixel_Model class loaded
INFO - 2018-10-18 14:07:23 --> Database Driver Class Initialized
INFO - 2018-10-18 14:07:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:07:23 --> Form Validation Class Initialized
INFO - 2018-10-18 14:07:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 14:07:24 --> Database Driver Class Initialized
INFO - 2018-10-18 14:07:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:07:24 --> Config Class Initialized
INFO - 2018-10-18 14:07:24 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:07:24 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:07:24 --> Utf8 Class Initialized
INFO - 2018-10-18 14:07:24 --> URI Class Initialized
INFO - 2018-10-18 14:07:24 --> Router Class Initialized
INFO - 2018-10-18 14:07:24 --> Output Class Initialized
INFO - 2018-10-18 14:07:24 --> Security Class Initialized
DEBUG - 2018-10-18 14:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:07:24 --> CSRF cookie sent
INFO - 2018-10-18 14:07:24 --> Input Class Initialized
INFO - 2018-10-18 14:07:24 --> Language Class Initialized
INFO - 2018-10-18 14:07:24 --> Loader Class Initialized
INFO - 2018-10-18 14:07:24 --> Helper loaded: url_helper
INFO - 2018-10-18 14:07:24 --> Helper loaded: form_helper
INFO - 2018-10-18 14:07:24 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:07:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:07:24 --> User Agent Class Initialized
INFO - 2018-10-18 14:07:24 --> Controller Class Initialized
INFO - 2018-10-18 14:07:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:07:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:07:24 --> Pixel_Model class loaded
INFO - 2018-10-18 14:07:24 --> Database Driver Class Initialized
INFO - 2018-10-18 14:07:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:07:24 --> Database Driver Class Initialized
INFO - 2018-10-18 14:07:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:07:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:07:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:07:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:07:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:07:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:07:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:07:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/nights_not_home.php
INFO - 2018-10-18 14:07:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:07:24 --> Final output sent to browser
DEBUG - 2018-10-18 14:07:24 --> Total execution time: 0.5994
INFO - 2018-10-18 14:07:25 --> Config Class Initialized
INFO - 2018-10-18 14:07:25 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:07:25 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:07:25 --> Utf8 Class Initialized
INFO - 2018-10-18 14:07:25 --> URI Class Initialized
INFO - 2018-10-18 14:07:25 --> Router Class Initialized
INFO - 2018-10-18 14:07:25 --> Output Class Initialized
INFO - 2018-10-18 14:07:25 --> Security Class Initialized
DEBUG - 2018-10-18 14:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:07:25 --> CSRF cookie sent
INFO - 2018-10-18 14:07:25 --> Input Class Initialized
INFO - 2018-10-18 14:07:25 --> Language Class Initialized
ERROR - 2018-10-18 14:07:25 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 14:07:27 --> Config Class Initialized
INFO - 2018-10-18 14:07:27 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:07:27 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:07:27 --> Utf8 Class Initialized
INFO - 2018-10-18 14:07:27 --> URI Class Initialized
INFO - 2018-10-18 14:07:27 --> Router Class Initialized
INFO - 2018-10-18 14:07:27 --> Output Class Initialized
INFO - 2018-10-18 14:07:27 --> Security Class Initialized
DEBUG - 2018-10-18 14:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:07:27 --> CSRF cookie sent
INFO - 2018-10-18 14:07:27 --> CSRF token verified
INFO - 2018-10-18 14:07:27 --> Input Class Initialized
INFO - 2018-10-18 14:07:27 --> Language Class Initialized
INFO - 2018-10-18 14:07:27 --> Loader Class Initialized
INFO - 2018-10-18 14:07:27 --> Helper loaded: url_helper
INFO - 2018-10-18 14:07:27 --> Helper loaded: form_helper
INFO - 2018-10-18 14:07:27 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:07:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:07:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:07:27 --> User Agent Class Initialized
INFO - 2018-10-18 14:07:27 --> Controller Class Initialized
INFO - 2018-10-18 14:07:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:07:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:07:27 --> Pixel_Model class loaded
INFO - 2018-10-18 14:07:27 --> Database Driver Class Initialized
INFO - 2018-10-18 14:07:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:07:27 --> Form Validation Class Initialized
INFO - 2018-10-18 14:07:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 14:07:27 --> Database Driver Class Initialized
INFO - 2018-10-18 14:07:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:07:28 --> Config Class Initialized
INFO - 2018-10-18 14:07:28 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:07:28 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:07:28 --> Utf8 Class Initialized
INFO - 2018-10-18 14:07:28 --> URI Class Initialized
INFO - 2018-10-18 14:07:28 --> Router Class Initialized
INFO - 2018-10-18 14:07:28 --> Output Class Initialized
INFO - 2018-10-18 14:07:28 --> Security Class Initialized
DEBUG - 2018-10-18 14:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:07:28 --> CSRF cookie sent
INFO - 2018-10-18 14:07:28 --> Input Class Initialized
INFO - 2018-10-18 14:07:28 --> Language Class Initialized
INFO - 2018-10-18 14:07:28 --> Loader Class Initialized
INFO - 2018-10-18 14:07:28 --> Helper loaded: url_helper
INFO - 2018-10-18 14:07:28 --> Helper loaded: form_helper
INFO - 2018-10-18 14:07:28 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:07:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:07:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:07:28 --> User Agent Class Initialized
INFO - 2018-10-18 14:07:28 --> Controller Class Initialized
INFO - 2018-10-18 14:07:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:07:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:07:28 --> Pixel_Model class loaded
INFO - 2018-10-18 14:07:28 --> Database Driver Class Initialized
INFO - 2018-10-18 14:07:28 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:07:28 --> Database Driver Class Initialized
INFO - 2018-10-18 14:07:28 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:07:28 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:07:28 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:07:28 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:07:28 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:07:28 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:07:28 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:07:28 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/s_nights_not_home.php
INFO - 2018-10-18 14:07:28 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:07:28 --> Final output sent to browser
DEBUG - 2018-10-18 14:07:28 --> Total execution time: 0.6283
INFO - 2018-10-18 14:07:28 --> Config Class Initialized
INFO - 2018-10-18 14:07:28 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:07:28 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:07:29 --> Utf8 Class Initialized
INFO - 2018-10-18 14:07:29 --> URI Class Initialized
INFO - 2018-10-18 14:07:29 --> Router Class Initialized
INFO - 2018-10-18 14:07:29 --> Output Class Initialized
INFO - 2018-10-18 14:07:29 --> Security Class Initialized
DEBUG - 2018-10-18 14:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:07:29 --> CSRF cookie sent
INFO - 2018-10-18 14:07:29 --> Input Class Initialized
INFO - 2018-10-18 14:07:29 --> Language Class Initialized
ERROR - 2018-10-18 14:07:29 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 14:07:31 --> Config Class Initialized
INFO - 2018-10-18 14:07:31 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:07:31 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:07:31 --> Utf8 Class Initialized
INFO - 2018-10-18 14:07:31 --> URI Class Initialized
INFO - 2018-10-18 14:07:31 --> Router Class Initialized
INFO - 2018-10-18 14:07:31 --> Output Class Initialized
INFO - 2018-10-18 14:07:31 --> Security Class Initialized
DEBUG - 2018-10-18 14:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:07:31 --> CSRF cookie sent
INFO - 2018-10-18 14:07:31 --> CSRF token verified
INFO - 2018-10-18 14:07:31 --> Input Class Initialized
INFO - 2018-10-18 14:07:31 --> Language Class Initialized
INFO - 2018-10-18 14:07:31 --> Loader Class Initialized
INFO - 2018-10-18 14:07:31 --> Helper loaded: url_helper
INFO - 2018-10-18 14:07:31 --> Helper loaded: form_helper
INFO - 2018-10-18 14:07:31 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:07:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:07:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:07:31 --> User Agent Class Initialized
INFO - 2018-10-18 14:07:31 --> Controller Class Initialized
INFO - 2018-10-18 14:07:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:07:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:07:31 --> Pixel_Model class loaded
INFO - 2018-10-18 14:07:31 --> Database Driver Class Initialized
INFO - 2018-10-18 14:07:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:07:31 --> Form Validation Class Initialized
INFO - 2018-10-18 14:07:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 14:07:31 --> Database Driver Class Initialized
INFO - 2018-10-18 14:07:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:07:31 --> Config Class Initialized
INFO - 2018-10-18 14:07:31 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:07:31 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:07:31 --> Utf8 Class Initialized
INFO - 2018-10-18 14:07:31 --> URI Class Initialized
INFO - 2018-10-18 14:07:31 --> Router Class Initialized
INFO - 2018-10-18 14:07:31 --> Output Class Initialized
INFO - 2018-10-18 14:07:31 --> Security Class Initialized
DEBUG - 2018-10-18 14:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:07:31 --> CSRF cookie sent
INFO - 2018-10-18 14:07:31 --> Input Class Initialized
INFO - 2018-10-18 14:07:31 --> Language Class Initialized
INFO - 2018-10-18 14:07:31 --> Loader Class Initialized
INFO - 2018-10-18 14:07:31 --> Helper loaded: url_helper
INFO - 2018-10-18 14:07:31 --> Helper loaded: form_helper
INFO - 2018-10-18 14:07:31 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:07:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:07:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:07:32 --> User Agent Class Initialized
INFO - 2018-10-18 14:07:32 --> Controller Class Initialized
INFO - 2018-10-18 14:07:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:07:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:07:32 --> Pixel_Model class loaded
INFO - 2018-10-18 14:07:32 --> Database Driver Class Initialized
INFO - 2018-10-18 14:07:32 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:07:32 --> Database Driver Class Initialized
INFO - 2018-10-18 14:07:32 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:07:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:07:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:07:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:07:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:07:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:07:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:07:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/s_nights_without_you.php
INFO - 2018-10-18 14:07:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:07:32 --> Final output sent to browser
DEBUG - 2018-10-18 14:07:32 --> Total execution time: 0.6332
INFO - 2018-10-18 14:07:32 --> Config Class Initialized
INFO - 2018-10-18 14:07:32 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:07:32 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:07:32 --> Utf8 Class Initialized
INFO - 2018-10-18 14:07:32 --> URI Class Initialized
INFO - 2018-10-18 14:07:32 --> Router Class Initialized
INFO - 2018-10-18 14:07:32 --> Output Class Initialized
INFO - 2018-10-18 14:07:32 --> Security Class Initialized
DEBUG - 2018-10-18 14:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:07:32 --> CSRF cookie sent
INFO - 2018-10-18 14:07:32 --> Input Class Initialized
INFO - 2018-10-18 14:07:32 --> Language Class Initialized
ERROR - 2018-10-18 14:07:32 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 14:07:34 --> Config Class Initialized
INFO - 2018-10-18 14:07:34 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:07:34 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:07:34 --> Utf8 Class Initialized
INFO - 2018-10-18 14:07:34 --> URI Class Initialized
INFO - 2018-10-18 14:07:34 --> Router Class Initialized
INFO - 2018-10-18 14:07:34 --> Output Class Initialized
INFO - 2018-10-18 14:07:34 --> Security Class Initialized
DEBUG - 2018-10-18 14:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:07:34 --> CSRF cookie sent
INFO - 2018-10-18 14:07:34 --> CSRF token verified
INFO - 2018-10-18 14:07:34 --> Input Class Initialized
INFO - 2018-10-18 14:07:34 --> Language Class Initialized
INFO - 2018-10-18 14:07:34 --> Loader Class Initialized
INFO - 2018-10-18 14:07:34 --> Helper loaded: url_helper
INFO - 2018-10-18 14:07:34 --> Helper loaded: form_helper
INFO - 2018-10-18 14:07:34 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:07:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:07:35 --> User Agent Class Initialized
INFO - 2018-10-18 14:07:35 --> Controller Class Initialized
INFO - 2018-10-18 14:07:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:07:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:07:35 --> Pixel_Model class loaded
INFO - 2018-10-18 14:07:35 --> Database Driver Class Initialized
INFO - 2018-10-18 14:07:35 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:07:35 --> Form Validation Class Initialized
INFO - 2018-10-18 14:07:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 14:07:35 --> Database Driver Class Initialized
INFO - 2018-10-18 14:07:35 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:07:35 --> Config Class Initialized
INFO - 2018-10-18 14:07:35 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:07:35 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:07:35 --> Utf8 Class Initialized
INFO - 2018-10-18 14:07:35 --> URI Class Initialized
INFO - 2018-10-18 14:07:35 --> Router Class Initialized
INFO - 2018-10-18 14:07:35 --> Output Class Initialized
INFO - 2018-10-18 14:07:35 --> Security Class Initialized
DEBUG - 2018-10-18 14:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:07:35 --> CSRF cookie sent
INFO - 2018-10-18 14:07:35 --> Input Class Initialized
INFO - 2018-10-18 14:07:35 --> Language Class Initialized
INFO - 2018-10-18 14:07:35 --> Loader Class Initialized
INFO - 2018-10-18 14:07:35 --> Helper loaded: url_helper
INFO - 2018-10-18 14:07:35 --> Helper loaded: form_helper
INFO - 2018-10-18 14:07:35 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:07:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:07:35 --> User Agent Class Initialized
INFO - 2018-10-18 14:07:35 --> Controller Class Initialized
INFO - 2018-10-18 14:07:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:07:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:07:35 --> Pixel_Model class loaded
INFO - 2018-10-18 14:07:35 --> Database Driver Class Initialized
INFO - 2018-10-18 14:07:35 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:07:35 --> Database Driver Class Initialized
INFO - 2018-10-18 14:07:35 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:07:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:07:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:07:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:07:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:07:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:07:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:07:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/alcoholic_drinks_per_week.php
INFO - 2018-10-18 14:07:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:07:35 --> Final output sent to browser
DEBUG - 2018-10-18 14:07:35 --> Total execution time: 0.6341
INFO - 2018-10-18 14:07:36 --> Config Class Initialized
INFO - 2018-10-18 14:07:36 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:07:36 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:07:36 --> Utf8 Class Initialized
INFO - 2018-10-18 14:07:36 --> URI Class Initialized
INFO - 2018-10-18 14:07:36 --> Router Class Initialized
INFO - 2018-10-18 14:07:36 --> Output Class Initialized
INFO - 2018-10-18 14:07:36 --> Security Class Initialized
DEBUG - 2018-10-18 14:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:07:36 --> CSRF cookie sent
INFO - 2018-10-18 14:07:36 --> Input Class Initialized
INFO - 2018-10-18 14:07:36 --> Language Class Initialized
ERROR - 2018-10-18 14:07:36 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 14:07:38 --> Config Class Initialized
INFO - 2018-10-18 14:07:38 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:07:38 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:07:38 --> Utf8 Class Initialized
INFO - 2018-10-18 14:07:38 --> URI Class Initialized
INFO - 2018-10-18 14:07:38 --> Router Class Initialized
INFO - 2018-10-18 14:07:38 --> Output Class Initialized
INFO - 2018-10-18 14:07:38 --> Security Class Initialized
DEBUG - 2018-10-18 14:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:07:38 --> CSRF cookie sent
INFO - 2018-10-18 14:07:38 --> CSRF token verified
INFO - 2018-10-18 14:07:38 --> Input Class Initialized
INFO - 2018-10-18 14:07:38 --> Language Class Initialized
INFO - 2018-10-18 14:07:38 --> Loader Class Initialized
INFO - 2018-10-18 14:07:38 --> Helper loaded: url_helper
INFO - 2018-10-18 14:07:38 --> Helper loaded: form_helper
INFO - 2018-10-18 14:07:38 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:07:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:07:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:07:38 --> User Agent Class Initialized
INFO - 2018-10-18 14:07:38 --> Controller Class Initialized
INFO - 2018-10-18 14:07:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:07:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:07:38 --> Pixel_Model class loaded
INFO - 2018-10-18 14:07:38 --> Database Driver Class Initialized
INFO - 2018-10-18 14:07:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:07:39 --> Form Validation Class Initialized
INFO - 2018-10-18 14:07:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 14:07:39 --> Database Driver Class Initialized
INFO - 2018-10-18 14:07:39 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:07:39 --> Config Class Initialized
INFO - 2018-10-18 14:07:39 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:07:39 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:07:39 --> Utf8 Class Initialized
INFO - 2018-10-18 14:07:39 --> URI Class Initialized
INFO - 2018-10-18 14:07:39 --> Router Class Initialized
INFO - 2018-10-18 14:07:39 --> Output Class Initialized
INFO - 2018-10-18 14:07:39 --> Security Class Initialized
DEBUG - 2018-10-18 14:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:07:39 --> CSRF cookie sent
INFO - 2018-10-18 14:07:39 --> Input Class Initialized
INFO - 2018-10-18 14:07:39 --> Language Class Initialized
INFO - 2018-10-18 14:07:39 --> Loader Class Initialized
INFO - 2018-10-18 14:07:39 --> Helper loaded: url_helper
INFO - 2018-10-18 14:07:39 --> Helper loaded: form_helper
INFO - 2018-10-18 14:07:39 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:07:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:07:39 --> User Agent Class Initialized
INFO - 2018-10-18 14:07:39 --> Controller Class Initialized
INFO - 2018-10-18 14:07:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:07:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:07:39 --> Pixel_Model class loaded
INFO - 2018-10-18 14:07:39 --> Database Driver Class Initialized
INFO - 2018-10-18 14:07:39 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:07:39 --> Database Driver Class Initialized
INFO - 2018-10-18 14:07:39 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:07:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:07:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:07:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:07:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:07:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:07:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:07:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/have_drugs.php
INFO - 2018-10-18 14:07:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:07:39 --> Final output sent to browser
DEBUG - 2018-10-18 14:07:39 --> Total execution time: 0.6123
INFO - 2018-10-18 14:07:40 --> Config Class Initialized
INFO - 2018-10-18 14:07:40 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:07:40 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:07:40 --> Utf8 Class Initialized
INFO - 2018-10-18 14:07:40 --> URI Class Initialized
INFO - 2018-10-18 14:07:40 --> Router Class Initialized
INFO - 2018-10-18 14:07:40 --> Output Class Initialized
INFO - 2018-10-18 14:07:40 --> Security Class Initialized
DEBUG - 2018-10-18 14:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:07:40 --> CSRF cookie sent
INFO - 2018-10-18 14:07:40 --> Input Class Initialized
INFO - 2018-10-18 14:07:40 --> Language Class Initialized
ERROR - 2018-10-18 14:07:40 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 14:07:43 --> Config Class Initialized
INFO - 2018-10-18 14:07:43 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:07:43 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:07:43 --> Utf8 Class Initialized
INFO - 2018-10-18 14:07:43 --> URI Class Initialized
INFO - 2018-10-18 14:07:43 --> Router Class Initialized
INFO - 2018-10-18 14:07:43 --> Output Class Initialized
INFO - 2018-10-18 14:07:43 --> Security Class Initialized
DEBUG - 2018-10-18 14:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:07:43 --> CSRF cookie sent
INFO - 2018-10-18 14:07:43 --> CSRF token verified
INFO - 2018-10-18 14:07:43 --> Input Class Initialized
INFO - 2018-10-18 14:07:43 --> Language Class Initialized
INFO - 2018-10-18 14:07:43 --> Loader Class Initialized
INFO - 2018-10-18 14:07:43 --> Helper loaded: url_helper
INFO - 2018-10-18 14:07:43 --> Helper loaded: form_helper
INFO - 2018-10-18 14:07:43 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:07:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:07:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:07:43 --> User Agent Class Initialized
INFO - 2018-10-18 14:07:43 --> Controller Class Initialized
INFO - 2018-10-18 14:07:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:07:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:07:43 --> Pixel_Model class loaded
INFO - 2018-10-18 14:07:43 --> Database Driver Class Initialized
INFO - 2018-10-18 14:07:43 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:07:43 --> Form Validation Class Initialized
INFO - 2018-10-18 14:07:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 14:07:43 --> Database Driver Class Initialized
INFO - 2018-10-18 14:07:43 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:07:43 --> Config Class Initialized
INFO - 2018-10-18 14:07:43 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:07:43 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:07:43 --> Utf8 Class Initialized
INFO - 2018-10-18 14:07:43 --> URI Class Initialized
INFO - 2018-10-18 14:07:43 --> Router Class Initialized
INFO - 2018-10-18 14:07:43 --> Output Class Initialized
INFO - 2018-10-18 14:07:43 --> Security Class Initialized
DEBUG - 2018-10-18 14:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:07:43 --> CSRF cookie sent
INFO - 2018-10-18 14:07:43 --> Input Class Initialized
INFO - 2018-10-18 14:07:44 --> Language Class Initialized
INFO - 2018-10-18 14:07:44 --> Loader Class Initialized
INFO - 2018-10-18 14:07:44 --> Helper loaded: url_helper
INFO - 2018-10-18 14:07:44 --> Helper loaded: form_helper
INFO - 2018-10-18 14:07:44 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:07:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:07:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:07:44 --> User Agent Class Initialized
INFO - 2018-10-18 14:07:44 --> Controller Class Initialized
INFO - 2018-10-18 14:07:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:07:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:07:44 --> Pixel_Model class loaded
INFO - 2018-10-18 14:07:44 --> Database Driver Class Initialized
INFO - 2018-10-18 14:07:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:07:44 --> Database Driver Class Initialized
INFO - 2018-10-18 14:07:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:07:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:07:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:07:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:07:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:07:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:07:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:07:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/has_addiction_problem.php
INFO - 2018-10-18 14:07:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:07:44 --> Final output sent to browser
DEBUG - 2018-10-18 14:07:44 --> Total execution time: 0.6684
INFO - 2018-10-18 14:07:44 --> Config Class Initialized
INFO - 2018-10-18 14:07:44 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:07:44 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:07:44 --> Utf8 Class Initialized
INFO - 2018-10-18 14:07:44 --> URI Class Initialized
INFO - 2018-10-18 14:07:44 --> Router Class Initialized
INFO - 2018-10-18 14:07:44 --> Output Class Initialized
INFO - 2018-10-18 14:07:44 --> Security Class Initialized
DEBUG - 2018-10-18 14:07:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:07:44 --> CSRF cookie sent
INFO - 2018-10-18 14:07:45 --> Input Class Initialized
INFO - 2018-10-18 14:07:45 --> Language Class Initialized
ERROR - 2018-10-18 14:07:45 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 14:07:47 --> Config Class Initialized
INFO - 2018-10-18 14:07:47 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:07:47 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:07:47 --> Utf8 Class Initialized
INFO - 2018-10-18 14:07:47 --> URI Class Initialized
INFO - 2018-10-18 14:07:47 --> Router Class Initialized
INFO - 2018-10-18 14:07:47 --> Output Class Initialized
INFO - 2018-10-18 14:07:47 --> Security Class Initialized
DEBUG - 2018-10-18 14:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:07:47 --> CSRF cookie sent
INFO - 2018-10-18 14:07:47 --> CSRF token verified
INFO - 2018-10-18 14:07:47 --> Input Class Initialized
INFO - 2018-10-18 14:07:47 --> Language Class Initialized
INFO - 2018-10-18 14:07:47 --> Loader Class Initialized
INFO - 2018-10-18 14:07:47 --> Helper loaded: url_helper
INFO - 2018-10-18 14:07:47 --> Helper loaded: form_helper
INFO - 2018-10-18 14:07:47 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:07:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:07:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:07:47 --> User Agent Class Initialized
INFO - 2018-10-18 14:07:47 --> Controller Class Initialized
INFO - 2018-10-18 14:07:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:07:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:07:47 --> Pixel_Model class loaded
INFO - 2018-10-18 14:07:47 --> Database Driver Class Initialized
INFO - 2018-10-18 14:07:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:07:47 --> Form Validation Class Initialized
INFO - 2018-10-18 14:07:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 14:07:47 --> Database Driver Class Initialized
INFO - 2018-10-18 14:07:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:07:47 --> Config Class Initialized
INFO - 2018-10-18 14:07:47 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:07:47 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:07:47 --> Utf8 Class Initialized
INFO - 2018-10-18 14:07:47 --> URI Class Initialized
INFO - 2018-10-18 14:07:47 --> Router Class Initialized
INFO - 2018-10-18 14:07:47 --> Output Class Initialized
INFO - 2018-10-18 14:07:47 --> Security Class Initialized
DEBUG - 2018-10-18 14:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:07:47 --> CSRF cookie sent
INFO - 2018-10-18 14:07:47 --> Input Class Initialized
INFO - 2018-10-18 14:07:47 --> Language Class Initialized
INFO - 2018-10-18 14:07:47 --> Loader Class Initialized
INFO - 2018-10-18 14:07:47 --> Helper loaded: url_helper
INFO - 2018-10-18 14:07:47 --> Helper loaded: form_helper
INFO - 2018-10-18 14:07:47 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:07:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:07:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:07:47 --> User Agent Class Initialized
INFO - 2018-10-18 14:07:47 --> Controller Class Initialized
INFO - 2018-10-18 14:07:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:07:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:07:48 --> Pixel_Model class loaded
INFO - 2018-10-18 14:07:48 --> Database Driver Class Initialized
INFO - 2018-10-18 14:07:48 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:07:48 --> Database Driver Class Initialized
INFO - 2018-10-18 14:07:48 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:07:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:07:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:07:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:07:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:07:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:07:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:07:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/have_hit_s.php
INFO - 2018-10-18 14:07:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:07:48 --> Final output sent to browser
DEBUG - 2018-10-18 14:07:48 --> Total execution time: 0.6817
INFO - 2018-10-18 14:07:48 --> Config Class Initialized
INFO - 2018-10-18 14:07:48 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:07:48 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:07:48 --> Utf8 Class Initialized
INFO - 2018-10-18 14:07:48 --> URI Class Initialized
INFO - 2018-10-18 14:07:48 --> Router Class Initialized
INFO - 2018-10-18 14:07:48 --> Output Class Initialized
INFO - 2018-10-18 14:07:48 --> Security Class Initialized
DEBUG - 2018-10-18 14:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:07:48 --> CSRF cookie sent
INFO - 2018-10-18 14:07:48 --> Input Class Initialized
INFO - 2018-10-18 14:07:48 --> Language Class Initialized
ERROR - 2018-10-18 14:07:48 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 14:07:51 --> Config Class Initialized
INFO - 2018-10-18 14:07:51 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:07:51 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:07:51 --> Utf8 Class Initialized
INFO - 2018-10-18 14:07:51 --> URI Class Initialized
INFO - 2018-10-18 14:07:51 --> Router Class Initialized
INFO - 2018-10-18 14:07:51 --> Output Class Initialized
INFO - 2018-10-18 14:07:51 --> Security Class Initialized
DEBUG - 2018-10-18 14:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:07:51 --> CSRF cookie sent
INFO - 2018-10-18 14:07:51 --> CSRF token verified
INFO - 2018-10-18 14:07:51 --> Input Class Initialized
INFO - 2018-10-18 14:07:51 --> Language Class Initialized
INFO - 2018-10-18 14:07:51 --> Loader Class Initialized
INFO - 2018-10-18 14:07:51 --> Helper loaded: url_helper
INFO - 2018-10-18 14:07:51 --> Helper loaded: form_helper
INFO - 2018-10-18 14:07:51 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:07:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:07:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:07:51 --> User Agent Class Initialized
INFO - 2018-10-18 14:07:51 --> Controller Class Initialized
INFO - 2018-10-18 14:07:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:07:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:07:51 --> Pixel_Model class loaded
INFO - 2018-10-18 14:07:51 --> Database Driver Class Initialized
INFO - 2018-10-18 14:07:51 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:07:51 --> Form Validation Class Initialized
INFO - 2018-10-18 14:07:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 14:07:51 --> Database Driver Class Initialized
INFO - 2018-10-18 14:07:51 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:07:51 --> Config Class Initialized
INFO - 2018-10-18 14:07:51 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:07:52 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:07:52 --> Utf8 Class Initialized
INFO - 2018-10-18 14:07:52 --> URI Class Initialized
INFO - 2018-10-18 14:07:52 --> Router Class Initialized
INFO - 2018-10-18 14:07:52 --> Output Class Initialized
INFO - 2018-10-18 14:07:52 --> Security Class Initialized
DEBUG - 2018-10-18 14:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:07:52 --> CSRF cookie sent
INFO - 2018-10-18 14:07:52 --> Input Class Initialized
INFO - 2018-10-18 14:07:52 --> Language Class Initialized
INFO - 2018-10-18 14:07:52 --> Loader Class Initialized
INFO - 2018-10-18 14:07:52 --> Helper loaded: url_helper
INFO - 2018-10-18 14:07:52 --> Helper loaded: form_helper
INFO - 2018-10-18 14:07:52 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:07:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:07:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:07:52 --> User Agent Class Initialized
INFO - 2018-10-18 14:07:52 --> Controller Class Initialized
INFO - 2018-10-18 14:07:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:07:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:07:52 --> Pixel_Model class loaded
INFO - 2018-10-18 14:07:52 --> Database Driver Class Initialized
INFO - 2018-10-18 14:07:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:07:52 --> Database Driver Class Initialized
INFO - 2018-10-18 14:07:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:07:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:07:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:07:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:07:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:07:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:07:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:07:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/financial_control.php
INFO - 2018-10-18 14:07:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:07:52 --> Final output sent to browser
DEBUG - 2018-10-18 14:07:52 --> Total execution time: 0.6649
INFO - 2018-10-18 14:07:52 --> Config Class Initialized
INFO - 2018-10-18 14:07:52 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:07:52 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:07:52 --> Utf8 Class Initialized
INFO - 2018-10-18 14:07:53 --> URI Class Initialized
INFO - 2018-10-18 14:07:53 --> Router Class Initialized
INFO - 2018-10-18 14:07:53 --> Output Class Initialized
INFO - 2018-10-18 14:07:53 --> Security Class Initialized
DEBUG - 2018-10-18 14:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:07:53 --> CSRF cookie sent
INFO - 2018-10-18 14:07:53 --> Input Class Initialized
INFO - 2018-10-18 14:07:53 --> Language Class Initialized
ERROR - 2018-10-18 14:07:53 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 14:07:55 --> Config Class Initialized
INFO - 2018-10-18 14:07:55 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:07:55 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:07:55 --> Utf8 Class Initialized
INFO - 2018-10-18 14:07:55 --> URI Class Initialized
INFO - 2018-10-18 14:07:55 --> Router Class Initialized
INFO - 2018-10-18 14:07:55 --> Output Class Initialized
INFO - 2018-10-18 14:07:55 --> Security Class Initialized
DEBUG - 2018-10-18 14:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:07:55 --> CSRF cookie sent
INFO - 2018-10-18 14:07:55 --> CSRF token verified
INFO - 2018-10-18 14:07:55 --> Input Class Initialized
INFO - 2018-10-18 14:07:55 --> Language Class Initialized
INFO - 2018-10-18 14:07:55 --> Loader Class Initialized
INFO - 2018-10-18 14:07:55 --> Helper loaded: url_helper
INFO - 2018-10-18 14:07:55 --> Helper loaded: form_helper
INFO - 2018-10-18 14:07:55 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:07:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:07:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:07:56 --> User Agent Class Initialized
INFO - 2018-10-18 14:07:56 --> Controller Class Initialized
INFO - 2018-10-18 14:07:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:07:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:07:56 --> Pixel_Model class loaded
INFO - 2018-10-18 14:07:56 --> Database Driver Class Initialized
INFO - 2018-10-18 14:07:56 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:07:56 --> Form Validation Class Initialized
INFO - 2018-10-18 14:07:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 14:07:56 --> Database Driver Class Initialized
INFO - 2018-10-18 14:07:56 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:07:56 --> Config Class Initialized
INFO - 2018-10-18 14:07:56 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:07:56 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:07:56 --> Utf8 Class Initialized
INFO - 2018-10-18 14:07:56 --> URI Class Initialized
INFO - 2018-10-18 14:07:56 --> Router Class Initialized
INFO - 2018-10-18 14:07:56 --> Output Class Initialized
INFO - 2018-10-18 14:07:56 --> Security Class Initialized
DEBUG - 2018-10-18 14:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:07:56 --> CSRF cookie sent
INFO - 2018-10-18 14:07:56 --> Input Class Initialized
INFO - 2018-10-18 14:07:56 --> Language Class Initialized
INFO - 2018-10-18 14:07:56 --> Loader Class Initialized
INFO - 2018-10-18 14:07:56 --> Helper loaded: url_helper
INFO - 2018-10-18 14:07:56 --> Helper loaded: form_helper
INFO - 2018-10-18 14:07:56 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:07:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:07:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:07:56 --> User Agent Class Initialized
INFO - 2018-10-18 14:07:56 --> Controller Class Initialized
INFO - 2018-10-18 14:07:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:07:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:07:56 --> Pixel_Model class loaded
INFO - 2018-10-18 14:07:56 --> Database Driver Class Initialized
INFO - 2018-10-18 14:07:56 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:07:56 --> Database Driver Class Initialized
INFO - 2018-10-18 14:07:56 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:07:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:07:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:07:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:07:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:07:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:07:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:07:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/has_hit_kids.php
INFO - 2018-10-18 14:07:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:07:56 --> Final output sent to browser
DEBUG - 2018-10-18 14:07:57 --> Total execution time: 0.6533
INFO - 2018-10-18 14:07:57 --> Config Class Initialized
INFO - 2018-10-18 14:07:57 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:07:57 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:07:57 --> Utf8 Class Initialized
INFO - 2018-10-18 14:07:57 --> URI Class Initialized
INFO - 2018-10-18 14:07:57 --> Router Class Initialized
INFO - 2018-10-18 14:07:57 --> Output Class Initialized
INFO - 2018-10-18 14:07:57 --> Security Class Initialized
DEBUG - 2018-10-18 14:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:07:57 --> CSRF cookie sent
INFO - 2018-10-18 14:07:57 --> Input Class Initialized
INFO - 2018-10-18 14:07:57 --> Language Class Initialized
ERROR - 2018-10-18 14:07:57 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 14:07:58 --> Config Class Initialized
INFO - 2018-10-18 14:07:58 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:07:58 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:07:58 --> Utf8 Class Initialized
INFO - 2018-10-18 14:07:58 --> URI Class Initialized
INFO - 2018-10-18 14:07:58 --> Router Class Initialized
INFO - 2018-10-18 14:07:58 --> Output Class Initialized
INFO - 2018-10-18 14:07:58 --> Security Class Initialized
DEBUG - 2018-10-18 14:07:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:07:58 --> CSRF cookie sent
INFO - 2018-10-18 14:07:58 --> CSRF token verified
INFO - 2018-10-18 14:07:58 --> Input Class Initialized
INFO - 2018-10-18 14:07:58 --> Language Class Initialized
INFO - 2018-10-18 14:07:58 --> Loader Class Initialized
INFO - 2018-10-18 14:07:58 --> Helper loaded: url_helper
INFO - 2018-10-18 14:07:58 --> Helper loaded: form_helper
INFO - 2018-10-18 14:07:58 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:07:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:07:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:07:59 --> User Agent Class Initialized
INFO - 2018-10-18 14:07:59 --> Controller Class Initialized
INFO - 2018-10-18 14:07:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:07:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:07:59 --> Pixel_Model class loaded
INFO - 2018-10-18 14:07:59 --> Database Driver Class Initialized
INFO - 2018-10-18 14:07:59 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:07:59 --> Form Validation Class Initialized
INFO - 2018-10-18 14:07:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 14:07:59 --> Database Driver Class Initialized
INFO - 2018-10-18 14:07:59 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:07:59 --> Config Class Initialized
INFO - 2018-10-18 14:07:59 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:07:59 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:07:59 --> Utf8 Class Initialized
INFO - 2018-10-18 14:07:59 --> URI Class Initialized
INFO - 2018-10-18 14:07:59 --> Router Class Initialized
INFO - 2018-10-18 14:07:59 --> Output Class Initialized
INFO - 2018-10-18 14:07:59 --> Security Class Initialized
DEBUG - 2018-10-18 14:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:07:59 --> CSRF cookie sent
INFO - 2018-10-18 14:07:59 --> Input Class Initialized
INFO - 2018-10-18 14:07:59 --> Language Class Initialized
INFO - 2018-10-18 14:07:59 --> Loader Class Initialized
INFO - 2018-10-18 14:07:59 --> Helper loaded: url_helper
INFO - 2018-10-18 14:07:59 --> Helper loaded: form_helper
INFO - 2018-10-18 14:07:59 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:07:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:07:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:07:59 --> User Agent Class Initialized
INFO - 2018-10-18 14:07:59 --> Controller Class Initialized
INFO - 2018-10-18 14:07:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:07:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:07:59 --> Pixel_Model class loaded
INFO - 2018-10-18 14:07:59 --> Database Driver Class Initialized
INFO - 2018-10-18 14:07:59 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:07:59 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:07:59 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:07:59 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:07:59 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:07:59 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/suspension.php
INFO - 2018-10-18 14:07:59 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:07:59 --> Final output sent to browser
DEBUG - 2018-10-18 14:07:59 --> Total execution time: 0.5519
INFO - 2018-10-18 14:08:00 --> Config Class Initialized
INFO - 2018-10-18 14:08:00 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:08:00 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:08:00 --> Utf8 Class Initialized
INFO - 2018-10-18 14:08:00 --> URI Class Initialized
INFO - 2018-10-18 14:08:00 --> Router Class Initialized
INFO - 2018-10-18 14:08:00 --> Output Class Initialized
INFO - 2018-10-18 14:08:00 --> Security Class Initialized
DEBUG - 2018-10-18 14:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:08:00 --> CSRF cookie sent
INFO - 2018-10-18 14:08:00 --> Input Class Initialized
INFO - 2018-10-18 14:08:00 --> Language Class Initialized
ERROR - 2018-10-18 14:08:00 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 14:08:02 --> Config Class Initialized
INFO - 2018-10-18 14:08:02 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:08:02 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:08:02 --> Utf8 Class Initialized
INFO - 2018-10-18 14:08:02 --> URI Class Initialized
INFO - 2018-10-18 14:08:02 --> Router Class Initialized
INFO - 2018-10-18 14:08:02 --> Output Class Initialized
INFO - 2018-10-18 14:08:02 --> Security Class Initialized
DEBUG - 2018-10-18 14:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:08:02 --> CSRF cookie sent
INFO - 2018-10-18 14:08:02 --> Input Class Initialized
INFO - 2018-10-18 14:08:02 --> Language Class Initialized
INFO - 2018-10-18 14:08:02 --> Loader Class Initialized
INFO - 2018-10-18 14:08:02 --> Helper loaded: url_helper
INFO - 2018-10-18 14:08:02 --> Helper loaded: form_helper
INFO - 2018-10-18 14:08:02 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:08:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:08:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:08:02 --> User Agent Class Initialized
INFO - 2018-10-18 14:08:02 --> Controller Class Initialized
INFO - 2018-10-18 14:08:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:08:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:08:02 --> Pixel_Model class loaded
INFO - 2018-10-18 14:08:02 --> Database Driver Class Initialized
INFO - 2018-10-18 14:08:02 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:08:02 --> Config Class Initialized
INFO - 2018-10-18 14:08:02 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:08:03 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:08:03 --> Utf8 Class Initialized
INFO - 2018-10-18 14:08:03 --> URI Class Initialized
INFO - 2018-10-18 14:08:03 --> Router Class Initialized
INFO - 2018-10-18 14:08:03 --> Output Class Initialized
INFO - 2018-10-18 14:08:03 --> Security Class Initialized
DEBUG - 2018-10-18 14:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:08:03 --> CSRF cookie sent
INFO - 2018-10-18 14:08:03 --> Input Class Initialized
INFO - 2018-10-18 14:08:03 --> Language Class Initialized
INFO - 2018-10-18 14:08:03 --> Loader Class Initialized
INFO - 2018-10-18 14:08:03 --> Helper loaded: url_helper
INFO - 2018-10-18 14:08:03 --> Helper loaded: form_helper
INFO - 2018-10-18 14:08:03 --> Helper loaded: language_helper
DEBUG - 2018-10-18 14:08:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 14:08:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 14:08:03 --> User Agent Class Initialized
INFO - 2018-10-18 14:08:03 --> Controller Class Initialized
INFO - 2018-10-18 14:08:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 14:08:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 14:08:03 --> Pixel_Model class loaded
INFO - 2018-10-18 14:08:03 --> Database Driver Class Initialized
INFO - 2018-10-18 14:08:03 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 14:08:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 14:08:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 14:08:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 14:08:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 14:08:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 14:08:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 14:08:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-18 14:08:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 14:08:03 --> Final output sent to browser
DEBUG - 2018-10-18 14:08:03 --> Total execution time: 0.6083
INFO - 2018-10-18 14:08:03 --> Config Class Initialized
INFO - 2018-10-18 14:08:03 --> Hooks Class Initialized
DEBUG - 2018-10-18 14:08:03 --> UTF-8 Support Enabled
INFO - 2018-10-18 14:08:03 --> Utf8 Class Initialized
INFO - 2018-10-18 14:08:03 --> URI Class Initialized
INFO - 2018-10-18 14:08:03 --> Router Class Initialized
INFO - 2018-10-18 14:08:04 --> Output Class Initialized
INFO - 2018-10-18 14:08:04 --> Security Class Initialized
DEBUG - 2018-10-18 14:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 14:08:04 --> CSRF cookie sent
INFO - 2018-10-18 14:08:04 --> Input Class Initialized
INFO - 2018-10-18 14:08:04 --> Language Class Initialized
ERROR - 2018-10-18 14:08:04 --> 404 Page Not Found: Assets/css
<<<<<<< HEAD
>>>>>>> 4c5a3fb837b72a5ebe34152c40ec6a8ad1b51698
=======
>>>>>>> 4c5a3fb837b72a5ebe34152c40ec6a8ad1b51698
INFO - 2018-10-18 16:02:35 --> Config Class Initialized
INFO - 2018-10-18 16:02:35 --> Hooks Class Initialized
DEBUG - 2018-10-18 16:02:35 --> UTF-8 Support Enabled
INFO - 2018-10-18 16:02:35 --> Utf8 Class Initialized
INFO - 2018-10-18 16:02:35 --> URI Class Initialized
DEBUG - 2018-10-18 16:02:35 --> No URI present. Default controller set.
INFO - 2018-10-18 16:02:35 --> Router Class Initialized
INFO - 2018-10-18 16:02:36 --> Output Class Initialized
INFO - 2018-10-18 16:02:36 --> Security Class Initialized
DEBUG - 2018-10-18 16:02:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 16:02:36 --> CSRF cookie sent
INFO - 2018-10-18 16:02:36 --> Input Class Initialized
INFO - 2018-10-18 16:02:36 --> Language Class Initialized
INFO - 2018-10-18 16:02:37 --> Loader Class Initialized
INFO - 2018-10-18 16:02:37 --> Helper loaded: url_helper
INFO - 2018-10-18 16:02:37 --> Helper loaded: form_helper
INFO - 2018-10-18 16:02:37 --> Helper loaded: language_helper
DEBUG - 2018-10-18 16:02:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 16:02:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 16:02:37 --> User Agent Class Initialized
INFO - 2018-10-18 16:02:38 --> Controller Class Initialized
INFO - 2018-10-18 16:02:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 16:02:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 16:02:38 --> Pixel_Model class loaded
INFO - 2018-10-18 16:02:39 --> Database Driver Class Initialized
INFO - 2018-10-18 16:02:39 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 16:02:40 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 16:02:40 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 16:02:40 --> File loaded: F:\xampp\htdocs\famiquity\application\views\home.php
INFO - 2018-10-18 16:02:40 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 16:02:40 --> Final output sent to browser
DEBUG - 2018-10-18 16:02:40 --> Total execution time: 5.9243
INFO - 2018-10-18 16:02:51 --> Config Class Initialized
INFO - 2018-10-18 16:02:51 --> Hooks Class Initialized
DEBUG - 2018-10-18 16:02:51 --> UTF-8 Support Enabled
INFO - 2018-10-18 16:02:51 --> Utf8 Class Initialized
INFO - 2018-10-18 16:02:51 --> URI Class Initialized
INFO - 2018-10-18 16:02:52 --> Router Class Initialized
INFO - 2018-10-18 16:02:52 --> Output Class Initialized
INFO - 2018-10-18 16:02:52 --> Security Class Initialized
DEBUG - 2018-10-18 16:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 16:02:52 --> CSRF cookie sent
INFO - 2018-10-18 16:02:52 --> Input Class Initialized
INFO - 2018-10-18 16:02:52 --> Language Class Initialized
INFO - 2018-10-18 16:02:52 --> Loader Class Initialized
INFO - 2018-10-18 16:02:52 --> Helper loaded: url_helper
INFO - 2018-10-18 16:02:52 --> Helper loaded: form_helper
INFO - 2018-10-18 16:02:52 --> Helper loaded: language_helper
DEBUG - 2018-10-18 16:02:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 16:02:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 16:02:52 --> User Agent Class Initialized
INFO - 2018-10-18 16:02:52 --> Controller Class Initialized
INFO - 2018-10-18 16:02:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 16:02:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 16:02:52 --> Pixel_Model class loaded
INFO - 2018-10-18 16:02:53 --> Database Driver Class Initialized
INFO - 2018-10-18 16:02:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 16:02:53 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 16:02:53 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 16:02:53 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 16:02:53 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 16:02:53 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 16:02:53 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 16:02:53 --> File loaded: F:\xampp\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-18 16:02:53 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 16:02:53 --> Final output sent to browser
DEBUG - 2018-10-18 16:02:53 --> Total execution time: 1.9956
INFO - 2018-10-18 16:03:09 --> Config Class Initialized
INFO - 2018-10-18 16:03:09 --> Hooks Class Initialized
DEBUG - 2018-10-18 16:03:09 --> UTF-8 Support Enabled
INFO - 2018-10-18 16:03:09 --> Utf8 Class Initialized
INFO - 2018-10-18 16:03:09 --> URI Class Initialized
INFO - 2018-10-18 16:03:09 --> Router Class Initialized
INFO - 2018-10-18 16:03:09 --> Output Class Initialized
INFO - 2018-10-18 16:03:09 --> Security Class Initialized
DEBUG - 2018-10-18 16:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 16:03:09 --> CSRF cookie sent
INFO - 2018-10-18 16:03:09 --> Input Class Initialized
INFO - 2018-10-18 16:03:09 --> Language Class Initialized
INFO - 2018-10-18 16:03:10 --> Loader Class Initialized
INFO - 2018-10-18 16:03:10 --> Helper loaded: url_helper
INFO - 2018-10-18 16:03:10 --> Helper loaded: form_helper
INFO - 2018-10-18 16:03:10 --> Helper loaded: language_helper
DEBUG - 2018-10-18 16:03:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 16:03:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 16:03:10 --> User Agent Class Initialized
INFO - 2018-10-18 16:03:10 --> Controller Class Initialized
INFO - 2018-10-18 16:03:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 16:03:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 16:03:10 --> Pixel_Model class loaded
INFO - 2018-10-18 16:03:10 --> Database Driver Class Initialized
INFO - 2018-10-18 16:03:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 16:03:10 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 16:03:10 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 16:03:10 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 16:03:10 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 16:03:10 --> File loaded: F:\xampp\htdocs\famiquity\application\views\questions/contact_us.php
INFO - 2018-10-18 16:03:10 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 16:03:10 --> Final output sent to browser
DEBUG - 2018-10-18 16:03:11 --> Total execution time: 1.6082
INFO - 2018-10-18 16:04:51 --> Config Class Initialized
INFO - 2018-10-18 16:04:51 --> Hooks Class Initialized
DEBUG - 2018-10-18 16:04:51 --> UTF-8 Support Enabled
INFO - 2018-10-18 16:04:51 --> Utf8 Class Initialized
INFO - 2018-10-18 16:04:51 --> URI Class Initialized
INFO - 2018-10-18 16:04:51 --> Router Class Initialized
INFO - 2018-10-18 16:04:51 --> Output Class Initialized
INFO - 2018-10-18 16:04:51 --> Security Class Initialized
DEBUG - 2018-10-18 16:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 16:04:51 --> CSRF cookie sent
INFO - 2018-10-18 16:04:51 --> Input Class Initialized
INFO - 2018-10-18 16:04:51 --> Language Class Initialized
INFO - 2018-10-18 16:04:51 --> Loader Class Initialized
INFO - 2018-10-18 16:04:51 --> Helper loaded: url_helper
INFO - 2018-10-18 16:04:51 --> Helper loaded: form_helper
INFO - 2018-10-18 16:04:51 --> Helper loaded: language_helper
DEBUG - 2018-10-18 16:04:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 16:04:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 16:04:51 --> User Agent Class Initialized
INFO - 2018-10-18 16:04:52 --> Controller Class Initialized
INFO - 2018-10-18 16:04:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 16:04:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 16:04:52 --> Pixel_Model class loaded
INFO - 2018-10-18 16:04:52 --> Database Driver Class Initialized
INFO - 2018-10-18 16:04:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 16:04:52 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 16:04:52 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 16:04:52 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 16:04:52 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 16:04:52 --> File loaded: F:\xampp\htdocs\famiquity\application\views\questions/contact_us.php
INFO - 2018-10-18 16:04:52 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 16:04:52 --> Final output sent to browser
DEBUG - 2018-10-18 16:04:52 --> Total execution time: 1.4023
INFO - 2018-10-18 16:04:55 --> Config Class Initialized
INFO - 2018-10-18 16:04:55 --> Hooks Class Initialized
DEBUG - 2018-10-18 16:04:55 --> UTF-8 Support Enabled
INFO - 2018-10-18 16:04:55 --> Utf8 Class Initialized
INFO - 2018-10-18 16:04:55 --> URI Class Initialized
INFO - 2018-10-18 16:04:55 --> Router Class Initialized
INFO - 2018-10-18 16:04:55 --> Output Class Initialized
INFO - 2018-10-18 16:04:55 --> Security Class Initialized
DEBUG - 2018-10-18 16:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 16:04:55 --> CSRF cookie sent
INFO - 2018-10-18 16:04:55 --> Input Class Initialized
INFO - 2018-10-18 16:04:55 --> Language Class Initialized
INFO - 2018-10-18 16:04:55 --> Loader Class Initialized
INFO - 2018-10-18 16:04:55 --> Helper loaded: url_helper
INFO - 2018-10-18 16:04:56 --> Helper loaded: form_helper
INFO - 2018-10-18 16:04:56 --> Helper loaded: language_helper
DEBUG - 2018-10-18 16:04:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 16:04:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 16:04:56 --> User Agent Class Initialized
INFO - 2018-10-18 16:04:56 --> Controller Class Initialized
INFO - 2018-10-18 16:04:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 16:04:56 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-18 16:04:56 --> Config file loaded: F:\xampp\htdocs\famiquity\application\config/recaptcha.php
INFO - 2018-10-18 16:04:56 --> Config Class Initialized
INFO - 2018-10-18 16:04:56 --> Hooks Class Initialized
DEBUG - 2018-10-18 16:04:56 --> UTF-8 Support Enabled
INFO - 2018-10-18 16:04:56 --> Utf8 Class Initialized
INFO - 2018-10-18 16:04:56 --> URI Class Initialized
INFO - 2018-10-18 16:04:56 --> Router Class Initialized
INFO - 2018-10-18 16:04:56 --> Output Class Initialized
INFO - 2018-10-18 16:04:57 --> Security Class Initialized
DEBUG - 2018-10-18 16:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 16:04:57 --> CSRF cookie sent
INFO - 2018-10-18 16:04:57 --> Input Class Initialized
INFO - 2018-10-18 16:04:57 --> Language Class Initialized
INFO - 2018-10-18 16:04:57 --> Loader Class Initialized
INFO - 2018-10-18 16:04:57 --> Helper loaded: url_helper
INFO - 2018-10-18 16:04:57 --> Helper loaded: form_helper
INFO - 2018-10-18 16:04:57 --> Helper loaded: language_helper
DEBUG - 2018-10-18 16:04:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 16:04:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 16:04:57 --> User Agent Class Initialized
INFO - 2018-10-18 16:04:57 --> Controller Class Initialized
INFO - 2018-10-18 16:04:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 16:04:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 16:04:57 --> Pixel_Model class loaded
INFO - 2018-10-18 16:04:58 --> Database Driver Class Initialized
INFO - 2018-10-18 16:04:58 --> Model "RegistrationModel" initialized
DEBUG - 2018-10-18 16:04:58 --> Config file loaded: F:\xampp\htdocs\famiquity\application\config/recaptcha.php
INFO - 2018-10-18 16:04:58 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 16:04:58 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 16:04:58 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 16:04:58 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 16:04:58 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_soft_error.php
ERROR - 2018-10-18 16:04:58 --> Could not find the language line "req_email"
INFO - 2018-10-18 16:04:58 --> File loaded: F:\xampp\htdocs\famiquity\application\views\register/signup.php
INFO - 2018-10-18 16:04:58 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 16:04:59 --> Final output sent to browser
DEBUG - 2018-10-18 16:04:59 --> Total execution time: 2.3329
INFO - 2018-10-18 16:05:27 --> Config Class Initialized
INFO - 2018-10-18 16:05:27 --> Hooks Class Initialized
DEBUG - 2018-10-18 16:05:27 --> UTF-8 Support Enabled
INFO - 2018-10-18 16:05:27 --> Utf8 Class Initialized
INFO - 2018-10-18 16:05:27 --> URI Class Initialized
INFO - 2018-10-18 16:05:27 --> Router Class Initialized
INFO - 2018-10-18 16:05:27 --> Output Class Initialized
INFO - 2018-10-18 16:05:27 --> Security Class Initialized
DEBUG - 2018-10-18 16:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 16:05:27 --> CSRF cookie sent
INFO - 2018-10-18 16:05:28 --> Input Class Initialized
INFO - 2018-10-18 16:05:28 --> Language Class Initialized
INFO - 2018-10-18 16:05:28 --> Loader Class Initialized
INFO - 2018-10-18 16:05:28 --> Helper loaded: url_helper
INFO - 2018-10-18 16:05:28 --> Helper loaded: form_helper
INFO - 2018-10-18 16:05:28 --> Helper loaded: language_helper
DEBUG - 2018-10-18 16:05:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 16:05:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 16:05:28 --> User Agent Class Initialized
INFO - 2018-10-18 16:05:28 --> Controller Class Initialized
INFO - 2018-10-18 16:05:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 16:05:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 16:05:28 --> Pixel_Model class loaded
INFO - 2018-10-18 16:05:28 --> Database Driver Class Initialized
INFO - 2018-10-18 16:05:28 --> Model "RegistrationModel" initialized
DEBUG - 2018-10-18 16:05:28 --> Config file loaded: F:\xampp\htdocs\famiquity\application\config/recaptcha.php
INFO - 2018-10-18 16:05:28 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 16:05:29 --> Config Class Initialized
INFO - 2018-10-18 16:05:29 --> Hooks Class Initialized
INFO - 2018-10-18 16:05:29 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 16:05:29 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_page_banner_empty.php
DEBUG - 2018-10-18 16:05:29 --> UTF-8 Support Enabled
INFO - 2018-10-18 16:05:29 --> Utf8 Class Initialized
INFO - 2018-10-18 16:05:29 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 16:05:29 --> URI Class Initialized
ERROR - 2018-10-18 16:05:29 --> Could not find the language line "req_email"
INFO - 2018-10-18 16:05:29 --> File loaded: F:\xampp\htdocs\famiquity\application\views\register/signup.php
INFO - 2018-10-18 16:05:29 --> Router Class Initialized
INFO - 2018-10-18 16:05:29 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 16:05:29 --> Output Class Initialized
INFO - 2018-10-18 16:05:29 --> Final output sent to browser
INFO - 2018-10-18 16:05:29 --> Security Class Initialized
DEBUG - 2018-10-18 16:05:29 --> Total execution time: 1.8411
DEBUG - 2018-10-18 16:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 16:05:29 --> CSRF cookie sent
INFO - 2018-10-18 16:05:29 --> Input Class Initialized
INFO - 2018-10-18 16:05:29 --> Language Class Initialized
INFO - 2018-10-18 16:05:29 --> Loader Class Initialized
INFO - 2018-10-18 16:05:29 --> Helper loaded: url_helper
INFO - 2018-10-18 16:05:29 --> Helper loaded: form_helper
INFO - 2018-10-18 16:05:29 --> Helper loaded: language_helper
DEBUG - 2018-10-18 16:05:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 16:05:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 16:05:29 --> User Agent Class Initialized
INFO - 2018-10-18 16:05:30 --> Controller Class Initialized
INFO - 2018-10-18 16:05:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 16:05:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 16:05:30 --> Pixel_Model class loaded
INFO - 2018-10-18 16:05:30 --> Database Driver Class Initialized
INFO - 2018-10-18 16:05:30 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 16:05:30 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 16:05:30 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 16:05:30 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 16:05:30 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 16:05:30 --> File loaded: F:\xampp\htdocs\famiquity\application\views\questions/contact_us.php
INFO - 2018-10-18 16:05:30 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 16:05:30 --> Final output sent to browser
DEBUG - 2018-10-18 16:05:30 --> Total execution time: 1.5844
INFO - 2018-10-18 16:05:33 --> Config Class Initialized
INFO - 2018-10-18 16:05:33 --> Hooks Class Initialized
DEBUG - 2018-10-18 16:05:33 --> UTF-8 Support Enabled
INFO - 2018-10-18 16:05:33 --> Utf8 Class Initialized
INFO - 2018-10-18 16:05:33 --> URI Class Initialized
INFO - 2018-10-18 16:05:33 --> Router Class Initialized
INFO - 2018-10-18 16:05:33 --> Output Class Initialized
INFO - 2018-10-18 16:05:33 --> Security Class Initialized
DEBUG - 2018-10-18 16:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 16:05:33 --> CSRF cookie sent
INFO - 2018-10-18 16:05:33 --> Input Class Initialized
INFO - 2018-10-18 16:05:33 --> Language Class Initialized
INFO - 2018-10-18 16:05:33 --> Loader Class Initialized
INFO - 2018-10-18 16:05:34 --> Helper loaded: url_helper
INFO - 2018-10-18 16:05:34 --> Helper loaded: form_helper
INFO - 2018-10-18 16:05:34 --> Helper loaded: language_helper
DEBUG - 2018-10-18 16:05:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 16:05:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 16:05:34 --> User Agent Class Initialized
INFO - 2018-10-18 16:05:34 --> Controller Class Initialized
INFO - 2018-10-18 16:05:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 16:05:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 16:05:34 --> Form Validation Class Initialized
INFO - 2018-10-18 16:05:34 --> Pixel_Model class loaded
INFO - 2018-10-18 16:05:34 --> Database Driver Class Initialized
INFO - 2018-10-18 16:05:34 --> Model "RegistrationModel" initialized
DEBUG - 2018-10-18 16:05:34 --> Config file loaded: F:\xampp\htdocs\famiquity\application\config/recaptcha.php
INFO - 2018-10-18 16:05:34 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 16:05:34 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 16:05:34 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 16:05:34 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_page_header.php
ERROR - 2018-10-18 16:05:35 --> Could not find the language line "req_email"
INFO - 2018-10-18 16:05:35 --> File loaded: F:\xampp\htdocs\famiquity\application\views\register/signup.php
INFO - 2018-10-18 16:05:35 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 16:05:35 --> Final output sent to browser
DEBUG - 2018-10-18 16:05:35 --> Total execution time: 1.8146
INFO - 2018-10-18 16:06:02 --> Config Class Initialized
INFO - 2018-10-18 16:06:02 --> Hooks Class Initialized
DEBUG - 2018-10-18 16:06:02 --> UTF-8 Support Enabled
INFO - 2018-10-18 16:06:02 --> Utf8 Class Initialized
INFO - 2018-10-18 16:06:02 --> URI Class Initialized
INFO - 2018-10-18 16:06:02 --> Router Class Initialized
INFO - 2018-10-18 16:06:02 --> Output Class Initialized
INFO - 2018-10-18 16:06:02 --> Security Class Initialized
DEBUG - 2018-10-18 16:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 16:06:03 --> CSRF cookie sent
INFO - 2018-10-18 16:06:03 --> Input Class Initialized
INFO - 2018-10-18 16:06:03 --> Language Class Initialized
INFO - 2018-10-18 16:06:03 --> Loader Class Initialized
INFO - 2018-10-18 16:06:03 --> Helper loaded: url_helper
INFO - 2018-10-18 16:06:03 --> Helper loaded: form_helper
INFO - 2018-10-18 16:06:03 --> Helper loaded: language_helper
DEBUG - 2018-10-18 16:06:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 16:06:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 16:06:03 --> User Agent Class Initialized
INFO - 2018-10-18 16:06:03 --> Controller Class Initialized
INFO - 2018-10-18 16:06:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 16:06:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 16:06:03 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 16:06:03 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 16:06:03 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 16:06:04 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 16:06:04 --> File loaded: F:\xampp\htdocs\famiquity\application\views\register/signup_terms.php
INFO - 2018-10-18 16:06:04 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 16:06:04 --> Final output sent to browser
DEBUG - 2018-10-18 16:06:04 --> Total execution time: 1.6694
INFO - 2018-10-18 16:06:24 --> Config Class Initialized
INFO - 2018-10-18 16:06:24 --> Hooks Class Initialized
DEBUG - 2018-10-18 16:06:24 --> UTF-8 Support Enabled
INFO - 2018-10-18 16:06:24 --> Utf8 Class Initialized
INFO - 2018-10-18 16:06:24 --> URI Class Initialized
INFO - 2018-10-18 16:06:24 --> Router Class Initialized
INFO - 2018-10-18 16:06:24 --> Output Class Initialized
INFO - 2018-10-18 16:06:24 --> Security Class Initialized
DEBUG - 2018-10-18 16:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 16:06:24 --> CSRF cookie sent
INFO - 2018-10-18 16:06:24 --> CSRF token verified
INFO - 2018-10-18 16:06:24 --> Input Class Initialized
INFO - 2018-10-18 16:06:24 --> Language Class Initialized
INFO - 2018-10-18 16:06:24 --> Loader Class Initialized
INFO - 2018-10-18 16:06:24 --> Helper loaded: url_helper
INFO - 2018-10-18 16:06:25 --> Helper loaded: form_helper
INFO - 2018-10-18 16:06:25 --> Helper loaded: language_helper
DEBUG - 2018-10-18 16:06:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 16:06:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 16:06:25 --> User Agent Class Initialized
INFO - 2018-10-18 16:06:25 --> Controller Class Initialized
INFO - 2018-10-18 16:06:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 16:06:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 16:06:25 --> Pixel_Model class loaded
INFO - 2018-10-18 16:06:25 --> Database Driver Class Initialized
INFO - 2018-10-18 16:06:25 --> Model "RegistrationModel" initialized
INFO - 2018-10-18 16:06:25 --> Helper loaded: string_helper
INFO - 2018-10-18 16:06:25 --> Language file loaded: language/en/notifications_lang.php
INFO - 2018-10-18 16:06:26 --> File loaded: F:\xampp\htdocs\famiquity\application\views\emails/_buttons.php
INFO - 2018-10-18 16:06:26 --> File loaded: F:\xampp\htdocs\famiquity\application\views\emails/header.php
INFO - 2018-10-18 16:06:26 --> File loaded: F:\xampp\htdocs\famiquity\application\views\emails/footer.php
INFO - 2018-10-18 16:06:26 --> File loaded: F:\xampp\htdocs\famiquity\application\views\emails/generic.php
INFO - 2018-10-18 16:06:27 --> Email Class Initialized
INFO - 2018-10-18 16:06:28 --> Language file loaded: language/english/email_lang.php
INFO - 2018-10-18 16:06:28 --> Config Class Initialized
INFO - 2018-10-18 16:06:28 --> Hooks Class Initialized
DEBUG - 2018-10-18 16:06:28 --> UTF-8 Support Enabled
INFO - 2018-10-18 16:06:28 --> Utf8 Class Initialized
INFO - 2018-10-18 16:06:28 --> URI Class Initialized
INFO - 2018-10-18 16:06:28 --> Router Class Initialized
INFO - 2018-10-18 16:06:29 --> Output Class Initialized
INFO - 2018-10-18 16:06:29 --> Security Class Initialized
DEBUG - 2018-10-18 16:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 16:06:29 --> CSRF cookie sent
INFO - 2018-10-18 16:06:29 --> Input Class Initialized
INFO - 2018-10-18 16:06:29 --> Language Class Initialized
INFO - 2018-10-18 16:06:29 --> Loader Class Initialized
INFO - 2018-10-18 16:06:29 --> Helper loaded: url_helper
INFO - 2018-10-18 16:06:29 --> Helper loaded: form_helper
INFO - 2018-10-18 16:06:29 --> Helper loaded: language_helper
DEBUG - 2018-10-18 16:06:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 16:06:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 16:06:29 --> User Agent Class Initialized
INFO - 2018-10-18 16:06:29 --> Controller Class Initialized
INFO - 2018-10-18 16:06:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 16:06:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 16:06:30 --> Config Class Initialized
INFO - 2018-10-18 16:06:30 --> Hooks Class Initialized
DEBUG - 2018-10-18 16:06:30 --> UTF-8 Support Enabled
INFO - 2018-10-18 16:06:30 --> Utf8 Class Initialized
INFO - 2018-10-18 16:06:30 --> URI Class Initialized
INFO - 2018-10-18 16:06:30 --> Router Class Initialized
INFO - 2018-10-18 16:06:30 --> Output Class Initialized
INFO - 2018-10-18 16:06:30 --> Security Class Initialized
DEBUG - 2018-10-18 16:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 16:06:30 --> CSRF cookie sent
INFO - 2018-10-18 16:06:30 --> Input Class Initialized
INFO - 2018-10-18 16:06:30 --> Language Class Initialized
INFO - 2018-10-18 16:06:30 --> Loader Class Initialized
INFO - 2018-10-18 16:06:30 --> Helper loaded: url_helper
INFO - 2018-10-18 16:06:30 --> Helper loaded: form_helper
INFO - 2018-10-18 16:06:30 --> Helper loaded: language_helper
DEBUG - 2018-10-18 16:06:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 16:06:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 16:06:31 --> User Agent Class Initialized
INFO - 2018-10-18 16:06:31 --> Controller Class Initialized
INFO - 2018-10-18 16:06:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 16:06:31 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-18 16:06:31 --> Config file loaded: F:\xampp\htdocs\famiquity\application\config/recaptcha.php
INFO - 2018-10-18 16:06:31 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 16:06:31 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_end_user_nav.php
INFO - 2018-10-18 16:06:31 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 16:06:31 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 16:06:31 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_page_header.php
ERROR - 2018-10-18 16:06:31 --> Could not find the language line "req_email"
INFO - 2018-10-18 16:06:31 --> File loaded: F:\xampp\htdocs\famiquity\application\views\myaccount/signin.php
INFO - 2018-10-18 16:06:31 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 16:06:31 --> Final output sent to browser
DEBUG - 2018-10-18 16:06:31 --> Total execution time: 1.9188
INFO - 2018-10-18 16:07:54 --> Config Class Initialized
INFO - 2018-10-18 16:07:54 --> Hooks Class Initialized
DEBUG - 2018-10-18 16:07:54 --> UTF-8 Support Enabled
INFO - 2018-10-18 16:07:54 --> Utf8 Class Initialized
INFO - 2018-10-18 16:07:54 --> URI Class Initialized
INFO - 2018-10-18 16:07:54 --> Router Class Initialized
INFO - 2018-10-18 16:07:54 --> Output Class Initialized
INFO - 2018-10-18 16:07:54 --> Security Class Initialized
DEBUG - 2018-10-18 16:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 16:07:54 --> CSRF cookie sent
INFO - 2018-10-18 16:07:54 --> Input Class Initialized
INFO - 2018-10-18 16:07:54 --> Language Class Initialized
INFO - 2018-10-18 16:07:54 --> Loader Class Initialized
INFO - 2018-10-18 16:07:54 --> Helper loaded: url_helper
INFO - 2018-10-18 16:07:54 --> Helper loaded: form_helper
INFO - 2018-10-18 16:07:54 --> Helper loaded: language_helper
DEBUG - 2018-10-18 16:07:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 16:07:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 16:07:54 --> User Agent Class Initialized
INFO - 2018-10-18 16:07:54 --> Controller Class Initialized
INFO - 2018-10-18 16:07:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 16:07:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 16:07:55 --> Pixel_Model class loaded
INFO - 2018-10-18 16:07:55 --> Database Driver Class Initialized
INFO - 2018-10-18 16:07:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 16:07:55 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 16:07:55 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_end_user_nav.php
INFO - 2018-10-18 16:07:55 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 16:07:55 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 16:07:55 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 16:07:55 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 16:07:55 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 16:07:55 --> File loaded: F:\xampp\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-18 16:07:55 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 16:07:55 --> Final output sent to browser
DEBUG - 2018-10-18 16:07:55 --> Total execution time: 1.2434
INFO - 2018-10-18 16:08:05 --> Config Class Initialized
INFO - 2018-10-18 16:08:05 --> Hooks Class Initialized
DEBUG - 2018-10-18 16:08:05 --> UTF-8 Support Enabled
INFO - 2018-10-18 16:08:05 --> Utf8 Class Initialized
INFO - 2018-10-18 16:08:05 --> URI Class Initialized
INFO - 2018-10-18 16:08:05 --> Router Class Initialized
INFO - 2018-10-18 16:08:05 --> Output Class Initialized
INFO - 2018-10-18 16:08:06 --> Security Class Initialized
DEBUG - 2018-10-18 16:08:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 16:08:06 --> CSRF cookie sent
INFO - 2018-10-18 16:08:06 --> CSRF token verified
INFO - 2018-10-18 16:08:06 --> Input Class Initialized
INFO - 2018-10-18 16:08:06 --> Language Class Initialized
INFO - 2018-10-18 16:08:06 --> Loader Class Initialized
INFO - 2018-10-18 16:08:06 --> Helper loaded: url_helper
INFO - 2018-10-18 16:08:06 --> Helper loaded: form_helper
INFO - 2018-10-18 16:08:06 --> Helper loaded: language_helper
DEBUG - 2018-10-18 16:08:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 16:08:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 16:08:06 --> User Agent Class Initialized
INFO - 2018-10-18 16:08:06 --> Controller Class Initialized
INFO - 2018-10-18 16:08:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 16:08:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 16:08:06 --> Pixel_Model class loaded
INFO - 2018-10-18 16:08:06 --> Database Driver Class Initialized
INFO - 2018-10-18 16:08:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 16:08:06 --> Form Validation Class Initialized
INFO - 2018-10-18 16:08:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 16:08:07 --> Database Driver Class Initialized
INFO - 2018-10-18 16:08:07 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 16:08:07 --> Config Class Initialized
INFO - 2018-10-18 16:08:07 --> Hooks Class Initialized
DEBUG - 2018-10-18 16:08:07 --> UTF-8 Support Enabled
INFO - 2018-10-18 16:08:07 --> Utf8 Class Initialized
INFO - 2018-10-18 16:08:07 --> URI Class Initialized
INFO - 2018-10-18 16:08:07 --> Router Class Initialized
INFO - 2018-10-18 16:08:07 --> Output Class Initialized
INFO - 2018-10-18 16:08:07 --> Security Class Initialized
DEBUG - 2018-10-18 16:08:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 16:08:07 --> CSRF cookie sent
INFO - 2018-10-18 16:08:07 --> Input Class Initialized
INFO - 2018-10-18 16:08:07 --> Language Class Initialized
INFO - 2018-10-18 16:08:07 --> Loader Class Initialized
INFO - 2018-10-18 16:08:07 --> Helper loaded: url_helper
INFO - 2018-10-18 16:08:08 --> Helper loaded: form_helper
INFO - 2018-10-18 16:08:08 --> Helper loaded: language_helper
DEBUG - 2018-10-18 16:08:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 16:08:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 16:08:08 --> User Agent Class Initialized
INFO - 2018-10-18 16:08:08 --> Controller Class Initialized
INFO - 2018-10-18 16:08:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 16:08:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 16:08:08 --> Pixel_Model class loaded
INFO - 2018-10-18 16:08:08 --> Database Driver Class Initialized
INFO - 2018-10-18 16:08:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 16:08:08 --> Database Driver Class Initialized
INFO - 2018-10-18 16:08:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 16:08:08 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 16:08:08 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_end_user_nav.php
INFO - 2018-10-18 16:08:08 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 16:08:08 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 16:08:08 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 16:08:08 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 16:08:09 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 16:08:09 --> File loaded: F:\xampp\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-18 16:08:09 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 16:08:09 --> Final output sent to browser
DEBUG - 2018-10-18 16:08:09 --> Total execution time: 1.9186
INFO - 2018-10-18 16:08:47 --> Config Class Initialized
INFO - 2018-10-18 16:08:47 --> Hooks Class Initialized
DEBUG - 2018-10-18 16:08:47 --> UTF-8 Support Enabled
INFO - 2018-10-18 16:08:47 --> Utf8 Class Initialized
INFO - 2018-10-18 16:08:47 --> URI Class Initialized
INFO - 2018-10-18 16:08:47 --> Router Class Initialized
INFO - 2018-10-18 16:08:47 --> Output Class Initialized
INFO - 2018-10-18 16:08:47 --> Security Class Initialized
DEBUG - 2018-10-18 16:08:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 16:08:47 --> CSRF cookie sent
INFO - 2018-10-18 16:08:47 --> Input Class Initialized
INFO - 2018-10-18 16:08:47 --> Language Class Initialized
INFO - 2018-10-18 16:08:47 --> Loader Class Initialized
INFO - 2018-10-18 16:08:47 --> Helper loaded: url_helper
INFO - 2018-10-18 16:08:47 --> Helper loaded: form_helper
INFO - 2018-10-18 16:08:47 --> Helper loaded: language_helper
DEBUG - 2018-10-18 16:08:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 16:08:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 16:08:47 --> User Agent Class Initialized
INFO - 2018-10-18 16:08:47 --> Controller Class Initialized
INFO - 2018-10-18 16:08:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 16:08:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 16:08:47 --> Config Class Initialized
INFO - 2018-10-18 16:08:47 --> Hooks Class Initialized
DEBUG - 2018-10-18 16:08:48 --> UTF-8 Support Enabled
INFO - 2018-10-18 16:08:48 --> Utf8 Class Initialized
INFO - 2018-10-18 16:08:48 --> URI Class Initialized
INFO - 2018-10-18 16:08:48 --> Router Class Initialized
INFO - 2018-10-18 16:08:48 --> Output Class Initialized
INFO - 2018-10-18 16:08:48 --> Security Class Initialized
DEBUG - 2018-10-18 16:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 16:08:48 --> CSRF cookie sent
INFO - 2018-10-18 16:08:48 --> Input Class Initialized
INFO - 2018-10-18 16:08:48 --> Language Class Initialized
INFO - 2018-10-18 16:08:48 --> Loader Class Initialized
INFO - 2018-10-18 16:08:48 --> Helper loaded: url_helper
INFO - 2018-10-18 16:08:48 --> Helper loaded: form_helper
INFO - 2018-10-18 16:08:48 --> Helper loaded: language_helper
DEBUG - 2018-10-18 16:08:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 16:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 16:08:48 --> User Agent Class Initialized
INFO - 2018-10-18 16:08:48 --> Controller Class Initialized
INFO - 2018-10-18 16:08:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 16:08:48 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-18 16:08:48 --> Config file loaded: F:\xampp\htdocs\famiquity\application\config/recaptcha.php
INFO - 2018-10-18 16:08:48 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 16:08:48 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_end_user_nav.php
INFO - 2018-10-18 16:08:48 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 16:08:48 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 16:08:48 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_page_header.php
ERROR - 2018-10-18 16:08:48 --> Could not find the language line "req_email"
INFO - 2018-10-18 16:08:48 --> File loaded: F:\xampp\htdocs\famiquity\application\views\myaccount/signin.php
INFO - 2018-10-18 16:08:49 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 16:08:49 --> Final output sent to browser
DEBUG - 2018-10-18 16:08:49 --> Total execution time: 1.0942
INFO - 2018-10-18 16:08:55 --> Config Class Initialized
INFO - 2018-10-18 16:08:55 --> Hooks Class Initialized
DEBUG - 2018-10-18 16:08:55 --> UTF-8 Support Enabled
INFO - 2018-10-18 16:08:55 --> Utf8 Class Initialized
INFO - 2018-10-18 16:08:55 --> URI Class Initialized
INFO - 2018-10-18 16:08:55 --> Router Class Initialized
INFO - 2018-10-18 16:08:55 --> Output Class Initialized
INFO - 2018-10-18 16:08:55 --> Security Class Initialized
DEBUG - 2018-10-18 16:08:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 16:08:55 --> CSRF cookie sent
INFO - 2018-10-18 16:08:56 --> Input Class Initialized
INFO - 2018-10-18 16:08:56 --> Language Class Initialized
INFO - 2018-10-18 16:08:56 --> Loader Class Initialized
INFO - 2018-10-18 16:08:56 --> Helper loaded: url_helper
INFO - 2018-10-18 16:08:56 --> Helper loaded: form_helper
INFO - 2018-10-18 16:08:56 --> Helper loaded: language_helper
DEBUG - 2018-10-18 16:08:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 16:08:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 16:08:56 --> User Agent Class Initialized
INFO - 2018-10-18 16:08:56 --> Controller Class Initialized
INFO - 2018-10-18 16:08:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 16:08:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 16:08:56 --> Config Class Initialized
INFO - 2018-10-18 16:08:56 --> Hooks Class Initialized
DEBUG - 2018-10-18 16:08:56 --> UTF-8 Support Enabled
INFO - 2018-10-18 16:08:56 --> Utf8 Class Initialized
INFO - 2018-10-18 16:08:56 --> URI Class Initialized
INFO - 2018-10-18 16:08:56 --> Router Class Initialized
INFO - 2018-10-18 16:08:56 --> Output Class Initialized
INFO - 2018-10-18 16:08:56 --> Security Class Initialized
DEBUG - 2018-10-18 16:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 16:08:56 --> CSRF cookie sent
INFO - 2018-10-18 16:08:57 --> Input Class Initialized
INFO - 2018-10-18 16:08:57 --> Language Class Initialized
INFO - 2018-10-18 16:08:57 --> Loader Class Initialized
INFO - 2018-10-18 16:08:57 --> Helper loaded: url_helper
INFO - 2018-10-18 16:08:57 --> Helper loaded: form_helper
INFO - 2018-10-18 16:08:57 --> Helper loaded: language_helper
DEBUG - 2018-10-18 16:08:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 16:08:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 16:08:57 --> User Agent Class Initialized
INFO - 2018-10-18 16:08:57 --> Controller Class Initialized
INFO - 2018-10-18 16:08:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 16:08:57 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-18 16:08:57 --> Config file loaded: F:\xampp\htdocs\famiquity\application\config/recaptcha.php
INFO - 2018-10-18 16:08:57 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 16:08:57 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_end_user_nav.php
INFO - 2018-10-18 16:08:57 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 16:08:57 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 16:08:57 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_page_header.php
ERROR - 2018-10-18 16:08:57 --> Could not find the language line "req_email"
INFO - 2018-10-18 16:08:57 --> File loaded: F:\xampp\htdocs\famiquity\application\views\myaccount/signin.php
INFO - 2018-10-18 16:08:58 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 16:08:58 --> Final output sent to browser
DEBUG - 2018-10-18 16:08:58 --> Total execution time: 1.4500
INFO - 2018-10-18 16:09:32 --> Config Class Initialized
INFO - 2018-10-18 16:09:32 --> Hooks Class Initialized
DEBUG - 2018-10-18 16:09:32 --> UTF-8 Support Enabled
INFO - 2018-10-18 16:09:32 --> Utf8 Class Initialized
INFO - 2018-10-18 16:09:33 --> URI Class Initialized
INFO - 2018-10-18 16:09:33 --> Router Class Initialized
INFO - 2018-10-18 16:09:33 --> Output Class Initialized
INFO - 2018-10-18 16:09:33 --> Security Class Initialized
DEBUG - 2018-10-18 16:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 16:09:33 --> CSRF cookie sent
INFO - 2018-10-18 16:09:33 --> Input Class Initialized
INFO - 2018-10-18 16:09:33 --> Language Class Initialized
INFO - 2018-10-18 16:09:33 --> Loader Class Initialized
INFO - 2018-10-18 16:09:33 --> Helper loaded: url_helper
INFO - 2018-10-18 16:09:33 --> Helper loaded: form_helper
INFO - 2018-10-18 16:09:33 --> Helper loaded: language_helper
DEBUG - 2018-10-18 16:09:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 16:09:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 16:09:33 --> User Agent Class Initialized
INFO - 2018-10-18 16:09:33 --> Controller Class Initialized
INFO - 2018-10-18 16:09:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 16:09:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 16:09:33 --> CSRF cookie sent
INFO - 2018-10-18 16:09:33 --> Config Class Initialized
INFO - 2018-10-18 16:09:33 --> Hooks Class Initialized
DEBUG - 2018-10-18 16:09:33 --> UTF-8 Support Enabled
INFO - 2018-10-18 16:09:33 --> Utf8 Class Initialized
INFO - 2018-10-18 16:09:33 --> URI Class Initialized
DEBUG - 2018-10-18 16:09:34 --> No URI present. Default controller set.
INFO - 2018-10-18 16:09:34 --> Router Class Initialized
INFO - 2018-10-18 16:09:34 --> Output Class Initialized
INFO - 2018-10-18 16:09:34 --> Security Class Initialized
DEBUG - 2018-10-18 16:09:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 16:09:34 --> CSRF cookie sent
INFO - 2018-10-18 16:09:34 --> Input Class Initialized
INFO - 2018-10-18 16:09:34 --> Language Class Initialized
INFO - 2018-10-18 16:09:34 --> Loader Class Initialized
INFO - 2018-10-18 16:09:34 --> Helper loaded: url_helper
INFO - 2018-10-18 16:09:34 --> Helper loaded: form_helper
INFO - 2018-10-18 16:09:34 --> Helper loaded: language_helper
DEBUG - 2018-10-18 16:09:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 16:09:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 16:09:34 --> User Agent Class Initialized
INFO - 2018-10-18 16:09:34 --> Controller Class Initialized
INFO - 2018-10-18 16:09:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 16:09:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 16:09:34 --> Pixel_Model class loaded
INFO - 2018-10-18 16:09:34 --> Database Driver Class Initialized
INFO - 2018-10-18 16:09:34 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 16:09:34 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 16:09:34 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 16:09:34 --> File loaded: F:\xampp\htdocs\famiquity\application\views\home.php
INFO - 2018-10-18 16:09:34 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 16:09:34 --> Final output sent to browser
DEBUG - 2018-10-18 16:09:35 --> Total execution time: 1.1117
INFO - 2018-10-18 16:09:39 --> Config Class Initialized
INFO - 2018-10-18 16:09:39 --> Hooks Class Initialized
DEBUG - 2018-10-18 16:09:40 --> UTF-8 Support Enabled
INFO - 2018-10-18 16:09:40 --> Utf8 Class Initialized
INFO - 2018-10-18 16:09:40 --> URI Class Initialized
INFO - 2018-10-18 16:09:40 --> Router Class Initialized
INFO - 2018-10-18 16:09:40 --> Output Class Initialized
INFO - 2018-10-18 16:09:40 --> Security Class Initialized
DEBUG - 2018-10-18 16:09:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 16:09:40 --> CSRF cookie sent
INFO - 2018-10-18 16:09:40 --> Input Class Initialized
INFO - 2018-10-18 16:09:40 --> Language Class Initialized
INFO - 2018-10-18 16:09:40 --> Loader Class Initialized
INFO - 2018-10-18 16:09:40 --> Helper loaded: url_helper
INFO - 2018-10-18 16:09:40 --> Helper loaded: form_helper
INFO - 2018-10-18 16:09:40 --> Helper loaded: language_helper
DEBUG - 2018-10-18 16:09:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 16:09:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 16:09:40 --> User Agent Class Initialized
INFO - 2018-10-18 16:09:40 --> Controller Class Initialized
INFO - 2018-10-18 16:09:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 16:09:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 16:09:41 --> Pixel_Model class loaded
INFO - 2018-10-18 16:09:41 --> Database Driver Class Initialized
INFO - 2018-10-18 16:09:41 --> Model "RegistrationModel" initialized
DEBUG - 2018-10-18 16:09:41 --> Config file loaded: F:\xampp\htdocs\famiquity\application\config/recaptcha.php
INFO - 2018-10-18 16:09:41 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 16:09:41 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 16:09:41 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 16:09:41 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_page_header.php
ERROR - 2018-10-18 16:09:41 --> Could not find the language line "req_email"
INFO - 2018-10-18 16:09:41 --> File loaded: F:\xampp\htdocs\famiquity\application\views\register/signup.php
INFO - 2018-10-18 16:09:41 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 16:09:41 --> Final output sent to browser
DEBUG - 2018-10-18 16:09:41 --> Total execution time: 1.6914
INFO - 2018-10-18 16:10:25 --> Config Class Initialized
INFO - 2018-10-18 16:10:25 --> Hooks Class Initialized
DEBUG - 2018-10-18 16:10:25 --> UTF-8 Support Enabled
INFO - 2018-10-18 16:10:25 --> Utf8 Class Initialized
INFO - 2018-10-18 16:10:25 --> URI Class Initialized
INFO - 2018-10-18 16:10:25 --> Router Class Initialized
INFO - 2018-10-18 16:10:25 --> Output Class Initialized
INFO - 2018-10-18 16:10:25 --> Security Class Initialized
DEBUG - 2018-10-18 16:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 16:10:25 --> CSRF cookie sent
INFO - 2018-10-18 16:10:25 --> CSRF token verified
INFO - 2018-10-18 16:10:25 --> Input Class Initialized
INFO - 2018-10-18 16:10:25 --> Language Class Initialized
INFO - 2018-10-18 16:10:25 --> Loader Class Initialized
INFO - 2018-10-18 16:10:25 --> Helper loaded: url_helper
INFO - 2018-10-18 16:10:25 --> Helper loaded: form_helper
INFO - 2018-10-18 16:10:25 --> Helper loaded: language_helper
DEBUG - 2018-10-18 16:10:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 16:10:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 16:10:25 --> User Agent Class Initialized
INFO - 2018-10-18 16:10:25 --> Controller Class Initialized
INFO - 2018-10-18 16:10:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 16:10:25 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-18 16:10:25 --> Config file loaded: F:\xampp\htdocs\famiquity\application\config/recaptcha.php
INFO - 2018-10-18 16:10:26 --> Config Class Initialized
INFO - 2018-10-18 16:10:26 --> Hooks Class Initialized
DEBUG - 2018-10-18 16:10:26 --> UTF-8 Support Enabled
INFO - 2018-10-18 16:10:26 --> Utf8 Class Initialized
INFO - 2018-10-18 16:10:26 --> URI Class Initialized
INFO - 2018-10-18 16:10:26 --> Router Class Initialized
INFO - 2018-10-18 16:10:26 --> Output Class Initialized
INFO - 2018-10-18 16:10:26 --> Security Class Initialized
DEBUG - 2018-10-18 16:10:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 16:10:26 --> CSRF cookie sent
INFO - 2018-10-18 16:10:26 --> Input Class Initialized
INFO - 2018-10-18 16:10:26 --> Language Class Initialized
INFO - 2018-10-18 16:10:26 --> Loader Class Initialized
INFO - 2018-10-18 16:10:26 --> Helper loaded: url_helper
INFO - 2018-10-18 16:10:26 --> Helper loaded: form_helper
INFO - 2018-10-18 16:10:26 --> Helper loaded: language_helper
DEBUG - 2018-10-18 16:10:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 16:10:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 16:10:26 --> User Agent Class Initialized
INFO - 2018-10-18 16:10:26 --> Controller Class Initialized
INFO - 2018-10-18 16:10:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 16:10:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 16:10:26 --> Pixel_Model class loaded
INFO - 2018-10-18 16:10:26 --> Database Driver Class Initialized
INFO - 2018-10-18 16:10:26 --> Model "RegistrationModel" initialized
DEBUG - 2018-10-18 16:10:26 --> Config file loaded: F:\xampp\htdocs\famiquity\application\config/recaptcha.php
INFO - 2018-10-18 16:10:27 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 16:10:27 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 16:10:27 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 16:10:27 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 16:10:27 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_soft_error.php
ERROR - 2018-10-18 16:10:27 --> Could not find the language line "req_email"
INFO - 2018-10-18 16:10:27 --> File loaded: F:\xampp\htdocs\famiquity\application\views\register/signup.php
INFO - 2018-10-18 16:10:27 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 16:10:27 --> Final output sent to browser
DEBUG - 2018-10-18 16:10:27 --> Total execution time: 1.2442
INFO - 2018-10-18 16:11:38 --> Config Class Initialized
INFO - 2018-10-18 16:11:38 --> Hooks Class Initialized
DEBUG - 2018-10-18 16:11:38 --> UTF-8 Support Enabled
INFO - 2018-10-18 16:11:38 --> Utf8 Class Initialized
INFO - 2018-10-18 16:11:38 --> URI Class Initialized
INFO - 2018-10-18 16:11:38 --> Router Class Initialized
INFO - 2018-10-18 16:11:38 --> Output Class Initialized
INFO - 2018-10-18 16:11:38 --> Security Class Initialized
DEBUG - 2018-10-18 16:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 16:11:38 --> CSRF cookie sent
INFO - 2018-10-18 16:11:38 --> Input Class Initialized
INFO - 2018-10-18 16:11:38 --> Language Class Initialized
INFO - 2018-10-18 16:11:38 --> Loader Class Initialized
INFO - 2018-10-18 16:11:38 --> Helper loaded: url_helper
INFO - 2018-10-18 16:11:38 --> Helper loaded: form_helper
INFO - 2018-10-18 16:11:38 --> Helper loaded: language_helper
DEBUG - 2018-10-18 16:11:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 16:11:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 16:11:38 --> User Agent Class Initialized
INFO - 2018-10-18 16:11:38 --> Controller Class Initialized
INFO - 2018-10-18 16:11:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 16:11:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 16:11:39 --> Pixel_Model class loaded
INFO - 2018-10-18 16:11:39 --> Database Driver Class Initialized
INFO - 2018-10-18 16:11:39 --> Model "RegistrationModel" initialized
DEBUG - 2018-10-18 16:11:39 --> Config file loaded: F:\xampp\htdocs\famiquity\application\config/recaptcha.php
INFO - 2018-10-18 16:11:39 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 16:11:39 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 16:11:39 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 16:11:39 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_page_header.php
ERROR - 2018-10-18 16:11:39 --> Could not find the language line "req_email"
INFO - 2018-10-18 16:11:39 --> File loaded: F:\xampp\htdocs\famiquity\application\views\register/signup.php
INFO - 2018-10-18 16:11:39 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 16:11:39 --> Final output sent to browser
DEBUG - 2018-10-18 16:11:39 --> Total execution time: 1.5100
INFO - 2018-10-18 16:16:02 --> Config Class Initialized
INFO - 2018-10-18 16:16:02 --> Hooks Class Initialized
DEBUG - 2018-10-18 16:16:02 --> UTF-8 Support Enabled
INFO - 2018-10-18 16:16:03 --> Utf8 Class Initialized
INFO - 2018-10-18 16:16:03 --> URI Class Initialized
INFO - 2018-10-18 16:16:03 --> Router Class Initialized
INFO - 2018-10-18 16:16:03 --> Output Class Initialized
INFO - 2018-10-18 16:16:03 --> Security Class Initialized
DEBUG - 2018-10-18 16:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 16:16:03 --> CSRF cookie sent
INFO - 2018-10-18 16:16:03 --> Input Class Initialized
INFO - 2018-10-18 16:16:03 --> Language Class Initialized
INFO - 2018-10-18 16:16:03 --> Loader Class Initialized
INFO - 2018-10-18 16:16:03 --> Helper loaded: url_helper
INFO - 2018-10-18 16:16:03 --> Helper loaded: form_helper
INFO - 2018-10-18 16:16:03 --> Helper loaded: language_helper
DEBUG - 2018-10-18 16:16:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 16:16:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 16:16:03 --> User Agent Class Initialized
INFO - 2018-10-18 16:16:03 --> Controller Class Initialized
INFO - 2018-10-18 16:16:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 16:16:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 16:16:03 --> Pixel_Model class loaded
INFO - 2018-10-18 16:16:03 --> Database Driver Class Initialized
INFO - 2018-10-18 16:16:03 --> Model "RegistrationModel" initialized
DEBUG - 2018-10-18 16:16:04 --> Config file loaded: F:\xampp\htdocs\famiquity\application\config/recaptcha.php
INFO - 2018-10-18 16:16:04 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 16:16:04 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 16:16:04 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 16:16:04 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_page_header.php
ERROR - 2018-10-18 16:16:04 --> Could not find the language line "req_email"
INFO - 2018-10-18 16:16:04 --> File loaded: F:\xampp\htdocs\famiquity\application\views\register/signup.php
INFO - 2018-10-18 16:16:04 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 16:16:04 --> Final output sent to browser
DEBUG - 2018-10-18 16:16:04 --> Total execution time: 1.5775
INFO - 2018-10-18 16:17:55 --> Config Class Initialized
INFO - 2018-10-18 16:17:55 --> Hooks Class Initialized
DEBUG - 2018-10-18 16:17:55 --> UTF-8 Support Enabled
INFO - 2018-10-18 16:17:55 --> Utf8 Class Initialized
INFO - 2018-10-18 16:17:55 --> URI Class Initialized
INFO - 2018-10-18 16:17:55 --> Router Class Initialized
INFO - 2018-10-18 16:17:55 --> Output Class Initialized
INFO - 2018-10-18 16:17:55 --> Security Class Initialized
DEBUG - 2018-10-18 16:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 16:17:55 --> CSRF cookie sent
INFO - 2018-10-18 16:17:55 --> Input Class Initialized
INFO - 2018-10-18 16:17:55 --> Language Class Initialized
INFO - 2018-10-18 16:17:55 --> Loader Class Initialized
INFO - 2018-10-18 16:17:55 --> Helper loaded: url_helper
INFO - 2018-10-18 16:17:55 --> Helper loaded: form_helper
INFO - 2018-10-18 16:17:55 --> Helper loaded: language_helper
DEBUG - 2018-10-18 16:17:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 16:17:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 16:17:55 --> User Agent Class Initialized
INFO - 2018-10-18 16:17:55 --> Controller Class Initialized
INFO - 2018-10-18 16:17:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 16:17:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 16:17:56 --> Pixel_Model class loaded
INFO - 2018-10-18 16:17:56 --> Database Driver Class Initialized
INFO - 2018-10-18 16:17:56 --> Model "RegistrationModel" initialized
DEBUG - 2018-10-18 16:17:56 --> Config file loaded: F:\xampp\htdocs\famiquity\application\config/recaptcha.php
INFO - 2018-10-18 16:17:56 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 16:17:56 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 16:17:56 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 16:17:56 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_page_header.php
ERROR - 2018-10-18 16:17:56 --> Could not find the language line "req_email"
INFO - 2018-10-18 16:17:56 --> File loaded: F:\xampp\htdocs\famiquity\application\views\register/signup.php
INFO - 2018-10-18 16:17:56 --> File loaded: F:\xampp\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 16:17:56 --> Final output sent to browser
DEBUG - 2018-10-18 16:17:56 --> Total execution time: 1.3980
INFO - 2018-10-18 16:49:02 --> Config Class Initialized
INFO - 2018-10-18 16:49:02 --> Hooks Class Initialized
DEBUG - 2018-10-18 16:49:02 --> UTF-8 Support Enabled
INFO - 2018-10-18 16:49:02 --> Utf8 Class Initialized
INFO - 2018-10-18 16:49:02 --> URI Class Initialized
DEBUG - 2018-10-18 16:49:02 --> No URI present. Default controller set.
INFO - 2018-10-18 16:49:02 --> Router Class Initialized
INFO - 2018-10-18 16:49:02 --> Output Class Initialized
INFO - 2018-10-18 16:49:02 --> Security Class Initialized
DEBUG - 2018-10-18 16:49:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 16:49:03 --> CSRF cookie sent
INFO - 2018-10-18 16:49:03 --> Input Class Initialized
INFO - 2018-10-18 16:49:03 --> Language Class Initialized
INFO - 2018-10-18 16:49:03 --> Loader Class Initialized
INFO - 2018-10-18 16:49:03 --> Helper loaded: url_helper
INFO - 2018-10-18 16:49:03 --> Helper loaded: form_helper
INFO - 2018-10-18 16:49:03 --> Helper loaded: language_helper
DEBUG - 2018-10-18 16:49:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 16:49:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 16:49:03 --> User Agent Class Initialized
INFO - 2018-10-18 16:49:03 --> Controller Class Initialized
INFO - 2018-10-18 16:49:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 16:49:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 16:49:03 --> Pixel_Model class loaded
INFO - 2018-10-18 16:49:03 --> Database Driver Class Initialized
INFO - 2018-10-18 16:49:03 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 16:49:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 16:49:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 16:49:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-18 16:49:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 16:49:03 --> Final output sent to browser
DEBUG - 2018-10-18 16:49:03 --> Total execution time: 0.6080
INFO - 2018-10-18 16:51:29 --> Config Class Initialized
INFO - 2018-10-18 16:51:29 --> Hooks Class Initialized
DEBUG - 2018-10-18 16:51:29 --> UTF-8 Support Enabled
INFO - 2018-10-18 16:51:29 --> Utf8 Class Initialized
INFO - 2018-10-18 16:51:29 --> URI Class Initialized
INFO - 2018-10-18 16:51:29 --> Router Class Initialized
INFO - 2018-10-18 16:51:29 --> Output Class Initialized
INFO - 2018-10-18 16:51:29 --> Security Class Initialized
DEBUG - 2018-10-18 16:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 16:51:29 --> CSRF cookie sent
INFO - 2018-10-18 16:51:29 --> Input Class Initialized
INFO - 2018-10-18 16:51:29 --> Language Class Initialized
INFO - 2018-10-18 16:51:29 --> Loader Class Initialized
INFO - 2018-10-18 16:51:29 --> Helper loaded: url_helper
INFO - 2018-10-18 16:51:29 --> Helper loaded: form_helper
INFO - 2018-10-18 16:51:29 --> Helper loaded: language_helper
DEBUG - 2018-10-18 16:51:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 16:51:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 16:51:29 --> User Agent Class Initialized
INFO - 2018-10-18 16:51:29 --> Controller Class Initialized
INFO - 2018-10-18 16:51:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 16:51:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 16:51:29 --> Pixel_Model class loaded
INFO - 2018-10-18 16:51:29 --> Database Driver Class Initialized
INFO - 2018-10-18 16:51:29 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 16:51:29 --> Config Class Initialized
INFO - 2018-10-18 16:51:29 --> Hooks Class Initialized
DEBUG - 2018-10-18 16:51:29 --> UTF-8 Support Enabled
INFO - 2018-10-18 16:51:29 --> Utf8 Class Initialized
INFO - 2018-10-18 16:51:29 --> URI Class Initialized
INFO - 2018-10-18 16:51:29 --> Router Class Initialized
INFO - 2018-10-18 16:51:29 --> Output Class Initialized
INFO - 2018-10-18 16:51:29 --> Security Class Initialized
DEBUG - 2018-10-18 16:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 16:51:29 --> CSRF cookie sent
INFO - 2018-10-18 16:51:29 --> Input Class Initialized
INFO - 2018-10-18 16:51:29 --> Language Class Initialized
INFO - 2018-10-18 16:51:29 --> Loader Class Initialized
INFO - 2018-10-18 16:51:29 --> Helper loaded: url_helper
INFO - 2018-10-18 16:51:29 --> Helper loaded: form_helper
INFO - 2018-10-18 16:51:29 --> Helper loaded: language_helper
DEBUG - 2018-10-18 16:51:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 16:51:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 16:51:29 --> User Agent Class Initialized
INFO - 2018-10-18 16:51:29 --> Controller Class Initialized
INFO - 2018-10-18 16:51:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 16:51:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 16:51:30 --> Pixel_Model class loaded
INFO - 2018-10-18 16:51:30 --> Database Driver Class Initialized
INFO - 2018-10-18 16:51:30 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 16:51:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 16:51:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 16:51:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 16:51:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 16:51:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 16:51:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 16:51:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-18 16:51:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 16:51:30 --> Final output sent to browser
DEBUG - 2018-10-18 16:51:30 --> Total execution time: 0.6381
INFO - 2018-10-18 16:54:55 --> Config Class Initialized
INFO - 2018-10-18 16:54:55 --> Hooks Class Initialized
DEBUG - 2018-10-18 16:54:55 --> UTF-8 Support Enabled
INFO - 2018-10-18 16:54:55 --> Utf8 Class Initialized
INFO - 2018-10-18 16:54:55 --> URI Class Initialized
INFO - 2018-10-18 16:54:55 --> Router Class Initialized
INFO - 2018-10-18 16:54:55 --> Output Class Initialized
INFO - 2018-10-18 16:54:55 --> Security Class Initialized
DEBUG - 2018-10-18 16:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 16:54:55 --> CSRF cookie sent
INFO - 2018-10-18 16:54:55 --> CSRF token verified
INFO - 2018-10-18 16:54:55 --> Input Class Initialized
INFO - 2018-10-18 16:54:55 --> Language Class Initialized
INFO - 2018-10-18 16:54:55 --> Loader Class Initialized
INFO - 2018-10-18 16:54:55 --> Helper loaded: url_helper
INFO - 2018-10-18 16:54:55 --> Helper loaded: form_helper
INFO - 2018-10-18 16:54:55 --> Helper loaded: language_helper
DEBUG - 2018-10-18 16:54:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 16:54:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 16:54:55 --> User Agent Class Initialized
INFO - 2018-10-18 16:54:55 --> Controller Class Initialized
INFO - 2018-10-18 16:54:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 16:54:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 16:54:56 --> Pixel_Model class loaded
INFO - 2018-10-18 16:54:56 --> Database Driver Class Initialized
INFO - 2018-10-18 16:54:56 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 16:54:56 --> Form Validation Class Initialized
INFO - 2018-10-18 16:54:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 16:54:56 --> Database Driver Class Initialized
INFO - 2018-10-18 16:54:56 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 16:54:56 --> Config Class Initialized
INFO - 2018-10-18 16:54:56 --> Hooks Class Initialized
DEBUG - 2018-10-18 16:54:56 --> UTF-8 Support Enabled
INFO - 2018-10-18 16:54:56 --> Utf8 Class Initialized
INFO - 2018-10-18 16:54:56 --> URI Class Initialized
INFO - 2018-10-18 16:54:56 --> Router Class Initialized
INFO - 2018-10-18 16:54:56 --> Output Class Initialized
INFO - 2018-10-18 16:54:56 --> Security Class Initialized
DEBUG - 2018-10-18 16:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 16:54:56 --> CSRF cookie sent
INFO - 2018-10-18 16:54:56 --> Input Class Initialized
INFO - 2018-10-18 16:54:56 --> Language Class Initialized
INFO - 2018-10-18 16:54:56 --> Loader Class Initialized
INFO - 2018-10-18 16:54:56 --> Helper loaded: url_helper
INFO - 2018-10-18 16:54:56 --> Helper loaded: form_helper
INFO - 2018-10-18 16:54:56 --> Helper loaded: language_helper
DEBUG - 2018-10-18 16:54:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 16:54:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 16:54:56 --> User Agent Class Initialized
INFO - 2018-10-18 16:54:56 --> Controller Class Initialized
INFO - 2018-10-18 16:54:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 16:54:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 16:54:56 --> Pixel_Model class loaded
INFO - 2018-10-18 16:54:56 --> Database Driver Class Initialized
INFO - 2018-10-18 16:54:56 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 16:54:56 --> Database Driver Class Initialized
INFO - 2018-10-18 16:54:56 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 16:54:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 16:54:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 16:54:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 16:54:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 16:54:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 16:54:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 16:54:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-18 16:54:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 16:54:56 --> Final output sent to browser
DEBUG - 2018-10-18 16:54:56 --> Total execution time: 0.6840
INFO - 2018-10-18 16:55:19 --> Config Class Initialized
INFO - 2018-10-18 16:55:19 --> Hooks Class Initialized
DEBUG - 2018-10-18 16:55:19 --> UTF-8 Support Enabled
INFO - 2018-10-18 16:55:19 --> Utf8 Class Initialized
INFO - 2018-10-18 16:55:19 --> URI Class Initialized
INFO - 2018-10-18 16:55:19 --> Router Class Initialized
INFO - 2018-10-18 16:55:19 --> Output Class Initialized
INFO - 2018-10-18 16:55:19 --> Security Class Initialized
DEBUG - 2018-10-18 16:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 16:55:19 --> CSRF cookie sent
INFO - 2018-10-18 16:55:19 --> Input Class Initialized
INFO - 2018-10-18 16:55:19 --> Language Class Initialized
ERROR - 2018-10-18 16:55:19 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 16:58:49 --> Config Class Initialized
INFO - 2018-10-18 16:58:49 --> Hooks Class Initialized
DEBUG - 2018-10-18 16:58:49 --> UTF-8 Support Enabled
INFO - 2018-10-18 16:58:49 --> Utf8 Class Initialized
INFO - 2018-10-18 16:58:49 --> URI Class Initialized
INFO - 2018-10-18 16:58:49 --> Router Class Initialized
INFO - 2018-10-18 16:58:49 --> Output Class Initialized
INFO - 2018-10-18 16:58:49 --> Security Class Initialized
DEBUG - 2018-10-18 16:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 16:58:49 --> CSRF cookie sent
INFO - 2018-10-18 16:58:49 --> Input Class Initialized
INFO - 2018-10-18 16:58:49 --> Language Class Initialized
INFO - 2018-10-18 16:58:49 --> Loader Class Initialized
INFO - 2018-10-18 16:58:49 --> Helper loaded: url_helper
INFO - 2018-10-18 16:58:49 --> Helper loaded: form_helper
INFO - 2018-10-18 16:58:49 --> Helper loaded: language_helper
DEBUG - 2018-10-18 16:58:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 16:58:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 16:58:49 --> User Agent Class Initialized
INFO - 2018-10-18 16:58:49 --> Controller Class Initialized
INFO - 2018-10-18 16:58:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 16:58:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 16:58:49 --> Pixel_Model class loaded
INFO - 2018-10-18 16:58:49 --> Database Driver Class Initialized
INFO - 2018-10-18 16:58:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 16:58:49 --> Database Driver Class Initialized
INFO - 2018-10-18 16:58:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 16:58:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 16:58:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 16:58:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 16:58:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 16:58:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 16:58:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 16:58:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-18 16:58:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 16:58:49 --> Final output sent to browser
DEBUG - 2018-10-18 16:58:49 --> Total execution time: 0.7136
INFO - 2018-10-18 16:58:50 --> Config Class Initialized
INFO - 2018-10-18 16:58:50 --> Hooks Class Initialized
DEBUG - 2018-10-18 16:58:50 --> UTF-8 Support Enabled
INFO - 2018-10-18 16:58:50 --> Utf8 Class Initialized
INFO - 2018-10-18 16:58:50 --> URI Class Initialized
INFO - 2018-10-18 16:58:50 --> Router Class Initialized
INFO - 2018-10-18 16:58:50 --> Output Class Initialized
INFO - 2018-10-18 16:58:50 --> Security Class Initialized
DEBUG - 2018-10-18 16:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 16:58:50 --> CSRF cookie sent
INFO - 2018-10-18 16:58:50 --> Input Class Initialized
INFO - 2018-10-18 16:58:50 --> Language Class Initialized
ERROR - 2018-10-18 16:58:50 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 16:59:01 --> Config Class Initialized
INFO - 2018-10-18 16:59:01 --> Hooks Class Initialized
DEBUG - 2018-10-18 16:59:01 --> UTF-8 Support Enabled
INFO - 2018-10-18 16:59:01 --> Utf8 Class Initialized
INFO - 2018-10-18 16:59:01 --> URI Class Initialized
INFO - 2018-10-18 16:59:01 --> Router Class Initialized
INFO - 2018-10-18 16:59:01 --> Output Class Initialized
INFO - 2018-10-18 16:59:01 --> Security Class Initialized
DEBUG - 2018-10-18 16:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 16:59:01 --> CSRF cookie sent
INFO - 2018-10-18 16:59:01 --> Input Class Initialized
INFO - 2018-10-18 16:59:01 --> Language Class Initialized
INFO - 2018-10-18 16:59:01 --> Loader Class Initialized
INFO - 2018-10-18 16:59:01 --> Helper loaded: url_helper
INFO - 2018-10-18 16:59:01 --> Helper loaded: form_helper
INFO - 2018-10-18 16:59:01 --> Helper loaded: language_helper
DEBUG - 2018-10-18 16:59:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 16:59:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 16:59:01 --> User Agent Class Initialized
INFO - 2018-10-18 16:59:01 --> Controller Class Initialized
INFO - 2018-10-18 16:59:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 16:59:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 16:59:01 --> Pixel_Model class loaded
INFO - 2018-10-18 16:59:01 --> Database Driver Class Initialized
INFO - 2018-10-18 16:59:01 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 16:59:02 --> Database Driver Class Initialized
INFO - 2018-10-18 16:59:02 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 16:59:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 16:59:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 16:59:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 16:59:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 16:59:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 16:59:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 16:59:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-18 16:59:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 16:59:02 --> Final output sent to browser
DEBUG - 2018-10-18 16:59:02 --> Total execution time: 0.7017
INFO - 2018-10-18 16:59:02 --> Config Class Initialized
INFO - 2018-10-18 16:59:02 --> Hooks Class Initialized
DEBUG - 2018-10-18 16:59:02 --> UTF-8 Support Enabled
INFO - 2018-10-18 16:59:02 --> Utf8 Class Initialized
INFO - 2018-10-18 16:59:02 --> URI Class Initialized
INFO - 2018-10-18 16:59:02 --> Router Class Initialized
INFO - 2018-10-18 16:59:02 --> Output Class Initialized
INFO - 2018-10-18 16:59:02 --> Security Class Initialized
DEBUG - 2018-10-18 16:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 16:59:02 --> CSRF cookie sent
INFO - 2018-10-18 16:59:02 --> Input Class Initialized
INFO - 2018-10-18 16:59:02 --> Language Class Initialized
ERROR - 2018-10-18 16:59:02 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 17:02:35 --> Config Class Initialized
INFO - 2018-10-18 17:02:35 --> Hooks Class Initialized
DEBUG - 2018-10-18 17:02:35 --> UTF-8 Support Enabled
INFO - 2018-10-18 17:02:35 --> Utf8 Class Initialized
INFO - 2018-10-18 17:02:35 --> URI Class Initialized
INFO - 2018-10-18 17:02:35 --> Router Class Initialized
INFO - 2018-10-18 17:02:35 --> Output Class Initialized
INFO - 2018-10-18 17:02:35 --> Security Class Initialized
DEBUG - 2018-10-18 17:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 17:02:35 --> CSRF cookie sent
INFO - 2018-10-18 17:02:35 --> Input Class Initialized
INFO - 2018-10-18 17:02:35 --> Language Class Initialized
INFO - 2018-10-18 17:02:35 --> Loader Class Initialized
INFO - 2018-10-18 17:02:35 --> Helper loaded: url_helper
INFO - 2018-10-18 17:02:35 --> Helper loaded: form_helper
INFO - 2018-10-18 17:02:35 --> Helper loaded: language_helper
DEBUG - 2018-10-18 17:02:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 17:02:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 17:02:35 --> User Agent Class Initialized
INFO - 2018-10-18 17:02:35 --> Controller Class Initialized
INFO - 2018-10-18 17:02:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 17:02:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 17:02:36 --> Pixel_Model class loaded
INFO - 2018-10-18 17:02:36 --> Database Driver Class Initialized
INFO - 2018-10-18 17:02:36 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 17:02:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 17:02:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 17:02:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 17:02:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 17:02:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 17:02:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 17:02:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-18 17:02:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 17:02:36 --> Final output sent to browser
DEBUG - 2018-10-18 17:02:36 --> Total execution time: 0.7046
INFO - 2018-10-18 17:02:36 --> Config Class Initialized
INFO - 2018-10-18 17:02:36 --> Hooks Class Initialized
DEBUG - 2018-10-18 17:02:36 --> UTF-8 Support Enabled
INFO - 2018-10-18 17:02:36 --> Utf8 Class Initialized
INFO - 2018-10-18 17:02:36 --> URI Class Initialized
INFO - 2018-10-18 17:02:36 --> Router Class Initialized
INFO - 2018-10-18 17:02:36 --> Output Class Initialized
INFO - 2018-10-18 17:02:36 --> Security Class Initialized
DEBUG - 2018-10-18 17:02:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 17:02:36 --> CSRF cookie sent
INFO - 2018-10-18 17:02:36 --> Input Class Initialized
INFO - 2018-10-18 17:02:36 --> Language Class Initialized
ERROR - 2018-10-18 17:02:36 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 17:03:39 --> Config Class Initialized
INFO - 2018-10-18 17:03:39 --> Hooks Class Initialized
DEBUG - 2018-10-18 17:03:39 --> UTF-8 Support Enabled
INFO - 2018-10-18 17:03:39 --> Utf8 Class Initialized
INFO - 2018-10-18 17:03:39 --> URI Class Initialized
INFO - 2018-10-18 17:03:39 --> Router Class Initialized
INFO - 2018-10-18 17:03:39 --> Output Class Initialized
INFO - 2018-10-18 17:03:39 --> Security Class Initialized
DEBUG - 2018-10-18 17:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 17:03:39 --> CSRF cookie sent
INFO - 2018-10-18 17:03:39 --> CSRF token verified
INFO - 2018-10-18 17:03:39 --> Input Class Initialized
INFO - 2018-10-18 17:03:39 --> Language Class Initialized
INFO - 2018-10-18 17:03:39 --> Loader Class Initialized
INFO - 2018-10-18 17:03:39 --> Helper loaded: url_helper
INFO - 2018-10-18 17:03:39 --> Helper loaded: form_helper
INFO - 2018-10-18 17:03:39 --> Helper loaded: language_helper
DEBUG - 2018-10-18 17:03:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 17:03:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 17:03:39 --> User Agent Class Initialized
INFO - 2018-10-18 17:03:39 --> Controller Class Initialized
INFO - 2018-10-18 17:03:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 17:03:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 17:03:39 --> Pixel_Model class loaded
INFO - 2018-10-18 17:03:39 --> Database Driver Class Initialized
INFO - 2018-10-18 17:03:39 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 17:03:39 --> Form Validation Class Initialized
INFO - 2018-10-18 17:03:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 17:03:40 --> Database Driver Class Initialized
INFO - 2018-10-18 17:03:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 17:03:40 --> Config Class Initialized
INFO - 2018-10-18 17:03:40 --> Hooks Class Initialized
DEBUG - 2018-10-18 17:03:40 --> UTF-8 Support Enabled
INFO - 2018-10-18 17:03:40 --> Utf8 Class Initialized
INFO - 2018-10-18 17:03:40 --> URI Class Initialized
INFO - 2018-10-18 17:03:40 --> Router Class Initialized
INFO - 2018-10-18 17:03:40 --> Output Class Initialized
INFO - 2018-10-18 17:03:40 --> Security Class Initialized
DEBUG - 2018-10-18 17:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 17:03:40 --> CSRF cookie sent
INFO - 2018-10-18 17:03:40 --> Input Class Initialized
INFO - 2018-10-18 17:03:40 --> Language Class Initialized
INFO - 2018-10-18 17:03:40 --> Loader Class Initialized
INFO - 2018-10-18 17:03:40 --> Helper loaded: url_helper
INFO - 2018-10-18 17:03:40 --> Helper loaded: form_helper
INFO - 2018-10-18 17:03:40 --> Helper loaded: language_helper
DEBUG - 2018-10-18 17:03:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 17:03:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 17:03:40 --> User Agent Class Initialized
INFO - 2018-10-18 17:03:40 --> Controller Class Initialized
INFO - 2018-10-18 17:03:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 17:03:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 17:03:40 --> Pixel_Model class loaded
INFO - 2018-10-18 17:03:40 --> Database Driver Class Initialized
INFO - 2018-10-18 17:03:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 17:03:40 --> Database Driver Class Initialized
INFO - 2018-10-18 17:03:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 17:03:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 17:03:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 17:03:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 17:03:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 17:03:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 17:03:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 17:03:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-18 17:03:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 17:03:40 --> Final output sent to browser
DEBUG - 2018-10-18 17:03:40 --> Total execution time: 0.7039
INFO - 2018-10-18 17:03:41 --> Config Class Initialized
INFO - 2018-10-18 17:03:41 --> Hooks Class Initialized
DEBUG - 2018-10-18 17:03:41 --> UTF-8 Support Enabled
INFO - 2018-10-18 17:03:41 --> Utf8 Class Initialized
INFO - 2018-10-18 17:03:41 --> URI Class Initialized
INFO - 2018-10-18 17:03:41 --> Router Class Initialized
INFO - 2018-10-18 17:03:41 --> Output Class Initialized
INFO - 2018-10-18 17:03:41 --> Security Class Initialized
DEBUG - 2018-10-18 17:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 17:03:41 --> CSRF cookie sent
INFO - 2018-10-18 17:03:41 --> Input Class Initialized
INFO - 2018-10-18 17:03:41 --> Language Class Initialized
ERROR - 2018-10-18 17:03:41 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 17:03:53 --> Config Class Initialized
INFO - 2018-10-18 17:03:53 --> Hooks Class Initialized
DEBUG - 2018-10-18 17:03:53 --> UTF-8 Support Enabled
INFO - 2018-10-18 17:03:53 --> Utf8 Class Initialized
INFO - 2018-10-18 17:03:53 --> URI Class Initialized
INFO - 2018-10-18 17:03:53 --> Router Class Initialized
INFO - 2018-10-18 17:03:53 --> Output Class Initialized
INFO - 2018-10-18 17:03:53 --> Security Class Initialized
DEBUG - 2018-10-18 17:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 17:03:53 --> CSRF cookie sent
INFO - 2018-10-18 17:03:53 --> Input Class Initialized
INFO - 2018-10-18 17:03:53 --> Language Class Initialized
INFO - 2018-10-18 17:03:53 --> Loader Class Initialized
INFO - 2018-10-18 17:03:53 --> Helper loaded: url_helper
INFO - 2018-10-18 17:03:53 --> Helper loaded: form_helper
INFO - 2018-10-18 17:03:54 --> Helper loaded: language_helper
DEBUG - 2018-10-18 17:03:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 17:03:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 17:03:54 --> User Agent Class Initialized
INFO - 2018-10-18 17:03:54 --> Controller Class Initialized
INFO - 2018-10-18 17:03:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 17:03:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 17:03:54 --> Pixel_Model class loaded
INFO - 2018-10-18 17:03:54 --> Database Driver Class Initialized
INFO - 2018-10-18 17:03:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 17:03:54 --> Database Driver Class Initialized
INFO - 2018-10-18 17:03:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 17:03:54 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 17:03:54 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 17:03:54 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 17:03:54 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 17:03:54 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 17:03:54 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 17:03:54 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-18 17:03:54 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 17:03:54 --> Final output sent to browser
DEBUG - 2018-10-18 17:03:54 --> Total execution time: 0.7226
INFO - 2018-10-18 17:03:54 --> Config Class Initialized
INFO - 2018-10-18 17:03:54 --> Hooks Class Initialized
DEBUG - 2018-10-18 17:03:54 --> UTF-8 Support Enabled
INFO - 2018-10-18 17:03:54 --> Utf8 Class Initialized
INFO - 2018-10-18 17:03:54 --> URI Class Initialized
INFO - 2018-10-18 17:03:54 --> Router Class Initialized
INFO - 2018-10-18 17:03:54 --> Output Class Initialized
INFO - 2018-10-18 17:03:55 --> Security Class Initialized
DEBUG - 2018-10-18 17:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 17:03:55 --> CSRF cookie sent
INFO - 2018-10-18 17:03:55 --> Input Class Initialized
INFO - 2018-10-18 17:03:55 --> Language Class Initialized
ERROR - 2018-10-18 17:03:55 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 17:04:07 --> Config Class Initialized
INFO - 2018-10-18 17:04:07 --> Hooks Class Initialized
DEBUG - 2018-10-18 17:04:07 --> UTF-8 Support Enabled
INFO - 2018-10-18 17:04:07 --> Utf8 Class Initialized
INFO - 2018-10-18 17:04:07 --> URI Class Initialized
INFO - 2018-10-18 17:04:07 --> Router Class Initialized
INFO - 2018-10-18 17:04:07 --> Output Class Initialized
INFO - 2018-10-18 17:04:07 --> Security Class Initialized
DEBUG - 2018-10-18 17:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 17:04:07 --> CSRF cookie sent
INFO - 2018-10-18 17:04:07 --> Input Class Initialized
INFO - 2018-10-18 17:04:07 --> Language Class Initialized
INFO - 2018-10-18 17:04:07 --> Loader Class Initialized
INFO - 2018-10-18 17:04:07 --> Helper loaded: url_helper
INFO - 2018-10-18 17:04:07 --> Helper loaded: form_helper
INFO - 2018-10-18 17:04:07 --> Helper loaded: language_helper
DEBUG - 2018-10-18 17:04:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 17:04:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 17:04:07 --> User Agent Class Initialized
INFO - 2018-10-18 17:04:07 --> Controller Class Initialized
INFO - 2018-10-18 17:04:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 17:04:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 17:04:08 --> Pixel_Model class loaded
INFO - 2018-10-18 17:04:08 --> Database Driver Class Initialized
INFO - 2018-10-18 17:04:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 17:04:08 --> Database Driver Class Initialized
INFO - 2018-10-18 17:04:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 17:04:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 17:04:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 17:04:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 17:04:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 17:04:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 17:04:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 17:04:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-18 17:04:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 17:04:08 --> Final output sent to browser
DEBUG - 2018-10-18 17:04:08 --> Total execution time: 0.7134
INFO - 2018-10-18 17:04:08 --> Config Class Initialized
INFO - 2018-10-18 17:04:08 --> Hooks Class Initialized
DEBUG - 2018-10-18 17:04:08 --> UTF-8 Support Enabled
INFO - 2018-10-18 17:04:08 --> Utf8 Class Initialized
INFO - 2018-10-18 17:04:08 --> URI Class Initialized
INFO - 2018-10-18 17:04:08 --> Router Class Initialized
INFO - 2018-10-18 17:04:08 --> Output Class Initialized
INFO - 2018-10-18 17:04:08 --> Security Class Initialized
DEBUG - 2018-10-18 17:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 17:04:08 --> CSRF cookie sent
INFO - 2018-10-18 17:04:08 --> Input Class Initialized
INFO - 2018-10-18 17:04:09 --> Language Class Initialized
ERROR - 2018-10-18 17:04:09 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 17:04:16 --> Config Class Initialized
INFO - 2018-10-18 17:04:16 --> Hooks Class Initialized
DEBUG - 2018-10-18 17:04:16 --> UTF-8 Support Enabled
INFO - 2018-10-18 17:04:16 --> Utf8 Class Initialized
INFO - 2018-10-18 17:04:16 --> URI Class Initialized
INFO - 2018-10-18 17:04:16 --> Router Class Initialized
INFO - 2018-10-18 17:04:16 --> Output Class Initialized
INFO - 2018-10-18 17:04:16 --> Security Class Initialized
DEBUG - 2018-10-18 17:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 17:04:16 --> CSRF cookie sent
INFO - 2018-10-18 17:04:16 --> Input Class Initialized
INFO - 2018-10-18 17:04:16 --> Language Class Initialized
INFO - 2018-10-18 17:04:16 --> Loader Class Initialized
INFO - 2018-10-18 17:04:16 --> Helper loaded: url_helper
INFO - 2018-10-18 17:04:16 --> Helper loaded: form_helper
INFO - 2018-10-18 17:04:16 --> Helper loaded: language_helper
DEBUG - 2018-10-18 17:04:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 17:04:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 17:04:16 --> User Agent Class Initialized
INFO - 2018-10-18 17:04:16 --> Controller Class Initialized
INFO - 2018-10-18 17:04:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 17:04:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 17:04:17 --> Pixel_Model class loaded
INFO - 2018-10-18 17:04:17 --> Database Driver Class Initialized
INFO - 2018-10-18 17:04:17 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 17:04:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 17:04:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 17:04:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 17:04:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 17:04:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 17:04:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 17:04:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-18 17:04:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 17:04:17 --> Final output sent to browser
DEBUG - 2018-10-18 17:04:17 --> Total execution time: 0.6903
INFO - 2018-10-18 17:04:17 --> Config Class Initialized
INFO - 2018-10-18 17:04:17 --> Hooks Class Initialized
DEBUG - 2018-10-18 17:04:17 --> UTF-8 Support Enabled
INFO - 2018-10-18 17:04:17 --> Utf8 Class Initialized
INFO - 2018-10-18 17:04:17 --> URI Class Initialized
INFO - 2018-10-18 17:04:17 --> Router Class Initialized
INFO - 2018-10-18 17:04:17 --> Output Class Initialized
INFO - 2018-10-18 17:04:17 --> Security Class Initialized
DEBUG - 2018-10-18 17:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 17:04:17 --> CSRF cookie sent
INFO - 2018-10-18 17:04:17 --> Input Class Initialized
INFO - 2018-10-18 17:04:17 --> Language Class Initialized
ERROR - 2018-10-18 17:04:17 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 17:04:22 --> Config Class Initialized
INFO - 2018-10-18 17:04:22 --> Hooks Class Initialized
DEBUG - 2018-10-18 17:04:22 --> UTF-8 Support Enabled
INFO - 2018-10-18 17:04:22 --> Utf8 Class Initialized
INFO - 2018-10-18 17:04:22 --> URI Class Initialized
INFO - 2018-10-18 17:04:22 --> Router Class Initialized
INFO - 2018-10-18 17:04:22 --> Output Class Initialized
INFO - 2018-10-18 17:04:22 --> Security Class Initialized
DEBUG - 2018-10-18 17:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 17:04:22 --> CSRF cookie sent
INFO - 2018-10-18 17:04:22 --> CSRF token verified
INFO - 2018-10-18 17:04:22 --> Input Class Initialized
INFO - 2018-10-18 17:04:22 --> Language Class Initialized
INFO - 2018-10-18 17:04:22 --> Loader Class Initialized
INFO - 2018-10-18 17:04:22 --> Helper loaded: url_helper
INFO - 2018-10-18 17:04:22 --> Helper loaded: form_helper
INFO - 2018-10-18 17:04:22 --> Helper loaded: language_helper
DEBUG - 2018-10-18 17:04:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 17:04:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 17:04:22 --> User Agent Class Initialized
INFO - 2018-10-18 17:04:22 --> Controller Class Initialized
INFO - 2018-10-18 17:04:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 17:04:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 17:04:22 --> Pixel_Model class loaded
INFO - 2018-10-18 17:04:22 --> Database Driver Class Initialized
INFO - 2018-10-18 17:04:22 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 17:04:22 --> Form Validation Class Initialized
INFO - 2018-10-18 17:04:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 17:04:22 --> Database Driver Class Initialized
INFO - 2018-10-18 17:04:22 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 17:04:22 --> Config Class Initialized
INFO - 2018-10-18 17:04:22 --> Hooks Class Initialized
DEBUG - 2018-10-18 17:04:22 --> UTF-8 Support Enabled
INFO - 2018-10-18 17:04:22 --> Utf8 Class Initialized
INFO - 2018-10-18 17:04:22 --> URI Class Initialized
INFO - 2018-10-18 17:04:22 --> Router Class Initialized
INFO - 2018-10-18 17:04:22 --> Output Class Initialized
INFO - 2018-10-18 17:04:23 --> Security Class Initialized
DEBUG - 2018-10-18 17:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 17:04:23 --> CSRF cookie sent
INFO - 2018-10-18 17:04:23 --> Input Class Initialized
INFO - 2018-10-18 17:04:23 --> Language Class Initialized
INFO - 2018-10-18 17:04:23 --> Loader Class Initialized
INFO - 2018-10-18 17:04:23 --> Helper loaded: url_helper
INFO - 2018-10-18 17:04:23 --> Helper loaded: form_helper
INFO - 2018-10-18 17:04:23 --> Helper loaded: language_helper
DEBUG - 2018-10-18 17:04:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 17:04:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 17:04:23 --> User Agent Class Initialized
INFO - 2018-10-18 17:04:23 --> Controller Class Initialized
INFO - 2018-10-18 17:04:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 17:04:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 17:04:23 --> Pixel_Model class loaded
INFO - 2018-10-18 17:04:23 --> Database Driver Class Initialized
INFO - 2018-10-18 17:04:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 17:04:23 --> Database Driver Class Initialized
INFO - 2018-10-18 17:04:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 17:04:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 17:04:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 17:04:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 17:04:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 17:04:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 17:04:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 17:04:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-18 17:04:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 17:04:23 --> Final output sent to browser
DEBUG - 2018-10-18 17:04:23 --> Total execution time: 0.7256
INFO - 2018-10-18 17:04:23 --> Config Class Initialized
INFO - 2018-10-18 17:04:23 --> Hooks Class Initialized
DEBUG - 2018-10-18 17:04:23 --> UTF-8 Support Enabled
INFO - 2018-10-18 17:04:23 --> Utf8 Class Initialized
INFO - 2018-10-18 17:04:23 --> URI Class Initialized
INFO - 2018-10-18 17:04:23 --> Router Class Initialized
INFO - 2018-10-18 17:04:24 --> Output Class Initialized
INFO - 2018-10-18 17:04:24 --> Security Class Initialized
DEBUG - 2018-10-18 17:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 17:04:24 --> CSRF cookie sent
INFO - 2018-10-18 17:04:24 --> Input Class Initialized
INFO - 2018-10-18 17:04:24 --> Language Class Initialized
ERROR - 2018-10-18 17:04:24 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 17:04:24 --> Config Class Initialized
INFO - 2018-10-18 17:04:24 --> Hooks Class Initialized
DEBUG - 2018-10-18 17:04:24 --> UTF-8 Support Enabled
INFO - 2018-10-18 17:04:24 --> Utf8 Class Initialized
INFO - 2018-10-18 17:04:24 --> URI Class Initialized
INFO - 2018-10-18 17:04:24 --> Router Class Initialized
INFO - 2018-10-18 17:04:24 --> Output Class Initialized
INFO - 2018-10-18 17:04:24 --> Security Class Initialized
DEBUG - 2018-10-18 17:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 17:04:24 --> CSRF cookie sent
INFO - 2018-10-18 17:04:24 --> Input Class Initialized
INFO - 2018-10-18 17:04:24 --> Language Class Initialized
INFO - 2018-10-18 17:04:24 --> Loader Class Initialized
INFO - 2018-10-18 17:04:24 --> Helper loaded: url_helper
INFO - 2018-10-18 17:04:24 --> Helper loaded: form_helper
INFO - 2018-10-18 17:04:24 --> Helper loaded: language_helper
DEBUG - 2018-10-18 17:04:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 17:04:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 17:04:24 --> User Agent Class Initialized
INFO - 2018-10-18 17:04:24 --> Controller Class Initialized
INFO - 2018-10-18 17:04:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 17:04:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 17:04:24 --> Pixel_Model class loaded
INFO - 2018-10-18 17:04:24 --> Database Driver Class Initialized
INFO - 2018-10-18 17:04:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 17:04:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 17:04:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 17:04:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 17:04:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 17:04:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 17:04:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 17:04:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-18 17:04:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 17:04:25 --> Final output sent to browser
DEBUG - 2018-10-18 17:04:25 --> Total execution time: 0.7083
INFO - 2018-10-18 17:04:25 --> Config Class Initialized
INFO - 2018-10-18 17:04:25 --> Hooks Class Initialized
DEBUG - 2018-10-18 17:04:25 --> UTF-8 Support Enabled
INFO - 2018-10-18 17:04:25 --> Utf8 Class Initialized
INFO - 2018-10-18 17:04:25 --> URI Class Initialized
INFO - 2018-10-18 17:04:25 --> Router Class Initialized
INFO - 2018-10-18 17:04:25 --> Output Class Initialized
INFO - 2018-10-18 17:04:25 --> Security Class Initialized
DEBUG - 2018-10-18 17:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 17:04:25 --> CSRF cookie sent
INFO - 2018-10-18 17:04:25 --> Input Class Initialized
INFO - 2018-10-18 17:04:25 --> Language Class Initialized
ERROR - 2018-10-18 17:04:25 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 17:07:32 --> Config Class Initialized
INFO - 2018-10-18 17:07:32 --> Hooks Class Initialized
DEBUG - 2018-10-18 17:07:32 --> UTF-8 Support Enabled
INFO - 2018-10-18 17:07:32 --> Utf8 Class Initialized
INFO - 2018-10-18 17:07:32 --> URI Class Initialized
INFO - 2018-10-18 17:07:32 --> Router Class Initialized
INFO - 2018-10-18 17:07:32 --> Output Class Initialized
INFO - 2018-10-18 17:07:32 --> Security Class Initialized
DEBUG - 2018-10-18 17:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 17:07:32 --> CSRF cookie sent
INFO - 2018-10-18 17:07:32 --> Input Class Initialized
INFO - 2018-10-18 17:07:32 --> Language Class Initialized
INFO - 2018-10-18 17:07:32 --> Loader Class Initialized
INFO - 2018-10-18 17:07:32 --> Helper loaded: url_helper
INFO - 2018-10-18 17:07:32 --> Helper loaded: form_helper
INFO - 2018-10-18 17:07:32 --> Helper loaded: language_helper
DEBUG - 2018-10-18 17:07:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 17:07:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 17:07:32 --> User Agent Class Initialized
INFO - 2018-10-18 17:07:32 --> Controller Class Initialized
INFO - 2018-10-18 17:07:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 17:07:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 17:07:32 --> Pixel_Model class loaded
INFO - 2018-10-18 17:07:32 --> Database Driver Class Initialized
INFO - 2018-10-18 17:07:32 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 17:07:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 17:07:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 17:07:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 17:07:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 17:07:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 17:07:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 17:07:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-18 17:07:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 17:07:32 --> Final output sent to browser
DEBUG - 2018-10-18 17:07:32 --> Total execution time: 0.6471
INFO - 2018-10-18 17:07:33 --> Config Class Initialized
INFO - 2018-10-18 17:07:33 --> Hooks Class Initialized
DEBUG - 2018-10-18 17:07:33 --> UTF-8 Support Enabled
INFO - 2018-10-18 17:07:33 --> Utf8 Class Initialized
INFO - 2018-10-18 17:07:33 --> URI Class Initialized
INFO - 2018-10-18 17:07:33 --> Router Class Initialized
INFO - 2018-10-18 17:07:33 --> Output Class Initialized
INFO - 2018-10-18 17:07:33 --> Security Class Initialized
DEBUG - 2018-10-18 17:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 17:07:33 --> CSRF cookie sent
INFO - 2018-10-18 17:07:33 --> Input Class Initialized
INFO - 2018-10-18 17:07:33 --> Language Class Initialized
ERROR - 2018-10-18 17:07:33 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 17:07:38 --> Config Class Initialized
INFO - 2018-10-18 17:07:38 --> Hooks Class Initialized
DEBUG - 2018-10-18 17:07:38 --> UTF-8 Support Enabled
INFO - 2018-10-18 17:07:38 --> Utf8 Class Initialized
INFO - 2018-10-18 17:07:38 --> URI Class Initialized
INFO - 2018-10-18 17:07:38 --> Router Class Initialized
INFO - 2018-10-18 17:07:38 --> Output Class Initialized
INFO - 2018-10-18 17:07:38 --> Security Class Initialized
DEBUG - 2018-10-18 17:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 17:07:38 --> CSRF cookie sent
INFO - 2018-10-18 17:07:38 --> CSRF token verified
INFO - 2018-10-18 17:07:38 --> Input Class Initialized
INFO - 2018-10-18 17:07:38 --> Language Class Initialized
INFO - 2018-10-18 17:07:38 --> Loader Class Initialized
INFO - 2018-10-18 17:07:38 --> Helper loaded: url_helper
INFO - 2018-10-18 17:07:38 --> Helper loaded: form_helper
INFO - 2018-10-18 17:07:38 --> Helper loaded: language_helper
DEBUG - 2018-10-18 17:07:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 17:07:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 17:07:38 --> User Agent Class Initialized
INFO - 2018-10-18 17:07:38 --> Controller Class Initialized
INFO - 2018-10-18 17:07:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 17:07:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 17:07:38 --> Pixel_Model class loaded
INFO - 2018-10-18 17:07:38 --> Database Driver Class Initialized
INFO - 2018-10-18 17:07:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 17:07:38 --> Form Validation Class Initialized
INFO - 2018-10-18 17:07:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 17:07:38 --> Database Driver Class Initialized
INFO - 2018-10-18 17:07:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 17:07:38 --> Config Class Initialized
INFO - 2018-10-18 17:07:38 --> Hooks Class Initialized
DEBUG - 2018-10-18 17:07:38 --> UTF-8 Support Enabled
INFO - 2018-10-18 17:07:38 --> Utf8 Class Initialized
INFO - 2018-10-18 17:07:38 --> URI Class Initialized
INFO - 2018-10-18 17:07:39 --> Router Class Initialized
INFO - 2018-10-18 17:07:39 --> Output Class Initialized
INFO - 2018-10-18 17:07:39 --> Security Class Initialized
DEBUG - 2018-10-18 17:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 17:07:39 --> CSRF cookie sent
INFO - 2018-10-18 17:07:39 --> Input Class Initialized
INFO - 2018-10-18 17:07:39 --> Language Class Initialized
INFO - 2018-10-18 17:07:39 --> Loader Class Initialized
INFO - 2018-10-18 17:07:39 --> Helper loaded: url_helper
INFO - 2018-10-18 17:07:39 --> Helper loaded: form_helper
INFO - 2018-10-18 17:07:39 --> Helper loaded: language_helper
DEBUG - 2018-10-18 17:07:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 17:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 17:07:39 --> User Agent Class Initialized
INFO - 2018-10-18 17:07:39 --> Controller Class Initialized
INFO - 2018-10-18 17:07:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 17:07:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 17:07:39 --> Pixel_Model class loaded
INFO - 2018-10-18 17:07:39 --> Database Driver Class Initialized
INFO - 2018-10-18 17:07:39 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 17:08:08 --> Config Class Initialized
INFO - 2018-10-18 17:08:08 --> Hooks Class Initialized
DEBUG - 2018-10-18 17:08:08 --> UTF-8 Support Enabled
INFO - 2018-10-18 17:08:08 --> Utf8 Class Initialized
INFO - 2018-10-18 17:08:08 --> URI Class Initialized
INFO - 2018-10-18 17:08:08 --> Router Class Initialized
INFO - 2018-10-18 17:08:08 --> Output Class Initialized
INFO - 2018-10-18 17:08:08 --> Security Class Initialized
DEBUG - 2018-10-18 17:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 17:08:08 --> CSRF cookie sent
INFO - 2018-10-18 17:08:08 --> Input Class Initialized
INFO - 2018-10-18 17:08:08 --> Language Class Initialized
INFO - 2018-10-18 17:08:08 --> Loader Class Initialized
INFO - 2018-10-18 17:08:08 --> Helper loaded: url_helper
INFO - 2018-10-18 17:08:08 --> Helper loaded: form_helper
INFO - 2018-10-18 17:08:08 --> Helper loaded: language_helper
DEBUG - 2018-10-18 17:08:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 17:08:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 17:08:08 --> User Agent Class Initialized
INFO - 2018-10-18 17:08:08 --> Controller Class Initialized
INFO - 2018-10-18 17:08:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 17:08:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 17:08:09 --> Pixel_Model class loaded
INFO - 2018-10-18 17:08:09 --> Database Driver Class Initialized
INFO - 2018-10-18 17:08:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 17:08:29 --> Config Class Initialized
INFO - 2018-10-18 17:08:29 --> Hooks Class Initialized
DEBUG - 2018-10-18 17:08:29 --> UTF-8 Support Enabled
INFO - 2018-10-18 17:08:29 --> Utf8 Class Initialized
INFO - 2018-10-18 17:08:29 --> URI Class Initialized
INFO - 2018-10-18 17:08:29 --> Router Class Initialized
INFO - 2018-10-18 17:08:29 --> Output Class Initialized
INFO - 2018-10-18 17:08:29 --> Security Class Initialized
DEBUG - 2018-10-18 17:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 17:08:29 --> CSRF cookie sent
INFO - 2018-10-18 17:08:29 --> Input Class Initialized
INFO - 2018-10-18 17:08:29 --> Language Class Initialized
INFO - 2018-10-18 17:08:29 --> Loader Class Initialized
INFO - 2018-10-18 17:08:29 --> Helper loaded: url_helper
INFO - 2018-10-18 17:08:29 --> Helper loaded: form_helper
INFO - 2018-10-18 17:08:30 --> Helper loaded: language_helper
DEBUG - 2018-10-18 17:08:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 17:08:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 17:08:30 --> User Agent Class Initialized
INFO - 2018-10-18 17:08:30 --> Controller Class Initialized
INFO - 2018-10-18 17:08:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 17:08:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 17:08:30 --> Pixel_Model class loaded
INFO - 2018-10-18 17:08:30 --> Database Driver Class Initialized
INFO - 2018-10-18 17:08:30 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 17:08:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 17:08:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 17:08:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 17:08:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 17:08:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 17:08:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 17:08:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-18 17:08:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 17:08:30 --> Final output sent to browser
DEBUG - 2018-10-18 17:08:30 --> Total execution time: 0.6734
INFO - 2018-10-18 17:08:30 --> Config Class Initialized
INFO - 2018-10-18 17:08:30 --> Hooks Class Initialized
DEBUG - 2018-10-18 17:08:30 --> UTF-8 Support Enabled
INFO - 2018-10-18 17:08:30 --> Utf8 Class Initialized
INFO - 2018-10-18 17:08:30 --> URI Class Initialized
INFO - 2018-10-18 17:08:30 --> Router Class Initialized
INFO - 2018-10-18 17:08:30 --> Output Class Initialized
INFO - 2018-10-18 17:08:30 --> Security Class Initialized
DEBUG - 2018-10-18 17:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 17:08:30 --> CSRF cookie sent
INFO - 2018-10-18 17:08:31 --> Input Class Initialized
INFO - 2018-10-18 17:08:31 --> Language Class Initialized
ERROR - 2018-10-18 17:08:31 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 17:08:31 --> Config Class Initialized
INFO - 2018-10-18 17:08:31 --> Hooks Class Initialized
DEBUG - 2018-10-18 17:08:31 --> UTF-8 Support Enabled
INFO - 2018-10-18 17:08:31 --> Utf8 Class Initialized
INFO - 2018-10-18 17:08:31 --> URI Class Initialized
INFO - 2018-10-18 17:08:31 --> Router Class Initialized
INFO - 2018-10-18 17:08:31 --> Output Class Initialized
INFO - 2018-10-18 17:08:31 --> Security Class Initialized
DEBUG - 2018-10-18 17:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 17:08:31 --> CSRF cookie sent
INFO - 2018-10-18 17:08:31 --> Input Class Initialized
INFO - 2018-10-18 17:08:31 --> Language Class Initialized
INFO - 2018-10-18 17:08:31 --> Loader Class Initialized
INFO - 2018-10-18 17:08:31 --> Helper loaded: url_helper
INFO - 2018-10-18 17:08:31 --> Helper loaded: form_helper
INFO - 2018-10-18 17:08:31 --> Helper loaded: language_helper
DEBUG - 2018-10-18 17:08:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 17:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 17:08:31 --> User Agent Class Initialized
INFO - 2018-10-18 17:08:31 --> Controller Class Initialized
INFO - 2018-10-18 17:08:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 17:08:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 17:08:31 --> Pixel_Model class loaded
INFO - 2018-10-18 17:08:31 --> Database Driver Class Initialized
INFO - 2018-10-18 17:08:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:08:45 --> Config Class Initialized
INFO - 2018-10-18 19:08:45 --> Hooks Class Initialized
DEBUG - 2018-10-18 19:08:45 --> UTF-8 Support Enabled
INFO - 2018-10-18 19:08:45 --> Utf8 Class Initialized
INFO - 2018-10-18 19:08:45 --> URI Class Initialized
DEBUG - 2018-10-18 19:08:45 --> No URI present. Default controller set.
INFO - 2018-10-18 19:08:45 --> Router Class Initialized
INFO - 2018-10-18 19:08:45 --> Output Class Initialized
INFO - 2018-10-18 19:08:45 --> Security Class Initialized
DEBUG - 2018-10-18 19:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 19:08:46 --> CSRF cookie sent
INFO - 2018-10-18 19:08:46 --> Input Class Initialized
INFO - 2018-10-18 19:08:46 --> Language Class Initialized
INFO - 2018-10-18 19:08:46 --> Loader Class Initialized
INFO - 2018-10-18 19:08:46 --> Helper loaded: url_helper
INFO - 2018-10-18 19:08:46 --> Helper loaded: form_helper
INFO - 2018-10-18 19:08:46 --> Helper loaded: language_helper
DEBUG - 2018-10-18 19:08:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 19:08:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 19:08:46 --> User Agent Class Initialized
INFO - 2018-10-18 19:08:46 --> Controller Class Initialized
INFO - 2018-10-18 19:08:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 19:08:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 19:08:46 --> Helper loaded: custom_helper
INFO - 2018-10-18 19:08:46 --> Pixel_Model class loaded
INFO - 2018-10-18 19:08:46 --> Database Driver Class Initialized
INFO - 2018-10-18 19:08:46 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:08:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 19:08:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 19:08:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-18 19:08:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 19:08:46 --> Final output sent to browser
DEBUG - 2018-10-18 19:08:46 --> Total execution time: 0.7533
INFO - 2018-10-18 19:08:53 --> Config Class Initialized
INFO - 2018-10-18 19:08:53 --> Hooks Class Initialized
DEBUG - 2018-10-18 19:08:53 --> UTF-8 Support Enabled
INFO - 2018-10-18 19:08:53 --> Utf8 Class Initialized
INFO - 2018-10-18 19:08:53 --> URI Class Initialized
DEBUG - 2018-10-18 19:08:53 --> No URI present. Default controller set.
INFO - 2018-10-18 19:08:53 --> Router Class Initialized
INFO - 2018-10-18 19:08:53 --> Output Class Initialized
INFO - 2018-10-18 19:08:53 --> Security Class Initialized
DEBUG - 2018-10-18 19:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 19:08:53 --> CSRF cookie sent
INFO - 2018-10-18 19:08:53 --> Input Class Initialized
INFO - 2018-10-18 19:08:53 --> Language Class Initialized
INFO - 2018-10-18 19:08:53 --> Loader Class Initialized
INFO - 2018-10-18 19:08:53 --> Helper loaded: url_helper
INFO - 2018-10-18 19:08:53 --> Helper loaded: form_helper
INFO - 2018-10-18 19:08:53 --> Helper loaded: language_helper
DEBUG - 2018-10-18 19:08:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 19:08:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 19:08:53 --> User Agent Class Initialized
INFO - 2018-10-18 19:08:53 --> Controller Class Initialized
INFO - 2018-10-18 19:08:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 19:08:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 19:08:53 --> Helper loaded: custom_helper
INFO - 2018-10-18 19:08:53 --> Pixel_Model class loaded
INFO - 2018-10-18 19:08:53 --> Database Driver Class Initialized
INFO - 2018-10-18 19:08:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:08:54 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 19:08:54 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 19:08:54 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-18 19:08:54 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 19:08:54 --> Final output sent to browser
DEBUG - 2018-10-18 19:08:54 --> Total execution time: 0.6253
INFO - 2018-10-18 19:11:45 --> Config Class Initialized
INFO - 2018-10-18 19:11:45 --> Hooks Class Initialized
DEBUG - 2018-10-18 19:11:45 --> UTF-8 Support Enabled
INFO - 2018-10-18 19:11:45 --> Utf8 Class Initialized
INFO - 2018-10-18 19:11:45 --> URI Class Initialized
INFO - 2018-10-18 19:11:45 --> Router Class Initialized
INFO - 2018-10-18 19:11:45 --> Output Class Initialized
INFO - 2018-10-18 19:11:45 --> Security Class Initialized
DEBUG - 2018-10-18 19:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 19:11:45 --> CSRF cookie sent
INFO - 2018-10-18 19:11:45 --> Input Class Initialized
INFO - 2018-10-18 19:11:45 --> Language Class Initialized
INFO - 2018-10-18 19:11:45 --> Loader Class Initialized
INFO - 2018-10-18 19:11:45 --> Helper loaded: url_helper
INFO - 2018-10-18 19:11:45 --> Helper loaded: form_helper
INFO - 2018-10-18 19:11:45 --> Helper loaded: language_helper
DEBUG - 2018-10-18 19:11:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 19:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 19:11:45 --> User Agent Class Initialized
INFO - 2018-10-18 19:11:45 --> Controller Class Initialized
INFO - 2018-10-18 19:11:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 19:11:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 19:11:45 --> Helper loaded: custom_helper
INFO - 2018-10-18 19:11:45 --> Pixel_Model class loaded
INFO - 2018-10-18 19:11:45 --> Database Driver Class Initialized
INFO - 2018-10-18 19:11:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:11:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 19:11:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 19:11:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 19:11:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 19:11:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 19:11:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 19:11:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-18 19:11:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 19:11:46 --> Final output sent to browser
DEBUG - 2018-10-18 19:11:46 --> Total execution time: 0.7151
INFO - 2018-10-18 19:11:48 --> Config Class Initialized
INFO - 2018-10-18 19:11:49 --> Hooks Class Initialized
DEBUG - 2018-10-18 19:11:49 --> UTF-8 Support Enabled
INFO - 2018-10-18 19:11:49 --> Utf8 Class Initialized
INFO - 2018-10-18 19:11:49 --> URI Class Initialized
INFO - 2018-10-18 19:11:49 --> Router Class Initialized
INFO - 2018-10-18 19:11:49 --> Output Class Initialized
INFO - 2018-10-18 19:11:49 --> Security Class Initialized
DEBUG - 2018-10-18 19:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 19:11:49 --> CSRF cookie sent
INFO - 2018-10-18 19:11:49 --> CSRF token verified
INFO - 2018-10-18 19:11:49 --> Input Class Initialized
INFO - 2018-10-18 19:11:49 --> Language Class Initialized
INFO - 2018-10-18 19:11:49 --> Loader Class Initialized
INFO - 2018-10-18 19:11:49 --> Helper loaded: url_helper
INFO - 2018-10-18 19:11:49 --> Helper loaded: form_helper
INFO - 2018-10-18 19:11:49 --> Helper loaded: language_helper
DEBUG - 2018-10-18 19:11:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 19:11:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 19:11:49 --> User Agent Class Initialized
INFO - 2018-10-18 19:11:49 --> Controller Class Initialized
INFO - 2018-10-18 19:11:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 19:11:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 19:11:49 --> Helper loaded: custom_helper
INFO - 2018-10-18 19:11:49 --> Pixel_Model class loaded
INFO - 2018-10-18 19:11:49 --> Database Driver Class Initialized
INFO - 2018-10-18 19:11:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:11:49 --> Form Validation Class Initialized
INFO - 2018-10-18 19:11:49 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-10-18 19:11:49 --> Severity: error --> Exception: Call to a member function get_decision() on null E:\xampp7\htdocs\famiquity\application\controllers\QuestionnaireController.php 79
INFO - 2018-10-18 19:12:05 --> Config Class Initialized
INFO - 2018-10-18 19:12:05 --> Hooks Class Initialized
DEBUG - 2018-10-18 19:12:05 --> UTF-8 Support Enabled
INFO - 2018-10-18 19:12:05 --> Utf8 Class Initialized
INFO - 2018-10-18 19:12:05 --> URI Class Initialized
INFO - 2018-10-18 19:12:05 --> Router Class Initialized
INFO - 2018-10-18 19:12:05 --> Output Class Initialized
INFO - 2018-10-18 19:12:05 --> Security Class Initialized
DEBUG - 2018-10-18 19:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 19:12:05 --> CSRF cookie sent
INFO - 2018-10-18 19:12:05 --> Input Class Initialized
INFO - 2018-10-18 19:12:05 --> Language Class Initialized
INFO - 2018-10-18 19:12:06 --> Loader Class Initialized
INFO - 2018-10-18 19:12:06 --> Helper loaded: url_helper
INFO - 2018-10-18 19:12:06 --> Helper loaded: form_helper
INFO - 2018-10-18 19:12:06 --> Helper loaded: language_helper
DEBUG - 2018-10-18 19:12:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 19:12:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 19:12:06 --> User Agent Class Initialized
INFO - 2018-10-18 19:12:06 --> Controller Class Initialized
INFO - 2018-10-18 19:12:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 19:12:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 19:12:06 --> Helper loaded: custom_helper
INFO - 2018-10-18 19:12:06 --> Pixel_Model class loaded
INFO - 2018-10-18 19:12:06 --> Database Driver Class Initialized
INFO - 2018-10-18 19:12:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:12:06 --> Form Validation Class Initialized
INFO - 2018-10-18 19:12:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 19:12:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 19:12:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 19:12:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 19:12:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 19:12:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 19:12:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-18 19:12:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 19:12:06 --> Final output sent to browser
DEBUG - 2018-10-18 19:12:06 --> Total execution time: 0.6922
INFO - 2018-10-18 19:12:07 --> Config Class Initialized
INFO - 2018-10-18 19:12:07 --> Hooks Class Initialized
DEBUG - 2018-10-18 19:12:07 --> UTF-8 Support Enabled
INFO - 2018-10-18 19:12:07 --> Utf8 Class Initialized
INFO - 2018-10-18 19:12:07 --> URI Class Initialized
INFO - 2018-10-18 19:12:07 --> Router Class Initialized
INFO - 2018-10-18 19:12:07 --> Output Class Initialized
INFO - 2018-10-18 19:12:07 --> Security Class Initialized
DEBUG - 2018-10-18 19:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 19:12:07 --> CSRF cookie sent
INFO - 2018-10-18 19:12:07 --> Input Class Initialized
INFO - 2018-10-18 19:12:07 --> Language Class Initialized
ERROR - 2018-10-18 19:12:07 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 19:12:10 --> Config Class Initialized
INFO - 2018-10-18 19:12:10 --> Hooks Class Initialized
DEBUG - 2018-10-18 19:12:10 --> UTF-8 Support Enabled
INFO - 2018-10-18 19:12:10 --> Utf8 Class Initialized
INFO - 2018-10-18 19:12:10 --> URI Class Initialized
INFO - 2018-10-18 19:12:10 --> Router Class Initialized
INFO - 2018-10-18 19:12:10 --> Output Class Initialized
INFO - 2018-10-18 19:12:10 --> Security Class Initialized
DEBUG - 2018-10-18 19:12:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 19:12:10 --> CSRF cookie sent
INFO - 2018-10-18 19:12:10 --> CSRF token verified
INFO - 2018-10-18 19:12:10 --> Input Class Initialized
INFO - 2018-10-18 19:12:10 --> Language Class Initialized
INFO - 2018-10-18 19:12:10 --> Loader Class Initialized
INFO - 2018-10-18 19:12:10 --> Helper loaded: url_helper
INFO - 2018-10-18 19:12:10 --> Helper loaded: form_helper
INFO - 2018-10-18 19:12:10 --> Helper loaded: language_helper
DEBUG - 2018-10-18 19:12:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 19:12:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 19:12:10 --> User Agent Class Initialized
INFO - 2018-10-18 19:12:10 --> Controller Class Initialized
INFO - 2018-10-18 19:12:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 19:12:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 19:12:10 --> Helper loaded: custom_helper
INFO - 2018-10-18 19:12:10 --> Pixel_Model class loaded
INFO - 2018-10-18 19:12:10 --> Database Driver Class Initialized
INFO - 2018-10-18 19:12:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:12:10 --> Form Validation Class Initialized
INFO - 2018-10-18 19:12:10 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-10-18 19:12:10 --> Severity: Notice --> Trying to get property 'id' of non-object E:\xampp7\htdocs\famiquity\application\controllers\QuestionnaireController.php 76
ERROR - 2018-10-18 19:12:10 --> Severity: Notice --> Undefined property: QuestionnaireController::$QuestionsModel E:\xampp7\htdocs\famiquity\application\controllers\QuestionnaireController.php 79
ERROR - 2018-10-18 19:12:10 --> Severity: error --> Exception: Call to a member function get_decision() on null E:\xampp7\htdocs\famiquity\application\controllers\QuestionnaireController.php 79
INFO - 2018-10-18 19:12:32 --> Config Class Initialized
INFO - 2018-10-18 19:12:32 --> Hooks Class Initialized
DEBUG - 2018-10-18 19:12:32 --> UTF-8 Support Enabled
INFO - 2018-10-18 19:12:32 --> Utf8 Class Initialized
INFO - 2018-10-18 19:12:32 --> URI Class Initialized
INFO - 2018-10-18 19:12:32 --> Router Class Initialized
INFO - 2018-10-18 19:12:32 --> Output Class Initialized
INFO - 2018-10-18 19:12:33 --> Security Class Initialized
DEBUG - 2018-10-18 19:12:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 19:12:33 --> CSRF cookie sent
INFO - 2018-10-18 19:12:33 --> CSRF token verified
INFO - 2018-10-18 19:12:33 --> Input Class Initialized
INFO - 2018-10-18 19:12:33 --> Language Class Initialized
INFO - 2018-10-18 19:12:33 --> Loader Class Initialized
INFO - 2018-10-18 19:12:33 --> Helper loaded: url_helper
INFO - 2018-10-18 19:12:33 --> Helper loaded: form_helper
INFO - 2018-10-18 19:12:33 --> Helper loaded: language_helper
DEBUG - 2018-10-18 19:12:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 19:12:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 19:12:33 --> User Agent Class Initialized
INFO - 2018-10-18 19:12:33 --> Controller Class Initialized
INFO - 2018-10-18 19:12:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 19:12:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 19:12:33 --> Helper loaded: custom_helper
INFO - 2018-10-18 19:12:33 --> Pixel_Model class loaded
INFO - 2018-10-18 19:12:33 --> Database Driver Class Initialized
INFO - 2018-10-18 19:12:33 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:12:33 --> Form Validation Class Initialized
INFO - 2018-10-18 19:12:33 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-10-18 19:12:33 --> Severity: Notice --> Trying to get property 'id' of non-object E:\xampp7\htdocs\famiquity\application\controllers\QuestionnaireController.php 76
ERROR - 2018-10-18 19:12:33 --> Severity: Notice --> Undefined property: QuestionnaireController::$QuestionsModel E:\xampp7\htdocs\famiquity\application\controllers\QuestionnaireController.php 79
ERROR - 2018-10-18 19:12:33 --> Severity: error --> Exception: Call to a member function get_decision() on null E:\xampp7\htdocs\famiquity\application\controllers\QuestionnaireController.php 79
INFO - 2018-10-18 19:12:56 --> Config Class Initialized
INFO - 2018-10-18 19:12:56 --> Hooks Class Initialized
DEBUG - 2018-10-18 19:12:56 --> UTF-8 Support Enabled
INFO - 2018-10-18 19:12:56 --> Utf8 Class Initialized
INFO - 2018-10-18 19:12:56 --> URI Class Initialized
INFO - 2018-10-18 19:12:56 --> Router Class Initialized
INFO - 2018-10-18 19:12:56 --> Output Class Initialized
INFO - 2018-10-18 19:12:56 --> Security Class Initialized
DEBUG - 2018-10-18 19:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 19:12:56 --> CSRF cookie sent
INFO - 2018-10-18 19:12:56 --> CSRF token verified
INFO - 2018-10-18 19:12:56 --> Input Class Initialized
INFO - 2018-10-18 19:12:56 --> Language Class Initialized
INFO - 2018-10-18 19:12:56 --> Loader Class Initialized
INFO - 2018-10-18 19:12:56 --> Helper loaded: url_helper
INFO - 2018-10-18 19:12:56 --> Helper loaded: form_helper
INFO - 2018-10-18 19:12:56 --> Helper loaded: language_helper
DEBUG - 2018-10-18 19:12:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 19:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 19:12:56 --> User Agent Class Initialized
INFO - 2018-10-18 19:12:56 --> Controller Class Initialized
INFO - 2018-10-18 19:12:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 19:12:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 19:12:56 --> Helper loaded: custom_helper
INFO - 2018-10-18 19:12:56 --> Pixel_Model class loaded
INFO - 2018-10-18 19:12:56 --> Database Driver Class Initialized
INFO - 2018-10-18 19:12:56 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:12:56 --> Form Validation Class Initialized
INFO - 2018-10-18 19:12:56 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-10-18 19:12:56 --> Severity: Notice --> Trying to get property 'id' of non-object E:\xampp7\htdocs\famiquity\application\controllers\QuestionnaireController.php 76
ERROR - 2018-10-18 19:12:56 --> Severity: Notice --> Undefined property: QuestionnaireController::$QuestionsModel E:\xampp7\htdocs\famiquity\application\controllers\QuestionnaireController.php 80
ERROR - 2018-10-18 19:12:56 --> Severity: error --> Exception: Call to a member function get_decision() on null E:\xampp7\htdocs\famiquity\application\controllers\QuestionnaireController.php 80
INFO - 2018-10-18 19:13:19 --> Config Class Initialized
INFO - 2018-10-18 19:13:20 --> Hooks Class Initialized
DEBUG - 2018-10-18 19:13:20 --> UTF-8 Support Enabled
INFO - 2018-10-18 19:13:20 --> Utf8 Class Initialized
INFO - 2018-10-18 19:13:20 --> URI Class Initialized
INFO - 2018-10-18 19:13:20 --> Router Class Initialized
INFO - 2018-10-18 19:13:20 --> Output Class Initialized
INFO - 2018-10-18 19:13:20 --> Security Class Initialized
DEBUG - 2018-10-18 19:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 19:13:20 --> CSRF cookie sent
INFO - 2018-10-18 19:13:20 --> CSRF token verified
INFO - 2018-10-18 19:13:20 --> Input Class Initialized
INFO - 2018-10-18 19:13:20 --> Language Class Initialized
INFO - 2018-10-18 19:13:20 --> Loader Class Initialized
INFO - 2018-10-18 19:13:20 --> Helper loaded: url_helper
INFO - 2018-10-18 19:13:20 --> Helper loaded: form_helper
INFO - 2018-10-18 19:13:20 --> Helper loaded: language_helper
DEBUG - 2018-10-18 19:13:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 19:13:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 19:13:20 --> User Agent Class Initialized
INFO - 2018-10-18 19:13:20 --> Controller Class Initialized
INFO - 2018-10-18 19:13:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 19:13:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 19:13:20 --> Helper loaded: custom_helper
INFO - 2018-10-18 19:13:20 --> Pixel_Model class loaded
INFO - 2018-10-18 19:13:20 --> Database Driver Class Initialized
INFO - 2018-10-18 19:13:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:13:20 --> Form Validation Class Initialized
INFO - 2018-10-18 19:13:20 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-10-18 19:13:20 --> Severity: Notice --> Trying to get property 'id' of non-object E:\xampp7\htdocs\famiquity\application\controllers\QuestionnaireController.php 76
INFO - 2018-10-18 19:13:29 --> Config Class Initialized
INFO - 2018-10-18 19:13:29 --> Hooks Class Initialized
DEBUG - 2018-10-18 19:13:29 --> UTF-8 Support Enabled
INFO - 2018-10-18 19:13:29 --> Utf8 Class Initialized
INFO - 2018-10-18 19:13:29 --> URI Class Initialized
INFO - 2018-10-18 19:13:29 --> Router Class Initialized
INFO - 2018-10-18 19:13:29 --> Output Class Initialized
INFO - 2018-10-18 19:13:29 --> Security Class Initialized
DEBUG - 2018-10-18 19:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 19:13:29 --> CSRF cookie sent
INFO - 2018-10-18 19:13:29 --> Input Class Initialized
INFO - 2018-10-18 19:13:29 --> Language Class Initialized
INFO - 2018-10-18 19:13:29 --> Loader Class Initialized
INFO - 2018-10-18 19:13:29 --> Helper loaded: url_helper
INFO - 2018-10-18 19:13:29 --> Helper loaded: form_helper
INFO - 2018-10-18 19:13:29 --> Helper loaded: language_helper
DEBUG - 2018-10-18 19:13:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 19:13:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 19:13:29 --> User Agent Class Initialized
INFO - 2018-10-18 19:13:29 --> Controller Class Initialized
INFO - 2018-10-18 19:13:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 19:13:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 19:13:29 --> Helper loaded: custom_helper
INFO - 2018-10-18 19:13:29 --> Pixel_Model class loaded
INFO - 2018-10-18 19:13:29 --> Database Driver Class Initialized
INFO - 2018-10-18 19:13:29 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:13:29 --> Form Validation Class Initialized
INFO - 2018-10-18 19:13:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 19:13:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 19:13:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 19:13:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 19:13:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 19:13:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 19:13:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-18 19:13:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 19:13:29 --> Final output sent to browser
DEBUG - 2018-10-18 19:13:30 --> Total execution time: 0.7423
INFO - 2018-10-18 19:13:30 --> Config Class Initialized
INFO - 2018-10-18 19:13:30 --> Hooks Class Initialized
DEBUG - 2018-10-18 19:13:30 --> UTF-8 Support Enabled
INFO - 2018-10-18 19:13:30 --> Utf8 Class Initialized
INFO - 2018-10-18 19:13:31 --> URI Class Initialized
INFO - 2018-10-18 19:13:31 --> Router Class Initialized
INFO - 2018-10-18 19:13:31 --> Output Class Initialized
INFO - 2018-10-18 19:13:31 --> Security Class Initialized
DEBUG - 2018-10-18 19:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 19:13:31 --> CSRF cookie sent
INFO - 2018-10-18 19:13:31 --> Input Class Initialized
INFO - 2018-10-18 19:13:31 --> Language Class Initialized
INFO - 2018-10-18 19:13:31 --> Loader Class Initialized
INFO - 2018-10-18 19:13:31 --> Helper loaded: url_helper
INFO - 2018-10-18 19:13:31 --> Helper loaded: form_helper
INFO - 2018-10-18 19:13:31 --> Helper loaded: language_helper
DEBUG - 2018-10-18 19:13:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 19:13:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 19:13:31 --> User Agent Class Initialized
INFO - 2018-10-18 19:13:31 --> Controller Class Initialized
INFO - 2018-10-18 19:13:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 19:13:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 19:13:31 --> Helper loaded: custom_helper
INFO - 2018-10-18 19:13:31 --> Pixel_Model class loaded
INFO - 2018-10-18 19:13:31 --> Database Driver Class Initialized
INFO - 2018-10-18 19:13:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:13:31 --> Form Validation Class Initialized
INFO - 2018-10-18 19:13:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 19:13:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 19:13:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 19:13:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 19:13:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 19:13:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 19:13:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-18 19:13:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 19:13:31 --> Final output sent to browser
DEBUG - 2018-10-18 19:13:31 --> Total execution time: 0.7521
INFO - 2018-10-18 19:13:33 --> Config Class Initialized
INFO - 2018-10-18 19:13:33 --> Hooks Class Initialized
DEBUG - 2018-10-18 19:13:33 --> UTF-8 Support Enabled
INFO - 2018-10-18 19:13:33 --> Utf8 Class Initialized
INFO - 2018-10-18 19:13:33 --> URI Class Initialized
INFO - 2018-10-18 19:13:33 --> Router Class Initialized
INFO - 2018-10-18 19:13:33 --> Output Class Initialized
INFO - 2018-10-18 19:13:33 --> Security Class Initialized
DEBUG - 2018-10-18 19:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 19:13:33 --> CSRF cookie sent
INFO - 2018-10-18 19:13:33 --> CSRF token verified
INFO - 2018-10-18 19:13:33 --> Input Class Initialized
INFO - 2018-10-18 19:13:33 --> Language Class Initialized
INFO - 2018-10-18 19:13:33 --> Loader Class Initialized
INFO - 2018-10-18 19:13:33 --> Helper loaded: url_helper
INFO - 2018-10-18 19:13:33 --> Helper loaded: form_helper
INFO - 2018-10-18 19:13:33 --> Helper loaded: language_helper
DEBUG - 2018-10-18 19:13:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 19:13:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 19:13:33 --> User Agent Class Initialized
INFO - 2018-10-18 19:13:33 --> Controller Class Initialized
INFO - 2018-10-18 19:13:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 19:13:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 19:13:33 --> Helper loaded: custom_helper
INFO - 2018-10-18 19:13:33 --> Pixel_Model class loaded
INFO - 2018-10-18 19:13:34 --> Database Driver Class Initialized
INFO - 2018-10-18 19:13:34 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:13:34 --> Form Validation Class Initialized
INFO - 2018-10-18 19:13:34 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-10-18 19:13:34 --> Severity: Notice --> Trying to get property 'id' of non-object E:\xampp7\htdocs\famiquity\application\controllers\QuestionnaireController.php 76
INFO - 2018-10-18 19:13:52 --> Config Class Initialized
INFO - 2018-10-18 19:13:52 --> Hooks Class Initialized
DEBUG - 2018-10-18 19:13:52 --> UTF-8 Support Enabled
INFO - 2018-10-18 19:13:52 --> Utf8 Class Initialized
INFO - 2018-10-18 19:13:52 --> URI Class Initialized
INFO - 2018-10-18 19:13:52 --> Router Class Initialized
INFO - 2018-10-18 19:13:52 --> Output Class Initialized
INFO - 2018-10-18 19:13:52 --> Security Class Initialized
DEBUG - 2018-10-18 19:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 19:13:52 --> CSRF cookie sent
INFO - 2018-10-18 19:13:52 --> CSRF token verified
INFO - 2018-10-18 19:13:52 --> Input Class Initialized
INFO - 2018-10-18 19:13:52 --> Language Class Initialized
INFO - 2018-10-18 19:13:52 --> Loader Class Initialized
INFO - 2018-10-18 19:13:52 --> Helper loaded: url_helper
INFO - 2018-10-18 19:13:52 --> Helper loaded: form_helper
INFO - 2018-10-18 19:13:52 --> Helper loaded: language_helper
DEBUG - 2018-10-18 19:13:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 19:13:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 19:13:52 --> User Agent Class Initialized
INFO - 2018-10-18 19:13:52 --> Controller Class Initialized
INFO - 2018-10-18 19:13:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 19:13:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 19:13:52 --> Helper loaded: custom_helper
INFO - 2018-10-18 19:13:52 --> Pixel_Model class loaded
INFO - 2018-10-18 19:13:52 --> Database Driver Class Initialized
INFO - 2018-10-18 19:13:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:13:52 --> Form Validation Class Initialized
INFO - 2018-10-18 19:13:52 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-10-18 19:13:52 --> Severity: Notice --> Trying to get property 'id' of non-object E:\xampp7\htdocs\famiquity\application\controllers\QuestionnaireController.php 76
ERROR - 2018-10-18 19:13:52 --> Severity: Notice --> Trying to get property 'name' of non-object E:\xampp7\htdocs\famiquity\application\controllers\QuestionnaireController.php 81
INFO - 2018-10-18 19:14:00 --> Config Class Initialized
INFO - 2018-10-18 19:14:00 --> Hooks Class Initialized
DEBUG - 2018-10-18 19:14:01 --> UTF-8 Support Enabled
INFO - 2018-10-18 19:14:01 --> Utf8 Class Initialized
INFO - 2018-10-18 19:14:01 --> URI Class Initialized
INFO - 2018-10-18 19:14:01 --> Router Class Initialized
INFO - 2018-10-18 19:14:01 --> Output Class Initialized
INFO - 2018-10-18 19:14:01 --> Security Class Initialized
DEBUG - 2018-10-18 19:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 19:14:01 --> CSRF cookie sent
INFO - 2018-10-18 19:14:01 --> CSRF token verified
INFO - 2018-10-18 19:14:01 --> Input Class Initialized
INFO - 2018-10-18 19:14:01 --> Language Class Initialized
INFO - 2018-10-18 19:14:01 --> Loader Class Initialized
INFO - 2018-10-18 19:14:01 --> Helper loaded: url_helper
INFO - 2018-10-18 19:14:01 --> Helper loaded: form_helper
INFO - 2018-10-18 19:14:01 --> Helper loaded: language_helper
DEBUG - 2018-10-18 19:14:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 19:14:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 19:14:01 --> User Agent Class Initialized
INFO - 2018-10-18 19:14:01 --> Controller Class Initialized
INFO - 2018-10-18 19:14:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 19:14:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 19:14:01 --> Helper loaded: custom_helper
INFO - 2018-10-18 19:14:01 --> Pixel_Model class loaded
INFO - 2018-10-18 19:14:01 --> Database Driver Class Initialized
INFO - 2018-10-18 19:14:01 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:14:01 --> Form Validation Class Initialized
INFO - 2018-10-18 19:14:01 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-10-18 19:14:01 --> Severity: Notice --> Trying to get property 'id' of non-object E:\xampp7\htdocs\famiquity\application\controllers\QuestionnaireController.php 76
INFO - 2018-10-18 19:14:16 --> Config Class Initialized
INFO - 2018-10-18 19:14:16 --> Hooks Class Initialized
DEBUG - 2018-10-18 19:14:16 --> UTF-8 Support Enabled
INFO - 2018-10-18 19:14:16 --> Utf8 Class Initialized
INFO - 2018-10-18 19:14:16 --> URI Class Initialized
INFO - 2018-10-18 19:14:16 --> Router Class Initialized
INFO - 2018-10-18 19:14:16 --> Output Class Initialized
INFO - 2018-10-18 19:14:16 --> Security Class Initialized
DEBUG - 2018-10-18 19:14:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 19:14:16 --> CSRF cookie sent
INFO - 2018-10-18 19:14:16 --> CSRF token verified
INFO - 2018-10-18 19:14:16 --> Input Class Initialized
INFO - 2018-10-18 19:14:16 --> Language Class Initialized
INFO - 2018-10-18 19:14:16 --> Loader Class Initialized
INFO - 2018-10-18 19:14:16 --> Helper loaded: url_helper
INFO - 2018-10-18 19:14:16 --> Helper loaded: form_helper
INFO - 2018-10-18 19:14:16 --> Helper loaded: language_helper
DEBUG - 2018-10-18 19:14:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 19:14:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 19:14:16 --> User Agent Class Initialized
INFO - 2018-10-18 19:14:16 --> Controller Class Initialized
INFO - 2018-10-18 19:14:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 19:14:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 19:14:16 --> Helper loaded: custom_helper
INFO - 2018-10-18 19:14:16 --> Pixel_Model class loaded
INFO - 2018-10-18 19:14:16 --> Database Driver Class Initialized
INFO - 2018-10-18 19:14:16 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:14:16 --> Form Validation Class Initialized
INFO - 2018-10-18 19:14:16 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-10-18 19:14:16 --> Severity: Notice --> Trying to get property 'id' of non-object E:\xampp7\htdocs\famiquity\application\controllers\QuestionnaireController.php 76
INFO - 2018-10-18 19:14:25 --> Config Class Initialized
INFO - 2018-10-18 19:14:25 --> Hooks Class Initialized
DEBUG - 2018-10-18 19:14:25 --> UTF-8 Support Enabled
INFO - 2018-10-18 19:14:25 --> Utf8 Class Initialized
INFO - 2018-10-18 19:14:25 --> URI Class Initialized
INFO - 2018-10-18 19:14:25 --> Router Class Initialized
INFO - 2018-10-18 19:14:25 --> Output Class Initialized
INFO - 2018-10-18 19:14:25 --> Security Class Initialized
DEBUG - 2018-10-18 19:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 19:14:25 --> CSRF cookie sent
INFO - 2018-10-18 19:14:25 --> CSRF token verified
INFO - 2018-10-18 19:14:25 --> Input Class Initialized
INFO - 2018-10-18 19:14:25 --> Language Class Initialized
INFO - 2018-10-18 19:14:25 --> Loader Class Initialized
INFO - 2018-10-18 19:14:25 --> Helper loaded: url_helper
INFO - 2018-10-18 19:14:25 --> Helper loaded: form_helper
INFO - 2018-10-18 19:14:25 --> Helper loaded: language_helper
DEBUG - 2018-10-18 19:14:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 19:14:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 19:14:25 --> User Agent Class Initialized
INFO - 2018-10-18 19:14:25 --> Controller Class Initialized
INFO - 2018-10-18 19:14:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 19:14:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 19:14:25 --> Helper loaded: custom_helper
INFO - 2018-10-18 19:14:25 --> Pixel_Model class loaded
INFO - 2018-10-18 19:14:25 --> Database Driver Class Initialized
INFO - 2018-10-18 19:14:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:14:25 --> Form Validation Class Initialized
INFO - 2018-10-18 19:14:25 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-10-18 19:14:25 --> Severity: Notice --> Trying to get property 'id' of non-object E:\xampp7\htdocs\famiquity\application\controllers\QuestionnaireController.php 76
INFO - 2018-10-18 19:14:36 --> Config Class Initialized
INFO - 2018-10-18 19:14:36 --> Hooks Class Initialized
DEBUG - 2018-10-18 19:14:36 --> UTF-8 Support Enabled
INFO - 2018-10-18 19:14:36 --> Utf8 Class Initialized
INFO - 2018-10-18 19:14:37 --> URI Class Initialized
INFO - 2018-10-18 19:14:37 --> Router Class Initialized
INFO - 2018-10-18 19:14:37 --> Output Class Initialized
INFO - 2018-10-18 19:14:37 --> Security Class Initialized
DEBUG - 2018-10-18 19:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 19:14:37 --> CSRF cookie sent
INFO - 2018-10-18 19:14:37 --> CSRF token verified
INFO - 2018-10-18 19:14:37 --> Input Class Initialized
INFO - 2018-10-18 19:14:37 --> Language Class Initialized
INFO - 2018-10-18 19:14:37 --> Loader Class Initialized
INFO - 2018-10-18 19:14:37 --> Helper loaded: url_helper
INFO - 2018-10-18 19:14:37 --> Helper loaded: form_helper
INFO - 2018-10-18 19:14:37 --> Helper loaded: language_helper
DEBUG - 2018-10-18 19:14:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 19:14:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 19:14:37 --> User Agent Class Initialized
INFO - 2018-10-18 19:14:37 --> Controller Class Initialized
INFO - 2018-10-18 19:14:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 19:14:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 19:14:37 --> Helper loaded: custom_helper
INFO - 2018-10-18 19:14:37 --> Pixel_Model class loaded
INFO - 2018-10-18 19:14:37 --> Database Driver Class Initialized
INFO - 2018-10-18 19:14:37 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:14:37 --> Form Validation Class Initialized
INFO - 2018-10-18 19:14:37 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-10-18 19:14:37 --> Severity: Notice --> Trying to get property 'id' of non-object E:\xampp7\htdocs\famiquity\application\controllers\QuestionnaireController.php 76
INFO - 2018-10-18 19:14:44 --> Config Class Initialized
INFO - 2018-10-18 19:14:44 --> Hooks Class Initialized
DEBUG - 2018-10-18 19:14:44 --> UTF-8 Support Enabled
INFO - 2018-10-18 19:14:44 --> Utf8 Class Initialized
INFO - 2018-10-18 19:14:44 --> URI Class Initialized
INFO - 2018-10-18 19:14:44 --> Router Class Initialized
INFO - 2018-10-18 19:14:44 --> Output Class Initialized
INFO - 2018-10-18 19:14:44 --> Security Class Initialized
DEBUG - 2018-10-18 19:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 19:14:44 --> CSRF cookie sent
INFO - 2018-10-18 19:14:44 --> CSRF token verified
INFO - 2018-10-18 19:14:44 --> Input Class Initialized
INFO - 2018-10-18 19:14:44 --> Language Class Initialized
INFO - 2018-10-18 19:14:44 --> Loader Class Initialized
INFO - 2018-10-18 19:14:44 --> Helper loaded: url_helper
INFO - 2018-10-18 19:14:44 --> Helper loaded: form_helper
INFO - 2018-10-18 19:14:44 --> Helper loaded: language_helper
DEBUG - 2018-10-18 19:14:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 19:14:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 19:14:44 --> User Agent Class Initialized
INFO - 2018-10-18 19:14:44 --> Controller Class Initialized
INFO - 2018-10-18 19:14:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 19:14:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 19:14:45 --> Helper loaded: custom_helper
INFO - 2018-10-18 19:14:45 --> Pixel_Model class loaded
INFO - 2018-10-18 19:14:45 --> Database Driver Class Initialized
INFO - 2018-10-18 19:14:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:14:45 --> Form Validation Class Initialized
INFO - 2018-10-18 19:14:45 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-10-18 19:14:45 --> Severity: Notice --> Trying to get property 'id' of non-object E:\xampp7\htdocs\famiquity\application\controllers\QuestionnaireController.php 76
INFO - 2018-10-18 19:16:03 --> Config Class Initialized
INFO - 2018-10-18 19:16:03 --> Hooks Class Initialized
DEBUG - 2018-10-18 19:16:03 --> UTF-8 Support Enabled
INFO - 2018-10-18 19:16:03 --> Utf8 Class Initialized
INFO - 2018-10-18 19:16:03 --> URI Class Initialized
INFO - 2018-10-18 19:16:03 --> Router Class Initialized
INFO - 2018-10-18 19:16:03 --> Output Class Initialized
INFO - 2018-10-18 19:16:03 --> Security Class Initialized
DEBUG - 2018-10-18 19:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 19:16:03 --> CSRF cookie sent
INFO - 2018-10-18 19:16:03 --> CSRF token verified
INFO - 2018-10-18 19:16:03 --> Input Class Initialized
INFO - 2018-10-18 19:16:03 --> Language Class Initialized
INFO - 2018-10-18 19:16:03 --> Loader Class Initialized
INFO - 2018-10-18 19:16:03 --> Helper loaded: url_helper
INFO - 2018-10-18 19:16:04 --> Helper loaded: form_helper
INFO - 2018-10-18 19:16:04 --> Helper loaded: language_helper
DEBUG - 2018-10-18 19:16:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 19:16:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 19:16:04 --> User Agent Class Initialized
INFO - 2018-10-18 19:16:04 --> Controller Class Initialized
INFO - 2018-10-18 19:16:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 19:16:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 19:16:04 --> Helper loaded: custom_helper
INFO - 2018-10-18 19:16:04 --> Pixel_Model class loaded
INFO - 2018-10-18 19:16:04 --> Database Driver Class Initialized
INFO - 2018-10-18 19:16:04 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:16:04 --> Form Validation Class Initialized
INFO - 2018-10-18 19:16:04 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-10-18 19:16:04 --> Severity: Notice --> Trying to get property 'id' of non-object E:\xampp7\htdocs\famiquity\application\controllers\QuestionnaireController.php 76
INFO - 2018-10-18 19:16:28 --> Config Class Initialized
INFO - 2018-10-18 19:16:28 --> Hooks Class Initialized
DEBUG - 2018-10-18 19:16:28 --> UTF-8 Support Enabled
INFO - 2018-10-18 19:16:28 --> Utf8 Class Initialized
INFO - 2018-10-18 19:16:28 --> URI Class Initialized
INFO - 2018-10-18 19:16:28 --> Router Class Initialized
INFO - 2018-10-18 19:16:28 --> Output Class Initialized
INFO - 2018-10-18 19:16:28 --> Security Class Initialized
DEBUG - 2018-10-18 19:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 19:16:28 --> CSRF cookie sent
INFO - 2018-10-18 19:16:29 --> CSRF token verified
INFO - 2018-10-18 19:16:29 --> Input Class Initialized
INFO - 2018-10-18 19:16:29 --> Language Class Initialized
INFO - 2018-10-18 19:16:29 --> Loader Class Initialized
INFO - 2018-10-18 19:16:29 --> Helper loaded: url_helper
INFO - 2018-10-18 19:16:29 --> Helper loaded: form_helper
INFO - 2018-10-18 19:16:29 --> Helper loaded: language_helper
DEBUG - 2018-10-18 19:16:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 19:16:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 19:16:29 --> User Agent Class Initialized
INFO - 2018-10-18 19:16:29 --> Controller Class Initialized
INFO - 2018-10-18 19:16:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 19:16:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 19:16:29 --> Helper loaded: custom_helper
INFO - 2018-10-18 19:16:29 --> Pixel_Model class loaded
INFO - 2018-10-18 19:16:29 --> Database Driver Class Initialized
INFO - 2018-10-18 19:16:29 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:16:29 --> Form Validation Class Initialized
INFO - 2018-10-18 19:16:29 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-10-18 19:16:29 --> Severity: Notice --> Trying to get property 'id' of non-object E:\xampp7\htdocs\famiquity\application\controllers\QuestionnaireController.php 76
INFO - 2018-10-18 19:16:29 --> Database Driver Class Initialized
INFO - 2018-10-18 19:16:29 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:16:29 --> Config Class Initialized
INFO - 2018-10-18 19:16:29 --> Hooks Class Initialized
DEBUG - 2018-10-18 19:16:29 --> UTF-8 Support Enabled
INFO - 2018-10-18 19:16:29 --> Utf8 Class Initialized
INFO - 2018-10-18 19:16:29 --> URI Class Initialized
INFO - 2018-10-18 19:16:29 --> Router Class Initialized
INFO - 2018-10-18 19:16:29 --> Output Class Initialized
INFO - 2018-10-18 19:16:29 --> Security Class Initialized
DEBUG - 2018-10-18 19:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 19:16:29 --> CSRF cookie sent
INFO - 2018-10-18 19:16:29 --> Input Class Initialized
INFO - 2018-10-18 19:16:29 --> Language Class Initialized
INFO - 2018-10-18 19:16:29 --> Loader Class Initialized
INFO - 2018-10-18 19:16:29 --> Helper loaded: url_helper
INFO - 2018-10-18 19:16:29 --> Helper loaded: form_helper
INFO - 2018-10-18 19:16:29 --> Helper loaded: language_helper
DEBUG - 2018-10-18 19:16:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 19:16:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 19:16:29 --> User Agent Class Initialized
INFO - 2018-10-18 19:16:29 --> Controller Class Initialized
INFO - 2018-10-18 19:16:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 19:16:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 19:16:30 --> Helper loaded: custom_helper
INFO - 2018-10-18 19:16:30 --> Pixel_Model class loaded
INFO - 2018-10-18 19:16:30 --> Database Driver Class Initialized
INFO - 2018-10-18 19:16:30 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:16:40 --> Config Class Initialized
INFO - 2018-10-18 19:16:40 --> Hooks Class Initialized
DEBUG - 2018-10-18 19:16:40 --> UTF-8 Support Enabled
INFO - 2018-10-18 19:16:40 --> Utf8 Class Initialized
INFO - 2018-10-18 19:16:40 --> URI Class Initialized
INFO - 2018-10-18 19:16:40 --> Router Class Initialized
INFO - 2018-10-18 19:16:40 --> Output Class Initialized
INFO - 2018-10-18 19:16:40 --> Security Class Initialized
DEBUG - 2018-10-18 19:16:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 19:16:40 --> CSRF cookie sent
INFO - 2018-10-18 19:16:40 --> Input Class Initialized
INFO - 2018-10-18 19:16:40 --> Language Class Initialized
INFO - 2018-10-18 19:16:40 --> Loader Class Initialized
INFO - 2018-10-18 19:16:40 --> Helper loaded: url_helper
INFO - 2018-10-18 19:16:40 --> Helper loaded: form_helper
INFO - 2018-10-18 19:16:40 --> Helper loaded: language_helper
DEBUG - 2018-10-18 19:16:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 19:16:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 19:16:40 --> User Agent Class Initialized
INFO - 2018-10-18 19:16:41 --> Controller Class Initialized
INFO - 2018-10-18 19:16:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 19:16:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 19:16:41 --> Helper loaded: custom_helper
INFO - 2018-10-18 19:16:41 --> Pixel_Model class loaded
INFO - 2018-10-18 19:16:41 --> Database Driver Class Initialized
INFO - 2018-10-18 19:16:41 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:16:59 --> Config Class Initialized
INFO - 2018-10-18 19:16:59 --> Hooks Class Initialized
DEBUG - 2018-10-18 19:16:59 --> UTF-8 Support Enabled
INFO - 2018-10-18 19:16:59 --> Utf8 Class Initialized
INFO - 2018-10-18 19:16:59 --> URI Class Initialized
DEBUG - 2018-10-18 19:16:59 --> No URI present. Default controller set.
INFO - 2018-10-18 19:16:59 --> Router Class Initialized
INFO - 2018-10-18 19:16:59 --> Output Class Initialized
INFO - 2018-10-18 19:16:59 --> Security Class Initialized
DEBUG - 2018-10-18 19:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 19:16:59 --> CSRF cookie sent
INFO - 2018-10-18 19:16:59 --> Input Class Initialized
INFO - 2018-10-18 19:16:59 --> Language Class Initialized
INFO - 2018-10-18 19:16:59 --> Loader Class Initialized
INFO - 2018-10-18 19:16:59 --> Helper loaded: url_helper
INFO - 2018-10-18 19:16:59 --> Helper loaded: form_helper
INFO - 2018-10-18 19:17:00 --> Helper loaded: language_helper
DEBUG - 2018-10-18 19:17:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 19:17:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 19:17:00 --> User Agent Class Initialized
INFO - 2018-10-18 19:17:00 --> Controller Class Initialized
INFO - 2018-10-18 19:17:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 19:17:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 19:17:00 --> Helper loaded: custom_helper
INFO - 2018-10-18 19:17:00 --> Pixel_Model class loaded
INFO - 2018-10-18 19:17:00 --> Database Driver Class Initialized
INFO - 2018-10-18 19:17:00 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:17:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 19:17:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 19:17:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-18 19:17:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 19:17:00 --> Final output sent to browser
DEBUG - 2018-10-18 19:17:00 --> Total execution time: 0.6735
INFO - 2018-10-18 19:17:01 --> Config Class Initialized
INFO - 2018-10-18 19:17:01 --> Hooks Class Initialized
DEBUG - 2018-10-18 19:17:01 --> UTF-8 Support Enabled
INFO - 2018-10-18 19:17:01 --> Utf8 Class Initialized
INFO - 2018-10-18 19:17:02 --> URI Class Initialized
INFO - 2018-10-18 19:17:02 --> Router Class Initialized
INFO - 2018-10-18 19:17:02 --> Output Class Initialized
INFO - 2018-10-18 19:17:02 --> Security Class Initialized
DEBUG - 2018-10-18 19:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 19:17:02 --> CSRF cookie sent
INFO - 2018-10-18 19:17:02 --> Input Class Initialized
INFO - 2018-10-18 19:17:02 --> Language Class Initialized
INFO - 2018-10-18 19:17:02 --> Loader Class Initialized
INFO - 2018-10-18 19:17:02 --> Helper loaded: url_helper
INFO - 2018-10-18 19:17:02 --> Helper loaded: form_helper
INFO - 2018-10-18 19:17:02 --> Helper loaded: language_helper
DEBUG - 2018-10-18 19:17:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 19:17:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 19:17:02 --> User Agent Class Initialized
INFO - 2018-10-18 19:17:02 --> Controller Class Initialized
INFO - 2018-10-18 19:17:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 19:17:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 19:17:02 --> Helper loaded: custom_helper
INFO - 2018-10-18 19:17:02 --> Pixel_Model class loaded
INFO - 2018-10-18 19:17:02 --> Database Driver Class Initialized
INFO - 2018-10-18 19:17:02 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:17:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 19:17:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 19:17:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 19:17:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 19:17:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 19:17:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 19:17:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-18 19:17:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 19:17:02 --> Final output sent to browser
DEBUG - 2018-10-18 19:17:02 --> Total execution time: 0.8488
INFO - 2018-10-18 19:17:05 --> Config Class Initialized
INFO - 2018-10-18 19:17:05 --> Hooks Class Initialized
DEBUG - 2018-10-18 19:17:05 --> UTF-8 Support Enabled
INFO - 2018-10-18 19:17:05 --> Utf8 Class Initialized
INFO - 2018-10-18 19:17:05 --> URI Class Initialized
INFO - 2018-10-18 19:17:05 --> Router Class Initialized
INFO - 2018-10-18 19:17:05 --> Output Class Initialized
INFO - 2018-10-18 19:17:05 --> Security Class Initialized
DEBUG - 2018-10-18 19:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 19:17:05 --> CSRF cookie sent
INFO - 2018-10-18 19:17:05 --> CSRF token verified
INFO - 2018-10-18 19:17:05 --> Input Class Initialized
INFO - 2018-10-18 19:17:05 --> Language Class Initialized
INFO - 2018-10-18 19:17:05 --> Loader Class Initialized
INFO - 2018-10-18 19:17:05 --> Helper loaded: url_helper
INFO - 2018-10-18 19:17:05 --> Helper loaded: form_helper
INFO - 2018-10-18 19:17:05 --> Helper loaded: language_helper
DEBUG - 2018-10-18 19:17:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 19:17:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 19:17:05 --> User Agent Class Initialized
INFO - 2018-10-18 19:17:05 --> Controller Class Initialized
INFO - 2018-10-18 19:17:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 19:17:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 19:17:05 --> Helper loaded: custom_helper
INFO - 2018-10-18 19:17:05 --> Pixel_Model class loaded
INFO - 2018-10-18 19:17:05 --> Database Driver Class Initialized
INFO - 2018-10-18 19:17:05 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:17:05 --> Form Validation Class Initialized
INFO - 2018-10-18 19:17:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 19:17:06 --> Database Driver Class Initialized
INFO - 2018-10-18 19:17:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:17:06 --> Config Class Initialized
INFO - 2018-10-18 19:17:06 --> Hooks Class Initialized
DEBUG - 2018-10-18 19:17:06 --> UTF-8 Support Enabled
INFO - 2018-10-18 19:17:06 --> Utf8 Class Initialized
INFO - 2018-10-18 19:17:06 --> URI Class Initialized
INFO - 2018-10-18 19:17:06 --> Router Class Initialized
INFO - 2018-10-18 19:17:06 --> Output Class Initialized
INFO - 2018-10-18 19:17:06 --> Security Class Initialized
DEBUG - 2018-10-18 19:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 19:17:06 --> CSRF cookie sent
INFO - 2018-10-18 19:17:06 --> Input Class Initialized
INFO - 2018-10-18 19:17:06 --> Language Class Initialized
INFO - 2018-10-18 19:17:06 --> Loader Class Initialized
INFO - 2018-10-18 19:17:06 --> Helper loaded: url_helper
INFO - 2018-10-18 19:17:06 --> Helper loaded: form_helper
INFO - 2018-10-18 19:17:06 --> Helper loaded: language_helper
DEBUG - 2018-10-18 19:17:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 19:17:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 19:17:06 --> User Agent Class Initialized
INFO - 2018-10-18 19:17:06 --> Controller Class Initialized
INFO - 2018-10-18 19:17:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 19:17:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 19:17:06 --> Helper loaded: custom_helper
INFO - 2018-10-18 19:17:06 --> Pixel_Model class loaded
INFO - 2018-10-18 19:17:06 --> Database Driver Class Initialized
INFO - 2018-10-18 19:17:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:17:49 --> Config Class Initialized
INFO - 2018-10-18 19:17:49 --> Hooks Class Initialized
DEBUG - 2018-10-18 19:17:49 --> UTF-8 Support Enabled
INFO - 2018-10-18 19:17:49 --> Utf8 Class Initialized
INFO - 2018-10-18 19:17:49 --> URI Class Initialized
INFO - 2018-10-18 19:17:49 --> Router Class Initialized
INFO - 2018-10-18 19:17:49 --> Output Class Initialized
INFO - 2018-10-18 19:17:49 --> Security Class Initialized
DEBUG - 2018-10-18 19:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 19:17:49 --> CSRF cookie sent
INFO - 2018-10-18 19:17:49 --> Input Class Initialized
INFO - 2018-10-18 19:17:49 --> Language Class Initialized
INFO - 2018-10-18 19:17:49 --> Loader Class Initialized
INFO - 2018-10-18 19:17:49 --> Helper loaded: url_helper
INFO - 2018-10-18 19:17:49 --> Helper loaded: form_helper
INFO - 2018-10-18 19:17:49 --> Helper loaded: language_helper
DEBUG - 2018-10-18 19:17:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 19:17:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 19:17:50 --> User Agent Class Initialized
INFO - 2018-10-18 19:17:50 --> Controller Class Initialized
INFO - 2018-10-18 19:17:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 19:17:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 19:17:50 --> Helper loaded: custom_helper
INFO - 2018-10-18 19:17:50 --> Pixel_Model class loaded
INFO - 2018-10-18 19:17:50 --> Database Driver Class Initialized
INFO - 2018-10-18 19:17:50 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:17:50 --> Database Driver Class Initialized
INFO - 2018-10-18 19:17:50 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:17:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 19:17:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 19:17:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 19:17:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 19:17:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 19:17:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 19:17:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-18 19:17:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 19:17:50 --> Final output sent to browser
DEBUG - 2018-10-18 19:17:50 --> Total execution time: 0.7758
INFO - 2018-10-18 19:19:27 --> Config Class Initialized
INFO - 2018-10-18 19:19:27 --> Hooks Class Initialized
DEBUG - 2018-10-18 19:19:27 --> UTF-8 Support Enabled
INFO - 2018-10-18 19:19:27 --> Utf8 Class Initialized
INFO - 2018-10-18 19:19:27 --> URI Class Initialized
INFO - 2018-10-18 19:19:27 --> Router Class Initialized
INFO - 2018-10-18 19:19:27 --> Output Class Initialized
INFO - 2018-10-18 19:19:27 --> Security Class Initialized
DEBUG - 2018-10-18 19:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 19:19:27 --> CSRF cookie sent
INFO - 2018-10-18 19:19:27 --> Input Class Initialized
INFO - 2018-10-18 19:19:27 --> Language Class Initialized
INFO - 2018-10-18 19:19:27 --> Loader Class Initialized
INFO - 2018-10-18 19:19:27 --> Helper loaded: url_helper
INFO - 2018-10-18 19:19:27 --> Helper loaded: form_helper
INFO - 2018-10-18 19:19:27 --> Helper loaded: language_helper
DEBUG - 2018-10-18 19:19:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 19:19:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 19:19:28 --> User Agent Class Initialized
INFO - 2018-10-18 19:19:28 --> Controller Class Initialized
INFO - 2018-10-18 19:19:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 19:19:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 19:19:28 --> Helper loaded: custom_helper
INFO - 2018-10-18 19:19:28 --> Pixel_Model class loaded
INFO - 2018-10-18 19:19:28 --> Database Driver Class Initialized
INFO - 2018-10-18 19:19:28 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:19:28 --> Database Driver Class Initialized
INFO - 2018-10-18 19:19:28 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:19:28 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 19:19:28 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 19:19:28 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 19:19:28 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 19:19:28 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 19:19:28 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 19:19:28 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-18 19:19:28 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 19:19:28 --> Final output sent to browser
DEBUG - 2018-10-18 19:19:28 --> Total execution time: 0.7742
INFO - 2018-10-18 19:26:30 --> Config Class Initialized
INFO - 2018-10-18 19:26:30 --> Hooks Class Initialized
DEBUG - 2018-10-18 19:26:30 --> UTF-8 Support Enabled
INFO - 2018-10-18 19:26:30 --> Utf8 Class Initialized
INFO - 2018-10-18 19:26:30 --> URI Class Initialized
INFO - 2018-10-18 19:26:30 --> Router Class Initialized
INFO - 2018-10-18 19:26:30 --> Output Class Initialized
INFO - 2018-10-18 19:26:30 --> Security Class Initialized
DEBUG - 2018-10-18 19:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 19:26:30 --> CSRF cookie sent
INFO - 2018-10-18 19:26:30 --> Input Class Initialized
INFO - 2018-10-18 19:26:30 --> Language Class Initialized
INFO - 2018-10-18 19:26:30 --> Loader Class Initialized
INFO - 2018-10-18 19:26:30 --> Helper loaded: url_helper
INFO - 2018-10-18 19:26:30 --> Helper loaded: form_helper
INFO - 2018-10-18 19:26:30 --> Helper loaded: language_helper
DEBUG - 2018-10-18 19:26:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 19:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 19:26:30 --> User Agent Class Initialized
INFO - 2018-10-18 19:26:30 --> Controller Class Initialized
INFO - 2018-10-18 19:26:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 19:26:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 19:26:30 --> Helper loaded: custom_helper
INFO - 2018-10-18 19:26:30 --> Pixel_Model class loaded
INFO - 2018-10-18 19:26:30 --> Database Driver Class Initialized
INFO - 2018-10-18 19:26:30 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:26:30 --> Database Driver Class Initialized
INFO - 2018-10-18 19:26:30 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:26:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 19:26:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 19:26:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 19:26:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 19:26:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 19:26:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 19:26:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-18 19:26:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 19:26:30 --> Final output sent to browser
DEBUG - 2018-10-18 19:26:30 --> Total execution time: 0.7589
INFO - 2018-10-18 19:26:32 --> Config Class Initialized
INFO - 2018-10-18 19:26:32 --> Hooks Class Initialized
DEBUG - 2018-10-18 19:26:32 --> UTF-8 Support Enabled
INFO - 2018-10-18 19:26:32 --> Utf8 Class Initialized
INFO - 2018-10-18 19:26:32 --> URI Class Initialized
INFO - 2018-10-18 19:26:32 --> Router Class Initialized
INFO - 2018-10-18 19:26:32 --> Output Class Initialized
INFO - 2018-10-18 19:26:32 --> Security Class Initialized
DEBUG - 2018-10-18 19:26:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 19:26:32 --> CSRF cookie sent
INFO - 2018-10-18 19:26:32 --> CSRF token verified
INFO - 2018-10-18 19:26:32 --> Input Class Initialized
INFO - 2018-10-18 19:26:32 --> Language Class Initialized
INFO - 2018-10-18 19:26:32 --> Loader Class Initialized
INFO - 2018-10-18 19:26:32 --> Helper loaded: url_helper
INFO - 2018-10-18 19:26:32 --> Helper loaded: form_helper
INFO - 2018-10-18 19:26:32 --> Helper loaded: language_helper
DEBUG - 2018-10-18 19:26:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 19:26:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 19:26:33 --> User Agent Class Initialized
INFO - 2018-10-18 19:26:33 --> Controller Class Initialized
INFO - 2018-10-18 19:26:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 19:26:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 19:26:33 --> Helper loaded: custom_helper
INFO - 2018-10-18 19:26:33 --> Pixel_Model class loaded
INFO - 2018-10-18 19:26:33 --> Database Driver Class Initialized
INFO - 2018-10-18 19:26:33 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:26:33 --> Form Validation Class Initialized
INFO - 2018-10-18 19:26:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 19:26:33 --> Database Driver Class Initialized
INFO - 2018-10-18 19:26:33 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:26:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 19:26:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 19:26:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 19:26:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 19:26:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 19:26:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_errors.php
INFO - 2018-10-18 19:26:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 19:26:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-18 19:26:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 19:26:33 --> Final output sent to browser
DEBUG - 2018-10-18 19:26:33 --> Total execution time: 0.8295
INFO - 2018-10-18 19:26:37 --> Config Class Initialized
INFO - 2018-10-18 19:26:37 --> Hooks Class Initialized
DEBUG - 2018-10-18 19:26:37 --> UTF-8 Support Enabled
INFO - 2018-10-18 19:26:37 --> Utf8 Class Initialized
INFO - 2018-10-18 19:26:37 --> URI Class Initialized
INFO - 2018-10-18 19:26:37 --> Router Class Initialized
INFO - 2018-10-18 19:26:37 --> Output Class Initialized
INFO - 2018-10-18 19:26:37 --> Security Class Initialized
DEBUG - 2018-10-18 19:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 19:26:37 --> CSRF cookie sent
INFO - 2018-10-18 19:26:37 --> CSRF token verified
INFO - 2018-10-18 19:26:37 --> Input Class Initialized
INFO - 2018-10-18 19:26:37 --> Language Class Initialized
INFO - 2018-10-18 19:26:37 --> Loader Class Initialized
INFO - 2018-10-18 19:26:37 --> Helper loaded: url_helper
INFO - 2018-10-18 19:26:37 --> Helper loaded: form_helper
INFO - 2018-10-18 19:26:37 --> Helper loaded: language_helper
DEBUG - 2018-10-18 19:26:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 19:26:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 19:26:37 --> User Agent Class Initialized
INFO - 2018-10-18 19:26:37 --> Controller Class Initialized
INFO - 2018-10-18 19:26:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 19:26:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 19:26:37 --> Helper loaded: custom_helper
INFO - 2018-10-18 19:26:37 --> Pixel_Model class loaded
INFO - 2018-10-18 19:26:37 --> Database Driver Class Initialized
INFO - 2018-10-18 19:26:37 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:26:37 --> Form Validation Class Initialized
INFO - 2018-10-18 19:26:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 19:26:37 --> Database Driver Class Initialized
INFO - 2018-10-18 19:26:37 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:26:37 --> Config Class Initialized
INFO - 2018-10-18 19:26:37 --> Hooks Class Initialized
DEBUG - 2018-10-18 19:26:37 --> UTF-8 Support Enabled
INFO - 2018-10-18 19:26:37 --> Utf8 Class Initialized
INFO - 2018-10-18 19:26:37 --> URI Class Initialized
INFO - 2018-10-18 19:26:37 --> Router Class Initialized
INFO - 2018-10-18 19:26:37 --> Output Class Initialized
INFO - 2018-10-18 19:26:37 --> Security Class Initialized
DEBUG - 2018-10-18 19:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 19:26:37 --> CSRF cookie sent
INFO - 2018-10-18 19:26:37 --> Input Class Initialized
INFO - 2018-10-18 19:26:37 --> Language Class Initialized
INFO - 2018-10-18 19:26:37 --> Loader Class Initialized
INFO - 2018-10-18 19:26:38 --> Helper loaded: url_helper
INFO - 2018-10-18 19:26:38 --> Helper loaded: form_helper
INFO - 2018-10-18 19:26:38 --> Helper loaded: language_helper
DEBUG - 2018-10-18 19:26:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 19:26:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 19:26:38 --> User Agent Class Initialized
INFO - 2018-10-18 19:26:38 --> Controller Class Initialized
INFO - 2018-10-18 19:26:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 19:26:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 19:26:38 --> Helper loaded: custom_helper
INFO - 2018-10-18 19:26:38 --> Pixel_Model class loaded
INFO - 2018-10-18 19:26:38 --> Database Driver Class Initialized
INFO - 2018-10-18 19:26:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:26:38 --> Database Driver Class Initialized
INFO - 2018-10-18 19:26:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:26:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 19:26:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 19:26:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 19:26:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 19:26:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 19:26:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 19:26:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/your_job.php
INFO - 2018-10-18 19:26:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 19:26:38 --> Final output sent to browser
DEBUG - 2018-10-18 19:26:38 --> Total execution time: 0.7773
INFO - 2018-10-18 19:26:39 --> Config Class Initialized
INFO - 2018-10-18 19:26:39 --> Hooks Class Initialized
DEBUG - 2018-10-18 19:26:39 --> UTF-8 Support Enabled
INFO - 2018-10-18 19:26:39 --> Utf8 Class Initialized
INFO - 2018-10-18 19:26:39 --> URI Class Initialized
INFO - 2018-10-18 19:26:39 --> Router Class Initialized
INFO - 2018-10-18 19:26:39 --> Output Class Initialized
INFO - 2018-10-18 19:26:39 --> Security Class Initialized
DEBUG - 2018-10-18 19:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 19:26:39 --> CSRF cookie sent
INFO - 2018-10-18 19:26:39 --> CSRF token verified
INFO - 2018-10-18 19:26:39 --> Input Class Initialized
INFO - 2018-10-18 19:26:39 --> Language Class Initialized
INFO - 2018-10-18 19:26:39 --> Loader Class Initialized
INFO - 2018-10-18 19:26:40 --> Helper loaded: url_helper
INFO - 2018-10-18 19:26:40 --> Helper loaded: form_helper
INFO - 2018-10-18 19:26:40 --> Helper loaded: language_helper
DEBUG - 2018-10-18 19:26:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 19:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 19:26:40 --> User Agent Class Initialized
INFO - 2018-10-18 19:26:40 --> Controller Class Initialized
INFO - 2018-10-18 19:26:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 19:26:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 19:26:40 --> Helper loaded: custom_helper
INFO - 2018-10-18 19:26:40 --> Pixel_Model class loaded
INFO - 2018-10-18 19:26:40 --> Database Driver Class Initialized
INFO - 2018-10-18 19:26:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:26:40 --> Form Validation Class Initialized
INFO - 2018-10-18 19:26:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 19:26:40 --> Database Driver Class Initialized
INFO - 2018-10-18 19:26:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:26:40 --> Config Class Initialized
INFO - 2018-10-18 19:26:40 --> Hooks Class Initialized
DEBUG - 2018-10-18 19:26:40 --> UTF-8 Support Enabled
INFO - 2018-10-18 19:26:40 --> Utf8 Class Initialized
INFO - 2018-10-18 19:26:40 --> URI Class Initialized
INFO - 2018-10-18 19:26:40 --> Router Class Initialized
INFO - 2018-10-18 19:26:40 --> Output Class Initialized
INFO - 2018-10-18 19:26:40 --> Security Class Initialized
DEBUG - 2018-10-18 19:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 19:26:40 --> CSRF cookie sent
INFO - 2018-10-18 19:26:40 --> Input Class Initialized
INFO - 2018-10-18 19:26:40 --> Language Class Initialized
INFO - 2018-10-18 19:26:40 --> Loader Class Initialized
INFO - 2018-10-18 19:26:40 --> Helper loaded: url_helper
INFO - 2018-10-18 19:26:40 --> Helper loaded: form_helper
INFO - 2018-10-18 19:26:40 --> Helper loaded: language_helper
DEBUG - 2018-10-18 19:26:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 19:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 19:26:40 --> User Agent Class Initialized
INFO - 2018-10-18 19:26:40 --> Controller Class Initialized
INFO - 2018-10-18 19:26:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 19:26:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 19:26:40 --> Helper loaded: custom_helper
INFO - 2018-10-18 19:26:40 --> Pixel_Model class loaded
INFO - 2018-10-18 19:26:40 --> Database Driver Class Initialized
INFO - 2018-10-18 19:26:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:26:40 --> Database Driver Class Initialized
INFO - 2018-10-18 19:26:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:26:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 19:26:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 19:26:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner.php
INFO - 2018-10-18 19:26:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 19:26:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 19:26:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 19:26:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 19:26:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/relation_ship_status.php
INFO - 2018-10-18 19:26:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 19:26:41 --> Final output sent to browser
DEBUG - 2018-10-18 19:26:41 --> Total execution time: 0.7630
INFO - 2018-10-18 19:27:07 --> Config Class Initialized
INFO - 2018-10-18 19:27:07 --> Hooks Class Initialized
DEBUG - 2018-10-18 19:27:07 --> UTF-8 Support Enabled
INFO - 2018-10-18 19:27:07 --> Utf8 Class Initialized
INFO - 2018-10-18 19:27:07 --> URI Class Initialized
INFO - 2018-10-18 19:27:07 --> Router Class Initialized
INFO - 2018-10-18 19:27:07 --> Output Class Initialized
INFO - 2018-10-18 19:27:07 --> Security Class Initialized
DEBUG - 2018-10-18 19:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 19:27:07 --> CSRF cookie sent
INFO - 2018-10-18 19:27:07 --> CSRF token verified
INFO - 2018-10-18 19:27:07 --> Input Class Initialized
INFO - 2018-10-18 19:27:07 --> Language Class Initialized
INFO - 2018-10-18 19:27:07 --> Loader Class Initialized
INFO - 2018-10-18 19:27:07 --> Helper loaded: url_helper
INFO - 2018-10-18 19:27:07 --> Helper loaded: form_helper
INFO - 2018-10-18 19:27:07 --> Helper loaded: language_helper
DEBUG - 2018-10-18 19:27:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 19:27:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 19:27:07 --> User Agent Class Initialized
INFO - 2018-10-18 19:27:07 --> Controller Class Initialized
INFO - 2018-10-18 19:27:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 19:27:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 19:27:07 --> Helper loaded: custom_helper
INFO - 2018-10-18 19:27:07 --> Pixel_Model class loaded
INFO - 2018-10-18 19:27:07 --> Database Driver Class Initialized
INFO - 2018-10-18 19:27:07 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:27:07 --> Form Validation Class Initialized
INFO - 2018-10-18 19:27:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 19:27:07 --> Database Driver Class Initialized
INFO - 2018-10-18 19:27:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:27:08 --> Config Class Initialized
INFO - 2018-10-18 19:27:08 --> Hooks Class Initialized
DEBUG - 2018-10-18 19:27:08 --> UTF-8 Support Enabled
INFO - 2018-10-18 19:27:08 --> Utf8 Class Initialized
INFO - 2018-10-18 19:27:08 --> URI Class Initialized
INFO - 2018-10-18 19:27:08 --> Router Class Initialized
INFO - 2018-10-18 19:27:08 --> Output Class Initialized
INFO - 2018-10-18 19:27:08 --> Security Class Initialized
DEBUG - 2018-10-18 19:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 19:27:08 --> CSRF cookie sent
INFO - 2018-10-18 19:27:08 --> Input Class Initialized
INFO - 2018-10-18 19:27:08 --> Language Class Initialized
INFO - 2018-10-18 19:27:08 --> Loader Class Initialized
INFO - 2018-10-18 19:27:08 --> Helper loaded: url_helper
INFO - 2018-10-18 19:27:08 --> Helper loaded: form_helper
INFO - 2018-10-18 19:27:08 --> Helper loaded: language_helper
DEBUG - 2018-10-18 19:27:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 19:27:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 19:27:08 --> User Agent Class Initialized
INFO - 2018-10-18 19:27:08 --> Controller Class Initialized
INFO - 2018-10-18 19:27:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 19:27:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 19:27:08 --> Helper loaded: custom_helper
INFO - 2018-10-18 19:27:08 --> Pixel_Model class loaded
INFO - 2018-10-18 19:27:08 --> Database Driver Class Initialized
INFO - 2018-10-18 19:27:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:27:08 --> Database Driver Class Initialized
INFO - 2018-10-18 19:27:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:27:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 19:27:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 19:27:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 19:27:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 19:27:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 19:27:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 19:27:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/income.php
INFO - 2018-10-18 19:27:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 19:27:08 --> Final output sent to browser
DEBUG - 2018-10-18 19:27:08 --> Total execution time: 0.7455
INFO - 2018-10-18 19:27:12 --> Config Class Initialized
INFO - 2018-10-18 19:27:12 --> Hooks Class Initialized
DEBUG - 2018-10-18 19:27:12 --> UTF-8 Support Enabled
INFO - 2018-10-18 19:27:12 --> Utf8 Class Initialized
INFO - 2018-10-18 19:27:12 --> URI Class Initialized
INFO - 2018-10-18 19:27:12 --> Router Class Initialized
INFO - 2018-10-18 19:27:12 --> Output Class Initialized
INFO - 2018-10-18 19:27:12 --> Security Class Initialized
DEBUG - 2018-10-18 19:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 19:27:12 --> CSRF cookie sent
INFO - 2018-10-18 19:27:12 --> CSRF token verified
INFO - 2018-10-18 19:27:12 --> Input Class Initialized
INFO - 2018-10-18 19:27:12 --> Language Class Initialized
INFO - 2018-10-18 19:27:12 --> Loader Class Initialized
INFO - 2018-10-18 19:27:12 --> Helper loaded: url_helper
INFO - 2018-10-18 19:27:12 --> Helper loaded: form_helper
INFO - 2018-10-18 19:27:12 --> Helper loaded: language_helper
DEBUG - 2018-10-18 19:27:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 19:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 19:27:12 --> User Agent Class Initialized
INFO - 2018-10-18 19:27:12 --> Controller Class Initialized
INFO - 2018-10-18 19:27:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 19:27:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 19:27:12 --> Helper loaded: custom_helper
INFO - 2018-10-18 19:27:12 --> Pixel_Model class loaded
INFO - 2018-10-18 19:27:12 --> Database Driver Class Initialized
INFO - 2018-10-18 19:27:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:27:12 --> Form Validation Class Initialized
INFO - 2018-10-18 19:27:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 19:27:12 --> Database Driver Class Initialized
INFO - 2018-10-18 19:27:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:27:13 --> Config Class Initialized
INFO - 2018-10-18 19:27:13 --> Hooks Class Initialized
DEBUG - 2018-10-18 19:27:13 --> UTF-8 Support Enabled
INFO - 2018-10-18 19:27:13 --> Utf8 Class Initialized
INFO - 2018-10-18 19:27:13 --> URI Class Initialized
INFO - 2018-10-18 19:27:13 --> Router Class Initialized
INFO - 2018-10-18 19:27:13 --> Output Class Initialized
INFO - 2018-10-18 19:27:13 --> Security Class Initialized
DEBUG - 2018-10-18 19:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 19:27:13 --> CSRF cookie sent
INFO - 2018-10-18 19:27:13 --> Input Class Initialized
INFO - 2018-10-18 19:27:13 --> Language Class Initialized
INFO - 2018-10-18 19:27:13 --> Loader Class Initialized
INFO - 2018-10-18 19:27:13 --> Helper loaded: url_helper
INFO - 2018-10-18 19:27:13 --> Helper loaded: form_helper
INFO - 2018-10-18 19:27:13 --> Helper loaded: language_helper
DEBUG - 2018-10-18 19:27:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 19:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 19:27:13 --> User Agent Class Initialized
INFO - 2018-10-18 19:27:13 --> Controller Class Initialized
INFO - 2018-10-18 19:27:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 19:27:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 19:27:13 --> Helper loaded: custom_helper
INFO - 2018-10-18 19:27:13 --> Pixel_Model class loaded
INFO - 2018-10-18 19:27:13 --> Database Driver Class Initialized
INFO - 2018-10-18 19:27:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:27:13 --> Database Driver Class Initialized
INFO - 2018-10-18 19:27:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:27:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 19:27:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 19:27:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 19:27:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 19:27:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 19:27:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 19:27:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/marriage.php
INFO - 2018-10-18 19:27:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 19:27:13 --> Final output sent to browser
DEBUG - 2018-10-18 19:27:13 --> Total execution time: 0.7522
INFO - 2018-10-18 19:27:16 --> Config Class Initialized
INFO - 2018-10-18 19:27:16 --> Hooks Class Initialized
DEBUG - 2018-10-18 19:27:16 --> UTF-8 Support Enabled
INFO - 2018-10-18 19:27:16 --> Utf8 Class Initialized
INFO - 2018-10-18 19:27:16 --> URI Class Initialized
INFO - 2018-10-18 19:27:16 --> Router Class Initialized
INFO - 2018-10-18 19:27:16 --> Output Class Initialized
INFO - 2018-10-18 19:27:16 --> Security Class Initialized
DEBUG - 2018-10-18 19:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 19:27:16 --> CSRF cookie sent
INFO - 2018-10-18 19:27:16 --> CSRF token verified
INFO - 2018-10-18 19:27:16 --> Input Class Initialized
INFO - 2018-10-18 19:27:16 --> Language Class Initialized
INFO - 2018-10-18 19:27:17 --> Loader Class Initialized
INFO - 2018-10-18 19:27:17 --> Helper loaded: url_helper
INFO - 2018-10-18 19:27:17 --> Helper loaded: form_helper
INFO - 2018-10-18 19:27:17 --> Helper loaded: language_helper
DEBUG - 2018-10-18 19:27:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 19:27:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 19:27:17 --> User Agent Class Initialized
INFO - 2018-10-18 19:27:17 --> Controller Class Initialized
INFO - 2018-10-18 19:27:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 19:27:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 19:27:17 --> Helper loaded: custom_helper
INFO - 2018-10-18 19:27:17 --> Pixel_Model class loaded
INFO - 2018-10-18 19:27:17 --> Database Driver Class Initialized
INFO - 2018-10-18 19:27:17 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:27:17 --> Form Validation Class Initialized
INFO - 2018-10-18 19:27:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 19:27:17 --> Database Driver Class Initialized
INFO - 2018-10-18 19:27:17 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:27:17 --> Config Class Initialized
INFO - 2018-10-18 19:27:17 --> Hooks Class Initialized
DEBUG - 2018-10-18 19:27:17 --> UTF-8 Support Enabled
INFO - 2018-10-18 19:27:17 --> Utf8 Class Initialized
INFO - 2018-10-18 19:27:17 --> URI Class Initialized
INFO - 2018-10-18 19:27:17 --> Router Class Initialized
INFO - 2018-10-18 19:27:17 --> Output Class Initialized
INFO - 2018-10-18 19:27:17 --> Security Class Initialized
DEBUG - 2018-10-18 19:27:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 19:27:17 --> CSRF cookie sent
INFO - 2018-10-18 19:27:17 --> Input Class Initialized
INFO - 2018-10-18 19:27:17 --> Language Class Initialized
INFO - 2018-10-18 19:27:17 --> Loader Class Initialized
INFO - 2018-10-18 19:27:17 --> Helper loaded: url_helper
INFO - 2018-10-18 19:27:17 --> Helper loaded: form_helper
INFO - 2018-10-18 19:27:17 --> Helper loaded: language_helper
DEBUG - 2018-10-18 19:27:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 19:27:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 19:27:17 --> User Agent Class Initialized
INFO - 2018-10-18 19:27:17 --> Controller Class Initialized
INFO - 2018-10-18 19:27:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 19:27:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 19:27:17 --> Helper loaded: custom_helper
INFO - 2018-10-18 19:27:17 --> Pixel_Model class loaded
INFO - 2018-10-18 19:27:17 --> Database Driver Class Initialized
INFO - 2018-10-18 19:27:17 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:27:18 --> Database Driver Class Initialized
INFO - 2018-10-18 19:27:18 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:27:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 19:27:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 19:27:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 19:27:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 19:27:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 19:27:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 19:27:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/kids.php
INFO - 2018-10-18 19:27:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 19:27:18 --> Final output sent to browser
DEBUG - 2018-10-18 19:27:18 --> Total execution time: 0.7929
INFO - 2018-10-18 19:27:30 --> Config Class Initialized
INFO - 2018-10-18 19:27:30 --> Hooks Class Initialized
DEBUG - 2018-10-18 19:27:30 --> UTF-8 Support Enabled
INFO - 2018-10-18 19:27:30 --> Utf8 Class Initialized
INFO - 2018-10-18 19:27:30 --> URI Class Initialized
INFO - 2018-10-18 19:27:30 --> Router Class Initialized
INFO - 2018-10-18 19:27:30 --> Output Class Initialized
INFO - 2018-10-18 19:27:30 --> Security Class Initialized
DEBUG - 2018-10-18 19:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 19:27:30 --> CSRF cookie sent
INFO - 2018-10-18 19:27:30 --> CSRF token verified
INFO - 2018-10-18 19:27:30 --> Input Class Initialized
INFO - 2018-10-18 19:27:30 --> Language Class Initialized
INFO - 2018-10-18 19:27:30 --> Loader Class Initialized
INFO - 2018-10-18 19:27:30 --> Helper loaded: url_helper
INFO - 2018-10-18 19:27:30 --> Helper loaded: form_helper
INFO - 2018-10-18 19:27:30 --> Helper loaded: language_helper
DEBUG - 2018-10-18 19:27:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 19:27:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 19:27:31 --> User Agent Class Initialized
INFO - 2018-10-18 19:27:31 --> Controller Class Initialized
INFO - 2018-10-18 19:27:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 19:27:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 19:27:31 --> Helper loaded: custom_helper
INFO - 2018-10-18 19:27:31 --> Pixel_Model class loaded
INFO - 2018-10-18 19:27:31 --> Database Driver Class Initialized
INFO - 2018-10-18 19:27:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:27:31 --> Form Validation Class Initialized
INFO - 2018-10-18 19:27:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 19:27:31 --> Database Driver Class Initialized
INFO - 2018-10-18 19:27:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:27:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 19:27:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 19:27:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 19:27:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 19:27:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 19:27:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_errors.php
INFO - 2018-10-18 19:27:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 19:27:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/kids.php
INFO - 2018-10-18 19:27:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 19:27:31 --> Final output sent to browser
DEBUG - 2018-10-18 19:27:31 --> Total execution time: 0.8495
INFO - 2018-10-18 19:27:36 --> Config Class Initialized
INFO - 2018-10-18 19:27:36 --> Hooks Class Initialized
DEBUG - 2018-10-18 19:27:36 --> UTF-8 Support Enabled
INFO - 2018-10-18 19:27:36 --> Utf8 Class Initialized
INFO - 2018-10-18 19:27:36 --> URI Class Initialized
INFO - 2018-10-18 19:27:36 --> Router Class Initialized
INFO - 2018-10-18 19:27:36 --> Output Class Initialized
INFO - 2018-10-18 19:27:36 --> Security Class Initialized
DEBUG - 2018-10-18 19:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 19:27:36 --> CSRF cookie sent
INFO - 2018-10-18 19:27:36 --> CSRF token verified
INFO - 2018-10-18 19:27:36 --> Input Class Initialized
INFO - 2018-10-18 19:27:36 --> Language Class Initialized
INFO - 2018-10-18 19:27:36 --> Loader Class Initialized
INFO - 2018-10-18 19:27:36 --> Helper loaded: url_helper
INFO - 2018-10-18 19:27:36 --> Helper loaded: form_helper
INFO - 2018-10-18 19:27:36 --> Helper loaded: language_helper
DEBUG - 2018-10-18 19:27:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 19:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 19:27:36 --> User Agent Class Initialized
INFO - 2018-10-18 19:27:36 --> Controller Class Initialized
INFO - 2018-10-18 19:27:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 19:27:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 19:27:36 --> Helper loaded: custom_helper
INFO - 2018-10-18 19:27:36 --> Pixel_Model class loaded
INFO - 2018-10-18 19:27:36 --> Database Driver Class Initialized
INFO - 2018-10-18 19:27:36 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:27:36 --> Form Validation Class Initialized
INFO - 2018-10-18 19:27:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 19:27:36 --> Database Driver Class Initialized
INFO - 2018-10-18 19:27:36 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:27:36 --> Config Class Initialized
INFO - 2018-10-18 19:27:36 --> Hooks Class Initialized
DEBUG - 2018-10-18 19:27:36 --> UTF-8 Support Enabled
INFO - 2018-10-18 19:27:36 --> Utf8 Class Initialized
INFO - 2018-10-18 19:27:36 --> URI Class Initialized
INFO - 2018-10-18 19:27:36 --> Router Class Initialized
INFO - 2018-10-18 19:27:37 --> Output Class Initialized
INFO - 2018-10-18 19:27:37 --> Security Class Initialized
DEBUG - 2018-10-18 19:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 19:27:37 --> CSRF cookie sent
INFO - 2018-10-18 19:27:37 --> Input Class Initialized
INFO - 2018-10-18 19:27:37 --> Language Class Initialized
INFO - 2018-10-18 19:27:37 --> Loader Class Initialized
INFO - 2018-10-18 19:27:37 --> Helper loaded: url_helper
INFO - 2018-10-18 19:27:37 --> Helper loaded: form_helper
INFO - 2018-10-18 19:27:37 --> Helper loaded: language_helper
DEBUG - 2018-10-18 19:27:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 19:27:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 19:27:37 --> User Agent Class Initialized
INFO - 2018-10-18 19:27:37 --> Controller Class Initialized
INFO - 2018-10-18 19:27:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 19:27:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 19:27:37 --> Helper loaded: custom_helper
INFO - 2018-10-18 19:27:37 --> Pixel_Model class loaded
INFO - 2018-10-18 19:27:37 --> Database Driver Class Initialized
INFO - 2018-10-18 19:27:37 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:27:37 --> Database Driver Class Initialized
INFO - 2018-10-18 19:27:37 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:27:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 19:27:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 19:27:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 19:27:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 19:27:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 19:27:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 19:27:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/pension.php
INFO - 2018-10-18 19:27:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 19:27:37 --> Final output sent to browser
DEBUG - 2018-10-18 19:27:37 --> Total execution time: 0.7488
INFO - 2018-10-18 19:27:41 --> Config Class Initialized
INFO - 2018-10-18 19:27:41 --> Hooks Class Initialized
DEBUG - 2018-10-18 19:27:41 --> UTF-8 Support Enabled
INFO - 2018-10-18 19:27:41 --> Utf8 Class Initialized
INFO - 2018-10-18 19:27:41 --> URI Class Initialized
INFO - 2018-10-18 19:27:41 --> Router Class Initialized
INFO - 2018-10-18 19:27:41 --> Output Class Initialized
INFO - 2018-10-18 19:27:41 --> Security Class Initialized
DEBUG - 2018-10-18 19:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 19:27:41 --> CSRF cookie sent
INFO - 2018-10-18 19:27:41 --> CSRF token verified
INFO - 2018-10-18 19:27:41 --> Input Class Initialized
INFO - 2018-10-18 19:27:41 --> Language Class Initialized
INFO - 2018-10-18 19:27:41 --> Loader Class Initialized
INFO - 2018-10-18 19:27:41 --> Helper loaded: url_helper
INFO - 2018-10-18 19:27:41 --> Helper loaded: form_helper
INFO - 2018-10-18 19:27:41 --> Helper loaded: language_helper
DEBUG - 2018-10-18 19:27:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 19:27:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 19:27:42 --> User Agent Class Initialized
INFO - 2018-10-18 19:27:42 --> Controller Class Initialized
INFO - 2018-10-18 19:27:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 19:27:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 19:27:42 --> Helper loaded: custom_helper
INFO - 2018-10-18 19:27:42 --> Pixel_Model class loaded
INFO - 2018-10-18 19:27:42 --> Database Driver Class Initialized
INFO - 2018-10-18 19:27:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:27:42 --> Form Validation Class Initialized
INFO - 2018-10-18 19:27:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 19:27:42 --> Database Driver Class Initialized
INFO - 2018-10-18 19:27:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:27:42 --> Config Class Initialized
INFO - 2018-10-18 19:27:42 --> Hooks Class Initialized
DEBUG - 2018-10-18 19:27:42 --> UTF-8 Support Enabled
INFO - 2018-10-18 19:27:42 --> Utf8 Class Initialized
INFO - 2018-10-18 19:27:42 --> URI Class Initialized
INFO - 2018-10-18 19:27:42 --> Router Class Initialized
INFO - 2018-10-18 19:27:42 --> Output Class Initialized
INFO - 2018-10-18 19:27:42 --> Security Class Initialized
DEBUG - 2018-10-18 19:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 19:27:42 --> CSRF cookie sent
INFO - 2018-10-18 19:27:42 --> Input Class Initialized
INFO - 2018-10-18 19:27:42 --> Language Class Initialized
INFO - 2018-10-18 19:27:42 --> Loader Class Initialized
INFO - 2018-10-18 19:27:42 --> Helper loaded: url_helper
INFO - 2018-10-18 19:27:42 --> Helper loaded: form_helper
INFO - 2018-10-18 19:27:42 --> Helper loaded: language_helper
DEBUG - 2018-10-18 19:27:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 19:27:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 19:27:42 --> User Agent Class Initialized
INFO - 2018-10-18 19:27:42 --> Controller Class Initialized
INFO - 2018-10-18 19:27:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 19:27:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 19:27:42 --> Helper loaded: custom_helper
INFO - 2018-10-18 19:27:42 --> Pixel_Model class loaded
INFO - 2018-10-18 19:27:42 --> Database Driver Class Initialized
INFO - 2018-10-18 19:27:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:27:42 --> Database Driver Class Initialized
INFO - 2018-10-18 19:27:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:27:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 19:27:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 19:27:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 19:27:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 19:27:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 19:27:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 19:27:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/inheritance.php
INFO - 2018-10-18 19:27:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 19:27:43 --> Final output sent to browser
DEBUG - 2018-10-18 19:27:43 --> Total execution time: 0.7574
INFO - 2018-10-18 19:27:45 --> Config Class Initialized
INFO - 2018-10-18 19:27:45 --> Hooks Class Initialized
DEBUG - 2018-10-18 19:27:45 --> UTF-8 Support Enabled
INFO - 2018-10-18 19:27:45 --> Utf8 Class Initialized
INFO - 2018-10-18 19:27:46 --> URI Class Initialized
INFO - 2018-10-18 19:27:46 --> Router Class Initialized
INFO - 2018-10-18 19:27:46 --> Output Class Initialized
INFO - 2018-10-18 19:27:46 --> Security Class Initialized
DEBUG - 2018-10-18 19:27:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 19:27:46 --> CSRF cookie sent
INFO - 2018-10-18 19:27:46 --> CSRF token verified
INFO - 2018-10-18 19:27:46 --> Input Class Initialized
INFO - 2018-10-18 19:27:46 --> Language Class Initialized
INFO - 2018-10-18 19:27:46 --> Loader Class Initialized
INFO - 2018-10-18 19:27:46 --> Helper loaded: url_helper
INFO - 2018-10-18 19:27:46 --> Helper loaded: form_helper
INFO - 2018-10-18 19:27:46 --> Helper loaded: language_helper
DEBUG - 2018-10-18 19:27:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 19:27:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 19:27:46 --> User Agent Class Initialized
INFO - 2018-10-18 19:27:46 --> Controller Class Initialized
INFO - 2018-10-18 19:27:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 19:27:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 19:27:46 --> Helper loaded: custom_helper
INFO - 2018-10-18 19:27:46 --> Pixel_Model class loaded
INFO - 2018-10-18 19:27:46 --> Database Driver Class Initialized
INFO - 2018-10-18 19:27:46 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:27:46 --> Form Validation Class Initialized
INFO - 2018-10-18 19:27:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 19:27:46 --> Database Driver Class Initialized
INFO - 2018-10-18 19:27:46 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:27:46 --> Config Class Initialized
INFO - 2018-10-18 19:27:46 --> Hooks Class Initialized
DEBUG - 2018-10-18 19:27:46 --> UTF-8 Support Enabled
INFO - 2018-10-18 19:27:46 --> Utf8 Class Initialized
INFO - 2018-10-18 19:27:46 --> URI Class Initialized
INFO - 2018-10-18 19:27:46 --> Router Class Initialized
INFO - 2018-10-18 19:27:46 --> Output Class Initialized
INFO - 2018-10-18 19:27:46 --> Security Class Initialized
DEBUG - 2018-10-18 19:27:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 19:27:46 --> CSRF cookie sent
INFO - 2018-10-18 19:27:46 --> Input Class Initialized
INFO - 2018-10-18 19:27:46 --> Language Class Initialized
INFO - 2018-10-18 19:27:46 --> Loader Class Initialized
INFO - 2018-10-18 19:27:46 --> Helper loaded: url_helper
INFO - 2018-10-18 19:27:46 --> Helper loaded: form_helper
INFO - 2018-10-18 19:27:46 --> Helper loaded: language_helper
DEBUG - 2018-10-18 19:27:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 19:27:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 19:27:47 --> User Agent Class Initialized
INFO - 2018-10-18 19:27:47 --> Controller Class Initialized
INFO - 2018-10-18 19:27:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 19:27:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 19:27:47 --> Helper loaded: custom_helper
INFO - 2018-10-18 19:27:47 --> Pixel_Model class loaded
INFO - 2018-10-18 19:27:47 --> Database Driver Class Initialized
INFO - 2018-10-18 19:27:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:27:47 --> Database Driver Class Initialized
INFO - 2018-10-18 19:27:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:27:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 19:27:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 19:27:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 19:27:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 19:27:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 19:27:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 19:27:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/inheritance_maintained.php
INFO - 2018-10-18 19:27:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 19:27:47 --> Final output sent to browser
DEBUG - 2018-10-18 19:27:47 --> Total execution time: 0.7973
INFO - 2018-10-18 19:27:49 --> Config Class Initialized
INFO - 2018-10-18 19:27:49 --> Hooks Class Initialized
DEBUG - 2018-10-18 19:27:49 --> UTF-8 Support Enabled
INFO - 2018-10-18 19:27:49 --> Utf8 Class Initialized
INFO - 2018-10-18 19:27:49 --> URI Class Initialized
INFO - 2018-10-18 19:27:49 --> Router Class Initialized
INFO - 2018-10-18 19:27:49 --> Output Class Initialized
INFO - 2018-10-18 19:27:49 --> Security Class Initialized
DEBUG - 2018-10-18 19:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 19:27:49 --> CSRF cookie sent
INFO - 2018-10-18 19:27:49 --> CSRF token verified
INFO - 2018-10-18 19:27:49 --> Input Class Initialized
INFO - 2018-10-18 19:27:49 --> Language Class Initialized
INFO - 2018-10-18 19:27:49 --> Loader Class Initialized
INFO - 2018-10-18 19:27:49 --> Helper loaded: url_helper
INFO - 2018-10-18 19:27:49 --> Helper loaded: form_helper
INFO - 2018-10-18 19:27:49 --> Helper loaded: language_helper
DEBUG - 2018-10-18 19:27:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 19:27:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 19:27:49 --> User Agent Class Initialized
INFO - 2018-10-18 19:27:49 --> Controller Class Initialized
INFO - 2018-10-18 19:27:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 19:27:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 19:27:49 --> Helper loaded: custom_helper
INFO - 2018-10-18 19:27:49 --> Pixel_Model class loaded
INFO - 2018-10-18 19:27:49 --> Database Driver Class Initialized
INFO - 2018-10-18 19:27:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:27:49 --> Form Validation Class Initialized
INFO - 2018-10-18 19:27:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 19:27:49 --> Database Driver Class Initialized
INFO - 2018-10-18 19:27:50 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:27:50 --> Config Class Initialized
INFO - 2018-10-18 19:27:50 --> Hooks Class Initialized
DEBUG - 2018-10-18 19:27:50 --> UTF-8 Support Enabled
INFO - 2018-10-18 19:27:50 --> Utf8 Class Initialized
INFO - 2018-10-18 19:27:50 --> URI Class Initialized
INFO - 2018-10-18 19:27:50 --> Router Class Initialized
INFO - 2018-10-18 19:27:50 --> Output Class Initialized
INFO - 2018-10-18 19:27:50 --> Security Class Initialized
DEBUG - 2018-10-18 19:27:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 19:27:50 --> CSRF cookie sent
INFO - 2018-10-18 19:27:50 --> Input Class Initialized
INFO - 2018-10-18 19:27:50 --> Language Class Initialized
INFO - 2018-10-18 19:27:50 --> Loader Class Initialized
INFO - 2018-10-18 19:27:50 --> Helper loaded: url_helper
INFO - 2018-10-18 19:27:50 --> Helper loaded: form_helper
INFO - 2018-10-18 19:27:50 --> Helper loaded: language_helper
DEBUG - 2018-10-18 19:27:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 19:27:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 19:27:50 --> User Agent Class Initialized
INFO - 2018-10-18 19:27:50 --> Controller Class Initialized
INFO - 2018-10-18 19:27:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 19:27:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 19:27:50 --> Helper loaded: custom_helper
INFO - 2018-10-18 19:27:50 --> Pixel_Model class loaded
INFO - 2018-10-18 19:27:50 --> Database Driver Class Initialized
INFO - 2018-10-18 19:27:50 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:27:50 --> Database Driver Class Initialized
INFO - 2018-10-18 19:27:50 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:27:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 19:27:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 19:27:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 19:27:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 19:27:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 19:27:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 19:27:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/home_owner.php
INFO - 2018-10-18 19:27:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 19:27:50 --> Final output sent to browser
DEBUG - 2018-10-18 19:27:50 --> Total execution time: 0.7651
INFO - 2018-10-18 19:27:51 --> Config Class Initialized
INFO - 2018-10-18 19:27:51 --> Hooks Class Initialized
DEBUG - 2018-10-18 19:27:51 --> UTF-8 Support Enabled
INFO - 2018-10-18 19:27:51 --> Utf8 Class Initialized
INFO - 2018-10-18 19:27:51 --> URI Class Initialized
INFO - 2018-10-18 19:27:51 --> Router Class Initialized
INFO - 2018-10-18 19:27:51 --> Output Class Initialized
INFO - 2018-10-18 19:27:52 --> Security Class Initialized
DEBUG - 2018-10-18 19:27:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 19:27:52 --> CSRF cookie sent
INFO - 2018-10-18 19:27:52 --> CSRF token verified
INFO - 2018-10-18 19:27:52 --> Input Class Initialized
INFO - 2018-10-18 19:27:52 --> Language Class Initialized
INFO - 2018-10-18 19:27:52 --> Loader Class Initialized
INFO - 2018-10-18 19:27:52 --> Helper loaded: url_helper
INFO - 2018-10-18 19:27:52 --> Helper loaded: form_helper
INFO - 2018-10-18 19:27:52 --> Helper loaded: language_helper
DEBUG - 2018-10-18 19:27:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 19:27:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 19:27:52 --> User Agent Class Initialized
INFO - 2018-10-18 19:27:52 --> Controller Class Initialized
INFO - 2018-10-18 19:27:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 19:27:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 19:27:52 --> Helper loaded: custom_helper
INFO - 2018-10-18 19:27:52 --> Pixel_Model class loaded
INFO - 2018-10-18 19:27:52 --> Database Driver Class Initialized
INFO - 2018-10-18 19:27:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:27:52 --> Form Validation Class Initialized
INFO - 2018-10-18 19:27:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 19:27:52 --> Database Driver Class Initialized
INFO - 2018-10-18 19:27:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:27:52 --> Config Class Initialized
INFO - 2018-10-18 19:27:52 --> Hooks Class Initialized
DEBUG - 2018-10-18 19:27:52 --> UTF-8 Support Enabled
INFO - 2018-10-18 19:27:52 --> Utf8 Class Initialized
INFO - 2018-10-18 19:27:52 --> URI Class Initialized
INFO - 2018-10-18 19:27:52 --> Router Class Initialized
INFO - 2018-10-18 19:27:52 --> Output Class Initialized
INFO - 2018-10-18 19:27:52 --> Security Class Initialized
DEBUG - 2018-10-18 19:27:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 19:27:52 --> CSRF cookie sent
INFO - 2018-10-18 19:27:52 --> Input Class Initialized
INFO - 2018-10-18 19:27:52 --> Language Class Initialized
INFO - 2018-10-18 19:27:52 --> Loader Class Initialized
INFO - 2018-10-18 19:27:52 --> Helper loaded: url_helper
INFO - 2018-10-18 19:27:52 --> Helper loaded: form_helper
INFO - 2018-10-18 19:27:52 --> Helper loaded: language_helper
DEBUG - 2018-10-18 19:27:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 19:27:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 19:27:52 --> User Agent Class Initialized
INFO - 2018-10-18 19:27:52 --> Controller Class Initialized
INFO - 2018-10-18 19:27:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 19:27:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 19:27:53 --> Helper loaded: custom_helper
INFO - 2018-10-18 19:27:53 --> Pixel_Model class loaded
INFO - 2018-10-18 19:27:53 --> Database Driver Class Initialized
INFO - 2018-10-18 19:27:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:27:53 --> Database Driver Class Initialized
INFO - 2018-10-18 19:27:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:27:53 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 19:27:53 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 19:27:53 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 19:27:53 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 19:27:53 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 19:27:53 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 19:27:53 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/home_value.php
INFO - 2018-10-18 19:27:53 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 19:27:53 --> Final output sent to browser
DEBUG - 2018-10-18 19:27:53 --> Total execution time: 0.7889
INFO - 2018-10-18 19:27:56 --> Config Class Initialized
INFO - 2018-10-18 19:27:56 --> Hooks Class Initialized
DEBUG - 2018-10-18 19:27:56 --> UTF-8 Support Enabled
INFO - 2018-10-18 19:27:56 --> Utf8 Class Initialized
INFO - 2018-10-18 19:27:56 --> URI Class Initialized
INFO - 2018-10-18 19:27:56 --> Router Class Initialized
INFO - 2018-10-18 19:27:56 --> Output Class Initialized
INFO - 2018-10-18 19:27:56 --> Security Class Initialized
DEBUG - 2018-10-18 19:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 19:27:56 --> CSRF cookie sent
INFO - 2018-10-18 19:27:56 --> CSRF token verified
INFO - 2018-10-18 19:27:56 --> Input Class Initialized
INFO - 2018-10-18 19:27:56 --> Language Class Initialized
INFO - 2018-10-18 19:27:56 --> Loader Class Initialized
INFO - 2018-10-18 19:27:56 --> Helper loaded: url_helper
INFO - 2018-10-18 19:27:56 --> Helper loaded: form_helper
INFO - 2018-10-18 19:27:56 --> Helper loaded: language_helper
DEBUG - 2018-10-18 19:27:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 19:27:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 19:27:57 --> User Agent Class Initialized
INFO - 2018-10-18 19:27:57 --> Controller Class Initialized
INFO - 2018-10-18 19:27:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 19:27:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 19:27:57 --> Helper loaded: custom_helper
INFO - 2018-10-18 19:27:57 --> Pixel_Model class loaded
INFO - 2018-10-18 19:27:57 --> Database Driver Class Initialized
INFO - 2018-10-18 19:27:57 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:27:57 --> Form Validation Class Initialized
INFO - 2018-10-18 19:27:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 19:27:57 --> Database Driver Class Initialized
INFO - 2018-10-18 19:27:57 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:27:57 --> Config Class Initialized
INFO - 2018-10-18 19:27:57 --> Hooks Class Initialized
DEBUG - 2018-10-18 19:27:57 --> UTF-8 Support Enabled
INFO - 2018-10-18 19:27:57 --> Utf8 Class Initialized
INFO - 2018-10-18 19:27:57 --> URI Class Initialized
INFO - 2018-10-18 19:27:57 --> Router Class Initialized
INFO - 2018-10-18 19:27:57 --> Output Class Initialized
INFO - 2018-10-18 19:27:57 --> Security Class Initialized
DEBUG - 2018-10-18 19:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 19:27:57 --> CSRF cookie sent
INFO - 2018-10-18 19:27:57 --> Input Class Initialized
INFO - 2018-10-18 19:27:57 --> Language Class Initialized
INFO - 2018-10-18 19:27:57 --> Loader Class Initialized
INFO - 2018-10-18 19:27:57 --> Helper loaded: url_helper
INFO - 2018-10-18 19:27:57 --> Helper loaded: form_helper
INFO - 2018-10-18 19:27:57 --> Helper loaded: language_helper
DEBUG - 2018-10-18 19:27:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 19:27:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 19:27:57 --> User Agent Class Initialized
INFO - 2018-10-18 19:27:57 --> Controller Class Initialized
INFO - 2018-10-18 19:27:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 19:27:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 19:27:57 --> Helper loaded: custom_helper
INFO - 2018-10-18 19:27:57 --> Pixel_Model class loaded
INFO - 2018-10-18 19:27:57 --> Database Driver Class Initialized
INFO - 2018-10-18 19:27:57 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:27:57 --> Database Driver Class Initialized
INFO - 2018-10-18 19:27:57 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:27:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 19:27:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 19:27:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 19:27:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 19:27:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 19:27:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 19:27:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/merriage_home_title.php
INFO - 2018-10-18 19:27:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 19:27:58 --> Final output sent to browser
DEBUG - 2018-10-18 19:27:58 --> Total execution time: 0.7744
INFO - 2018-10-18 19:28:00 --> Config Class Initialized
INFO - 2018-10-18 19:28:00 --> Hooks Class Initialized
DEBUG - 2018-10-18 19:28:00 --> UTF-8 Support Enabled
INFO - 2018-10-18 19:28:01 --> Utf8 Class Initialized
INFO - 2018-10-18 19:28:01 --> URI Class Initialized
INFO - 2018-10-18 19:28:01 --> Router Class Initialized
INFO - 2018-10-18 19:28:01 --> Output Class Initialized
INFO - 2018-10-18 19:28:01 --> Security Class Initialized
DEBUG - 2018-10-18 19:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 19:28:01 --> CSRF cookie sent
INFO - 2018-10-18 19:28:01 --> CSRF token verified
INFO - 2018-10-18 19:28:01 --> Input Class Initialized
INFO - 2018-10-18 19:28:01 --> Language Class Initialized
INFO - 2018-10-18 19:28:01 --> Loader Class Initialized
INFO - 2018-10-18 19:28:01 --> Helper loaded: url_helper
INFO - 2018-10-18 19:28:01 --> Helper loaded: form_helper
INFO - 2018-10-18 19:28:01 --> Helper loaded: language_helper
DEBUG - 2018-10-18 19:28:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 19:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 19:28:01 --> User Agent Class Initialized
INFO - 2018-10-18 19:28:01 --> Controller Class Initialized
INFO - 2018-10-18 19:28:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 19:28:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 19:28:01 --> Helper loaded: custom_helper
INFO - 2018-10-18 19:28:01 --> Pixel_Model class loaded
INFO - 2018-10-18 19:28:01 --> Database Driver Class Initialized
INFO - 2018-10-18 19:28:01 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:28:01 --> Form Validation Class Initialized
INFO - 2018-10-18 19:28:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 19:28:01 --> Database Driver Class Initialized
INFO - 2018-10-18 19:28:01 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:28:01 --> Config Class Initialized
INFO - 2018-10-18 19:28:01 --> Hooks Class Initialized
DEBUG - 2018-10-18 19:28:01 --> UTF-8 Support Enabled
INFO - 2018-10-18 19:28:01 --> Utf8 Class Initialized
INFO - 2018-10-18 19:28:01 --> URI Class Initialized
INFO - 2018-10-18 19:28:01 --> Router Class Initialized
INFO - 2018-10-18 19:28:01 --> Output Class Initialized
INFO - 2018-10-18 19:28:01 --> Security Class Initialized
DEBUG - 2018-10-18 19:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 19:28:01 --> CSRF cookie sent
INFO - 2018-10-18 19:28:01 --> Input Class Initialized
INFO - 2018-10-18 19:28:01 --> Language Class Initialized
INFO - 2018-10-18 19:28:01 --> Loader Class Initialized
INFO - 2018-10-18 19:28:01 --> Helper loaded: url_helper
INFO - 2018-10-18 19:28:01 --> Helper loaded: form_helper
INFO - 2018-10-18 19:28:02 --> Helper loaded: language_helper
DEBUG - 2018-10-18 19:28:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 19:28:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 19:28:02 --> User Agent Class Initialized
INFO - 2018-10-18 19:28:02 --> Controller Class Initialized
INFO - 2018-10-18 19:28:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 19:28:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 19:28:02 --> Helper loaded: custom_helper
INFO - 2018-10-18 19:28:02 --> Pixel_Model class loaded
INFO - 2018-10-18 19:28:02 --> Database Driver Class Initialized
INFO - 2018-10-18 19:28:02 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:28:02 --> Database Driver Class Initialized
INFO - 2018-10-18 19:28:02 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:28:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 19:28:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 19:28:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 19:28:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 19:28:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-18 19:28:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-18 19:28:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/financial.php
INFO - 2018-10-18 19:28:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 19:28:02 --> Final output sent to browser
DEBUG - 2018-10-18 19:28:02 --> Total execution time: 0.7848
INFO - 2018-10-18 19:28:05 --> Config Class Initialized
INFO - 2018-10-18 19:28:05 --> Hooks Class Initialized
DEBUG - 2018-10-18 19:28:05 --> UTF-8 Support Enabled
INFO - 2018-10-18 19:28:05 --> Utf8 Class Initialized
INFO - 2018-10-18 19:28:05 --> URI Class Initialized
INFO - 2018-10-18 19:28:05 --> Router Class Initialized
INFO - 2018-10-18 19:28:05 --> Output Class Initialized
INFO - 2018-10-18 19:28:05 --> Security Class Initialized
DEBUG - 2018-10-18 19:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 19:28:05 --> CSRF cookie sent
INFO - 2018-10-18 19:28:05 --> CSRF token verified
INFO - 2018-10-18 19:28:05 --> Input Class Initialized
INFO - 2018-10-18 19:28:05 --> Language Class Initialized
INFO - 2018-10-18 19:28:05 --> Loader Class Initialized
INFO - 2018-10-18 19:28:05 --> Helper loaded: url_helper
INFO - 2018-10-18 19:28:05 --> Helper loaded: form_helper
INFO - 2018-10-18 19:28:05 --> Helper loaded: language_helper
DEBUG - 2018-10-18 19:28:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 19:28:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 19:28:05 --> User Agent Class Initialized
INFO - 2018-10-18 19:28:05 --> Controller Class Initialized
INFO - 2018-10-18 19:28:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 19:28:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 19:28:05 --> Helper loaded: custom_helper
INFO - 2018-10-18 19:28:05 --> Pixel_Model class loaded
INFO - 2018-10-18 19:28:05 --> Database Driver Class Initialized
INFO - 2018-10-18 19:28:05 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:28:05 --> Form Validation Class Initialized
INFO - 2018-10-18 19:28:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-18 19:28:05 --> Database Driver Class Initialized
INFO - 2018-10-18 19:28:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:28:06 --> Config Class Initialized
INFO - 2018-10-18 19:28:06 --> Hooks Class Initialized
DEBUG - 2018-10-18 19:28:06 --> UTF-8 Support Enabled
INFO - 2018-10-18 19:28:06 --> Utf8 Class Initialized
INFO - 2018-10-18 19:28:06 --> URI Class Initialized
INFO - 2018-10-18 19:28:06 --> Router Class Initialized
INFO - 2018-10-18 19:28:06 --> Output Class Initialized
INFO - 2018-10-18 19:28:06 --> Security Class Initialized
DEBUG - 2018-10-18 19:28:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 19:28:06 --> CSRF cookie sent
INFO - 2018-10-18 19:28:06 --> Input Class Initialized
INFO - 2018-10-18 19:28:06 --> Language Class Initialized
INFO - 2018-10-18 19:28:06 --> Loader Class Initialized
INFO - 2018-10-18 19:28:06 --> Helper loaded: url_helper
INFO - 2018-10-18 19:28:06 --> Helper loaded: form_helper
INFO - 2018-10-18 19:28:06 --> Helper loaded: language_helper
DEBUG - 2018-10-18 19:28:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 19:28:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 19:28:06 --> User Agent Class Initialized
INFO - 2018-10-18 19:28:06 --> Controller Class Initialized
INFO - 2018-10-18 19:28:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 19:28:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 19:28:06 --> Helper loaded: custom_helper
INFO - 2018-10-18 19:28:06 --> Pixel_Model class loaded
INFO - 2018-10-18 19:28:06 --> Database Driver Class Initialized
INFO - 2018-10-18 19:28:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:28:06 --> Database Driver Class Initialized
INFO - 2018-10-18 19:28:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 19:28:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 19:28:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 19:28:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 19:28:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 19:28:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/risk_report.php
INFO - 2018-10-18 19:28:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 19:28:06 --> Final output sent to browser
DEBUG - 2018-10-18 19:28:06 --> Total execution time: 0.7591
INFO - 2018-10-18 19:28:10 --> Config Class Initialized
INFO - 2018-10-18 19:28:10 --> Hooks Class Initialized
DEBUG - 2018-10-18 19:28:10 --> UTF-8 Support Enabled
INFO - 2018-10-18 19:28:11 --> Utf8 Class Initialized
INFO - 2018-10-18 19:28:11 --> URI Class Initialized
INFO - 2018-10-18 19:28:11 --> Router Class Initialized
INFO - 2018-10-18 19:28:11 --> Output Class Initialized
INFO - 2018-10-18 19:28:11 --> Security Class Initialized
DEBUG - 2018-10-18 19:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 19:28:11 --> CSRF cookie sent
INFO - 2018-10-18 19:28:11 --> Input Class Initialized
INFO - 2018-10-18 19:28:11 --> Language Class Initialized
INFO - 2018-10-18 19:28:11 --> Loader Class Initialized
INFO - 2018-10-18 19:28:11 --> Helper loaded: url_helper
INFO - 2018-10-18 19:28:11 --> Helper loaded: form_helper
INFO - 2018-10-18 19:28:11 --> Helper loaded: language_helper
DEBUG - 2018-10-18 19:28:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 19:28:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 19:28:11 --> User Agent Class Initialized
INFO - 2018-10-18 19:28:11 --> Controller Class Initialized
INFO - 2018-10-18 19:28:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 19:28:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 19:28:11 --> Helper loaded: custom_helper
DEBUG - 2018-10-18 19:28:11 --> Config file loaded: E:\xampp7\htdocs\famiquity\application\config/recaptcha.php
INFO - 2018-10-18 19:28:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 19:28:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 19:28:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 19:28:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
ERROR - 2018-10-18 19:28:11 --> Could not find the language line "req_email"
INFO - 2018-10-18 19:28:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\myaccount/signin.php
INFO - 2018-10-18 19:28:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 19:28:11 --> Final output sent to browser
DEBUG - 2018-10-18 19:28:11 --> Total execution time: 0.8423
INFO - 2018-10-18 19:28:52 --> Config Class Initialized
INFO - 2018-10-18 19:28:52 --> Hooks Class Initialized
DEBUG - 2018-10-18 19:28:52 --> UTF-8 Support Enabled
INFO - 2018-10-18 19:28:52 --> Utf8 Class Initialized
INFO - 2018-10-18 19:28:52 --> URI Class Initialized
INFO - 2018-10-18 19:28:52 --> Router Class Initialized
INFO - 2018-10-18 19:28:52 --> Output Class Initialized
INFO - 2018-10-18 19:28:52 --> Security Class Initialized
DEBUG - 2018-10-18 19:28:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 19:28:52 --> CSRF cookie sent
INFO - 2018-10-18 19:28:52 --> Input Class Initialized
INFO - 2018-10-18 19:28:52 --> Language Class Initialized
INFO - 2018-10-18 19:28:52 --> Loader Class Initialized
INFO - 2018-10-18 19:28:52 --> Helper loaded: url_helper
INFO - 2018-10-18 19:28:52 --> Helper loaded: form_helper
INFO - 2018-10-18 19:28:53 --> Helper loaded: language_helper
DEBUG - 2018-10-18 19:28:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 19:28:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 19:28:53 --> User Agent Class Initialized
INFO - 2018-10-18 19:28:53 --> Controller Class Initialized
INFO - 2018-10-18 19:28:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 19:28:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 19:28:53 --> Helper loaded: custom_helper
DEBUG - 2018-10-18 19:28:53 --> Config file loaded: E:\xampp7\htdocs\famiquity\application\config/recaptcha.php
INFO - 2018-10-18 19:28:53 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 19:28:53 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 19:28:53 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 19:28:53 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
ERROR - 2018-10-18 19:28:53 --> Could not find the language line "req_email"
INFO - 2018-10-18 19:28:53 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\myaccount/signin.php
INFO - 2018-10-18 19:28:53 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 19:28:53 --> Final output sent to browser
DEBUG - 2018-10-18 19:28:53 --> Total execution time: 0.7017
INFO - 2018-10-18 19:28:57 --> Config Class Initialized
INFO - 2018-10-18 19:28:57 --> Hooks Class Initialized
DEBUG - 2018-10-18 19:28:57 --> UTF-8 Support Enabled
INFO - 2018-10-18 19:28:57 --> Utf8 Class Initialized
INFO - 2018-10-18 19:28:57 --> URI Class Initialized
INFO - 2018-10-18 19:28:57 --> Router Class Initialized
INFO - 2018-10-18 19:28:57 --> Output Class Initialized
INFO - 2018-10-18 19:28:57 --> Security Class Initialized
DEBUG - 2018-10-18 19:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 19:28:57 --> CSRF cookie sent
INFO - 2018-10-18 19:28:57 --> CSRF token verified
INFO - 2018-10-18 19:28:57 --> Input Class Initialized
INFO - 2018-10-18 19:28:57 --> Language Class Initialized
INFO - 2018-10-18 19:28:57 --> Loader Class Initialized
INFO - 2018-10-18 19:28:57 --> Helper loaded: url_helper
INFO - 2018-10-18 19:28:57 --> Helper loaded: form_helper
INFO - 2018-10-18 19:28:57 --> Helper loaded: language_helper
DEBUG - 2018-10-18 19:28:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 19:28:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 19:28:57 --> User Agent Class Initialized
INFO - 2018-10-18 19:28:57 --> Controller Class Initialized
INFO - 2018-10-18 19:28:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 19:28:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 19:28:58 --> Helper loaded: custom_helper
INFO - 2018-10-18 19:28:58 --> Form Validation Class Initialized
INFO - 2018-10-18 19:28:58 --> Pixel_Model class loaded
ERROR - 2018-10-18 19:28:58 --> Severity: error --> Exception: syntax error, unexpected 'return' (T_RETURN), expecting function (T_FUNCTION) or const (T_CONST) E:\xampp7\htdocs\famiquity\application\models\AuthenticationModel.php 74
INFO - 2018-10-18 19:29:00 --> Config Class Initialized
INFO - 2018-10-18 19:29:00 --> Hooks Class Initialized
DEBUG - 2018-10-18 19:29:00 --> UTF-8 Support Enabled
INFO - 2018-10-18 19:29:00 --> Utf8 Class Initialized
INFO - 2018-10-18 19:29:00 --> URI Class Initialized
INFO - 2018-10-18 19:29:00 --> Router Class Initialized
INFO - 2018-10-18 19:29:00 --> Output Class Initialized
INFO - 2018-10-18 19:29:00 --> Security Class Initialized
DEBUG - 2018-10-18 19:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 19:29:00 --> CSRF cookie sent
INFO - 2018-10-18 19:29:00 --> Input Class Initialized
INFO - 2018-10-18 19:29:00 --> Language Class Initialized
INFO - 2018-10-18 19:29:00 --> Loader Class Initialized
INFO - 2018-10-18 19:29:00 --> Helper loaded: url_helper
INFO - 2018-10-18 19:29:00 --> Helper loaded: form_helper
INFO - 2018-10-18 19:29:00 --> Helper loaded: language_helper
DEBUG - 2018-10-18 19:29:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 19:29:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 19:29:00 --> User Agent Class Initialized
INFO - 2018-10-18 19:29:00 --> Controller Class Initialized
INFO - 2018-10-18 19:29:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 19:29:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 19:29:00 --> Helper loaded: custom_helper
INFO - 2018-10-18 19:29:00 --> Form Validation Class Initialized
INFO - 2018-10-18 19:29:01 --> Config Class Initialized
INFO - 2018-10-18 19:29:01 --> Hooks Class Initialized
DEBUG - 2018-10-18 19:29:01 --> UTF-8 Support Enabled
INFO - 2018-10-18 19:29:01 --> Utf8 Class Initialized
INFO - 2018-10-18 19:29:01 --> URI Class Initialized
INFO - 2018-10-18 19:29:01 --> Router Class Initialized
INFO - 2018-10-18 19:29:01 --> Output Class Initialized
INFO - 2018-10-18 19:29:01 --> Security Class Initialized
DEBUG - 2018-10-18 19:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 19:29:01 --> CSRF cookie sent
INFO - 2018-10-18 19:29:01 --> Input Class Initialized
INFO - 2018-10-18 19:29:01 --> Language Class Initialized
INFO - 2018-10-18 19:29:01 --> Loader Class Initialized
INFO - 2018-10-18 19:29:01 --> Helper loaded: url_helper
INFO - 2018-10-18 19:29:01 --> Helper loaded: form_helper
INFO - 2018-10-18 19:29:01 --> Helper loaded: language_helper
DEBUG - 2018-10-18 19:29:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 19:29:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 19:29:01 --> User Agent Class Initialized
INFO - 2018-10-18 19:29:01 --> Controller Class Initialized
INFO - 2018-10-18 19:29:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 19:29:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 19:29:01 --> Helper loaded: custom_helper
DEBUG - 2018-10-18 19:29:01 --> Config file loaded: E:\xampp7\htdocs\famiquity\application\config/recaptcha.php
INFO - 2018-10-18 19:29:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 19:29:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 19:29:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 19:29:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
ERROR - 2018-10-18 19:29:01 --> Could not find the language line "req_email"
INFO - 2018-10-18 19:29:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\myaccount/signin.php
INFO - 2018-10-18 19:29:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 19:29:01 --> Final output sent to browser
DEBUG - 2018-10-18 19:29:01 --> Total execution time: 0.6527
INFO - 2018-10-18 19:29:11 --> Config Class Initialized
INFO - 2018-10-18 19:29:11 --> Hooks Class Initialized
DEBUG - 2018-10-18 19:29:11 --> UTF-8 Support Enabled
INFO - 2018-10-18 19:29:11 --> Utf8 Class Initialized
INFO - 2018-10-18 19:29:11 --> URI Class Initialized
INFO - 2018-10-18 19:29:11 --> Router Class Initialized
INFO - 2018-10-18 19:29:11 --> Output Class Initialized
INFO - 2018-10-18 19:29:11 --> Security Class Initialized
DEBUG - 2018-10-18 19:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 19:29:11 --> CSRF cookie sent
INFO - 2018-10-18 19:29:11 --> CSRF token verified
INFO - 2018-10-18 19:29:11 --> Input Class Initialized
INFO - 2018-10-18 19:29:11 --> Language Class Initialized
INFO - 2018-10-18 19:29:11 --> Loader Class Initialized
INFO - 2018-10-18 19:29:11 --> Helper loaded: url_helper
INFO - 2018-10-18 19:29:11 --> Helper loaded: form_helper
INFO - 2018-10-18 19:29:11 --> Helper loaded: language_helper
DEBUG - 2018-10-18 19:29:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 19:29:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 19:29:11 --> User Agent Class Initialized
INFO - 2018-10-18 19:29:11 --> Controller Class Initialized
INFO - 2018-10-18 19:29:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 19:29:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 19:29:11 --> Helper loaded: custom_helper
INFO - 2018-10-18 19:29:11 --> Form Validation Class Initialized
INFO - 2018-10-18 19:29:11 --> Pixel_Model class loaded
ERROR - 2018-10-18 19:29:11 --> Severity: error --> Exception: syntax error, unexpected 'return' (T_RETURN), expecting function (T_FUNCTION) or const (T_CONST) E:\xampp7\htdocs\famiquity\application\models\AuthenticationModel.php 74
INFO - 2018-10-18 19:40:29 --> Config Class Initialized
INFO - 2018-10-18 19:40:29 --> Hooks Class Initialized
DEBUG - 2018-10-18 19:40:29 --> UTF-8 Support Enabled
INFO - 2018-10-18 19:40:29 --> Utf8 Class Initialized
INFO - 2018-10-18 19:40:30 --> URI Class Initialized
INFO - 2018-10-18 19:40:30 --> Router Class Initialized
INFO - 2018-10-18 19:40:30 --> Output Class Initialized
INFO - 2018-10-18 19:40:30 --> Security Class Initialized
DEBUG - 2018-10-18 19:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 19:40:30 --> CSRF cookie sent
INFO - 2018-10-18 19:40:30 --> Input Class Initialized
INFO - 2018-10-18 19:40:30 --> Language Class Initialized
INFO - 2018-10-18 19:40:30 --> Loader Class Initialized
INFO - 2018-10-18 19:40:30 --> Helper loaded: url_helper
INFO - 2018-10-18 19:40:30 --> Helper loaded: form_helper
INFO - 2018-10-18 19:40:30 --> Helper loaded: language_helper
DEBUG - 2018-10-18 19:40:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 19:40:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 19:40:30 --> User Agent Class Initialized
INFO - 2018-10-18 19:40:30 --> Controller Class Initialized
INFO - 2018-10-18 19:40:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 19:40:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 19:40:30 --> Helper loaded: custom_helper
INFO - 2018-10-18 19:40:30 --> Pixel_Model class loaded
INFO - 2018-10-18 19:40:30 --> Database Driver Class Initialized
INFO - 2018-10-18 19:40:30 --> Model "RegistrationModel" initialized
DEBUG - 2018-10-18 19:40:30 --> Config file loaded: E:\xampp7\htdocs\famiquity\application\config/recaptcha.php
INFO - 2018-10-18 19:40:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 19:40:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 19:40:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 19:40:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
ERROR - 2018-10-18 19:40:30 --> Could not find the language line "req_email"
INFO - 2018-10-18 19:40:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\register/signup.php
INFO - 2018-10-18 19:40:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 19:40:30 --> Final output sent to browser
DEBUG - 2018-10-18 19:40:30 --> Total execution time: 0.8357
INFO - 2018-10-18 19:40:40 --> Config Class Initialized
INFO - 2018-10-18 19:40:40 --> Hooks Class Initialized
DEBUG - 2018-10-18 19:40:40 --> UTF-8 Support Enabled
INFO - 2018-10-18 19:40:40 --> Utf8 Class Initialized
INFO - 2018-10-18 19:40:40 --> URI Class Initialized
INFO - 2018-10-18 19:40:40 --> Router Class Initialized
INFO - 2018-10-18 19:40:40 --> Output Class Initialized
INFO - 2018-10-18 19:40:40 --> Security Class Initialized
DEBUG - 2018-10-18 19:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 19:40:40 --> CSRF cookie sent
INFO - 2018-10-18 19:40:40 --> Input Class Initialized
INFO - 2018-10-18 19:40:40 --> Language Class Initialized
ERROR - 2018-10-18 19:40:40 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 20:07:18 --> Config Class Initialized
INFO - 2018-10-18 20:07:18 --> Hooks Class Initialized
DEBUG - 2018-10-18 20:07:18 --> UTF-8 Support Enabled
INFO - 2018-10-18 20:07:18 --> Utf8 Class Initialized
INFO - 2018-10-18 20:07:18 --> URI Class Initialized
INFO - 2018-10-18 20:07:18 --> Router Class Initialized
INFO - 2018-10-18 20:07:18 --> Output Class Initialized
INFO - 2018-10-18 20:07:18 --> Security Class Initialized
DEBUG - 2018-10-18 20:07:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 20:07:18 --> CSRF cookie sent
INFO - 2018-10-18 20:07:18 --> Input Class Initialized
INFO - 2018-10-18 20:07:18 --> Language Class Initialized
INFO - 2018-10-18 20:07:18 --> Loader Class Initialized
INFO - 2018-10-18 20:07:18 --> Helper loaded: url_helper
INFO - 2018-10-18 20:07:18 --> Helper loaded: form_helper
INFO - 2018-10-18 20:07:18 --> Helper loaded: language_helper
DEBUG - 2018-10-18 20:07:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 20:07:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 20:07:18 --> User Agent Class Initialized
INFO - 2018-10-18 20:07:18 --> Controller Class Initialized
INFO - 2018-10-18 20:07:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 20:07:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 20:07:18 --> Helper loaded: custom_helper
INFO - 2018-10-18 20:07:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 20:07:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 20:07:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 20:07:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 20:07:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\register/terms.php
INFO - 2018-10-18 20:07:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 20:07:18 --> Final output sent to browser
DEBUG - 2018-10-18 20:07:18 --> Total execution time: 0.6379
INFO - 2018-10-18 20:07:19 --> Config Class Initialized
INFO - 2018-10-18 20:07:19 --> Hooks Class Initialized
DEBUG - 2018-10-18 20:07:19 --> UTF-8 Support Enabled
INFO - 2018-10-18 20:07:19 --> Utf8 Class Initialized
INFO - 2018-10-18 20:07:19 --> URI Class Initialized
INFO - 2018-10-18 20:07:19 --> Router Class Initialized
INFO - 2018-10-18 20:07:19 --> Output Class Initialized
INFO - 2018-10-18 20:07:19 --> Security Class Initialized
DEBUG - 2018-10-18 20:07:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 20:07:19 --> CSRF cookie sent
INFO - 2018-10-18 20:07:19 --> Input Class Initialized
INFO - 2018-10-18 20:07:19 --> Language Class Initialized
ERROR - 2018-10-18 20:07:19 --> 404 Page Not Found: Assets/css
INFO - 2018-10-18 20:08:02 --> Config Class Initialized
INFO - 2018-10-18 20:08:02 --> Hooks Class Initialized
DEBUG - 2018-10-18 20:08:02 --> UTF-8 Support Enabled
INFO - 2018-10-18 20:08:02 --> Utf8 Class Initialized
INFO - 2018-10-18 20:08:03 --> URI Class Initialized
INFO - 2018-10-18 20:08:03 --> Router Class Initialized
INFO - 2018-10-18 20:08:03 --> Output Class Initialized
INFO - 2018-10-18 20:08:03 --> Security Class Initialized
DEBUG - 2018-10-18 20:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 20:08:03 --> CSRF cookie sent
INFO - 2018-10-18 20:08:03 --> Input Class Initialized
INFO - 2018-10-18 20:08:03 --> Language Class Initialized
INFO - 2018-10-18 20:08:03 --> Loader Class Initialized
INFO - 2018-10-18 20:08:03 --> Helper loaded: url_helper
INFO - 2018-10-18 20:08:03 --> Helper loaded: form_helper
INFO - 2018-10-18 20:08:03 --> Helper loaded: language_helper
DEBUG - 2018-10-18 20:08:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 20:08:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 20:08:03 --> User Agent Class Initialized
INFO - 2018-10-18 20:08:03 --> Controller Class Initialized
INFO - 2018-10-18 20:08:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 20:08:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 20:08:03 --> Helper loaded: custom_helper
INFO - 2018-10-18 20:08:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 20:08:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 20:08:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 20:08:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 20:08:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\register/terms.php
INFO - 2018-10-18 20:08:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 20:08:03 --> Final output sent to browser
DEBUG - 2018-10-18 20:08:03 --> Total execution time: 0.6329
INFO - 2018-10-18 20:08:10 --> Config Class Initialized
INFO - 2018-10-18 20:08:10 --> Hooks Class Initialized
DEBUG - 2018-10-18 20:08:10 --> UTF-8 Support Enabled
INFO - 2018-10-18 20:08:10 --> Utf8 Class Initialized
INFO - 2018-10-18 20:08:10 --> URI Class Initialized
INFO - 2018-10-18 20:08:10 --> Router Class Initialized
INFO - 2018-10-18 20:08:10 --> Output Class Initialized
INFO - 2018-10-18 20:08:10 --> Security Class Initialized
DEBUG - 2018-10-18 20:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 20:08:10 --> CSRF cookie sent
INFO - 2018-10-18 20:08:10 --> Input Class Initialized
INFO - 2018-10-18 20:08:10 --> Language Class Initialized
INFO - 2018-10-18 20:08:10 --> Loader Class Initialized
INFO - 2018-10-18 20:08:10 --> Helper loaded: url_helper
INFO - 2018-10-18 20:08:10 --> Helper loaded: form_helper
INFO - 2018-10-18 20:08:10 --> Helper loaded: language_helper
DEBUG - 2018-10-18 20:08:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 20:08:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 20:08:10 --> User Agent Class Initialized
INFO - 2018-10-18 20:08:10 --> Controller Class Initialized
INFO - 2018-10-18 20:08:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 20:08:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 20:08:10 --> Helper loaded: custom_helper
INFO - 2018-10-18 20:08:10 --> Pixel_Model class loaded
INFO - 2018-10-18 20:08:10 --> Database Driver Class Initialized
INFO - 2018-10-18 20:08:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-18 20:08:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 20:08:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 20:08:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 20:08:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 20:08:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/contact_us.php
INFO - 2018-10-18 20:08:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 20:08:10 --> Final output sent to browser
DEBUG - 2018-10-18 20:08:10 --> Total execution time: 0.7490
INFO - 2018-10-18 20:08:33 --> Config Class Initialized
INFO - 2018-10-18 20:08:33 --> Hooks Class Initialized
DEBUG - 2018-10-18 20:08:33 --> UTF-8 Support Enabled
INFO - 2018-10-18 20:08:33 --> Utf8 Class Initialized
INFO - 2018-10-18 20:08:33 --> URI Class Initialized
INFO - 2018-10-18 20:08:33 --> Router Class Initialized
INFO - 2018-10-18 20:08:33 --> Output Class Initialized
INFO - 2018-10-18 20:08:33 --> Security Class Initialized
DEBUG - 2018-10-18 20:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 20:08:33 --> CSRF cookie sent
INFO - 2018-10-18 20:08:33 --> Input Class Initialized
INFO - 2018-10-18 20:08:33 --> Language Class Initialized
INFO - 2018-10-18 20:08:33 --> Loader Class Initialized
INFO - 2018-10-18 20:08:33 --> Helper loaded: url_helper
INFO - 2018-10-18 20:08:33 --> Helper loaded: form_helper
INFO - 2018-10-18 20:08:33 --> Helper loaded: language_helper
DEBUG - 2018-10-18 20:08:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-18 20:08:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-18 20:08:34 --> User Agent Class Initialized
INFO - 2018-10-18 20:08:34 --> Controller Class Initialized
INFO - 2018-10-18 20:08:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-18 20:08:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-18 20:08:34 --> Helper loaded: custom_helper
INFO - 2018-10-18 20:08:34 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-18 20:08:34 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-18 20:08:34 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-18 20:08:34 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-18 20:08:34 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\register/terms.php
INFO - 2018-10-18 20:08:34 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-18 20:08:34 --> Final output sent to browser
DEBUG - 2018-10-18 20:08:34 --> Total execution time: 0.6349
INFO - 2018-10-18 20:59:29 --> Config Class Initialized
INFO - 2018-10-18 20:59:29 --> Hooks Class Initialized
DEBUG - 2018-10-18 20:59:29 --> UTF-8 Support Enabled
INFO - 2018-10-18 20:59:29 --> Utf8 Class Initialized
INFO - 2018-10-18 20:59:29 --> URI Class Initialized
INFO - 2018-10-18 20:59:29 --> Router Class Initialized
INFO - 2018-10-18 20:59:29 --> Output Class Initialized
INFO - 2018-10-18 20:59:29 --> Security Class Initialized
DEBUG - 2018-10-18 20:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-18 20:59:30 --> CSRF cookie sent
INFO - 2018-10-18 20:59:30 --> Input Class Initialized
INFO - 2018-10-18 20:59:30 --> Language Class Initialized
ERROR - 2018-10-18 20:59:30 --> 404 Page Not Found: Contact/index

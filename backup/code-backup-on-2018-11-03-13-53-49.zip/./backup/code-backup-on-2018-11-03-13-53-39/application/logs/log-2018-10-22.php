<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-10-22 12:15:01 --> Config Class Initialized
INFO - 2018-10-22 12:15:01 --> Hooks Class Initialized
DEBUG - 2018-10-22 12:15:01 --> UTF-8 Support Enabled
INFO - 2018-10-22 12:15:01 --> Utf8 Class Initialized
INFO - 2018-10-22 12:15:01 --> URI Class Initialized
INFO - 2018-10-22 12:15:01 --> Router Class Initialized
INFO - 2018-10-22 12:15:01 --> Output Class Initialized
INFO - 2018-10-22 12:15:01 --> Security Class Initialized
DEBUG - 2018-10-22 12:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 12:15:01 --> CSRF cookie sent
INFO - 2018-10-22 12:15:01 --> Input Class Initialized
INFO - 2018-10-22 12:15:01 --> Language Class Initialized
INFO - 2018-10-22 12:15:01 --> Loader Class Initialized
INFO - 2018-10-22 12:15:01 --> Helper loaded: url_helper
INFO - 2018-10-22 12:15:01 --> Helper loaded: form_helper
INFO - 2018-10-22 12:15:01 --> Helper loaded: language_helper
DEBUG - 2018-10-22 12:15:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 12:15:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 12:15:01 --> User Agent Class Initialized
INFO - 2018-10-22 12:15:01 --> Controller Class Initialized
INFO - 2018-10-22 12:15:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 12:15:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 12:15:01 --> Helper loaded: custom_helper
INFO - 2018-10-22 12:15:01 --> Pixel_Model class loaded
INFO - 2018-10-22 12:15:01 --> Database Driver Class Initialized
ERROR - 2018-10-22 12:15:01 --> Unable to connect to the database
INFO - 2018-10-22 12:15:01 --> Model "QuestionsModel" initialized
ERROR - 2018-10-22 12:15:01 --> Unable to connect to the database
ERROR - 2018-10-22 12:15:01 --> Query error: php_network_getaddresses: getaddrinfo failed: No such host is known.  - Invalid query: SELECT *
FROM `questions`
WHERE `status` = 1
ERROR - 2018-10-22 12:15:01 --> Severity: error --> Exception: Call to a member function num_rows() on boolean E:\xampp7\htdocs\famiquity\application\models\QuestionsModel.php 25
INFO - 2018-10-22 12:15:05 --> Config Class Initialized
INFO - 2018-10-22 12:15:05 --> Hooks Class Initialized
DEBUG - 2018-10-22 12:15:05 --> UTF-8 Support Enabled
INFO - 2018-10-22 12:15:05 --> Utf8 Class Initialized
INFO - 2018-10-22 12:15:05 --> URI Class Initialized
INFO - 2018-10-22 12:15:05 --> Router Class Initialized
INFO - 2018-10-22 12:15:05 --> Output Class Initialized
INFO - 2018-10-22 12:15:05 --> Security Class Initialized
DEBUG - 2018-10-22 12:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 12:15:05 --> CSRF cookie sent
INFO - 2018-10-22 12:15:05 --> Input Class Initialized
INFO - 2018-10-22 12:15:05 --> Language Class Initialized
INFO - 2018-10-22 12:15:05 --> Loader Class Initialized
INFO - 2018-10-22 12:15:05 --> Helper loaded: url_helper
INFO - 2018-10-22 12:15:05 --> Helper loaded: form_helper
INFO - 2018-10-22 12:15:05 --> Helper loaded: language_helper
DEBUG - 2018-10-22 12:15:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 12:15:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 12:15:05 --> User Agent Class Initialized
INFO - 2018-10-22 12:15:05 --> Controller Class Initialized
INFO - 2018-10-22 12:15:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 12:15:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 12:15:05 --> Helper loaded: custom_helper
INFO - 2018-10-22 12:15:05 --> Pixel_Model class loaded
INFO - 2018-10-22 12:15:05 --> Database Driver Class Initialized
ERROR - 2018-10-22 12:15:05 --> Unable to connect to the database
INFO - 2018-10-22 12:15:05 --> Model "QuestionsModel" initialized
ERROR - 2018-10-22 12:15:05 --> Unable to connect to the database
ERROR - 2018-10-22 12:15:05 --> Query error: php_network_getaddresses: getaddrinfo failed: No such host is known.  - Invalid query: SELECT *
FROM `questions`
WHERE `status` = 1
ERROR - 2018-10-22 12:15:05 --> Severity: error --> Exception: Call to a member function num_rows() on boolean E:\xampp7\htdocs\famiquity\application\models\QuestionsModel.php 25
INFO - 2018-10-22 12:38:16 --> Config Class Initialized
INFO - 2018-10-22 12:38:16 --> Hooks Class Initialized
DEBUG - 2018-10-22 12:38:16 --> UTF-8 Support Enabled
INFO - 2018-10-22 12:38:16 --> Utf8 Class Initialized
INFO - 2018-10-22 12:38:16 --> URI Class Initialized
DEBUG - 2018-10-22 12:38:16 --> No URI present. Default controller set.
INFO - 2018-10-22 12:38:16 --> Router Class Initialized
INFO - 2018-10-22 12:38:16 --> Output Class Initialized
INFO - 2018-10-22 12:38:16 --> Security Class Initialized
DEBUG - 2018-10-22 12:38:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 12:38:16 --> CSRF cookie sent
INFO - 2018-10-22 12:38:16 --> Input Class Initialized
INFO - 2018-10-22 12:38:16 --> Language Class Initialized
INFO - 2018-10-22 12:38:16 --> Loader Class Initialized
INFO - 2018-10-22 12:38:16 --> Helper loaded: url_helper
INFO - 2018-10-22 12:38:16 --> Helper loaded: form_helper
INFO - 2018-10-22 12:38:16 --> Helper loaded: language_helper
DEBUG - 2018-10-22 12:38:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 12:38:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 12:38:16 --> User Agent Class Initialized
INFO - 2018-10-22 12:38:16 --> Controller Class Initialized
INFO - 2018-10-22 12:38:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 12:38:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 12:38:16 --> Helper loaded: custom_helper
INFO - 2018-10-22 12:38:16 --> Pixel_Model class loaded
INFO - 2018-10-22 12:38:16 --> Database Driver Class Initialized
ERROR - 2018-10-22 12:38:17 --> Unable to connect to the database
INFO - 2018-10-22 12:38:17 --> Model "QuestionsModel" initialized
ERROR - 2018-10-22 12:38:17 --> Unable to connect to the database
ERROR - 2018-10-22 12:38:17 --> Query error: php_network_getaddresses: getaddrinfo failed: No such host is known.  - Invalid query: SELECT *
FROM `questions`
WHERE `status` = 1
ERROR - 2018-10-22 12:38:17 --> Severity: error --> Exception: Call to a member function num_rows() on boolean E:\xampp7\htdocs\famiquity\application\models\QuestionsModel.php 25
INFO - 2018-10-22 12:39:06 --> Config Class Initialized
INFO - 2018-10-22 12:39:06 --> Hooks Class Initialized
DEBUG - 2018-10-22 12:39:06 --> UTF-8 Support Enabled
INFO - 2018-10-22 12:39:06 --> Utf8 Class Initialized
INFO - 2018-10-22 12:39:06 --> URI Class Initialized
DEBUG - 2018-10-22 12:39:06 --> No URI present. Default controller set.
INFO - 2018-10-22 12:39:06 --> Router Class Initialized
INFO - 2018-10-22 12:39:06 --> Output Class Initialized
INFO - 2018-10-22 12:39:06 --> Security Class Initialized
DEBUG - 2018-10-22 12:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 12:39:06 --> CSRF cookie sent
INFO - 2018-10-22 12:39:06 --> Input Class Initialized
INFO - 2018-10-22 12:39:06 --> Language Class Initialized
INFO - 2018-10-22 12:39:06 --> Loader Class Initialized
INFO - 2018-10-22 12:39:06 --> Helper loaded: url_helper
INFO - 2018-10-22 12:39:06 --> Helper loaded: form_helper
INFO - 2018-10-22 12:39:06 --> Helper loaded: language_helper
DEBUG - 2018-10-22 12:39:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 12:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 12:39:06 --> User Agent Class Initialized
INFO - 2018-10-22 12:39:06 --> Controller Class Initialized
INFO - 2018-10-22 12:39:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 12:39:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 12:39:06 --> Helper loaded: custom_helper
INFO - 2018-10-22 12:39:06 --> Pixel_Model class loaded
INFO - 2018-10-22 12:39:06 --> Database Driver Class Initialized
INFO - 2018-10-22 12:39:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 12:39:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 12:39:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 12:39:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-22 12:39:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 12:39:06 --> Final output sent to browser
DEBUG - 2018-10-22 12:39:06 --> Total execution time: 0.2688
INFO - 2018-10-22 12:39:08 --> Config Class Initialized
INFO - 2018-10-22 12:39:08 --> Hooks Class Initialized
DEBUG - 2018-10-22 12:39:08 --> UTF-8 Support Enabled
INFO - 2018-10-22 12:39:08 --> Utf8 Class Initialized
INFO - 2018-10-22 12:39:08 --> URI Class Initialized
INFO - 2018-10-22 12:39:08 --> Router Class Initialized
INFO - 2018-10-22 12:39:08 --> Output Class Initialized
INFO - 2018-10-22 12:39:08 --> Security Class Initialized
DEBUG - 2018-10-22 12:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 12:39:08 --> CSRF cookie sent
INFO - 2018-10-22 12:39:08 --> Input Class Initialized
INFO - 2018-10-22 12:39:08 --> Language Class Initialized
INFO - 2018-10-22 12:39:08 --> Loader Class Initialized
INFO - 2018-10-22 12:39:08 --> Helper loaded: url_helper
INFO - 2018-10-22 12:39:08 --> Helper loaded: form_helper
INFO - 2018-10-22 12:39:08 --> Helper loaded: language_helper
DEBUG - 2018-10-22 12:39:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 12:39:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 12:39:08 --> User Agent Class Initialized
INFO - 2018-10-22 12:39:08 --> Controller Class Initialized
INFO - 2018-10-22 12:39:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 12:39:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 12:39:08 --> Helper loaded: custom_helper
INFO - 2018-10-22 12:39:08 --> Pixel_Model class loaded
INFO - 2018-10-22 12:39:08 --> Database Driver Class Initialized
INFO - 2018-10-22 12:39:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 12:39:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 12:39:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 12:39:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 12:39:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 12:39:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 12:39:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 12:39:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-22 12:39:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 12:39:08 --> Final output sent to browser
DEBUG - 2018-10-22 12:39:08 --> Total execution time: 0.3849
INFO - 2018-10-22 12:39:11 --> Config Class Initialized
INFO - 2018-10-22 12:39:11 --> Hooks Class Initialized
DEBUG - 2018-10-22 12:39:11 --> UTF-8 Support Enabled
INFO - 2018-10-22 12:39:11 --> Utf8 Class Initialized
INFO - 2018-10-22 12:39:11 --> URI Class Initialized
INFO - 2018-10-22 12:39:11 --> Router Class Initialized
INFO - 2018-10-22 12:39:11 --> Output Class Initialized
INFO - 2018-10-22 12:39:11 --> Security Class Initialized
DEBUG - 2018-10-22 12:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 12:39:11 --> CSRF cookie sent
INFO - 2018-10-22 12:39:11 --> CSRF token verified
INFO - 2018-10-22 12:39:11 --> Input Class Initialized
INFO - 2018-10-22 12:39:11 --> Language Class Initialized
INFO - 2018-10-22 12:39:11 --> Loader Class Initialized
INFO - 2018-10-22 12:39:11 --> Helper loaded: url_helper
INFO - 2018-10-22 12:39:11 --> Helper loaded: form_helper
INFO - 2018-10-22 12:39:11 --> Helper loaded: language_helper
DEBUG - 2018-10-22 12:39:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 12:39:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 12:39:11 --> User Agent Class Initialized
INFO - 2018-10-22 12:39:11 --> Controller Class Initialized
INFO - 2018-10-22 12:39:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 12:39:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 12:39:11 --> Helper loaded: custom_helper
INFO - 2018-10-22 12:39:11 --> Pixel_Model class loaded
INFO - 2018-10-22 12:39:11 --> Database Driver Class Initialized
INFO - 2018-10-22 12:39:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 12:39:11 --> Form Validation Class Initialized
INFO - 2018-10-22 12:39:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 12:39:11 --> Database Driver Class Initialized
INFO - 2018-10-22 12:39:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 12:39:11 --> Config Class Initialized
INFO - 2018-10-22 12:39:11 --> Hooks Class Initialized
DEBUG - 2018-10-22 12:39:11 --> UTF-8 Support Enabled
INFO - 2018-10-22 12:39:11 --> Utf8 Class Initialized
INFO - 2018-10-22 12:39:11 --> URI Class Initialized
INFO - 2018-10-22 12:39:11 --> Router Class Initialized
INFO - 2018-10-22 12:39:11 --> Output Class Initialized
INFO - 2018-10-22 12:39:11 --> Security Class Initialized
DEBUG - 2018-10-22 12:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 12:39:11 --> CSRF cookie sent
INFO - 2018-10-22 12:39:11 --> Input Class Initialized
INFO - 2018-10-22 12:39:11 --> Language Class Initialized
INFO - 2018-10-22 12:39:11 --> Loader Class Initialized
INFO - 2018-10-22 12:39:11 --> Helper loaded: url_helper
INFO - 2018-10-22 12:39:11 --> Helper loaded: form_helper
INFO - 2018-10-22 12:39:11 --> Helper loaded: language_helper
DEBUG - 2018-10-22 12:39:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 12:39:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 12:39:11 --> User Agent Class Initialized
INFO - 2018-10-22 12:39:11 --> Controller Class Initialized
INFO - 2018-10-22 12:39:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 12:39:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 12:39:11 --> Helper loaded: custom_helper
INFO - 2018-10-22 12:39:11 --> Pixel_Model class loaded
INFO - 2018-10-22 12:39:11 --> Database Driver Class Initialized
INFO - 2018-10-22 12:39:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 12:39:11 --> Database Driver Class Initialized
INFO - 2018-10-22 12:39:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 12:39:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 12:39:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 12:39:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 12:39:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 12:39:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 12:39:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 12:39:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-22 12:39:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 12:39:11 --> Final output sent to browser
DEBUG - 2018-10-22 12:39:11 --> Total execution time: 0.3254
INFO - 2018-10-22 12:39:14 --> Config Class Initialized
INFO - 2018-10-22 12:39:14 --> Hooks Class Initialized
DEBUG - 2018-10-22 12:39:15 --> UTF-8 Support Enabled
INFO - 2018-10-22 12:39:15 --> Utf8 Class Initialized
INFO - 2018-10-22 12:39:15 --> URI Class Initialized
INFO - 2018-10-22 12:39:15 --> Router Class Initialized
INFO - 2018-10-22 12:39:15 --> Output Class Initialized
INFO - 2018-10-22 12:39:15 --> Security Class Initialized
DEBUG - 2018-10-22 12:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 12:39:15 --> CSRF cookie sent
INFO - 2018-10-22 12:39:15 --> CSRF token verified
INFO - 2018-10-22 12:39:15 --> Input Class Initialized
INFO - 2018-10-22 12:39:15 --> Language Class Initialized
INFO - 2018-10-22 12:39:15 --> Loader Class Initialized
INFO - 2018-10-22 12:39:15 --> Helper loaded: url_helper
INFO - 2018-10-22 12:39:15 --> Helper loaded: form_helper
INFO - 2018-10-22 12:39:15 --> Helper loaded: language_helper
DEBUG - 2018-10-22 12:39:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 12:39:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 12:39:15 --> User Agent Class Initialized
INFO - 2018-10-22 12:39:15 --> Controller Class Initialized
INFO - 2018-10-22 12:39:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 12:39:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 12:39:15 --> Helper loaded: custom_helper
INFO - 2018-10-22 12:39:15 --> Pixel_Model class loaded
INFO - 2018-10-22 12:39:15 --> Database Driver Class Initialized
INFO - 2018-10-22 12:39:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 12:39:15 --> Form Validation Class Initialized
INFO - 2018-10-22 12:39:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 12:39:15 --> Database Driver Class Initialized
INFO - 2018-10-22 12:39:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 12:39:15 --> Config Class Initialized
INFO - 2018-10-22 12:39:15 --> Hooks Class Initialized
DEBUG - 2018-10-22 12:39:15 --> UTF-8 Support Enabled
INFO - 2018-10-22 12:39:15 --> Utf8 Class Initialized
INFO - 2018-10-22 12:39:15 --> URI Class Initialized
INFO - 2018-10-22 12:39:15 --> Router Class Initialized
INFO - 2018-10-22 12:39:15 --> Output Class Initialized
INFO - 2018-10-22 12:39:15 --> Security Class Initialized
DEBUG - 2018-10-22 12:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 12:39:15 --> CSRF cookie sent
INFO - 2018-10-22 12:39:15 --> Input Class Initialized
INFO - 2018-10-22 12:39:15 --> Language Class Initialized
INFO - 2018-10-22 12:39:15 --> Loader Class Initialized
INFO - 2018-10-22 12:39:15 --> Helper loaded: url_helper
INFO - 2018-10-22 12:39:15 --> Helper loaded: form_helper
INFO - 2018-10-22 12:39:15 --> Helper loaded: language_helper
DEBUG - 2018-10-22 12:39:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 12:39:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 12:39:15 --> User Agent Class Initialized
INFO - 2018-10-22 12:39:15 --> Controller Class Initialized
INFO - 2018-10-22 12:39:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 12:39:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 12:39:15 --> Helper loaded: custom_helper
INFO - 2018-10-22 12:39:15 --> Pixel_Model class loaded
INFO - 2018-10-22 12:39:15 --> Database Driver Class Initialized
INFO - 2018-10-22 12:39:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 12:39:15 --> Database Driver Class Initialized
INFO - 2018-10-22 12:39:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 12:39:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 12:39:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 12:39:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 12:39:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 12:39:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 12:39:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 12:39:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/your_job.php
INFO - 2018-10-22 12:39:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 12:39:15 --> Final output sent to browser
DEBUG - 2018-10-22 12:39:15 --> Total execution time: 0.3251
INFO - 2018-10-22 12:39:17 --> Config Class Initialized
INFO - 2018-10-22 12:39:17 --> Hooks Class Initialized
DEBUG - 2018-10-22 12:39:17 --> UTF-8 Support Enabled
INFO - 2018-10-22 12:39:17 --> Utf8 Class Initialized
INFO - 2018-10-22 12:39:17 --> URI Class Initialized
INFO - 2018-10-22 12:39:17 --> Router Class Initialized
INFO - 2018-10-22 12:39:17 --> Output Class Initialized
INFO - 2018-10-22 12:39:17 --> Security Class Initialized
DEBUG - 2018-10-22 12:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 12:39:17 --> CSRF cookie sent
INFO - 2018-10-22 12:39:17 --> CSRF token verified
INFO - 2018-10-22 12:39:17 --> Input Class Initialized
INFO - 2018-10-22 12:39:17 --> Language Class Initialized
INFO - 2018-10-22 12:39:17 --> Loader Class Initialized
INFO - 2018-10-22 12:39:17 --> Helper loaded: url_helper
INFO - 2018-10-22 12:39:17 --> Helper loaded: form_helper
INFO - 2018-10-22 12:39:17 --> Helper loaded: language_helper
DEBUG - 2018-10-22 12:39:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 12:39:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 12:39:17 --> User Agent Class Initialized
INFO - 2018-10-22 12:39:17 --> Controller Class Initialized
INFO - 2018-10-22 12:39:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 12:39:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 12:39:17 --> Helper loaded: custom_helper
INFO - 2018-10-22 12:39:17 --> Pixel_Model class loaded
INFO - 2018-10-22 12:39:17 --> Database Driver Class Initialized
INFO - 2018-10-22 12:39:17 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 12:39:18 --> Form Validation Class Initialized
INFO - 2018-10-22 12:39:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 12:39:21 --> Config Class Initialized
INFO - 2018-10-22 12:39:21 --> Hooks Class Initialized
DEBUG - 2018-10-22 12:39:21 --> UTF-8 Support Enabled
INFO - 2018-10-22 12:39:21 --> Utf8 Class Initialized
INFO - 2018-10-22 12:39:21 --> URI Class Initialized
INFO - 2018-10-22 12:39:21 --> Router Class Initialized
INFO - 2018-10-22 12:39:21 --> Output Class Initialized
INFO - 2018-10-22 12:39:21 --> Security Class Initialized
DEBUG - 2018-10-22 12:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 12:39:21 --> CSRF cookie sent
INFO - 2018-10-22 12:39:22 --> Input Class Initialized
INFO - 2018-10-22 12:39:22 --> Language Class Initialized
INFO - 2018-10-22 12:39:22 --> Loader Class Initialized
INFO - 2018-10-22 12:39:22 --> Helper loaded: url_helper
INFO - 2018-10-22 12:39:22 --> Helper loaded: form_helper
INFO - 2018-10-22 12:39:22 --> Helper loaded: language_helper
DEBUG - 2018-10-22 12:39:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 12:39:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 12:39:22 --> User Agent Class Initialized
INFO - 2018-10-22 12:39:22 --> Controller Class Initialized
INFO - 2018-10-22 12:39:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 12:39:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 12:39:22 --> Helper loaded: custom_helper
INFO - 2018-10-22 12:39:22 --> Pixel_Model class loaded
INFO - 2018-10-22 12:39:22 --> Database Driver Class Initialized
INFO - 2018-10-22 12:39:22 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 12:39:22 --> Database Driver Class Initialized
INFO - 2018-10-22 12:39:22 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 12:39:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 12:39:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 12:39:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 12:39:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 12:39:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 12:39:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 12:39:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/your_job.php
INFO - 2018-10-22 12:39:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 12:39:22 --> Final output sent to browser
DEBUG - 2018-10-22 12:39:22 --> Total execution time: 0.3155
INFO - 2018-10-22 12:39:34 --> Config Class Initialized
INFO - 2018-10-22 12:39:34 --> Hooks Class Initialized
DEBUG - 2018-10-22 12:39:34 --> UTF-8 Support Enabled
INFO - 2018-10-22 12:39:34 --> Utf8 Class Initialized
INFO - 2018-10-22 12:39:34 --> URI Class Initialized
INFO - 2018-10-22 12:39:34 --> Router Class Initialized
INFO - 2018-10-22 12:39:34 --> Output Class Initialized
INFO - 2018-10-22 12:39:34 --> Security Class Initialized
DEBUG - 2018-10-22 12:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 12:39:34 --> CSRF cookie sent
INFO - 2018-10-22 12:39:34 --> Input Class Initialized
INFO - 2018-10-22 12:39:34 --> Language Class Initialized
INFO - 2018-10-22 12:39:34 --> Loader Class Initialized
INFO - 2018-10-22 12:39:34 --> Helper loaded: url_helper
INFO - 2018-10-22 12:39:34 --> Helper loaded: form_helper
INFO - 2018-10-22 12:39:34 --> Helper loaded: language_helper
DEBUG - 2018-10-22 12:39:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 12:39:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 12:39:34 --> User Agent Class Initialized
INFO - 2018-10-22 12:39:34 --> Controller Class Initialized
INFO - 2018-10-22 12:39:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 12:39:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 12:39:34 --> Helper loaded: custom_helper
INFO - 2018-10-22 12:39:34 --> Pixel_Model class loaded
INFO - 2018-10-22 12:39:34 --> Database Driver Class Initialized
INFO - 2018-10-22 12:39:34 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 12:39:34 --> Database Driver Class Initialized
INFO - 2018-10-22 12:39:34 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 12:39:34 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 12:39:34 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 12:39:34 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 12:39:34 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 12:39:34 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 12:39:34 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 12:39:34 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/your_job.php
INFO - 2018-10-22 12:39:34 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 12:39:34 --> Final output sent to browser
DEBUG - 2018-10-22 12:39:34 --> Total execution time: 0.3517
INFO - 2018-10-22 12:39:37 --> Config Class Initialized
INFO - 2018-10-22 12:39:37 --> Hooks Class Initialized
DEBUG - 2018-10-22 12:39:37 --> UTF-8 Support Enabled
INFO - 2018-10-22 12:39:37 --> Utf8 Class Initialized
INFO - 2018-10-22 12:39:37 --> URI Class Initialized
INFO - 2018-10-22 12:39:37 --> Router Class Initialized
INFO - 2018-10-22 12:39:37 --> Output Class Initialized
INFO - 2018-10-22 12:39:37 --> Security Class Initialized
DEBUG - 2018-10-22 12:39:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 12:39:37 --> CSRF cookie sent
INFO - 2018-10-22 12:39:37 --> CSRF token verified
INFO - 2018-10-22 12:39:37 --> Input Class Initialized
INFO - 2018-10-22 12:39:37 --> Language Class Initialized
INFO - 2018-10-22 12:39:37 --> Loader Class Initialized
INFO - 2018-10-22 12:39:37 --> Helper loaded: url_helper
INFO - 2018-10-22 12:39:37 --> Helper loaded: form_helper
INFO - 2018-10-22 12:39:37 --> Helper loaded: language_helper
DEBUG - 2018-10-22 12:39:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 12:39:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 12:39:37 --> User Agent Class Initialized
INFO - 2018-10-22 12:39:37 --> Controller Class Initialized
INFO - 2018-10-22 12:39:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 12:39:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 12:39:37 --> Helper loaded: custom_helper
INFO - 2018-10-22 12:39:37 --> Pixel_Model class loaded
INFO - 2018-10-22 12:39:37 --> Database Driver Class Initialized
INFO - 2018-10-22 12:39:37 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 12:39:37 --> Form Validation Class Initialized
INFO - 2018-10-22 12:39:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 12:39:37 --> Database Driver Class Initialized
INFO - 2018-10-22 12:39:37 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 12:39:37 --> Config Class Initialized
INFO - 2018-10-22 12:39:37 --> Hooks Class Initialized
DEBUG - 2018-10-22 12:39:37 --> UTF-8 Support Enabled
INFO - 2018-10-22 12:39:37 --> Utf8 Class Initialized
INFO - 2018-10-22 12:39:37 --> URI Class Initialized
INFO - 2018-10-22 12:39:37 --> Router Class Initialized
INFO - 2018-10-22 12:39:37 --> Output Class Initialized
INFO - 2018-10-22 12:39:37 --> Security Class Initialized
DEBUG - 2018-10-22 12:39:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 12:39:37 --> CSRF cookie sent
INFO - 2018-10-22 12:39:37 --> Input Class Initialized
INFO - 2018-10-22 12:39:37 --> Language Class Initialized
INFO - 2018-10-22 12:39:37 --> Loader Class Initialized
INFO - 2018-10-22 12:39:37 --> Helper loaded: url_helper
INFO - 2018-10-22 12:39:37 --> Helper loaded: form_helper
INFO - 2018-10-22 12:39:37 --> Helper loaded: language_helper
DEBUG - 2018-10-22 12:39:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 12:39:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 12:39:38 --> User Agent Class Initialized
INFO - 2018-10-22 12:39:38 --> Controller Class Initialized
INFO - 2018-10-22 12:39:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 12:39:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 12:39:38 --> Helper loaded: custom_helper
INFO - 2018-10-22 12:39:38 --> Pixel_Model class loaded
INFO - 2018-10-22 12:39:38 --> Database Driver Class Initialized
INFO - 2018-10-22 12:39:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 12:39:38 --> Database Driver Class Initialized
INFO - 2018-10-22 12:39:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 12:39:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 12:39:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 12:39:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner.php
INFO - 2018-10-22 12:39:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 12:39:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 12:39:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 12:39:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 12:39:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/relation_ship_status.php
INFO - 2018-10-22 12:39:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 12:39:38 --> Final output sent to browser
DEBUG - 2018-10-22 12:39:38 --> Total execution time: 0.3298
INFO - 2018-10-22 12:39:40 --> Config Class Initialized
INFO - 2018-10-22 12:39:40 --> Hooks Class Initialized
DEBUG - 2018-10-22 12:39:40 --> UTF-8 Support Enabled
INFO - 2018-10-22 12:39:40 --> Utf8 Class Initialized
INFO - 2018-10-22 12:39:40 --> URI Class Initialized
INFO - 2018-10-22 12:39:40 --> Router Class Initialized
INFO - 2018-10-22 12:39:40 --> Output Class Initialized
INFO - 2018-10-22 12:39:40 --> Security Class Initialized
DEBUG - 2018-10-22 12:39:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 12:39:40 --> CSRF cookie sent
INFO - 2018-10-22 12:39:40 --> CSRF token verified
INFO - 2018-10-22 12:39:40 --> Input Class Initialized
INFO - 2018-10-22 12:39:40 --> Language Class Initialized
INFO - 2018-10-22 12:39:40 --> Loader Class Initialized
INFO - 2018-10-22 12:39:40 --> Helper loaded: url_helper
INFO - 2018-10-22 12:39:40 --> Helper loaded: form_helper
INFO - 2018-10-22 12:39:40 --> Helper loaded: language_helper
DEBUG - 2018-10-22 12:39:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 12:39:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 12:39:41 --> User Agent Class Initialized
INFO - 2018-10-22 12:39:41 --> Controller Class Initialized
INFO - 2018-10-22 12:39:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 12:39:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 12:39:41 --> Helper loaded: custom_helper
INFO - 2018-10-22 12:39:41 --> Pixel_Model class loaded
INFO - 2018-10-22 12:39:41 --> Database Driver Class Initialized
INFO - 2018-10-22 12:39:41 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 12:39:41 --> Form Validation Class Initialized
INFO - 2018-10-22 12:39:41 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-10-22 12:39:41 --> Severity: 4096 --> Object of class stdClass could not be converted to string E:\xampp7\htdocs\famiquity\application\controllers\QuestionnaireController.php 189
INFO - 2018-10-22 12:39:43 --> Config Class Initialized
INFO - 2018-10-22 12:39:43 --> Hooks Class Initialized
DEBUG - 2018-10-22 12:39:43 --> UTF-8 Support Enabled
INFO - 2018-10-22 12:39:43 --> Utf8 Class Initialized
INFO - 2018-10-22 12:39:43 --> URI Class Initialized
INFO - 2018-10-22 12:39:43 --> Router Class Initialized
INFO - 2018-10-22 12:39:43 --> Output Class Initialized
INFO - 2018-10-22 12:39:43 --> Security Class Initialized
DEBUG - 2018-10-22 12:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 12:39:43 --> CSRF cookie sent
INFO - 2018-10-22 12:39:43 --> Input Class Initialized
INFO - 2018-10-22 12:39:43 --> Language Class Initialized
INFO - 2018-10-22 12:39:43 --> Loader Class Initialized
INFO - 2018-10-22 12:39:43 --> Helper loaded: url_helper
INFO - 2018-10-22 12:39:43 --> Helper loaded: form_helper
INFO - 2018-10-22 12:39:43 --> Helper loaded: language_helper
DEBUG - 2018-10-22 12:39:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 12:39:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 12:39:43 --> User Agent Class Initialized
INFO - 2018-10-22 12:39:43 --> Controller Class Initialized
INFO - 2018-10-22 12:39:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 12:39:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 12:39:43 --> Helper loaded: custom_helper
INFO - 2018-10-22 12:39:43 --> Pixel_Model class loaded
INFO - 2018-10-22 12:39:43 --> Database Driver Class Initialized
INFO - 2018-10-22 12:39:43 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 12:39:43 --> Database Driver Class Initialized
INFO - 2018-10-22 12:39:43 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 12:39:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 12:39:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 12:39:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner.php
INFO - 2018-10-22 12:39:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 12:39:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 12:39:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 12:39:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 12:39:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/relation_ship_status.php
INFO - 2018-10-22 12:39:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 12:39:43 --> Final output sent to browser
DEBUG - 2018-10-22 12:39:43 --> Total execution time: 0.3434
INFO - 2018-10-22 12:40:30 --> Config Class Initialized
INFO - 2018-10-22 12:40:30 --> Hooks Class Initialized
DEBUG - 2018-10-22 12:40:30 --> UTF-8 Support Enabled
INFO - 2018-10-22 12:40:30 --> Utf8 Class Initialized
INFO - 2018-10-22 12:40:30 --> URI Class Initialized
INFO - 2018-10-22 12:40:30 --> Router Class Initialized
INFO - 2018-10-22 12:40:30 --> Output Class Initialized
INFO - 2018-10-22 12:40:30 --> Security Class Initialized
DEBUG - 2018-10-22 12:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 12:40:30 --> CSRF cookie sent
INFO - 2018-10-22 12:40:30 --> Input Class Initialized
INFO - 2018-10-22 12:40:30 --> Language Class Initialized
INFO - 2018-10-22 12:40:30 --> Loader Class Initialized
INFO - 2018-10-22 12:40:30 --> Helper loaded: url_helper
INFO - 2018-10-22 12:40:30 --> Helper loaded: form_helper
INFO - 2018-10-22 12:40:30 --> Helper loaded: language_helper
DEBUG - 2018-10-22 12:40:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 12:40:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 12:40:30 --> User Agent Class Initialized
INFO - 2018-10-22 12:40:30 --> Controller Class Initialized
INFO - 2018-10-22 12:40:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 12:40:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 12:40:30 --> Helper loaded: custom_helper
INFO - 2018-10-22 12:40:30 --> Pixel_Model class loaded
INFO - 2018-10-22 12:40:30 --> Database Driver Class Initialized
INFO - 2018-10-22 12:40:30 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 12:40:30 --> Database Driver Class Initialized
INFO - 2018-10-22 12:40:30 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 12:40:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 12:40:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 12:40:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner.php
INFO - 2018-10-22 12:40:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 12:40:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 12:40:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 12:40:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 12:40:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/relation_ship_status.php
INFO - 2018-10-22 12:40:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 12:40:30 --> Final output sent to browser
DEBUG - 2018-10-22 12:40:30 --> Total execution time: 0.3521
INFO - 2018-10-22 12:40:32 --> Config Class Initialized
INFO - 2018-10-22 12:40:32 --> Hooks Class Initialized
DEBUG - 2018-10-22 12:40:32 --> UTF-8 Support Enabled
INFO - 2018-10-22 12:40:32 --> Utf8 Class Initialized
INFO - 2018-10-22 12:40:32 --> URI Class Initialized
INFO - 2018-10-22 12:40:32 --> Router Class Initialized
INFO - 2018-10-22 12:40:32 --> Output Class Initialized
INFO - 2018-10-22 12:40:32 --> Security Class Initialized
DEBUG - 2018-10-22 12:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 12:40:32 --> CSRF cookie sent
INFO - 2018-10-22 12:40:32 --> CSRF token verified
INFO - 2018-10-22 12:40:32 --> Input Class Initialized
INFO - 2018-10-22 12:40:32 --> Language Class Initialized
INFO - 2018-10-22 12:40:32 --> Loader Class Initialized
INFO - 2018-10-22 12:40:32 --> Helper loaded: url_helper
INFO - 2018-10-22 12:40:32 --> Helper loaded: form_helper
INFO - 2018-10-22 12:40:32 --> Helper loaded: language_helper
DEBUG - 2018-10-22 12:40:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 12:40:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 12:40:32 --> User Agent Class Initialized
INFO - 2018-10-22 12:40:32 --> Controller Class Initialized
INFO - 2018-10-22 12:40:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 12:40:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 12:40:32 --> Helper loaded: custom_helper
INFO - 2018-10-22 12:40:32 --> Pixel_Model class loaded
INFO - 2018-10-22 12:40:32 --> Database Driver Class Initialized
INFO - 2018-10-22 12:40:32 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 12:40:32 --> Form Validation Class Initialized
INFO - 2018-10-22 12:40:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 12:42:21 --> Config Class Initialized
INFO - 2018-10-22 12:42:21 --> Hooks Class Initialized
DEBUG - 2018-10-22 12:42:21 --> UTF-8 Support Enabled
INFO - 2018-10-22 12:42:21 --> Utf8 Class Initialized
INFO - 2018-10-22 12:42:21 --> URI Class Initialized
INFO - 2018-10-22 12:42:21 --> Router Class Initialized
INFO - 2018-10-22 12:42:21 --> Output Class Initialized
INFO - 2018-10-22 12:42:21 --> Security Class Initialized
DEBUG - 2018-10-22 12:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 12:42:21 --> CSRF cookie sent
INFO - 2018-10-22 12:42:21 --> Input Class Initialized
INFO - 2018-10-22 12:42:21 --> Language Class Initialized
INFO - 2018-10-22 12:42:21 --> Loader Class Initialized
INFO - 2018-10-22 12:42:21 --> Helper loaded: url_helper
INFO - 2018-10-22 12:42:21 --> Helper loaded: form_helper
INFO - 2018-10-22 12:42:21 --> Helper loaded: language_helper
DEBUG - 2018-10-22 12:42:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 12:42:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 12:42:21 --> User Agent Class Initialized
INFO - 2018-10-22 12:42:21 --> Controller Class Initialized
INFO - 2018-10-22 12:42:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 12:42:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 12:42:21 --> Helper loaded: custom_helper
INFO - 2018-10-22 12:42:21 --> Pixel_Model class loaded
INFO - 2018-10-22 12:42:21 --> Database Driver Class Initialized
INFO - 2018-10-22 12:42:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 12:42:21 --> Database Driver Class Initialized
INFO - 2018-10-22 12:42:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 12:42:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 12:42:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 12:42:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner.php
INFO - 2018-10-22 12:42:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 12:42:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 12:42:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 12:42:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 12:42:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/relation_ship_status.php
INFO - 2018-10-22 12:42:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 12:42:21 --> Final output sent to browser
DEBUG - 2018-10-22 12:42:21 --> Total execution time: 0.3538
INFO - 2018-10-22 12:42:22 --> Config Class Initialized
INFO - 2018-10-22 12:42:22 --> Hooks Class Initialized
DEBUG - 2018-10-22 12:42:22 --> UTF-8 Support Enabled
INFO - 2018-10-22 12:42:22 --> Utf8 Class Initialized
INFO - 2018-10-22 12:42:22 --> URI Class Initialized
INFO - 2018-10-22 12:42:22 --> Router Class Initialized
INFO - 2018-10-22 12:42:22 --> Output Class Initialized
INFO - 2018-10-22 12:42:22 --> Security Class Initialized
DEBUG - 2018-10-22 12:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 12:42:22 --> CSRF cookie sent
INFO - 2018-10-22 12:42:22 --> Input Class Initialized
INFO - 2018-10-22 12:42:22 --> Language Class Initialized
INFO - 2018-10-22 12:42:22 --> Loader Class Initialized
INFO - 2018-10-22 12:42:22 --> Helper loaded: url_helper
INFO - 2018-10-22 12:42:22 --> Helper loaded: form_helper
INFO - 2018-10-22 12:42:22 --> Helper loaded: language_helper
DEBUG - 2018-10-22 12:42:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 12:42:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 12:42:22 --> User Agent Class Initialized
INFO - 2018-10-22 12:42:22 --> Controller Class Initialized
INFO - 2018-10-22 12:42:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 12:42:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 12:42:23 --> Helper loaded: custom_helper
INFO - 2018-10-22 12:42:23 --> Pixel_Model class loaded
INFO - 2018-10-22 12:42:23 --> Database Driver Class Initialized
INFO - 2018-10-22 12:42:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 12:42:23 --> Database Driver Class Initialized
INFO - 2018-10-22 12:42:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 12:42:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 12:42:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 12:42:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner.php
INFO - 2018-10-22 12:42:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 12:42:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 12:42:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 12:42:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 12:42:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/relation_ship_status.php
INFO - 2018-10-22 12:42:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 12:42:23 --> Final output sent to browser
DEBUG - 2018-10-22 12:42:23 --> Total execution time: 0.3799
INFO - 2018-10-22 12:42:28 --> Config Class Initialized
INFO - 2018-10-22 12:42:28 --> Hooks Class Initialized
DEBUG - 2018-10-22 12:42:28 --> UTF-8 Support Enabled
INFO - 2018-10-22 12:42:28 --> Utf8 Class Initialized
INFO - 2018-10-22 12:42:28 --> URI Class Initialized
INFO - 2018-10-22 12:42:28 --> Router Class Initialized
INFO - 2018-10-22 12:42:28 --> Output Class Initialized
INFO - 2018-10-22 12:42:28 --> Security Class Initialized
DEBUG - 2018-10-22 12:42:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 12:42:28 --> CSRF cookie sent
INFO - 2018-10-22 12:42:28 --> CSRF token verified
INFO - 2018-10-22 12:42:28 --> Input Class Initialized
INFO - 2018-10-22 12:42:28 --> Language Class Initialized
INFO - 2018-10-22 12:42:28 --> Loader Class Initialized
INFO - 2018-10-22 12:42:28 --> Helper loaded: url_helper
INFO - 2018-10-22 12:42:28 --> Helper loaded: form_helper
INFO - 2018-10-22 12:42:28 --> Helper loaded: language_helper
DEBUG - 2018-10-22 12:42:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 12:42:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 12:42:28 --> User Agent Class Initialized
INFO - 2018-10-22 12:42:28 --> Controller Class Initialized
INFO - 2018-10-22 12:42:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 12:42:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 12:42:28 --> Helper loaded: custom_helper
INFO - 2018-10-22 12:42:28 --> Pixel_Model class loaded
INFO - 2018-10-22 12:42:28 --> Database Driver Class Initialized
INFO - 2018-10-22 12:42:28 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 12:42:28 --> Form Validation Class Initialized
INFO - 2018-10-22 12:42:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 12:42:28 --> Database Driver Class Initialized
INFO - 2018-10-22 12:42:28 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 12:43:39 --> Config Class Initialized
INFO - 2018-10-22 12:43:39 --> Hooks Class Initialized
DEBUG - 2018-10-22 12:43:39 --> UTF-8 Support Enabled
INFO - 2018-10-22 12:43:39 --> Utf8 Class Initialized
INFO - 2018-10-22 12:43:39 --> URI Class Initialized
INFO - 2018-10-22 12:43:39 --> Router Class Initialized
INFO - 2018-10-22 12:43:39 --> Output Class Initialized
INFO - 2018-10-22 12:43:39 --> Security Class Initialized
DEBUG - 2018-10-22 12:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 12:43:39 --> CSRF cookie sent
INFO - 2018-10-22 12:43:39 --> Input Class Initialized
INFO - 2018-10-22 12:43:39 --> Language Class Initialized
INFO - 2018-10-22 12:43:39 --> Loader Class Initialized
INFO - 2018-10-22 12:43:39 --> Helper loaded: url_helper
INFO - 2018-10-22 12:43:39 --> Helper loaded: form_helper
INFO - 2018-10-22 12:43:39 --> Helper loaded: language_helper
DEBUG - 2018-10-22 12:43:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 12:43:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 12:43:39 --> User Agent Class Initialized
INFO - 2018-10-22 12:43:39 --> Controller Class Initialized
INFO - 2018-10-22 12:43:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 12:43:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 12:43:39 --> Helper loaded: custom_helper
INFO - 2018-10-22 12:43:39 --> Pixel_Model class loaded
INFO - 2018-10-22 12:43:39 --> Database Driver Class Initialized
INFO - 2018-10-22 12:43:39 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 12:43:39 --> Database Driver Class Initialized
INFO - 2018-10-22 12:43:39 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 12:43:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 12:43:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 12:43:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner.php
INFO - 2018-10-22 12:43:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 12:43:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 12:43:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 12:43:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 12:43:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/relation_ship_status.php
INFO - 2018-10-22 12:43:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 12:43:39 --> Final output sent to browser
DEBUG - 2018-10-22 12:43:39 --> Total execution time: 0.3742
INFO - 2018-10-22 12:44:02 --> Config Class Initialized
INFO - 2018-10-22 12:44:02 --> Hooks Class Initialized
DEBUG - 2018-10-22 12:44:02 --> UTF-8 Support Enabled
INFO - 2018-10-22 12:44:03 --> Utf8 Class Initialized
INFO - 2018-10-22 12:44:03 --> URI Class Initialized
INFO - 2018-10-22 12:44:03 --> Router Class Initialized
INFO - 2018-10-22 12:44:03 --> Output Class Initialized
INFO - 2018-10-22 12:44:03 --> Security Class Initialized
DEBUG - 2018-10-22 12:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 12:44:03 --> CSRF cookie sent
INFO - 2018-10-22 12:44:03 --> Input Class Initialized
INFO - 2018-10-22 12:44:03 --> Language Class Initialized
INFO - 2018-10-22 12:44:03 --> Loader Class Initialized
INFO - 2018-10-22 12:44:03 --> Helper loaded: url_helper
INFO - 2018-10-22 12:44:03 --> Helper loaded: form_helper
INFO - 2018-10-22 12:44:03 --> Helper loaded: language_helper
DEBUG - 2018-10-22 12:44:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 12:44:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 12:44:03 --> User Agent Class Initialized
INFO - 2018-10-22 12:44:03 --> Controller Class Initialized
INFO - 2018-10-22 12:44:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 12:44:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 12:44:03 --> Helper loaded: custom_helper
INFO - 2018-10-22 12:44:03 --> Pixel_Model class loaded
INFO - 2018-10-22 12:44:03 --> Database Driver Class Initialized
INFO - 2018-10-22 12:44:03 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 12:44:03 --> Database Driver Class Initialized
INFO - 2018-10-22 12:44:03 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 12:44:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 12:44:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 12:44:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner.php
INFO - 2018-10-22 12:44:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 12:44:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 12:44:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 12:44:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 12:44:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/relation_ship_status.php
INFO - 2018-10-22 12:44:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 12:44:03 --> Final output sent to browser
DEBUG - 2018-10-22 12:44:03 --> Total execution time: 0.3672
INFO - 2018-10-22 12:44:05 --> Config Class Initialized
INFO - 2018-10-22 12:44:05 --> Hooks Class Initialized
DEBUG - 2018-10-22 12:44:05 --> UTF-8 Support Enabled
INFO - 2018-10-22 12:44:05 --> Utf8 Class Initialized
INFO - 2018-10-22 12:44:05 --> URI Class Initialized
INFO - 2018-10-22 12:44:05 --> Router Class Initialized
INFO - 2018-10-22 12:44:05 --> Output Class Initialized
INFO - 2018-10-22 12:44:05 --> Security Class Initialized
DEBUG - 2018-10-22 12:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 12:44:05 --> CSRF cookie sent
INFO - 2018-10-22 12:44:05 --> CSRF token verified
INFO - 2018-10-22 12:44:05 --> Input Class Initialized
INFO - 2018-10-22 12:44:05 --> Language Class Initialized
INFO - 2018-10-22 12:44:05 --> Loader Class Initialized
INFO - 2018-10-22 12:44:05 --> Helper loaded: url_helper
INFO - 2018-10-22 12:44:05 --> Helper loaded: form_helper
INFO - 2018-10-22 12:44:05 --> Helper loaded: language_helper
DEBUG - 2018-10-22 12:44:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 12:44:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 12:44:05 --> User Agent Class Initialized
INFO - 2018-10-22 12:44:05 --> Controller Class Initialized
INFO - 2018-10-22 12:44:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 12:44:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 12:44:05 --> Helper loaded: custom_helper
INFO - 2018-10-22 12:44:05 --> Pixel_Model class loaded
INFO - 2018-10-22 12:44:05 --> Database Driver Class Initialized
INFO - 2018-10-22 12:44:05 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 12:44:05 --> Form Validation Class Initialized
INFO - 2018-10-22 12:44:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 12:44:06 --> Database Driver Class Initialized
INFO - 2018-10-22 12:44:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 12:50:23 --> Config Class Initialized
INFO - 2018-10-22 12:50:23 --> Hooks Class Initialized
DEBUG - 2018-10-22 12:50:23 --> UTF-8 Support Enabled
INFO - 2018-10-22 12:50:23 --> Utf8 Class Initialized
INFO - 2018-10-22 12:50:23 --> URI Class Initialized
INFO - 2018-10-22 12:50:23 --> Router Class Initialized
INFO - 2018-10-22 12:50:23 --> Output Class Initialized
INFO - 2018-10-22 12:50:23 --> Security Class Initialized
DEBUG - 2018-10-22 12:50:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 12:50:23 --> CSRF cookie sent
INFO - 2018-10-22 12:50:23 --> Input Class Initialized
INFO - 2018-10-22 12:50:23 --> Language Class Initialized
INFO - 2018-10-22 12:50:23 --> Loader Class Initialized
INFO - 2018-10-22 12:50:24 --> Helper loaded: url_helper
INFO - 2018-10-22 12:50:24 --> Helper loaded: form_helper
INFO - 2018-10-22 12:50:24 --> Helper loaded: language_helper
DEBUG - 2018-10-22 12:50:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 12:50:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 12:50:24 --> User Agent Class Initialized
INFO - 2018-10-22 12:50:24 --> Controller Class Initialized
INFO - 2018-10-22 12:50:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 12:50:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 12:50:24 --> Helper loaded: custom_helper
INFO - 2018-10-22 12:50:24 --> Pixel_Model class loaded
INFO - 2018-10-22 12:50:24 --> Database Driver Class Initialized
INFO - 2018-10-22 12:50:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 12:50:24 --> Database Driver Class Initialized
INFO - 2018-10-22 12:50:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 12:50:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 12:50:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 12:50:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner.php
INFO - 2018-10-22 12:50:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 12:50:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 12:50:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 12:50:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 12:50:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/relation_ship_status.php
INFO - 2018-10-22 12:50:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 12:50:24 --> Final output sent to browser
DEBUG - 2018-10-22 12:50:24 --> Total execution time: 0.3927
INFO - 2018-10-22 12:50:24 --> Config Class Initialized
INFO - 2018-10-22 12:50:24 --> Hooks Class Initialized
DEBUG - 2018-10-22 12:50:24 --> UTF-8 Support Enabled
INFO - 2018-10-22 12:50:24 --> Utf8 Class Initialized
INFO - 2018-10-22 12:50:24 --> URI Class Initialized
INFO - 2018-10-22 12:50:24 --> Router Class Initialized
INFO - 2018-10-22 12:50:24 --> Output Class Initialized
INFO - 2018-10-22 12:50:24 --> Security Class Initialized
DEBUG - 2018-10-22 12:50:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 12:50:24 --> CSRF cookie sent
INFO - 2018-10-22 12:50:24 --> Input Class Initialized
INFO - 2018-10-22 12:50:24 --> Language Class Initialized
INFO - 2018-10-22 12:50:24 --> Loader Class Initialized
INFO - 2018-10-22 12:50:24 --> Helper loaded: url_helper
INFO - 2018-10-22 12:50:24 --> Helper loaded: form_helper
INFO - 2018-10-22 12:50:24 --> Helper loaded: language_helper
DEBUG - 2018-10-22 12:50:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 12:50:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 12:50:24 --> User Agent Class Initialized
INFO - 2018-10-22 12:50:24 --> Controller Class Initialized
INFO - 2018-10-22 12:50:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 12:50:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 12:50:24 --> Helper loaded: custom_helper
INFO - 2018-10-22 12:50:24 --> Pixel_Model class loaded
INFO - 2018-10-22 12:50:25 --> Database Driver Class Initialized
INFO - 2018-10-22 12:50:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 12:50:25 --> Database Driver Class Initialized
INFO - 2018-10-22 12:50:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 12:50:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 12:50:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 12:50:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 12:50:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 12:50:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 12:50:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 12:50:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/your_job.php
INFO - 2018-10-22 12:50:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 12:50:25 --> Final output sent to browser
DEBUG - 2018-10-22 12:50:25 --> Total execution time: 0.3809
INFO - 2018-10-22 12:50:26 --> Config Class Initialized
INFO - 2018-10-22 12:50:26 --> Hooks Class Initialized
DEBUG - 2018-10-22 12:50:26 --> UTF-8 Support Enabled
INFO - 2018-10-22 12:50:26 --> Utf8 Class Initialized
INFO - 2018-10-22 12:50:26 --> URI Class Initialized
INFO - 2018-10-22 12:50:26 --> Router Class Initialized
INFO - 2018-10-22 12:50:26 --> Output Class Initialized
INFO - 2018-10-22 12:50:26 --> Security Class Initialized
DEBUG - 2018-10-22 12:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 12:50:26 --> CSRF cookie sent
INFO - 2018-10-22 12:50:26 --> Input Class Initialized
INFO - 2018-10-22 12:50:26 --> Language Class Initialized
INFO - 2018-10-22 12:50:26 --> Loader Class Initialized
INFO - 2018-10-22 12:50:26 --> Helper loaded: url_helper
INFO - 2018-10-22 12:50:26 --> Helper loaded: form_helper
INFO - 2018-10-22 12:50:26 --> Helper loaded: language_helper
DEBUG - 2018-10-22 12:50:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 12:50:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 12:50:26 --> User Agent Class Initialized
INFO - 2018-10-22 12:50:26 --> Controller Class Initialized
INFO - 2018-10-22 12:50:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 12:50:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 12:50:26 --> Helper loaded: custom_helper
INFO - 2018-10-22 12:50:26 --> Pixel_Model class loaded
INFO - 2018-10-22 12:50:26 --> Database Driver Class Initialized
INFO - 2018-10-22 12:50:26 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 12:50:26 --> Database Driver Class Initialized
INFO - 2018-10-22 12:50:26 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 12:50:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 12:50:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 12:50:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 12:50:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 12:50:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 12:50:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 12:50:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/your_job.php
INFO - 2018-10-22 12:50:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 12:50:26 --> Final output sent to browser
DEBUG - 2018-10-22 12:50:26 --> Total execution time: 0.3579
INFO - 2018-10-22 12:50:31 --> Config Class Initialized
INFO - 2018-10-22 12:50:31 --> Hooks Class Initialized
DEBUG - 2018-10-22 12:50:31 --> UTF-8 Support Enabled
INFO - 2018-10-22 12:50:31 --> Utf8 Class Initialized
INFO - 2018-10-22 12:50:31 --> URI Class Initialized
INFO - 2018-10-22 12:50:31 --> Router Class Initialized
INFO - 2018-10-22 12:50:31 --> Output Class Initialized
INFO - 2018-10-22 12:50:31 --> Security Class Initialized
DEBUG - 2018-10-22 12:50:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 12:50:31 --> CSRF cookie sent
INFO - 2018-10-22 12:50:31 --> CSRF token verified
INFO - 2018-10-22 12:50:31 --> Input Class Initialized
INFO - 2018-10-22 12:50:31 --> Language Class Initialized
INFO - 2018-10-22 12:50:31 --> Loader Class Initialized
INFO - 2018-10-22 12:50:31 --> Helper loaded: url_helper
INFO - 2018-10-22 12:50:31 --> Helper loaded: form_helper
INFO - 2018-10-22 12:50:31 --> Helper loaded: language_helper
DEBUG - 2018-10-22 12:50:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 12:50:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 12:50:31 --> User Agent Class Initialized
INFO - 2018-10-22 12:50:31 --> Controller Class Initialized
INFO - 2018-10-22 12:50:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 12:50:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 12:50:31 --> Helper loaded: custom_helper
INFO - 2018-10-22 12:50:31 --> Pixel_Model class loaded
INFO - 2018-10-22 12:50:31 --> Database Driver Class Initialized
INFO - 2018-10-22 12:50:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 12:50:31 --> Form Validation Class Initialized
INFO - 2018-10-22 12:50:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 12:50:31 --> Database Driver Class Initialized
INFO - 2018-10-22 12:50:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 12:52:29 --> Config Class Initialized
INFO - 2018-10-22 12:52:29 --> Hooks Class Initialized
DEBUG - 2018-10-22 12:52:29 --> UTF-8 Support Enabled
INFO - 2018-10-22 12:52:29 --> Utf8 Class Initialized
INFO - 2018-10-22 12:52:29 --> URI Class Initialized
INFO - 2018-10-22 12:52:29 --> Router Class Initialized
INFO - 2018-10-22 12:52:29 --> Output Class Initialized
INFO - 2018-10-22 12:52:29 --> Security Class Initialized
DEBUG - 2018-10-22 12:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 12:52:29 --> CSRF cookie sent
INFO - 2018-10-22 12:52:29 --> CSRF token verified
INFO - 2018-10-22 12:52:29 --> Input Class Initialized
INFO - 2018-10-22 12:52:29 --> Language Class Initialized
INFO - 2018-10-22 12:52:29 --> Loader Class Initialized
INFO - 2018-10-22 12:52:29 --> Helper loaded: url_helper
INFO - 2018-10-22 12:52:29 --> Helper loaded: form_helper
INFO - 2018-10-22 12:52:29 --> Helper loaded: language_helper
DEBUG - 2018-10-22 12:52:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 12:52:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 12:52:29 --> User Agent Class Initialized
INFO - 2018-10-22 12:52:29 --> Controller Class Initialized
INFO - 2018-10-22 12:52:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 12:52:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 12:52:29 --> Helper loaded: custom_helper
INFO - 2018-10-22 12:52:29 --> Pixel_Model class loaded
INFO - 2018-10-22 12:52:29 --> Database Driver Class Initialized
INFO - 2018-10-22 12:52:29 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 12:52:29 --> Form Validation Class Initialized
INFO - 2018-10-22 12:52:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 12:52:29 --> Database Driver Class Initialized
INFO - 2018-10-22 12:52:29 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 12:52:29 --> Config Class Initialized
INFO - 2018-10-22 12:52:29 --> Hooks Class Initialized
DEBUG - 2018-10-22 12:52:29 --> UTF-8 Support Enabled
INFO - 2018-10-22 12:52:29 --> Utf8 Class Initialized
INFO - 2018-10-22 12:52:29 --> URI Class Initialized
INFO - 2018-10-22 12:52:29 --> Router Class Initialized
INFO - 2018-10-22 12:52:29 --> Output Class Initialized
INFO - 2018-10-22 12:52:29 --> Security Class Initialized
DEBUG - 2018-10-22 12:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 12:52:29 --> CSRF cookie sent
INFO - 2018-10-22 12:52:29 --> Input Class Initialized
INFO - 2018-10-22 12:52:29 --> Language Class Initialized
INFO - 2018-10-22 12:52:29 --> Loader Class Initialized
INFO - 2018-10-22 12:52:29 --> Helper loaded: url_helper
INFO - 2018-10-22 12:52:29 --> Helper loaded: form_helper
INFO - 2018-10-22 12:52:29 --> Helper loaded: language_helper
DEBUG - 2018-10-22 12:52:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 12:52:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 12:52:29 --> User Agent Class Initialized
INFO - 2018-10-22 12:52:29 --> Controller Class Initialized
INFO - 2018-10-22 12:52:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 12:52:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 12:52:29 --> Helper loaded: custom_helper
INFO - 2018-10-22 12:52:29 --> Pixel_Model class loaded
INFO - 2018-10-22 12:52:29 --> Database Driver Class Initialized
INFO - 2018-10-22 12:52:30 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 12:52:45 --> Config Class Initialized
INFO - 2018-10-22 12:52:45 --> Hooks Class Initialized
DEBUG - 2018-10-22 12:52:45 --> UTF-8 Support Enabled
INFO - 2018-10-22 12:52:45 --> Utf8 Class Initialized
INFO - 2018-10-22 12:52:45 --> URI Class Initialized
INFO - 2018-10-22 12:52:45 --> Router Class Initialized
INFO - 2018-10-22 12:52:45 --> Output Class Initialized
INFO - 2018-10-22 12:52:45 --> Security Class Initialized
DEBUG - 2018-10-22 12:52:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 12:52:45 --> CSRF cookie sent
INFO - 2018-10-22 12:52:45 --> Input Class Initialized
INFO - 2018-10-22 12:52:45 --> Language Class Initialized
INFO - 2018-10-22 12:52:45 --> Loader Class Initialized
INFO - 2018-10-22 12:52:45 --> Helper loaded: url_helper
INFO - 2018-10-22 12:52:45 --> Helper loaded: form_helper
INFO - 2018-10-22 12:52:45 --> Helper loaded: language_helper
DEBUG - 2018-10-22 12:52:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 12:52:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 12:52:45 --> User Agent Class Initialized
INFO - 2018-10-22 12:52:45 --> Controller Class Initialized
INFO - 2018-10-22 12:52:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 12:52:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 12:52:45 --> Helper loaded: custom_helper
INFO - 2018-10-22 12:52:45 --> Pixel_Model class loaded
INFO - 2018-10-22 12:52:45 --> Database Driver Class Initialized
INFO - 2018-10-22 12:52:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 12:54:37 --> Config Class Initialized
INFO - 2018-10-22 12:54:37 --> Hooks Class Initialized
DEBUG - 2018-10-22 12:54:37 --> UTF-8 Support Enabled
INFO - 2018-10-22 12:54:37 --> Utf8 Class Initialized
INFO - 2018-10-22 12:54:37 --> URI Class Initialized
INFO - 2018-10-22 12:54:37 --> Router Class Initialized
INFO - 2018-10-22 12:54:37 --> Output Class Initialized
INFO - 2018-10-22 12:54:37 --> Security Class Initialized
DEBUG - 2018-10-22 12:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 12:54:37 --> CSRF cookie sent
INFO - 2018-10-22 12:54:37 --> Input Class Initialized
INFO - 2018-10-22 12:54:37 --> Language Class Initialized
INFO - 2018-10-22 12:54:37 --> Loader Class Initialized
INFO - 2018-10-22 12:54:37 --> Helper loaded: url_helper
INFO - 2018-10-22 12:54:37 --> Helper loaded: form_helper
INFO - 2018-10-22 12:54:37 --> Helper loaded: language_helper
DEBUG - 2018-10-22 12:54:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 12:54:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 12:54:37 --> User Agent Class Initialized
INFO - 2018-10-22 12:54:37 --> Controller Class Initialized
INFO - 2018-10-22 12:54:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 12:54:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 12:54:37 --> Helper loaded: custom_helper
INFO - 2018-10-22 12:54:37 --> Pixel_Model class loaded
INFO - 2018-10-22 12:54:37 --> Database Driver Class Initialized
INFO - 2018-10-22 12:54:37 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 12:55:01 --> Config Class Initialized
INFO - 2018-10-22 12:55:01 --> Hooks Class Initialized
DEBUG - 2018-10-22 12:55:01 --> UTF-8 Support Enabled
INFO - 2018-10-22 12:55:01 --> Utf8 Class Initialized
INFO - 2018-10-22 12:55:01 --> URI Class Initialized
INFO - 2018-10-22 12:55:01 --> Router Class Initialized
INFO - 2018-10-22 12:55:01 --> Output Class Initialized
INFO - 2018-10-22 12:55:01 --> Security Class Initialized
DEBUG - 2018-10-22 12:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 12:55:01 --> CSRF cookie sent
INFO - 2018-10-22 12:55:01 --> Input Class Initialized
INFO - 2018-10-22 12:55:01 --> Language Class Initialized
INFO - 2018-10-22 12:55:01 --> Loader Class Initialized
INFO - 2018-10-22 12:55:01 --> Helper loaded: url_helper
INFO - 2018-10-22 12:55:01 --> Helper loaded: form_helper
INFO - 2018-10-22 12:55:01 --> Helper loaded: language_helper
DEBUG - 2018-10-22 12:55:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 12:55:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 12:55:01 --> User Agent Class Initialized
INFO - 2018-10-22 12:55:01 --> Controller Class Initialized
INFO - 2018-10-22 12:55:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 12:55:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 12:55:01 --> Helper loaded: custom_helper
INFO - 2018-10-22 12:55:01 --> Pixel_Model class loaded
INFO - 2018-10-22 12:55:01 --> Database Driver Class Initialized
INFO - 2018-10-22 12:55:01 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 12:55:01 --> Database Driver Class Initialized
INFO - 2018-10-22 12:55:01 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 12:57:19 --> Config Class Initialized
INFO - 2018-10-22 12:57:19 --> Hooks Class Initialized
DEBUG - 2018-10-22 12:57:19 --> UTF-8 Support Enabled
INFO - 2018-10-22 12:57:19 --> Utf8 Class Initialized
INFO - 2018-10-22 12:57:19 --> URI Class Initialized
DEBUG - 2018-10-22 12:57:19 --> No URI present. Default controller set.
INFO - 2018-10-22 12:57:19 --> Router Class Initialized
INFO - 2018-10-22 12:57:19 --> Output Class Initialized
INFO - 2018-10-22 12:57:19 --> Security Class Initialized
DEBUG - 2018-10-22 12:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 12:57:19 --> CSRF cookie sent
INFO - 2018-10-22 12:57:19 --> Input Class Initialized
INFO - 2018-10-22 12:57:19 --> Language Class Initialized
INFO - 2018-10-22 12:57:19 --> Loader Class Initialized
INFO - 2018-10-22 12:57:19 --> Helper loaded: url_helper
INFO - 2018-10-22 12:57:19 --> Helper loaded: form_helper
INFO - 2018-10-22 12:57:19 --> Helper loaded: language_helper
DEBUG - 2018-10-22 12:57:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 12:57:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 12:57:19 --> User Agent Class Initialized
INFO - 2018-10-22 12:57:19 --> Controller Class Initialized
INFO - 2018-10-22 12:57:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 12:57:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 12:57:19 --> Helper loaded: custom_helper
INFO - 2018-10-22 12:57:19 --> Pixel_Model class loaded
INFO - 2018-10-22 12:57:19 --> Database Driver Class Initialized
INFO - 2018-10-22 12:57:19 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 12:57:19 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 12:57:19 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 12:57:19 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-22 12:57:19 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 12:57:19 --> Final output sent to browser
DEBUG - 2018-10-22 12:57:19 --> Total execution time: 0.3099
INFO - 2018-10-22 12:57:20 --> Config Class Initialized
INFO - 2018-10-22 12:57:20 --> Hooks Class Initialized
DEBUG - 2018-10-22 12:57:20 --> UTF-8 Support Enabled
INFO - 2018-10-22 12:57:20 --> Utf8 Class Initialized
INFO - 2018-10-22 12:57:20 --> URI Class Initialized
INFO - 2018-10-22 12:57:20 --> Router Class Initialized
INFO - 2018-10-22 12:57:20 --> Output Class Initialized
INFO - 2018-10-22 12:57:20 --> Security Class Initialized
DEBUG - 2018-10-22 12:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 12:57:20 --> CSRF cookie sent
INFO - 2018-10-22 12:57:20 --> Input Class Initialized
INFO - 2018-10-22 12:57:20 --> Language Class Initialized
INFO - 2018-10-22 12:57:20 --> Loader Class Initialized
INFO - 2018-10-22 12:57:20 --> Helper loaded: url_helper
INFO - 2018-10-22 12:57:20 --> Helper loaded: form_helper
INFO - 2018-10-22 12:57:20 --> Helper loaded: language_helper
DEBUG - 2018-10-22 12:57:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 12:57:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 12:57:20 --> User Agent Class Initialized
INFO - 2018-10-22 12:57:20 --> Controller Class Initialized
INFO - 2018-10-22 12:57:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 12:57:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 12:57:20 --> Helper loaded: custom_helper
INFO - 2018-10-22 12:57:20 --> Pixel_Model class loaded
INFO - 2018-10-22 12:57:20 --> Database Driver Class Initialized
INFO - 2018-10-22 12:57:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 12:57:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 12:57:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 12:57:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 12:57:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 12:57:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 12:57:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 12:57:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-22 12:57:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 12:57:21 --> Final output sent to browser
DEBUG - 2018-10-22 12:57:21 --> Total execution time: 0.4565
INFO - 2018-10-22 12:57:23 --> Config Class Initialized
INFO - 2018-10-22 12:57:23 --> Hooks Class Initialized
DEBUG - 2018-10-22 12:57:23 --> UTF-8 Support Enabled
INFO - 2018-10-22 12:57:23 --> Utf8 Class Initialized
INFO - 2018-10-22 12:57:23 --> URI Class Initialized
INFO - 2018-10-22 12:57:23 --> Router Class Initialized
INFO - 2018-10-22 12:57:23 --> Output Class Initialized
INFO - 2018-10-22 12:57:23 --> Security Class Initialized
DEBUG - 2018-10-22 12:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 12:57:23 --> CSRF cookie sent
INFO - 2018-10-22 12:57:23 --> CSRF token verified
INFO - 2018-10-22 12:57:23 --> Input Class Initialized
INFO - 2018-10-22 12:57:23 --> Language Class Initialized
INFO - 2018-10-22 12:57:23 --> Loader Class Initialized
INFO - 2018-10-22 12:57:23 --> Helper loaded: url_helper
INFO - 2018-10-22 12:57:23 --> Helper loaded: form_helper
INFO - 2018-10-22 12:57:23 --> Helper loaded: language_helper
DEBUG - 2018-10-22 12:57:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 12:57:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 12:57:23 --> User Agent Class Initialized
INFO - 2018-10-22 12:57:23 --> Controller Class Initialized
INFO - 2018-10-22 12:57:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 12:57:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 12:57:23 --> Helper loaded: custom_helper
INFO - 2018-10-22 12:57:23 --> Pixel_Model class loaded
INFO - 2018-10-22 12:57:23 --> Database Driver Class Initialized
INFO - 2018-10-22 12:57:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 12:57:23 --> Form Validation Class Initialized
INFO - 2018-10-22 12:57:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 12:57:23 --> Database Driver Class Initialized
INFO - 2018-10-22 12:57:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 12:57:23 --> Config Class Initialized
INFO - 2018-10-22 12:57:23 --> Hooks Class Initialized
DEBUG - 2018-10-22 12:57:23 --> UTF-8 Support Enabled
INFO - 2018-10-22 12:57:23 --> Utf8 Class Initialized
INFO - 2018-10-22 12:57:23 --> URI Class Initialized
INFO - 2018-10-22 12:57:23 --> Router Class Initialized
INFO - 2018-10-22 12:57:23 --> Output Class Initialized
INFO - 2018-10-22 12:57:23 --> Security Class Initialized
DEBUG - 2018-10-22 12:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 12:57:23 --> CSRF cookie sent
INFO - 2018-10-22 12:57:23 --> Input Class Initialized
INFO - 2018-10-22 12:57:23 --> Language Class Initialized
INFO - 2018-10-22 12:57:24 --> Loader Class Initialized
INFO - 2018-10-22 12:57:24 --> Helper loaded: url_helper
INFO - 2018-10-22 12:57:24 --> Helper loaded: form_helper
INFO - 2018-10-22 12:57:24 --> Helper loaded: language_helper
DEBUG - 2018-10-22 12:57:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 12:57:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 12:57:24 --> User Agent Class Initialized
INFO - 2018-10-22 12:57:24 --> Controller Class Initialized
INFO - 2018-10-22 12:57:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 12:57:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 12:57:24 --> Helper loaded: custom_helper
INFO - 2018-10-22 12:57:24 --> Pixel_Model class loaded
INFO - 2018-10-22 12:57:24 --> Database Driver Class Initialized
INFO - 2018-10-22 12:57:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 12:57:24 --> Database Driver Class Initialized
INFO - 2018-10-22 12:57:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 12:57:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 12:57:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 12:57:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 12:57:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 12:57:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 12:57:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 12:57:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-22 12:57:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 12:57:24 --> Final output sent to browser
DEBUG - 2018-10-22 12:57:24 --> Total execution time: 0.3356
INFO - 2018-10-22 12:57:27 --> Config Class Initialized
INFO - 2018-10-22 12:57:27 --> Hooks Class Initialized
DEBUG - 2018-10-22 12:57:27 --> UTF-8 Support Enabled
INFO - 2018-10-22 12:57:27 --> Utf8 Class Initialized
INFO - 2018-10-22 12:57:27 --> URI Class Initialized
INFO - 2018-10-22 12:57:27 --> Router Class Initialized
INFO - 2018-10-22 12:57:27 --> Output Class Initialized
INFO - 2018-10-22 12:57:27 --> Security Class Initialized
DEBUG - 2018-10-22 12:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 12:57:27 --> CSRF cookie sent
INFO - 2018-10-22 12:57:27 --> CSRF token verified
INFO - 2018-10-22 12:57:27 --> Input Class Initialized
INFO - 2018-10-22 12:57:27 --> Language Class Initialized
INFO - 2018-10-22 12:57:27 --> Loader Class Initialized
INFO - 2018-10-22 12:57:27 --> Helper loaded: url_helper
INFO - 2018-10-22 12:57:27 --> Helper loaded: form_helper
INFO - 2018-10-22 12:57:27 --> Helper loaded: language_helper
DEBUG - 2018-10-22 12:57:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 12:57:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 12:57:27 --> User Agent Class Initialized
INFO - 2018-10-22 12:57:27 --> Controller Class Initialized
INFO - 2018-10-22 12:57:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 12:57:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 12:57:27 --> Helper loaded: custom_helper
INFO - 2018-10-22 12:57:27 --> Pixel_Model class loaded
INFO - 2018-10-22 12:57:27 --> Database Driver Class Initialized
INFO - 2018-10-22 12:57:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 12:57:27 --> Form Validation Class Initialized
INFO - 2018-10-22 12:57:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 12:57:27 --> Database Driver Class Initialized
INFO - 2018-10-22 12:57:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 12:57:27 --> Config Class Initialized
INFO - 2018-10-22 12:57:27 --> Hooks Class Initialized
DEBUG - 2018-10-22 12:57:27 --> UTF-8 Support Enabled
INFO - 2018-10-22 12:57:27 --> Utf8 Class Initialized
INFO - 2018-10-22 12:57:27 --> URI Class Initialized
INFO - 2018-10-22 12:57:27 --> Router Class Initialized
INFO - 2018-10-22 12:57:27 --> Output Class Initialized
INFO - 2018-10-22 12:57:27 --> Security Class Initialized
DEBUG - 2018-10-22 12:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 12:57:27 --> CSRF cookie sent
INFO - 2018-10-22 12:57:27 --> Input Class Initialized
INFO - 2018-10-22 12:57:27 --> Language Class Initialized
INFO - 2018-10-22 12:57:27 --> Loader Class Initialized
INFO - 2018-10-22 12:57:27 --> Helper loaded: url_helper
INFO - 2018-10-22 12:57:27 --> Helper loaded: form_helper
INFO - 2018-10-22 12:57:27 --> Helper loaded: language_helper
DEBUG - 2018-10-22 12:57:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 12:57:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 12:57:27 --> User Agent Class Initialized
INFO - 2018-10-22 12:57:28 --> Controller Class Initialized
INFO - 2018-10-22 12:57:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 12:57:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 12:57:28 --> Helper loaded: custom_helper
INFO - 2018-10-22 12:57:28 --> Pixel_Model class loaded
INFO - 2018-10-22 12:57:28 --> Database Driver Class Initialized
INFO - 2018-10-22 12:57:28 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 12:57:28 --> Database Driver Class Initialized
INFO - 2018-10-22 12:57:28 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 12:58:05 --> Config Class Initialized
INFO - 2018-10-22 12:58:05 --> Hooks Class Initialized
DEBUG - 2018-10-22 12:58:05 --> UTF-8 Support Enabled
INFO - 2018-10-22 12:58:05 --> Utf8 Class Initialized
INFO - 2018-10-22 12:58:05 --> URI Class Initialized
INFO - 2018-10-22 12:58:05 --> Router Class Initialized
INFO - 2018-10-22 12:58:05 --> Output Class Initialized
INFO - 2018-10-22 12:58:05 --> Security Class Initialized
DEBUG - 2018-10-22 12:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 12:58:05 --> CSRF cookie sent
INFO - 2018-10-22 12:58:05 --> Input Class Initialized
INFO - 2018-10-22 12:58:05 --> Language Class Initialized
INFO - 2018-10-22 12:58:05 --> Loader Class Initialized
INFO - 2018-10-22 12:58:05 --> Helper loaded: url_helper
INFO - 2018-10-22 12:58:05 --> Helper loaded: form_helper
INFO - 2018-10-22 12:58:05 --> Helper loaded: language_helper
DEBUG - 2018-10-22 12:58:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 12:58:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 12:58:05 --> User Agent Class Initialized
INFO - 2018-10-22 12:58:05 --> Controller Class Initialized
INFO - 2018-10-22 12:58:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 12:58:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 12:58:05 --> Helper loaded: custom_helper
INFO - 2018-10-22 12:58:05 --> Pixel_Model class loaded
INFO - 2018-10-22 12:58:05 --> Database Driver Class Initialized
INFO - 2018-10-22 12:58:05 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 12:58:05 --> Database Driver Class Initialized
INFO - 2018-10-22 12:58:05 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 12:58:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 12:58:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 12:58:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 12:58:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 12:58:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 12:58:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 12:58:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/your_job.php
INFO - 2018-10-22 12:58:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 12:58:05 --> Final output sent to browser
DEBUG - 2018-10-22 12:58:05 --> Total execution time: 0.3818
INFO - 2018-10-22 12:58:09 --> Config Class Initialized
INFO - 2018-10-22 12:58:09 --> Hooks Class Initialized
DEBUG - 2018-10-22 12:58:09 --> UTF-8 Support Enabled
INFO - 2018-10-22 12:58:09 --> Utf8 Class Initialized
INFO - 2018-10-22 12:58:09 --> URI Class Initialized
INFO - 2018-10-22 12:58:09 --> Router Class Initialized
INFO - 2018-10-22 12:58:09 --> Output Class Initialized
INFO - 2018-10-22 12:58:09 --> Security Class Initialized
DEBUG - 2018-10-22 12:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 12:58:09 --> CSRF cookie sent
INFO - 2018-10-22 12:58:09 --> CSRF token verified
INFO - 2018-10-22 12:58:09 --> Input Class Initialized
INFO - 2018-10-22 12:58:09 --> Language Class Initialized
INFO - 2018-10-22 12:58:09 --> Loader Class Initialized
INFO - 2018-10-22 12:58:09 --> Helper loaded: url_helper
INFO - 2018-10-22 12:58:09 --> Helper loaded: form_helper
INFO - 2018-10-22 12:58:09 --> Helper loaded: language_helper
DEBUG - 2018-10-22 12:58:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 12:58:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 12:58:09 --> User Agent Class Initialized
INFO - 2018-10-22 12:58:09 --> Controller Class Initialized
INFO - 2018-10-22 12:58:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 12:58:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 12:58:09 --> Helper loaded: custom_helper
INFO - 2018-10-22 12:58:09 --> Pixel_Model class loaded
INFO - 2018-10-22 12:58:09 --> Database Driver Class Initialized
INFO - 2018-10-22 12:58:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 12:58:09 --> Form Validation Class Initialized
INFO - 2018-10-22 12:58:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 12:58:09 --> Database Driver Class Initialized
INFO - 2018-10-22 12:58:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 12:58:09 --> Config Class Initialized
INFO - 2018-10-22 12:58:09 --> Hooks Class Initialized
DEBUG - 2018-10-22 12:58:09 --> UTF-8 Support Enabled
INFO - 2018-10-22 12:58:09 --> Utf8 Class Initialized
INFO - 2018-10-22 12:58:09 --> URI Class Initialized
INFO - 2018-10-22 12:58:09 --> Router Class Initialized
INFO - 2018-10-22 12:58:09 --> Output Class Initialized
INFO - 2018-10-22 12:58:09 --> Security Class Initialized
DEBUG - 2018-10-22 12:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 12:58:09 --> CSRF cookie sent
INFO - 2018-10-22 12:58:09 --> Input Class Initialized
INFO - 2018-10-22 12:58:09 --> Language Class Initialized
INFO - 2018-10-22 12:58:09 --> Loader Class Initialized
INFO - 2018-10-22 12:58:09 --> Helper loaded: url_helper
INFO - 2018-10-22 12:58:09 --> Helper loaded: form_helper
INFO - 2018-10-22 12:58:09 --> Helper loaded: language_helper
DEBUG - 2018-10-22 12:58:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 12:58:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 12:58:09 --> User Agent Class Initialized
INFO - 2018-10-22 12:58:09 --> Controller Class Initialized
INFO - 2018-10-22 12:58:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 12:58:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 12:58:09 --> Helper loaded: custom_helper
INFO - 2018-10-22 12:58:09 --> Pixel_Model class loaded
INFO - 2018-10-22 12:58:09 --> Database Driver Class Initialized
INFO - 2018-10-22 12:58:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 12:58:52 --> Config Class Initialized
INFO - 2018-10-22 12:58:52 --> Hooks Class Initialized
DEBUG - 2018-10-22 12:58:52 --> UTF-8 Support Enabled
INFO - 2018-10-22 12:58:52 --> Utf8 Class Initialized
INFO - 2018-10-22 12:58:52 --> URI Class Initialized
INFO - 2018-10-22 12:58:52 --> Router Class Initialized
INFO - 2018-10-22 12:58:52 --> Output Class Initialized
INFO - 2018-10-22 12:58:52 --> Security Class Initialized
DEBUG - 2018-10-22 12:58:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 12:58:52 --> CSRF cookie sent
INFO - 2018-10-22 12:58:52 --> Input Class Initialized
INFO - 2018-10-22 12:58:52 --> Language Class Initialized
INFO - 2018-10-22 12:58:52 --> Loader Class Initialized
INFO - 2018-10-22 12:58:52 --> Helper loaded: url_helper
INFO - 2018-10-22 12:58:52 --> Helper loaded: form_helper
INFO - 2018-10-22 12:58:52 --> Helper loaded: language_helper
DEBUG - 2018-10-22 12:58:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 12:58:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 12:58:52 --> User Agent Class Initialized
INFO - 2018-10-22 12:58:52 --> Controller Class Initialized
INFO - 2018-10-22 12:58:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 12:58:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 12:58:52 --> Helper loaded: custom_helper
INFO - 2018-10-22 12:58:52 --> Pixel_Model class loaded
INFO - 2018-10-22 12:58:52 --> Database Driver Class Initialized
INFO - 2018-10-22 12:58:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 12:58:52 --> Database Driver Class Initialized
INFO - 2018-10-22 12:58:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 12:59:12 --> Config Class Initialized
INFO - 2018-10-22 12:59:12 --> Hooks Class Initialized
DEBUG - 2018-10-22 12:59:12 --> UTF-8 Support Enabled
INFO - 2018-10-22 12:59:12 --> Utf8 Class Initialized
INFO - 2018-10-22 12:59:12 --> URI Class Initialized
INFO - 2018-10-22 12:59:12 --> Router Class Initialized
INFO - 2018-10-22 12:59:12 --> Output Class Initialized
INFO - 2018-10-22 12:59:12 --> Security Class Initialized
DEBUG - 2018-10-22 12:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 12:59:12 --> CSRF cookie sent
INFO - 2018-10-22 12:59:12 --> Input Class Initialized
INFO - 2018-10-22 12:59:12 --> Language Class Initialized
INFO - 2018-10-22 12:59:12 --> Loader Class Initialized
INFO - 2018-10-22 12:59:12 --> Helper loaded: url_helper
INFO - 2018-10-22 12:59:12 --> Helper loaded: form_helper
INFO - 2018-10-22 12:59:13 --> Helper loaded: language_helper
DEBUG - 2018-10-22 12:59:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 12:59:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 12:59:13 --> User Agent Class Initialized
INFO - 2018-10-22 12:59:13 --> Controller Class Initialized
INFO - 2018-10-22 12:59:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 12:59:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 12:59:13 --> Helper loaded: custom_helper
INFO - 2018-10-22 12:59:13 --> Pixel_Model class loaded
INFO - 2018-10-22 12:59:13 --> Database Driver Class Initialized
INFO - 2018-10-22 12:59:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 12:59:13 --> Database Driver Class Initialized
INFO - 2018-10-22 12:59:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 12:59:45 --> Config Class Initialized
INFO - 2018-10-22 12:59:45 --> Hooks Class Initialized
DEBUG - 2018-10-22 12:59:45 --> UTF-8 Support Enabled
INFO - 2018-10-22 12:59:45 --> Utf8 Class Initialized
INFO - 2018-10-22 12:59:45 --> URI Class Initialized
INFO - 2018-10-22 12:59:45 --> Router Class Initialized
INFO - 2018-10-22 12:59:45 --> Output Class Initialized
INFO - 2018-10-22 12:59:45 --> Security Class Initialized
DEBUG - 2018-10-22 12:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 12:59:45 --> CSRF cookie sent
INFO - 2018-10-22 12:59:45 --> Input Class Initialized
INFO - 2018-10-22 12:59:45 --> Language Class Initialized
INFO - 2018-10-22 12:59:45 --> Loader Class Initialized
INFO - 2018-10-22 12:59:45 --> Helper loaded: url_helper
INFO - 2018-10-22 12:59:45 --> Helper loaded: form_helper
INFO - 2018-10-22 12:59:45 --> Helper loaded: language_helper
DEBUG - 2018-10-22 12:59:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 12:59:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 12:59:45 --> User Agent Class Initialized
INFO - 2018-10-22 12:59:45 --> Controller Class Initialized
INFO - 2018-10-22 12:59:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 12:59:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 12:59:45 --> Helper loaded: custom_helper
INFO - 2018-10-22 12:59:45 --> Pixel_Model class loaded
INFO - 2018-10-22 12:59:45 --> Database Driver Class Initialized
INFO - 2018-10-22 12:59:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 12:59:45 --> Database Driver Class Initialized
INFO - 2018-10-22 12:59:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 12:59:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 12:59:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 12:59:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner.php
INFO - 2018-10-22 12:59:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 12:59:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 12:59:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 12:59:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 12:59:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/relation_ship_status.php
INFO - 2018-10-22 12:59:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 12:59:45 --> Final output sent to browser
DEBUG - 2018-10-22 12:59:45 --> Total execution time: 0.4134
INFO - 2018-10-22 12:59:49 --> Config Class Initialized
INFO - 2018-10-22 12:59:49 --> Hooks Class Initialized
DEBUG - 2018-10-22 12:59:49 --> UTF-8 Support Enabled
INFO - 2018-10-22 12:59:49 --> Utf8 Class Initialized
INFO - 2018-10-22 12:59:49 --> URI Class Initialized
INFO - 2018-10-22 12:59:49 --> Router Class Initialized
INFO - 2018-10-22 12:59:49 --> Output Class Initialized
INFO - 2018-10-22 12:59:49 --> Security Class Initialized
DEBUG - 2018-10-22 12:59:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 12:59:49 --> CSRF cookie sent
INFO - 2018-10-22 12:59:49 --> Input Class Initialized
INFO - 2018-10-22 12:59:49 --> Language Class Initialized
ERROR - 2018-10-22 12:59:49 --> 404 Page Not Found: Assets/css
INFO - 2018-10-22 12:59:58 --> Config Class Initialized
INFO - 2018-10-22 12:59:58 --> Hooks Class Initialized
DEBUG - 2018-10-22 12:59:58 --> UTF-8 Support Enabled
INFO - 2018-10-22 12:59:58 --> Utf8 Class Initialized
INFO - 2018-10-22 12:59:58 --> URI Class Initialized
INFO - 2018-10-22 12:59:58 --> Router Class Initialized
INFO - 2018-10-22 12:59:58 --> Output Class Initialized
INFO - 2018-10-22 12:59:58 --> Security Class Initialized
DEBUG - 2018-10-22 12:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 12:59:58 --> CSRF cookie sent
INFO - 2018-10-22 12:59:58 --> CSRF token verified
INFO - 2018-10-22 12:59:58 --> Input Class Initialized
INFO - 2018-10-22 12:59:58 --> Language Class Initialized
INFO - 2018-10-22 12:59:58 --> Loader Class Initialized
INFO - 2018-10-22 12:59:58 --> Helper loaded: url_helper
INFO - 2018-10-22 12:59:58 --> Helper loaded: form_helper
INFO - 2018-10-22 12:59:58 --> Helper loaded: language_helper
DEBUG - 2018-10-22 12:59:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 12:59:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 12:59:58 --> User Agent Class Initialized
INFO - 2018-10-22 12:59:58 --> Controller Class Initialized
INFO - 2018-10-22 12:59:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 12:59:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 12:59:59 --> Helper loaded: custom_helper
INFO - 2018-10-22 12:59:59 --> Pixel_Model class loaded
INFO - 2018-10-22 12:59:59 --> Database Driver Class Initialized
INFO - 2018-10-22 12:59:59 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 12:59:59 --> Form Validation Class Initialized
INFO - 2018-10-22 12:59:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 12:59:59 --> Database Driver Class Initialized
INFO - 2018-10-22 12:59:59 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:00:10 --> Config Class Initialized
INFO - 2018-10-22 13:00:10 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:00:10 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:00:10 --> Utf8 Class Initialized
INFO - 2018-10-22 13:00:10 --> URI Class Initialized
INFO - 2018-10-22 13:00:10 --> Router Class Initialized
INFO - 2018-10-22 13:00:10 --> Output Class Initialized
INFO - 2018-10-22 13:00:10 --> Security Class Initialized
DEBUG - 2018-10-22 13:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:00:10 --> CSRF cookie sent
INFO - 2018-10-22 13:00:10 --> Input Class Initialized
INFO - 2018-10-22 13:00:10 --> Language Class Initialized
INFO - 2018-10-22 13:00:10 --> Loader Class Initialized
INFO - 2018-10-22 13:00:10 --> Helper loaded: url_helper
INFO - 2018-10-22 13:00:10 --> Helper loaded: form_helper
INFO - 2018-10-22 13:00:10 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:00:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:00:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:00:10 --> User Agent Class Initialized
INFO - 2018-10-22 13:00:10 --> Controller Class Initialized
INFO - 2018-10-22 13:00:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:00:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:00:10 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:00:10 --> Pixel_Model class loaded
INFO - 2018-10-22 13:00:10 --> Database Driver Class Initialized
INFO - 2018-10-22 13:00:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:00:10 --> Database Driver Class Initialized
INFO - 2018-10-22 13:00:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:00:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:00:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:00:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner.php
INFO - 2018-10-22 13:00:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:00:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:00:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:00:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:00:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/relation_ship_status.php
INFO - 2018-10-22 13:00:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:00:10 --> Final output sent to browser
DEBUG - 2018-10-22 13:00:11 --> Total execution time: 0.3872
INFO - 2018-10-22 13:00:11 --> Config Class Initialized
INFO - 2018-10-22 13:00:11 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:00:11 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:00:11 --> Utf8 Class Initialized
INFO - 2018-10-22 13:00:11 --> URI Class Initialized
INFO - 2018-10-22 13:00:11 --> Router Class Initialized
INFO - 2018-10-22 13:00:11 --> Output Class Initialized
INFO - 2018-10-22 13:00:11 --> Security Class Initialized
DEBUG - 2018-10-22 13:00:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:00:11 --> CSRF cookie sent
INFO - 2018-10-22 13:00:11 --> Input Class Initialized
INFO - 2018-10-22 13:00:11 --> Language Class Initialized
ERROR - 2018-10-22 13:00:11 --> 404 Page Not Found: Assets/css
INFO - 2018-10-22 13:00:13 --> Config Class Initialized
INFO - 2018-10-22 13:00:13 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:00:13 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:00:13 --> Utf8 Class Initialized
INFO - 2018-10-22 13:00:13 --> URI Class Initialized
INFO - 2018-10-22 13:00:13 --> Router Class Initialized
INFO - 2018-10-22 13:00:13 --> Output Class Initialized
INFO - 2018-10-22 13:00:13 --> Security Class Initialized
DEBUG - 2018-10-22 13:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:00:13 --> CSRF cookie sent
INFO - 2018-10-22 13:00:13 --> CSRF token verified
INFO - 2018-10-22 13:00:13 --> Input Class Initialized
INFO - 2018-10-22 13:00:13 --> Language Class Initialized
INFO - 2018-10-22 13:00:13 --> Loader Class Initialized
INFO - 2018-10-22 13:00:13 --> Helper loaded: url_helper
INFO - 2018-10-22 13:00:13 --> Helper loaded: form_helper
INFO - 2018-10-22 13:00:13 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:00:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:00:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:00:13 --> User Agent Class Initialized
INFO - 2018-10-22 13:00:13 --> Controller Class Initialized
INFO - 2018-10-22 13:00:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:00:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:00:13 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:00:13 --> Pixel_Model class loaded
INFO - 2018-10-22 13:00:13 --> Database Driver Class Initialized
INFO - 2018-10-22 13:00:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:00:13 --> Form Validation Class Initialized
INFO - 2018-10-22 13:00:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:00:13 --> Database Driver Class Initialized
INFO - 2018-10-22 13:00:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:00:55 --> Config Class Initialized
INFO - 2018-10-22 13:00:55 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:00:55 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:00:55 --> Utf8 Class Initialized
INFO - 2018-10-22 13:00:55 --> URI Class Initialized
INFO - 2018-10-22 13:00:55 --> Router Class Initialized
INFO - 2018-10-22 13:00:55 --> Output Class Initialized
INFO - 2018-10-22 13:00:55 --> Security Class Initialized
DEBUG - 2018-10-22 13:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:00:55 --> CSRF cookie sent
INFO - 2018-10-22 13:00:55 --> CSRF token verified
INFO - 2018-10-22 13:00:55 --> Input Class Initialized
INFO - 2018-10-22 13:00:55 --> Language Class Initialized
INFO - 2018-10-22 13:00:55 --> Loader Class Initialized
INFO - 2018-10-22 13:00:55 --> Helper loaded: url_helper
INFO - 2018-10-22 13:00:55 --> Helper loaded: form_helper
INFO - 2018-10-22 13:00:55 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:00:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:00:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:00:55 --> User Agent Class Initialized
INFO - 2018-10-22 13:00:55 --> Controller Class Initialized
INFO - 2018-10-22 13:00:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:00:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:00:55 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:00:55 --> Pixel_Model class loaded
INFO - 2018-10-22 13:00:55 --> Database Driver Class Initialized
INFO - 2018-10-22 13:00:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:00:55 --> Form Validation Class Initialized
INFO - 2018-10-22 13:00:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:00:55 --> Database Driver Class Initialized
INFO - 2018-10-22 13:00:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:00:55 --> Config Class Initialized
INFO - 2018-10-22 13:00:55 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:00:55 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:00:55 --> Utf8 Class Initialized
INFO - 2018-10-22 13:00:55 --> URI Class Initialized
INFO - 2018-10-22 13:00:55 --> Router Class Initialized
INFO - 2018-10-22 13:00:55 --> Output Class Initialized
INFO - 2018-10-22 13:00:55 --> Security Class Initialized
DEBUG - 2018-10-22 13:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:00:55 --> CSRF cookie sent
INFO - 2018-10-22 13:00:55 --> Input Class Initialized
INFO - 2018-10-22 13:00:55 --> Language Class Initialized
INFO - 2018-10-22 13:00:55 --> Loader Class Initialized
INFO - 2018-10-22 13:00:55 --> Helper loaded: url_helper
INFO - 2018-10-22 13:00:55 --> Helper loaded: form_helper
INFO - 2018-10-22 13:00:55 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:00:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:00:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:00:55 --> User Agent Class Initialized
INFO - 2018-10-22 13:00:55 --> Controller Class Initialized
INFO - 2018-10-22 13:00:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:00:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:00:55 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:00:55 --> Pixel_Model class loaded
INFO - 2018-10-22 13:00:55 --> Database Driver Class Initialized
INFO - 2018-10-22 13:00:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:00:55 --> Database Driver Class Initialized
INFO - 2018-10-22 13:00:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:00:55 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:00:55 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:00:55 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:00:55 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:00:55 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:00:55 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:00:55 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/income.php
INFO - 2018-10-22 13:00:55 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:00:56 --> Final output sent to browser
DEBUG - 2018-10-22 13:00:56 --> Total execution time: 0.3984
INFO - 2018-10-22 13:00:56 --> Config Class Initialized
INFO - 2018-10-22 13:00:56 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:00:56 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:00:56 --> Utf8 Class Initialized
INFO - 2018-10-22 13:00:56 --> URI Class Initialized
INFO - 2018-10-22 13:00:56 --> Router Class Initialized
INFO - 2018-10-22 13:00:56 --> Output Class Initialized
INFO - 2018-10-22 13:00:56 --> Security Class Initialized
DEBUG - 2018-10-22 13:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:00:56 --> CSRF cookie sent
INFO - 2018-10-22 13:00:56 --> Input Class Initialized
INFO - 2018-10-22 13:00:56 --> Language Class Initialized
ERROR - 2018-10-22 13:00:56 --> 404 Page Not Found: Assets/css
INFO - 2018-10-22 13:02:06 --> Config Class Initialized
INFO - 2018-10-22 13:02:06 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:02:06 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:02:06 --> Utf8 Class Initialized
INFO - 2018-10-22 13:02:06 --> URI Class Initialized
INFO - 2018-10-22 13:02:06 --> Router Class Initialized
INFO - 2018-10-22 13:02:06 --> Output Class Initialized
INFO - 2018-10-22 13:02:06 --> Security Class Initialized
DEBUG - 2018-10-22 13:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:02:06 --> CSRF cookie sent
INFO - 2018-10-22 13:02:06 --> Input Class Initialized
INFO - 2018-10-22 13:02:06 --> Language Class Initialized
INFO - 2018-10-22 13:02:06 --> Loader Class Initialized
INFO - 2018-10-22 13:02:06 --> Helper loaded: url_helper
INFO - 2018-10-22 13:02:06 --> Helper loaded: form_helper
INFO - 2018-10-22 13:02:06 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:02:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:02:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:02:06 --> User Agent Class Initialized
INFO - 2018-10-22 13:02:06 --> Controller Class Initialized
INFO - 2018-10-22 13:02:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:02:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:02:06 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:02:06 --> Pixel_Model class loaded
INFO - 2018-10-22 13:02:06 --> Database Driver Class Initialized
INFO - 2018-10-22 13:02:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:02:06 --> Database Driver Class Initialized
INFO - 2018-10-22 13:02:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:02:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:02:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:02:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner.php
INFO - 2018-10-22 13:02:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:02:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:02:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:02:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:02:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/relation_ship_status.php
INFO - 2018-10-22 13:02:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:02:06 --> Final output sent to browser
DEBUG - 2018-10-22 13:02:06 --> Total execution time: 0.3742
INFO - 2018-10-22 13:02:09 --> Config Class Initialized
INFO - 2018-10-22 13:02:09 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:02:09 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:02:09 --> Utf8 Class Initialized
INFO - 2018-10-22 13:02:09 --> URI Class Initialized
INFO - 2018-10-22 13:02:09 --> Router Class Initialized
INFO - 2018-10-22 13:02:09 --> Output Class Initialized
INFO - 2018-10-22 13:02:09 --> Security Class Initialized
DEBUG - 2018-10-22 13:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:02:09 --> CSRF cookie sent
INFO - 2018-10-22 13:02:09 --> CSRF token verified
INFO - 2018-10-22 13:02:09 --> Input Class Initialized
INFO - 2018-10-22 13:02:09 --> Language Class Initialized
INFO - 2018-10-22 13:02:09 --> Loader Class Initialized
INFO - 2018-10-22 13:02:09 --> Helper loaded: url_helper
INFO - 2018-10-22 13:02:09 --> Helper loaded: form_helper
INFO - 2018-10-22 13:02:09 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:02:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:02:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:02:09 --> User Agent Class Initialized
INFO - 2018-10-22 13:02:09 --> Controller Class Initialized
INFO - 2018-10-22 13:02:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:02:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:02:09 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:02:09 --> Pixel_Model class loaded
INFO - 2018-10-22 13:02:09 --> Database Driver Class Initialized
INFO - 2018-10-22 13:02:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:02:09 --> Form Validation Class Initialized
INFO - 2018-10-22 13:02:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:02:09 --> Database Driver Class Initialized
INFO - 2018-10-22 13:02:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:02:10 --> Config Class Initialized
INFO - 2018-10-22 13:02:10 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:02:10 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:02:10 --> Utf8 Class Initialized
INFO - 2018-10-22 13:02:10 --> URI Class Initialized
INFO - 2018-10-22 13:02:10 --> Router Class Initialized
INFO - 2018-10-22 13:02:10 --> Output Class Initialized
INFO - 2018-10-22 13:02:10 --> Security Class Initialized
DEBUG - 2018-10-22 13:02:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:02:10 --> CSRF cookie sent
INFO - 2018-10-22 13:02:10 --> Input Class Initialized
INFO - 2018-10-22 13:02:10 --> Language Class Initialized
INFO - 2018-10-22 13:02:10 --> Loader Class Initialized
INFO - 2018-10-22 13:02:10 --> Helper loaded: url_helper
INFO - 2018-10-22 13:02:10 --> Helper loaded: form_helper
INFO - 2018-10-22 13:02:10 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:02:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:02:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:02:10 --> User Agent Class Initialized
INFO - 2018-10-22 13:02:10 --> Controller Class Initialized
INFO - 2018-10-22 13:02:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:02:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:02:10 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:02:10 --> Pixel_Model class loaded
INFO - 2018-10-22 13:02:10 --> Database Driver Class Initialized
INFO - 2018-10-22 13:02:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:02:10 --> Database Driver Class Initialized
INFO - 2018-10-22 13:02:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:02:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:02:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:02:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:02:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:02:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:02:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:02:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/income.php
INFO - 2018-10-22 13:02:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:02:10 --> Final output sent to browser
DEBUG - 2018-10-22 13:02:10 --> Total execution time: 0.3607
INFO - 2018-10-22 13:04:12 --> Config Class Initialized
INFO - 2018-10-22 13:04:12 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:04:12 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:04:12 --> Utf8 Class Initialized
INFO - 2018-10-22 13:04:12 --> URI Class Initialized
INFO - 2018-10-22 13:04:12 --> Router Class Initialized
INFO - 2018-10-22 13:04:12 --> Output Class Initialized
INFO - 2018-10-22 13:04:12 --> Security Class Initialized
DEBUG - 2018-10-22 13:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:04:12 --> CSRF cookie sent
INFO - 2018-10-22 13:04:12 --> Input Class Initialized
INFO - 2018-10-22 13:04:12 --> Language Class Initialized
INFO - 2018-10-22 13:04:12 --> Loader Class Initialized
INFO - 2018-10-22 13:04:12 --> Helper loaded: url_helper
INFO - 2018-10-22 13:04:12 --> Helper loaded: form_helper
INFO - 2018-10-22 13:04:12 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:04:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:04:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:04:12 --> User Agent Class Initialized
INFO - 2018-10-22 13:04:12 --> Controller Class Initialized
INFO - 2018-10-22 13:04:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:04:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:04:12 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:04:12 --> Pixel_Model class loaded
INFO - 2018-10-22 13:04:12 --> Database Driver Class Initialized
INFO - 2018-10-22 13:04:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:04:47 --> Config Class Initialized
INFO - 2018-10-22 13:04:47 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:04:47 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:04:47 --> Utf8 Class Initialized
INFO - 2018-10-22 13:04:47 --> URI Class Initialized
INFO - 2018-10-22 13:04:47 --> Router Class Initialized
INFO - 2018-10-22 13:04:47 --> Output Class Initialized
INFO - 2018-10-22 13:04:47 --> Security Class Initialized
DEBUG - 2018-10-22 13:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:04:47 --> CSRF cookie sent
INFO - 2018-10-22 13:04:47 --> Input Class Initialized
INFO - 2018-10-22 13:04:47 --> Language Class Initialized
INFO - 2018-10-22 13:04:47 --> Loader Class Initialized
INFO - 2018-10-22 13:04:47 --> Helper loaded: url_helper
INFO - 2018-10-22 13:04:47 --> Helper loaded: form_helper
INFO - 2018-10-22 13:04:47 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:04:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:04:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:04:47 --> User Agent Class Initialized
INFO - 2018-10-22 13:04:47 --> Controller Class Initialized
INFO - 2018-10-22 13:04:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:04:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:04:47 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:04:47 --> Pixel_Model class loaded
INFO - 2018-10-22 13:04:47 --> Database Driver Class Initialized
INFO - 2018-10-22 13:04:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:04:47 --> Database Driver Class Initialized
INFO - 2018-10-22 13:04:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:06:05 --> Config Class Initialized
INFO - 2018-10-22 13:06:05 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:06:05 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:06:05 --> Utf8 Class Initialized
INFO - 2018-10-22 13:06:05 --> URI Class Initialized
INFO - 2018-10-22 13:06:05 --> Router Class Initialized
INFO - 2018-10-22 13:06:05 --> Output Class Initialized
INFO - 2018-10-22 13:06:05 --> Security Class Initialized
DEBUG - 2018-10-22 13:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:06:05 --> CSRF cookie sent
INFO - 2018-10-22 13:06:05 --> Input Class Initialized
INFO - 2018-10-22 13:06:05 --> Language Class Initialized
INFO - 2018-10-22 13:06:05 --> Loader Class Initialized
INFO - 2018-10-22 13:06:05 --> Helper loaded: url_helper
INFO - 2018-10-22 13:06:05 --> Helper loaded: form_helper
INFO - 2018-10-22 13:06:05 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:06:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:06:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:06:05 --> User Agent Class Initialized
INFO - 2018-10-22 13:06:05 --> Controller Class Initialized
INFO - 2018-10-22 13:06:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:06:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:06:06 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:06:06 --> Pixel_Model class loaded
INFO - 2018-10-22 13:06:06 --> Database Driver Class Initialized
INFO - 2018-10-22 13:06:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:06:06 --> Database Driver Class Initialized
INFO - 2018-10-22 13:06:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:06:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:06:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:06:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:06:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:06:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:06:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:06:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/income.php
INFO - 2018-10-22 13:06:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:06:06 --> Final output sent to browser
DEBUG - 2018-10-22 13:06:06 --> Total execution time: 0.3727
INFO - 2018-10-22 13:06:09 --> Config Class Initialized
INFO - 2018-10-22 13:06:09 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:06:09 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:06:09 --> Utf8 Class Initialized
INFO - 2018-10-22 13:06:09 --> URI Class Initialized
INFO - 2018-10-22 13:06:09 --> Router Class Initialized
INFO - 2018-10-22 13:06:09 --> Output Class Initialized
INFO - 2018-10-22 13:06:09 --> Security Class Initialized
DEBUG - 2018-10-22 13:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:06:09 --> CSRF cookie sent
INFO - 2018-10-22 13:06:09 --> CSRF token verified
INFO - 2018-10-22 13:06:09 --> Input Class Initialized
INFO - 2018-10-22 13:06:09 --> Language Class Initialized
INFO - 2018-10-22 13:06:09 --> Loader Class Initialized
INFO - 2018-10-22 13:06:09 --> Helper loaded: url_helper
INFO - 2018-10-22 13:06:09 --> Helper loaded: form_helper
INFO - 2018-10-22 13:06:10 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:06:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:06:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:06:10 --> User Agent Class Initialized
INFO - 2018-10-22 13:06:10 --> Controller Class Initialized
INFO - 2018-10-22 13:06:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:06:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:06:10 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:06:10 --> Pixel_Model class loaded
INFO - 2018-10-22 13:06:10 --> Database Driver Class Initialized
INFO - 2018-10-22 13:06:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:06:10 --> Form Validation Class Initialized
INFO - 2018-10-22 13:06:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:06:10 --> Database Driver Class Initialized
INFO - 2018-10-22 13:06:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:07:11 --> Config Class Initialized
INFO - 2018-10-22 13:07:11 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:07:11 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:07:11 --> Utf8 Class Initialized
INFO - 2018-10-22 13:07:11 --> URI Class Initialized
INFO - 2018-10-22 13:07:11 --> Router Class Initialized
INFO - 2018-10-22 13:07:11 --> Output Class Initialized
INFO - 2018-10-22 13:07:11 --> Security Class Initialized
DEBUG - 2018-10-22 13:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:07:11 --> CSRF cookie sent
INFO - 2018-10-22 13:07:11 --> Input Class Initialized
INFO - 2018-10-22 13:07:11 --> Language Class Initialized
INFO - 2018-10-22 13:07:11 --> Loader Class Initialized
INFO - 2018-10-22 13:07:11 --> Helper loaded: url_helper
INFO - 2018-10-22 13:07:11 --> Helper loaded: form_helper
INFO - 2018-10-22 13:07:11 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:07:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:07:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:07:11 --> User Agent Class Initialized
INFO - 2018-10-22 13:07:11 --> Controller Class Initialized
INFO - 2018-10-22 13:07:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:07:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:07:11 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:07:11 --> Pixel_Model class loaded
INFO - 2018-10-22 13:07:11 --> Database Driver Class Initialized
INFO - 2018-10-22 13:07:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:07:11 --> Database Driver Class Initialized
INFO - 2018-10-22 13:07:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:07:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:07:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:07:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:07:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:07:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:07:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:07:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/income.php
INFO - 2018-10-22 13:07:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:07:11 --> Final output sent to browser
DEBUG - 2018-10-22 13:07:11 --> Total execution time: 0.4156
INFO - 2018-10-22 13:07:12 --> Config Class Initialized
INFO - 2018-10-22 13:07:12 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:07:12 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:07:12 --> Utf8 Class Initialized
INFO - 2018-10-22 13:07:12 --> URI Class Initialized
INFO - 2018-10-22 13:07:12 --> Router Class Initialized
INFO - 2018-10-22 13:07:12 --> Output Class Initialized
INFO - 2018-10-22 13:07:12 --> Security Class Initialized
DEBUG - 2018-10-22 13:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:07:12 --> CSRF cookie sent
INFO - 2018-10-22 13:07:12 --> Input Class Initialized
INFO - 2018-10-22 13:07:12 --> Language Class Initialized
INFO - 2018-10-22 13:07:12 --> Loader Class Initialized
INFO - 2018-10-22 13:07:12 --> Helper loaded: url_helper
INFO - 2018-10-22 13:07:12 --> Helper loaded: form_helper
INFO - 2018-10-22 13:07:12 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:07:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:07:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:07:12 --> User Agent Class Initialized
INFO - 2018-10-22 13:07:12 --> Controller Class Initialized
INFO - 2018-10-22 13:07:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:07:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:07:12 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:07:12 --> Pixel_Model class loaded
INFO - 2018-10-22 13:07:12 --> Database Driver Class Initialized
INFO - 2018-10-22 13:07:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:07:12 --> Database Driver Class Initialized
INFO - 2018-10-22 13:07:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:07:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:07:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:07:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner.php
INFO - 2018-10-22 13:07:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:07:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:07:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:07:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:07:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/relation_ship_status.php
INFO - 2018-10-22 13:07:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:07:12 --> Final output sent to browser
DEBUG - 2018-10-22 13:07:12 --> Total execution time: 0.4553
INFO - 2018-10-22 13:07:14 --> Config Class Initialized
INFO - 2018-10-22 13:07:14 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:07:14 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:07:14 --> Utf8 Class Initialized
INFO - 2018-10-22 13:07:14 --> URI Class Initialized
INFO - 2018-10-22 13:07:14 --> Router Class Initialized
INFO - 2018-10-22 13:07:14 --> Output Class Initialized
INFO - 2018-10-22 13:07:14 --> Security Class Initialized
DEBUG - 2018-10-22 13:07:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:07:14 --> CSRF cookie sent
INFO - 2018-10-22 13:07:14 --> Input Class Initialized
INFO - 2018-10-22 13:07:14 --> Language Class Initialized
INFO - 2018-10-22 13:07:14 --> Loader Class Initialized
INFO - 2018-10-22 13:07:14 --> Helper loaded: url_helper
INFO - 2018-10-22 13:07:14 --> Helper loaded: form_helper
INFO - 2018-10-22 13:07:14 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:07:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:07:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:07:14 --> User Agent Class Initialized
INFO - 2018-10-22 13:07:14 --> Controller Class Initialized
INFO - 2018-10-22 13:07:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:07:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:07:14 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:07:14 --> Pixel_Model class loaded
INFO - 2018-10-22 13:07:14 --> Database Driver Class Initialized
INFO - 2018-10-22 13:07:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:07:15 --> Database Driver Class Initialized
INFO - 2018-10-22 13:07:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:07:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:07:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:07:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner.php
INFO - 2018-10-22 13:07:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:07:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:07:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:07:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:07:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/relation_ship_status.php
INFO - 2018-10-22 13:07:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:07:15 --> Final output sent to browser
DEBUG - 2018-10-22 13:07:15 --> Total execution time: 0.4347
INFO - 2018-10-22 13:07:29 --> Config Class Initialized
INFO - 2018-10-22 13:07:29 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:07:29 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:07:29 --> Utf8 Class Initialized
INFO - 2018-10-22 13:07:29 --> URI Class Initialized
INFO - 2018-10-22 13:07:29 --> Router Class Initialized
INFO - 2018-10-22 13:07:29 --> Output Class Initialized
INFO - 2018-10-22 13:07:29 --> Security Class Initialized
DEBUG - 2018-10-22 13:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:07:29 --> CSRF cookie sent
INFO - 2018-10-22 13:07:29 --> CSRF token verified
INFO - 2018-10-22 13:07:29 --> Input Class Initialized
INFO - 2018-10-22 13:07:29 --> Language Class Initialized
INFO - 2018-10-22 13:07:29 --> Loader Class Initialized
INFO - 2018-10-22 13:07:29 --> Helper loaded: url_helper
INFO - 2018-10-22 13:07:29 --> Helper loaded: form_helper
INFO - 2018-10-22 13:07:29 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:07:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:07:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:07:29 --> User Agent Class Initialized
INFO - 2018-10-22 13:07:29 --> Controller Class Initialized
INFO - 2018-10-22 13:07:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:07:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:07:29 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:07:29 --> Pixel_Model class loaded
INFO - 2018-10-22 13:07:29 --> Database Driver Class Initialized
INFO - 2018-10-22 13:07:29 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:07:29 --> Form Validation Class Initialized
INFO - 2018-10-22 13:07:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:07:29 --> Database Driver Class Initialized
INFO - 2018-10-22 13:07:29 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:07:29 --> Config Class Initialized
INFO - 2018-10-22 13:07:29 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:07:29 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:07:29 --> Utf8 Class Initialized
INFO - 2018-10-22 13:07:29 --> URI Class Initialized
INFO - 2018-10-22 13:07:29 --> Router Class Initialized
INFO - 2018-10-22 13:07:29 --> Output Class Initialized
INFO - 2018-10-22 13:07:29 --> Security Class Initialized
DEBUG - 2018-10-22 13:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:07:29 --> CSRF cookie sent
INFO - 2018-10-22 13:07:29 --> Input Class Initialized
INFO - 2018-10-22 13:07:29 --> Language Class Initialized
INFO - 2018-10-22 13:07:29 --> Loader Class Initialized
INFO - 2018-10-22 13:07:29 --> Helper loaded: url_helper
INFO - 2018-10-22 13:07:29 --> Helper loaded: form_helper
INFO - 2018-10-22 13:07:29 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:07:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:07:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:07:29 --> User Agent Class Initialized
INFO - 2018-10-22 13:07:29 --> Controller Class Initialized
INFO - 2018-10-22 13:07:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:07:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:07:29 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:07:29 --> Pixel_Model class loaded
INFO - 2018-10-22 13:07:29 --> Database Driver Class Initialized
INFO - 2018-10-22 13:07:29 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:07:29 --> Database Driver Class Initialized
INFO - 2018-10-22 13:07:29 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:07:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:07:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:07:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:07:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:07:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:07:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:07:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/income.php
INFO - 2018-10-22 13:07:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:07:29 --> Final output sent to browser
DEBUG - 2018-10-22 13:07:29 --> Total execution time: 0.4029
INFO - 2018-10-22 13:07:47 --> Config Class Initialized
INFO - 2018-10-22 13:07:47 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:07:47 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:07:47 --> Utf8 Class Initialized
INFO - 2018-10-22 13:07:47 --> URI Class Initialized
INFO - 2018-10-22 13:07:47 --> Router Class Initialized
INFO - 2018-10-22 13:07:47 --> Output Class Initialized
INFO - 2018-10-22 13:07:47 --> Security Class Initialized
DEBUG - 2018-10-22 13:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:07:47 --> CSRF cookie sent
INFO - 2018-10-22 13:07:47 --> CSRF token verified
INFO - 2018-10-22 13:07:47 --> Input Class Initialized
INFO - 2018-10-22 13:07:47 --> Language Class Initialized
INFO - 2018-10-22 13:07:47 --> Loader Class Initialized
INFO - 2018-10-22 13:07:47 --> Helper loaded: url_helper
INFO - 2018-10-22 13:07:47 --> Helper loaded: form_helper
INFO - 2018-10-22 13:07:47 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:07:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:07:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:07:47 --> User Agent Class Initialized
INFO - 2018-10-22 13:07:47 --> Controller Class Initialized
INFO - 2018-10-22 13:07:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:07:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:07:47 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:07:47 --> Pixel_Model class loaded
INFO - 2018-10-22 13:07:47 --> Database Driver Class Initialized
INFO - 2018-10-22 13:07:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:07:47 --> Form Validation Class Initialized
INFO - 2018-10-22 13:07:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:07:47 --> Database Driver Class Initialized
INFO - 2018-10-22 13:07:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:08:42 --> Config Class Initialized
INFO - 2018-10-22 13:08:42 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:08:42 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:08:42 --> Utf8 Class Initialized
INFO - 2018-10-22 13:08:42 --> URI Class Initialized
INFO - 2018-10-22 13:08:42 --> Router Class Initialized
INFO - 2018-10-22 13:08:42 --> Output Class Initialized
INFO - 2018-10-22 13:08:42 --> Security Class Initialized
DEBUG - 2018-10-22 13:08:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:08:42 --> CSRF cookie sent
INFO - 2018-10-22 13:08:42 --> Input Class Initialized
INFO - 2018-10-22 13:08:42 --> Language Class Initialized
INFO - 2018-10-22 13:08:42 --> Loader Class Initialized
INFO - 2018-10-22 13:08:42 --> Helper loaded: url_helper
INFO - 2018-10-22 13:08:42 --> Helper loaded: form_helper
INFO - 2018-10-22 13:08:42 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:08:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:08:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:08:42 --> User Agent Class Initialized
INFO - 2018-10-22 13:08:42 --> Controller Class Initialized
INFO - 2018-10-22 13:08:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:08:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:08:42 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:08:42 --> Pixel_Model class loaded
INFO - 2018-10-22 13:08:42 --> Database Driver Class Initialized
INFO - 2018-10-22 13:08:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:08:42 --> Database Driver Class Initialized
INFO - 2018-10-22 13:08:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:09:10 --> Config Class Initialized
INFO - 2018-10-22 13:09:10 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:09:10 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:09:10 --> Utf8 Class Initialized
INFO - 2018-10-22 13:09:10 --> URI Class Initialized
INFO - 2018-10-22 13:09:10 --> Router Class Initialized
INFO - 2018-10-22 13:09:10 --> Output Class Initialized
INFO - 2018-10-22 13:09:10 --> Security Class Initialized
DEBUG - 2018-10-22 13:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:09:10 --> CSRF cookie sent
INFO - 2018-10-22 13:09:10 --> Input Class Initialized
INFO - 2018-10-22 13:09:10 --> Language Class Initialized
INFO - 2018-10-22 13:09:10 --> Loader Class Initialized
INFO - 2018-10-22 13:09:10 --> Helper loaded: url_helper
INFO - 2018-10-22 13:09:10 --> Helper loaded: form_helper
INFO - 2018-10-22 13:09:10 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:09:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:09:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:09:10 --> User Agent Class Initialized
INFO - 2018-10-22 13:09:10 --> Controller Class Initialized
INFO - 2018-10-22 13:09:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:09:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:09:10 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:09:10 --> Pixel_Model class loaded
INFO - 2018-10-22 13:09:10 --> Database Driver Class Initialized
INFO - 2018-10-22 13:09:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:09:10 --> Database Driver Class Initialized
INFO - 2018-10-22 13:09:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:09:57 --> Config Class Initialized
INFO - 2018-10-22 13:09:57 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:09:57 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:09:57 --> Utf8 Class Initialized
INFO - 2018-10-22 13:09:57 --> URI Class Initialized
INFO - 2018-10-22 13:09:57 --> Router Class Initialized
INFO - 2018-10-22 13:09:57 --> Output Class Initialized
INFO - 2018-10-22 13:09:57 --> Security Class Initialized
DEBUG - 2018-10-22 13:09:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:09:57 --> CSRF cookie sent
INFO - 2018-10-22 13:09:57 --> Input Class Initialized
INFO - 2018-10-22 13:09:57 --> Language Class Initialized
INFO - 2018-10-22 13:09:57 --> Loader Class Initialized
INFO - 2018-10-22 13:09:57 --> Helper loaded: url_helper
INFO - 2018-10-22 13:09:57 --> Helper loaded: form_helper
INFO - 2018-10-22 13:09:57 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:09:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:09:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:09:57 --> User Agent Class Initialized
INFO - 2018-10-22 13:09:57 --> Controller Class Initialized
INFO - 2018-10-22 13:09:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:09:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:09:57 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:09:57 --> Pixel_Model class loaded
INFO - 2018-10-22 13:09:57 --> Database Driver Class Initialized
INFO - 2018-10-22 13:09:57 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:09:57 --> Database Driver Class Initialized
INFO - 2018-10-22 13:09:57 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:11:13 --> Config Class Initialized
INFO - 2018-10-22 13:11:13 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:11:13 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:11:13 --> Utf8 Class Initialized
INFO - 2018-10-22 13:11:13 --> URI Class Initialized
INFO - 2018-10-22 13:11:13 --> Router Class Initialized
INFO - 2018-10-22 13:11:13 --> Output Class Initialized
INFO - 2018-10-22 13:11:13 --> Security Class Initialized
DEBUG - 2018-10-22 13:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:11:13 --> CSRF cookie sent
INFO - 2018-10-22 13:11:13 --> Input Class Initialized
INFO - 2018-10-22 13:11:13 --> Language Class Initialized
INFO - 2018-10-22 13:11:13 --> Loader Class Initialized
INFO - 2018-10-22 13:11:13 --> Helper loaded: url_helper
INFO - 2018-10-22 13:11:13 --> Helper loaded: form_helper
INFO - 2018-10-22 13:11:13 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:11:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:11:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:11:13 --> User Agent Class Initialized
INFO - 2018-10-22 13:11:13 --> Controller Class Initialized
INFO - 2018-10-22 13:11:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:11:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:11:13 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:11:13 --> Pixel_Model class loaded
INFO - 2018-10-22 13:11:13 --> Database Driver Class Initialized
INFO - 2018-10-22 13:11:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:11:13 --> Database Driver Class Initialized
INFO - 2018-10-22 13:11:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:11:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:11:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:11:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner.php
INFO - 2018-10-22 13:11:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:11:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:11:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:11:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:11:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/relation_ship_status.php
INFO - 2018-10-22 13:11:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:11:13 --> Final output sent to browser
DEBUG - 2018-10-22 13:11:13 --> Total execution time: 0.4131
INFO - 2018-10-22 13:11:17 --> Config Class Initialized
INFO - 2018-10-22 13:11:17 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:11:17 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:11:17 --> Utf8 Class Initialized
INFO - 2018-10-22 13:11:17 --> URI Class Initialized
INFO - 2018-10-22 13:11:17 --> Router Class Initialized
INFO - 2018-10-22 13:11:17 --> Output Class Initialized
INFO - 2018-10-22 13:11:17 --> Security Class Initialized
DEBUG - 2018-10-22 13:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:11:17 --> CSRF cookie sent
INFO - 2018-10-22 13:11:17 --> Input Class Initialized
INFO - 2018-10-22 13:11:17 --> Language Class Initialized
INFO - 2018-10-22 13:11:17 --> Loader Class Initialized
INFO - 2018-10-22 13:11:17 --> Helper loaded: url_helper
INFO - 2018-10-22 13:11:17 --> Helper loaded: form_helper
INFO - 2018-10-22 13:11:17 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:11:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:11:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:11:17 --> User Agent Class Initialized
INFO - 2018-10-22 13:11:17 --> Controller Class Initialized
INFO - 2018-10-22 13:11:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:11:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:11:17 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:11:17 --> Pixel_Model class loaded
INFO - 2018-10-22 13:11:17 --> Database Driver Class Initialized
INFO - 2018-10-22 13:11:17 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:11:17 --> Database Driver Class Initialized
INFO - 2018-10-22 13:11:17 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:11:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:11:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:11:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner.php
INFO - 2018-10-22 13:11:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:11:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:11:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:11:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:11:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/relation_ship_status.php
INFO - 2018-10-22 13:11:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:11:17 --> Final output sent to browser
DEBUG - 2018-10-22 13:11:17 --> Total execution time: 0.4378
INFO - 2018-10-22 13:11:21 --> Config Class Initialized
INFO - 2018-10-22 13:11:21 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:11:21 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:11:21 --> Utf8 Class Initialized
INFO - 2018-10-22 13:11:21 --> URI Class Initialized
INFO - 2018-10-22 13:11:21 --> Router Class Initialized
INFO - 2018-10-22 13:11:21 --> Output Class Initialized
INFO - 2018-10-22 13:11:21 --> Security Class Initialized
DEBUG - 2018-10-22 13:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:11:21 --> CSRF cookie sent
INFO - 2018-10-22 13:11:21 --> CSRF token verified
INFO - 2018-10-22 13:11:21 --> Input Class Initialized
INFO - 2018-10-22 13:11:21 --> Language Class Initialized
INFO - 2018-10-22 13:11:21 --> Loader Class Initialized
INFO - 2018-10-22 13:11:21 --> Helper loaded: url_helper
INFO - 2018-10-22 13:11:21 --> Helper loaded: form_helper
INFO - 2018-10-22 13:11:21 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:11:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:11:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:11:21 --> User Agent Class Initialized
INFO - 2018-10-22 13:11:21 --> Controller Class Initialized
INFO - 2018-10-22 13:11:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:11:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:11:21 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:11:21 --> Pixel_Model class loaded
INFO - 2018-10-22 13:11:21 --> Database Driver Class Initialized
INFO - 2018-10-22 13:11:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:11:21 --> Form Validation Class Initialized
INFO - 2018-10-22 13:11:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:11:21 --> Database Driver Class Initialized
INFO - 2018-10-22 13:11:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:11:21 --> Config Class Initialized
INFO - 2018-10-22 13:11:21 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:11:21 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:11:21 --> Utf8 Class Initialized
INFO - 2018-10-22 13:11:21 --> URI Class Initialized
INFO - 2018-10-22 13:11:21 --> Router Class Initialized
INFO - 2018-10-22 13:11:21 --> Output Class Initialized
INFO - 2018-10-22 13:11:21 --> Security Class Initialized
DEBUG - 2018-10-22 13:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:11:21 --> CSRF cookie sent
INFO - 2018-10-22 13:11:21 --> Input Class Initialized
INFO - 2018-10-22 13:11:21 --> Language Class Initialized
INFO - 2018-10-22 13:11:21 --> Loader Class Initialized
INFO - 2018-10-22 13:11:21 --> Helper loaded: url_helper
INFO - 2018-10-22 13:11:21 --> Helper loaded: form_helper
INFO - 2018-10-22 13:11:21 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:11:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:11:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:11:21 --> User Agent Class Initialized
INFO - 2018-10-22 13:11:21 --> Controller Class Initialized
INFO - 2018-10-22 13:11:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:11:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:11:21 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:11:21 --> Pixel_Model class loaded
INFO - 2018-10-22 13:11:21 --> Database Driver Class Initialized
INFO - 2018-10-22 13:11:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:11:21 --> Database Driver Class Initialized
INFO - 2018-10-22 13:11:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:12:01 --> Config Class Initialized
INFO - 2018-10-22 13:12:01 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:12:01 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:12:01 --> Utf8 Class Initialized
INFO - 2018-10-22 13:12:01 --> URI Class Initialized
INFO - 2018-10-22 13:12:01 --> Router Class Initialized
INFO - 2018-10-22 13:12:01 --> Output Class Initialized
INFO - 2018-10-22 13:12:01 --> Security Class Initialized
DEBUG - 2018-10-22 13:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:12:01 --> CSRF cookie sent
INFO - 2018-10-22 13:12:01 --> Input Class Initialized
INFO - 2018-10-22 13:12:01 --> Language Class Initialized
INFO - 2018-10-22 13:12:01 --> Loader Class Initialized
INFO - 2018-10-22 13:12:01 --> Helper loaded: url_helper
INFO - 2018-10-22 13:12:01 --> Helper loaded: form_helper
INFO - 2018-10-22 13:12:01 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:12:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:12:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:12:01 --> User Agent Class Initialized
INFO - 2018-10-22 13:12:01 --> Controller Class Initialized
INFO - 2018-10-22 13:12:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:12:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:12:01 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:12:01 --> Pixel_Model class loaded
INFO - 2018-10-22 13:12:01 --> Database Driver Class Initialized
INFO - 2018-10-22 13:12:01 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:12:01 --> Database Driver Class Initialized
INFO - 2018-10-22 13:12:01 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:12:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:12:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:12:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:12:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:12:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:12:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:12:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/income.php
INFO - 2018-10-22 13:12:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:12:01 --> Final output sent to browser
DEBUG - 2018-10-22 13:12:01 --> Total execution time: 0.3785
INFO - 2018-10-22 13:12:04 --> Config Class Initialized
INFO - 2018-10-22 13:12:04 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:12:04 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:12:05 --> Utf8 Class Initialized
INFO - 2018-10-22 13:12:05 --> URI Class Initialized
INFO - 2018-10-22 13:12:05 --> Router Class Initialized
INFO - 2018-10-22 13:12:05 --> Output Class Initialized
INFO - 2018-10-22 13:12:05 --> Security Class Initialized
DEBUG - 2018-10-22 13:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:12:05 --> CSRF cookie sent
INFO - 2018-10-22 13:12:05 --> CSRF token verified
INFO - 2018-10-22 13:12:05 --> Input Class Initialized
INFO - 2018-10-22 13:12:05 --> Language Class Initialized
INFO - 2018-10-22 13:12:05 --> Loader Class Initialized
INFO - 2018-10-22 13:12:05 --> Helper loaded: url_helper
INFO - 2018-10-22 13:12:05 --> Helper loaded: form_helper
INFO - 2018-10-22 13:12:05 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:12:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:12:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:12:05 --> User Agent Class Initialized
INFO - 2018-10-22 13:12:05 --> Controller Class Initialized
INFO - 2018-10-22 13:12:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:12:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:12:05 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:12:05 --> Pixel_Model class loaded
INFO - 2018-10-22 13:12:05 --> Database Driver Class Initialized
INFO - 2018-10-22 13:12:05 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:12:05 --> Form Validation Class Initialized
INFO - 2018-10-22 13:12:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:12:05 --> Database Driver Class Initialized
INFO - 2018-10-22 13:12:05 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:12:11 --> Config Class Initialized
INFO - 2018-10-22 13:12:11 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:12:11 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:12:11 --> Utf8 Class Initialized
INFO - 2018-10-22 13:12:11 --> URI Class Initialized
INFO - 2018-10-22 13:12:11 --> Router Class Initialized
INFO - 2018-10-22 13:12:11 --> Output Class Initialized
INFO - 2018-10-22 13:12:11 --> Security Class Initialized
DEBUG - 2018-10-22 13:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:12:11 --> CSRF cookie sent
INFO - 2018-10-22 13:12:11 --> Input Class Initialized
INFO - 2018-10-22 13:12:11 --> Language Class Initialized
INFO - 2018-10-22 13:12:12 --> Loader Class Initialized
INFO - 2018-10-22 13:12:12 --> Helper loaded: url_helper
INFO - 2018-10-22 13:12:12 --> Helper loaded: form_helper
INFO - 2018-10-22 13:12:12 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:12:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:12:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:12:12 --> User Agent Class Initialized
INFO - 2018-10-22 13:12:12 --> Controller Class Initialized
INFO - 2018-10-22 13:12:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:12:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:12:12 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:12:12 --> Pixel_Model class loaded
INFO - 2018-10-22 13:12:12 --> Database Driver Class Initialized
INFO - 2018-10-22 13:12:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:12:12 --> Database Driver Class Initialized
INFO - 2018-10-22 13:12:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:12:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:12:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:12:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:12:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:12:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:12:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:12:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/income.php
INFO - 2018-10-22 13:12:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:12:12 --> Final output sent to browser
DEBUG - 2018-10-22 13:12:12 --> Total execution time: 0.4144
INFO - 2018-10-22 13:12:12 --> Config Class Initialized
INFO - 2018-10-22 13:12:13 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:12:13 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:12:13 --> Utf8 Class Initialized
INFO - 2018-10-22 13:12:13 --> URI Class Initialized
INFO - 2018-10-22 13:12:13 --> Router Class Initialized
INFO - 2018-10-22 13:12:13 --> Output Class Initialized
INFO - 2018-10-22 13:12:13 --> Security Class Initialized
DEBUG - 2018-10-22 13:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:12:13 --> CSRF cookie sent
INFO - 2018-10-22 13:12:13 --> Input Class Initialized
INFO - 2018-10-22 13:12:13 --> Language Class Initialized
INFO - 2018-10-22 13:12:13 --> Loader Class Initialized
INFO - 2018-10-22 13:12:13 --> Helper loaded: url_helper
INFO - 2018-10-22 13:12:13 --> Helper loaded: form_helper
INFO - 2018-10-22 13:12:13 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:12:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:12:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:12:13 --> User Agent Class Initialized
INFO - 2018-10-22 13:12:13 --> Controller Class Initialized
INFO - 2018-10-22 13:12:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:12:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:12:13 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:12:13 --> Pixel_Model class loaded
INFO - 2018-10-22 13:12:13 --> Database Driver Class Initialized
INFO - 2018-10-22 13:12:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:12:13 --> Database Driver Class Initialized
INFO - 2018-10-22 13:12:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:12:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:12:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:12:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner.php
INFO - 2018-10-22 13:12:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:12:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:12:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:12:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:12:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/relation_ship_status.php
INFO - 2018-10-22 13:12:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:12:13 --> Final output sent to browser
DEBUG - 2018-10-22 13:12:13 --> Total execution time: 0.4180
INFO - 2018-10-22 13:14:00 --> Config Class Initialized
INFO - 2018-10-22 13:14:00 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:14:00 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:14:00 --> Utf8 Class Initialized
INFO - 2018-10-22 13:14:00 --> URI Class Initialized
INFO - 2018-10-22 13:14:00 --> Router Class Initialized
INFO - 2018-10-22 13:14:00 --> Output Class Initialized
INFO - 2018-10-22 13:14:00 --> Security Class Initialized
DEBUG - 2018-10-22 13:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:14:00 --> CSRF cookie sent
INFO - 2018-10-22 13:14:00 --> Input Class Initialized
INFO - 2018-10-22 13:14:00 --> Language Class Initialized
INFO - 2018-10-22 13:14:00 --> Loader Class Initialized
INFO - 2018-10-22 13:14:00 --> Helper loaded: url_helper
INFO - 2018-10-22 13:14:00 --> Helper loaded: form_helper
INFO - 2018-10-22 13:14:00 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:14:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:14:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:14:00 --> User Agent Class Initialized
INFO - 2018-10-22 13:14:00 --> Controller Class Initialized
INFO - 2018-10-22 13:14:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:14:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:14:00 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:14:00 --> Pixel_Model class loaded
INFO - 2018-10-22 13:14:00 --> Database Driver Class Initialized
INFO - 2018-10-22 13:14:00 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:14:00 --> Database Driver Class Initialized
INFO - 2018-10-22 13:14:00 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:14:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:14:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:14:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner.php
INFO - 2018-10-22 13:14:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:14:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:14:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:14:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:14:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/relation_ship_status.php
INFO - 2018-10-22 13:14:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:14:00 --> Final output sent to browser
DEBUG - 2018-10-22 13:14:01 --> Total execution time: 0.4247
INFO - 2018-10-22 13:14:04 --> Config Class Initialized
INFO - 2018-10-22 13:14:04 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:14:04 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:14:04 --> Utf8 Class Initialized
INFO - 2018-10-22 13:14:04 --> URI Class Initialized
INFO - 2018-10-22 13:14:04 --> Router Class Initialized
INFO - 2018-10-22 13:14:04 --> Output Class Initialized
INFO - 2018-10-22 13:14:04 --> Security Class Initialized
DEBUG - 2018-10-22 13:14:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:14:04 --> CSRF cookie sent
INFO - 2018-10-22 13:14:04 --> CSRF token verified
INFO - 2018-10-22 13:14:04 --> Input Class Initialized
INFO - 2018-10-22 13:14:04 --> Language Class Initialized
INFO - 2018-10-22 13:14:04 --> Loader Class Initialized
INFO - 2018-10-22 13:14:04 --> Helper loaded: url_helper
INFO - 2018-10-22 13:14:04 --> Helper loaded: form_helper
INFO - 2018-10-22 13:14:04 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:14:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:14:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:14:05 --> User Agent Class Initialized
INFO - 2018-10-22 13:14:05 --> Controller Class Initialized
INFO - 2018-10-22 13:14:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:14:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:14:05 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:14:05 --> Pixel_Model class loaded
INFO - 2018-10-22 13:14:05 --> Database Driver Class Initialized
INFO - 2018-10-22 13:14:05 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:14:05 --> Form Validation Class Initialized
INFO - 2018-10-22 13:14:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:14:05 --> Database Driver Class Initialized
INFO - 2018-10-22 13:14:05 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:14:05 --> Config Class Initialized
INFO - 2018-10-22 13:14:05 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:14:05 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:14:05 --> Utf8 Class Initialized
INFO - 2018-10-22 13:14:05 --> URI Class Initialized
INFO - 2018-10-22 13:14:05 --> Router Class Initialized
INFO - 2018-10-22 13:14:05 --> Output Class Initialized
INFO - 2018-10-22 13:14:05 --> Security Class Initialized
DEBUG - 2018-10-22 13:14:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:14:05 --> CSRF cookie sent
INFO - 2018-10-22 13:14:05 --> Input Class Initialized
INFO - 2018-10-22 13:14:05 --> Language Class Initialized
INFO - 2018-10-22 13:14:05 --> Loader Class Initialized
INFO - 2018-10-22 13:14:05 --> Helper loaded: url_helper
INFO - 2018-10-22 13:14:05 --> Helper loaded: form_helper
INFO - 2018-10-22 13:14:05 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:14:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:14:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:14:05 --> User Agent Class Initialized
INFO - 2018-10-22 13:14:05 --> Controller Class Initialized
INFO - 2018-10-22 13:14:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:14:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:14:05 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:14:05 --> Pixel_Model class loaded
INFO - 2018-10-22 13:14:05 --> Database Driver Class Initialized
INFO - 2018-10-22 13:14:05 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:14:05 --> Database Driver Class Initialized
INFO - 2018-10-22 13:14:05 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:14:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:14:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:14:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:14:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:14:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:14:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:14:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/income.php
INFO - 2018-10-22 13:14:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:14:05 --> Final output sent to browser
DEBUG - 2018-10-22 13:14:05 --> Total execution time: 0.4025
INFO - 2018-10-22 13:14:14 --> Config Class Initialized
INFO - 2018-10-22 13:14:14 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:14:14 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:14:14 --> Utf8 Class Initialized
INFO - 2018-10-22 13:14:14 --> URI Class Initialized
INFO - 2018-10-22 13:14:14 --> Router Class Initialized
INFO - 2018-10-22 13:14:14 --> Output Class Initialized
INFO - 2018-10-22 13:14:14 --> Security Class Initialized
DEBUG - 2018-10-22 13:14:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:14:14 --> CSRF cookie sent
INFO - 2018-10-22 13:14:14 --> Input Class Initialized
INFO - 2018-10-22 13:14:14 --> Language Class Initialized
INFO - 2018-10-22 13:14:14 --> Loader Class Initialized
INFO - 2018-10-22 13:14:14 --> Helper loaded: url_helper
INFO - 2018-10-22 13:14:14 --> Helper loaded: form_helper
INFO - 2018-10-22 13:14:14 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:14:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:14:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:14:14 --> User Agent Class Initialized
INFO - 2018-10-22 13:14:14 --> Controller Class Initialized
INFO - 2018-10-22 13:14:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:14:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:14:14 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:14:14 --> Pixel_Model class loaded
INFO - 2018-10-22 13:14:14 --> Database Driver Class Initialized
INFO - 2018-10-22 13:14:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:14:14 --> Database Driver Class Initialized
INFO - 2018-10-22 13:14:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:14:43 --> Config Class Initialized
INFO - 2018-10-22 13:14:43 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:14:43 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:14:43 --> Utf8 Class Initialized
INFO - 2018-10-22 13:14:43 --> URI Class Initialized
INFO - 2018-10-22 13:14:43 --> Router Class Initialized
INFO - 2018-10-22 13:14:43 --> Output Class Initialized
INFO - 2018-10-22 13:14:43 --> Security Class Initialized
DEBUG - 2018-10-22 13:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:14:43 --> CSRF cookie sent
INFO - 2018-10-22 13:14:43 --> Input Class Initialized
INFO - 2018-10-22 13:14:43 --> Language Class Initialized
INFO - 2018-10-22 13:14:43 --> Loader Class Initialized
INFO - 2018-10-22 13:14:43 --> Helper loaded: url_helper
INFO - 2018-10-22 13:14:43 --> Helper loaded: form_helper
INFO - 2018-10-22 13:14:43 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:14:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:14:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:14:44 --> User Agent Class Initialized
INFO - 2018-10-22 13:14:44 --> Controller Class Initialized
INFO - 2018-10-22 13:14:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:14:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:14:44 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:14:44 --> Pixel_Model class loaded
INFO - 2018-10-22 13:14:44 --> Database Driver Class Initialized
INFO - 2018-10-22 13:14:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:14:44 --> Database Driver Class Initialized
INFO - 2018-10-22 13:14:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:14:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:14:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:14:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner.php
INFO - 2018-10-22 13:14:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:14:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:14:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:14:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:14:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/relation_ship_status.php
INFO - 2018-10-22 13:14:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:14:44 --> Final output sent to browser
DEBUG - 2018-10-22 13:14:44 --> Total execution time: 0.4243
INFO - 2018-10-22 13:15:27 --> Config Class Initialized
INFO - 2018-10-22 13:15:27 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:15:27 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:15:27 --> Utf8 Class Initialized
INFO - 2018-10-22 13:15:27 --> URI Class Initialized
INFO - 2018-10-22 13:15:27 --> Router Class Initialized
INFO - 2018-10-22 13:15:27 --> Output Class Initialized
INFO - 2018-10-22 13:15:27 --> Security Class Initialized
DEBUG - 2018-10-22 13:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:15:27 --> CSRF cookie sent
INFO - 2018-10-22 13:15:27 --> Input Class Initialized
INFO - 2018-10-22 13:15:27 --> Language Class Initialized
INFO - 2018-10-22 13:15:27 --> Loader Class Initialized
INFO - 2018-10-22 13:15:27 --> Helper loaded: url_helper
INFO - 2018-10-22 13:15:27 --> Helper loaded: form_helper
INFO - 2018-10-22 13:15:27 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:15:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:15:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:15:27 --> User Agent Class Initialized
INFO - 2018-10-22 13:15:27 --> Controller Class Initialized
INFO - 2018-10-22 13:15:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:15:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:15:27 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:15:27 --> Pixel_Model class loaded
INFO - 2018-10-22 13:15:27 --> Database Driver Class Initialized
INFO - 2018-10-22 13:15:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:15:27 --> Database Driver Class Initialized
INFO - 2018-10-22 13:15:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:15:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:15:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:15:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner.php
INFO - 2018-10-22 13:15:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:15:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:15:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:15:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:15:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/relation_ship_status.php
INFO - 2018-10-22 13:15:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:15:27 --> Final output sent to browser
DEBUG - 2018-10-22 13:15:27 --> Total execution time: 0.3996
INFO - 2018-10-22 13:15:30 --> Config Class Initialized
INFO - 2018-10-22 13:15:30 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:15:30 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:15:30 --> Utf8 Class Initialized
INFO - 2018-10-22 13:15:31 --> URI Class Initialized
INFO - 2018-10-22 13:15:31 --> Router Class Initialized
INFO - 2018-10-22 13:15:31 --> Output Class Initialized
INFO - 2018-10-22 13:15:31 --> Security Class Initialized
DEBUG - 2018-10-22 13:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:15:31 --> CSRF cookie sent
INFO - 2018-10-22 13:15:31 --> CSRF token verified
INFO - 2018-10-22 13:15:31 --> Input Class Initialized
INFO - 2018-10-22 13:15:31 --> Language Class Initialized
INFO - 2018-10-22 13:15:31 --> Loader Class Initialized
INFO - 2018-10-22 13:15:31 --> Helper loaded: url_helper
INFO - 2018-10-22 13:15:31 --> Helper loaded: form_helper
INFO - 2018-10-22 13:15:31 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:15:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:15:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:15:31 --> User Agent Class Initialized
INFO - 2018-10-22 13:15:31 --> Controller Class Initialized
INFO - 2018-10-22 13:15:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:15:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:15:31 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:15:31 --> Pixel_Model class loaded
INFO - 2018-10-22 13:15:31 --> Database Driver Class Initialized
INFO - 2018-10-22 13:15:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:15:31 --> Form Validation Class Initialized
INFO - 2018-10-22 13:15:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:15:36 --> Config Class Initialized
INFO - 2018-10-22 13:15:36 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:15:36 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:15:36 --> Utf8 Class Initialized
INFO - 2018-10-22 13:15:36 --> URI Class Initialized
INFO - 2018-10-22 13:15:36 --> Router Class Initialized
INFO - 2018-10-22 13:15:36 --> Output Class Initialized
INFO - 2018-10-22 13:15:36 --> Security Class Initialized
DEBUG - 2018-10-22 13:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:15:36 --> CSRF cookie sent
INFO - 2018-10-22 13:15:36 --> Input Class Initialized
INFO - 2018-10-22 13:15:36 --> Language Class Initialized
INFO - 2018-10-22 13:15:36 --> Loader Class Initialized
INFO - 2018-10-22 13:15:37 --> Helper loaded: url_helper
INFO - 2018-10-22 13:15:37 --> Helper loaded: form_helper
INFO - 2018-10-22 13:15:37 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:15:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:15:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:15:37 --> User Agent Class Initialized
INFO - 2018-10-22 13:15:37 --> Controller Class Initialized
INFO - 2018-10-22 13:15:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:15:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:15:37 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:15:37 --> Pixel_Model class loaded
INFO - 2018-10-22 13:15:37 --> Database Driver Class Initialized
INFO - 2018-10-22 13:15:37 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:15:37 --> Database Driver Class Initialized
INFO - 2018-10-22 13:15:37 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:15:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:15:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:15:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner.php
INFO - 2018-10-22 13:15:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:15:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:15:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:15:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:15:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/relation_ship_status.php
INFO - 2018-10-22 13:15:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:15:37 --> Final output sent to browser
DEBUG - 2018-10-22 13:15:37 --> Total execution time: 0.4351
INFO - 2018-10-22 13:15:39 --> Config Class Initialized
INFO - 2018-10-22 13:15:39 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:15:39 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:15:39 --> Utf8 Class Initialized
INFO - 2018-10-22 13:15:39 --> URI Class Initialized
INFO - 2018-10-22 13:15:39 --> Router Class Initialized
INFO - 2018-10-22 13:15:39 --> Output Class Initialized
INFO - 2018-10-22 13:15:39 --> Security Class Initialized
DEBUG - 2018-10-22 13:15:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:15:39 --> CSRF cookie sent
INFO - 2018-10-22 13:15:39 --> Input Class Initialized
INFO - 2018-10-22 13:15:39 --> Language Class Initialized
INFO - 2018-10-22 13:15:39 --> Loader Class Initialized
INFO - 2018-10-22 13:15:39 --> Helper loaded: url_helper
INFO - 2018-10-22 13:15:39 --> Helper loaded: form_helper
INFO - 2018-10-22 13:15:39 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:15:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:15:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:15:39 --> User Agent Class Initialized
INFO - 2018-10-22 13:15:39 --> Controller Class Initialized
INFO - 2018-10-22 13:15:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:15:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:15:39 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:15:39 --> Pixel_Model class loaded
INFO - 2018-10-22 13:15:39 --> Database Driver Class Initialized
INFO - 2018-10-22 13:15:39 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:15:39 --> Database Driver Class Initialized
INFO - 2018-10-22 13:15:39 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:15:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:15:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:15:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner.php
INFO - 2018-10-22 13:15:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:15:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:15:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:15:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:15:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/relation_ship_status.php
INFO - 2018-10-22 13:15:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:15:39 --> Final output sent to browser
DEBUG - 2018-10-22 13:15:39 --> Total execution time: 0.4201
INFO - 2018-10-22 13:15:42 --> Config Class Initialized
INFO - 2018-10-22 13:15:42 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:15:42 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:15:42 --> Utf8 Class Initialized
INFO - 2018-10-22 13:15:42 --> URI Class Initialized
INFO - 2018-10-22 13:15:42 --> Router Class Initialized
INFO - 2018-10-22 13:15:42 --> Output Class Initialized
INFO - 2018-10-22 13:15:42 --> Security Class Initialized
DEBUG - 2018-10-22 13:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:15:42 --> CSRF cookie sent
INFO - 2018-10-22 13:15:42 --> CSRF token verified
INFO - 2018-10-22 13:15:42 --> Input Class Initialized
INFO - 2018-10-22 13:15:42 --> Language Class Initialized
INFO - 2018-10-22 13:15:42 --> Loader Class Initialized
INFO - 2018-10-22 13:15:42 --> Helper loaded: url_helper
INFO - 2018-10-22 13:15:42 --> Helper loaded: form_helper
INFO - 2018-10-22 13:15:42 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:15:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:15:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:15:42 --> User Agent Class Initialized
INFO - 2018-10-22 13:15:42 --> Controller Class Initialized
INFO - 2018-10-22 13:15:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:15:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:15:42 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:15:42 --> Pixel_Model class loaded
INFO - 2018-10-22 13:15:42 --> Database Driver Class Initialized
INFO - 2018-10-22 13:15:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:15:42 --> Form Validation Class Initialized
INFO - 2018-10-22 13:15:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:15:44 --> Config Class Initialized
INFO - 2018-10-22 13:15:44 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:15:44 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:15:44 --> Utf8 Class Initialized
INFO - 2018-10-22 13:15:44 --> URI Class Initialized
INFO - 2018-10-22 13:15:44 --> Router Class Initialized
INFO - 2018-10-22 13:15:45 --> Output Class Initialized
INFO - 2018-10-22 13:15:45 --> Security Class Initialized
DEBUG - 2018-10-22 13:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:15:45 --> CSRF cookie sent
INFO - 2018-10-22 13:15:45 --> Input Class Initialized
INFO - 2018-10-22 13:15:45 --> Language Class Initialized
INFO - 2018-10-22 13:15:45 --> Loader Class Initialized
INFO - 2018-10-22 13:15:45 --> Helper loaded: url_helper
INFO - 2018-10-22 13:15:45 --> Helper loaded: form_helper
INFO - 2018-10-22 13:15:45 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:15:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:15:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:15:45 --> User Agent Class Initialized
INFO - 2018-10-22 13:15:45 --> Controller Class Initialized
INFO - 2018-10-22 13:15:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:15:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:15:45 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:15:45 --> Pixel_Model class loaded
INFO - 2018-10-22 13:15:45 --> Database Driver Class Initialized
INFO - 2018-10-22 13:15:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:15:45 --> Database Driver Class Initialized
INFO - 2018-10-22 13:15:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:15:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:15:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:15:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner.php
INFO - 2018-10-22 13:15:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:15:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:15:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:15:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:15:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/relation_ship_status.php
INFO - 2018-10-22 13:15:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:15:45 --> Final output sent to browser
DEBUG - 2018-10-22 13:15:45 --> Total execution time: 0.4627
INFO - 2018-10-22 13:15:46 --> Config Class Initialized
INFO - 2018-10-22 13:15:46 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:15:46 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:15:46 --> Utf8 Class Initialized
INFO - 2018-10-22 13:15:46 --> URI Class Initialized
INFO - 2018-10-22 13:15:46 --> Router Class Initialized
INFO - 2018-10-22 13:15:46 --> Output Class Initialized
INFO - 2018-10-22 13:15:46 --> Security Class Initialized
DEBUG - 2018-10-22 13:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:15:46 --> CSRF cookie sent
INFO - 2018-10-22 13:15:46 --> Input Class Initialized
INFO - 2018-10-22 13:15:46 --> Language Class Initialized
INFO - 2018-10-22 13:15:46 --> Loader Class Initialized
INFO - 2018-10-22 13:15:46 --> Helper loaded: url_helper
INFO - 2018-10-22 13:15:46 --> Helper loaded: form_helper
INFO - 2018-10-22 13:15:46 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:15:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:15:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:15:46 --> User Agent Class Initialized
INFO - 2018-10-22 13:15:46 --> Controller Class Initialized
INFO - 2018-10-22 13:15:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:15:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:15:46 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:15:46 --> Pixel_Model class loaded
INFO - 2018-10-22 13:15:46 --> Database Driver Class Initialized
INFO - 2018-10-22 13:15:46 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:15:46 --> Database Driver Class Initialized
INFO - 2018-10-22 13:15:46 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:15:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:15:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:15:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner.php
INFO - 2018-10-22 13:15:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:15:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:15:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:15:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:15:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/relation_ship_status.php
INFO - 2018-10-22 13:15:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:15:46 --> Final output sent to browser
DEBUG - 2018-10-22 13:15:46 --> Total execution time: 0.4454
INFO - 2018-10-22 13:15:49 --> Config Class Initialized
INFO - 2018-10-22 13:15:49 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:15:49 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:15:49 --> Utf8 Class Initialized
INFO - 2018-10-22 13:15:49 --> URI Class Initialized
INFO - 2018-10-22 13:15:49 --> Router Class Initialized
INFO - 2018-10-22 13:15:49 --> Output Class Initialized
INFO - 2018-10-22 13:15:49 --> Security Class Initialized
DEBUG - 2018-10-22 13:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:15:49 --> CSRF cookie sent
INFO - 2018-10-22 13:15:49 --> CSRF token verified
INFO - 2018-10-22 13:15:49 --> Input Class Initialized
INFO - 2018-10-22 13:15:49 --> Language Class Initialized
INFO - 2018-10-22 13:15:49 --> Loader Class Initialized
INFO - 2018-10-22 13:15:49 --> Helper loaded: url_helper
INFO - 2018-10-22 13:15:49 --> Helper loaded: form_helper
INFO - 2018-10-22 13:15:49 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:15:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:15:49 --> User Agent Class Initialized
INFO - 2018-10-22 13:15:49 --> Controller Class Initialized
INFO - 2018-10-22 13:15:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:15:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:15:49 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:15:49 --> Pixel_Model class loaded
INFO - 2018-10-22 13:15:49 --> Database Driver Class Initialized
INFO - 2018-10-22 13:15:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:15:50 --> Form Validation Class Initialized
INFO - 2018-10-22 13:15:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:16:29 --> Config Class Initialized
INFO - 2018-10-22 13:16:29 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:16:29 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:16:29 --> Utf8 Class Initialized
INFO - 2018-10-22 13:16:29 --> URI Class Initialized
INFO - 2018-10-22 13:16:29 --> Router Class Initialized
INFO - 2018-10-22 13:16:29 --> Output Class Initialized
INFO - 2018-10-22 13:16:29 --> Security Class Initialized
DEBUG - 2018-10-22 13:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:16:29 --> CSRF cookie sent
INFO - 2018-10-22 13:16:29 --> CSRF token verified
INFO - 2018-10-22 13:16:29 --> Input Class Initialized
INFO - 2018-10-22 13:16:29 --> Language Class Initialized
INFO - 2018-10-22 13:16:29 --> Loader Class Initialized
INFO - 2018-10-22 13:16:29 --> Helper loaded: url_helper
INFO - 2018-10-22 13:16:29 --> Helper loaded: form_helper
INFO - 2018-10-22 13:16:29 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:16:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:16:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:16:30 --> User Agent Class Initialized
INFO - 2018-10-22 13:16:30 --> Controller Class Initialized
INFO - 2018-10-22 13:16:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:16:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:16:30 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:16:30 --> Pixel_Model class loaded
INFO - 2018-10-22 13:16:30 --> Database Driver Class Initialized
INFO - 2018-10-22 13:16:30 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:16:30 --> Form Validation Class Initialized
INFO - 2018-10-22 13:16:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:16:30 --> Database Driver Class Initialized
INFO - 2018-10-22 13:16:30 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:17:20 --> Config Class Initialized
INFO - 2018-10-22 13:17:20 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:17:20 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:17:20 --> Utf8 Class Initialized
INFO - 2018-10-22 13:17:20 --> URI Class Initialized
INFO - 2018-10-22 13:17:20 --> Router Class Initialized
INFO - 2018-10-22 13:17:20 --> Output Class Initialized
INFO - 2018-10-22 13:17:20 --> Security Class Initialized
DEBUG - 2018-10-22 13:17:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:17:20 --> CSRF cookie sent
INFO - 2018-10-22 13:17:20 --> CSRF token verified
INFO - 2018-10-22 13:17:20 --> Input Class Initialized
INFO - 2018-10-22 13:17:20 --> Language Class Initialized
INFO - 2018-10-22 13:17:20 --> Loader Class Initialized
INFO - 2018-10-22 13:17:20 --> Helper loaded: url_helper
INFO - 2018-10-22 13:17:20 --> Helper loaded: form_helper
INFO - 2018-10-22 13:17:20 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:17:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:17:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:17:20 --> User Agent Class Initialized
INFO - 2018-10-22 13:17:20 --> Controller Class Initialized
INFO - 2018-10-22 13:17:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:17:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:17:21 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:17:21 --> Pixel_Model class loaded
INFO - 2018-10-22 13:17:21 --> Database Driver Class Initialized
INFO - 2018-10-22 13:17:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:17:21 --> Form Validation Class Initialized
INFO - 2018-10-22 13:17:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:17:21 --> Database Driver Class Initialized
INFO - 2018-10-22 13:17:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:18:52 --> Config Class Initialized
INFO - 2018-10-22 13:18:52 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:18:52 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:18:52 --> Utf8 Class Initialized
INFO - 2018-10-22 13:18:52 --> URI Class Initialized
INFO - 2018-10-22 13:18:52 --> Router Class Initialized
INFO - 2018-10-22 13:18:52 --> Output Class Initialized
INFO - 2018-10-22 13:18:52 --> Security Class Initialized
DEBUG - 2018-10-22 13:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:18:53 --> CSRF cookie sent
INFO - 2018-10-22 13:18:53 --> CSRF token verified
INFO - 2018-10-22 13:18:53 --> Input Class Initialized
INFO - 2018-10-22 13:18:53 --> Language Class Initialized
INFO - 2018-10-22 13:18:53 --> Loader Class Initialized
INFO - 2018-10-22 13:18:53 --> Helper loaded: url_helper
INFO - 2018-10-22 13:18:53 --> Helper loaded: form_helper
INFO - 2018-10-22 13:18:53 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:18:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:18:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:18:53 --> User Agent Class Initialized
INFO - 2018-10-22 13:18:53 --> Controller Class Initialized
INFO - 2018-10-22 13:18:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:18:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:18:53 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:18:53 --> Pixel_Model class loaded
INFO - 2018-10-22 13:18:53 --> Database Driver Class Initialized
INFO - 2018-10-22 13:18:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:18:53 --> Form Validation Class Initialized
INFO - 2018-10-22 13:18:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:18:53 --> Database Driver Class Initialized
INFO - 2018-10-22 13:18:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:23:10 --> Config Class Initialized
INFO - 2018-10-22 13:23:10 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:23:10 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:23:10 --> Utf8 Class Initialized
INFO - 2018-10-22 13:23:10 --> URI Class Initialized
INFO - 2018-10-22 13:23:10 --> Router Class Initialized
INFO - 2018-10-22 13:23:10 --> Output Class Initialized
INFO - 2018-10-22 13:23:10 --> Security Class Initialized
DEBUG - 2018-10-22 13:23:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:23:10 --> CSRF cookie sent
INFO - 2018-10-22 13:23:10 --> CSRF token verified
INFO - 2018-10-22 13:23:10 --> Input Class Initialized
INFO - 2018-10-22 13:23:10 --> Language Class Initialized
INFO - 2018-10-22 13:23:10 --> Loader Class Initialized
INFO - 2018-10-22 13:23:10 --> Helper loaded: url_helper
INFO - 2018-10-22 13:23:10 --> Helper loaded: form_helper
INFO - 2018-10-22 13:23:10 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:23:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:23:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:23:10 --> User Agent Class Initialized
INFO - 2018-10-22 13:23:10 --> Controller Class Initialized
INFO - 2018-10-22 13:23:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:23:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:23:10 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:23:11 --> Pixel_Model class loaded
INFO - 2018-10-22 13:23:11 --> Database Driver Class Initialized
INFO - 2018-10-22 13:23:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:23:11 --> Form Validation Class Initialized
INFO - 2018-10-22 13:23:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:23:11 --> Database Driver Class Initialized
INFO - 2018-10-22 13:23:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:23:19 --> Config Class Initialized
INFO - 2018-10-22 13:23:19 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:23:19 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:23:19 --> Utf8 Class Initialized
INFO - 2018-10-22 13:23:19 --> URI Class Initialized
INFO - 2018-10-22 13:23:19 --> Router Class Initialized
INFO - 2018-10-22 13:23:19 --> Output Class Initialized
INFO - 2018-10-22 13:23:19 --> Security Class Initialized
DEBUG - 2018-10-22 13:23:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:23:19 --> CSRF cookie sent
INFO - 2018-10-22 13:23:19 --> CSRF token verified
INFO - 2018-10-22 13:23:19 --> Input Class Initialized
INFO - 2018-10-22 13:23:19 --> Language Class Initialized
INFO - 2018-10-22 13:23:19 --> Loader Class Initialized
INFO - 2018-10-22 13:23:19 --> Helper loaded: url_helper
INFO - 2018-10-22 13:23:19 --> Helper loaded: form_helper
INFO - 2018-10-22 13:23:19 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:23:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:23:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:23:19 --> User Agent Class Initialized
INFO - 2018-10-22 13:23:19 --> Controller Class Initialized
INFO - 2018-10-22 13:23:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:23:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:23:19 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:23:19 --> Pixel_Model class loaded
INFO - 2018-10-22 13:23:19 --> Database Driver Class Initialized
INFO - 2018-10-22 13:23:19 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:23:19 --> Form Validation Class Initialized
INFO - 2018-10-22 13:23:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:23:19 --> Database Driver Class Initialized
INFO - 2018-10-22 13:23:19 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:24:32 --> Config Class Initialized
INFO - 2018-10-22 13:24:32 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:24:32 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:24:32 --> Utf8 Class Initialized
INFO - 2018-10-22 13:24:32 --> URI Class Initialized
INFO - 2018-10-22 13:24:32 --> Router Class Initialized
INFO - 2018-10-22 13:24:32 --> Output Class Initialized
INFO - 2018-10-22 13:24:32 --> Security Class Initialized
DEBUG - 2018-10-22 13:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:24:32 --> CSRF cookie sent
INFO - 2018-10-22 13:24:32 --> CSRF token verified
INFO - 2018-10-22 13:24:32 --> Input Class Initialized
INFO - 2018-10-22 13:24:32 --> Language Class Initialized
INFO - 2018-10-22 13:24:32 --> Loader Class Initialized
INFO - 2018-10-22 13:24:32 --> Helper loaded: url_helper
INFO - 2018-10-22 13:24:32 --> Helper loaded: form_helper
INFO - 2018-10-22 13:24:32 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:24:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:24:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:24:32 --> User Agent Class Initialized
INFO - 2018-10-22 13:24:32 --> Controller Class Initialized
INFO - 2018-10-22 13:24:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:24:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:24:32 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:24:32 --> Pixel_Model class loaded
INFO - 2018-10-22 13:24:32 --> Database Driver Class Initialized
INFO - 2018-10-22 13:24:33 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:24:33 --> Form Validation Class Initialized
INFO - 2018-10-22 13:24:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:24:33 --> Database Driver Class Initialized
INFO - 2018-10-22 13:24:33 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:25:05 --> Config Class Initialized
INFO - 2018-10-22 13:25:05 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:25:05 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:25:05 --> Utf8 Class Initialized
INFO - 2018-10-22 13:25:05 --> URI Class Initialized
INFO - 2018-10-22 13:25:05 --> Router Class Initialized
INFO - 2018-10-22 13:25:05 --> Output Class Initialized
INFO - 2018-10-22 13:25:05 --> Security Class Initialized
DEBUG - 2018-10-22 13:25:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:25:05 --> CSRF cookie sent
INFO - 2018-10-22 13:25:05 --> CSRF token verified
INFO - 2018-10-22 13:25:05 --> Input Class Initialized
INFO - 2018-10-22 13:25:05 --> Language Class Initialized
INFO - 2018-10-22 13:25:05 --> Loader Class Initialized
INFO - 2018-10-22 13:25:05 --> Helper loaded: url_helper
INFO - 2018-10-22 13:25:05 --> Helper loaded: form_helper
INFO - 2018-10-22 13:25:05 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:25:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:25:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:25:06 --> User Agent Class Initialized
INFO - 2018-10-22 13:25:06 --> Controller Class Initialized
INFO - 2018-10-22 13:25:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:25:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:25:06 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:25:06 --> Pixel_Model class loaded
INFO - 2018-10-22 13:25:06 --> Database Driver Class Initialized
INFO - 2018-10-22 13:25:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:25:06 --> Form Validation Class Initialized
INFO - 2018-10-22 13:25:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:25:06 --> Database Driver Class Initialized
INFO - 2018-10-22 13:25:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:28:48 --> Config Class Initialized
INFO - 2018-10-22 13:28:48 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:28:48 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:28:48 --> Utf8 Class Initialized
INFO - 2018-10-22 13:28:48 --> URI Class Initialized
INFO - 2018-10-22 13:28:48 --> Router Class Initialized
INFO - 2018-10-22 13:28:48 --> Output Class Initialized
INFO - 2018-10-22 13:28:48 --> Security Class Initialized
DEBUG - 2018-10-22 13:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:28:48 --> CSRF cookie sent
INFO - 2018-10-22 13:28:48 --> CSRF token verified
INFO - 2018-10-22 13:28:48 --> Input Class Initialized
INFO - 2018-10-22 13:28:48 --> Language Class Initialized
INFO - 2018-10-22 13:28:48 --> Loader Class Initialized
INFO - 2018-10-22 13:28:48 --> Helper loaded: url_helper
INFO - 2018-10-22 13:28:48 --> Helper loaded: form_helper
INFO - 2018-10-22 13:28:48 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:28:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:28:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:28:48 --> User Agent Class Initialized
INFO - 2018-10-22 13:28:48 --> Controller Class Initialized
INFO - 2018-10-22 13:28:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:28:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:28:48 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:28:48 --> Pixel_Model class loaded
INFO - 2018-10-22 13:28:48 --> Database Driver Class Initialized
INFO - 2018-10-22 13:28:48 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:28:48 --> Form Validation Class Initialized
INFO - 2018-10-22 13:28:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:28:48 --> Database Driver Class Initialized
INFO - 2018-10-22 13:28:48 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:31:51 --> Config Class Initialized
INFO - 2018-10-22 13:31:51 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:31:51 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:31:51 --> Utf8 Class Initialized
INFO - 2018-10-22 13:31:51 --> URI Class Initialized
INFO - 2018-10-22 13:31:51 --> Router Class Initialized
INFO - 2018-10-22 13:31:51 --> Output Class Initialized
INFO - 2018-10-22 13:31:51 --> Security Class Initialized
DEBUG - 2018-10-22 13:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:31:51 --> CSRF cookie sent
INFO - 2018-10-22 13:31:52 --> CSRF token verified
INFO - 2018-10-22 13:31:52 --> Input Class Initialized
INFO - 2018-10-22 13:31:52 --> Language Class Initialized
INFO - 2018-10-22 13:31:52 --> Loader Class Initialized
INFO - 2018-10-22 13:31:52 --> Helper loaded: url_helper
INFO - 2018-10-22 13:31:52 --> Helper loaded: form_helper
INFO - 2018-10-22 13:31:52 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:31:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:31:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:31:52 --> User Agent Class Initialized
INFO - 2018-10-22 13:31:52 --> Controller Class Initialized
INFO - 2018-10-22 13:31:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:31:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:31:52 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:31:52 --> Pixel_Model class loaded
INFO - 2018-10-22 13:31:52 --> Database Driver Class Initialized
INFO - 2018-10-22 13:31:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:31:52 --> Form Validation Class Initialized
INFO - 2018-10-22 13:31:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:31:52 --> Database Driver Class Initialized
INFO - 2018-10-22 13:31:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:35:52 --> Config Class Initialized
INFO - 2018-10-22 13:35:52 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:35:52 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:35:52 --> Utf8 Class Initialized
INFO - 2018-10-22 13:35:52 --> URI Class Initialized
INFO - 2018-10-22 13:35:52 --> Router Class Initialized
INFO - 2018-10-22 13:35:52 --> Output Class Initialized
INFO - 2018-10-22 13:35:52 --> Security Class Initialized
DEBUG - 2018-10-22 13:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:35:52 --> CSRF cookie sent
INFO - 2018-10-22 13:35:52 --> CSRF token verified
INFO - 2018-10-22 13:35:52 --> Input Class Initialized
INFO - 2018-10-22 13:35:52 --> Language Class Initialized
INFO - 2018-10-22 13:35:52 --> Loader Class Initialized
INFO - 2018-10-22 13:35:52 --> Helper loaded: url_helper
INFO - 2018-10-22 13:35:52 --> Helper loaded: form_helper
INFO - 2018-10-22 13:35:52 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:35:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:35:52 --> User Agent Class Initialized
INFO - 2018-10-22 13:35:52 --> Controller Class Initialized
INFO - 2018-10-22 13:35:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:35:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:35:52 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:35:52 --> Pixel_Model class loaded
INFO - 2018-10-22 13:35:52 --> Database Driver Class Initialized
INFO - 2018-10-22 13:35:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:35:52 --> Form Validation Class Initialized
INFO - 2018-10-22 13:35:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:35:52 --> Database Driver Class Initialized
INFO - 2018-10-22 13:35:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:37:51 --> Config Class Initialized
INFO - 2018-10-22 13:37:51 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:37:51 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:37:51 --> Utf8 Class Initialized
INFO - 2018-10-22 13:37:51 --> URI Class Initialized
INFO - 2018-10-22 13:37:51 --> Router Class Initialized
INFO - 2018-10-22 13:37:51 --> Output Class Initialized
INFO - 2018-10-22 13:37:51 --> Security Class Initialized
DEBUG - 2018-10-22 13:37:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:37:51 --> CSRF cookie sent
INFO - 2018-10-22 13:37:51 --> CSRF token verified
INFO - 2018-10-22 13:37:51 --> Input Class Initialized
INFO - 2018-10-22 13:37:51 --> Language Class Initialized
INFO - 2018-10-22 13:37:51 --> Loader Class Initialized
INFO - 2018-10-22 13:37:51 --> Helper loaded: url_helper
INFO - 2018-10-22 13:37:51 --> Helper loaded: form_helper
INFO - 2018-10-22 13:37:51 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:37:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:37:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:37:52 --> User Agent Class Initialized
INFO - 2018-10-22 13:37:52 --> Controller Class Initialized
INFO - 2018-10-22 13:37:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:37:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:37:52 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:37:52 --> Pixel_Model class loaded
INFO - 2018-10-22 13:37:52 --> Database Driver Class Initialized
INFO - 2018-10-22 13:37:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:37:52 --> Form Validation Class Initialized
INFO - 2018-10-22 13:37:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:37:52 --> Database Driver Class Initialized
INFO - 2018-10-22 13:37:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:38:07 --> Config Class Initialized
INFO - 2018-10-22 13:38:07 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:38:07 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:38:07 --> Utf8 Class Initialized
INFO - 2018-10-22 13:38:07 --> URI Class Initialized
INFO - 2018-10-22 13:38:07 --> Router Class Initialized
INFO - 2018-10-22 13:38:07 --> Output Class Initialized
INFO - 2018-10-22 13:38:07 --> Security Class Initialized
DEBUG - 2018-10-22 13:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:38:07 --> CSRF cookie sent
INFO - 2018-10-22 13:38:07 --> CSRF token verified
INFO - 2018-10-22 13:38:07 --> Input Class Initialized
INFO - 2018-10-22 13:38:07 --> Language Class Initialized
INFO - 2018-10-22 13:38:07 --> Loader Class Initialized
INFO - 2018-10-22 13:38:07 --> Helper loaded: url_helper
INFO - 2018-10-22 13:38:07 --> Helper loaded: form_helper
INFO - 2018-10-22 13:38:07 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:38:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:38:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:38:07 --> User Agent Class Initialized
INFO - 2018-10-22 13:38:07 --> Controller Class Initialized
INFO - 2018-10-22 13:38:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:38:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:38:07 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:38:07 --> Pixel_Model class loaded
INFO - 2018-10-22 13:38:07 --> Database Driver Class Initialized
INFO - 2018-10-22 13:38:07 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:38:07 --> Form Validation Class Initialized
INFO - 2018-10-22 13:38:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:38:07 --> Database Driver Class Initialized
INFO - 2018-10-22 13:38:07 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:38:07 --> Config Class Initialized
INFO - 2018-10-22 13:38:07 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:38:07 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:38:07 --> Utf8 Class Initialized
INFO - 2018-10-22 13:38:07 --> URI Class Initialized
INFO - 2018-10-22 13:38:07 --> Router Class Initialized
INFO - 2018-10-22 13:38:07 --> Output Class Initialized
INFO - 2018-10-22 13:38:07 --> Security Class Initialized
DEBUG - 2018-10-22 13:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:38:07 --> CSRF cookie sent
INFO - 2018-10-22 13:38:07 --> Input Class Initialized
INFO - 2018-10-22 13:38:07 --> Language Class Initialized
INFO - 2018-10-22 13:38:07 --> Loader Class Initialized
INFO - 2018-10-22 13:38:07 --> Helper loaded: url_helper
INFO - 2018-10-22 13:38:07 --> Helper loaded: form_helper
INFO - 2018-10-22 13:38:07 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:38:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:38:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:38:07 --> User Agent Class Initialized
INFO - 2018-10-22 13:38:07 --> Controller Class Initialized
INFO - 2018-10-22 13:38:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:38:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:38:07 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:38:07 --> Pixel_Model class loaded
INFO - 2018-10-22 13:38:07 --> Database Driver Class Initialized
INFO - 2018-10-22 13:38:07 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:38:07 --> Database Driver Class Initialized
INFO - 2018-10-22 13:38:07 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:38:15 --> Config Class Initialized
INFO - 2018-10-22 13:38:15 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:38:15 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:38:15 --> Utf8 Class Initialized
INFO - 2018-10-22 13:38:15 --> URI Class Initialized
INFO - 2018-10-22 13:38:15 --> Router Class Initialized
INFO - 2018-10-22 13:38:15 --> Output Class Initialized
INFO - 2018-10-22 13:38:15 --> Security Class Initialized
DEBUG - 2018-10-22 13:38:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:38:15 --> CSRF cookie sent
INFO - 2018-10-22 13:38:15 --> Input Class Initialized
INFO - 2018-10-22 13:38:15 --> Language Class Initialized
INFO - 2018-10-22 13:38:15 --> Loader Class Initialized
INFO - 2018-10-22 13:38:15 --> Helper loaded: url_helper
INFO - 2018-10-22 13:38:15 --> Helper loaded: form_helper
INFO - 2018-10-22 13:38:15 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:38:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:38:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:38:15 --> User Agent Class Initialized
INFO - 2018-10-22 13:38:15 --> Controller Class Initialized
INFO - 2018-10-22 13:38:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:38:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:38:15 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:38:15 --> Pixel_Model class loaded
INFO - 2018-10-22 13:38:15 --> Database Driver Class Initialized
INFO - 2018-10-22 13:38:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:38:15 --> Database Driver Class Initialized
INFO - 2018-10-22 13:38:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:38:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:38:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:38:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:38:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:38:16 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:38:16 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:38:16 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/income.php
INFO - 2018-10-22 13:38:16 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:38:16 --> Final output sent to browser
DEBUG - 2018-10-22 13:38:16 --> Total execution time: 0.4610
INFO - 2018-10-22 13:38:23 --> Config Class Initialized
INFO - 2018-10-22 13:38:23 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:38:23 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:38:23 --> Utf8 Class Initialized
INFO - 2018-10-22 13:38:23 --> URI Class Initialized
INFO - 2018-10-22 13:38:23 --> Router Class Initialized
INFO - 2018-10-22 13:38:23 --> Output Class Initialized
INFO - 2018-10-22 13:38:23 --> Security Class Initialized
DEBUG - 2018-10-22 13:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:38:23 --> CSRF cookie sent
INFO - 2018-10-22 13:38:23 --> Input Class Initialized
INFO - 2018-10-22 13:38:23 --> Language Class Initialized
INFO - 2018-10-22 13:38:23 --> Loader Class Initialized
INFO - 2018-10-22 13:38:23 --> Helper loaded: url_helper
INFO - 2018-10-22 13:38:23 --> Helper loaded: form_helper
INFO - 2018-10-22 13:38:23 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:38:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:38:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:38:23 --> User Agent Class Initialized
INFO - 2018-10-22 13:38:23 --> Controller Class Initialized
INFO - 2018-10-22 13:38:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:38:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:38:23 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:38:23 --> Pixel_Model class loaded
INFO - 2018-10-22 13:38:23 --> Database Driver Class Initialized
INFO - 2018-10-22 13:38:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:38:23 --> Database Driver Class Initialized
INFO - 2018-10-22 13:38:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:38:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:38:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:38:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:38:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:38:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:38:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:38:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/income.php
INFO - 2018-10-22 13:38:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:38:23 --> Final output sent to browser
DEBUG - 2018-10-22 13:38:23 --> Total execution time: 0.4390
INFO - 2018-10-22 13:38:26 --> Config Class Initialized
INFO - 2018-10-22 13:38:26 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:38:26 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:38:26 --> Utf8 Class Initialized
INFO - 2018-10-22 13:38:26 --> URI Class Initialized
INFO - 2018-10-22 13:38:26 --> Router Class Initialized
INFO - 2018-10-22 13:38:26 --> Output Class Initialized
INFO - 2018-10-22 13:38:26 --> Security Class Initialized
DEBUG - 2018-10-22 13:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:38:26 --> CSRF cookie sent
INFO - 2018-10-22 13:38:26 --> Input Class Initialized
INFO - 2018-10-22 13:38:26 --> Language Class Initialized
INFO - 2018-10-22 13:38:26 --> Loader Class Initialized
INFO - 2018-10-22 13:38:26 --> Helper loaded: url_helper
INFO - 2018-10-22 13:38:26 --> Helper loaded: form_helper
INFO - 2018-10-22 13:38:26 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:38:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:38:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:38:26 --> User Agent Class Initialized
INFO - 2018-10-22 13:38:26 --> Controller Class Initialized
INFO - 2018-10-22 13:38:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:38:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:38:26 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:38:26 --> Pixel_Model class loaded
INFO - 2018-10-22 13:38:26 --> Database Driver Class Initialized
INFO - 2018-10-22 13:38:26 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:38:26 --> Database Driver Class Initialized
INFO - 2018-10-22 13:38:26 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:38:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:38:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:38:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner.php
INFO - 2018-10-22 13:38:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:38:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:38:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:38:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:38:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/relation_ship_status.php
INFO - 2018-10-22 13:38:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:38:26 --> Final output sent to browser
DEBUG - 2018-10-22 13:38:26 --> Total execution time: 0.4486
INFO - 2018-10-22 13:39:12 --> Config Class Initialized
INFO - 2018-10-22 13:39:12 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:39:12 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:39:12 --> Utf8 Class Initialized
INFO - 2018-10-22 13:39:12 --> URI Class Initialized
INFO - 2018-10-22 13:39:12 --> Router Class Initialized
INFO - 2018-10-22 13:39:12 --> Output Class Initialized
INFO - 2018-10-22 13:39:12 --> Security Class Initialized
DEBUG - 2018-10-22 13:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:39:12 --> CSRF cookie sent
INFO - 2018-10-22 13:39:12 --> Input Class Initialized
INFO - 2018-10-22 13:39:12 --> Language Class Initialized
INFO - 2018-10-22 13:39:12 --> Loader Class Initialized
INFO - 2018-10-22 13:39:12 --> Helper loaded: url_helper
INFO - 2018-10-22 13:39:12 --> Helper loaded: form_helper
INFO - 2018-10-22 13:39:12 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:39:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:39:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:39:12 --> User Agent Class Initialized
INFO - 2018-10-22 13:39:12 --> Controller Class Initialized
INFO - 2018-10-22 13:39:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:39:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:39:12 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:39:12 --> Pixel_Model class loaded
INFO - 2018-10-22 13:39:12 --> Database Driver Class Initialized
INFO - 2018-10-22 13:39:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:39:12 --> Database Driver Class Initialized
INFO - 2018-10-22 13:39:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:39:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:39:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:39:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner.php
INFO - 2018-10-22 13:39:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:39:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:39:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:39:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:39:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/relation_ship_status.php
INFO - 2018-10-22 13:39:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:39:12 --> Final output sent to browser
DEBUG - 2018-10-22 13:39:12 --> Total execution time: 0.4450
INFO - 2018-10-22 13:39:14 --> Config Class Initialized
INFO - 2018-10-22 13:39:14 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:39:14 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:39:14 --> Utf8 Class Initialized
INFO - 2018-10-22 13:39:14 --> URI Class Initialized
INFO - 2018-10-22 13:39:14 --> Router Class Initialized
INFO - 2018-10-22 13:39:14 --> Output Class Initialized
INFO - 2018-10-22 13:39:14 --> Security Class Initialized
DEBUG - 2018-10-22 13:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:39:14 --> CSRF cookie sent
INFO - 2018-10-22 13:39:14 --> Input Class Initialized
INFO - 2018-10-22 13:39:14 --> Language Class Initialized
INFO - 2018-10-22 13:39:14 --> Loader Class Initialized
INFO - 2018-10-22 13:39:14 --> Helper loaded: url_helper
INFO - 2018-10-22 13:39:14 --> Helper loaded: form_helper
INFO - 2018-10-22 13:39:14 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:39:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:39:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:39:14 --> User Agent Class Initialized
INFO - 2018-10-22 13:39:14 --> Controller Class Initialized
INFO - 2018-10-22 13:39:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:39:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:39:14 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:39:14 --> Pixel_Model class loaded
INFO - 2018-10-22 13:39:14 --> Database Driver Class Initialized
INFO - 2018-10-22 13:39:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:39:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:39:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:39:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:39:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:39:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:39:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:39:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-22 13:39:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:39:14 --> Final output sent to browser
DEBUG - 2018-10-22 13:39:14 --> Total execution time: 0.4139
INFO - 2018-10-22 13:39:17 --> Config Class Initialized
INFO - 2018-10-22 13:39:17 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:39:17 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:39:17 --> Utf8 Class Initialized
INFO - 2018-10-22 13:39:17 --> URI Class Initialized
INFO - 2018-10-22 13:39:17 --> Router Class Initialized
INFO - 2018-10-22 13:39:17 --> Output Class Initialized
INFO - 2018-10-22 13:39:17 --> Security Class Initialized
DEBUG - 2018-10-22 13:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:39:17 --> CSRF cookie sent
INFO - 2018-10-22 13:39:17 --> CSRF token verified
INFO - 2018-10-22 13:39:17 --> Input Class Initialized
INFO - 2018-10-22 13:39:17 --> Language Class Initialized
INFO - 2018-10-22 13:39:17 --> Loader Class Initialized
INFO - 2018-10-22 13:39:17 --> Helper loaded: url_helper
INFO - 2018-10-22 13:39:17 --> Helper loaded: form_helper
INFO - 2018-10-22 13:39:17 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:39:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:39:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:39:17 --> User Agent Class Initialized
INFO - 2018-10-22 13:39:18 --> Controller Class Initialized
INFO - 2018-10-22 13:39:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:39:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:39:18 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:39:18 --> Pixel_Model class loaded
INFO - 2018-10-22 13:39:18 --> Database Driver Class Initialized
INFO - 2018-10-22 13:39:18 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:39:18 --> Form Validation Class Initialized
INFO - 2018-10-22 13:39:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:39:18 --> Database Driver Class Initialized
INFO - 2018-10-22 13:39:18 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:39:18 --> Config Class Initialized
INFO - 2018-10-22 13:39:18 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:39:18 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:39:18 --> Utf8 Class Initialized
INFO - 2018-10-22 13:39:18 --> URI Class Initialized
INFO - 2018-10-22 13:39:18 --> Router Class Initialized
INFO - 2018-10-22 13:39:18 --> Output Class Initialized
INFO - 2018-10-22 13:39:18 --> Security Class Initialized
DEBUG - 2018-10-22 13:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:39:18 --> CSRF cookie sent
INFO - 2018-10-22 13:39:18 --> Input Class Initialized
INFO - 2018-10-22 13:39:18 --> Language Class Initialized
INFO - 2018-10-22 13:39:18 --> Loader Class Initialized
INFO - 2018-10-22 13:39:18 --> Helper loaded: url_helper
INFO - 2018-10-22 13:39:18 --> Helper loaded: form_helper
INFO - 2018-10-22 13:39:18 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:39:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:39:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:39:18 --> User Agent Class Initialized
INFO - 2018-10-22 13:39:18 --> Controller Class Initialized
INFO - 2018-10-22 13:39:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:39:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:39:18 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:39:18 --> Pixel_Model class loaded
INFO - 2018-10-22 13:39:18 --> Database Driver Class Initialized
INFO - 2018-10-22 13:39:18 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:39:18 --> Database Driver Class Initialized
INFO - 2018-10-22 13:39:18 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:39:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:39:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:39:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:39:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:39:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:39:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:39:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-22 13:39:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:39:18 --> Final output sent to browser
DEBUG - 2018-10-22 13:39:18 --> Total execution time: 0.4554
INFO - 2018-10-22 13:39:21 --> Config Class Initialized
INFO - 2018-10-22 13:39:21 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:39:21 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:39:21 --> Utf8 Class Initialized
INFO - 2018-10-22 13:39:21 --> URI Class Initialized
INFO - 2018-10-22 13:39:21 --> Router Class Initialized
INFO - 2018-10-22 13:39:21 --> Output Class Initialized
INFO - 2018-10-22 13:39:21 --> Security Class Initialized
DEBUG - 2018-10-22 13:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:39:21 --> CSRF cookie sent
INFO - 2018-10-22 13:39:21 --> CSRF token verified
INFO - 2018-10-22 13:39:21 --> Input Class Initialized
INFO - 2018-10-22 13:39:21 --> Language Class Initialized
INFO - 2018-10-22 13:39:21 --> Loader Class Initialized
INFO - 2018-10-22 13:39:21 --> Helper loaded: url_helper
INFO - 2018-10-22 13:39:21 --> Helper loaded: form_helper
INFO - 2018-10-22 13:39:21 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:39:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:39:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:39:22 --> User Agent Class Initialized
INFO - 2018-10-22 13:39:22 --> Controller Class Initialized
INFO - 2018-10-22 13:39:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:39:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:39:22 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:39:22 --> Pixel_Model class loaded
INFO - 2018-10-22 13:39:22 --> Database Driver Class Initialized
INFO - 2018-10-22 13:39:22 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:39:22 --> Form Validation Class Initialized
INFO - 2018-10-22 13:39:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:39:22 --> Database Driver Class Initialized
INFO - 2018-10-22 13:39:22 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:39:22 --> Config Class Initialized
INFO - 2018-10-22 13:39:22 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:39:22 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:39:22 --> Utf8 Class Initialized
INFO - 2018-10-22 13:39:22 --> URI Class Initialized
INFO - 2018-10-22 13:39:22 --> Router Class Initialized
INFO - 2018-10-22 13:39:22 --> Output Class Initialized
INFO - 2018-10-22 13:39:22 --> Security Class Initialized
DEBUG - 2018-10-22 13:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:39:22 --> CSRF cookie sent
INFO - 2018-10-22 13:39:22 --> Input Class Initialized
INFO - 2018-10-22 13:39:22 --> Language Class Initialized
INFO - 2018-10-22 13:39:22 --> Loader Class Initialized
INFO - 2018-10-22 13:39:22 --> Helper loaded: url_helper
INFO - 2018-10-22 13:39:22 --> Helper loaded: form_helper
INFO - 2018-10-22 13:39:22 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:39:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:39:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:39:22 --> User Agent Class Initialized
INFO - 2018-10-22 13:39:22 --> Controller Class Initialized
INFO - 2018-10-22 13:39:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:39:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:39:22 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:39:22 --> Pixel_Model class loaded
INFO - 2018-10-22 13:39:22 --> Database Driver Class Initialized
INFO - 2018-10-22 13:39:22 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:39:22 --> Database Driver Class Initialized
INFO - 2018-10-22 13:39:22 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:39:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:39:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:39:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:39:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:39:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:39:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:39:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/your_job.php
INFO - 2018-10-22 13:39:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:39:22 --> Final output sent to browser
DEBUG - 2018-10-22 13:39:22 --> Total execution time: 0.4616
INFO - 2018-10-22 13:39:25 --> Config Class Initialized
INFO - 2018-10-22 13:39:25 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:39:25 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:39:25 --> Utf8 Class Initialized
INFO - 2018-10-22 13:39:25 --> URI Class Initialized
INFO - 2018-10-22 13:39:25 --> Router Class Initialized
INFO - 2018-10-22 13:39:25 --> Output Class Initialized
INFO - 2018-10-22 13:39:25 --> Security Class Initialized
DEBUG - 2018-10-22 13:39:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:39:25 --> CSRF cookie sent
INFO - 2018-10-22 13:39:25 --> CSRF token verified
INFO - 2018-10-22 13:39:25 --> Input Class Initialized
INFO - 2018-10-22 13:39:25 --> Language Class Initialized
INFO - 2018-10-22 13:39:25 --> Loader Class Initialized
INFO - 2018-10-22 13:39:25 --> Helper loaded: url_helper
INFO - 2018-10-22 13:39:25 --> Helper loaded: form_helper
INFO - 2018-10-22 13:39:25 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:39:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:39:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:39:25 --> User Agent Class Initialized
INFO - 2018-10-22 13:39:25 --> Controller Class Initialized
INFO - 2018-10-22 13:39:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:39:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:39:25 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:39:25 --> Pixel_Model class loaded
INFO - 2018-10-22 13:39:25 --> Database Driver Class Initialized
INFO - 2018-10-22 13:39:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:39:25 --> Form Validation Class Initialized
INFO - 2018-10-22 13:39:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:39:25 --> Database Driver Class Initialized
INFO - 2018-10-22 13:39:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:39:25 --> Config Class Initialized
INFO - 2018-10-22 13:39:25 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:39:25 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:39:25 --> Utf8 Class Initialized
INFO - 2018-10-22 13:39:25 --> URI Class Initialized
INFO - 2018-10-22 13:39:25 --> Router Class Initialized
INFO - 2018-10-22 13:39:25 --> Output Class Initialized
INFO - 2018-10-22 13:39:25 --> Security Class Initialized
DEBUG - 2018-10-22 13:39:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:39:25 --> CSRF cookie sent
INFO - 2018-10-22 13:39:25 --> Input Class Initialized
INFO - 2018-10-22 13:39:25 --> Language Class Initialized
INFO - 2018-10-22 13:39:25 --> Loader Class Initialized
INFO - 2018-10-22 13:39:25 --> Helper loaded: url_helper
INFO - 2018-10-22 13:39:25 --> Helper loaded: form_helper
INFO - 2018-10-22 13:39:25 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:39:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:39:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:39:25 --> User Agent Class Initialized
INFO - 2018-10-22 13:39:25 --> Controller Class Initialized
INFO - 2018-10-22 13:39:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:39:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:39:25 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:39:25 --> Pixel_Model class loaded
INFO - 2018-10-22 13:39:25 --> Database Driver Class Initialized
INFO - 2018-10-22 13:39:26 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:39:26 --> Database Driver Class Initialized
INFO - 2018-10-22 13:39:26 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:39:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:39:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:39:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner.php
INFO - 2018-10-22 13:39:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:39:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:39:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:39:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:39:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/relation_ship_status.php
INFO - 2018-10-22 13:39:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:39:26 --> Final output sent to browser
DEBUG - 2018-10-22 13:39:26 --> Total execution time: 0.4491
INFO - 2018-10-22 13:39:29 --> Config Class Initialized
INFO - 2018-10-22 13:39:29 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:39:29 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:39:29 --> Utf8 Class Initialized
INFO - 2018-10-22 13:39:29 --> URI Class Initialized
INFO - 2018-10-22 13:39:29 --> Router Class Initialized
INFO - 2018-10-22 13:39:29 --> Output Class Initialized
INFO - 2018-10-22 13:39:29 --> Security Class Initialized
DEBUG - 2018-10-22 13:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:39:29 --> CSRF cookie sent
INFO - 2018-10-22 13:39:29 --> CSRF token verified
INFO - 2018-10-22 13:39:29 --> Input Class Initialized
INFO - 2018-10-22 13:39:29 --> Language Class Initialized
INFO - 2018-10-22 13:39:29 --> Loader Class Initialized
INFO - 2018-10-22 13:39:29 --> Helper loaded: url_helper
INFO - 2018-10-22 13:39:29 --> Helper loaded: form_helper
INFO - 2018-10-22 13:39:29 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:39:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:39:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:39:29 --> User Agent Class Initialized
INFO - 2018-10-22 13:39:29 --> Controller Class Initialized
INFO - 2018-10-22 13:39:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:39:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:39:29 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:39:29 --> Pixel_Model class loaded
INFO - 2018-10-22 13:39:30 --> Database Driver Class Initialized
INFO - 2018-10-22 13:39:30 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:39:30 --> Form Validation Class Initialized
INFO - 2018-10-22 13:39:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:39:30 --> Database Driver Class Initialized
INFO - 2018-10-22 13:39:30 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:39:30 --> Config Class Initialized
INFO - 2018-10-22 13:39:30 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:39:30 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:39:30 --> Utf8 Class Initialized
INFO - 2018-10-22 13:39:30 --> URI Class Initialized
INFO - 2018-10-22 13:39:30 --> Router Class Initialized
INFO - 2018-10-22 13:39:30 --> Output Class Initialized
INFO - 2018-10-22 13:39:30 --> Security Class Initialized
DEBUG - 2018-10-22 13:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:39:30 --> CSRF cookie sent
INFO - 2018-10-22 13:39:30 --> Input Class Initialized
INFO - 2018-10-22 13:39:30 --> Language Class Initialized
INFO - 2018-10-22 13:39:30 --> Loader Class Initialized
INFO - 2018-10-22 13:39:30 --> Helper loaded: url_helper
INFO - 2018-10-22 13:39:30 --> Helper loaded: form_helper
INFO - 2018-10-22 13:39:30 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:39:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:39:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:39:30 --> User Agent Class Initialized
INFO - 2018-10-22 13:39:30 --> Controller Class Initialized
INFO - 2018-10-22 13:39:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:39:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:39:30 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:39:30 --> Pixel_Model class loaded
INFO - 2018-10-22 13:39:30 --> Database Driver Class Initialized
INFO - 2018-10-22 13:39:30 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:39:30 --> Database Driver Class Initialized
INFO - 2018-10-22 13:39:30 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:39:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:39:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:39:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:39:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:39:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:39:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:39:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/income.php
INFO - 2018-10-22 13:39:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:39:30 --> Final output sent to browser
DEBUG - 2018-10-22 13:39:30 --> Total execution time: 0.4286
INFO - 2018-10-22 13:39:39 --> Config Class Initialized
INFO - 2018-10-22 13:39:39 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:39:39 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:39:39 --> Utf8 Class Initialized
INFO - 2018-10-22 13:39:39 --> URI Class Initialized
INFO - 2018-10-22 13:39:39 --> Router Class Initialized
INFO - 2018-10-22 13:39:39 --> Output Class Initialized
INFO - 2018-10-22 13:39:39 --> Security Class Initialized
DEBUG - 2018-10-22 13:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:39:39 --> CSRF cookie sent
INFO - 2018-10-22 13:39:39 --> CSRF token verified
INFO - 2018-10-22 13:39:40 --> Input Class Initialized
INFO - 2018-10-22 13:39:40 --> Language Class Initialized
INFO - 2018-10-22 13:39:40 --> Loader Class Initialized
INFO - 2018-10-22 13:39:40 --> Helper loaded: url_helper
INFO - 2018-10-22 13:39:40 --> Helper loaded: form_helper
INFO - 2018-10-22 13:39:40 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:39:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:39:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:39:40 --> User Agent Class Initialized
INFO - 2018-10-22 13:39:40 --> Controller Class Initialized
INFO - 2018-10-22 13:39:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:39:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:39:40 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:39:40 --> Pixel_Model class loaded
INFO - 2018-10-22 13:39:40 --> Database Driver Class Initialized
INFO - 2018-10-22 13:39:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:39:40 --> Form Validation Class Initialized
INFO - 2018-10-22 13:39:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:39:40 --> Database Driver Class Initialized
INFO - 2018-10-22 13:39:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:39:40 --> Config Class Initialized
INFO - 2018-10-22 13:39:40 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:39:40 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:39:40 --> Utf8 Class Initialized
INFO - 2018-10-22 13:39:40 --> URI Class Initialized
INFO - 2018-10-22 13:39:40 --> Router Class Initialized
INFO - 2018-10-22 13:39:40 --> Output Class Initialized
INFO - 2018-10-22 13:39:40 --> Security Class Initialized
DEBUG - 2018-10-22 13:39:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:39:40 --> CSRF cookie sent
INFO - 2018-10-22 13:39:40 --> Input Class Initialized
INFO - 2018-10-22 13:39:40 --> Language Class Initialized
INFO - 2018-10-22 13:39:40 --> Loader Class Initialized
INFO - 2018-10-22 13:39:40 --> Helper loaded: url_helper
INFO - 2018-10-22 13:39:40 --> Helper loaded: form_helper
INFO - 2018-10-22 13:39:40 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:39:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:39:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:39:40 --> User Agent Class Initialized
INFO - 2018-10-22 13:39:40 --> Controller Class Initialized
INFO - 2018-10-22 13:39:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:39:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:39:40 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:39:40 --> Pixel_Model class loaded
INFO - 2018-10-22 13:39:40 --> Database Driver Class Initialized
INFO - 2018-10-22 13:39:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:39:40 --> Database Driver Class Initialized
INFO - 2018-10-22 13:39:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:39:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:39:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:39:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:39:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:39:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:39:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:39:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/cohabitation.php
INFO - 2018-10-22 13:39:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:39:40 --> Final output sent to browser
DEBUG - 2018-10-22 13:39:40 --> Total execution time: 0.4273
INFO - 2018-10-22 13:42:35 --> Config Class Initialized
INFO - 2018-10-22 13:42:35 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:42:35 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:42:35 --> Utf8 Class Initialized
INFO - 2018-10-22 13:42:35 --> URI Class Initialized
INFO - 2018-10-22 13:42:35 --> Router Class Initialized
INFO - 2018-10-22 13:42:35 --> Output Class Initialized
INFO - 2018-10-22 13:42:35 --> Security Class Initialized
DEBUG - 2018-10-22 13:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:42:35 --> CSRF cookie sent
INFO - 2018-10-22 13:42:35 --> Input Class Initialized
INFO - 2018-10-22 13:42:35 --> Language Class Initialized
INFO - 2018-10-22 13:42:35 --> Loader Class Initialized
INFO - 2018-10-22 13:42:35 --> Helper loaded: url_helper
INFO - 2018-10-22 13:42:35 --> Helper loaded: form_helper
INFO - 2018-10-22 13:42:35 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:42:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:42:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:42:35 --> User Agent Class Initialized
INFO - 2018-10-22 13:42:35 --> Controller Class Initialized
INFO - 2018-10-22 13:42:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:42:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:42:35 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:42:35 --> Pixel_Model class loaded
INFO - 2018-10-22 13:42:35 --> Database Driver Class Initialized
INFO - 2018-10-22 13:42:35 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:42:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:42:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:42:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:42:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:42:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:42:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:42:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-22 13:42:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:42:35 --> Final output sent to browser
DEBUG - 2018-10-22 13:42:35 --> Total execution time: 0.4294
INFO - 2018-10-22 13:42:36 --> Config Class Initialized
INFO - 2018-10-22 13:42:36 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:42:36 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:42:36 --> Utf8 Class Initialized
INFO - 2018-10-22 13:42:36 --> URI Class Initialized
INFO - 2018-10-22 13:42:36 --> Router Class Initialized
INFO - 2018-10-22 13:42:36 --> Output Class Initialized
INFO - 2018-10-22 13:42:36 --> Security Class Initialized
DEBUG - 2018-10-22 13:42:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:42:36 --> CSRF cookie sent
INFO - 2018-10-22 13:42:36 --> Input Class Initialized
INFO - 2018-10-22 13:42:36 --> Language Class Initialized
INFO - 2018-10-22 13:42:36 --> Loader Class Initialized
INFO - 2018-10-22 13:42:36 --> Helper loaded: url_helper
INFO - 2018-10-22 13:42:36 --> Helper loaded: form_helper
INFO - 2018-10-22 13:42:36 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:42:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:42:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:42:36 --> User Agent Class Initialized
INFO - 2018-10-22 13:42:36 --> Controller Class Initialized
INFO - 2018-10-22 13:42:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:42:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:42:36 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:42:36 --> Pixel_Model class loaded
INFO - 2018-10-22 13:42:36 --> Database Driver Class Initialized
INFO - 2018-10-22 13:42:36 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:42:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:42:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:42:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:42:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:42:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:42:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:42:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-22 13:42:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:42:36 --> Final output sent to browser
DEBUG - 2018-10-22 13:42:36 --> Total execution time: 0.4751
INFO - 2018-10-22 13:42:39 --> Config Class Initialized
INFO - 2018-10-22 13:42:39 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:42:39 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:42:39 --> Utf8 Class Initialized
INFO - 2018-10-22 13:42:39 --> URI Class Initialized
INFO - 2018-10-22 13:42:39 --> Router Class Initialized
INFO - 2018-10-22 13:42:39 --> Output Class Initialized
INFO - 2018-10-22 13:42:39 --> Security Class Initialized
DEBUG - 2018-10-22 13:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:42:39 --> CSRF cookie sent
INFO - 2018-10-22 13:42:39 --> CSRF token verified
INFO - 2018-10-22 13:42:39 --> Input Class Initialized
INFO - 2018-10-22 13:42:39 --> Language Class Initialized
INFO - 2018-10-22 13:42:39 --> Loader Class Initialized
INFO - 2018-10-22 13:42:39 --> Helper loaded: url_helper
INFO - 2018-10-22 13:42:39 --> Helper loaded: form_helper
INFO - 2018-10-22 13:42:39 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:42:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:42:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:42:39 --> User Agent Class Initialized
INFO - 2018-10-22 13:42:39 --> Controller Class Initialized
INFO - 2018-10-22 13:42:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:42:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:42:39 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:42:39 --> Pixel_Model class loaded
INFO - 2018-10-22 13:42:39 --> Database Driver Class Initialized
INFO - 2018-10-22 13:42:39 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:42:39 --> Form Validation Class Initialized
INFO - 2018-10-22 13:42:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:42:39 --> Database Driver Class Initialized
INFO - 2018-10-22 13:42:39 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:42:39 --> Config Class Initialized
INFO - 2018-10-22 13:42:39 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:42:39 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:42:39 --> Utf8 Class Initialized
INFO - 2018-10-22 13:42:39 --> URI Class Initialized
INFO - 2018-10-22 13:42:39 --> Router Class Initialized
INFO - 2018-10-22 13:42:39 --> Output Class Initialized
INFO - 2018-10-22 13:42:39 --> Security Class Initialized
DEBUG - 2018-10-22 13:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:42:39 --> CSRF cookie sent
INFO - 2018-10-22 13:42:39 --> Input Class Initialized
INFO - 2018-10-22 13:42:39 --> Language Class Initialized
INFO - 2018-10-22 13:42:39 --> Loader Class Initialized
INFO - 2018-10-22 13:42:39 --> Helper loaded: url_helper
INFO - 2018-10-22 13:42:39 --> Helper loaded: form_helper
INFO - 2018-10-22 13:42:39 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:42:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:42:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:42:39 --> User Agent Class Initialized
INFO - 2018-10-22 13:42:39 --> Controller Class Initialized
INFO - 2018-10-22 13:42:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:42:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:42:39 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:42:39 --> Pixel_Model class loaded
INFO - 2018-10-22 13:42:40 --> Database Driver Class Initialized
INFO - 2018-10-22 13:42:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:42:40 --> Database Driver Class Initialized
INFO - 2018-10-22 13:42:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:42:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:42:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:42:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:42:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:42:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:42:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:42:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-22 13:42:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:42:40 --> Final output sent to browser
DEBUG - 2018-10-22 13:42:40 --> Total execution time: 0.4399
INFO - 2018-10-22 13:42:43 --> Config Class Initialized
INFO - 2018-10-22 13:42:43 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:42:43 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:42:43 --> Utf8 Class Initialized
INFO - 2018-10-22 13:42:43 --> URI Class Initialized
INFO - 2018-10-22 13:42:43 --> Router Class Initialized
INFO - 2018-10-22 13:42:43 --> Output Class Initialized
INFO - 2018-10-22 13:42:43 --> Security Class Initialized
DEBUG - 2018-10-22 13:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:42:43 --> CSRF cookie sent
INFO - 2018-10-22 13:42:43 --> CSRF token verified
INFO - 2018-10-22 13:42:43 --> Input Class Initialized
INFO - 2018-10-22 13:42:43 --> Language Class Initialized
INFO - 2018-10-22 13:42:43 --> Loader Class Initialized
INFO - 2018-10-22 13:42:43 --> Helper loaded: url_helper
INFO - 2018-10-22 13:42:43 --> Helper loaded: form_helper
INFO - 2018-10-22 13:42:43 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:42:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:42:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:42:43 --> User Agent Class Initialized
INFO - 2018-10-22 13:42:43 --> Controller Class Initialized
INFO - 2018-10-22 13:42:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:42:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:42:43 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:42:43 --> Pixel_Model class loaded
INFO - 2018-10-22 13:42:43 --> Database Driver Class Initialized
INFO - 2018-10-22 13:42:43 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:42:43 --> Form Validation Class Initialized
INFO - 2018-10-22 13:42:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:42:43 --> Database Driver Class Initialized
INFO - 2018-10-22 13:42:43 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:42:44 --> Config Class Initialized
INFO - 2018-10-22 13:42:44 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:42:44 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:42:44 --> Utf8 Class Initialized
INFO - 2018-10-22 13:42:44 --> URI Class Initialized
INFO - 2018-10-22 13:42:44 --> Router Class Initialized
INFO - 2018-10-22 13:42:44 --> Output Class Initialized
INFO - 2018-10-22 13:42:44 --> Security Class Initialized
DEBUG - 2018-10-22 13:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:42:44 --> CSRF cookie sent
INFO - 2018-10-22 13:42:44 --> Input Class Initialized
INFO - 2018-10-22 13:42:44 --> Language Class Initialized
INFO - 2018-10-22 13:42:44 --> Loader Class Initialized
INFO - 2018-10-22 13:42:44 --> Helper loaded: url_helper
INFO - 2018-10-22 13:42:44 --> Helper loaded: form_helper
INFO - 2018-10-22 13:42:44 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:42:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:42:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:42:44 --> User Agent Class Initialized
INFO - 2018-10-22 13:42:44 --> Controller Class Initialized
INFO - 2018-10-22 13:42:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:42:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:42:44 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:42:44 --> Pixel_Model class loaded
INFO - 2018-10-22 13:42:44 --> Database Driver Class Initialized
INFO - 2018-10-22 13:42:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:42:44 --> Database Driver Class Initialized
INFO - 2018-10-22 13:42:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:42:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:42:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:42:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:42:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:42:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:42:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:42:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/your_job.php
INFO - 2018-10-22 13:42:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:42:44 --> Final output sent to browser
DEBUG - 2018-10-22 13:42:44 --> Total execution time: 0.4829
INFO - 2018-10-22 13:42:46 --> Config Class Initialized
INFO - 2018-10-22 13:42:46 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:42:47 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:42:47 --> Utf8 Class Initialized
INFO - 2018-10-22 13:42:47 --> URI Class Initialized
INFO - 2018-10-22 13:42:47 --> Router Class Initialized
INFO - 2018-10-22 13:42:47 --> Output Class Initialized
INFO - 2018-10-22 13:42:47 --> Security Class Initialized
DEBUG - 2018-10-22 13:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:42:47 --> CSRF cookie sent
INFO - 2018-10-22 13:42:47 --> Input Class Initialized
INFO - 2018-10-22 13:42:47 --> Language Class Initialized
INFO - 2018-10-22 13:42:47 --> Loader Class Initialized
INFO - 2018-10-22 13:42:47 --> Helper loaded: url_helper
INFO - 2018-10-22 13:42:47 --> Helper loaded: form_helper
INFO - 2018-10-22 13:42:47 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:42:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:42:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:42:47 --> User Agent Class Initialized
INFO - 2018-10-22 13:42:47 --> Controller Class Initialized
INFO - 2018-10-22 13:42:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:42:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:42:47 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:42:47 --> Pixel_Model class loaded
INFO - 2018-10-22 13:42:47 --> Database Driver Class Initialized
INFO - 2018-10-22 13:42:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:42:47 --> Database Driver Class Initialized
INFO - 2018-10-22 13:42:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:42:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:42:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:42:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:42:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:42:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:42:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:42:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-22 13:42:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:42:47 --> Final output sent to browser
DEBUG - 2018-10-22 13:42:47 --> Total execution time: 0.4749
INFO - 2018-10-22 13:42:49 --> Config Class Initialized
INFO - 2018-10-22 13:42:49 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:42:49 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:42:49 --> Utf8 Class Initialized
INFO - 2018-10-22 13:42:49 --> URI Class Initialized
INFO - 2018-10-22 13:42:49 --> Router Class Initialized
INFO - 2018-10-22 13:42:49 --> Output Class Initialized
INFO - 2018-10-22 13:42:49 --> Security Class Initialized
DEBUG - 2018-10-22 13:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:42:49 --> CSRF cookie sent
INFO - 2018-10-22 13:42:49 --> CSRF token verified
INFO - 2018-10-22 13:42:49 --> Input Class Initialized
INFO - 2018-10-22 13:42:49 --> Language Class Initialized
INFO - 2018-10-22 13:42:49 --> Loader Class Initialized
INFO - 2018-10-22 13:42:49 --> Helper loaded: url_helper
INFO - 2018-10-22 13:42:49 --> Helper loaded: form_helper
INFO - 2018-10-22 13:42:49 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:42:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:42:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:42:49 --> User Agent Class Initialized
INFO - 2018-10-22 13:42:49 --> Controller Class Initialized
INFO - 2018-10-22 13:42:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:42:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:42:49 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:42:49 --> Pixel_Model class loaded
INFO - 2018-10-22 13:42:49 --> Database Driver Class Initialized
INFO - 2018-10-22 13:42:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:42:49 --> Form Validation Class Initialized
INFO - 2018-10-22 13:42:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:42:49 --> Database Driver Class Initialized
INFO - 2018-10-22 13:42:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:42:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:42:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:42:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:42:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:42:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:42:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_errors.php
INFO - 2018-10-22 13:42:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:42:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-22 13:42:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:42:49 --> Final output sent to browser
DEBUG - 2018-10-22 13:42:49 --> Total execution time: 0.5343
INFO - 2018-10-22 13:43:01 --> Config Class Initialized
INFO - 2018-10-22 13:43:01 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:43:01 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:43:01 --> Utf8 Class Initialized
INFO - 2018-10-22 13:43:01 --> URI Class Initialized
INFO - 2018-10-22 13:43:01 --> Router Class Initialized
INFO - 2018-10-22 13:43:01 --> Output Class Initialized
INFO - 2018-10-22 13:43:01 --> Security Class Initialized
DEBUG - 2018-10-22 13:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:43:01 --> CSRF cookie sent
INFO - 2018-10-22 13:43:01 --> CSRF token verified
INFO - 2018-10-22 13:43:01 --> Input Class Initialized
INFO - 2018-10-22 13:43:01 --> Language Class Initialized
INFO - 2018-10-22 13:43:01 --> Loader Class Initialized
INFO - 2018-10-22 13:43:01 --> Helper loaded: url_helper
INFO - 2018-10-22 13:43:01 --> Helper loaded: form_helper
INFO - 2018-10-22 13:43:01 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:43:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:43:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:43:01 --> User Agent Class Initialized
INFO - 2018-10-22 13:43:01 --> Controller Class Initialized
INFO - 2018-10-22 13:43:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:43:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:43:01 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:43:01 --> Pixel_Model class loaded
INFO - 2018-10-22 13:43:01 --> Database Driver Class Initialized
INFO - 2018-10-22 13:43:01 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:43:01 --> Form Validation Class Initialized
INFO - 2018-10-22 13:43:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:43:01 --> Database Driver Class Initialized
INFO - 2018-10-22 13:43:01 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:43:01 --> Config Class Initialized
INFO - 2018-10-22 13:43:01 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:43:01 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:43:01 --> Utf8 Class Initialized
INFO - 2018-10-22 13:43:01 --> URI Class Initialized
INFO - 2018-10-22 13:43:01 --> Router Class Initialized
INFO - 2018-10-22 13:43:01 --> Output Class Initialized
INFO - 2018-10-22 13:43:01 --> Security Class Initialized
DEBUG - 2018-10-22 13:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:43:01 --> CSRF cookie sent
INFO - 2018-10-22 13:43:01 --> Input Class Initialized
INFO - 2018-10-22 13:43:01 --> Language Class Initialized
INFO - 2018-10-22 13:43:01 --> Loader Class Initialized
INFO - 2018-10-22 13:43:01 --> Helper loaded: url_helper
INFO - 2018-10-22 13:43:01 --> Helper loaded: form_helper
INFO - 2018-10-22 13:43:01 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:43:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:43:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:43:01 --> User Agent Class Initialized
INFO - 2018-10-22 13:43:02 --> Controller Class Initialized
INFO - 2018-10-22 13:43:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:43:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:43:02 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:43:02 --> Pixel_Model class loaded
INFO - 2018-10-22 13:43:02 --> Database Driver Class Initialized
INFO - 2018-10-22 13:43:02 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:43:02 --> Database Driver Class Initialized
INFO - 2018-10-22 13:43:02 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:43:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:43:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:43:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:43:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:43:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:43:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:43:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/your_job.php
INFO - 2018-10-22 13:43:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:43:02 --> Final output sent to browser
DEBUG - 2018-10-22 13:43:02 --> Total execution time: 0.4644
INFO - 2018-10-22 13:43:07 --> Config Class Initialized
INFO - 2018-10-22 13:43:07 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:43:07 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:43:07 --> Utf8 Class Initialized
INFO - 2018-10-22 13:43:08 --> URI Class Initialized
INFO - 2018-10-22 13:43:08 --> Router Class Initialized
INFO - 2018-10-22 13:43:08 --> Output Class Initialized
INFO - 2018-10-22 13:43:08 --> Security Class Initialized
DEBUG - 2018-10-22 13:43:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:43:08 --> CSRF cookie sent
INFO - 2018-10-22 13:43:08 --> CSRF token verified
INFO - 2018-10-22 13:43:08 --> Input Class Initialized
INFO - 2018-10-22 13:43:08 --> Language Class Initialized
INFO - 2018-10-22 13:43:08 --> Loader Class Initialized
INFO - 2018-10-22 13:43:08 --> Helper loaded: url_helper
INFO - 2018-10-22 13:43:08 --> Helper loaded: form_helper
INFO - 2018-10-22 13:43:08 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:43:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:43:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:43:08 --> User Agent Class Initialized
INFO - 2018-10-22 13:43:08 --> Controller Class Initialized
INFO - 2018-10-22 13:43:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:43:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:43:08 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:43:08 --> Pixel_Model class loaded
INFO - 2018-10-22 13:43:08 --> Database Driver Class Initialized
INFO - 2018-10-22 13:43:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:43:08 --> Form Validation Class Initialized
INFO - 2018-10-22 13:43:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:43:08 --> Database Driver Class Initialized
INFO - 2018-10-22 13:43:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:43:08 --> Config Class Initialized
INFO - 2018-10-22 13:43:08 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:43:08 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:43:08 --> Utf8 Class Initialized
INFO - 2018-10-22 13:43:08 --> URI Class Initialized
INFO - 2018-10-22 13:43:08 --> Router Class Initialized
INFO - 2018-10-22 13:43:08 --> Output Class Initialized
INFO - 2018-10-22 13:43:08 --> Security Class Initialized
DEBUG - 2018-10-22 13:43:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:43:08 --> CSRF cookie sent
INFO - 2018-10-22 13:43:08 --> Input Class Initialized
INFO - 2018-10-22 13:43:08 --> Language Class Initialized
INFO - 2018-10-22 13:43:08 --> Loader Class Initialized
INFO - 2018-10-22 13:43:08 --> Helper loaded: url_helper
INFO - 2018-10-22 13:43:08 --> Helper loaded: form_helper
INFO - 2018-10-22 13:43:08 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:43:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:43:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:43:08 --> User Agent Class Initialized
INFO - 2018-10-22 13:43:08 --> Controller Class Initialized
INFO - 2018-10-22 13:43:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:43:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:43:08 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:43:08 --> Pixel_Model class loaded
INFO - 2018-10-22 13:43:08 --> Database Driver Class Initialized
INFO - 2018-10-22 13:43:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:43:08 --> Database Driver Class Initialized
INFO - 2018-10-22 13:43:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:43:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:43:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:43:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner.php
INFO - 2018-10-22 13:43:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:43:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:43:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:43:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:43:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/relation_ship_status.php
INFO - 2018-10-22 13:43:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:43:08 --> Final output sent to browser
DEBUG - 2018-10-22 13:43:08 --> Total execution time: 0.4642
INFO - 2018-10-22 13:43:27 --> Config Class Initialized
INFO - 2018-10-22 13:43:27 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:43:27 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:43:27 --> Utf8 Class Initialized
INFO - 2018-10-22 13:43:27 --> URI Class Initialized
INFO - 2018-10-22 13:43:27 --> Router Class Initialized
INFO - 2018-10-22 13:43:27 --> Output Class Initialized
INFO - 2018-10-22 13:43:27 --> Security Class Initialized
DEBUG - 2018-10-22 13:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:43:27 --> CSRF cookie sent
INFO - 2018-10-22 13:43:27 --> CSRF token verified
INFO - 2018-10-22 13:43:27 --> Input Class Initialized
INFO - 2018-10-22 13:43:27 --> Language Class Initialized
INFO - 2018-10-22 13:43:27 --> Loader Class Initialized
INFO - 2018-10-22 13:43:27 --> Helper loaded: url_helper
INFO - 2018-10-22 13:43:27 --> Helper loaded: form_helper
INFO - 2018-10-22 13:43:27 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:43:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:43:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:43:27 --> User Agent Class Initialized
INFO - 2018-10-22 13:43:27 --> Controller Class Initialized
INFO - 2018-10-22 13:43:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:43:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:43:27 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:43:27 --> Pixel_Model class loaded
INFO - 2018-10-22 13:43:27 --> Database Driver Class Initialized
INFO - 2018-10-22 13:43:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:43:27 --> Form Validation Class Initialized
INFO - 2018-10-22 13:43:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:43:27 --> Database Driver Class Initialized
INFO - 2018-10-22 13:43:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:43:27 --> Config Class Initialized
INFO - 2018-10-22 13:43:27 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:43:27 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:43:27 --> Utf8 Class Initialized
INFO - 2018-10-22 13:43:27 --> URI Class Initialized
INFO - 2018-10-22 13:43:27 --> Router Class Initialized
INFO - 2018-10-22 13:43:27 --> Output Class Initialized
INFO - 2018-10-22 13:43:27 --> Security Class Initialized
DEBUG - 2018-10-22 13:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:43:27 --> CSRF cookie sent
INFO - 2018-10-22 13:43:27 --> Input Class Initialized
INFO - 2018-10-22 13:43:27 --> Language Class Initialized
INFO - 2018-10-22 13:43:27 --> Loader Class Initialized
INFO - 2018-10-22 13:43:27 --> Helper loaded: url_helper
INFO - 2018-10-22 13:43:27 --> Helper loaded: form_helper
INFO - 2018-10-22 13:43:27 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:43:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:43:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:43:27 --> User Agent Class Initialized
INFO - 2018-10-22 13:43:27 --> Controller Class Initialized
INFO - 2018-10-22 13:43:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:43:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:43:27 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:43:27 --> Pixel_Model class loaded
INFO - 2018-10-22 13:43:27 --> Database Driver Class Initialized
INFO - 2018-10-22 13:43:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:43:27 --> Database Driver Class Initialized
INFO - 2018-10-22 13:43:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:43:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:43:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:43:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:43:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:43:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:43:28 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:43:28 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/income.php
INFO - 2018-10-22 13:43:28 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:43:28 --> Final output sent to browser
DEBUG - 2018-10-22 13:43:28 --> Total execution time: 0.4784
INFO - 2018-10-22 13:43:31 --> Config Class Initialized
INFO - 2018-10-22 13:43:31 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:43:31 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:43:31 --> Utf8 Class Initialized
INFO - 2018-10-22 13:43:31 --> URI Class Initialized
INFO - 2018-10-22 13:43:31 --> Router Class Initialized
INFO - 2018-10-22 13:43:31 --> Output Class Initialized
INFO - 2018-10-22 13:43:31 --> Security Class Initialized
DEBUG - 2018-10-22 13:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:43:31 --> CSRF cookie sent
INFO - 2018-10-22 13:43:31 --> CSRF token verified
INFO - 2018-10-22 13:43:31 --> Input Class Initialized
INFO - 2018-10-22 13:43:31 --> Language Class Initialized
INFO - 2018-10-22 13:43:31 --> Loader Class Initialized
INFO - 2018-10-22 13:43:31 --> Helper loaded: url_helper
INFO - 2018-10-22 13:43:31 --> Helper loaded: form_helper
INFO - 2018-10-22 13:43:31 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:43:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:43:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:43:31 --> User Agent Class Initialized
INFO - 2018-10-22 13:43:31 --> Controller Class Initialized
INFO - 2018-10-22 13:43:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:43:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:43:31 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:43:31 --> Pixel_Model class loaded
INFO - 2018-10-22 13:43:31 --> Database Driver Class Initialized
INFO - 2018-10-22 13:43:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:43:31 --> Form Validation Class Initialized
INFO - 2018-10-22 13:43:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:43:31 --> Database Driver Class Initialized
INFO - 2018-10-22 13:43:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:43:32 --> Config Class Initialized
INFO - 2018-10-22 13:43:32 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:43:32 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:43:32 --> Utf8 Class Initialized
INFO - 2018-10-22 13:43:32 --> URI Class Initialized
INFO - 2018-10-22 13:43:32 --> Router Class Initialized
INFO - 2018-10-22 13:43:32 --> Output Class Initialized
INFO - 2018-10-22 13:43:32 --> Security Class Initialized
DEBUG - 2018-10-22 13:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:43:32 --> CSRF cookie sent
INFO - 2018-10-22 13:43:32 --> Input Class Initialized
INFO - 2018-10-22 13:43:32 --> Language Class Initialized
INFO - 2018-10-22 13:43:32 --> Loader Class Initialized
INFO - 2018-10-22 13:43:32 --> Helper loaded: url_helper
INFO - 2018-10-22 13:43:32 --> Helper loaded: form_helper
INFO - 2018-10-22 13:43:32 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:43:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:43:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:43:32 --> User Agent Class Initialized
INFO - 2018-10-22 13:43:32 --> Controller Class Initialized
INFO - 2018-10-22 13:43:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:43:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:43:32 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:43:32 --> Pixel_Model class loaded
INFO - 2018-10-22 13:43:32 --> Database Driver Class Initialized
INFO - 2018-10-22 13:43:32 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:43:32 --> Database Driver Class Initialized
INFO - 2018-10-22 13:43:32 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:43:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:43:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:43:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:43:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:43:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:43:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:43:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/pension.php
INFO - 2018-10-22 13:43:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:43:32 --> Final output sent to browser
DEBUG - 2018-10-22 13:43:32 --> Total execution time: 0.4570
INFO - 2018-10-22 13:43:39 --> Config Class Initialized
INFO - 2018-10-22 13:43:39 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:43:39 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:43:39 --> Utf8 Class Initialized
INFO - 2018-10-22 13:43:39 --> URI Class Initialized
INFO - 2018-10-22 13:43:39 --> Router Class Initialized
INFO - 2018-10-22 13:43:39 --> Output Class Initialized
INFO - 2018-10-22 13:43:40 --> Security Class Initialized
DEBUG - 2018-10-22 13:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:43:40 --> CSRF cookie sent
INFO - 2018-10-22 13:43:40 --> Input Class Initialized
INFO - 2018-10-22 13:43:40 --> Language Class Initialized
INFO - 2018-10-22 13:43:40 --> Loader Class Initialized
INFO - 2018-10-22 13:43:40 --> Helper loaded: url_helper
INFO - 2018-10-22 13:43:40 --> Helper loaded: form_helper
INFO - 2018-10-22 13:43:40 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:43:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:43:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:43:40 --> User Agent Class Initialized
INFO - 2018-10-22 13:43:40 --> Controller Class Initialized
INFO - 2018-10-22 13:43:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:43:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:43:40 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:43:40 --> Pixel_Model class loaded
INFO - 2018-10-22 13:43:40 --> Database Driver Class Initialized
INFO - 2018-10-22 13:43:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:43:40 --> Database Driver Class Initialized
INFO - 2018-10-22 13:43:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:43:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:43:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:43:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:43:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:43:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:43:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:43:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/pension.php
INFO - 2018-10-22 13:43:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:43:40 --> Final output sent to browser
DEBUG - 2018-10-22 13:43:40 --> Total execution time: 0.5148
INFO - 2018-10-22 13:43:42 --> Config Class Initialized
INFO - 2018-10-22 13:43:42 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:43:43 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:43:43 --> Utf8 Class Initialized
INFO - 2018-10-22 13:43:43 --> URI Class Initialized
INFO - 2018-10-22 13:43:43 --> Router Class Initialized
INFO - 2018-10-22 13:43:43 --> Output Class Initialized
INFO - 2018-10-22 13:43:43 --> Security Class Initialized
DEBUG - 2018-10-22 13:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:43:43 --> CSRF cookie sent
INFO - 2018-10-22 13:43:43 --> CSRF token verified
INFO - 2018-10-22 13:43:43 --> Input Class Initialized
INFO - 2018-10-22 13:43:43 --> Language Class Initialized
INFO - 2018-10-22 13:43:43 --> Loader Class Initialized
INFO - 2018-10-22 13:43:43 --> Helper loaded: url_helper
INFO - 2018-10-22 13:43:43 --> Helper loaded: form_helper
INFO - 2018-10-22 13:43:43 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:43:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:43:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:43:43 --> User Agent Class Initialized
INFO - 2018-10-22 13:43:43 --> Controller Class Initialized
INFO - 2018-10-22 13:43:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:43:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:43:43 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:43:43 --> Pixel_Model class loaded
INFO - 2018-10-22 13:43:43 --> Database Driver Class Initialized
INFO - 2018-10-22 13:43:43 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:43:43 --> Form Validation Class Initialized
INFO - 2018-10-22 13:43:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:43:43 --> Database Driver Class Initialized
INFO - 2018-10-22 13:43:43 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:43:43 --> Config Class Initialized
INFO - 2018-10-22 13:43:43 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:43:43 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:43:43 --> Utf8 Class Initialized
INFO - 2018-10-22 13:43:43 --> URI Class Initialized
INFO - 2018-10-22 13:43:43 --> Router Class Initialized
INFO - 2018-10-22 13:43:43 --> Output Class Initialized
INFO - 2018-10-22 13:43:43 --> Security Class Initialized
DEBUG - 2018-10-22 13:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:43:43 --> CSRF cookie sent
INFO - 2018-10-22 13:43:43 --> Input Class Initialized
INFO - 2018-10-22 13:43:43 --> Language Class Initialized
INFO - 2018-10-22 13:43:43 --> Loader Class Initialized
INFO - 2018-10-22 13:43:43 --> Helper loaded: url_helper
INFO - 2018-10-22 13:43:43 --> Helper loaded: form_helper
INFO - 2018-10-22 13:43:43 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:43:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:43:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:43:43 --> User Agent Class Initialized
INFO - 2018-10-22 13:43:43 --> Controller Class Initialized
INFO - 2018-10-22 13:43:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:43:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:43:43 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:43:43 --> Pixel_Model class loaded
INFO - 2018-10-22 13:43:43 --> Database Driver Class Initialized
INFO - 2018-10-22 13:43:43 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:43:43 --> Database Driver Class Initialized
INFO - 2018-10-22 13:43:43 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:43:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:43:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:43:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:43:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:43:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:43:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:43:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/home_title.php
INFO - 2018-10-22 13:43:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:43:43 --> Final output sent to browser
DEBUG - 2018-10-22 13:43:43 --> Total execution time: 0.4815
INFO - 2018-10-22 13:43:57 --> Config Class Initialized
INFO - 2018-10-22 13:43:57 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:43:57 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:43:57 --> Utf8 Class Initialized
INFO - 2018-10-22 13:43:57 --> URI Class Initialized
INFO - 2018-10-22 13:43:57 --> Router Class Initialized
INFO - 2018-10-22 13:43:57 --> Output Class Initialized
INFO - 2018-10-22 13:43:57 --> Security Class Initialized
DEBUG - 2018-10-22 13:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:43:57 --> CSRF cookie sent
INFO - 2018-10-22 13:43:57 --> Input Class Initialized
INFO - 2018-10-22 13:43:57 --> Language Class Initialized
INFO - 2018-10-22 13:43:57 --> Loader Class Initialized
INFO - 2018-10-22 13:43:57 --> Helper loaded: url_helper
INFO - 2018-10-22 13:43:57 --> Helper loaded: form_helper
INFO - 2018-10-22 13:43:57 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:43:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:43:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:43:57 --> User Agent Class Initialized
INFO - 2018-10-22 13:43:57 --> Controller Class Initialized
INFO - 2018-10-22 13:43:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:43:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:43:57 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:43:57 --> Pixel_Model class loaded
INFO - 2018-10-22 13:43:57 --> Database Driver Class Initialized
INFO - 2018-10-22 13:43:57 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:43:57 --> Database Driver Class Initialized
INFO - 2018-10-22 13:43:57 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:43:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:43:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:43:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:43:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:43:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:43:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:43:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/inheritance.php
INFO - 2018-10-22 13:43:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:43:58 --> Final output sent to browser
DEBUG - 2018-10-22 13:43:58 --> Total execution time: 0.4804
INFO - 2018-10-22 13:44:01 --> Config Class Initialized
INFO - 2018-10-22 13:44:01 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:44:01 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:44:01 --> Utf8 Class Initialized
INFO - 2018-10-22 13:44:01 --> URI Class Initialized
INFO - 2018-10-22 13:44:01 --> Router Class Initialized
INFO - 2018-10-22 13:44:01 --> Output Class Initialized
INFO - 2018-10-22 13:44:01 --> Security Class Initialized
DEBUG - 2018-10-22 13:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:44:01 --> CSRF cookie sent
INFO - 2018-10-22 13:44:01 --> Input Class Initialized
INFO - 2018-10-22 13:44:01 --> Language Class Initialized
INFO - 2018-10-22 13:44:01 --> Loader Class Initialized
INFO - 2018-10-22 13:44:01 --> Helper loaded: url_helper
INFO - 2018-10-22 13:44:01 --> Helper loaded: form_helper
INFO - 2018-10-22 13:44:01 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:44:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:44:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:44:01 --> User Agent Class Initialized
INFO - 2018-10-22 13:44:01 --> Controller Class Initialized
INFO - 2018-10-22 13:44:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:44:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:44:01 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:44:02 --> Pixel_Model class loaded
INFO - 2018-10-22 13:44:02 --> Database Driver Class Initialized
INFO - 2018-10-22 13:44:02 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:44:02 --> Database Driver Class Initialized
INFO - 2018-10-22 13:44:02 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:44:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:44:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:44:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:44:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:44:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:44:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:44:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/home_title.php
INFO - 2018-10-22 13:44:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:44:02 --> Final output sent to browser
DEBUG - 2018-10-22 13:44:02 --> Total execution time: 0.4823
INFO - 2018-10-22 13:44:07 --> Config Class Initialized
INFO - 2018-10-22 13:44:07 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:44:07 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:44:07 --> Utf8 Class Initialized
INFO - 2018-10-22 13:44:07 --> URI Class Initialized
INFO - 2018-10-22 13:44:07 --> Router Class Initialized
INFO - 2018-10-22 13:44:07 --> Output Class Initialized
INFO - 2018-10-22 13:44:07 --> Security Class Initialized
DEBUG - 2018-10-22 13:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:44:07 --> CSRF cookie sent
INFO - 2018-10-22 13:44:07 --> Input Class Initialized
INFO - 2018-10-22 13:44:07 --> Language Class Initialized
INFO - 2018-10-22 13:44:07 --> Loader Class Initialized
INFO - 2018-10-22 13:44:07 --> Helper loaded: url_helper
INFO - 2018-10-22 13:44:07 --> Helper loaded: form_helper
INFO - 2018-10-22 13:44:07 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:44:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:44:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:44:07 --> User Agent Class Initialized
INFO - 2018-10-22 13:44:07 --> Controller Class Initialized
INFO - 2018-10-22 13:44:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:44:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:44:07 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:44:07 --> Pixel_Model class loaded
INFO - 2018-10-22 13:44:07 --> Database Driver Class Initialized
INFO - 2018-10-22 13:44:07 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:44:07 --> Database Driver Class Initialized
INFO - 2018-10-22 13:44:07 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:44:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:44:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:44:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:44:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:44:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:44:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:44:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/pension.php
INFO - 2018-10-22 13:44:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:44:07 --> Final output sent to browser
DEBUG - 2018-10-22 13:44:07 --> Total execution time: 0.5054
INFO - 2018-10-22 13:46:31 --> Config Class Initialized
INFO - 2018-10-22 13:46:31 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:46:31 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:46:31 --> Utf8 Class Initialized
INFO - 2018-10-22 13:46:31 --> URI Class Initialized
INFO - 2018-10-22 13:46:31 --> Router Class Initialized
INFO - 2018-10-22 13:46:31 --> Output Class Initialized
INFO - 2018-10-22 13:46:31 --> Security Class Initialized
DEBUG - 2018-10-22 13:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:46:32 --> CSRF cookie sent
INFO - 2018-10-22 13:46:32 --> Input Class Initialized
INFO - 2018-10-22 13:46:32 --> Language Class Initialized
INFO - 2018-10-22 13:46:32 --> Loader Class Initialized
INFO - 2018-10-22 13:46:32 --> Helper loaded: url_helper
INFO - 2018-10-22 13:46:32 --> Helper loaded: form_helper
INFO - 2018-10-22 13:46:32 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:46:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:46:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:46:32 --> User Agent Class Initialized
INFO - 2018-10-22 13:46:32 --> Controller Class Initialized
INFO - 2018-10-22 13:46:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:46:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:46:32 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:46:32 --> Pixel_Model class loaded
INFO - 2018-10-22 13:46:32 --> Database Driver Class Initialized
INFO - 2018-10-22 13:46:32 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:46:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:46:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:46:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:46:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:46:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:46:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:46:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-22 13:46:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:46:32 --> Final output sent to browser
DEBUG - 2018-10-22 13:46:32 --> Total execution time: 0.4729
INFO - 2018-10-22 13:46:33 --> Config Class Initialized
INFO - 2018-10-22 13:46:33 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:46:33 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:46:33 --> Utf8 Class Initialized
INFO - 2018-10-22 13:46:33 --> URI Class Initialized
INFO - 2018-10-22 13:46:33 --> Router Class Initialized
INFO - 2018-10-22 13:46:33 --> Output Class Initialized
INFO - 2018-10-22 13:46:33 --> Security Class Initialized
DEBUG - 2018-10-22 13:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:46:33 --> CSRF cookie sent
INFO - 2018-10-22 13:46:33 --> Input Class Initialized
INFO - 2018-10-22 13:46:33 --> Language Class Initialized
INFO - 2018-10-22 13:46:33 --> Loader Class Initialized
INFO - 2018-10-22 13:46:33 --> Helper loaded: url_helper
INFO - 2018-10-22 13:46:33 --> Helper loaded: form_helper
INFO - 2018-10-22 13:46:33 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:46:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:46:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:46:33 --> User Agent Class Initialized
INFO - 2018-10-22 13:46:33 --> Controller Class Initialized
INFO - 2018-10-22 13:46:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:46:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:46:33 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:46:33 --> Pixel_Model class loaded
INFO - 2018-10-22 13:46:33 --> Database Driver Class Initialized
INFO - 2018-10-22 13:46:33 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:46:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:46:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:46:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:46:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:46:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:46:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:46:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-22 13:46:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:46:33 --> Final output sent to browser
DEBUG - 2018-10-22 13:46:33 --> Total execution time: 0.4565
INFO - 2018-10-22 13:46:35 --> Config Class Initialized
INFO - 2018-10-22 13:46:35 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:46:35 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:46:35 --> Utf8 Class Initialized
INFO - 2018-10-22 13:46:35 --> URI Class Initialized
INFO - 2018-10-22 13:46:35 --> Router Class Initialized
INFO - 2018-10-22 13:46:35 --> Output Class Initialized
INFO - 2018-10-22 13:46:35 --> Security Class Initialized
DEBUG - 2018-10-22 13:46:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:46:35 --> CSRF cookie sent
INFO - 2018-10-22 13:46:35 --> CSRF token verified
INFO - 2018-10-22 13:46:35 --> Input Class Initialized
INFO - 2018-10-22 13:46:35 --> Language Class Initialized
INFO - 2018-10-22 13:46:36 --> Loader Class Initialized
INFO - 2018-10-22 13:46:36 --> Helper loaded: url_helper
INFO - 2018-10-22 13:46:36 --> Helper loaded: form_helper
INFO - 2018-10-22 13:46:36 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:46:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:46:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:46:36 --> User Agent Class Initialized
INFO - 2018-10-22 13:46:36 --> Controller Class Initialized
INFO - 2018-10-22 13:46:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:46:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:46:36 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:46:36 --> Pixel_Model class loaded
INFO - 2018-10-22 13:46:36 --> Database Driver Class Initialized
INFO - 2018-10-22 13:46:36 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:46:36 --> Form Validation Class Initialized
INFO - 2018-10-22 13:46:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:46:36 --> Database Driver Class Initialized
INFO - 2018-10-22 13:46:36 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:46:36 --> Config Class Initialized
INFO - 2018-10-22 13:46:36 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:46:36 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:46:36 --> Utf8 Class Initialized
INFO - 2018-10-22 13:46:36 --> URI Class Initialized
INFO - 2018-10-22 13:46:36 --> Router Class Initialized
INFO - 2018-10-22 13:46:36 --> Output Class Initialized
INFO - 2018-10-22 13:46:36 --> Security Class Initialized
DEBUG - 2018-10-22 13:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:46:36 --> CSRF cookie sent
INFO - 2018-10-22 13:46:36 --> Input Class Initialized
INFO - 2018-10-22 13:46:36 --> Language Class Initialized
INFO - 2018-10-22 13:46:36 --> Loader Class Initialized
INFO - 2018-10-22 13:46:36 --> Helper loaded: url_helper
INFO - 2018-10-22 13:46:36 --> Helper loaded: form_helper
INFO - 2018-10-22 13:46:36 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:46:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:46:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:46:36 --> User Agent Class Initialized
INFO - 2018-10-22 13:46:36 --> Controller Class Initialized
INFO - 2018-10-22 13:46:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:46:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:46:36 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:46:36 --> Pixel_Model class loaded
INFO - 2018-10-22 13:46:36 --> Database Driver Class Initialized
INFO - 2018-10-22 13:46:36 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:46:36 --> Database Driver Class Initialized
INFO - 2018-10-22 13:46:36 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:46:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:46:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:46:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:46:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:46:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:46:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:46:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-22 13:46:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:46:36 --> Final output sent to browser
DEBUG - 2018-10-22 13:46:36 --> Total execution time: 0.4694
INFO - 2018-10-22 13:46:44 --> Config Class Initialized
INFO - 2018-10-22 13:46:44 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:46:44 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:46:44 --> Utf8 Class Initialized
INFO - 2018-10-22 13:46:44 --> URI Class Initialized
INFO - 2018-10-22 13:46:44 --> Router Class Initialized
INFO - 2018-10-22 13:46:44 --> Output Class Initialized
INFO - 2018-10-22 13:46:44 --> Security Class Initialized
DEBUG - 2018-10-22 13:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:46:44 --> CSRF cookie sent
INFO - 2018-10-22 13:46:44 --> CSRF token verified
INFO - 2018-10-22 13:46:44 --> Input Class Initialized
INFO - 2018-10-22 13:46:44 --> Language Class Initialized
INFO - 2018-10-22 13:46:44 --> Loader Class Initialized
INFO - 2018-10-22 13:46:44 --> Helper loaded: url_helper
INFO - 2018-10-22 13:46:44 --> Helper loaded: form_helper
INFO - 2018-10-22 13:46:44 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:46:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:46:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:46:44 --> User Agent Class Initialized
INFO - 2018-10-22 13:46:44 --> Controller Class Initialized
INFO - 2018-10-22 13:46:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:46:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:46:44 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:46:44 --> Pixel_Model class loaded
INFO - 2018-10-22 13:46:44 --> Database Driver Class Initialized
INFO - 2018-10-22 13:46:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:46:44 --> Form Validation Class Initialized
INFO - 2018-10-22 13:46:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:46:44 --> Database Driver Class Initialized
INFO - 2018-10-22 13:46:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:46:44 --> Config Class Initialized
INFO - 2018-10-22 13:46:44 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:46:44 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:46:44 --> Utf8 Class Initialized
INFO - 2018-10-22 13:46:44 --> URI Class Initialized
INFO - 2018-10-22 13:46:44 --> Router Class Initialized
INFO - 2018-10-22 13:46:44 --> Output Class Initialized
INFO - 2018-10-22 13:46:44 --> Security Class Initialized
DEBUG - 2018-10-22 13:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:46:44 --> CSRF cookie sent
INFO - 2018-10-22 13:46:44 --> Input Class Initialized
INFO - 2018-10-22 13:46:44 --> Language Class Initialized
INFO - 2018-10-22 13:46:44 --> Loader Class Initialized
INFO - 2018-10-22 13:46:44 --> Helper loaded: url_helper
INFO - 2018-10-22 13:46:44 --> Helper loaded: form_helper
INFO - 2018-10-22 13:46:44 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:46:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:46:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:46:44 --> User Agent Class Initialized
INFO - 2018-10-22 13:46:44 --> Controller Class Initialized
INFO - 2018-10-22 13:46:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:46:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:46:44 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:46:44 --> Pixel_Model class loaded
INFO - 2018-10-22 13:46:44 --> Database Driver Class Initialized
INFO - 2018-10-22 13:46:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:46:44 --> Database Driver Class Initialized
INFO - 2018-10-22 13:46:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:46:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:46:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:46:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:46:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:46:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:46:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:46:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/your_job.php
INFO - 2018-10-22 13:46:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:46:45 --> Final output sent to browser
DEBUG - 2018-10-22 13:46:45 --> Total execution time: 0.4946
INFO - 2018-10-22 13:46:46 --> Config Class Initialized
INFO - 2018-10-22 13:46:46 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:46:46 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:46:46 --> Utf8 Class Initialized
INFO - 2018-10-22 13:46:46 --> URI Class Initialized
INFO - 2018-10-22 13:46:46 --> Router Class Initialized
INFO - 2018-10-22 13:46:46 --> Output Class Initialized
INFO - 2018-10-22 13:46:46 --> Security Class Initialized
DEBUG - 2018-10-22 13:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:46:46 --> CSRF cookie sent
INFO - 2018-10-22 13:46:46 --> CSRF token verified
INFO - 2018-10-22 13:46:46 --> Input Class Initialized
INFO - 2018-10-22 13:46:46 --> Language Class Initialized
INFO - 2018-10-22 13:46:47 --> Loader Class Initialized
INFO - 2018-10-22 13:46:47 --> Helper loaded: url_helper
INFO - 2018-10-22 13:46:47 --> Helper loaded: form_helper
INFO - 2018-10-22 13:46:47 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:46:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:46:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:46:47 --> User Agent Class Initialized
INFO - 2018-10-22 13:46:47 --> Controller Class Initialized
INFO - 2018-10-22 13:46:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:46:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:46:47 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:46:47 --> Pixel_Model class loaded
INFO - 2018-10-22 13:46:47 --> Database Driver Class Initialized
INFO - 2018-10-22 13:46:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:46:47 --> Form Validation Class Initialized
INFO - 2018-10-22 13:46:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:46:47 --> Database Driver Class Initialized
INFO - 2018-10-22 13:46:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:46:47 --> Config Class Initialized
INFO - 2018-10-22 13:46:47 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:46:47 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:46:47 --> Utf8 Class Initialized
INFO - 2018-10-22 13:46:47 --> URI Class Initialized
INFO - 2018-10-22 13:46:47 --> Router Class Initialized
INFO - 2018-10-22 13:46:47 --> Output Class Initialized
INFO - 2018-10-22 13:46:47 --> Security Class Initialized
DEBUG - 2018-10-22 13:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:46:47 --> CSRF cookie sent
INFO - 2018-10-22 13:46:47 --> Input Class Initialized
INFO - 2018-10-22 13:46:47 --> Language Class Initialized
INFO - 2018-10-22 13:46:47 --> Loader Class Initialized
INFO - 2018-10-22 13:46:47 --> Helper loaded: url_helper
INFO - 2018-10-22 13:46:47 --> Helper loaded: form_helper
INFO - 2018-10-22 13:46:47 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:46:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:46:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:46:47 --> User Agent Class Initialized
INFO - 2018-10-22 13:46:47 --> Controller Class Initialized
INFO - 2018-10-22 13:46:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:46:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:46:47 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:46:47 --> Pixel_Model class loaded
INFO - 2018-10-22 13:46:47 --> Database Driver Class Initialized
INFO - 2018-10-22 13:46:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:46:47 --> Database Driver Class Initialized
INFO - 2018-10-22 13:46:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:46:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:46:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:46:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner.php
INFO - 2018-10-22 13:46:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:46:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:46:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:46:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:46:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/relation_ship_status.php
INFO - 2018-10-22 13:46:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:46:47 --> Final output sent to browser
DEBUG - 2018-10-22 13:46:47 --> Total execution time: 0.4801
INFO - 2018-10-22 13:46:50 --> Config Class Initialized
INFO - 2018-10-22 13:46:51 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:46:51 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:46:51 --> Utf8 Class Initialized
INFO - 2018-10-22 13:46:51 --> URI Class Initialized
INFO - 2018-10-22 13:46:51 --> Router Class Initialized
INFO - 2018-10-22 13:46:51 --> Output Class Initialized
INFO - 2018-10-22 13:46:51 --> Security Class Initialized
DEBUG - 2018-10-22 13:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:46:51 --> CSRF cookie sent
INFO - 2018-10-22 13:46:51 --> CSRF token verified
INFO - 2018-10-22 13:46:51 --> Input Class Initialized
INFO - 2018-10-22 13:46:51 --> Language Class Initialized
INFO - 2018-10-22 13:46:51 --> Loader Class Initialized
INFO - 2018-10-22 13:46:51 --> Helper loaded: url_helper
INFO - 2018-10-22 13:46:51 --> Helper loaded: form_helper
INFO - 2018-10-22 13:46:51 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:46:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:46:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:46:51 --> User Agent Class Initialized
INFO - 2018-10-22 13:46:51 --> Controller Class Initialized
INFO - 2018-10-22 13:46:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:46:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:46:51 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:46:51 --> Pixel_Model class loaded
INFO - 2018-10-22 13:46:51 --> Database Driver Class Initialized
INFO - 2018-10-22 13:46:51 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:46:51 --> Form Validation Class Initialized
INFO - 2018-10-22 13:46:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:46:51 --> Database Driver Class Initialized
INFO - 2018-10-22 13:46:51 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:46:51 --> Config Class Initialized
INFO - 2018-10-22 13:46:51 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:46:51 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:46:51 --> Utf8 Class Initialized
INFO - 2018-10-22 13:46:51 --> URI Class Initialized
INFO - 2018-10-22 13:46:51 --> Router Class Initialized
INFO - 2018-10-22 13:46:51 --> Output Class Initialized
INFO - 2018-10-22 13:46:51 --> Security Class Initialized
DEBUG - 2018-10-22 13:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:46:51 --> CSRF cookie sent
INFO - 2018-10-22 13:46:51 --> Input Class Initialized
INFO - 2018-10-22 13:46:51 --> Language Class Initialized
INFO - 2018-10-22 13:46:51 --> Loader Class Initialized
INFO - 2018-10-22 13:46:51 --> Helper loaded: url_helper
INFO - 2018-10-22 13:46:51 --> Helper loaded: form_helper
INFO - 2018-10-22 13:46:51 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:46:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:46:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:46:51 --> User Agent Class Initialized
INFO - 2018-10-22 13:46:51 --> Controller Class Initialized
INFO - 2018-10-22 13:46:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:46:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:46:51 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:46:51 --> Pixel_Model class loaded
INFO - 2018-10-22 13:46:51 --> Database Driver Class Initialized
INFO - 2018-10-22 13:46:51 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:46:51 --> Database Driver Class Initialized
INFO - 2018-10-22 13:46:51 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:46:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:46:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:46:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:46:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:46:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:46:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:46:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/income.php
INFO - 2018-10-22 13:46:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:46:51 --> Final output sent to browser
DEBUG - 2018-10-22 13:46:51 --> Total execution time: 0.4791
INFO - 2018-10-22 13:47:01 --> Config Class Initialized
INFO - 2018-10-22 13:47:02 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:47:02 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:47:02 --> Utf8 Class Initialized
INFO - 2018-10-22 13:47:02 --> URI Class Initialized
INFO - 2018-10-22 13:47:02 --> Router Class Initialized
INFO - 2018-10-22 13:47:02 --> Output Class Initialized
INFO - 2018-10-22 13:47:02 --> Security Class Initialized
DEBUG - 2018-10-22 13:47:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:47:02 --> CSRF cookie sent
INFO - 2018-10-22 13:47:02 --> CSRF token verified
INFO - 2018-10-22 13:47:02 --> Input Class Initialized
INFO - 2018-10-22 13:47:02 --> Language Class Initialized
INFO - 2018-10-22 13:47:02 --> Loader Class Initialized
INFO - 2018-10-22 13:47:02 --> Helper loaded: url_helper
INFO - 2018-10-22 13:47:02 --> Helper loaded: form_helper
INFO - 2018-10-22 13:47:02 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:47:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:47:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:47:02 --> User Agent Class Initialized
INFO - 2018-10-22 13:47:02 --> Controller Class Initialized
INFO - 2018-10-22 13:47:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:47:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:47:02 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:47:02 --> Pixel_Model class loaded
INFO - 2018-10-22 13:47:02 --> Database Driver Class Initialized
INFO - 2018-10-22 13:47:02 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:47:02 --> Form Validation Class Initialized
INFO - 2018-10-22 13:47:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:47:02 --> Database Driver Class Initialized
INFO - 2018-10-22 13:47:02 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:47:02 --> Config Class Initialized
INFO - 2018-10-22 13:47:02 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:47:02 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:47:02 --> Utf8 Class Initialized
INFO - 2018-10-22 13:47:02 --> URI Class Initialized
INFO - 2018-10-22 13:47:02 --> Router Class Initialized
INFO - 2018-10-22 13:47:02 --> Output Class Initialized
INFO - 2018-10-22 13:47:02 --> Security Class Initialized
DEBUG - 2018-10-22 13:47:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:47:02 --> CSRF cookie sent
INFO - 2018-10-22 13:47:02 --> Input Class Initialized
INFO - 2018-10-22 13:47:02 --> Language Class Initialized
INFO - 2018-10-22 13:47:02 --> Loader Class Initialized
INFO - 2018-10-22 13:47:02 --> Helper loaded: url_helper
INFO - 2018-10-22 13:47:02 --> Helper loaded: form_helper
INFO - 2018-10-22 13:47:02 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:47:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:47:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:47:02 --> User Agent Class Initialized
INFO - 2018-10-22 13:47:02 --> Controller Class Initialized
INFO - 2018-10-22 13:47:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:47:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:47:02 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:47:02 --> Pixel_Model class loaded
INFO - 2018-10-22 13:47:02 --> Database Driver Class Initialized
INFO - 2018-10-22 13:47:02 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:47:02 --> Database Driver Class Initialized
INFO - 2018-10-22 13:47:02 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:47:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:47:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:47:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:47:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:47:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:47:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:47:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/pension.php
INFO - 2018-10-22 13:47:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:47:02 --> Final output sent to browser
DEBUG - 2018-10-22 13:47:03 --> Total execution time: 0.4832
INFO - 2018-10-22 13:47:04 --> Config Class Initialized
INFO - 2018-10-22 13:47:04 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:47:04 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:47:04 --> Utf8 Class Initialized
INFO - 2018-10-22 13:47:04 --> URI Class Initialized
INFO - 2018-10-22 13:47:04 --> Router Class Initialized
INFO - 2018-10-22 13:47:05 --> Output Class Initialized
INFO - 2018-10-22 13:47:05 --> Security Class Initialized
DEBUG - 2018-10-22 13:47:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:47:05 --> CSRF cookie sent
INFO - 2018-10-22 13:47:05 --> CSRF token verified
INFO - 2018-10-22 13:47:05 --> Input Class Initialized
INFO - 2018-10-22 13:47:05 --> Language Class Initialized
INFO - 2018-10-22 13:47:05 --> Loader Class Initialized
INFO - 2018-10-22 13:47:05 --> Helper loaded: url_helper
INFO - 2018-10-22 13:47:05 --> Helper loaded: form_helper
INFO - 2018-10-22 13:47:05 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:47:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:47:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:47:05 --> User Agent Class Initialized
INFO - 2018-10-22 13:47:05 --> Controller Class Initialized
INFO - 2018-10-22 13:47:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:47:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:47:05 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:47:05 --> Pixel_Model class loaded
INFO - 2018-10-22 13:47:05 --> Database Driver Class Initialized
INFO - 2018-10-22 13:47:05 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:47:05 --> Form Validation Class Initialized
INFO - 2018-10-22 13:47:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:47:05 --> Database Driver Class Initialized
INFO - 2018-10-22 13:47:05 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:47:05 --> Config Class Initialized
INFO - 2018-10-22 13:47:05 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:47:05 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:47:05 --> Utf8 Class Initialized
INFO - 2018-10-22 13:47:05 --> URI Class Initialized
INFO - 2018-10-22 13:47:05 --> Router Class Initialized
INFO - 2018-10-22 13:47:05 --> Output Class Initialized
INFO - 2018-10-22 13:47:05 --> Security Class Initialized
DEBUG - 2018-10-22 13:47:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:47:05 --> CSRF cookie sent
INFO - 2018-10-22 13:47:05 --> Input Class Initialized
INFO - 2018-10-22 13:47:05 --> Language Class Initialized
INFO - 2018-10-22 13:47:05 --> Loader Class Initialized
INFO - 2018-10-22 13:47:05 --> Helper loaded: url_helper
INFO - 2018-10-22 13:47:05 --> Helper loaded: form_helper
INFO - 2018-10-22 13:47:05 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:47:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:47:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:47:05 --> User Agent Class Initialized
INFO - 2018-10-22 13:47:05 --> Controller Class Initialized
INFO - 2018-10-22 13:47:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:47:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:47:05 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:47:05 --> Pixel_Model class loaded
INFO - 2018-10-22 13:47:05 --> Database Driver Class Initialized
INFO - 2018-10-22 13:47:05 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:47:05 --> Database Driver Class Initialized
INFO - 2018-10-22 13:47:05 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:47:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:47:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:47:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:47:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:47:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:47:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:47:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/home_title.php
INFO - 2018-10-22 13:47:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:47:05 --> Final output sent to browser
DEBUG - 2018-10-22 13:47:05 --> Total execution time: 0.5004
INFO - 2018-10-22 13:47:11 --> Config Class Initialized
INFO - 2018-10-22 13:47:11 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:47:11 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:47:11 --> Utf8 Class Initialized
INFO - 2018-10-22 13:47:11 --> URI Class Initialized
INFO - 2018-10-22 13:47:11 --> Router Class Initialized
INFO - 2018-10-22 13:47:11 --> Output Class Initialized
INFO - 2018-10-22 13:47:11 --> Security Class Initialized
DEBUG - 2018-10-22 13:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:47:11 --> CSRF cookie sent
INFO - 2018-10-22 13:47:11 --> CSRF token verified
INFO - 2018-10-22 13:47:11 --> Input Class Initialized
INFO - 2018-10-22 13:47:11 --> Language Class Initialized
INFO - 2018-10-22 13:47:11 --> Loader Class Initialized
INFO - 2018-10-22 13:47:11 --> Helper loaded: url_helper
INFO - 2018-10-22 13:47:12 --> Helper loaded: form_helper
INFO - 2018-10-22 13:47:12 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:47:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:47:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:47:12 --> User Agent Class Initialized
INFO - 2018-10-22 13:47:12 --> Controller Class Initialized
INFO - 2018-10-22 13:47:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:47:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:47:12 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:47:12 --> Pixel_Model class loaded
INFO - 2018-10-22 13:47:12 --> Database Driver Class Initialized
INFO - 2018-10-22 13:47:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:47:12 --> Form Validation Class Initialized
INFO - 2018-10-22 13:47:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:47:12 --> Database Driver Class Initialized
INFO - 2018-10-22 13:47:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:47:12 --> Config Class Initialized
INFO - 2018-10-22 13:47:12 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:47:12 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:47:12 --> Utf8 Class Initialized
INFO - 2018-10-22 13:47:12 --> URI Class Initialized
INFO - 2018-10-22 13:47:12 --> Router Class Initialized
INFO - 2018-10-22 13:47:12 --> Output Class Initialized
INFO - 2018-10-22 13:47:12 --> Security Class Initialized
DEBUG - 2018-10-22 13:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:47:12 --> CSRF cookie sent
INFO - 2018-10-22 13:47:12 --> Input Class Initialized
INFO - 2018-10-22 13:47:12 --> Language Class Initialized
INFO - 2018-10-22 13:47:12 --> Loader Class Initialized
INFO - 2018-10-22 13:47:12 --> Helper loaded: url_helper
INFO - 2018-10-22 13:47:12 --> Helper loaded: form_helper
INFO - 2018-10-22 13:47:12 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:47:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:47:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:47:12 --> User Agent Class Initialized
INFO - 2018-10-22 13:47:12 --> Controller Class Initialized
INFO - 2018-10-22 13:47:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:47:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:47:12 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:47:12 --> Pixel_Model class loaded
INFO - 2018-10-22 13:47:12 --> Database Driver Class Initialized
INFO - 2018-10-22 13:47:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:47:12 --> Database Driver Class Initialized
INFO - 2018-10-22 13:47:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:47:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:47:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:47:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:47:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:47:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:47:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:47:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/financial.php
INFO - 2018-10-22 13:47:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:47:12 --> Final output sent to browser
DEBUG - 2018-10-22 13:47:12 --> Total execution time: 0.4890
INFO - 2018-10-22 13:47:16 --> Config Class Initialized
INFO - 2018-10-22 13:47:16 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:47:16 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:47:16 --> Utf8 Class Initialized
INFO - 2018-10-22 13:47:16 --> URI Class Initialized
INFO - 2018-10-22 13:47:16 --> Router Class Initialized
INFO - 2018-10-22 13:47:16 --> Output Class Initialized
INFO - 2018-10-22 13:47:16 --> Security Class Initialized
DEBUG - 2018-10-22 13:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:47:16 --> CSRF cookie sent
INFO - 2018-10-22 13:47:16 --> CSRF token verified
INFO - 2018-10-22 13:47:16 --> Input Class Initialized
INFO - 2018-10-22 13:47:16 --> Language Class Initialized
INFO - 2018-10-22 13:47:16 --> Loader Class Initialized
INFO - 2018-10-22 13:47:16 --> Helper loaded: url_helper
INFO - 2018-10-22 13:47:16 --> Helper loaded: form_helper
INFO - 2018-10-22 13:47:16 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:47:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:47:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:47:16 --> User Agent Class Initialized
INFO - 2018-10-22 13:47:16 --> Controller Class Initialized
INFO - 2018-10-22 13:47:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:47:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:47:16 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:47:16 --> Pixel_Model class loaded
INFO - 2018-10-22 13:47:16 --> Database Driver Class Initialized
INFO - 2018-10-22 13:47:16 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:47:16 --> Form Validation Class Initialized
INFO - 2018-10-22 13:47:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:47:16 --> Database Driver Class Initialized
INFO - 2018-10-22 13:47:16 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:47:16 --> Config Class Initialized
INFO - 2018-10-22 13:47:16 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:47:16 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:47:16 --> Utf8 Class Initialized
INFO - 2018-10-22 13:47:16 --> URI Class Initialized
INFO - 2018-10-22 13:47:16 --> Router Class Initialized
INFO - 2018-10-22 13:47:16 --> Output Class Initialized
INFO - 2018-10-22 13:47:16 --> Security Class Initialized
DEBUG - 2018-10-22 13:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:47:16 --> CSRF cookie sent
INFO - 2018-10-22 13:47:16 --> Input Class Initialized
INFO - 2018-10-22 13:47:16 --> Language Class Initialized
INFO - 2018-10-22 13:47:16 --> Loader Class Initialized
INFO - 2018-10-22 13:47:16 --> Helper loaded: url_helper
INFO - 2018-10-22 13:47:16 --> Helper loaded: form_helper
INFO - 2018-10-22 13:47:16 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:47:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:47:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:47:16 --> User Agent Class Initialized
INFO - 2018-10-22 13:47:16 --> Controller Class Initialized
INFO - 2018-10-22 13:47:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:47:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:47:17 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:47:17 --> Pixel_Model class loaded
INFO - 2018-10-22 13:47:17 --> Database Driver Class Initialized
INFO - 2018-10-22 13:47:17 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:47:17 --> Database Driver Class Initialized
INFO - 2018-10-22 13:47:17 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:47:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:47:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:47:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:47:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:47:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/risk_report.php
INFO - 2018-10-22 13:47:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:47:17 --> Final output sent to browser
DEBUG - 2018-10-22 13:47:17 --> Total execution time: 0.4867
INFO - 2018-10-22 13:47:23 --> Config Class Initialized
INFO - 2018-10-22 13:47:23 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:47:23 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:47:23 --> Utf8 Class Initialized
INFO - 2018-10-22 13:47:23 --> URI Class Initialized
INFO - 2018-10-22 13:47:23 --> Router Class Initialized
INFO - 2018-10-22 13:47:23 --> Output Class Initialized
INFO - 2018-10-22 13:47:23 --> Security Class Initialized
DEBUG - 2018-10-22 13:47:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:47:23 --> CSRF cookie sent
INFO - 2018-10-22 13:47:23 --> Input Class Initialized
INFO - 2018-10-22 13:47:23 --> Language Class Initialized
INFO - 2018-10-22 13:47:23 --> Loader Class Initialized
INFO - 2018-10-22 13:47:23 --> Helper loaded: url_helper
INFO - 2018-10-22 13:47:23 --> Helper loaded: form_helper
INFO - 2018-10-22 13:47:23 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:47:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:47:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:47:23 --> User Agent Class Initialized
INFO - 2018-10-22 13:47:23 --> Controller Class Initialized
INFO - 2018-10-22 13:47:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:47:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:47:23 --> Helper loaded: custom_helper
DEBUG - 2018-10-22 13:47:23 --> Config file loaded: E:\xampp7\htdocs\famiquity\application\config/recaptcha.php
INFO - 2018-10-22 13:47:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:47:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:47:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:47:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
ERROR - 2018-10-22 13:47:23 --> Could not find the language line "req_email"
INFO - 2018-10-22 13:47:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\myaccount/signin.php
INFO - 2018-10-22 13:47:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:47:23 --> Final output sent to browser
DEBUG - 2018-10-22 13:47:23 --> Total execution time: 0.4352
INFO - 2018-10-22 13:48:21 --> Config Class Initialized
INFO - 2018-10-22 13:48:21 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:48:21 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:48:21 --> Utf8 Class Initialized
INFO - 2018-10-22 13:48:21 --> URI Class Initialized
INFO - 2018-10-22 13:48:21 --> Router Class Initialized
INFO - 2018-10-22 13:48:21 --> Output Class Initialized
INFO - 2018-10-22 13:48:21 --> Security Class Initialized
DEBUG - 2018-10-22 13:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:48:21 --> CSRF cookie sent
INFO - 2018-10-22 13:48:21 --> Input Class Initialized
INFO - 2018-10-22 13:48:21 --> Language Class Initialized
INFO - 2018-10-22 13:48:21 --> Loader Class Initialized
INFO - 2018-10-22 13:48:21 --> Helper loaded: url_helper
INFO - 2018-10-22 13:48:21 --> Helper loaded: form_helper
INFO - 2018-10-22 13:48:21 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:48:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:48:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:48:21 --> User Agent Class Initialized
INFO - 2018-10-22 13:48:21 --> Controller Class Initialized
INFO - 2018-10-22 13:48:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:48:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:48:21 --> Helper loaded: custom_helper
DEBUG - 2018-10-22 13:48:22 --> Config file loaded: E:\xampp7\htdocs\famiquity\application\config/recaptcha.php
INFO - 2018-10-22 13:48:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:48:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:48:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:48:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
ERROR - 2018-10-22 13:48:22 --> Could not find the language line "req_email"
INFO - 2018-10-22 13:48:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\myaccount/signin.php
INFO - 2018-10-22 13:48:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:48:22 --> Final output sent to browser
DEBUG - 2018-10-22 13:48:22 --> Total execution time: 0.4181
INFO - 2018-10-22 13:48:26 --> Config Class Initialized
INFO - 2018-10-22 13:48:26 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:48:26 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:48:26 --> Utf8 Class Initialized
INFO - 2018-10-22 13:48:26 --> URI Class Initialized
INFO - 2018-10-22 13:48:26 --> Router Class Initialized
INFO - 2018-10-22 13:48:26 --> Output Class Initialized
INFO - 2018-10-22 13:48:26 --> Security Class Initialized
DEBUG - 2018-10-22 13:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:48:26 --> CSRF cookie sent
INFO - 2018-10-22 13:48:26 --> CSRF token verified
INFO - 2018-10-22 13:48:26 --> Input Class Initialized
INFO - 2018-10-22 13:48:26 --> Language Class Initialized
INFO - 2018-10-22 13:48:26 --> Loader Class Initialized
INFO - 2018-10-22 13:48:26 --> Helper loaded: url_helper
INFO - 2018-10-22 13:48:26 --> Helper loaded: form_helper
INFO - 2018-10-22 13:48:26 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:48:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:48:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:48:26 --> User Agent Class Initialized
INFO - 2018-10-22 13:48:26 --> Controller Class Initialized
INFO - 2018-10-22 13:48:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:48:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:48:26 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:48:26 --> Form Validation Class Initialized
INFO - 2018-10-22 13:48:26 --> Pixel_Model class loaded
INFO - 2018-10-22 13:48:26 --> Database Driver Class Initialized
INFO - 2018-10-22 13:48:26 --> Model "AuthenticationModel" initialized
INFO - 2018-10-22 13:48:26 --> Config Class Initialized
INFO - 2018-10-22 13:48:26 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:48:26 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:48:26 --> Utf8 Class Initialized
INFO - 2018-10-22 13:48:26 --> URI Class Initialized
DEBUG - 2018-10-22 13:48:26 --> No URI present. Default controller set.
INFO - 2018-10-22 13:48:26 --> Router Class Initialized
INFO - 2018-10-22 13:48:26 --> Output Class Initialized
INFO - 2018-10-22 13:48:26 --> Security Class Initialized
DEBUG - 2018-10-22 13:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:48:26 --> CSRF cookie sent
INFO - 2018-10-22 13:48:26 --> Input Class Initialized
INFO - 2018-10-22 13:48:26 --> Language Class Initialized
INFO - 2018-10-22 13:48:26 --> Loader Class Initialized
INFO - 2018-10-22 13:48:26 --> Helper loaded: url_helper
INFO - 2018-10-22 13:48:26 --> Helper loaded: form_helper
INFO - 2018-10-22 13:48:26 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:48:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:48:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:48:26 --> User Agent Class Initialized
INFO - 2018-10-22 13:48:26 --> Controller Class Initialized
INFO - 2018-10-22 13:48:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:48:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:48:27 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:48:27 --> Pixel_Model class loaded
INFO - 2018-10-22 13:48:27 --> Database Driver Class Initialized
INFO - 2018-10-22 13:48:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:48:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:48:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:48:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-22 13:48:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:48:27 --> Final output sent to browser
DEBUG - 2018-10-22 13:48:27 --> Total execution time: 0.4300
INFO - 2018-10-22 13:48:29 --> Config Class Initialized
INFO - 2018-10-22 13:48:29 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:48:29 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:48:29 --> Utf8 Class Initialized
INFO - 2018-10-22 13:48:29 --> URI Class Initialized
INFO - 2018-10-22 13:48:29 --> Router Class Initialized
INFO - 2018-10-22 13:48:29 --> Output Class Initialized
INFO - 2018-10-22 13:48:29 --> Security Class Initialized
DEBUG - 2018-10-22 13:48:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:48:29 --> CSRF cookie sent
INFO - 2018-10-22 13:48:29 --> Input Class Initialized
INFO - 2018-10-22 13:48:29 --> Language Class Initialized
INFO - 2018-10-22 13:48:29 --> Loader Class Initialized
INFO - 2018-10-22 13:48:29 --> Helper loaded: url_helper
INFO - 2018-10-22 13:48:29 --> Helper loaded: form_helper
INFO - 2018-10-22 13:48:29 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:48:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:48:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:48:29 --> User Agent Class Initialized
INFO - 2018-10-22 13:48:29 --> Controller Class Initialized
INFO - 2018-10-22 13:48:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:48:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:48:29 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:48:29 --> Pixel_Model class loaded
INFO - 2018-10-22 13:48:29 --> Database Driver Class Initialized
INFO - 2018-10-22 13:48:29 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:48:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:48:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:48:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:48:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:48:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:48:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:48:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-22 13:48:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:48:29 --> Final output sent to browser
DEBUG - 2018-10-22 13:48:30 --> Total execution time: 0.5117
INFO - 2018-10-22 13:48:32 --> Config Class Initialized
INFO - 2018-10-22 13:48:32 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:48:32 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:48:32 --> Utf8 Class Initialized
INFO - 2018-10-22 13:48:32 --> URI Class Initialized
INFO - 2018-10-22 13:48:32 --> Router Class Initialized
INFO - 2018-10-22 13:48:32 --> Output Class Initialized
INFO - 2018-10-22 13:48:32 --> Security Class Initialized
DEBUG - 2018-10-22 13:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:48:32 --> CSRF cookie sent
INFO - 2018-10-22 13:48:32 --> CSRF token verified
INFO - 2018-10-22 13:48:32 --> Input Class Initialized
INFO - 2018-10-22 13:48:32 --> Language Class Initialized
INFO - 2018-10-22 13:48:32 --> Loader Class Initialized
INFO - 2018-10-22 13:48:32 --> Helper loaded: url_helper
INFO - 2018-10-22 13:48:32 --> Helper loaded: form_helper
INFO - 2018-10-22 13:48:32 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:48:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:48:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:48:32 --> User Agent Class Initialized
INFO - 2018-10-22 13:48:32 --> Controller Class Initialized
INFO - 2018-10-22 13:48:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:48:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:48:32 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:48:32 --> Pixel_Model class loaded
INFO - 2018-10-22 13:48:32 --> Database Driver Class Initialized
INFO - 2018-10-22 13:48:32 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:48:32 --> Form Validation Class Initialized
INFO - 2018-10-22 13:48:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:48:33 --> Database Driver Class Initialized
INFO - 2018-10-22 13:48:33 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:48:33 --> Config Class Initialized
INFO - 2018-10-22 13:48:33 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:48:33 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:48:33 --> Utf8 Class Initialized
INFO - 2018-10-22 13:48:33 --> URI Class Initialized
INFO - 2018-10-22 13:48:33 --> Router Class Initialized
INFO - 2018-10-22 13:48:33 --> Output Class Initialized
INFO - 2018-10-22 13:48:33 --> Security Class Initialized
DEBUG - 2018-10-22 13:48:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:48:33 --> CSRF cookie sent
INFO - 2018-10-22 13:48:33 --> Input Class Initialized
INFO - 2018-10-22 13:48:33 --> Language Class Initialized
INFO - 2018-10-22 13:48:33 --> Loader Class Initialized
INFO - 2018-10-22 13:48:33 --> Helper loaded: url_helper
INFO - 2018-10-22 13:48:33 --> Helper loaded: form_helper
INFO - 2018-10-22 13:48:33 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:48:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:48:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:48:33 --> User Agent Class Initialized
INFO - 2018-10-22 13:48:33 --> Controller Class Initialized
INFO - 2018-10-22 13:48:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:48:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:48:33 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:48:33 --> Pixel_Model class loaded
INFO - 2018-10-22 13:48:33 --> Database Driver Class Initialized
INFO - 2018-10-22 13:48:33 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:48:33 --> Database Driver Class Initialized
INFO - 2018-10-22 13:48:33 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:48:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:48:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:48:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:48:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:48:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:48:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:48:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-22 13:48:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:48:33 --> Final output sent to browser
DEBUG - 2018-10-22 13:48:33 --> Total execution time: 0.4983
INFO - 2018-10-22 13:48:36 --> Config Class Initialized
INFO - 2018-10-22 13:48:36 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:48:36 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:48:36 --> Utf8 Class Initialized
INFO - 2018-10-22 13:48:36 --> URI Class Initialized
INFO - 2018-10-22 13:48:36 --> Router Class Initialized
INFO - 2018-10-22 13:48:36 --> Output Class Initialized
INFO - 2018-10-22 13:48:36 --> Security Class Initialized
DEBUG - 2018-10-22 13:48:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:48:36 --> CSRF cookie sent
INFO - 2018-10-22 13:48:36 --> CSRF token verified
INFO - 2018-10-22 13:48:36 --> Input Class Initialized
INFO - 2018-10-22 13:48:36 --> Language Class Initialized
INFO - 2018-10-22 13:48:36 --> Loader Class Initialized
INFO - 2018-10-22 13:48:36 --> Helper loaded: url_helper
INFO - 2018-10-22 13:48:36 --> Helper loaded: form_helper
INFO - 2018-10-22 13:48:36 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:48:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:48:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:48:36 --> User Agent Class Initialized
INFO - 2018-10-22 13:48:36 --> Controller Class Initialized
INFO - 2018-10-22 13:48:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:48:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:48:36 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:48:36 --> Pixel_Model class loaded
INFO - 2018-10-22 13:48:36 --> Database Driver Class Initialized
INFO - 2018-10-22 13:48:36 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:48:36 --> Form Validation Class Initialized
INFO - 2018-10-22 13:48:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:48:36 --> Database Driver Class Initialized
INFO - 2018-10-22 13:48:36 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:48:36 --> Config Class Initialized
INFO - 2018-10-22 13:48:36 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:48:36 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:48:36 --> Utf8 Class Initialized
INFO - 2018-10-22 13:48:36 --> URI Class Initialized
INFO - 2018-10-22 13:48:36 --> Router Class Initialized
INFO - 2018-10-22 13:48:36 --> Output Class Initialized
INFO - 2018-10-22 13:48:36 --> Security Class Initialized
DEBUG - 2018-10-22 13:48:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:48:36 --> CSRF cookie sent
INFO - 2018-10-22 13:48:36 --> Input Class Initialized
INFO - 2018-10-22 13:48:36 --> Language Class Initialized
INFO - 2018-10-22 13:48:36 --> Loader Class Initialized
INFO - 2018-10-22 13:48:36 --> Helper loaded: url_helper
INFO - 2018-10-22 13:48:36 --> Helper loaded: form_helper
INFO - 2018-10-22 13:48:36 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:48:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:48:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:48:37 --> User Agent Class Initialized
INFO - 2018-10-22 13:48:37 --> Controller Class Initialized
INFO - 2018-10-22 13:48:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:48:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:48:37 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:48:37 --> Pixel_Model class loaded
INFO - 2018-10-22 13:48:37 --> Database Driver Class Initialized
INFO - 2018-10-22 13:48:37 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:48:37 --> Database Driver Class Initialized
INFO - 2018-10-22 13:48:37 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:48:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:48:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:48:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:48:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:48:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:48:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:48:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/your_job.php
INFO - 2018-10-22 13:48:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:48:37 --> Final output sent to browser
DEBUG - 2018-10-22 13:48:37 --> Total execution time: 0.5268
INFO - 2018-10-22 13:48:39 --> Config Class Initialized
INFO - 2018-10-22 13:48:39 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:48:39 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:48:39 --> Utf8 Class Initialized
INFO - 2018-10-22 13:48:39 --> URI Class Initialized
INFO - 2018-10-22 13:48:40 --> Router Class Initialized
INFO - 2018-10-22 13:48:40 --> Output Class Initialized
INFO - 2018-10-22 13:48:40 --> Security Class Initialized
DEBUG - 2018-10-22 13:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:48:40 --> CSRF cookie sent
INFO - 2018-10-22 13:48:40 --> CSRF token verified
INFO - 2018-10-22 13:48:40 --> Input Class Initialized
INFO - 2018-10-22 13:48:40 --> Language Class Initialized
INFO - 2018-10-22 13:48:40 --> Loader Class Initialized
INFO - 2018-10-22 13:48:40 --> Helper loaded: url_helper
INFO - 2018-10-22 13:48:40 --> Helper loaded: form_helper
INFO - 2018-10-22 13:48:40 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:48:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:48:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:48:40 --> User Agent Class Initialized
INFO - 2018-10-22 13:48:40 --> Controller Class Initialized
INFO - 2018-10-22 13:48:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:48:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:48:40 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:48:40 --> Pixel_Model class loaded
INFO - 2018-10-22 13:48:40 --> Database Driver Class Initialized
INFO - 2018-10-22 13:48:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:48:40 --> Form Validation Class Initialized
INFO - 2018-10-22 13:48:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:48:40 --> Database Driver Class Initialized
INFO - 2018-10-22 13:48:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:48:40 --> Config Class Initialized
INFO - 2018-10-22 13:48:40 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:48:40 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:48:40 --> Utf8 Class Initialized
INFO - 2018-10-22 13:48:40 --> URI Class Initialized
INFO - 2018-10-22 13:48:40 --> Router Class Initialized
INFO - 2018-10-22 13:48:40 --> Output Class Initialized
INFO - 2018-10-22 13:48:40 --> Security Class Initialized
DEBUG - 2018-10-22 13:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:48:40 --> CSRF cookie sent
INFO - 2018-10-22 13:48:40 --> Input Class Initialized
INFO - 2018-10-22 13:48:40 --> Language Class Initialized
INFO - 2018-10-22 13:48:40 --> Loader Class Initialized
INFO - 2018-10-22 13:48:40 --> Helper loaded: url_helper
INFO - 2018-10-22 13:48:40 --> Helper loaded: form_helper
INFO - 2018-10-22 13:48:40 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:48:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:48:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:48:40 --> User Agent Class Initialized
INFO - 2018-10-22 13:48:40 --> Controller Class Initialized
INFO - 2018-10-22 13:48:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:48:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:48:40 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:48:40 --> Pixel_Model class loaded
INFO - 2018-10-22 13:48:40 --> Database Driver Class Initialized
INFO - 2018-10-22 13:48:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:48:40 --> Database Driver Class Initialized
INFO - 2018-10-22 13:48:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:48:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:48:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:48:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner.php
INFO - 2018-10-22 13:48:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:48:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:48:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:48:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:48:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/relation_ship_status.php
INFO - 2018-10-22 13:48:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:48:40 --> Final output sent to browser
DEBUG - 2018-10-22 13:48:40 --> Total execution time: 0.5043
INFO - 2018-10-22 13:48:43 --> Config Class Initialized
INFO - 2018-10-22 13:48:43 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:48:43 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:48:43 --> Utf8 Class Initialized
INFO - 2018-10-22 13:48:43 --> URI Class Initialized
INFO - 2018-10-22 13:48:43 --> Router Class Initialized
INFO - 2018-10-22 13:48:43 --> Output Class Initialized
INFO - 2018-10-22 13:48:43 --> Security Class Initialized
DEBUG - 2018-10-22 13:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:48:43 --> CSRF cookie sent
INFO - 2018-10-22 13:48:43 --> CSRF token verified
INFO - 2018-10-22 13:48:43 --> Input Class Initialized
INFO - 2018-10-22 13:48:43 --> Language Class Initialized
INFO - 2018-10-22 13:48:43 --> Loader Class Initialized
INFO - 2018-10-22 13:48:43 --> Helper loaded: url_helper
INFO - 2018-10-22 13:48:43 --> Helper loaded: form_helper
INFO - 2018-10-22 13:48:43 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:48:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:48:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:48:43 --> User Agent Class Initialized
INFO - 2018-10-22 13:48:43 --> Controller Class Initialized
INFO - 2018-10-22 13:48:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:48:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:48:44 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:48:44 --> Pixel_Model class loaded
INFO - 2018-10-22 13:48:44 --> Database Driver Class Initialized
INFO - 2018-10-22 13:48:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:48:44 --> Form Validation Class Initialized
INFO - 2018-10-22 13:48:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:48:44 --> Database Driver Class Initialized
INFO - 2018-10-22 13:48:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:48:44 --> Config Class Initialized
INFO - 2018-10-22 13:48:44 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:48:44 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:48:44 --> Utf8 Class Initialized
INFO - 2018-10-22 13:48:44 --> URI Class Initialized
INFO - 2018-10-22 13:48:44 --> Router Class Initialized
INFO - 2018-10-22 13:48:44 --> Output Class Initialized
INFO - 2018-10-22 13:48:44 --> Security Class Initialized
DEBUG - 2018-10-22 13:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:48:44 --> CSRF cookie sent
INFO - 2018-10-22 13:48:44 --> Input Class Initialized
INFO - 2018-10-22 13:48:44 --> Language Class Initialized
INFO - 2018-10-22 13:48:44 --> Loader Class Initialized
INFO - 2018-10-22 13:48:44 --> Helper loaded: url_helper
INFO - 2018-10-22 13:48:44 --> Helper loaded: form_helper
INFO - 2018-10-22 13:48:44 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:48:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:48:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:48:44 --> User Agent Class Initialized
INFO - 2018-10-22 13:48:44 --> Controller Class Initialized
INFO - 2018-10-22 13:48:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:48:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:48:44 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:48:44 --> Pixel_Model class loaded
INFO - 2018-10-22 13:48:44 --> Database Driver Class Initialized
INFO - 2018-10-22 13:48:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:48:44 --> Database Driver Class Initialized
INFO - 2018-10-22 13:48:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:48:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:48:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:48:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:48:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:48:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:48:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:48:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/income.php
INFO - 2018-10-22 13:48:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:48:44 --> Final output sent to browser
DEBUG - 2018-10-22 13:48:44 --> Total execution time: 0.5285
INFO - 2018-10-22 13:48:45 --> Config Class Initialized
INFO - 2018-10-22 13:48:45 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:48:45 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:48:45 --> Utf8 Class Initialized
INFO - 2018-10-22 13:48:45 --> URI Class Initialized
INFO - 2018-10-22 13:48:46 --> Router Class Initialized
INFO - 2018-10-22 13:48:46 --> Output Class Initialized
INFO - 2018-10-22 13:48:46 --> Security Class Initialized
DEBUG - 2018-10-22 13:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:48:46 --> CSRF cookie sent
INFO - 2018-10-22 13:48:46 --> CSRF token verified
INFO - 2018-10-22 13:48:46 --> Input Class Initialized
INFO - 2018-10-22 13:48:46 --> Language Class Initialized
INFO - 2018-10-22 13:48:46 --> Loader Class Initialized
INFO - 2018-10-22 13:48:46 --> Helper loaded: url_helper
INFO - 2018-10-22 13:48:46 --> Helper loaded: form_helper
INFO - 2018-10-22 13:48:46 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:48:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:48:46 --> User Agent Class Initialized
INFO - 2018-10-22 13:48:46 --> Controller Class Initialized
INFO - 2018-10-22 13:48:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:48:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:48:46 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:48:46 --> Pixel_Model class loaded
INFO - 2018-10-22 13:48:46 --> Database Driver Class Initialized
INFO - 2018-10-22 13:48:46 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:48:46 --> Form Validation Class Initialized
INFO - 2018-10-22 13:48:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:48:46 --> Database Driver Class Initialized
INFO - 2018-10-22 13:48:46 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:48:46 --> Config Class Initialized
INFO - 2018-10-22 13:48:46 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:48:46 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:48:46 --> Utf8 Class Initialized
INFO - 2018-10-22 13:48:46 --> URI Class Initialized
INFO - 2018-10-22 13:48:46 --> Router Class Initialized
INFO - 2018-10-22 13:48:46 --> Output Class Initialized
INFO - 2018-10-22 13:48:46 --> Security Class Initialized
DEBUG - 2018-10-22 13:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:48:46 --> CSRF cookie sent
INFO - 2018-10-22 13:48:46 --> Input Class Initialized
INFO - 2018-10-22 13:48:46 --> Language Class Initialized
INFO - 2018-10-22 13:48:46 --> Loader Class Initialized
INFO - 2018-10-22 13:48:46 --> Helper loaded: url_helper
INFO - 2018-10-22 13:48:46 --> Helper loaded: form_helper
INFO - 2018-10-22 13:48:46 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:48:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:48:46 --> User Agent Class Initialized
INFO - 2018-10-22 13:48:46 --> Controller Class Initialized
INFO - 2018-10-22 13:48:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:48:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:48:46 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:48:46 --> Pixel_Model class loaded
INFO - 2018-10-22 13:48:46 --> Database Driver Class Initialized
INFO - 2018-10-22 13:48:46 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:48:46 --> Database Driver Class Initialized
INFO - 2018-10-22 13:48:46 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:48:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:48:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:48:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:48:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:48:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:48:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:48:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/pension.php
INFO - 2018-10-22 13:48:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:48:46 --> Final output sent to browser
DEBUG - 2018-10-22 13:48:46 --> Total execution time: 0.5032
INFO - 2018-10-22 13:48:48 --> Config Class Initialized
INFO - 2018-10-22 13:48:48 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:48:48 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:48:48 --> Utf8 Class Initialized
INFO - 2018-10-22 13:48:48 --> URI Class Initialized
INFO - 2018-10-22 13:48:48 --> Router Class Initialized
INFO - 2018-10-22 13:48:48 --> Output Class Initialized
INFO - 2018-10-22 13:48:48 --> Security Class Initialized
DEBUG - 2018-10-22 13:48:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:48:48 --> CSRF cookie sent
INFO - 2018-10-22 13:48:48 --> CSRF token verified
INFO - 2018-10-22 13:48:48 --> Input Class Initialized
INFO - 2018-10-22 13:48:48 --> Language Class Initialized
INFO - 2018-10-22 13:48:48 --> Loader Class Initialized
INFO - 2018-10-22 13:48:48 --> Helper loaded: url_helper
INFO - 2018-10-22 13:48:48 --> Helper loaded: form_helper
INFO - 2018-10-22 13:48:48 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:48:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:48:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:48:48 --> User Agent Class Initialized
INFO - 2018-10-22 13:48:48 --> Controller Class Initialized
INFO - 2018-10-22 13:48:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:48:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:48:48 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:48:48 --> Pixel_Model class loaded
INFO - 2018-10-22 13:48:48 --> Database Driver Class Initialized
INFO - 2018-10-22 13:48:48 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:48:48 --> Form Validation Class Initialized
INFO - 2018-10-22 13:48:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:48:48 --> Database Driver Class Initialized
INFO - 2018-10-22 13:48:48 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:48:48 --> Config Class Initialized
INFO - 2018-10-22 13:48:48 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:48:48 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:48:48 --> Utf8 Class Initialized
INFO - 2018-10-22 13:48:48 --> URI Class Initialized
INFO - 2018-10-22 13:48:48 --> Router Class Initialized
INFO - 2018-10-22 13:48:48 --> Output Class Initialized
INFO - 2018-10-22 13:48:48 --> Security Class Initialized
DEBUG - 2018-10-22 13:48:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:48:48 --> CSRF cookie sent
INFO - 2018-10-22 13:48:48 --> Input Class Initialized
INFO - 2018-10-22 13:48:48 --> Language Class Initialized
INFO - 2018-10-22 13:48:48 --> Loader Class Initialized
INFO - 2018-10-22 13:48:48 --> Helper loaded: url_helper
INFO - 2018-10-22 13:48:48 --> Helper loaded: form_helper
INFO - 2018-10-22 13:48:48 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:48:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:48:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:48:48 --> User Agent Class Initialized
INFO - 2018-10-22 13:48:48 --> Controller Class Initialized
INFO - 2018-10-22 13:48:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:48:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:48:48 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:48:48 --> Pixel_Model class loaded
INFO - 2018-10-22 13:48:48 --> Database Driver Class Initialized
INFO - 2018-10-22 13:48:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:48:49 --> Database Driver Class Initialized
INFO - 2018-10-22 13:48:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:48:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:48:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:48:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:48:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:48:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:48:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:48:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/home_title.php
INFO - 2018-10-22 13:48:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:48:49 --> Final output sent to browser
DEBUG - 2018-10-22 13:48:49 --> Total execution time: 0.5178
INFO - 2018-10-22 13:48:50 --> Config Class Initialized
INFO - 2018-10-22 13:48:50 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:48:50 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:48:50 --> Utf8 Class Initialized
INFO - 2018-10-22 13:48:50 --> URI Class Initialized
INFO - 2018-10-22 13:48:50 --> Router Class Initialized
INFO - 2018-10-22 13:48:50 --> Output Class Initialized
INFO - 2018-10-22 13:48:50 --> Security Class Initialized
DEBUG - 2018-10-22 13:48:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:48:50 --> CSRF cookie sent
INFO - 2018-10-22 13:48:50 --> CSRF token verified
INFO - 2018-10-22 13:48:50 --> Input Class Initialized
INFO - 2018-10-22 13:48:50 --> Language Class Initialized
INFO - 2018-10-22 13:48:50 --> Loader Class Initialized
INFO - 2018-10-22 13:48:50 --> Helper loaded: url_helper
INFO - 2018-10-22 13:48:50 --> Helper loaded: form_helper
INFO - 2018-10-22 13:48:50 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:48:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:48:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:48:50 --> User Agent Class Initialized
INFO - 2018-10-22 13:48:50 --> Controller Class Initialized
INFO - 2018-10-22 13:48:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:48:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:48:50 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:48:50 --> Pixel_Model class loaded
INFO - 2018-10-22 13:48:50 --> Database Driver Class Initialized
INFO - 2018-10-22 13:48:51 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:48:51 --> Form Validation Class Initialized
INFO - 2018-10-22 13:48:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:48:51 --> Database Driver Class Initialized
INFO - 2018-10-22 13:48:51 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:48:51 --> Config Class Initialized
INFO - 2018-10-22 13:48:51 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:48:51 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:48:51 --> Utf8 Class Initialized
INFO - 2018-10-22 13:48:51 --> URI Class Initialized
INFO - 2018-10-22 13:48:51 --> Router Class Initialized
INFO - 2018-10-22 13:48:51 --> Output Class Initialized
INFO - 2018-10-22 13:48:51 --> Security Class Initialized
DEBUG - 2018-10-22 13:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:48:51 --> CSRF cookie sent
INFO - 2018-10-22 13:48:51 --> Input Class Initialized
INFO - 2018-10-22 13:48:51 --> Language Class Initialized
INFO - 2018-10-22 13:48:51 --> Loader Class Initialized
INFO - 2018-10-22 13:48:51 --> Helper loaded: url_helper
INFO - 2018-10-22 13:48:51 --> Helper loaded: form_helper
INFO - 2018-10-22 13:48:51 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:48:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:48:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:48:51 --> User Agent Class Initialized
INFO - 2018-10-22 13:48:51 --> Controller Class Initialized
INFO - 2018-10-22 13:48:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:48:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:48:51 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:48:51 --> Pixel_Model class loaded
INFO - 2018-10-22 13:48:51 --> Database Driver Class Initialized
INFO - 2018-10-22 13:48:51 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:48:51 --> Database Driver Class Initialized
INFO - 2018-10-22 13:48:51 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:48:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:48:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:48:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:48:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:48:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:48:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:48:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/financial.php
INFO - 2018-10-22 13:48:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:48:51 --> Final output sent to browser
DEBUG - 2018-10-22 13:48:51 --> Total execution time: 0.5228
INFO - 2018-10-22 13:48:59 --> Config Class Initialized
INFO - 2018-10-22 13:48:59 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:48:59 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:48:59 --> Utf8 Class Initialized
INFO - 2018-10-22 13:48:59 --> URI Class Initialized
INFO - 2018-10-22 13:48:59 --> Router Class Initialized
INFO - 2018-10-22 13:48:59 --> Output Class Initialized
INFO - 2018-10-22 13:48:59 --> Security Class Initialized
DEBUG - 2018-10-22 13:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:48:59 --> CSRF cookie sent
INFO - 2018-10-22 13:48:59 --> CSRF token verified
INFO - 2018-10-22 13:48:59 --> Input Class Initialized
INFO - 2018-10-22 13:48:59 --> Language Class Initialized
INFO - 2018-10-22 13:48:59 --> Loader Class Initialized
INFO - 2018-10-22 13:48:59 --> Helper loaded: url_helper
INFO - 2018-10-22 13:48:59 --> Helper loaded: form_helper
INFO - 2018-10-22 13:48:59 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:48:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:48:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:48:59 --> User Agent Class Initialized
INFO - 2018-10-22 13:49:00 --> Controller Class Initialized
INFO - 2018-10-22 13:49:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:49:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:49:00 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:49:00 --> Pixel_Model class loaded
INFO - 2018-10-22 13:49:00 --> Database Driver Class Initialized
INFO - 2018-10-22 13:49:00 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:49:00 --> Form Validation Class Initialized
INFO - 2018-10-22 13:49:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:49:00 --> Database Driver Class Initialized
INFO - 2018-10-22 13:49:00 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:49:00 --> Config Class Initialized
INFO - 2018-10-22 13:49:00 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:49:00 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:49:00 --> Utf8 Class Initialized
INFO - 2018-10-22 13:49:00 --> URI Class Initialized
INFO - 2018-10-22 13:49:00 --> Router Class Initialized
INFO - 2018-10-22 13:49:00 --> Output Class Initialized
INFO - 2018-10-22 13:49:00 --> Security Class Initialized
DEBUG - 2018-10-22 13:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:49:00 --> CSRF cookie sent
INFO - 2018-10-22 13:49:00 --> Input Class Initialized
INFO - 2018-10-22 13:49:00 --> Language Class Initialized
INFO - 2018-10-22 13:49:00 --> Loader Class Initialized
INFO - 2018-10-22 13:49:00 --> Helper loaded: url_helper
INFO - 2018-10-22 13:49:00 --> Helper loaded: form_helper
INFO - 2018-10-22 13:49:00 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:49:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:49:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:49:00 --> User Agent Class Initialized
INFO - 2018-10-22 13:49:00 --> Controller Class Initialized
INFO - 2018-10-22 13:49:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:49:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:49:00 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:49:00 --> Pixel_Model class loaded
INFO - 2018-10-22 13:49:00 --> Database Driver Class Initialized
INFO - 2018-10-22 13:49:00 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:49:00 --> Database Driver Class Initialized
INFO - 2018-10-22 13:49:00 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:49:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:49:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:49:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:49:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:49:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:49:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:49:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/spouse_info.php
INFO - 2018-10-22 13:49:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:49:00 --> Final output sent to browser
DEBUG - 2018-10-22 13:49:00 --> Total execution time: 0.5251
INFO - 2018-10-22 13:49:03 --> Config Class Initialized
INFO - 2018-10-22 13:49:03 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:49:03 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:49:03 --> Utf8 Class Initialized
INFO - 2018-10-22 13:49:03 --> URI Class Initialized
INFO - 2018-10-22 13:49:03 --> Router Class Initialized
INFO - 2018-10-22 13:49:03 --> Output Class Initialized
INFO - 2018-10-22 13:49:03 --> Security Class Initialized
DEBUG - 2018-10-22 13:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:49:03 --> CSRF cookie sent
INFO - 2018-10-22 13:49:03 --> CSRF token verified
INFO - 2018-10-22 13:49:03 --> Input Class Initialized
INFO - 2018-10-22 13:49:03 --> Language Class Initialized
INFO - 2018-10-22 13:49:03 --> Loader Class Initialized
INFO - 2018-10-22 13:49:03 --> Helper loaded: url_helper
INFO - 2018-10-22 13:49:03 --> Helper loaded: form_helper
INFO - 2018-10-22 13:49:03 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:49:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:49:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:49:03 --> User Agent Class Initialized
INFO - 2018-10-22 13:49:03 --> Controller Class Initialized
INFO - 2018-10-22 13:49:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:49:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:49:03 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:49:03 --> Pixel_Model class loaded
INFO - 2018-10-22 13:49:03 --> Database Driver Class Initialized
INFO - 2018-10-22 13:49:03 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:49:03 --> Form Validation Class Initialized
INFO - 2018-10-22 13:49:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:49:03 --> Database Driver Class Initialized
INFO - 2018-10-22 13:49:03 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:49:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:49:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:49:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:49:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:49:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:49:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_errors.php
INFO - 2018-10-22 13:49:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:49:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/spouse_info.php
INFO - 2018-10-22 13:49:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:49:03 --> Final output sent to browser
DEBUG - 2018-10-22 13:49:03 --> Total execution time: 0.6441
INFO - 2018-10-22 13:49:06 --> Config Class Initialized
INFO - 2018-10-22 13:49:06 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:49:06 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:49:06 --> Utf8 Class Initialized
INFO - 2018-10-22 13:49:06 --> URI Class Initialized
INFO - 2018-10-22 13:49:06 --> Router Class Initialized
INFO - 2018-10-22 13:49:06 --> Output Class Initialized
INFO - 2018-10-22 13:49:06 --> Security Class Initialized
DEBUG - 2018-10-22 13:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:49:06 --> CSRF cookie sent
INFO - 2018-10-22 13:49:06 --> CSRF token verified
INFO - 2018-10-22 13:49:06 --> Input Class Initialized
INFO - 2018-10-22 13:49:06 --> Language Class Initialized
INFO - 2018-10-22 13:49:06 --> Loader Class Initialized
INFO - 2018-10-22 13:49:06 --> Helper loaded: url_helper
INFO - 2018-10-22 13:49:06 --> Helper loaded: form_helper
INFO - 2018-10-22 13:49:06 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:49:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:49:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:49:06 --> User Agent Class Initialized
INFO - 2018-10-22 13:49:07 --> Controller Class Initialized
INFO - 2018-10-22 13:49:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:49:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:49:07 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:49:07 --> Pixel_Model class loaded
INFO - 2018-10-22 13:49:07 --> Database Driver Class Initialized
INFO - 2018-10-22 13:49:07 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:49:07 --> Form Validation Class Initialized
INFO - 2018-10-22 13:49:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:49:07 --> Database Driver Class Initialized
INFO - 2018-10-22 13:49:07 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:49:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:49:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:49:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:49:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:49:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:49:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_errors.php
INFO - 2018-10-22 13:49:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:49:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/spouse_info.php
INFO - 2018-10-22 13:49:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:49:07 --> Final output sent to browser
DEBUG - 2018-10-22 13:49:07 --> Total execution time: 0.6200
INFO - 2018-10-22 13:49:10 --> Config Class Initialized
INFO - 2018-10-22 13:49:11 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:49:11 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:49:11 --> Utf8 Class Initialized
INFO - 2018-10-22 13:49:11 --> URI Class Initialized
INFO - 2018-10-22 13:49:11 --> Router Class Initialized
INFO - 2018-10-22 13:49:11 --> Output Class Initialized
INFO - 2018-10-22 13:49:11 --> Security Class Initialized
DEBUG - 2018-10-22 13:49:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:49:11 --> CSRF cookie sent
INFO - 2018-10-22 13:49:11 --> CSRF token verified
INFO - 2018-10-22 13:49:11 --> Input Class Initialized
INFO - 2018-10-22 13:49:11 --> Language Class Initialized
INFO - 2018-10-22 13:49:11 --> Loader Class Initialized
INFO - 2018-10-22 13:49:11 --> Helper loaded: url_helper
INFO - 2018-10-22 13:49:11 --> Helper loaded: form_helper
INFO - 2018-10-22 13:49:11 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:49:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:49:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:49:11 --> User Agent Class Initialized
INFO - 2018-10-22 13:49:11 --> Controller Class Initialized
INFO - 2018-10-22 13:49:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:49:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:49:11 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:49:11 --> Pixel_Model class loaded
INFO - 2018-10-22 13:49:11 --> Database Driver Class Initialized
INFO - 2018-10-22 13:49:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:49:11 --> Form Validation Class Initialized
INFO - 2018-10-22 13:49:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:49:11 --> Database Driver Class Initialized
INFO - 2018-10-22 13:49:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:49:11 --> Config Class Initialized
INFO - 2018-10-22 13:49:11 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:49:11 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:49:11 --> Utf8 Class Initialized
INFO - 2018-10-22 13:49:11 --> URI Class Initialized
INFO - 2018-10-22 13:49:11 --> Router Class Initialized
INFO - 2018-10-22 13:49:11 --> Output Class Initialized
INFO - 2018-10-22 13:49:11 --> Security Class Initialized
DEBUG - 2018-10-22 13:49:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:49:11 --> CSRF cookie sent
INFO - 2018-10-22 13:49:11 --> Input Class Initialized
INFO - 2018-10-22 13:49:11 --> Language Class Initialized
INFO - 2018-10-22 13:49:11 --> Loader Class Initialized
INFO - 2018-10-22 13:49:11 --> Helper loaded: url_helper
INFO - 2018-10-22 13:49:11 --> Helper loaded: form_helper
INFO - 2018-10-22 13:49:11 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:49:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:49:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:49:11 --> User Agent Class Initialized
INFO - 2018-10-22 13:49:11 --> Controller Class Initialized
INFO - 2018-10-22 13:49:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:49:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:49:11 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:49:11 --> Pixel_Model class loaded
INFO - 2018-10-22 13:49:11 --> Database Driver Class Initialized
INFO - 2018-10-22 13:49:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:49:11 --> Database Driver Class Initialized
INFO - 2018-10-22 13:49:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:49:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:49:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:49:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:49:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:49:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:49:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:49:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/spouse_job.php
INFO - 2018-10-22 13:49:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:49:12 --> Final output sent to browser
DEBUG - 2018-10-22 13:49:12 --> Total execution time: 0.5367
INFO - 2018-10-22 13:49:17 --> Config Class Initialized
INFO - 2018-10-22 13:49:17 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:49:17 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:49:17 --> Utf8 Class Initialized
INFO - 2018-10-22 13:49:17 --> URI Class Initialized
INFO - 2018-10-22 13:49:17 --> Router Class Initialized
INFO - 2018-10-22 13:49:17 --> Output Class Initialized
INFO - 2018-10-22 13:49:17 --> Security Class Initialized
DEBUG - 2018-10-22 13:49:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:49:17 --> CSRF cookie sent
INFO - 2018-10-22 13:49:18 --> CSRF token verified
INFO - 2018-10-22 13:49:18 --> Input Class Initialized
INFO - 2018-10-22 13:49:18 --> Language Class Initialized
INFO - 2018-10-22 13:49:18 --> Loader Class Initialized
INFO - 2018-10-22 13:49:18 --> Helper loaded: url_helper
INFO - 2018-10-22 13:49:18 --> Helper loaded: form_helper
INFO - 2018-10-22 13:49:18 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:49:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:49:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:49:18 --> User Agent Class Initialized
INFO - 2018-10-22 13:49:18 --> Controller Class Initialized
INFO - 2018-10-22 13:49:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:49:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:49:18 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:49:18 --> Pixel_Model class loaded
INFO - 2018-10-22 13:49:18 --> Database Driver Class Initialized
INFO - 2018-10-22 13:49:18 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:49:18 --> Form Validation Class Initialized
INFO - 2018-10-22 13:49:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:49:18 --> Database Driver Class Initialized
INFO - 2018-10-22 13:49:18 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:49:18 --> Config Class Initialized
INFO - 2018-10-22 13:49:18 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:49:18 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:49:18 --> Utf8 Class Initialized
INFO - 2018-10-22 13:49:18 --> URI Class Initialized
INFO - 2018-10-22 13:49:18 --> Router Class Initialized
INFO - 2018-10-22 13:49:18 --> Output Class Initialized
INFO - 2018-10-22 13:49:18 --> Security Class Initialized
DEBUG - 2018-10-22 13:49:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:49:18 --> CSRF cookie sent
INFO - 2018-10-22 13:49:18 --> Input Class Initialized
INFO - 2018-10-22 13:49:18 --> Language Class Initialized
INFO - 2018-10-22 13:49:18 --> Loader Class Initialized
INFO - 2018-10-22 13:49:18 --> Helper loaded: url_helper
INFO - 2018-10-22 13:49:18 --> Helper loaded: form_helper
INFO - 2018-10-22 13:49:18 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:49:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:49:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:49:18 --> User Agent Class Initialized
INFO - 2018-10-22 13:49:18 --> Controller Class Initialized
INFO - 2018-10-22 13:49:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:49:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:49:18 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:49:18 --> Pixel_Model class loaded
INFO - 2018-10-22 13:49:18 --> Database Driver Class Initialized
INFO - 2018-10-22 13:49:18 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:49:18 --> Database Driver Class Initialized
INFO - 2018-10-22 13:49:18 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:49:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:49:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:49:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:49:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:49:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:49:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:49:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/affectionate_salutation.php
INFO - 2018-10-22 13:49:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:49:18 --> Final output sent to browser
DEBUG - 2018-10-22 13:49:18 --> Total execution time: 0.5395
INFO - 2018-10-22 13:49:52 --> Config Class Initialized
INFO - 2018-10-22 13:49:52 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:49:52 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:49:52 --> Utf8 Class Initialized
INFO - 2018-10-22 13:49:52 --> URI Class Initialized
INFO - 2018-10-22 13:49:52 --> Router Class Initialized
INFO - 2018-10-22 13:49:52 --> Output Class Initialized
INFO - 2018-10-22 13:49:52 --> Security Class Initialized
DEBUG - 2018-10-22 13:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:49:52 --> CSRF cookie sent
INFO - 2018-10-22 13:49:52 --> Input Class Initialized
INFO - 2018-10-22 13:49:52 --> Language Class Initialized
INFO - 2018-10-22 13:49:52 --> Loader Class Initialized
INFO - 2018-10-22 13:49:52 --> Helper loaded: url_helper
INFO - 2018-10-22 13:49:52 --> Helper loaded: form_helper
INFO - 2018-10-22 13:49:52 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:49:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:49:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:49:52 --> User Agent Class Initialized
INFO - 2018-10-22 13:49:52 --> Controller Class Initialized
INFO - 2018-10-22 13:49:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:49:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:49:52 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:49:52 --> Pixel_Model class loaded
INFO - 2018-10-22 13:49:52 --> Database Driver Class Initialized
INFO - 2018-10-22 13:49:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:49:52 --> Database Driver Class Initialized
INFO - 2018-10-22 13:49:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:49:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:49:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:49:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:49:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:49:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:49:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:49:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/spouse_job.php
INFO - 2018-10-22 13:49:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:49:52 --> Final output sent to browser
DEBUG - 2018-10-22 13:49:52 --> Total execution time: 0.5548
INFO - 2018-10-22 13:50:00 --> Config Class Initialized
INFO - 2018-10-22 13:50:00 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:50:00 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:50:00 --> Utf8 Class Initialized
INFO - 2018-10-22 13:50:00 --> URI Class Initialized
INFO - 2018-10-22 13:50:00 --> Router Class Initialized
INFO - 2018-10-22 13:50:00 --> Output Class Initialized
INFO - 2018-10-22 13:50:00 --> Security Class Initialized
DEBUG - 2018-10-22 13:50:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:50:00 --> CSRF cookie sent
INFO - 2018-10-22 13:50:00 --> CSRF token verified
INFO - 2018-10-22 13:50:00 --> Input Class Initialized
INFO - 2018-10-22 13:50:00 --> Language Class Initialized
INFO - 2018-10-22 13:50:00 --> Loader Class Initialized
INFO - 2018-10-22 13:50:00 --> Helper loaded: url_helper
INFO - 2018-10-22 13:50:00 --> Helper loaded: form_helper
INFO - 2018-10-22 13:50:00 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:50:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:50:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:50:00 --> User Agent Class Initialized
INFO - 2018-10-22 13:50:00 --> Controller Class Initialized
INFO - 2018-10-22 13:50:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:50:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:50:00 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:50:00 --> Pixel_Model class loaded
INFO - 2018-10-22 13:50:00 --> Database Driver Class Initialized
INFO - 2018-10-22 13:50:00 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:50:00 --> Form Validation Class Initialized
INFO - 2018-10-22 13:50:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:50:00 --> Database Driver Class Initialized
INFO - 2018-10-22 13:50:00 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:50:00 --> Config Class Initialized
INFO - 2018-10-22 13:50:00 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:50:00 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:50:00 --> Utf8 Class Initialized
INFO - 2018-10-22 13:50:00 --> URI Class Initialized
INFO - 2018-10-22 13:50:00 --> Router Class Initialized
INFO - 2018-10-22 13:50:00 --> Output Class Initialized
INFO - 2018-10-22 13:50:00 --> Security Class Initialized
DEBUG - 2018-10-22 13:50:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:50:00 --> CSRF cookie sent
INFO - 2018-10-22 13:50:00 --> Input Class Initialized
INFO - 2018-10-22 13:50:00 --> Language Class Initialized
INFO - 2018-10-22 13:50:00 --> Loader Class Initialized
INFO - 2018-10-22 13:50:00 --> Helper loaded: url_helper
INFO - 2018-10-22 13:50:00 --> Helper loaded: form_helper
INFO - 2018-10-22 13:50:00 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:50:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:50:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:50:00 --> User Agent Class Initialized
INFO - 2018-10-22 13:50:00 --> Controller Class Initialized
INFO - 2018-10-22 13:50:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:50:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:50:00 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:50:00 --> Pixel_Model class loaded
INFO - 2018-10-22 13:50:00 --> Database Driver Class Initialized
INFO - 2018-10-22 13:50:00 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:50:00 --> Database Driver Class Initialized
INFO - 2018-10-22 13:50:01 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:50:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:50:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:50:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:50:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:50:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:50:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:50:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/affectionate_salutation.php
INFO - 2018-10-22 13:50:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:50:01 --> Final output sent to browser
DEBUG - 2018-10-22 13:50:01 --> Total execution time: 0.5498
INFO - 2018-10-22 13:50:08 --> Config Class Initialized
INFO - 2018-10-22 13:50:08 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:50:08 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:50:08 --> Utf8 Class Initialized
INFO - 2018-10-22 13:50:08 --> URI Class Initialized
INFO - 2018-10-22 13:50:08 --> Router Class Initialized
INFO - 2018-10-22 13:50:08 --> Output Class Initialized
INFO - 2018-10-22 13:50:08 --> Security Class Initialized
DEBUG - 2018-10-22 13:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:50:08 --> CSRF cookie sent
INFO - 2018-10-22 13:50:08 --> CSRF token verified
INFO - 2018-10-22 13:50:08 --> Input Class Initialized
INFO - 2018-10-22 13:50:08 --> Language Class Initialized
INFO - 2018-10-22 13:50:08 --> Loader Class Initialized
INFO - 2018-10-22 13:50:08 --> Helper loaded: url_helper
INFO - 2018-10-22 13:50:08 --> Helper loaded: form_helper
INFO - 2018-10-22 13:50:08 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:50:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:50:08 --> User Agent Class Initialized
INFO - 2018-10-22 13:50:08 --> Controller Class Initialized
INFO - 2018-10-22 13:50:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:50:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:50:08 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:50:08 --> Pixel_Model class loaded
INFO - 2018-10-22 13:50:08 --> Database Driver Class Initialized
INFO - 2018-10-22 13:50:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:50:08 --> Form Validation Class Initialized
INFO - 2018-10-22 13:50:08 --> Config Class Initialized
INFO - 2018-10-22 13:50:08 --> Hooks Class Initialized
INFO - 2018-10-22 13:50:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:50:08 --> Database Driver Class Initialized
DEBUG - 2018-10-22 13:50:08 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:50:08 --> Utf8 Class Initialized
INFO - 2018-10-22 13:50:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:50:08 --> URI Class Initialized
INFO - 2018-10-22 13:50:08 --> Router Class Initialized
INFO - 2018-10-22 13:50:08 --> Output Class Initialized
INFO - 2018-10-22 13:50:08 --> Security Class Initialized
DEBUG - 2018-10-22 13:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:50:08 --> CSRF cookie sent
INFO - 2018-10-22 13:50:08 --> CSRF token verified
INFO - 2018-10-22 13:50:08 --> Input Class Initialized
INFO - 2018-10-22 13:50:08 --> Language Class Initialized
INFO - 2018-10-22 13:50:08 --> Loader Class Initialized
INFO - 2018-10-22 13:50:08 --> Helper loaded: url_helper
INFO - 2018-10-22 13:50:08 --> Helper loaded: form_helper
INFO - 2018-10-22 13:50:08 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:50:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:50:08 --> User Agent Class Initialized
INFO - 2018-10-22 13:50:08 --> Controller Class Initialized
INFO - 2018-10-22 13:50:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:50:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:50:08 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:50:08 --> Pixel_Model class loaded
INFO - 2018-10-22 13:50:08 --> Database Driver Class Initialized
INFO - 2018-10-22 13:50:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:50:09 --> Form Validation Class Initialized
INFO - 2018-10-22 13:50:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:50:09 --> Database Driver Class Initialized
INFO - 2018-10-22 13:50:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:50:09 --> Config Class Initialized
INFO - 2018-10-22 13:50:09 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:50:09 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:50:09 --> Utf8 Class Initialized
INFO - 2018-10-22 13:50:09 --> URI Class Initialized
INFO - 2018-10-22 13:50:09 --> Router Class Initialized
INFO - 2018-10-22 13:50:09 --> Output Class Initialized
INFO - 2018-10-22 13:50:09 --> Security Class Initialized
DEBUG - 2018-10-22 13:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:50:09 --> CSRF cookie sent
INFO - 2018-10-22 13:50:09 --> Input Class Initialized
INFO - 2018-10-22 13:50:09 --> Language Class Initialized
INFO - 2018-10-22 13:50:09 --> Loader Class Initialized
INFO - 2018-10-22 13:50:09 --> Helper loaded: url_helper
INFO - 2018-10-22 13:50:09 --> Helper loaded: form_helper
INFO - 2018-10-22 13:50:09 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:50:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:50:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:50:09 --> User Agent Class Initialized
INFO - 2018-10-22 13:50:09 --> Controller Class Initialized
INFO - 2018-10-22 13:50:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:50:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:50:09 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:50:09 --> Pixel_Model class loaded
INFO - 2018-10-22 13:50:09 --> Database Driver Class Initialized
INFO - 2018-10-22 13:50:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:50:09 --> Database Driver Class Initialized
INFO - 2018-10-22 13:50:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:50:09 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:50:09 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:50:09 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:50:09 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:50:09 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:50:09 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:50:09 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/additional_business_info.php
INFO - 2018-10-22 13:50:09 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:50:09 --> Final output sent to browser
DEBUG - 2018-10-22 13:50:09 --> Total execution time: 0.5498
INFO - 2018-10-22 13:50:17 --> Config Class Initialized
INFO - 2018-10-22 13:50:17 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:50:17 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:50:17 --> Utf8 Class Initialized
INFO - 2018-10-22 13:50:17 --> URI Class Initialized
INFO - 2018-10-22 13:50:17 --> Router Class Initialized
INFO - 2018-10-22 13:50:17 --> Output Class Initialized
INFO - 2018-10-22 13:50:17 --> Security Class Initialized
DEBUG - 2018-10-22 13:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:50:17 --> CSRF cookie sent
INFO - 2018-10-22 13:50:17 --> CSRF token verified
INFO - 2018-10-22 13:50:17 --> Input Class Initialized
INFO - 2018-10-22 13:50:17 --> Language Class Initialized
INFO - 2018-10-22 13:50:17 --> Loader Class Initialized
INFO - 2018-10-22 13:50:17 --> Helper loaded: url_helper
INFO - 2018-10-22 13:50:17 --> Helper loaded: form_helper
INFO - 2018-10-22 13:50:17 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:50:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:50:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:50:17 --> User Agent Class Initialized
INFO - 2018-10-22 13:50:17 --> Controller Class Initialized
INFO - 2018-10-22 13:50:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:50:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:50:17 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:50:17 --> Pixel_Model class loaded
INFO - 2018-10-22 13:50:17 --> Database Driver Class Initialized
INFO - 2018-10-22 13:50:17 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:50:17 --> Form Validation Class Initialized
INFO - 2018-10-22 13:50:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:50:17 --> Database Driver Class Initialized
INFO - 2018-10-22 13:50:17 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:50:17 --> Config Class Initialized
INFO - 2018-10-22 13:50:17 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:50:17 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:50:17 --> Utf8 Class Initialized
INFO - 2018-10-22 13:50:17 --> URI Class Initialized
INFO - 2018-10-22 13:50:17 --> Router Class Initialized
INFO - 2018-10-22 13:50:17 --> Output Class Initialized
INFO - 2018-10-22 13:50:17 --> Security Class Initialized
DEBUG - 2018-10-22 13:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:50:17 --> CSRF cookie sent
INFO - 2018-10-22 13:50:17 --> Input Class Initialized
INFO - 2018-10-22 13:50:17 --> Language Class Initialized
INFO - 2018-10-22 13:50:17 --> Loader Class Initialized
INFO - 2018-10-22 13:50:17 --> Helper loaded: url_helper
INFO - 2018-10-22 13:50:17 --> Helper loaded: form_helper
INFO - 2018-10-22 13:50:17 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:50:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:50:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:50:17 --> User Agent Class Initialized
INFO - 2018-10-22 13:50:17 --> Controller Class Initialized
INFO - 2018-10-22 13:50:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:50:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:50:17 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:50:17 --> Pixel_Model class loaded
INFO - 2018-10-22 13:50:17 --> Database Driver Class Initialized
INFO - 2018-10-22 13:50:17 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:50:17 --> Database Driver Class Initialized
INFO - 2018-10-22 13:50:17 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:50:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:50:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:50:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:50:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:50:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:50:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:50:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/business_tax_info.php
INFO - 2018-10-22 13:50:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:50:18 --> Final output sent to browser
DEBUG - 2018-10-22 13:50:18 --> Total execution time: 0.5533
INFO - 2018-10-22 13:50:25 --> Config Class Initialized
INFO - 2018-10-22 13:50:25 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:50:25 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:50:25 --> Utf8 Class Initialized
INFO - 2018-10-22 13:50:25 --> URI Class Initialized
INFO - 2018-10-22 13:50:25 --> Router Class Initialized
INFO - 2018-10-22 13:50:25 --> Output Class Initialized
INFO - 2018-10-22 13:50:25 --> Security Class Initialized
DEBUG - 2018-10-22 13:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:50:25 --> CSRF cookie sent
INFO - 2018-10-22 13:50:25 --> Input Class Initialized
INFO - 2018-10-22 13:50:25 --> Language Class Initialized
INFO - 2018-10-22 13:50:25 --> Loader Class Initialized
INFO - 2018-10-22 13:50:25 --> Helper loaded: url_helper
INFO - 2018-10-22 13:50:25 --> Helper loaded: form_helper
INFO - 2018-10-22 13:50:25 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:50:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:50:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:50:25 --> User Agent Class Initialized
INFO - 2018-10-22 13:50:25 --> Controller Class Initialized
INFO - 2018-10-22 13:50:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:50:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:50:25 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:50:25 --> Pixel_Model class loaded
INFO - 2018-10-22 13:50:25 --> Database Driver Class Initialized
INFO - 2018-10-22 13:50:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:50:25 --> Database Driver Class Initialized
INFO - 2018-10-22 13:50:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:50:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:50:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:50:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:50:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:50:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:50:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:50:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/additional_business_info.php
INFO - 2018-10-22 13:50:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:50:25 --> Final output sent to browser
DEBUG - 2018-10-22 13:50:25 --> Total execution time: 0.5720
INFO - 2018-10-22 13:50:38 --> Config Class Initialized
INFO - 2018-10-22 13:50:38 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:50:38 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:50:38 --> Utf8 Class Initialized
INFO - 2018-10-22 13:50:38 --> URI Class Initialized
INFO - 2018-10-22 13:50:38 --> Router Class Initialized
INFO - 2018-10-22 13:50:38 --> Output Class Initialized
INFO - 2018-10-22 13:50:38 --> Security Class Initialized
DEBUG - 2018-10-22 13:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:50:38 --> CSRF cookie sent
INFO - 2018-10-22 13:50:38 --> CSRF token verified
INFO - 2018-10-22 13:50:38 --> Input Class Initialized
INFO - 2018-10-22 13:50:38 --> Language Class Initialized
INFO - 2018-10-22 13:50:38 --> Loader Class Initialized
INFO - 2018-10-22 13:50:38 --> Helper loaded: url_helper
INFO - 2018-10-22 13:50:38 --> Helper loaded: form_helper
INFO - 2018-10-22 13:50:38 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:50:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:50:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:50:38 --> User Agent Class Initialized
INFO - 2018-10-22 13:50:38 --> Controller Class Initialized
INFO - 2018-10-22 13:50:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:50:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:50:38 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:50:38 --> Pixel_Model class loaded
INFO - 2018-10-22 13:50:38 --> Database Driver Class Initialized
INFO - 2018-10-22 13:50:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:50:38 --> Form Validation Class Initialized
INFO - 2018-10-22 13:50:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:50:38 --> Database Driver Class Initialized
INFO - 2018-10-22 13:50:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:50:39 --> Config Class Initialized
INFO - 2018-10-22 13:50:39 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:50:39 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:50:39 --> Utf8 Class Initialized
INFO - 2018-10-22 13:50:39 --> URI Class Initialized
INFO - 2018-10-22 13:50:39 --> Router Class Initialized
INFO - 2018-10-22 13:50:39 --> Output Class Initialized
INFO - 2018-10-22 13:50:39 --> Security Class Initialized
DEBUG - 2018-10-22 13:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:50:39 --> CSRF cookie sent
INFO - 2018-10-22 13:50:39 --> Input Class Initialized
INFO - 2018-10-22 13:50:39 --> Language Class Initialized
INFO - 2018-10-22 13:50:39 --> Loader Class Initialized
INFO - 2018-10-22 13:50:39 --> Helper loaded: url_helper
INFO - 2018-10-22 13:50:39 --> Helper loaded: form_helper
INFO - 2018-10-22 13:50:39 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:50:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:50:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:50:39 --> User Agent Class Initialized
INFO - 2018-10-22 13:50:39 --> Controller Class Initialized
INFO - 2018-10-22 13:50:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:50:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:50:39 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:50:39 --> Pixel_Model class loaded
INFO - 2018-10-22 13:50:39 --> Database Driver Class Initialized
INFO - 2018-10-22 13:50:39 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:50:39 --> Database Driver Class Initialized
INFO - 2018-10-22 13:50:39 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:50:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:50:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:50:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:50:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:50:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:50:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:50:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/business_tax_info.php
INFO - 2018-10-22 13:50:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:50:39 --> Final output sent to browser
DEBUG - 2018-10-22 13:50:39 --> Total execution time: 0.5503
INFO - 2018-10-22 13:50:43 --> Config Class Initialized
INFO - 2018-10-22 13:50:43 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:50:43 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:50:43 --> Utf8 Class Initialized
INFO - 2018-10-22 13:50:43 --> URI Class Initialized
INFO - 2018-10-22 13:50:43 --> Router Class Initialized
INFO - 2018-10-22 13:50:43 --> Output Class Initialized
INFO - 2018-10-22 13:50:43 --> Security Class Initialized
DEBUG - 2018-10-22 13:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:50:43 --> CSRF cookie sent
INFO - 2018-10-22 13:50:43 --> CSRF token verified
INFO - 2018-10-22 13:50:43 --> Input Class Initialized
INFO - 2018-10-22 13:50:43 --> Language Class Initialized
INFO - 2018-10-22 13:50:43 --> Loader Class Initialized
INFO - 2018-10-22 13:50:43 --> Helper loaded: url_helper
INFO - 2018-10-22 13:50:43 --> Helper loaded: form_helper
INFO - 2018-10-22 13:50:43 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:50:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:50:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:50:43 --> User Agent Class Initialized
INFO - 2018-10-22 13:50:43 --> Controller Class Initialized
INFO - 2018-10-22 13:50:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:50:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:50:43 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:50:43 --> Pixel_Model class loaded
INFO - 2018-10-22 13:50:43 --> Database Driver Class Initialized
INFO - 2018-10-22 13:50:43 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:50:43 --> Form Validation Class Initialized
INFO - 2018-10-22 13:50:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:50:43 --> Database Driver Class Initialized
INFO - 2018-10-22 13:50:43 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:50:43 --> Config Class Initialized
INFO - 2018-10-22 13:50:43 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:50:43 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:50:43 --> Utf8 Class Initialized
INFO - 2018-10-22 13:50:44 --> URI Class Initialized
INFO - 2018-10-22 13:50:44 --> Router Class Initialized
INFO - 2018-10-22 13:50:44 --> Output Class Initialized
INFO - 2018-10-22 13:50:44 --> Security Class Initialized
DEBUG - 2018-10-22 13:50:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:50:44 --> CSRF cookie sent
INFO - 2018-10-22 13:50:44 --> Input Class Initialized
INFO - 2018-10-22 13:50:44 --> Language Class Initialized
INFO - 2018-10-22 13:50:44 --> Loader Class Initialized
INFO - 2018-10-22 13:50:44 --> Helper loaded: url_helper
INFO - 2018-10-22 13:50:44 --> Helper loaded: form_helper
INFO - 2018-10-22 13:50:44 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:50:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:50:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:50:44 --> User Agent Class Initialized
INFO - 2018-10-22 13:50:44 --> Controller Class Initialized
INFO - 2018-10-22 13:50:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:50:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:50:44 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:50:44 --> Pixel_Model class loaded
INFO - 2018-10-22 13:50:44 --> Database Driver Class Initialized
INFO - 2018-10-22 13:50:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:50:44 --> Database Driver Class Initialized
INFO - 2018-10-22 13:50:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:50:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:50:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:50:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:50:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:50:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:50:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:50:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/trust_info.php
INFO - 2018-10-22 13:50:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:50:44 --> Final output sent to browser
DEBUG - 2018-10-22 13:50:44 --> Total execution time: 0.5658
INFO - 2018-10-22 13:50:49 --> Config Class Initialized
INFO - 2018-10-22 13:50:49 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:50:49 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:50:49 --> Utf8 Class Initialized
INFO - 2018-10-22 13:50:49 --> URI Class Initialized
INFO - 2018-10-22 13:50:49 --> Router Class Initialized
INFO - 2018-10-22 13:50:49 --> Output Class Initialized
INFO - 2018-10-22 13:50:49 --> Security Class Initialized
DEBUG - 2018-10-22 13:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:50:49 --> CSRF cookie sent
INFO - 2018-10-22 13:50:49 --> CSRF token verified
INFO - 2018-10-22 13:50:49 --> Input Class Initialized
INFO - 2018-10-22 13:50:49 --> Language Class Initialized
INFO - 2018-10-22 13:50:49 --> Loader Class Initialized
INFO - 2018-10-22 13:50:49 --> Helper loaded: url_helper
INFO - 2018-10-22 13:50:49 --> Helper loaded: form_helper
INFO - 2018-10-22 13:50:49 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:50:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:50:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:50:50 --> User Agent Class Initialized
INFO - 2018-10-22 13:50:50 --> Controller Class Initialized
INFO - 2018-10-22 13:50:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:50:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:50:50 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:50:50 --> Pixel_Model class loaded
INFO - 2018-10-22 13:50:50 --> Database Driver Class Initialized
INFO - 2018-10-22 13:50:50 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:50:50 --> Form Validation Class Initialized
INFO - 2018-10-22 13:50:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:50:50 --> Database Driver Class Initialized
INFO - 2018-10-22 13:50:50 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:50:50 --> Config Class Initialized
INFO - 2018-10-22 13:50:50 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:50:50 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:50:50 --> Utf8 Class Initialized
INFO - 2018-10-22 13:50:50 --> URI Class Initialized
INFO - 2018-10-22 13:50:50 --> Router Class Initialized
INFO - 2018-10-22 13:50:50 --> Output Class Initialized
INFO - 2018-10-22 13:50:50 --> Security Class Initialized
DEBUG - 2018-10-22 13:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:50:50 --> CSRF cookie sent
INFO - 2018-10-22 13:50:50 --> Input Class Initialized
INFO - 2018-10-22 13:50:50 --> Language Class Initialized
INFO - 2018-10-22 13:50:50 --> Loader Class Initialized
INFO - 2018-10-22 13:50:50 --> Helper loaded: url_helper
INFO - 2018-10-22 13:50:50 --> Helper loaded: form_helper
INFO - 2018-10-22 13:50:50 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:50:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:50:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:50:50 --> User Agent Class Initialized
INFO - 2018-10-22 13:50:50 --> Controller Class Initialized
INFO - 2018-10-22 13:50:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:50:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:50:50 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:50:50 --> Pixel_Model class loaded
INFO - 2018-10-22 13:50:50 --> Database Driver Class Initialized
INFO - 2018-10-22 13:50:50 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:50:50 --> Database Driver Class Initialized
INFO - 2018-10-22 13:50:50 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:50:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:50:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:50:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:50:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:50:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:50:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:50:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/inherited_income.php
INFO - 2018-10-22 13:50:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:50:50 --> Final output sent to browser
DEBUG - 2018-10-22 13:50:50 --> Total execution time: 0.5333
INFO - 2018-10-22 13:50:53 --> Config Class Initialized
INFO - 2018-10-22 13:50:53 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:50:53 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:50:53 --> Utf8 Class Initialized
INFO - 2018-10-22 13:50:53 --> URI Class Initialized
INFO - 2018-10-22 13:50:53 --> Router Class Initialized
INFO - 2018-10-22 13:50:53 --> Output Class Initialized
INFO - 2018-10-22 13:50:53 --> Security Class Initialized
DEBUG - 2018-10-22 13:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:50:53 --> CSRF cookie sent
INFO - 2018-10-22 13:50:53 --> CSRF token verified
INFO - 2018-10-22 13:50:53 --> Input Class Initialized
INFO - 2018-10-22 13:50:53 --> Language Class Initialized
INFO - 2018-10-22 13:50:53 --> Loader Class Initialized
INFO - 2018-10-22 13:50:53 --> Helper loaded: url_helper
INFO - 2018-10-22 13:50:53 --> Helper loaded: form_helper
INFO - 2018-10-22 13:50:53 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:50:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:50:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:50:53 --> User Agent Class Initialized
INFO - 2018-10-22 13:50:53 --> Controller Class Initialized
INFO - 2018-10-22 13:50:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:50:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:50:53 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:50:54 --> Pixel_Model class loaded
INFO - 2018-10-22 13:50:54 --> Database Driver Class Initialized
INFO - 2018-10-22 13:50:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:50:54 --> Form Validation Class Initialized
INFO - 2018-10-22 13:50:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:50:54 --> Database Driver Class Initialized
INFO - 2018-10-22 13:50:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:50:54 --> Config Class Initialized
INFO - 2018-10-22 13:50:54 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:50:54 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:50:54 --> Utf8 Class Initialized
INFO - 2018-10-22 13:50:54 --> URI Class Initialized
INFO - 2018-10-22 13:50:54 --> Router Class Initialized
INFO - 2018-10-22 13:50:54 --> Output Class Initialized
INFO - 2018-10-22 13:50:54 --> Security Class Initialized
DEBUG - 2018-10-22 13:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:50:54 --> CSRF cookie sent
INFO - 2018-10-22 13:50:54 --> Input Class Initialized
INFO - 2018-10-22 13:50:54 --> Language Class Initialized
INFO - 2018-10-22 13:50:54 --> Loader Class Initialized
INFO - 2018-10-22 13:50:54 --> Helper loaded: url_helper
INFO - 2018-10-22 13:50:54 --> Helper loaded: form_helper
INFO - 2018-10-22 13:50:54 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:50:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:50:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:50:54 --> User Agent Class Initialized
INFO - 2018-10-22 13:50:54 --> Controller Class Initialized
INFO - 2018-10-22 13:50:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:50:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:50:54 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:50:54 --> Pixel_Model class loaded
INFO - 2018-10-22 13:50:54 --> Database Driver Class Initialized
INFO - 2018-10-22 13:50:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:50:54 --> Database Driver Class Initialized
INFO - 2018-10-22 13:50:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:50:54 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:50:54 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:50:54 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:50:54 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:50:54 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:50:54 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:50:54 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/shift_work.php
INFO - 2018-10-22 13:50:54 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:50:54 --> Final output sent to browser
DEBUG - 2018-10-22 13:50:54 --> Total execution time: 0.5579
INFO - 2018-10-22 13:51:01 --> Config Class Initialized
INFO - 2018-10-22 13:51:01 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:51:01 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:51:01 --> Utf8 Class Initialized
INFO - 2018-10-22 13:51:01 --> URI Class Initialized
INFO - 2018-10-22 13:51:01 --> Router Class Initialized
INFO - 2018-10-22 13:51:01 --> Output Class Initialized
INFO - 2018-10-22 13:51:01 --> Security Class Initialized
DEBUG - 2018-10-22 13:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:51:01 --> CSRF cookie sent
INFO - 2018-10-22 13:51:01 --> CSRF token verified
INFO - 2018-10-22 13:51:01 --> Input Class Initialized
INFO - 2018-10-22 13:51:01 --> Language Class Initialized
INFO - 2018-10-22 13:51:01 --> Loader Class Initialized
INFO - 2018-10-22 13:51:01 --> Helper loaded: url_helper
INFO - 2018-10-22 13:51:01 --> Helper loaded: form_helper
INFO - 2018-10-22 13:51:01 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:51:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:51:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:51:01 --> User Agent Class Initialized
INFO - 2018-10-22 13:51:01 --> Controller Class Initialized
INFO - 2018-10-22 13:51:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:51:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:51:01 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:51:01 --> Pixel_Model class loaded
INFO - 2018-10-22 13:51:01 --> Database Driver Class Initialized
INFO - 2018-10-22 13:51:01 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:51:01 --> Form Validation Class Initialized
INFO - 2018-10-22 13:51:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:51:01 --> Database Driver Class Initialized
INFO - 2018-10-22 13:51:01 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:51:01 --> Config Class Initialized
INFO - 2018-10-22 13:51:01 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:51:01 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:51:02 --> Utf8 Class Initialized
INFO - 2018-10-22 13:51:02 --> URI Class Initialized
INFO - 2018-10-22 13:51:02 --> Router Class Initialized
INFO - 2018-10-22 13:51:02 --> Output Class Initialized
INFO - 2018-10-22 13:51:02 --> Security Class Initialized
DEBUG - 2018-10-22 13:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:51:02 --> CSRF cookie sent
INFO - 2018-10-22 13:51:02 --> Input Class Initialized
INFO - 2018-10-22 13:51:02 --> Language Class Initialized
INFO - 2018-10-22 13:51:02 --> Loader Class Initialized
INFO - 2018-10-22 13:51:02 --> Helper loaded: url_helper
INFO - 2018-10-22 13:51:02 --> Helper loaded: form_helper
INFO - 2018-10-22 13:51:02 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:51:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:51:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:51:02 --> User Agent Class Initialized
INFO - 2018-10-22 13:51:02 --> Controller Class Initialized
INFO - 2018-10-22 13:51:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:51:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:51:02 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:51:02 --> Pixel_Model class loaded
INFO - 2018-10-22 13:51:02 --> Database Driver Class Initialized
INFO - 2018-10-22 13:51:02 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:51:02 --> Database Driver Class Initialized
INFO - 2018-10-22 13:51:02 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:51:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:51:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:51:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:51:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:51:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:51:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:51:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/night_without_s.php
INFO - 2018-10-22 13:51:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:51:02 --> Final output sent to browser
DEBUG - 2018-10-22 13:51:02 --> Total execution time: 0.5819
INFO - 2018-10-22 13:51:05 --> Config Class Initialized
INFO - 2018-10-22 13:51:05 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:51:05 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:51:05 --> Utf8 Class Initialized
INFO - 2018-10-22 13:51:06 --> URI Class Initialized
INFO - 2018-10-22 13:51:06 --> Router Class Initialized
INFO - 2018-10-22 13:51:06 --> Output Class Initialized
INFO - 2018-10-22 13:51:06 --> Security Class Initialized
DEBUG - 2018-10-22 13:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:51:06 --> CSRF cookie sent
INFO - 2018-10-22 13:51:06 --> CSRF token verified
INFO - 2018-10-22 13:51:06 --> Input Class Initialized
INFO - 2018-10-22 13:51:06 --> Language Class Initialized
INFO - 2018-10-22 13:51:06 --> Loader Class Initialized
INFO - 2018-10-22 13:51:06 --> Helper loaded: url_helper
INFO - 2018-10-22 13:51:06 --> Helper loaded: form_helper
INFO - 2018-10-22 13:51:06 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:51:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:51:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:51:06 --> User Agent Class Initialized
INFO - 2018-10-22 13:51:06 --> Controller Class Initialized
INFO - 2018-10-22 13:51:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:51:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:51:06 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:51:06 --> Pixel_Model class loaded
INFO - 2018-10-22 13:51:06 --> Database Driver Class Initialized
INFO - 2018-10-22 13:51:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:51:06 --> Form Validation Class Initialized
INFO - 2018-10-22 13:51:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:51:06 --> Database Driver Class Initialized
INFO - 2018-10-22 13:51:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:51:06 --> Config Class Initialized
INFO - 2018-10-22 13:51:06 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:51:06 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:51:06 --> Utf8 Class Initialized
INFO - 2018-10-22 13:51:06 --> URI Class Initialized
INFO - 2018-10-22 13:51:06 --> Router Class Initialized
INFO - 2018-10-22 13:51:06 --> Output Class Initialized
INFO - 2018-10-22 13:51:06 --> Security Class Initialized
DEBUG - 2018-10-22 13:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:51:06 --> CSRF cookie sent
INFO - 2018-10-22 13:51:06 --> Input Class Initialized
INFO - 2018-10-22 13:51:06 --> Language Class Initialized
INFO - 2018-10-22 13:51:06 --> Loader Class Initialized
INFO - 2018-10-22 13:51:06 --> Helper loaded: url_helper
INFO - 2018-10-22 13:51:06 --> Helper loaded: form_helper
INFO - 2018-10-22 13:51:06 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:51:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:51:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:51:06 --> User Agent Class Initialized
INFO - 2018-10-22 13:51:06 --> Controller Class Initialized
INFO - 2018-10-22 13:51:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:51:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:51:06 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:51:06 --> Pixel_Model class loaded
INFO - 2018-10-22 13:51:06 --> Database Driver Class Initialized
INFO - 2018-10-22 13:51:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:51:06 --> Database Driver Class Initialized
INFO - 2018-10-22 13:51:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:51:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:51:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:51:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:51:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:51:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:51:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:51:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/have_date.php
INFO - 2018-10-22 13:51:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:51:07 --> Final output sent to browser
DEBUG - 2018-10-22 13:51:07 --> Total execution time: 0.5580
INFO - 2018-10-22 13:51:09 --> Config Class Initialized
INFO - 2018-10-22 13:51:09 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:51:09 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:51:09 --> Utf8 Class Initialized
INFO - 2018-10-22 13:51:09 --> URI Class Initialized
INFO - 2018-10-22 13:51:09 --> Router Class Initialized
INFO - 2018-10-22 13:51:09 --> Output Class Initialized
INFO - 2018-10-22 13:51:09 --> Security Class Initialized
DEBUG - 2018-10-22 13:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:51:09 --> CSRF cookie sent
INFO - 2018-10-22 13:51:09 --> CSRF token verified
INFO - 2018-10-22 13:51:09 --> Input Class Initialized
INFO - 2018-10-22 13:51:09 --> Language Class Initialized
INFO - 2018-10-22 13:51:09 --> Loader Class Initialized
INFO - 2018-10-22 13:51:09 --> Helper loaded: url_helper
INFO - 2018-10-22 13:51:09 --> Helper loaded: form_helper
INFO - 2018-10-22 13:51:09 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:51:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:51:10 --> User Agent Class Initialized
INFO - 2018-10-22 13:51:10 --> Controller Class Initialized
INFO - 2018-10-22 13:51:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:51:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:51:10 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:51:10 --> Pixel_Model class loaded
INFO - 2018-10-22 13:51:10 --> Database Driver Class Initialized
INFO - 2018-10-22 13:51:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:51:10 --> Form Validation Class Initialized
INFO - 2018-10-22 13:51:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:51:10 --> Database Driver Class Initialized
INFO - 2018-10-22 13:51:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:51:10 --> Config Class Initialized
INFO - 2018-10-22 13:51:10 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:51:10 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:51:10 --> Utf8 Class Initialized
INFO - 2018-10-22 13:51:10 --> URI Class Initialized
INFO - 2018-10-22 13:51:10 --> Router Class Initialized
INFO - 2018-10-22 13:51:10 --> Output Class Initialized
INFO - 2018-10-22 13:51:10 --> Security Class Initialized
DEBUG - 2018-10-22 13:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:51:10 --> CSRF cookie sent
INFO - 2018-10-22 13:51:10 --> Input Class Initialized
INFO - 2018-10-22 13:51:10 --> Language Class Initialized
INFO - 2018-10-22 13:51:10 --> Loader Class Initialized
INFO - 2018-10-22 13:51:10 --> Helper loaded: url_helper
INFO - 2018-10-22 13:51:10 --> Helper loaded: form_helper
INFO - 2018-10-22 13:51:10 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:51:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:51:10 --> User Agent Class Initialized
INFO - 2018-10-22 13:51:10 --> Controller Class Initialized
INFO - 2018-10-22 13:51:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:51:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:51:10 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:51:10 --> Pixel_Model class loaded
INFO - 2018-10-22 13:51:10 --> Database Driver Class Initialized
INFO - 2018-10-22 13:51:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:51:10 --> Database Driver Class Initialized
INFO - 2018-10-22 13:51:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:51:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:51:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:51:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:51:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:51:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:51:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:51:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/nights_not_home.php
INFO - 2018-10-22 13:51:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:51:10 --> Final output sent to browser
DEBUG - 2018-10-22 13:51:10 --> Total execution time: 0.6420
INFO - 2018-10-22 13:51:12 --> Config Class Initialized
INFO - 2018-10-22 13:51:12 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:51:12 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:51:12 --> Utf8 Class Initialized
INFO - 2018-10-22 13:51:12 --> URI Class Initialized
INFO - 2018-10-22 13:51:13 --> Router Class Initialized
INFO - 2018-10-22 13:51:13 --> Output Class Initialized
INFO - 2018-10-22 13:51:13 --> Security Class Initialized
DEBUG - 2018-10-22 13:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:51:13 --> CSRF cookie sent
INFO - 2018-10-22 13:51:13 --> CSRF token verified
INFO - 2018-10-22 13:51:13 --> Input Class Initialized
INFO - 2018-10-22 13:51:13 --> Language Class Initialized
INFO - 2018-10-22 13:51:13 --> Loader Class Initialized
INFO - 2018-10-22 13:51:13 --> Helper loaded: url_helper
INFO - 2018-10-22 13:51:13 --> Helper loaded: form_helper
INFO - 2018-10-22 13:51:13 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:51:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:51:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:51:13 --> User Agent Class Initialized
INFO - 2018-10-22 13:51:13 --> Controller Class Initialized
INFO - 2018-10-22 13:51:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:51:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:51:13 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:51:13 --> Pixel_Model class loaded
INFO - 2018-10-22 13:51:13 --> Database Driver Class Initialized
INFO - 2018-10-22 13:51:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:51:13 --> Form Validation Class Initialized
INFO - 2018-10-22 13:51:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:51:13 --> Database Driver Class Initialized
INFO - 2018-10-22 13:51:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:51:13 --> Config Class Initialized
INFO - 2018-10-22 13:51:13 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:51:13 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:51:13 --> Utf8 Class Initialized
INFO - 2018-10-22 13:51:13 --> URI Class Initialized
INFO - 2018-10-22 13:51:13 --> Router Class Initialized
INFO - 2018-10-22 13:51:13 --> Output Class Initialized
INFO - 2018-10-22 13:51:13 --> Security Class Initialized
DEBUG - 2018-10-22 13:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:51:13 --> CSRF cookie sent
INFO - 2018-10-22 13:51:13 --> Input Class Initialized
INFO - 2018-10-22 13:51:13 --> Language Class Initialized
INFO - 2018-10-22 13:51:13 --> Loader Class Initialized
INFO - 2018-10-22 13:51:13 --> Helper loaded: url_helper
INFO - 2018-10-22 13:51:13 --> Helper loaded: form_helper
INFO - 2018-10-22 13:51:13 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:51:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:51:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:51:13 --> User Agent Class Initialized
INFO - 2018-10-22 13:51:13 --> Controller Class Initialized
INFO - 2018-10-22 13:51:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:51:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:51:13 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:51:13 --> Pixel_Model class loaded
INFO - 2018-10-22 13:51:13 --> Database Driver Class Initialized
INFO - 2018-10-22 13:51:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:51:13 --> Database Driver Class Initialized
INFO - 2018-10-22 13:51:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:51:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:51:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:51:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:51:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:51:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:51:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:51:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/s_nights_not_home.php
INFO - 2018-10-22 13:51:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:51:14 --> Final output sent to browser
DEBUG - 2018-10-22 13:51:14 --> Total execution time: 0.5679
INFO - 2018-10-22 13:51:18 --> Config Class Initialized
INFO - 2018-10-22 13:51:18 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:51:18 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:51:18 --> Utf8 Class Initialized
INFO - 2018-10-22 13:51:18 --> URI Class Initialized
INFO - 2018-10-22 13:51:18 --> Router Class Initialized
INFO - 2018-10-22 13:51:18 --> Output Class Initialized
INFO - 2018-10-22 13:51:18 --> Security Class Initialized
DEBUG - 2018-10-22 13:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:51:18 --> CSRF cookie sent
INFO - 2018-10-22 13:51:18 --> CSRF token verified
INFO - 2018-10-22 13:51:18 --> Input Class Initialized
INFO - 2018-10-22 13:51:18 --> Language Class Initialized
INFO - 2018-10-22 13:51:18 --> Loader Class Initialized
INFO - 2018-10-22 13:51:18 --> Helper loaded: url_helper
INFO - 2018-10-22 13:51:18 --> Helper loaded: form_helper
INFO - 2018-10-22 13:51:18 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:51:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:51:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:51:18 --> User Agent Class Initialized
INFO - 2018-10-22 13:51:18 --> Controller Class Initialized
INFO - 2018-10-22 13:51:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:51:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:51:19 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:51:19 --> Pixel_Model class loaded
INFO - 2018-10-22 13:51:19 --> Database Driver Class Initialized
INFO - 2018-10-22 13:51:19 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:51:19 --> Form Validation Class Initialized
INFO - 2018-10-22 13:51:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:51:19 --> Database Driver Class Initialized
INFO - 2018-10-22 13:51:19 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:51:19 --> Config Class Initialized
INFO - 2018-10-22 13:51:19 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:51:19 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:51:19 --> Utf8 Class Initialized
INFO - 2018-10-22 13:51:19 --> URI Class Initialized
INFO - 2018-10-22 13:51:19 --> Router Class Initialized
INFO - 2018-10-22 13:51:19 --> Output Class Initialized
INFO - 2018-10-22 13:51:19 --> Security Class Initialized
DEBUG - 2018-10-22 13:51:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:51:19 --> CSRF cookie sent
INFO - 2018-10-22 13:51:19 --> Input Class Initialized
INFO - 2018-10-22 13:51:19 --> Language Class Initialized
INFO - 2018-10-22 13:51:19 --> Loader Class Initialized
INFO - 2018-10-22 13:51:19 --> Helper loaded: url_helper
INFO - 2018-10-22 13:51:19 --> Helper loaded: form_helper
INFO - 2018-10-22 13:51:19 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:51:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:51:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:51:19 --> User Agent Class Initialized
INFO - 2018-10-22 13:51:19 --> Controller Class Initialized
INFO - 2018-10-22 13:51:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:51:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:51:19 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:51:19 --> Pixel_Model class loaded
INFO - 2018-10-22 13:51:19 --> Database Driver Class Initialized
INFO - 2018-10-22 13:51:19 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:51:19 --> Database Driver Class Initialized
INFO - 2018-10-22 13:51:19 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:51:19 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:51:19 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:51:19 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:51:19 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:51:19 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:51:19 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:51:19 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/s_nights_without_you.php
INFO - 2018-10-22 13:51:19 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:51:19 --> Final output sent to browser
DEBUG - 2018-10-22 13:51:19 --> Total execution time: 0.5642
INFO - 2018-10-22 13:51:22 --> Config Class Initialized
INFO - 2018-10-22 13:51:22 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:51:22 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:51:22 --> Utf8 Class Initialized
INFO - 2018-10-22 13:51:22 --> URI Class Initialized
INFO - 2018-10-22 13:51:22 --> Router Class Initialized
INFO - 2018-10-22 13:51:22 --> Output Class Initialized
INFO - 2018-10-22 13:51:22 --> Security Class Initialized
DEBUG - 2018-10-22 13:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:51:22 --> CSRF cookie sent
INFO - 2018-10-22 13:51:22 --> CSRF token verified
INFO - 2018-10-22 13:51:22 --> Input Class Initialized
INFO - 2018-10-22 13:51:22 --> Language Class Initialized
INFO - 2018-10-22 13:51:22 --> Loader Class Initialized
INFO - 2018-10-22 13:51:22 --> Helper loaded: url_helper
INFO - 2018-10-22 13:51:22 --> Helper loaded: form_helper
INFO - 2018-10-22 13:51:22 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:51:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:51:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:51:22 --> User Agent Class Initialized
INFO - 2018-10-22 13:51:22 --> Controller Class Initialized
INFO - 2018-10-22 13:51:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:51:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:51:22 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:51:22 --> Pixel_Model class loaded
INFO - 2018-10-22 13:51:22 --> Database Driver Class Initialized
INFO - 2018-10-22 13:51:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:51:23 --> Form Validation Class Initialized
INFO - 2018-10-22 13:51:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:51:23 --> Database Driver Class Initialized
INFO - 2018-10-22 13:51:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:51:23 --> Config Class Initialized
INFO - 2018-10-22 13:51:23 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:51:23 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:51:23 --> Utf8 Class Initialized
INFO - 2018-10-22 13:51:23 --> URI Class Initialized
INFO - 2018-10-22 13:51:23 --> Router Class Initialized
INFO - 2018-10-22 13:51:23 --> Output Class Initialized
INFO - 2018-10-22 13:51:23 --> Security Class Initialized
DEBUG - 2018-10-22 13:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:51:23 --> CSRF cookie sent
INFO - 2018-10-22 13:51:23 --> Input Class Initialized
INFO - 2018-10-22 13:51:23 --> Language Class Initialized
INFO - 2018-10-22 13:51:23 --> Loader Class Initialized
INFO - 2018-10-22 13:51:23 --> Helper loaded: url_helper
INFO - 2018-10-22 13:51:23 --> Helper loaded: form_helper
INFO - 2018-10-22 13:51:23 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:51:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:51:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:51:23 --> User Agent Class Initialized
INFO - 2018-10-22 13:51:23 --> Controller Class Initialized
INFO - 2018-10-22 13:51:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:51:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:51:23 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:51:23 --> Pixel_Model class loaded
INFO - 2018-10-22 13:51:23 --> Database Driver Class Initialized
INFO - 2018-10-22 13:51:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:51:23 --> Database Driver Class Initialized
INFO - 2018-10-22 13:51:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:51:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:51:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:51:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:51:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:51:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:51:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:51:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/alcoholic_drinks_per_week.php
INFO - 2018-10-22 13:51:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:51:23 --> Final output sent to browser
DEBUG - 2018-10-22 13:51:23 --> Total execution time: 0.5682
INFO - 2018-10-22 13:51:26 --> Config Class Initialized
INFO - 2018-10-22 13:51:26 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:51:26 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:51:26 --> Utf8 Class Initialized
INFO - 2018-10-22 13:51:26 --> URI Class Initialized
INFO - 2018-10-22 13:51:26 --> Router Class Initialized
INFO - 2018-10-22 13:51:26 --> Output Class Initialized
INFO - 2018-10-22 13:51:26 --> Security Class Initialized
DEBUG - 2018-10-22 13:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:51:26 --> CSRF cookie sent
INFO - 2018-10-22 13:51:26 --> CSRF token verified
INFO - 2018-10-22 13:51:26 --> Input Class Initialized
INFO - 2018-10-22 13:51:26 --> Language Class Initialized
INFO - 2018-10-22 13:51:26 --> Loader Class Initialized
INFO - 2018-10-22 13:51:26 --> Helper loaded: url_helper
INFO - 2018-10-22 13:51:26 --> Helper loaded: form_helper
INFO - 2018-10-22 13:51:26 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:51:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:51:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:51:26 --> User Agent Class Initialized
INFO - 2018-10-22 13:51:26 --> Controller Class Initialized
INFO - 2018-10-22 13:51:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:51:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:51:26 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:51:26 --> Pixel_Model class loaded
INFO - 2018-10-22 13:51:26 --> Database Driver Class Initialized
INFO - 2018-10-22 13:51:26 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:51:26 --> Form Validation Class Initialized
INFO - 2018-10-22 13:51:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:51:26 --> Database Driver Class Initialized
INFO - 2018-10-22 13:51:26 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:51:26 --> Config Class Initialized
INFO - 2018-10-22 13:51:26 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:51:26 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:51:26 --> Utf8 Class Initialized
INFO - 2018-10-22 13:51:26 --> URI Class Initialized
INFO - 2018-10-22 13:51:26 --> Router Class Initialized
INFO - 2018-10-22 13:51:26 --> Output Class Initialized
INFO - 2018-10-22 13:51:26 --> Security Class Initialized
DEBUG - 2018-10-22 13:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:51:26 --> CSRF cookie sent
INFO - 2018-10-22 13:51:26 --> Input Class Initialized
INFO - 2018-10-22 13:51:26 --> Language Class Initialized
INFO - 2018-10-22 13:51:26 --> Loader Class Initialized
INFO - 2018-10-22 13:51:26 --> Helper loaded: url_helper
INFO - 2018-10-22 13:51:26 --> Helper loaded: form_helper
INFO - 2018-10-22 13:51:26 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:51:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:51:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:51:26 --> User Agent Class Initialized
INFO - 2018-10-22 13:51:26 --> Controller Class Initialized
INFO - 2018-10-22 13:51:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:51:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:51:26 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:51:26 --> Pixel_Model class loaded
INFO - 2018-10-22 13:51:26 --> Database Driver Class Initialized
INFO - 2018-10-22 13:51:26 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:51:26 --> Database Driver Class Initialized
INFO - 2018-10-22 13:51:26 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:51:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:51:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:51:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:51:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:51:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:51:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:51:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/have_drugs.php
INFO - 2018-10-22 13:51:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:51:27 --> Final output sent to browser
DEBUG - 2018-10-22 13:51:27 --> Total execution time: 0.5741
INFO - 2018-10-22 13:51:29 --> Config Class Initialized
INFO - 2018-10-22 13:51:29 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:51:29 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:51:29 --> Utf8 Class Initialized
INFO - 2018-10-22 13:51:30 --> URI Class Initialized
INFO - 2018-10-22 13:51:30 --> Router Class Initialized
INFO - 2018-10-22 13:51:30 --> Output Class Initialized
INFO - 2018-10-22 13:51:30 --> Security Class Initialized
DEBUG - 2018-10-22 13:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:51:30 --> CSRF cookie sent
INFO - 2018-10-22 13:51:30 --> CSRF token verified
INFO - 2018-10-22 13:51:30 --> Input Class Initialized
INFO - 2018-10-22 13:51:30 --> Language Class Initialized
INFO - 2018-10-22 13:51:30 --> Loader Class Initialized
INFO - 2018-10-22 13:51:30 --> Helper loaded: url_helper
INFO - 2018-10-22 13:51:30 --> Helper loaded: form_helper
INFO - 2018-10-22 13:51:30 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:51:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:51:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:51:30 --> User Agent Class Initialized
INFO - 2018-10-22 13:51:30 --> Controller Class Initialized
INFO - 2018-10-22 13:51:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:51:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:51:30 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:51:30 --> Pixel_Model class loaded
INFO - 2018-10-22 13:51:30 --> Database Driver Class Initialized
INFO - 2018-10-22 13:51:30 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:51:30 --> Form Validation Class Initialized
INFO - 2018-10-22 13:51:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:51:30 --> Database Driver Class Initialized
INFO - 2018-10-22 13:51:30 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:51:30 --> Config Class Initialized
INFO - 2018-10-22 13:51:30 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:51:30 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:51:30 --> Utf8 Class Initialized
INFO - 2018-10-22 13:51:30 --> URI Class Initialized
INFO - 2018-10-22 13:51:30 --> Router Class Initialized
INFO - 2018-10-22 13:51:30 --> Output Class Initialized
INFO - 2018-10-22 13:51:30 --> Security Class Initialized
DEBUG - 2018-10-22 13:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:51:30 --> CSRF cookie sent
INFO - 2018-10-22 13:51:30 --> Input Class Initialized
INFO - 2018-10-22 13:51:30 --> Language Class Initialized
INFO - 2018-10-22 13:51:30 --> Loader Class Initialized
INFO - 2018-10-22 13:51:30 --> Helper loaded: url_helper
INFO - 2018-10-22 13:51:30 --> Helper loaded: form_helper
INFO - 2018-10-22 13:51:30 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:51:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:51:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:51:30 --> User Agent Class Initialized
INFO - 2018-10-22 13:51:30 --> Controller Class Initialized
INFO - 2018-10-22 13:51:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:51:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:51:30 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:51:30 --> Pixel_Model class loaded
INFO - 2018-10-22 13:51:30 --> Database Driver Class Initialized
INFO - 2018-10-22 13:51:30 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:51:30 --> Database Driver Class Initialized
INFO - 2018-10-22 13:51:30 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:51:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:51:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:51:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:51:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:51:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:51:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:51:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/has_addiction_problem.php
INFO - 2018-10-22 13:51:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:51:31 --> Final output sent to browser
DEBUG - 2018-10-22 13:51:31 --> Total execution time: 0.5615
INFO - 2018-10-22 13:51:34 --> Config Class Initialized
INFO - 2018-10-22 13:51:34 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:51:34 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:51:34 --> Utf8 Class Initialized
INFO - 2018-10-22 13:51:34 --> URI Class Initialized
INFO - 2018-10-22 13:51:34 --> Router Class Initialized
INFO - 2018-10-22 13:51:34 --> Output Class Initialized
INFO - 2018-10-22 13:51:34 --> Security Class Initialized
DEBUG - 2018-10-22 13:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:51:34 --> CSRF cookie sent
INFO - 2018-10-22 13:51:34 --> CSRF token verified
INFO - 2018-10-22 13:51:34 --> Input Class Initialized
INFO - 2018-10-22 13:51:34 --> Language Class Initialized
INFO - 2018-10-22 13:51:34 --> Loader Class Initialized
INFO - 2018-10-22 13:51:34 --> Helper loaded: url_helper
INFO - 2018-10-22 13:51:34 --> Helper loaded: form_helper
INFO - 2018-10-22 13:51:34 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:51:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:51:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:51:34 --> User Agent Class Initialized
INFO - 2018-10-22 13:51:34 --> Controller Class Initialized
INFO - 2018-10-22 13:51:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:51:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:51:34 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:51:34 --> Pixel_Model class loaded
INFO - 2018-10-22 13:51:34 --> Database Driver Class Initialized
INFO - 2018-10-22 13:51:34 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:51:34 --> Form Validation Class Initialized
INFO - 2018-10-22 13:51:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:51:34 --> Database Driver Class Initialized
INFO - 2018-10-22 13:51:34 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:51:34 --> Config Class Initialized
INFO - 2018-10-22 13:51:34 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:51:34 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:51:34 --> Utf8 Class Initialized
INFO - 2018-10-22 13:51:34 --> URI Class Initialized
INFO - 2018-10-22 13:51:34 --> Router Class Initialized
INFO - 2018-10-22 13:51:34 --> Output Class Initialized
INFO - 2018-10-22 13:51:34 --> Security Class Initialized
DEBUG - 2018-10-22 13:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:51:34 --> CSRF cookie sent
INFO - 2018-10-22 13:51:34 --> Input Class Initialized
INFO - 2018-10-22 13:51:34 --> Language Class Initialized
INFO - 2018-10-22 13:51:34 --> Loader Class Initialized
INFO - 2018-10-22 13:51:34 --> Helper loaded: url_helper
INFO - 2018-10-22 13:51:34 --> Helper loaded: form_helper
INFO - 2018-10-22 13:51:34 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:51:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:51:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:51:34 --> User Agent Class Initialized
INFO - 2018-10-22 13:51:34 --> Controller Class Initialized
INFO - 2018-10-22 13:51:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:51:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:51:34 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:51:34 --> Pixel_Model class loaded
INFO - 2018-10-22 13:51:35 --> Database Driver Class Initialized
INFO - 2018-10-22 13:51:35 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:51:35 --> Database Driver Class Initialized
INFO - 2018-10-22 13:51:35 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:51:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:51:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:51:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:51:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:51:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:51:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:51:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/have_hit_s.php
INFO - 2018-10-22 13:51:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:51:35 --> Final output sent to browser
DEBUG - 2018-10-22 13:51:35 --> Total execution time: 0.5943
INFO - 2018-10-22 13:51:38 --> Config Class Initialized
INFO - 2018-10-22 13:51:38 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:51:38 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:51:38 --> Utf8 Class Initialized
INFO - 2018-10-22 13:51:38 --> URI Class Initialized
INFO - 2018-10-22 13:51:38 --> Router Class Initialized
INFO - 2018-10-22 13:51:38 --> Output Class Initialized
INFO - 2018-10-22 13:51:38 --> Security Class Initialized
DEBUG - 2018-10-22 13:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:51:38 --> CSRF cookie sent
INFO - 2018-10-22 13:51:38 --> CSRF token verified
INFO - 2018-10-22 13:51:38 --> Input Class Initialized
INFO - 2018-10-22 13:51:38 --> Language Class Initialized
INFO - 2018-10-22 13:51:38 --> Loader Class Initialized
INFO - 2018-10-22 13:51:38 --> Helper loaded: url_helper
INFO - 2018-10-22 13:51:38 --> Helper loaded: form_helper
INFO - 2018-10-22 13:51:38 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:51:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:51:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:51:38 --> User Agent Class Initialized
INFO - 2018-10-22 13:51:38 --> Controller Class Initialized
INFO - 2018-10-22 13:51:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:51:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:51:38 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:51:38 --> Pixel_Model class loaded
INFO - 2018-10-22 13:51:38 --> Database Driver Class Initialized
INFO - 2018-10-22 13:51:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:51:38 --> Form Validation Class Initialized
INFO - 2018-10-22 13:51:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:51:38 --> Database Driver Class Initialized
INFO - 2018-10-22 13:51:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:51:38 --> Config Class Initialized
INFO - 2018-10-22 13:51:38 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:51:38 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:51:38 --> Utf8 Class Initialized
INFO - 2018-10-22 13:51:38 --> URI Class Initialized
INFO - 2018-10-22 13:51:38 --> Router Class Initialized
INFO - 2018-10-22 13:51:38 --> Output Class Initialized
INFO - 2018-10-22 13:51:38 --> Security Class Initialized
DEBUG - 2018-10-22 13:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:51:39 --> CSRF cookie sent
INFO - 2018-10-22 13:51:39 --> Input Class Initialized
INFO - 2018-10-22 13:51:39 --> Language Class Initialized
INFO - 2018-10-22 13:51:39 --> Loader Class Initialized
INFO - 2018-10-22 13:51:39 --> Helper loaded: url_helper
INFO - 2018-10-22 13:51:39 --> Helper loaded: form_helper
INFO - 2018-10-22 13:51:39 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:51:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:51:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:51:39 --> User Agent Class Initialized
INFO - 2018-10-22 13:51:39 --> Controller Class Initialized
INFO - 2018-10-22 13:51:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:51:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:51:39 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:51:39 --> Pixel_Model class loaded
INFO - 2018-10-22 13:51:39 --> Database Driver Class Initialized
INFO - 2018-10-22 13:51:39 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:51:39 --> Database Driver Class Initialized
INFO - 2018-10-22 13:51:39 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:51:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:51:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:51:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:51:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:51:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:51:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:51:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/financial_control.php
INFO - 2018-10-22 13:51:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:51:39 --> Final output sent to browser
DEBUG - 2018-10-22 13:51:39 --> Total execution time: 0.5905
INFO - 2018-10-22 13:51:44 --> Config Class Initialized
INFO - 2018-10-22 13:51:44 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:51:44 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:51:44 --> Utf8 Class Initialized
INFO - 2018-10-22 13:51:44 --> URI Class Initialized
INFO - 2018-10-22 13:51:44 --> Router Class Initialized
INFO - 2018-10-22 13:51:44 --> Output Class Initialized
INFO - 2018-10-22 13:51:44 --> Security Class Initialized
DEBUG - 2018-10-22 13:51:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:51:44 --> CSRF cookie sent
INFO - 2018-10-22 13:51:44 --> CSRF token verified
INFO - 2018-10-22 13:51:44 --> Input Class Initialized
INFO - 2018-10-22 13:51:44 --> Language Class Initialized
INFO - 2018-10-22 13:51:44 --> Loader Class Initialized
INFO - 2018-10-22 13:51:44 --> Helper loaded: url_helper
INFO - 2018-10-22 13:51:44 --> Helper loaded: form_helper
INFO - 2018-10-22 13:51:44 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:51:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:51:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:51:44 --> User Agent Class Initialized
INFO - 2018-10-22 13:51:44 --> Controller Class Initialized
INFO - 2018-10-22 13:51:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:51:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:51:44 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:51:44 --> Pixel_Model class loaded
INFO - 2018-10-22 13:51:44 --> Database Driver Class Initialized
INFO - 2018-10-22 13:51:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:51:44 --> Form Validation Class Initialized
INFO - 2018-10-22 13:51:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:51:44 --> Database Driver Class Initialized
INFO - 2018-10-22 13:51:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:51:44 --> Config Class Initialized
INFO - 2018-10-22 13:51:44 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:51:44 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:51:44 --> Utf8 Class Initialized
INFO - 2018-10-22 13:51:44 --> URI Class Initialized
INFO - 2018-10-22 13:51:44 --> Router Class Initialized
INFO - 2018-10-22 13:51:44 --> Output Class Initialized
INFO - 2018-10-22 13:51:44 --> Security Class Initialized
DEBUG - 2018-10-22 13:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:51:45 --> CSRF cookie sent
INFO - 2018-10-22 13:51:45 --> Input Class Initialized
INFO - 2018-10-22 13:51:45 --> Language Class Initialized
INFO - 2018-10-22 13:51:45 --> Loader Class Initialized
INFO - 2018-10-22 13:51:45 --> Helper loaded: url_helper
INFO - 2018-10-22 13:51:45 --> Helper loaded: form_helper
INFO - 2018-10-22 13:51:45 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:51:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:51:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:51:45 --> User Agent Class Initialized
INFO - 2018-10-22 13:51:45 --> Controller Class Initialized
INFO - 2018-10-22 13:51:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:51:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:51:45 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:51:45 --> Pixel_Model class loaded
INFO - 2018-10-22 13:51:45 --> Database Driver Class Initialized
INFO - 2018-10-22 13:51:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:51:45 --> Database Driver Class Initialized
INFO - 2018-10-22 13:51:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:51:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:51:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:51:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:51:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:51:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:51:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:51:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/has_hit_kids.php
INFO - 2018-10-22 13:51:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:51:45 --> Final output sent to browser
DEBUG - 2018-10-22 13:51:45 --> Total execution time: 0.5673
INFO - 2018-10-22 13:51:48 --> Config Class Initialized
INFO - 2018-10-22 13:51:48 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:51:48 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:51:48 --> Utf8 Class Initialized
INFO - 2018-10-22 13:51:48 --> URI Class Initialized
INFO - 2018-10-22 13:51:48 --> Router Class Initialized
INFO - 2018-10-22 13:51:48 --> Output Class Initialized
INFO - 2018-10-22 13:51:48 --> Security Class Initialized
DEBUG - 2018-10-22 13:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:51:48 --> CSRF cookie sent
INFO - 2018-10-22 13:51:48 --> CSRF token verified
INFO - 2018-10-22 13:51:48 --> Input Class Initialized
INFO - 2018-10-22 13:51:48 --> Language Class Initialized
INFO - 2018-10-22 13:51:48 --> Loader Class Initialized
INFO - 2018-10-22 13:51:48 --> Helper loaded: url_helper
INFO - 2018-10-22 13:51:48 --> Helper loaded: form_helper
INFO - 2018-10-22 13:51:49 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:51:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:51:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:51:49 --> User Agent Class Initialized
INFO - 2018-10-22 13:51:49 --> Controller Class Initialized
INFO - 2018-10-22 13:51:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:51:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:51:49 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:51:49 --> Pixel_Model class loaded
INFO - 2018-10-22 13:51:49 --> Database Driver Class Initialized
INFO - 2018-10-22 13:51:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:51:49 --> Form Validation Class Initialized
INFO - 2018-10-22 13:51:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:51:49 --> Database Driver Class Initialized
INFO - 2018-10-22 13:51:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:51:49 --> Config Class Initialized
INFO - 2018-10-22 13:51:49 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:51:49 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:51:49 --> Utf8 Class Initialized
INFO - 2018-10-22 13:51:49 --> URI Class Initialized
INFO - 2018-10-22 13:51:49 --> Router Class Initialized
INFO - 2018-10-22 13:51:49 --> Output Class Initialized
INFO - 2018-10-22 13:51:49 --> Security Class Initialized
DEBUG - 2018-10-22 13:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:51:49 --> CSRF cookie sent
INFO - 2018-10-22 13:51:49 --> Input Class Initialized
INFO - 2018-10-22 13:51:49 --> Language Class Initialized
INFO - 2018-10-22 13:51:49 --> Loader Class Initialized
INFO - 2018-10-22 13:51:49 --> Helper loaded: url_helper
INFO - 2018-10-22 13:51:49 --> Helper loaded: form_helper
INFO - 2018-10-22 13:51:49 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:51:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:51:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:51:49 --> User Agent Class Initialized
INFO - 2018-10-22 13:51:49 --> Controller Class Initialized
INFO - 2018-10-22 13:51:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:51:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:51:49 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:51:49 --> Pixel_Model class loaded
INFO - 2018-10-22 13:51:49 --> Database Driver Class Initialized
INFO - 2018-10-22 13:51:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:51:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:51:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:51:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:51:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:51:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/suspension.php
INFO - 2018-10-22 13:51:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:51:49 --> Final output sent to browser
DEBUG - 2018-10-22 13:51:49 --> Total execution time: 0.5033
INFO - 2018-10-22 13:51:56 --> Config Class Initialized
INFO - 2018-10-22 13:51:56 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:51:56 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:51:56 --> Utf8 Class Initialized
INFO - 2018-10-22 13:51:56 --> URI Class Initialized
INFO - 2018-10-22 13:51:56 --> Router Class Initialized
INFO - 2018-10-22 13:51:56 --> Output Class Initialized
INFO - 2018-10-22 13:51:56 --> Security Class Initialized
DEBUG - 2018-10-22 13:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:51:56 --> CSRF cookie sent
INFO - 2018-10-22 13:51:56 --> Input Class Initialized
INFO - 2018-10-22 13:51:56 --> Language Class Initialized
INFO - 2018-10-22 13:51:56 --> Loader Class Initialized
INFO - 2018-10-22 13:51:57 --> Helper loaded: url_helper
INFO - 2018-10-22 13:51:57 --> Helper loaded: form_helper
INFO - 2018-10-22 13:51:57 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:51:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:51:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:51:57 --> User Agent Class Initialized
INFO - 2018-10-22 13:51:57 --> Controller Class Initialized
INFO - 2018-10-22 13:51:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:51:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:51:57 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:51:57 --> Pixel_Model class loaded
INFO - 2018-10-22 13:51:57 --> Database Driver Class Initialized
INFO - 2018-10-22 13:51:57 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:51:57 --> Config Class Initialized
INFO - 2018-10-22 13:51:57 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:51:57 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:51:57 --> Utf8 Class Initialized
INFO - 2018-10-22 13:51:57 --> URI Class Initialized
INFO - 2018-10-22 13:51:57 --> Router Class Initialized
INFO - 2018-10-22 13:51:57 --> Output Class Initialized
INFO - 2018-10-22 13:51:57 --> Security Class Initialized
DEBUG - 2018-10-22 13:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:51:57 --> CSRF cookie sent
INFO - 2018-10-22 13:51:57 --> Input Class Initialized
INFO - 2018-10-22 13:51:57 --> Language Class Initialized
INFO - 2018-10-22 13:51:57 --> Loader Class Initialized
INFO - 2018-10-22 13:51:57 --> Helper loaded: url_helper
INFO - 2018-10-22 13:51:57 --> Helper loaded: form_helper
INFO - 2018-10-22 13:51:57 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:51:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:51:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:51:57 --> User Agent Class Initialized
INFO - 2018-10-22 13:51:57 --> Controller Class Initialized
INFO - 2018-10-22 13:51:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:51:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:51:57 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:51:57 --> Pixel_Model class loaded
INFO - 2018-10-22 13:51:57 --> Database Driver Class Initialized
INFO - 2018-10-22 13:51:57 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:51:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:51:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:51:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:51:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:51:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:51:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:51:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-22 13:51:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:51:57 --> Final output sent to browser
DEBUG - 2018-10-22 13:51:57 --> Total execution time: 0.5428
INFO - 2018-10-22 13:51:58 --> Config Class Initialized
INFO - 2018-10-22 13:51:58 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:51:58 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:51:58 --> Utf8 Class Initialized
INFO - 2018-10-22 13:51:58 --> URI Class Initialized
INFO - 2018-10-22 13:51:58 --> Router Class Initialized
INFO - 2018-10-22 13:51:58 --> Output Class Initialized
INFO - 2018-10-22 13:51:58 --> Security Class Initialized
DEBUG - 2018-10-22 13:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:51:58 --> CSRF cookie sent
INFO - 2018-10-22 13:51:58 --> Input Class Initialized
INFO - 2018-10-22 13:51:58 --> Language Class Initialized
INFO - 2018-10-22 13:51:58 --> Loader Class Initialized
INFO - 2018-10-22 13:51:58 --> Helper loaded: url_helper
INFO - 2018-10-22 13:51:58 --> Helper loaded: form_helper
INFO - 2018-10-22 13:51:58 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:51:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:51:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:51:58 --> User Agent Class Initialized
INFO - 2018-10-22 13:51:58 --> Controller Class Initialized
INFO - 2018-10-22 13:51:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:51:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:51:58 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:51:58 --> Pixel_Model class loaded
INFO - 2018-10-22 13:51:58 --> Database Driver Class Initialized
INFO - 2018-10-22 13:51:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:51:58 --> Config Class Initialized
INFO - 2018-10-22 13:51:58 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:51:58 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:51:58 --> Utf8 Class Initialized
INFO - 2018-10-22 13:51:58 --> URI Class Initialized
INFO - 2018-10-22 13:51:58 --> Router Class Initialized
INFO - 2018-10-22 13:51:58 --> Output Class Initialized
INFO - 2018-10-22 13:51:58 --> Security Class Initialized
DEBUG - 2018-10-22 13:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:51:58 --> CSRF cookie sent
INFO - 2018-10-22 13:51:58 --> Input Class Initialized
INFO - 2018-10-22 13:51:58 --> Language Class Initialized
INFO - 2018-10-22 13:51:58 --> Loader Class Initialized
INFO - 2018-10-22 13:51:58 --> Helper loaded: url_helper
INFO - 2018-10-22 13:51:58 --> Helper loaded: form_helper
INFO - 2018-10-22 13:51:58 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:51:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:51:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:51:58 --> User Agent Class Initialized
INFO - 2018-10-22 13:51:59 --> Controller Class Initialized
INFO - 2018-10-22 13:51:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:51:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:51:59 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:51:59 --> Pixel_Model class loaded
INFO - 2018-10-22 13:51:59 --> Database Driver Class Initialized
INFO - 2018-10-22 13:51:59 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:51:59 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:51:59 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:51:59 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:51:59 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:51:59 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:51:59 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:51:59 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-22 13:51:59 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:51:59 --> Final output sent to browser
DEBUG - 2018-10-22 13:51:59 --> Total execution time: 0.5337
INFO - 2018-10-22 13:51:59 --> Config Class Initialized
INFO - 2018-10-22 13:51:59 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:51:59 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:51:59 --> Utf8 Class Initialized
INFO - 2018-10-22 13:51:59 --> URI Class Initialized
INFO - 2018-10-22 13:51:59 --> Router Class Initialized
INFO - 2018-10-22 13:51:59 --> Output Class Initialized
INFO - 2018-10-22 13:51:59 --> Security Class Initialized
DEBUG - 2018-10-22 13:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:51:59 --> CSRF cookie sent
INFO - 2018-10-22 13:51:59 --> Input Class Initialized
INFO - 2018-10-22 13:51:59 --> Language Class Initialized
INFO - 2018-10-22 13:51:59 --> Loader Class Initialized
INFO - 2018-10-22 13:51:59 --> Helper loaded: url_helper
INFO - 2018-10-22 13:51:59 --> Helper loaded: form_helper
INFO - 2018-10-22 13:51:59 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:51:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:51:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:51:59 --> User Agent Class Initialized
INFO - 2018-10-22 13:51:59 --> Controller Class Initialized
INFO - 2018-10-22 13:51:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:51:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:51:59 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:51:59 --> Pixel_Model class loaded
INFO - 2018-10-22 13:51:59 --> Database Driver Class Initialized
INFO - 2018-10-22 13:51:59 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:51:59 --> Config Class Initialized
INFO - 2018-10-22 13:52:00 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:52:00 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:52:00 --> Utf8 Class Initialized
INFO - 2018-10-22 13:52:00 --> URI Class Initialized
INFO - 2018-10-22 13:52:00 --> Router Class Initialized
INFO - 2018-10-22 13:52:00 --> Output Class Initialized
INFO - 2018-10-22 13:52:00 --> Security Class Initialized
DEBUG - 2018-10-22 13:52:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:52:00 --> CSRF cookie sent
INFO - 2018-10-22 13:52:00 --> Input Class Initialized
INFO - 2018-10-22 13:52:00 --> Language Class Initialized
INFO - 2018-10-22 13:52:00 --> Loader Class Initialized
INFO - 2018-10-22 13:52:00 --> Helper loaded: url_helper
INFO - 2018-10-22 13:52:00 --> Helper loaded: form_helper
INFO - 2018-10-22 13:52:00 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:52:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:52:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:52:00 --> User Agent Class Initialized
INFO - 2018-10-22 13:52:00 --> Controller Class Initialized
INFO - 2018-10-22 13:52:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:52:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:52:00 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:52:00 --> Pixel_Model class loaded
INFO - 2018-10-22 13:52:00 --> Database Driver Class Initialized
INFO - 2018-10-22 13:52:00 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:52:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:52:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:52:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:52:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:52:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:52:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:52:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-22 13:52:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:52:00 --> Final output sent to browser
DEBUG - 2018-10-22 13:52:00 --> Total execution time: 0.5421
INFO - 2018-10-22 13:52:02 --> Config Class Initialized
INFO - 2018-10-22 13:52:02 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:52:02 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:52:02 --> Utf8 Class Initialized
INFO - 2018-10-22 13:52:02 --> URI Class Initialized
INFO - 2018-10-22 13:52:02 --> Router Class Initialized
INFO - 2018-10-22 13:52:02 --> Output Class Initialized
INFO - 2018-10-22 13:52:02 --> Security Class Initialized
DEBUG - 2018-10-22 13:52:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:52:02 --> CSRF cookie sent
INFO - 2018-10-22 13:52:02 --> Input Class Initialized
INFO - 2018-10-22 13:52:02 --> Language Class Initialized
INFO - 2018-10-22 13:52:02 --> Loader Class Initialized
INFO - 2018-10-22 13:52:02 --> Helper loaded: url_helper
INFO - 2018-10-22 13:52:02 --> Helper loaded: form_helper
INFO - 2018-10-22 13:52:02 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:52:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:52:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:52:02 --> User Agent Class Initialized
INFO - 2018-10-22 13:52:02 --> Controller Class Initialized
INFO - 2018-10-22 13:52:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:52:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:52:02 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:52:02 --> Pixel_Model class loaded
INFO - 2018-10-22 13:52:02 --> Database Driver Class Initialized
INFO - 2018-10-22 13:52:02 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:52:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:52:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:52:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:52:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:52:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:52:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:52:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-22 13:52:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:52:02 --> Final output sent to browser
DEBUG - 2018-10-22 13:52:02 --> Total execution time: 0.5536
INFO - 2018-10-22 13:52:22 --> Config Class Initialized
INFO - 2018-10-22 13:52:22 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:52:22 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:52:22 --> Utf8 Class Initialized
INFO - 2018-10-22 13:52:22 --> URI Class Initialized
INFO - 2018-10-22 13:52:22 --> Router Class Initialized
INFO - 2018-10-22 13:52:22 --> Output Class Initialized
INFO - 2018-10-22 13:52:22 --> Security Class Initialized
DEBUG - 2018-10-22 13:52:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:52:22 --> CSRF cookie sent
INFO - 2018-10-22 13:52:22 --> CSRF token verified
INFO - 2018-10-22 13:52:22 --> Input Class Initialized
INFO - 2018-10-22 13:52:22 --> Language Class Initialized
INFO - 2018-10-22 13:52:22 --> Loader Class Initialized
INFO - 2018-10-22 13:52:22 --> Helper loaded: url_helper
INFO - 2018-10-22 13:52:22 --> Helper loaded: form_helper
INFO - 2018-10-22 13:52:22 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:52:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:52:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:52:22 --> User Agent Class Initialized
INFO - 2018-10-22 13:52:22 --> Controller Class Initialized
INFO - 2018-10-22 13:52:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:52:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:52:22 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:52:22 --> Pixel_Model class loaded
INFO - 2018-10-22 13:52:22 --> Database Driver Class Initialized
INFO - 2018-10-22 13:52:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:52:23 --> Form Validation Class Initialized
INFO - 2018-10-22 13:52:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:52:23 --> Database Driver Class Initialized
INFO - 2018-10-22 13:52:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:52:23 --> Config Class Initialized
INFO - 2018-10-22 13:52:23 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:52:23 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:52:23 --> Utf8 Class Initialized
INFO - 2018-10-22 13:52:23 --> URI Class Initialized
DEBUG - 2018-10-22 13:52:23 --> No URI present. Default controller set.
INFO - 2018-10-22 13:52:23 --> Router Class Initialized
INFO - 2018-10-22 13:52:23 --> Output Class Initialized
INFO - 2018-10-22 13:52:23 --> Security Class Initialized
DEBUG - 2018-10-22 13:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:52:23 --> CSRF cookie sent
INFO - 2018-10-22 13:52:23 --> Input Class Initialized
INFO - 2018-10-22 13:52:23 --> Language Class Initialized
INFO - 2018-10-22 13:52:23 --> Loader Class Initialized
INFO - 2018-10-22 13:52:23 --> Helper loaded: url_helper
INFO - 2018-10-22 13:52:23 --> Helper loaded: form_helper
INFO - 2018-10-22 13:52:23 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:52:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:52:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:52:23 --> User Agent Class Initialized
INFO - 2018-10-22 13:52:23 --> Controller Class Initialized
INFO - 2018-10-22 13:52:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:52:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:52:23 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:52:23 --> Pixel_Model class loaded
INFO - 2018-10-22 13:52:23 --> Database Driver Class Initialized
INFO - 2018-10-22 13:52:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:52:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:52:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:52:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-22 13:52:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:52:23 --> Final output sent to browser
DEBUG - 2018-10-22 13:52:23 --> Total execution time: 0.4999
INFO - 2018-10-22 13:52:25 --> Config Class Initialized
INFO - 2018-10-22 13:52:25 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:52:25 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:52:25 --> Utf8 Class Initialized
INFO - 2018-10-22 13:52:25 --> URI Class Initialized
INFO - 2018-10-22 13:52:25 --> Router Class Initialized
INFO - 2018-10-22 13:52:25 --> Output Class Initialized
INFO - 2018-10-22 13:52:25 --> Security Class Initialized
DEBUG - 2018-10-22 13:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:52:25 --> CSRF cookie sent
INFO - 2018-10-22 13:52:25 --> Input Class Initialized
INFO - 2018-10-22 13:52:25 --> Language Class Initialized
INFO - 2018-10-22 13:52:25 --> Loader Class Initialized
INFO - 2018-10-22 13:52:25 --> Helper loaded: url_helper
INFO - 2018-10-22 13:52:25 --> Helper loaded: form_helper
INFO - 2018-10-22 13:52:25 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:52:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:52:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:52:25 --> User Agent Class Initialized
INFO - 2018-10-22 13:52:25 --> Controller Class Initialized
INFO - 2018-10-22 13:52:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:52:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:52:25 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:52:25 --> Pixel_Model class loaded
INFO - 2018-10-22 13:52:25 --> Database Driver Class Initialized
INFO - 2018-10-22 13:52:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:52:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:52:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:52:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:52:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:52:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:52:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:52:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-22 13:52:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:52:26 --> Final output sent to browser
DEBUG - 2018-10-22 13:52:26 --> Total execution time: 0.6839
INFO - 2018-10-22 13:52:28 --> Config Class Initialized
INFO - 2018-10-22 13:52:28 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:52:28 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:52:28 --> Utf8 Class Initialized
INFO - 2018-10-22 13:52:28 --> URI Class Initialized
INFO - 2018-10-22 13:52:28 --> Router Class Initialized
INFO - 2018-10-22 13:52:28 --> Output Class Initialized
INFO - 2018-10-22 13:52:28 --> Security Class Initialized
DEBUG - 2018-10-22 13:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:52:28 --> CSRF cookie sent
INFO - 2018-10-22 13:52:28 --> CSRF token verified
INFO - 2018-10-22 13:52:28 --> Input Class Initialized
INFO - 2018-10-22 13:52:28 --> Language Class Initialized
INFO - 2018-10-22 13:52:28 --> Loader Class Initialized
INFO - 2018-10-22 13:52:28 --> Helper loaded: url_helper
INFO - 2018-10-22 13:52:28 --> Helper loaded: form_helper
INFO - 2018-10-22 13:52:28 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:52:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:52:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:52:28 --> User Agent Class Initialized
INFO - 2018-10-22 13:52:28 --> Controller Class Initialized
INFO - 2018-10-22 13:52:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:52:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:52:28 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:52:28 --> Pixel_Model class loaded
INFO - 2018-10-22 13:52:28 --> Database Driver Class Initialized
INFO - 2018-10-22 13:52:28 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:52:28 --> Form Validation Class Initialized
INFO - 2018-10-22 13:52:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:52:28 --> Database Driver Class Initialized
INFO - 2018-10-22 13:52:29 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:52:29 --> Config Class Initialized
INFO - 2018-10-22 13:52:29 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:52:29 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:52:29 --> Utf8 Class Initialized
INFO - 2018-10-22 13:52:29 --> URI Class Initialized
DEBUG - 2018-10-22 13:52:29 --> No URI present. Default controller set.
INFO - 2018-10-22 13:52:29 --> Router Class Initialized
INFO - 2018-10-22 13:52:29 --> Output Class Initialized
INFO - 2018-10-22 13:52:29 --> Security Class Initialized
DEBUG - 2018-10-22 13:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:52:29 --> CSRF cookie sent
INFO - 2018-10-22 13:52:29 --> Input Class Initialized
INFO - 2018-10-22 13:52:29 --> Language Class Initialized
INFO - 2018-10-22 13:52:29 --> Loader Class Initialized
INFO - 2018-10-22 13:52:29 --> Helper loaded: url_helper
INFO - 2018-10-22 13:52:29 --> Helper loaded: form_helper
INFO - 2018-10-22 13:52:29 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:52:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:52:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:52:29 --> User Agent Class Initialized
INFO - 2018-10-22 13:52:29 --> Controller Class Initialized
INFO - 2018-10-22 13:52:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:52:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:52:29 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:52:29 --> Pixel_Model class loaded
INFO - 2018-10-22 13:52:29 --> Database Driver Class Initialized
INFO - 2018-10-22 13:52:29 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:52:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:52:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:52:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-22 13:52:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:52:29 --> Final output sent to browser
DEBUG - 2018-10-22 13:52:29 --> Total execution time: 0.5117
INFO - 2018-10-22 13:52:31 --> Config Class Initialized
INFO - 2018-10-22 13:52:31 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:52:31 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:52:31 --> Utf8 Class Initialized
INFO - 2018-10-22 13:52:31 --> URI Class Initialized
INFO - 2018-10-22 13:52:31 --> Router Class Initialized
INFO - 2018-10-22 13:52:31 --> Output Class Initialized
INFO - 2018-10-22 13:52:31 --> Security Class Initialized
DEBUG - 2018-10-22 13:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:52:31 --> CSRF cookie sent
INFO - 2018-10-22 13:52:31 --> Input Class Initialized
INFO - 2018-10-22 13:52:31 --> Language Class Initialized
INFO - 2018-10-22 13:52:31 --> Loader Class Initialized
INFO - 2018-10-22 13:52:31 --> Helper loaded: url_helper
INFO - 2018-10-22 13:52:31 --> Helper loaded: form_helper
INFO - 2018-10-22 13:52:31 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:52:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:52:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:52:31 --> User Agent Class Initialized
INFO - 2018-10-22 13:52:31 --> Controller Class Initialized
INFO - 2018-10-22 13:52:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:52:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:52:31 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:52:31 --> Pixel_Model class loaded
INFO - 2018-10-22 13:52:31 --> Database Driver Class Initialized
INFO - 2018-10-22 13:52:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:52:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:52:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:52:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:52:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:52:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:52:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:52:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-22 13:52:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:52:31 --> Final output sent to browser
DEBUG - 2018-10-22 13:52:31 --> Total execution time: 0.6495
INFO - 2018-10-22 13:52:35 --> Config Class Initialized
INFO - 2018-10-22 13:52:35 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:52:35 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:52:35 --> Utf8 Class Initialized
INFO - 2018-10-22 13:52:35 --> URI Class Initialized
INFO - 2018-10-22 13:52:35 --> Router Class Initialized
INFO - 2018-10-22 13:52:35 --> Output Class Initialized
INFO - 2018-10-22 13:52:35 --> Security Class Initialized
DEBUG - 2018-10-22 13:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:52:35 --> CSRF cookie sent
INFO - 2018-10-22 13:52:35 --> CSRF token verified
INFO - 2018-10-22 13:52:35 --> Input Class Initialized
INFO - 2018-10-22 13:52:35 --> Language Class Initialized
INFO - 2018-10-22 13:52:35 --> Loader Class Initialized
INFO - 2018-10-22 13:52:35 --> Helper loaded: url_helper
INFO - 2018-10-22 13:52:35 --> Helper loaded: form_helper
INFO - 2018-10-22 13:52:35 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:52:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:52:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:52:35 --> User Agent Class Initialized
INFO - 2018-10-22 13:52:35 --> Controller Class Initialized
INFO - 2018-10-22 13:52:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:52:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:52:35 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:52:35 --> Pixel_Model class loaded
INFO - 2018-10-22 13:52:35 --> Database Driver Class Initialized
INFO - 2018-10-22 13:52:35 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:52:35 --> Form Validation Class Initialized
INFO - 2018-10-22 13:52:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:52:35 --> Database Driver Class Initialized
INFO - 2018-10-22 13:52:35 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:52:35 --> Config Class Initialized
INFO - 2018-10-22 13:52:35 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:52:35 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:52:35 --> Utf8 Class Initialized
INFO - 2018-10-22 13:52:35 --> URI Class Initialized
DEBUG - 2018-10-22 13:52:35 --> No URI present. Default controller set.
INFO - 2018-10-22 13:52:35 --> Router Class Initialized
INFO - 2018-10-22 13:52:35 --> Output Class Initialized
INFO - 2018-10-22 13:52:35 --> Security Class Initialized
DEBUG - 2018-10-22 13:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:52:35 --> CSRF cookie sent
INFO - 2018-10-22 13:52:35 --> Input Class Initialized
INFO - 2018-10-22 13:52:35 --> Language Class Initialized
INFO - 2018-10-22 13:52:35 --> Loader Class Initialized
INFO - 2018-10-22 13:52:36 --> Helper loaded: url_helper
INFO - 2018-10-22 13:52:36 --> Helper loaded: form_helper
INFO - 2018-10-22 13:52:36 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:52:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:52:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:52:36 --> User Agent Class Initialized
INFO - 2018-10-22 13:52:36 --> Controller Class Initialized
INFO - 2018-10-22 13:52:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:52:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:52:36 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:52:36 --> Pixel_Model class loaded
INFO - 2018-10-22 13:52:36 --> Database Driver Class Initialized
INFO - 2018-10-22 13:52:36 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:52:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:52:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:52:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-22 13:52:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:52:36 --> Final output sent to browser
DEBUG - 2018-10-22 13:52:36 --> Total execution time: 0.5074
INFO - 2018-10-22 13:52:37 --> Config Class Initialized
INFO - 2018-10-22 13:52:37 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:52:37 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:52:37 --> Utf8 Class Initialized
INFO - 2018-10-22 13:52:37 --> URI Class Initialized
INFO - 2018-10-22 13:52:37 --> Router Class Initialized
INFO - 2018-10-22 13:52:37 --> Output Class Initialized
INFO - 2018-10-22 13:52:37 --> Security Class Initialized
DEBUG - 2018-10-22 13:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:52:37 --> CSRF cookie sent
INFO - 2018-10-22 13:52:38 --> Input Class Initialized
INFO - 2018-10-22 13:52:38 --> Language Class Initialized
INFO - 2018-10-22 13:52:38 --> Loader Class Initialized
INFO - 2018-10-22 13:52:38 --> Helper loaded: url_helper
INFO - 2018-10-22 13:52:38 --> Helper loaded: form_helper
INFO - 2018-10-22 13:52:38 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:52:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:52:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:52:38 --> User Agent Class Initialized
INFO - 2018-10-22 13:52:38 --> Controller Class Initialized
INFO - 2018-10-22 13:52:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:52:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:52:38 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:52:38 --> Pixel_Model class loaded
INFO - 2018-10-22 13:52:38 --> Database Driver Class Initialized
INFO - 2018-10-22 13:52:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:52:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:52:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:52:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:52:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:52:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:52:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:52:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-22 13:52:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:52:38 --> Final output sent to browser
DEBUG - 2018-10-22 13:52:38 --> Total execution time: 0.6439
INFO - 2018-10-22 13:52:38 --> Config Class Initialized
INFO - 2018-10-22 13:52:38 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:52:38 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:52:38 --> Utf8 Class Initialized
INFO - 2018-10-22 13:52:38 --> URI Class Initialized
INFO - 2018-10-22 13:52:38 --> Router Class Initialized
INFO - 2018-10-22 13:52:38 --> Output Class Initialized
INFO - 2018-10-22 13:52:38 --> Security Class Initialized
DEBUG - 2018-10-22 13:52:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:52:38 --> CSRF cookie sent
INFO - 2018-10-22 13:52:38 --> Input Class Initialized
INFO - 2018-10-22 13:52:38 --> Language Class Initialized
INFO - 2018-10-22 13:52:38 --> Loader Class Initialized
INFO - 2018-10-22 13:52:38 --> Helper loaded: url_helper
INFO - 2018-10-22 13:52:38 --> Helper loaded: form_helper
INFO - 2018-10-22 13:52:38 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:52:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:52:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:52:39 --> User Agent Class Initialized
INFO - 2018-10-22 13:52:39 --> Controller Class Initialized
INFO - 2018-10-22 13:52:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:52:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:52:39 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:52:39 --> Pixel_Model class loaded
INFO - 2018-10-22 13:52:39 --> Database Driver Class Initialized
INFO - 2018-10-22 13:52:39 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:52:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:52:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:52:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:52:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:52:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:52:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:52:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-22 13:52:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:52:39 --> Final output sent to browser
DEBUG - 2018-10-22 13:52:39 --> Total execution time: 0.5732
INFO - 2018-10-22 13:52:39 --> Config Class Initialized
INFO - 2018-10-22 13:52:39 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:52:39 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:52:39 --> Utf8 Class Initialized
INFO - 2018-10-22 13:52:39 --> URI Class Initialized
INFO - 2018-10-22 13:52:39 --> Router Class Initialized
INFO - 2018-10-22 13:52:39 --> Output Class Initialized
INFO - 2018-10-22 13:52:39 --> Security Class Initialized
DEBUG - 2018-10-22 13:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:52:39 --> CSRF cookie sent
INFO - 2018-10-22 13:52:39 --> Input Class Initialized
INFO - 2018-10-22 13:52:39 --> Language Class Initialized
INFO - 2018-10-22 13:52:39 --> Loader Class Initialized
INFO - 2018-10-22 13:52:39 --> Helper loaded: url_helper
INFO - 2018-10-22 13:52:39 --> Helper loaded: form_helper
INFO - 2018-10-22 13:52:39 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:52:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:52:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:52:39 --> User Agent Class Initialized
INFO - 2018-10-22 13:52:40 --> Controller Class Initialized
INFO - 2018-10-22 13:52:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:52:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:52:40 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:52:40 --> Pixel_Model class loaded
INFO - 2018-10-22 13:52:40 --> Database Driver Class Initialized
INFO - 2018-10-22 13:52:40 --> Config Class Initialized
INFO - 2018-10-22 13:52:40 --> Hooks Class Initialized
INFO - 2018-10-22 13:52:40 --> Model "QuestionsModel" initialized
DEBUG - 2018-10-22 13:52:40 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:52:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:52:40 --> Utf8 Class Initialized
INFO - 2018-10-22 13:52:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:52:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:52:40 --> URI Class Initialized
INFO - 2018-10-22 13:52:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:52:40 --> Router Class Initialized
INFO - 2018-10-22 13:52:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:52:40 --> Output Class Initialized
INFO - 2018-10-22 13:52:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:52:40 --> Security Class Initialized
INFO - 2018-10-22 13:52:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
DEBUG - 2018-10-22 13:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:52:40 --> CSRF cookie sent
INFO - 2018-10-22 13:52:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:52:40 --> Input Class Initialized
INFO - 2018-10-22 13:52:40 --> Final output sent to browser
DEBUG - 2018-10-22 13:52:40 --> Total execution time: 0.6166
INFO - 2018-10-22 13:52:40 --> Language Class Initialized
INFO - 2018-10-22 13:52:40 --> Loader Class Initialized
INFO - 2018-10-22 13:52:40 --> Helper loaded: url_helper
INFO - 2018-10-22 13:52:40 --> Helper loaded: form_helper
INFO - 2018-10-22 13:52:40 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:52:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:52:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:52:40 --> User Agent Class Initialized
INFO - 2018-10-22 13:52:40 --> Config Class Initialized
INFO - 2018-10-22 13:52:40 --> Hooks Class Initialized
INFO - 2018-10-22 13:52:40 --> Controller Class Initialized
INFO - 2018-10-22 13:52:40 --> Language file loaded: language/en/common_lang.php
DEBUG - 2018-10-22 13:52:40 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:52:40 --> Utf8 Class Initialized
INFO - 2018-10-22 13:52:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:52:40 --> URI Class Initialized
INFO - 2018-10-22 13:52:40 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:52:40 --> Pixel_Model class loaded
INFO - 2018-10-22 13:52:40 --> Router Class Initialized
INFO - 2018-10-22 13:52:40 --> Output Class Initialized
INFO - 2018-10-22 13:52:40 --> Database Driver Class Initialized
INFO - 2018-10-22 13:52:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:52:40 --> Security Class Initialized
DEBUG - 2018-10-22 13:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:52:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:52:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:52:40 --> CSRF cookie sent
INFO - 2018-10-22 13:52:40 --> Input Class Initialized
INFO - 2018-10-22 13:52:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:52:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:52:40 --> Language Class Initialized
INFO - 2018-10-22 13:52:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:52:40 --> Loader Class Initialized
INFO - 2018-10-22 13:52:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:52:40 --> Helper loaded: url_helper
INFO - 2018-10-22 13:52:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-22 13:52:40 --> Helper loaded: form_helper
INFO - 2018-10-22 13:52:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:52:40 --> Helper loaded: language_helper
INFO - 2018-10-22 13:52:40 --> Final output sent to browser
DEBUG - 2018-10-22 13:52:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:52:40 --> Config Class Initialized
DEBUG - 2018-10-22 13:52:40 --> Total execution time: 0.5680
INFO - 2018-10-22 13:52:40 --> Hooks Class Initialized
INFO - 2018-10-22 13:52:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-10-22 13:52:40 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:52:40 --> Utf8 Class Initialized
INFO - 2018-10-22 13:52:40 --> User Agent Class Initialized
INFO - 2018-10-22 13:52:40 --> URI Class Initialized
INFO - 2018-10-22 13:52:40 --> Controller Class Initialized
INFO - 2018-10-22 13:52:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:52:40 --> Router Class Initialized
INFO - 2018-10-22 13:52:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:52:40 --> Output Class Initialized
INFO - 2018-10-22 13:52:40 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:52:40 --> Security Class Initialized
INFO - 2018-10-22 13:52:40 --> Pixel_Model class loaded
DEBUG - 2018-10-22 13:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:52:40 --> CSRF cookie sent
INFO - 2018-10-22 13:52:40 --> Database Driver Class Initialized
INFO - 2018-10-22 13:52:40 --> Input Class Initialized
INFO - 2018-10-22 13:52:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:52:40 --> Language Class Initialized
INFO - 2018-10-22 13:52:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:52:40 --> Loader Class Initialized
INFO - 2018-10-22 13:52:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:52:40 --> Helper loaded: url_helper
INFO - 2018-10-22 13:52:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:52:40 --> Helper loaded: form_helper
INFO - 2018-10-22 13:52:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:52:40 --> Helper loaded: language_helper
INFO - 2018-10-22 13:52:40 --> Config Class Initialized
INFO - 2018-10-22 13:52:40 --> Hooks Class Initialized
INFO - 2018-10-22 13:52:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:52:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
DEBUG - 2018-10-22 13:52:40 --> UTF-8 Support Enabled
DEBUG - 2018-10-22 13:52:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:52:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-22 13:52:40 --> Utf8 Class Initialized
INFO - 2018-10-22 13:52:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:52:40 --> URI Class Initialized
INFO - 2018-10-22 13:52:40 --> Final output sent to browser
INFO - 2018-10-22 13:52:40 --> Router Class Initialized
DEBUG - 2018-10-22 13:52:40 --> Total execution time: 0.5649
INFO - 2018-10-22 13:52:40 --> Output Class Initialized
INFO - 2018-10-22 13:52:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:52:41 --> Security Class Initialized
DEBUG - 2018-10-22 13:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:52:41 --> User Agent Class Initialized
INFO - 2018-10-22 13:52:41 --> CSRF cookie sent
INFO - 2018-10-22 13:52:41 --> Controller Class Initialized
INFO - 2018-10-22 13:52:41 --> Input Class Initialized
INFO - 2018-10-22 13:52:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:52:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:52:41 --> Language Class Initialized
INFO - 2018-10-22 13:52:41 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:52:41 --> Loader Class Initialized
INFO - 2018-10-22 13:52:41 --> Pixel_Model class loaded
INFO - 2018-10-22 13:52:41 --> Helper loaded: url_helper
INFO - 2018-10-22 13:52:41 --> Helper loaded: form_helper
INFO - 2018-10-22 13:52:41 --> Database Driver Class Initialized
INFO - 2018-10-22 13:52:41 --> Helper loaded: language_helper
INFO - 2018-10-22 13:52:41 --> Model "QuestionsModel" initialized
DEBUG - 2018-10-22 13:52:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:52:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:52:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:52:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:52:41 --> Config Class Initialized
INFO - 2018-10-22 13:52:41 --> Hooks Class Initialized
INFO - 2018-10-22 13:52:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:52:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
DEBUG - 2018-10-22 13:52:41 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:52:41 --> Utf8 Class Initialized
INFO - 2018-10-22 13:52:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:52:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-22 13:52:41 --> URI Class Initialized
INFO - 2018-10-22 13:52:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:52:41 --> Router Class Initialized
INFO - 2018-10-22 13:52:41 --> Final output sent to browser
INFO - 2018-10-22 13:52:41 --> Output Class Initialized
DEBUG - 2018-10-22 13:52:41 --> Total execution time: 0.6103
INFO - 2018-10-22 13:52:41 --> Security Class Initialized
INFO - 2018-10-22 13:52:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-10-22 13:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:52:41 --> CSRF cookie sent
INFO - 2018-10-22 13:52:41 --> User Agent Class Initialized
INFO - 2018-10-22 13:52:41 --> Input Class Initialized
INFO - 2018-10-22 13:52:41 --> Controller Class Initialized
INFO - 2018-10-22 13:52:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:52:41 --> Language Class Initialized
INFO - 2018-10-22 13:52:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:52:41 --> Loader Class Initialized
INFO - 2018-10-22 13:52:41 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:52:41 --> Helper loaded: url_helper
INFO - 2018-10-22 13:52:41 --> Pixel_Model class loaded
INFO - 2018-10-22 13:52:41 --> Helper loaded: form_helper
INFO - 2018-10-22 13:52:41 --> Helper loaded: language_helper
INFO - 2018-10-22 13:52:41 --> Database Driver Class Initialized
INFO - 2018-10-22 13:52:41 --> Model "QuestionsModel" initialized
DEBUG - 2018-10-22 13:52:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:52:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:52:41 --> Config Class Initialized
INFO - 2018-10-22 13:52:41 --> Hooks Class Initialized
INFO - 2018-10-22 13:52:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:52:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
DEBUG - 2018-10-22 13:52:41 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:52:41 --> Utf8 Class Initialized
INFO - 2018-10-22 13:52:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:52:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:52:41 --> URI Class Initialized
INFO - 2018-10-22 13:52:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:52:41 --> Router Class Initialized
INFO - 2018-10-22 13:52:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-22 13:52:41 --> Output Class Initialized
INFO - 2018-10-22 13:52:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:52:41 --> Security Class Initialized
INFO - 2018-10-22 13:52:41 --> Final output sent to browser
DEBUG - 2018-10-22 13:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:52:41 --> CSRF cookie sent
DEBUG - 2018-10-22 13:52:41 --> Total execution time: 0.6649
INFO - 2018-10-22 13:52:41 --> Input Class Initialized
INFO - 2018-10-22 13:52:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:52:41 --> Language Class Initialized
INFO - 2018-10-22 13:52:41 --> User Agent Class Initialized
INFO - 2018-10-22 13:52:41 --> Controller Class Initialized
INFO - 2018-10-22 13:52:41 --> Loader Class Initialized
INFO - 2018-10-22 13:52:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:52:41 --> Helper loaded: url_helper
INFO - 2018-10-22 13:52:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:52:41 --> Helper loaded: form_helper
INFO - 2018-10-22 13:52:41 --> Helper loaded: language_helper
INFO - 2018-10-22 13:52:41 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:52:41 --> Config Class Initialized
INFO - 2018-10-22 13:52:41 --> Hooks Class Initialized
INFO - 2018-10-22 13:52:41 --> Pixel_Model class loaded
DEBUG - 2018-10-22 13:52:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-10-22 13:52:41 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:52:41 --> Database Driver Class Initialized
INFO - 2018-10-22 13:52:41 --> Utf8 Class Initialized
INFO - 2018-10-22 13:52:41 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:52:41 --> URI Class Initialized
INFO - 2018-10-22 13:52:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:52:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:52:41 --> Router Class Initialized
INFO - 2018-10-22 13:52:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:52:41 --> Output Class Initialized
INFO - 2018-10-22 13:52:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:52:41 --> Security Class Initialized
INFO - 2018-10-22 13:52:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
DEBUG - 2018-10-22 13:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:52:41 --> CSRF cookie sent
INFO - 2018-10-22 13:52:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:52:41 --> Input Class Initialized
INFO - 2018-10-22 13:52:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-22 13:52:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:52:41 --> Language Class Initialized
INFO - 2018-10-22 13:52:41 --> Final output sent to browser
INFO - 2018-10-22 13:52:41 --> Loader Class Initialized
INFO - 2018-10-22 13:52:41 --> Config Class Initialized
INFO - 2018-10-22 13:52:41 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:52:41 --> Total execution time: 0.6752
INFO - 2018-10-22 13:52:41 --> Helper loaded: url_helper
INFO - 2018-10-22 13:52:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:52:41 --> Helper loaded: form_helper
DEBUG - 2018-10-22 13:52:41 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:52:41 --> Utf8 Class Initialized
INFO - 2018-10-22 13:52:41 --> Helper loaded: language_helper
INFO - 2018-10-22 13:52:41 --> User Agent Class Initialized
INFO - 2018-10-22 13:52:41 --> URI Class Initialized
INFO - 2018-10-22 13:52:41 --> Controller Class Initialized
DEBUG - 2018-10-22 13:52:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:52:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:52:41 --> Router Class Initialized
INFO - 2018-10-22 13:52:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:52:41 --> Output Class Initialized
INFO - 2018-10-22 13:52:41 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:52:41 --> Security Class Initialized
INFO - 2018-10-22 13:52:42 --> Pixel_Model class loaded
DEBUG - 2018-10-22 13:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:52:42 --> CSRF cookie sent
INFO - 2018-10-22 13:52:42 --> Database Driver Class Initialized
INFO - 2018-10-22 13:52:42 --> Input Class Initialized
INFO - 2018-10-22 13:52:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:52:42 --> Language Class Initialized
INFO - 2018-10-22 13:52:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:52:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:52:42 --> Loader Class Initialized
INFO - 2018-10-22 13:52:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:52:42 --> Helper loaded: url_helper
INFO - 2018-10-22 13:52:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:52:42 --> Helper loaded: form_helper
INFO - 2018-10-22 13:52:42 --> Helper loaded: language_helper
INFO - 2018-10-22 13:52:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:52:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
DEBUG - 2018-10-22 13:52:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:52:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-22 13:52:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:52:42 --> Final output sent to browser
DEBUG - 2018-10-22 13:52:42 --> Total execution time: 0.7298
INFO - 2018-10-22 13:52:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:52:42 --> User Agent Class Initialized
INFO - 2018-10-22 13:52:42 --> Controller Class Initialized
INFO - 2018-10-22 13:52:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:52:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:52:42 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:52:42 --> Pixel_Model class loaded
INFO - 2018-10-22 13:52:42 --> Database Driver Class Initialized
INFO - 2018-10-22 13:52:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:52:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:52:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:52:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:52:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:52:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:52:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:52:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-22 13:52:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:52:42 --> Final output sent to browser
DEBUG - 2018-10-22 13:52:42 --> Total execution time: 0.8265
INFO - 2018-10-22 13:52:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:52:42 --> User Agent Class Initialized
INFO - 2018-10-22 13:52:42 --> Controller Class Initialized
INFO - 2018-10-22 13:52:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:52:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:52:42 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:52:42 --> Pixel_Model class loaded
INFO - 2018-10-22 13:52:42 --> Database Driver Class Initialized
INFO - 2018-10-22 13:52:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:52:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:52:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:52:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:52:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:52:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:52:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:52:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-22 13:52:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:52:42 --> Final output sent to browser
DEBUG - 2018-10-22 13:52:42 --> Total execution time: 1.0155
INFO - 2018-10-22 13:52:49 --> Config Class Initialized
INFO - 2018-10-22 13:52:49 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:52:49 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:52:49 --> Utf8 Class Initialized
INFO - 2018-10-22 13:52:49 --> URI Class Initialized
INFO - 2018-10-22 13:52:49 --> Router Class Initialized
INFO - 2018-10-22 13:52:49 --> Output Class Initialized
INFO - 2018-10-22 13:52:49 --> Security Class Initialized
DEBUG - 2018-10-22 13:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:52:49 --> CSRF cookie sent
INFO - 2018-10-22 13:52:49 --> Input Class Initialized
INFO - 2018-10-22 13:52:49 --> Language Class Initialized
INFO - 2018-10-22 13:52:49 --> Loader Class Initialized
INFO - 2018-10-22 13:52:49 --> Helper loaded: url_helper
INFO - 2018-10-22 13:52:49 --> Helper loaded: form_helper
INFO - 2018-10-22 13:52:49 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:52:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:52:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:52:49 --> User Agent Class Initialized
INFO - 2018-10-22 13:52:49 --> Controller Class Initialized
INFO - 2018-10-22 13:52:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:52:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:52:49 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:52:49 --> Pixel_Model class loaded
INFO - 2018-10-22 13:52:49 --> Database Driver Class Initialized
INFO - 2018-10-22 13:52:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:52:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:52:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:52:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:52:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:52:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:52:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:52:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-22 13:52:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:52:49 --> Final output sent to browser
DEBUG - 2018-10-22 13:52:49 --> Total execution time: 0.6023
INFO - 2018-10-22 13:52:54 --> Config Class Initialized
INFO - 2018-10-22 13:52:54 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:52:54 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:52:54 --> Utf8 Class Initialized
INFO - 2018-10-22 13:52:54 --> URI Class Initialized
INFO - 2018-10-22 13:52:54 --> Router Class Initialized
INFO - 2018-10-22 13:52:54 --> Output Class Initialized
INFO - 2018-10-22 13:52:54 --> Security Class Initialized
DEBUG - 2018-10-22 13:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:52:54 --> CSRF cookie sent
INFO - 2018-10-22 13:52:54 --> CSRF token verified
INFO - 2018-10-22 13:52:54 --> Input Class Initialized
INFO - 2018-10-22 13:52:54 --> Language Class Initialized
INFO - 2018-10-22 13:52:54 --> Loader Class Initialized
INFO - 2018-10-22 13:52:54 --> Helper loaded: url_helper
INFO - 2018-10-22 13:52:54 --> Helper loaded: form_helper
INFO - 2018-10-22 13:52:54 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:52:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:52:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:52:55 --> User Agent Class Initialized
INFO - 2018-10-22 13:52:55 --> Controller Class Initialized
INFO - 2018-10-22 13:52:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:52:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:52:55 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:52:55 --> Pixel_Model class loaded
INFO - 2018-10-22 13:52:55 --> Database Driver Class Initialized
INFO - 2018-10-22 13:52:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:52:55 --> Form Validation Class Initialized
INFO - 2018-10-22 13:52:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:52:55 --> Database Driver Class Initialized
INFO - 2018-10-22 13:52:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:52:55 --> Config Class Initialized
INFO - 2018-10-22 13:52:55 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:52:55 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:52:55 --> Utf8 Class Initialized
INFO - 2018-10-22 13:52:55 --> URI Class Initialized
DEBUG - 2018-10-22 13:52:55 --> No URI present. Default controller set.
INFO - 2018-10-22 13:52:55 --> Router Class Initialized
INFO - 2018-10-22 13:52:55 --> Output Class Initialized
INFO - 2018-10-22 13:52:55 --> Security Class Initialized
DEBUG - 2018-10-22 13:52:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:52:55 --> CSRF cookie sent
INFO - 2018-10-22 13:52:55 --> Input Class Initialized
INFO - 2018-10-22 13:52:55 --> Language Class Initialized
INFO - 2018-10-22 13:52:55 --> Loader Class Initialized
INFO - 2018-10-22 13:52:55 --> Helper loaded: url_helper
INFO - 2018-10-22 13:52:55 --> Helper loaded: form_helper
INFO - 2018-10-22 13:52:55 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:52:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:52:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:52:55 --> User Agent Class Initialized
INFO - 2018-10-22 13:52:55 --> Controller Class Initialized
INFO - 2018-10-22 13:52:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:52:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:52:55 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:52:55 --> Pixel_Model class loaded
INFO - 2018-10-22 13:52:55 --> Database Driver Class Initialized
INFO - 2018-10-22 13:52:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:52:55 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:52:55 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:52:55 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-22 13:52:55 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:52:55 --> Final output sent to browser
DEBUG - 2018-10-22 13:52:55 --> Total execution time: 0.5065
INFO - 2018-10-22 13:52:58 --> Config Class Initialized
INFO - 2018-10-22 13:52:58 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:52:58 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:52:58 --> Utf8 Class Initialized
INFO - 2018-10-22 13:52:58 --> URI Class Initialized
INFO - 2018-10-22 13:52:58 --> Router Class Initialized
INFO - 2018-10-22 13:52:58 --> Output Class Initialized
INFO - 2018-10-22 13:52:58 --> Security Class Initialized
DEBUG - 2018-10-22 13:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:52:58 --> CSRF cookie sent
INFO - 2018-10-22 13:52:58 --> Input Class Initialized
INFO - 2018-10-22 13:52:58 --> Language Class Initialized
INFO - 2018-10-22 13:52:58 --> Loader Class Initialized
INFO - 2018-10-22 13:52:58 --> Helper loaded: url_helper
INFO - 2018-10-22 13:52:58 --> Helper loaded: form_helper
INFO - 2018-10-22 13:52:58 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:52:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:52:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:52:58 --> User Agent Class Initialized
INFO - 2018-10-22 13:52:58 --> Controller Class Initialized
INFO - 2018-10-22 13:52:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:52:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:52:58 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:52:58 --> Pixel_Model class loaded
INFO - 2018-10-22 13:52:58 --> Database Driver Class Initialized
INFO - 2018-10-22 13:52:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:52:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:52:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:52:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:52:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:52:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:52:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:52:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-22 13:52:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:52:58 --> Final output sent to browser
DEBUG - 2018-10-22 13:52:58 --> Total execution time: 0.5982
INFO - 2018-10-22 13:53:01 --> Config Class Initialized
INFO - 2018-10-22 13:53:01 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:53:01 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:53:01 --> Utf8 Class Initialized
INFO - 2018-10-22 13:53:01 --> URI Class Initialized
INFO - 2018-10-22 13:53:01 --> Router Class Initialized
INFO - 2018-10-22 13:53:01 --> Output Class Initialized
INFO - 2018-10-22 13:53:01 --> Security Class Initialized
DEBUG - 2018-10-22 13:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:53:01 --> CSRF cookie sent
INFO - 2018-10-22 13:53:01 --> CSRF token verified
INFO - 2018-10-22 13:53:01 --> Input Class Initialized
INFO - 2018-10-22 13:53:01 --> Language Class Initialized
INFO - 2018-10-22 13:53:01 --> Loader Class Initialized
INFO - 2018-10-22 13:53:02 --> Helper loaded: url_helper
INFO - 2018-10-22 13:53:02 --> Helper loaded: form_helper
INFO - 2018-10-22 13:53:02 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:53:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:53:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:53:02 --> User Agent Class Initialized
INFO - 2018-10-22 13:53:02 --> Controller Class Initialized
INFO - 2018-10-22 13:53:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:53:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:53:02 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:53:02 --> Pixel_Model class loaded
INFO - 2018-10-22 13:53:02 --> Database Driver Class Initialized
INFO - 2018-10-22 13:53:02 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:53:02 --> Form Validation Class Initialized
INFO - 2018-10-22 13:53:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:53:02 --> Database Driver Class Initialized
INFO - 2018-10-22 13:53:02 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:53:02 --> Config Class Initialized
INFO - 2018-10-22 13:53:02 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:53:02 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:53:02 --> Utf8 Class Initialized
INFO - 2018-10-22 13:53:02 --> URI Class Initialized
DEBUG - 2018-10-22 13:53:02 --> No URI present. Default controller set.
INFO - 2018-10-22 13:53:02 --> Router Class Initialized
INFO - 2018-10-22 13:53:02 --> Output Class Initialized
INFO - 2018-10-22 13:53:02 --> Security Class Initialized
DEBUG - 2018-10-22 13:53:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:53:02 --> CSRF cookie sent
INFO - 2018-10-22 13:53:02 --> Input Class Initialized
INFO - 2018-10-22 13:53:02 --> Language Class Initialized
INFO - 2018-10-22 13:53:02 --> Loader Class Initialized
INFO - 2018-10-22 13:53:02 --> Helper loaded: url_helper
INFO - 2018-10-22 13:53:02 --> Helper loaded: form_helper
INFO - 2018-10-22 13:53:02 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:53:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:53:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:53:02 --> User Agent Class Initialized
INFO - 2018-10-22 13:53:02 --> Controller Class Initialized
INFO - 2018-10-22 13:53:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:53:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:53:02 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:53:02 --> Pixel_Model class loaded
INFO - 2018-10-22 13:53:02 --> Database Driver Class Initialized
INFO - 2018-10-22 13:53:02 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:53:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:53:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:53:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-22 13:53:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:53:02 --> Final output sent to browser
DEBUG - 2018-10-22 13:53:02 --> Total execution time: 0.5086
INFO - 2018-10-22 13:53:09 --> Config Class Initialized
INFO - 2018-10-22 13:53:09 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:53:09 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:53:09 --> Utf8 Class Initialized
INFO - 2018-10-22 13:53:09 --> URI Class Initialized
INFO - 2018-10-22 13:53:09 --> Router Class Initialized
INFO - 2018-10-22 13:53:09 --> Output Class Initialized
INFO - 2018-10-22 13:53:09 --> Security Class Initialized
DEBUG - 2018-10-22 13:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:53:09 --> CSRF cookie sent
INFO - 2018-10-22 13:53:09 --> Input Class Initialized
INFO - 2018-10-22 13:53:09 --> Language Class Initialized
INFO - 2018-10-22 13:53:09 --> Loader Class Initialized
INFO - 2018-10-22 13:53:10 --> Helper loaded: url_helper
INFO - 2018-10-22 13:53:10 --> Helper loaded: form_helper
INFO - 2018-10-22 13:53:10 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:53:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:53:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:53:10 --> User Agent Class Initialized
INFO - 2018-10-22 13:53:10 --> Controller Class Initialized
INFO - 2018-10-22 13:53:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:53:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:53:10 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:53:10 --> Pixel_Model class loaded
INFO - 2018-10-22 13:53:10 --> Database Driver Class Initialized
INFO - 2018-10-22 13:53:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:53:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:53:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:53:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:53:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:53:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:53:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:53:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-22 13:53:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:53:10 --> Final output sent to browser
DEBUG - 2018-10-22 13:53:10 --> Total execution time: 0.5999
INFO - 2018-10-22 13:53:12 --> Config Class Initialized
INFO - 2018-10-22 13:53:12 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:53:12 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:53:12 --> Utf8 Class Initialized
INFO - 2018-10-22 13:53:12 --> URI Class Initialized
INFO - 2018-10-22 13:53:12 --> Router Class Initialized
INFO - 2018-10-22 13:53:12 --> Output Class Initialized
INFO - 2018-10-22 13:53:12 --> Security Class Initialized
DEBUG - 2018-10-22 13:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:53:12 --> CSRF cookie sent
INFO - 2018-10-22 13:53:12 --> CSRF token verified
INFO - 2018-10-22 13:53:12 --> Input Class Initialized
INFO - 2018-10-22 13:53:12 --> Language Class Initialized
INFO - 2018-10-22 13:53:12 --> Loader Class Initialized
INFO - 2018-10-22 13:53:12 --> Helper loaded: url_helper
INFO - 2018-10-22 13:53:12 --> Helper loaded: form_helper
INFO - 2018-10-22 13:53:12 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:53:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:53:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:53:12 --> User Agent Class Initialized
INFO - 2018-10-22 13:53:13 --> Controller Class Initialized
INFO - 2018-10-22 13:53:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:53:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:53:13 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:53:13 --> Pixel_Model class loaded
INFO - 2018-10-22 13:53:13 --> Database Driver Class Initialized
INFO - 2018-10-22 13:53:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:53:13 --> Form Validation Class Initialized
INFO - 2018-10-22 13:53:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:53:13 --> Database Driver Class Initialized
INFO - 2018-10-22 13:53:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:53:13 --> Config Class Initialized
INFO - 2018-10-22 13:53:13 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:53:13 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:53:13 --> Utf8 Class Initialized
INFO - 2018-10-22 13:53:13 --> URI Class Initialized
DEBUG - 2018-10-22 13:53:13 --> No URI present. Default controller set.
INFO - 2018-10-22 13:53:13 --> Router Class Initialized
INFO - 2018-10-22 13:53:13 --> Output Class Initialized
INFO - 2018-10-22 13:53:13 --> Security Class Initialized
DEBUG - 2018-10-22 13:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:53:13 --> CSRF cookie sent
INFO - 2018-10-22 13:53:13 --> Input Class Initialized
INFO - 2018-10-22 13:53:13 --> Language Class Initialized
INFO - 2018-10-22 13:53:13 --> Loader Class Initialized
INFO - 2018-10-22 13:53:13 --> Helper loaded: url_helper
INFO - 2018-10-22 13:53:13 --> Helper loaded: form_helper
INFO - 2018-10-22 13:53:13 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:53:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:53:13 --> User Agent Class Initialized
INFO - 2018-10-22 13:53:13 --> Controller Class Initialized
INFO - 2018-10-22 13:53:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:53:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:53:13 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:53:13 --> Pixel_Model class loaded
INFO - 2018-10-22 13:53:13 --> Database Driver Class Initialized
INFO - 2018-10-22 13:53:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:53:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:53:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:53:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-22 13:53:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:53:13 --> Final output sent to browser
DEBUG - 2018-10-22 13:53:13 --> Total execution time: 0.5245
INFO - 2018-10-22 13:53:31 --> Config Class Initialized
INFO - 2018-10-22 13:53:31 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:53:31 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:53:31 --> Utf8 Class Initialized
INFO - 2018-10-22 13:53:31 --> URI Class Initialized
INFO - 2018-10-22 13:53:32 --> Router Class Initialized
INFO - 2018-10-22 13:53:32 --> Output Class Initialized
INFO - 2018-10-22 13:53:32 --> Security Class Initialized
DEBUG - 2018-10-22 13:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:53:32 --> CSRF cookie sent
INFO - 2018-10-22 13:53:32 --> Input Class Initialized
INFO - 2018-10-22 13:53:32 --> Language Class Initialized
INFO - 2018-10-22 13:53:32 --> Loader Class Initialized
INFO - 2018-10-22 13:53:32 --> Helper loaded: url_helper
INFO - 2018-10-22 13:53:32 --> Helper loaded: form_helper
INFO - 2018-10-22 13:53:32 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:53:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:53:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:53:32 --> User Agent Class Initialized
INFO - 2018-10-22 13:53:32 --> Controller Class Initialized
INFO - 2018-10-22 13:53:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:53:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:53:32 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:53:32 --> Pixel_Model class loaded
INFO - 2018-10-22 13:53:32 --> Database Driver Class Initialized
INFO - 2018-10-22 13:53:32 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:53:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:53:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:53:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:53:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:53:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:53:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:53:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-22 13:53:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:53:32 --> Final output sent to browser
DEBUG - 2018-10-22 13:53:32 --> Total execution time: 0.6088
INFO - 2018-10-22 13:53:34 --> Config Class Initialized
INFO - 2018-10-22 13:53:34 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:53:34 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:53:34 --> Utf8 Class Initialized
INFO - 2018-10-22 13:53:34 --> URI Class Initialized
INFO - 2018-10-22 13:53:34 --> Router Class Initialized
INFO - 2018-10-22 13:53:34 --> Output Class Initialized
INFO - 2018-10-22 13:53:34 --> Security Class Initialized
DEBUG - 2018-10-22 13:53:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:53:34 --> CSRF cookie sent
INFO - 2018-10-22 13:53:34 --> CSRF token verified
INFO - 2018-10-22 13:53:34 --> Input Class Initialized
INFO - 2018-10-22 13:53:34 --> Language Class Initialized
INFO - 2018-10-22 13:53:34 --> Loader Class Initialized
INFO - 2018-10-22 13:53:35 --> Helper loaded: url_helper
INFO - 2018-10-22 13:53:35 --> Helper loaded: form_helper
INFO - 2018-10-22 13:53:35 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:53:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:53:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:53:35 --> User Agent Class Initialized
INFO - 2018-10-22 13:53:35 --> Controller Class Initialized
INFO - 2018-10-22 13:53:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:53:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:53:35 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:53:35 --> Pixel_Model class loaded
INFO - 2018-10-22 13:53:35 --> Database Driver Class Initialized
INFO - 2018-10-22 13:53:35 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:53:35 --> Form Validation Class Initialized
INFO - 2018-10-22 13:53:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:53:35 --> Database Driver Class Initialized
INFO - 2018-10-22 13:53:35 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:53:35 --> Config Class Initialized
INFO - 2018-10-22 13:53:35 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:53:35 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:53:35 --> Utf8 Class Initialized
INFO - 2018-10-22 13:53:35 --> URI Class Initialized
DEBUG - 2018-10-22 13:53:35 --> No URI present. Default controller set.
INFO - 2018-10-22 13:53:35 --> Router Class Initialized
INFO - 2018-10-22 13:53:35 --> Output Class Initialized
INFO - 2018-10-22 13:53:35 --> Security Class Initialized
DEBUG - 2018-10-22 13:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:53:35 --> CSRF cookie sent
INFO - 2018-10-22 13:53:35 --> Input Class Initialized
INFO - 2018-10-22 13:53:35 --> Language Class Initialized
INFO - 2018-10-22 13:53:35 --> Loader Class Initialized
INFO - 2018-10-22 13:53:35 --> Helper loaded: url_helper
INFO - 2018-10-22 13:53:35 --> Helper loaded: form_helper
INFO - 2018-10-22 13:53:35 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:53:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:53:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:53:35 --> User Agent Class Initialized
INFO - 2018-10-22 13:53:35 --> Controller Class Initialized
INFO - 2018-10-22 13:53:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:53:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:53:35 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:53:35 --> Pixel_Model class loaded
INFO - 2018-10-22 13:53:35 --> Database Driver Class Initialized
INFO - 2018-10-22 13:53:35 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:53:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:53:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:53:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-22 13:53:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:53:35 --> Final output sent to browser
DEBUG - 2018-10-22 13:53:35 --> Total execution time: 0.5179
INFO - 2018-10-22 13:53:41 --> Config Class Initialized
INFO - 2018-10-22 13:53:41 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:53:41 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:53:41 --> Utf8 Class Initialized
INFO - 2018-10-22 13:53:41 --> URI Class Initialized
INFO - 2018-10-22 13:53:41 --> Router Class Initialized
INFO - 2018-10-22 13:53:41 --> Output Class Initialized
INFO - 2018-10-22 13:53:41 --> Security Class Initialized
DEBUG - 2018-10-22 13:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:53:41 --> CSRF cookie sent
INFO - 2018-10-22 13:53:41 --> Input Class Initialized
INFO - 2018-10-22 13:53:41 --> Language Class Initialized
INFO - 2018-10-22 13:53:41 --> Loader Class Initialized
INFO - 2018-10-22 13:53:41 --> Helper loaded: url_helper
INFO - 2018-10-22 13:53:41 --> Helper loaded: form_helper
INFO - 2018-10-22 13:53:41 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:53:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:53:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:53:41 --> User Agent Class Initialized
INFO - 2018-10-22 13:53:41 --> Controller Class Initialized
INFO - 2018-10-22 13:53:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:53:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:53:41 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:53:41 --> Pixel_Model class loaded
INFO - 2018-10-22 13:53:41 --> Database Driver Class Initialized
INFO - 2018-10-22 13:53:41 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:53:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:53:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:53:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:53:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:53:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:53:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:53:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-22 13:53:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:53:42 --> Final output sent to browser
DEBUG - 2018-10-22 13:53:42 --> Total execution time: 0.6312
INFO - 2018-10-22 13:54:48 --> Config Class Initialized
INFO - 2018-10-22 13:54:48 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:54:48 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:54:48 --> Utf8 Class Initialized
INFO - 2018-10-22 13:54:48 --> URI Class Initialized
INFO - 2018-10-22 13:54:48 --> Router Class Initialized
INFO - 2018-10-22 13:54:48 --> Output Class Initialized
INFO - 2018-10-22 13:54:48 --> Security Class Initialized
DEBUG - 2018-10-22 13:54:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:54:48 --> CSRF cookie sent
INFO - 2018-10-22 13:54:48 --> Input Class Initialized
INFO - 2018-10-22 13:54:48 --> Language Class Initialized
INFO - 2018-10-22 13:54:48 --> Loader Class Initialized
INFO - 2018-10-22 13:54:48 --> Helper loaded: url_helper
INFO - 2018-10-22 13:54:48 --> Helper loaded: form_helper
INFO - 2018-10-22 13:54:48 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:54:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:54:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:54:48 --> User Agent Class Initialized
INFO - 2018-10-22 13:54:48 --> Controller Class Initialized
INFO - 2018-10-22 13:54:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:54:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:54:48 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:54:49 --> Pixel_Model class loaded
INFO - 2018-10-22 13:54:49 --> Database Driver Class Initialized
INFO - 2018-10-22 13:54:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:54:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:54:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:54:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:54:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:54:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:54:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:54:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-22 13:54:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:54:49 --> Final output sent to browser
DEBUG - 2018-10-22 13:54:49 --> Total execution time: 0.5921
INFO - 2018-10-22 13:54:51 --> Config Class Initialized
INFO - 2018-10-22 13:54:51 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:54:51 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:54:51 --> Utf8 Class Initialized
INFO - 2018-10-22 13:54:51 --> URI Class Initialized
INFO - 2018-10-22 13:54:51 --> Router Class Initialized
INFO - 2018-10-22 13:54:51 --> Output Class Initialized
INFO - 2018-10-22 13:54:52 --> Security Class Initialized
DEBUG - 2018-10-22 13:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:54:52 --> CSRF cookie sent
INFO - 2018-10-22 13:54:52 --> CSRF token verified
INFO - 2018-10-22 13:54:52 --> Input Class Initialized
INFO - 2018-10-22 13:54:52 --> Language Class Initialized
INFO - 2018-10-22 13:54:52 --> Loader Class Initialized
INFO - 2018-10-22 13:54:52 --> Helper loaded: url_helper
INFO - 2018-10-22 13:54:52 --> Helper loaded: form_helper
INFO - 2018-10-22 13:54:52 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:54:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:54:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:54:52 --> User Agent Class Initialized
INFO - 2018-10-22 13:54:52 --> Controller Class Initialized
INFO - 2018-10-22 13:54:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:54:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:54:52 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:54:52 --> Pixel_Model class loaded
INFO - 2018-10-22 13:54:52 --> Database Driver Class Initialized
INFO - 2018-10-22 13:54:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:54:52 --> Form Validation Class Initialized
INFO - 2018-10-22 13:54:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:54:52 --> Database Driver Class Initialized
INFO - 2018-10-22 13:54:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:54:52 --> Config Class Initialized
INFO - 2018-10-22 13:54:52 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:54:52 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:54:52 --> Utf8 Class Initialized
INFO - 2018-10-22 13:54:52 --> URI Class Initialized
DEBUG - 2018-10-22 13:54:52 --> No URI present. Default controller set.
INFO - 2018-10-22 13:54:52 --> Router Class Initialized
INFO - 2018-10-22 13:54:52 --> Output Class Initialized
INFO - 2018-10-22 13:54:52 --> Security Class Initialized
DEBUG - 2018-10-22 13:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:54:52 --> CSRF cookie sent
INFO - 2018-10-22 13:54:52 --> Input Class Initialized
INFO - 2018-10-22 13:54:52 --> Language Class Initialized
INFO - 2018-10-22 13:54:52 --> Loader Class Initialized
INFO - 2018-10-22 13:54:52 --> Helper loaded: url_helper
INFO - 2018-10-22 13:54:52 --> Helper loaded: form_helper
INFO - 2018-10-22 13:54:52 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:54:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:54:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:54:52 --> User Agent Class Initialized
INFO - 2018-10-22 13:54:52 --> Controller Class Initialized
INFO - 2018-10-22 13:54:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:54:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:54:52 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:54:52 --> Pixel_Model class loaded
INFO - 2018-10-22 13:54:52 --> Database Driver Class Initialized
INFO - 2018-10-22 13:54:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:54:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:54:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:54:53 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-22 13:54:53 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:54:53 --> Final output sent to browser
DEBUG - 2018-10-22 13:54:53 --> Total execution time: 0.5365
INFO - 2018-10-22 13:54:54 --> Config Class Initialized
INFO - 2018-10-22 13:54:54 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:54:54 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:54:55 --> Utf8 Class Initialized
INFO - 2018-10-22 13:54:55 --> URI Class Initialized
INFO - 2018-10-22 13:54:55 --> Router Class Initialized
INFO - 2018-10-22 13:54:55 --> Output Class Initialized
INFO - 2018-10-22 13:54:55 --> Security Class Initialized
DEBUG - 2018-10-22 13:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:54:55 --> CSRF cookie sent
INFO - 2018-10-22 13:54:55 --> Input Class Initialized
INFO - 2018-10-22 13:54:55 --> Language Class Initialized
INFO - 2018-10-22 13:54:55 --> Loader Class Initialized
INFO - 2018-10-22 13:54:55 --> Helper loaded: url_helper
INFO - 2018-10-22 13:54:55 --> Helper loaded: form_helper
INFO - 2018-10-22 13:54:55 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:54:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:54:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:54:55 --> User Agent Class Initialized
INFO - 2018-10-22 13:54:55 --> Controller Class Initialized
INFO - 2018-10-22 13:54:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:54:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:54:55 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:54:55 --> Pixel_Model class loaded
INFO - 2018-10-22 13:54:55 --> Database Driver Class Initialized
INFO - 2018-10-22 13:54:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:54:55 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:54:55 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:54:55 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:54:55 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:54:55 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:54:55 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:54:55 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-22 13:54:55 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:54:55 --> Final output sent to browser
DEBUG - 2018-10-22 13:54:55 --> Total execution time: 0.6463
INFO - 2018-10-22 13:54:58 --> Config Class Initialized
INFO - 2018-10-22 13:54:58 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:54:58 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:54:58 --> Utf8 Class Initialized
INFO - 2018-10-22 13:54:58 --> URI Class Initialized
INFO - 2018-10-22 13:54:58 --> Router Class Initialized
INFO - 2018-10-22 13:54:58 --> Output Class Initialized
INFO - 2018-10-22 13:54:58 --> Security Class Initialized
DEBUG - 2018-10-22 13:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:54:58 --> CSRF cookie sent
INFO - 2018-10-22 13:54:58 --> CSRF token verified
INFO - 2018-10-22 13:54:58 --> Input Class Initialized
INFO - 2018-10-22 13:54:58 --> Language Class Initialized
INFO - 2018-10-22 13:54:58 --> Loader Class Initialized
INFO - 2018-10-22 13:54:58 --> Helper loaded: url_helper
INFO - 2018-10-22 13:54:58 --> Helper loaded: form_helper
INFO - 2018-10-22 13:54:58 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:54:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:54:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:54:58 --> User Agent Class Initialized
INFO - 2018-10-22 13:54:58 --> Controller Class Initialized
INFO - 2018-10-22 13:54:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:54:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:54:58 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:54:58 --> Pixel_Model class loaded
INFO - 2018-10-22 13:54:58 --> Database Driver Class Initialized
INFO - 2018-10-22 13:54:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:54:58 --> Form Validation Class Initialized
INFO - 2018-10-22 13:54:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:54:59 --> Database Driver Class Initialized
INFO - 2018-10-22 13:54:59 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:54:59 --> Config Class Initialized
INFO - 2018-10-22 13:54:59 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:54:59 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:54:59 --> Utf8 Class Initialized
INFO - 2018-10-22 13:54:59 --> URI Class Initialized
DEBUG - 2018-10-22 13:54:59 --> No URI present. Default controller set.
INFO - 2018-10-22 13:54:59 --> Router Class Initialized
INFO - 2018-10-22 13:54:59 --> Output Class Initialized
INFO - 2018-10-22 13:54:59 --> Security Class Initialized
DEBUG - 2018-10-22 13:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:54:59 --> CSRF cookie sent
INFO - 2018-10-22 13:54:59 --> Input Class Initialized
INFO - 2018-10-22 13:54:59 --> Language Class Initialized
INFO - 2018-10-22 13:54:59 --> Loader Class Initialized
INFO - 2018-10-22 13:54:59 --> Helper loaded: url_helper
INFO - 2018-10-22 13:54:59 --> Helper loaded: form_helper
INFO - 2018-10-22 13:54:59 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:54:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:54:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:54:59 --> User Agent Class Initialized
INFO - 2018-10-22 13:54:59 --> Controller Class Initialized
INFO - 2018-10-22 13:54:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:54:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:54:59 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:54:59 --> Pixel_Model class loaded
INFO - 2018-10-22 13:54:59 --> Database Driver Class Initialized
INFO - 2018-10-22 13:54:59 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:54:59 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:54:59 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:54:59 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-22 13:54:59 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:54:59 --> Final output sent to browser
DEBUG - 2018-10-22 13:54:59 --> Total execution time: 0.5424
INFO - 2018-10-22 13:55:56 --> Config Class Initialized
INFO - 2018-10-22 13:55:57 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:55:57 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:55:57 --> Utf8 Class Initialized
INFO - 2018-10-22 13:55:57 --> URI Class Initialized
DEBUG - 2018-10-22 13:55:57 --> No URI present. Default controller set.
INFO - 2018-10-22 13:55:57 --> Router Class Initialized
INFO - 2018-10-22 13:55:57 --> Output Class Initialized
INFO - 2018-10-22 13:55:57 --> Security Class Initialized
DEBUG - 2018-10-22 13:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:55:57 --> CSRF cookie sent
INFO - 2018-10-22 13:55:57 --> Input Class Initialized
INFO - 2018-10-22 13:55:57 --> Language Class Initialized
INFO - 2018-10-22 13:55:57 --> Loader Class Initialized
INFO - 2018-10-22 13:55:57 --> Helper loaded: url_helper
INFO - 2018-10-22 13:55:57 --> Helper loaded: form_helper
INFO - 2018-10-22 13:55:57 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:55:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:55:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:55:57 --> User Agent Class Initialized
INFO - 2018-10-22 13:55:57 --> Controller Class Initialized
INFO - 2018-10-22 13:55:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:55:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:55:57 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:55:57 --> Pixel_Model class loaded
INFO - 2018-10-22 13:55:57 --> Database Driver Class Initialized
INFO - 2018-10-22 13:55:57 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:55:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:55:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:55:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-22 13:55:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:55:57 --> Final output sent to browser
DEBUG - 2018-10-22 13:55:57 --> Total execution time: 0.5718
INFO - 2018-10-22 13:55:58 --> Config Class Initialized
INFO - 2018-10-22 13:55:58 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:55:58 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:55:58 --> Utf8 Class Initialized
INFO - 2018-10-22 13:55:58 --> URI Class Initialized
INFO - 2018-10-22 13:55:58 --> Router Class Initialized
INFO - 2018-10-22 13:55:58 --> Output Class Initialized
INFO - 2018-10-22 13:55:58 --> Security Class Initialized
DEBUG - 2018-10-22 13:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:55:58 --> CSRF cookie sent
INFO - 2018-10-22 13:55:58 --> Input Class Initialized
INFO - 2018-10-22 13:55:58 --> Language Class Initialized
INFO - 2018-10-22 13:55:58 --> Loader Class Initialized
INFO - 2018-10-22 13:55:58 --> Helper loaded: url_helper
INFO - 2018-10-22 13:55:58 --> Helper loaded: form_helper
INFO - 2018-10-22 13:55:58 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:55:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:55:58 --> User Agent Class Initialized
INFO - 2018-10-22 13:55:59 --> Controller Class Initialized
INFO - 2018-10-22 13:55:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:55:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:55:59 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:55:59 --> Pixel_Model class loaded
INFO - 2018-10-22 13:55:59 --> Database Driver Class Initialized
INFO - 2018-10-22 13:55:59 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:55:59 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:55:59 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:55:59 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:55:59 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:55:59 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:55:59 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:55:59 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-22 13:55:59 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:55:59 --> Final output sent to browser
DEBUG - 2018-10-22 13:55:59 --> Total execution time: 0.8320
INFO - 2018-10-22 13:56:02 --> Config Class Initialized
INFO - 2018-10-22 13:56:02 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:56:02 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:56:02 --> Utf8 Class Initialized
INFO - 2018-10-22 13:56:02 --> URI Class Initialized
INFO - 2018-10-22 13:56:02 --> Router Class Initialized
INFO - 2018-10-22 13:56:02 --> Output Class Initialized
INFO - 2018-10-22 13:56:02 --> Security Class Initialized
DEBUG - 2018-10-22 13:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:56:02 --> CSRF cookie sent
INFO - 2018-10-22 13:56:02 --> CSRF token verified
INFO - 2018-10-22 13:56:02 --> Input Class Initialized
INFO - 2018-10-22 13:56:02 --> Language Class Initialized
INFO - 2018-10-22 13:56:02 --> Loader Class Initialized
INFO - 2018-10-22 13:56:02 --> Helper loaded: url_helper
INFO - 2018-10-22 13:56:02 --> Helper loaded: form_helper
INFO - 2018-10-22 13:56:02 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:56:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:56:02 --> User Agent Class Initialized
INFO - 2018-10-22 13:56:02 --> Controller Class Initialized
INFO - 2018-10-22 13:56:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:56:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:56:02 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:56:02 --> Pixel_Model class loaded
INFO - 2018-10-22 13:56:02 --> Database Driver Class Initialized
INFO - 2018-10-22 13:56:02 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:56:02 --> Form Validation Class Initialized
INFO - 2018-10-22 13:56:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:56:02 --> Database Driver Class Initialized
INFO - 2018-10-22 13:56:02 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:56:02 --> Config Class Initialized
INFO - 2018-10-22 13:56:02 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:56:02 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:56:02 --> Utf8 Class Initialized
INFO - 2018-10-22 13:56:02 --> URI Class Initialized
INFO - 2018-10-22 13:56:02 --> Router Class Initialized
INFO - 2018-10-22 13:56:02 --> Output Class Initialized
INFO - 2018-10-22 13:56:02 --> Security Class Initialized
DEBUG - 2018-10-22 13:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:56:02 --> CSRF cookie sent
INFO - 2018-10-22 13:56:02 --> Input Class Initialized
INFO - 2018-10-22 13:56:02 --> Language Class Initialized
INFO - 2018-10-22 13:56:02 --> Loader Class Initialized
INFO - 2018-10-22 13:56:02 --> Helper loaded: url_helper
INFO - 2018-10-22 13:56:02 --> Helper loaded: form_helper
INFO - 2018-10-22 13:56:02 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:56:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:56:02 --> User Agent Class Initialized
INFO - 2018-10-22 13:56:02 --> Controller Class Initialized
INFO - 2018-10-22 13:56:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:56:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:56:03 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:56:03 --> Pixel_Model class loaded
INFO - 2018-10-22 13:56:03 --> Database Driver Class Initialized
INFO - 2018-10-22 13:56:03 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:56:03 --> Database Driver Class Initialized
INFO - 2018-10-22 13:56:03 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:56:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:56:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:56:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:56:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:56:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:56:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:56:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-22 13:56:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:56:03 --> Final output sent to browser
DEBUG - 2018-10-22 13:56:03 --> Total execution time: 0.6388
INFO - 2018-10-22 13:56:20 --> Config Class Initialized
INFO - 2018-10-22 13:56:20 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:56:20 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:56:20 --> Utf8 Class Initialized
INFO - 2018-10-22 13:56:20 --> URI Class Initialized
INFO - 2018-10-22 13:56:20 --> Router Class Initialized
INFO - 2018-10-22 13:56:20 --> Output Class Initialized
INFO - 2018-10-22 13:56:20 --> Security Class Initialized
DEBUG - 2018-10-22 13:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:56:20 --> CSRF cookie sent
INFO - 2018-10-22 13:56:20 --> Input Class Initialized
INFO - 2018-10-22 13:56:20 --> Language Class Initialized
INFO - 2018-10-22 13:56:20 --> Loader Class Initialized
INFO - 2018-10-22 13:56:21 --> Helper loaded: url_helper
INFO - 2018-10-22 13:56:21 --> Helper loaded: form_helper
INFO - 2018-10-22 13:56:21 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:56:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:56:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:56:21 --> User Agent Class Initialized
INFO - 2018-10-22 13:56:21 --> Controller Class Initialized
INFO - 2018-10-22 13:56:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:56:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:56:21 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:56:21 --> Pixel_Model class loaded
INFO - 2018-10-22 13:56:21 --> Database Driver Class Initialized
INFO - 2018-10-22 13:56:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:56:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:56:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:56:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:56:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:56:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:56:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:56:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-22 13:56:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:56:21 --> Final output sent to browser
DEBUG - 2018-10-22 13:56:21 --> Total execution time: 0.6069
INFO - 2018-10-22 13:56:22 --> Config Class Initialized
INFO - 2018-10-22 13:56:22 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:56:22 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:56:22 --> Utf8 Class Initialized
INFO - 2018-10-22 13:56:22 --> URI Class Initialized
INFO - 2018-10-22 13:56:22 --> Router Class Initialized
INFO - 2018-10-22 13:56:22 --> Output Class Initialized
INFO - 2018-10-22 13:56:22 --> Security Class Initialized
DEBUG - 2018-10-22 13:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:56:22 --> CSRF cookie sent
INFO - 2018-10-22 13:56:22 --> Input Class Initialized
INFO - 2018-10-22 13:56:22 --> Language Class Initialized
INFO - 2018-10-22 13:56:22 --> Loader Class Initialized
INFO - 2018-10-22 13:56:22 --> Helper loaded: url_helper
INFO - 2018-10-22 13:56:22 --> Helper loaded: form_helper
INFO - 2018-10-22 13:56:22 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:56:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:56:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:56:22 --> User Agent Class Initialized
INFO - 2018-10-22 13:56:22 --> Controller Class Initialized
INFO - 2018-10-22 13:56:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:56:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:56:22 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:56:22 --> Pixel_Model class loaded
INFO - 2018-10-22 13:56:22 --> Database Driver Class Initialized
INFO - 2018-10-22 13:56:22 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:56:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:56:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:56:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:56:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:56:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:56:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:56:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-22 13:56:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:56:22 --> Final output sent to browser
DEBUG - 2018-10-22 13:56:22 --> Total execution time: 0.6044
INFO - 2018-10-22 13:56:24 --> Config Class Initialized
INFO - 2018-10-22 13:56:24 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:56:24 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:56:25 --> Utf8 Class Initialized
INFO - 2018-10-22 13:56:25 --> URI Class Initialized
INFO - 2018-10-22 13:56:25 --> Router Class Initialized
INFO - 2018-10-22 13:56:25 --> Output Class Initialized
INFO - 2018-10-22 13:56:25 --> Security Class Initialized
DEBUG - 2018-10-22 13:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:56:25 --> CSRF cookie sent
INFO - 2018-10-22 13:56:25 --> CSRF token verified
INFO - 2018-10-22 13:56:25 --> Input Class Initialized
INFO - 2018-10-22 13:56:25 --> Language Class Initialized
INFO - 2018-10-22 13:56:25 --> Loader Class Initialized
INFO - 2018-10-22 13:56:25 --> Helper loaded: url_helper
INFO - 2018-10-22 13:56:25 --> Helper loaded: form_helper
INFO - 2018-10-22 13:56:25 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:56:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:56:25 --> User Agent Class Initialized
INFO - 2018-10-22 13:56:25 --> Controller Class Initialized
INFO - 2018-10-22 13:56:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:56:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:56:25 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:56:25 --> Pixel_Model class loaded
INFO - 2018-10-22 13:56:25 --> Database Driver Class Initialized
INFO - 2018-10-22 13:56:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:56:25 --> Form Validation Class Initialized
INFO - 2018-10-22 13:56:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:56:25 --> Database Driver Class Initialized
INFO - 2018-10-22 13:56:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:56:25 --> Config Class Initialized
INFO - 2018-10-22 13:56:25 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:56:25 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:56:25 --> Utf8 Class Initialized
INFO - 2018-10-22 13:56:25 --> URI Class Initialized
INFO - 2018-10-22 13:56:25 --> Router Class Initialized
INFO - 2018-10-22 13:56:25 --> Output Class Initialized
INFO - 2018-10-22 13:56:25 --> Security Class Initialized
DEBUG - 2018-10-22 13:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:56:25 --> CSRF cookie sent
INFO - 2018-10-22 13:56:25 --> Input Class Initialized
INFO - 2018-10-22 13:56:25 --> Language Class Initialized
INFO - 2018-10-22 13:56:25 --> Loader Class Initialized
INFO - 2018-10-22 13:56:25 --> Helper loaded: url_helper
INFO - 2018-10-22 13:56:25 --> Helper loaded: form_helper
INFO - 2018-10-22 13:56:25 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:56:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:56:25 --> User Agent Class Initialized
INFO - 2018-10-22 13:56:25 --> Controller Class Initialized
INFO - 2018-10-22 13:56:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:56:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:56:25 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:56:25 --> Pixel_Model class loaded
INFO - 2018-10-22 13:56:25 --> Database Driver Class Initialized
INFO - 2018-10-22 13:56:26 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:56:26 --> Database Driver Class Initialized
INFO - 2018-10-22 13:56:26 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:56:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:56:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:56:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:56:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:56:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:56:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:56:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-22 13:56:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:56:26 --> Final output sent to browser
DEBUG - 2018-10-22 13:56:26 --> Total execution time: 0.6563
INFO - 2018-10-22 13:57:16 --> Config Class Initialized
INFO - 2018-10-22 13:57:16 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:57:16 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:57:16 --> Utf8 Class Initialized
INFO - 2018-10-22 13:57:16 --> URI Class Initialized
INFO - 2018-10-22 13:57:16 --> Router Class Initialized
INFO - 2018-10-22 13:57:17 --> Output Class Initialized
INFO - 2018-10-22 13:57:17 --> Security Class Initialized
DEBUG - 2018-10-22 13:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:57:17 --> CSRF cookie sent
INFO - 2018-10-22 13:57:17 --> Input Class Initialized
INFO - 2018-10-22 13:57:17 --> Language Class Initialized
INFO - 2018-10-22 13:57:17 --> Loader Class Initialized
INFO - 2018-10-22 13:57:17 --> Helper loaded: url_helper
INFO - 2018-10-22 13:57:17 --> Helper loaded: form_helper
INFO - 2018-10-22 13:57:17 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:57:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:57:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:57:17 --> User Agent Class Initialized
INFO - 2018-10-22 13:57:17 --> Controller Class Initialized
INFO - 2018-10-22 13:57:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:57:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:57:17 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:57:17 --> Pixel_Model class loaded
INFO - 2018-10-22 13:57:17 --> Database Driver Class Initialized
INFO - 2018-10-22 13:57:17 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:57:17 --> Database Driver Class Initialized
INFO - 2018-10-22 13:57:17 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:57:34 --> Config Class Initialized
INFO - 2018-10-22 13:57:34 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:57:34 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:57:34 --> Utf8 Class Initialized
INFO - 2018-10-22 13:57:34 --> URI Class Initialized
INFO - 2018-10-22 13:57:34 --> Router Class Initialized
INFO - 2018-10-22 13:57:34 --> Output Class Initialized
INFO - 2018-10-22 13:57:34 --> Security Class Initialized
DEBUG - 2018-10-22 13:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:57:34 --> CSRF cookie sent
INFO - 2018-10-22 13:57:34 --> Input Class Initialized
INFO - 2018-10-22 13:57:34 --> Language Class Initialized
INFO - 2018-10-22 13:57:34 --> Loader Class Initialized
INFO - 2018-10-22 13:57:34 --> Helper loaded: url_helper
INFO - 2018-10-22 13:57:34 --> Helper loaded: form_helper
INFO - 2018-10-22 13:57:34 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:57:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:57:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:57:34 --> User Agent Class Initialized
INFO - 2018-10-22 13:57:34 --> Controller Class Initialized
INFO - 2018-10-22 13:57:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:57:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:57:35 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:57:35 --> Pixel_Model class loaded
INFO - 2018-10-22 13:57:35 --> Database Driver Class Initialized
INFO - 2018-10-22 13:57:35 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:57:35 --> Database Driver Class Initialized
INFO - 2018-10-22 13:57:35 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:57:40 --> Config Class Initialized
INFO - 2018-10-22 13:57:40 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:57:40 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:57:40 --> Utf8 Class Initialized
INFO - 2018-10-22 13:57:40 --> URI Class Initialized
INFO - 2018-10-22 13:57:41 --> Router Class Initialized
INFO - 2018-10-22 13:57:41 --> Output Class Initialized
INFO - 2018-10-22 13:57:41 --> Security Class Initialized
DEBUG - 2018-10-22 13:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:57:41 --> CSRF cookie sent
INFO - 2018-10-22 13:57:41 --> Input Class Initialized
INFO - 2018-10-22 13:57:41 --> Language Class Initialized
INFO - 2018-10-22 13:57:41 --> Loader Class Initialized
INFO - 2018-10-22 13:57:41 --> Helper loaded: url_helper
INFO - 2018-10-22 13:57:41 --> Helper loaded: form_helper
INFO - 2018-10-22 13:57:41 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:57:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:57:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:57:41 --> User Agent Class Initialized
INFO - 2018-10-22 13:57:41 --> Controller Class Initialized
INFO - 2018-10-22 13:57:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:57:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:57:41 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:57:41 --> Pixel_Model class loaded
INFO - 2018-10-22 13:57:41 --> Database Driver Class Initialized
INFO - 2018-10-22 13:57:41 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:57:41 --> Database Driver Class Initialized
INFO - 2018-10-22 13:57:41 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:57:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:57:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:57:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:57:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:57:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:57:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:57:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-22 13:57:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:57:41 --> Final output sent to browser
DEBUG - 2018-10-22 13:57:41 --> Total execution time: 0.6400
INFO - 2018-10-22 13:57:43 --> Config Class Initialized
INFO - 2018-10-22 13:57:43 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:57:43 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:57:43 --> Utf8 Class Initialized
INFO - 2018-10-22 13:57:43 --> URI Class Initialized
INFO - 2018-10-22 13:57:43 --> Router Class Initialized
INFO - 2018-10-22 13:57:43 --> Output Class Initialized
INFO - 2018-10-22 13:57:43 --> Security Class Initialized
DEBUG - 2018-10-22 13:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:57:43 --> CSRF cookie sent
INFO - 2018-10-22 13:57:43 --> Input Class Initialized
INFO - 2018-10-22 13:57:43 --> Language Class Initialized
INFO - 2018-10-22 13:57:43 --> Loader Class Initialized
INFO - 2018-10-22 13:57:43 --> Helper loaded: url_helper
INFO - 2018-10-22 13:57:43 --> Helper loaded: form_helper
INFO - 2018-10-22 13:57:43 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:57:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:57:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:57:43 --> User Agent Class Initialized
INFO - 2018-10-22 13:57:43 --> Controller Class Initialized
INFO - 2018-10-22 13:57:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:57:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:57:43 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:57:43 --> Pixel_Model class loaded
INFO - 2018-10-22 13:57:44 --> Database Driver Class Initialized
INFO - 2018-10-22 13:57:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:57:44 --> Database Driver Class Initialized
INFO - 2018-10-22 13:57:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:57:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:57:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:57:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:57:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:57:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:57:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:57:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-22 13:57:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:57:44 --> Final output sent to browser
DEBUG - 2018-10-22 13:57:44 --> Total execution time: 0.6361
INFO - 2018-10-22 13:57:47 --> Config Class Initialized
INFO - 2018-10-22 13:57:47 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:57:47 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:57:47 --> Utf8 Class Initialized
INFO - 2018-10-22 13:57:47 --> URI Class Initialized
INFO - 2018-10-22 13:57:47 --> Router Class Initialized
INFO - 2018-10-22 13:57:47 --> Output Class Initialized
INFO - 2018-10-22 13:57:47 --> Security Class Initialized
DEBUG - 2018-10-22 13:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:57:47 --> CSRF cookie sent
INFO - 2018-10-22 13:57:47 --> Input Class Initialized
INFO - 2018-10-22 13:57:47 --> Language Class Initialized
INFO - 2018-10-22 13:57:47 --> Loader Class Initialized
INFO - 2018-10-22 13:57:47 --> Helper loaded: url_helper
INFO - 2018-10-22 13:57:47 --> Helper loaded: form_helper
INFO - 2018-10-22 13:57:47 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:57:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:57:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:57:47 --> User Agent Class Initialized
INFO - 2018-10-22 13:57:47 --> Controller Class Initialized
INFO - 2018-10-22 13:57:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:57:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:57:47 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:57:47 --> Pixel_Model class loaded
INFO - 2018-10-22 13:57:47 --> Database Driver Class Initialized
INFO - 2018-10-22 13:57:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:57:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:57:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:57:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:57:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:57:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:57:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:57:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-22 13:57:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:57:47 --> Final output sent to browser
DEBUG - 2018-10-22 13:57:47 --> Total execution time: 0.6403
INFO - 2018-10-22 13:57:50 --> Config Class Initialized
INFO - 2018-10-22 13:57:50 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:57:50 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:57:50 --> Utf8 Class Initialized
INFO - 2018-10-22 13:57:50 --> URI Class Initialized
INFO - 2018-10-22 13:57:50 --> Router Class Initialized
INFO - 2018-10-22 13:57:50 --> Output Class Initialized
INFO - 2018-10-22 13:57:50 --> Security Class Initialized
DEBUG - 2018-10-22 13:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:57:50 --> CSRF cookie sent
INFO - 2018-10-22 13:57:50 --> CSRF token verified
INFO - 2018-10-22 13:57:50 --> Input Class Initialized
INFO - 2018-10-22 13:57:50 --> Language Class Initialized
INFO - 2018-10-22 13:57:50 --> Loader Class Initialized
INFO - 2018-10-22 13:57:50 --> Helper loaded: url_helper
INFO - 2018-10-22 13:57:50 --> Helper loaded: form_helper
INFO - 2018-10-22 13:57:50 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:57:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:57:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:57:50 --> User Agent Class Initialized
INFO - 2018-10-22 13:57:50 --> Controller Class Initialized
INFO - 2018-10-22 13:57:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:57:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:57:50 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:57:50 --> Pixel_Model class loaded
INFO - 2018-10-22 13:57:50 --> Database Driver Class Initialized
INFO - 2018-10-22 13:57:50 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:57:50 --> Form Validation Class Initialized
INFO - 2018-10-22 13:57:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:57:50 --> Database Driver Class Initialized
INFO - 2018-10-22 13:57:50 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:57:50 --> Config Class Initialized
INFO - 2018-10-22 13:57:50 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:57:50 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:57:50 --> Utf8 Class Initialized
INFO - 2018-10-22 13:57:50 --> URI Class Initialized
INFO - 2018-10-22 13:57:50 --> Router Class Initialized
INFO - 2018-10-22 13:57:50 --> Output Class Initialized
INFO - 2018-10-22 13:57:50 --> Security Class Initialized
DEBUG - 2018-10-22 13:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:57:50 --> CSRF cookie sent
INFO - 2018-10-22 13:57:50 --> Input Class Initialized
INFO - 2018-10-22 13:57:50 --> Language Class Initialized
INFO - 2018-10-22 13:57:50 --> Loader Class Initialized
INFO - 2018-10-22 13:57:50 --> Helper loaded: url_helper
INFO - 2018-10-22 13:57:51 --> Helper loaded: form_helper
INFO - 2018-10-22 13:57:51 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:57:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:57:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:57:51 --> User Agent Class Initialized
INFO - 2018-10-22 13:57:51 --> Controller Class Initialized
INFO - 2018-10-22 13:57:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:57:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:57:51 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:57:51 --> Pixel_Model class loaded
INFO - 2018-10-22 13:57:51 --> Database Driver Class Initialized
INFO - 2018-10-22 13:57:51 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:57:51 --> Database Driver Class Initialized
INFO - 2018-10-22 13:57:51 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:57:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:57:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:57:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:57:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:57:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:57:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:57:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-22 13:57:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:57:51 --> Final output sent to browser
DEBUG - 2018-10-22 13:57:51 --> Total execution time: 0.6560
INFO - 2018-10-22 13:57:54 --> Config Class Initialized
INFO - 2018-10-22 13:57:54 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:57:54 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:57:54 --> Utf8 Class Initialized
INFO - 2018-10-22 13:57:54 --> URI Class Initialized
INFO - 2018-10-22 13:57:54 --> Router Class Initialized
INFO - 2018-10-22 13:57:54 --> Output Class Initialized
INFO - 2018-10-22 13:57:54 --> Security Class Initialized
DEBUG - 2018-10-22 13:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:57:54 --> CSRF cookie sent
INFO - 2018-10-22 13:57:54 --> CSRF token verified
INFO - 2018-10-22 13:57:55 --> Input Class Initialized
INFO - 2018-10-22 13:57:55 --> Language Class Initialized
INFO - 2018-10-22 13:57:55 --> Loader Class Initialized
INFO - 2018-10-22 13:57:55 --> Helper loaded: url_helper
INFO - 2018-10-22 13:57:55 --> Helper loaded: form_helper
INFO - 2018-10-22 13:57:55 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:57:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:57:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:57:55 --> User Agent Class Initialized
INFO - 2018-10-22 13:57:55 --> Controller Class Initialized
INFO - 2018-10-22 13:57:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:57:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:57:55 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:57:55 --> Pixel_Model class loaded
INFO - 2018-10-22 13:57:55 --> Database Driver Class Initialized
INFO - 2018-10-22 13:57:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:57:55 --> Form Validation Class Initialized
INFO - 2018-10-22 13:57:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:57:55 --> Database Driver Class Initialized
INFO - 2018-10-22 13:57:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:57:55 --> Config Class Initialized
INFO - 2018-10-22 13:57:55 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:57:55 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:57:55 --> Utf8 Class Initialized
INFO - 2018-10-22 13:57:55 --> URI Class Initialized
INFO - 2018-10-22 13:57:55 --> Router Class Initialized
INFO - 2018-10-22 13:57:55 --> Output Class Initialized
INFO - 2018-10-22 13:57:55 --> Security Class Initialized
DEBUG - 2018-10-22 13:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:57:55 --> CSRF cookie sent
INFO - 2018-10-22 13:57:55 --> Input Class Initialized
INFO - 2018-10-22 13:57:55 --> Language Class Initialized
INFO - 2018-10-22 13:57:55 --> Loader Class Initialized
INFO - 2018-10-22 13:57:55 --> Helper loaded: url_helper
INFO - 2018-10-22 13:57:55 --> Helper loaded: form_helper
INFO - 2018-10-22 13:57:55 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:57:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:57:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:57:55 --> User Agent Class Initialized
INFO - 2018-10-22 13:57:55 --> Controller Class Initialized
INFO - 2018-10-22 13:57:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:57:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:57:55 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:57:55 --> Pixel_Model class loaded
INFO - 2018-10-22 13:57:56 --> Database Driver Class Initialized
INFO - 2018-10-22 13:57:56 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:57:56 --> Database Driver Class Initialized
INFO - 2018-10-22 13:57:56 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:57:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:57:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:57:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:57:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:57:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:57:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:57:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/your_job.php
INFO - 2018-10-22 13:57:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:57:56 --> Final output sent to browser
DEBUG - 2018-10-22 13:57:56 --> Total execution time: 0.6876
INFO - 2018-10-22 13:57:59 --> Config Class Initialized
INFO - 2018-10-22 13:57:59 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:57:59 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:57:59 --> Utf8 Class Initialized
INFO - 2018-10-22 13:57:59 --> URI Class Initialized
INFO - 2018-10-22 13:57:59 --> Router Class Initialized
INFO - 2018-10-22 13:57:59 --> Output Class Initialized
INFO - 2018-10-22 13:57:59 --> Security Class Initialized
DEBUG - 2018-10-22 13:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:57:59 --> CSRF cookie sent
INFO - 2018-10-22 13:57:59 --> CSRF token verified
INFO - 2018-10-22 13:57:59 --> Input Class Initialized
INFO - 2018-10-22 13:57:59 --> Language Class Initialized
INFO - 2018-10-22 13:57:59 --> Loader Class Initialized
INFO - 2018-10-22 13:57:59 --> Helper loaded: url_helper
INFO - 2018-10-22 13:57:59 --> Helper loaded: form_helper
INFO - 2018-10-22 13:57:59 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:57:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:57:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:57:59 --> User Agent Class Initialized
INFO - 2018-10-22 13:57:59 --> Controller Class Initialized
INFO - 2018-10-22 13:57:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:57:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:57:59 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:57:59 --> Pixel_Model class loaded
INFO - 2018-10-22 13:58:00 --> Database Driver Class Initialized
INFO - 2018-10-22 13:58:00 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:58:00 --> Form Validation Class Initialized
INFO - 2018-10-22 13:58:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:58:00 --> Database Driver Class Initialized
INFO - 2018-10-22 13:58:00 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:58:00 --> Config Class Initialized
INFO - 2018-10-22 13:58:00 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:58:00 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:58:00 --> Utf8 Class Initialized
INFO - 2018-10-22 13:58:00 --> URI Class Initialized
INFO - 2018-10-22 13:58:00 --> Router Class Initialized
INFO - 2018-10-22 13:58:00 --> Output Class Initialized
INFO - 2018-10-22 13:58:00 --> Security Class Initialized
DEBUG - 2018-10-22 13:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:58:00 --> CSRF cookie sent
INFO - 2018-10-22 13:58:00 --> Input Class Initialized
INFO - 2018-10-22 13:58:00 --> Language Class Initialized
INFO - 2018-10-22 13:58:00 --> Loader Class Initialized
INFO - 2018-10-22 13:58:00 --> Helper loaded: url_helper
INFO - 2018-10-22 13:58:00 --> Helper loaded: form_helper
INFO - 2018-10-22 13:58:00 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:58:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:58:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:58:00 --> User Agent Class Initialized
INFO - 2018-10-22 13:58:00 --> Controller Class Initialized
INFO - 2018-10-22 13:58:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:58:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:58:00 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:58:00 --> Pixel_Model class loaded
INFO - 2018-10-22 13:58:00 --> Database Driver Class Initialized
INFO - 2018-10-22 13:58:00 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:58:00 --> Database Driver Class Initialized
INFO - 2018-10-22 13:58:00 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:58:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:58:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:58:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner.php
INFO - 2018-10-22 13:58:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:58:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:58:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:58:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:58:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/relation_ship_status.php
INFO - 2018-10-22 13:58:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:58:00 --> Final output sent to browser
DEBUG - 2018-10-22 13:58:00 --> Total execution time: 0.6680
INFO - 2018-10-22 13:58:22 --> Config Class Initialized
INFO - 2018-10-22 13:58:22 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:58:22 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:58:22 --> Utf8 Class Initialized
INFO - 2018-10-22 13:58:22 --> URI Class Initialized
INFO - 2018-10-22 13:58:22 --> Router Class Initialized
INFO - 2018-10-22 13:58:22 --> Output Class Initialized
INFO - 2018-10-22 13:58:22 --> Security Class Initialized
DEBUG - 2018-10-22 13:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:58:22 --> CSRF cookie sent
INFO - 2018-10-22 13:58:22 --> CSRF token verified
INFO - 2018-10-22 13:58:22 --> Input Class Initialized
INFO - 2018-10-22 13:58:22 --> Language Class Initialized
INFO - 2018-10-22 13:58:22 --> Loader Class Initialized
INFO - 2018-10-22 13:58:22 --> Helper loaded: url_helper
INFO - 2018-10-22 13:58:22 --> Helper loaded: form_helper
INFO - 2018-10-22 13:58:22 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:58:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:58:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:58:23 --> User Agent Class Initialized
INFO - 2018-10-22 13:58:23 --> Controller Class Initialized
INFO - 2018-10-22 13:58:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:58:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:58:23 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:58:23 --> Pixel_Model class loaded
INFO - 2018-10-22 13:58:23 --> Database Driver Class Initialized
INFO - 2018-10-22 13:58:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:58:23 --> Form Validation Class Initialized
INFO - 2018-10-22 13:58:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:58:23 --> Database Driver Class Initialized
INFO - 2018-10-22 13:58:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:58:23 --> Config Class Initialized
INFO - 2018-10-22 13:58:23 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:58:23 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:58:23 --> Utf8 Class Initialized
INFO - 2018-10-22 13:58:23 --> URI Class Initialized
INFO - 2018-10-22 13:58:23 --> Router Class Initialized
INFO - 2018-10-22 13:58:23 --> Output Class Initialized
INFO - 2018-10-22 13:58:23 --> Security Class Initialized
DEBUG - 2018-10-22 13:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:58:23 --> CSRF cookie sent
INFO - 2018-10-22 13:58:23 --> Input Class Initialized
INFO - 2018-10-22 13:58:23 --> Language Class Initialized
INFO - 2018-10-22 13:58:23 --> Loader Class Initialized
INFO - 2018-10-22 13:58:23 --> Helper loaded: url_helper
INFO - 2018-10-22 13:58:23 --> Helper loaded: form_helper
INFO - 2018-10-22 13:58:23 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:58:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:58:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:58:23 --> User Agent Class Initialized
INFO - 2018-10-22 13:58:23 --> Controller Class Initialized
INFO - 2018-10-22 13:58:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:58:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:58:23 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:58:23 --> Pixel_Model class loaded
INFO - 2018-10-22 13:58:23 --> Database Driver Class Initialized
INFO - 2018-10-22 13:58:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:58:23 --> Database Driver Class Initialized
INFO - 2018-10-22 13:58:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:58:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:58:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:58:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:58:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:58:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:58:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:58:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/income.php
INFO - 2018-10-22 13:58:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:58:23 --> Final output sent to browser
DEBUG - 2018-10-22 13:58:23 --> Total execution time: 0.6352
INFO - 2018-10-22 13:58:30 --> Config Class Initialized
INFO - 2018-10-22 13:58:30 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:58:30 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:58:30 --> Utf8 Class Initialized
INFO - 2018-10-22 13:58:30 --> URI Class Initialized
INFO - 2018-10-22 13:58:30 --> Router Class Initialized
INFO - 2018-10-22 13:58:30 --> Output Class Initialized
INFO - 2018-10-22 13:58:30 --> Security Class Initialized
DEBUG - 2018-10-22 13:58:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:58:30 --> CSRF cookie sent
INFO - 2018-10-22 13:58:30 --> CSRF token verified
INFO - 2018-10-22 13:58:30 --> Input Class Initialized
INFO - 2018-10-22 13:58:30 --> Language Class Initialized
INFO - 2018-10-22 13:58:30 --> Loader Class Initialized
INFO - 2018-10-22 13:58:30 --> Helper loaded: url_helper
INFO - 2018-10-22 13:58:30 --> Helper loaded: form_helper
INFO - 2018-10-22 13:58:30 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:58:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:58:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:58:31 --> User Agent Class Initialized
INFO - 2018-10-22 13:58:31 --> Controller Class Initialized
INFO - 2018-10-22 13:58:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:58:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:58:31 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:58:31 --> Pixel_Model class loaded
INFO - 2018-10-22 13:58:31 --> Database Driver Class Initialized
INFO - 2018-10-22 13:58:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:58:31 --> Form Validation Class Initialized
INFO - 2018-10-22 13:58:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:58:31 --> Database Driver Class Initialized
INFO - 2018-10-22 13:58:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:58:31 --> Config Class Initialized
INFO - 2018-10-22 13:58:31 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:58:31 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:58:31 --> Utf8 Class Initialized
INFO - 2018-10-22 13:58:31 --> URI Class Initialized
INFO - 2018-10-22 13:58:31 --> Router Class Initialized
INFO - 2018-10-22 13:58:31 --> Output Class Initialized
INFO - 2018-10-22 13:58:31 --> Security Class Initialized
DEBUG - 2018-10-22 13:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:58:31 --> CSRF cookie sent
INFO - 2018-10-22 13:58:31 --> Input Class Initialized
INFO - 2018-10-22 13:58:31 --> Language Class Initialized
INFO - 2018-10-22 13:58:31 --> Loader Class Initialized
INFO - 2018-10-22 13:58:31 --> Helper loaded: url_helper
INFO - 2018-10-22 13:58:31 --> Helper loaded: form_helper
INFO - 2018-10-22 13:58:31 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:58:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:58:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:58:31 --> User Agent Class Initialized
INFO - 2018-10-22 13:58:31 --> Controller Class Initialized
INFO - 2018-10-22 13:58:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:58:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:58:31 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:58:31 --> Pixel_Model class loaded
INFO - 2018-10-22 13:58:31 --> Database Driver Class Initialized
INFO - 2018-10-22 13:58:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:58:31 --> Database Driver Class Initialized
INFO - 2018-10-22 13:58:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:58:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:58:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:58:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:58:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:58:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:58:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:58:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/marriage.php
INFO - 2018-10-22 13:58:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:58:31 --> Final output sent to browser
DEBUG - 2018-10-22 13:58:32 --> Total execution time: 0.6573
INFO - 2018-10-22 13:59:12 --> Config Class Initialized
INFO - 2018-10-22 13:59:12 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:59:12 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:59:12 --> Utf8 Class Initialized
INFO - 2018-10-22 13:59:12 --> URI Class Initialized
INFO - 2018-10-22 13:59:12 --> Router Class Initialized
INFO - 2018-10-22 13:59:12 --> Output Class Initialized
INFO - 2018-10-22 13:59:12 --> Security Class Initialized
DEBUG - 2018-10-22 13:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:59:12 --> CSRF cookie sent
INFO - 2018-10-22 13:59:12 --> Input Class Initialized
INFO - 2018-10-22 13:59:12 --> Language Class Initialized
INFO - 2018-10-22 13:59:12 --> Loader Class Initialized
INFO - 2018-10-22 13:59:12 --> Helper loaded: url_helper
INFO - 2018-10-22 13:59:12 --> Helper loaded: form_helper
INFO - 2018-10-22 13:59:12 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:59:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:59:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:59:12 --> User Agent Class Initialized
INFO - 2018-10-22 13:59:12 --> Controller Class Initialized
INFO - 2018-10-22 13:59:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:59:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:59:12 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:59:12 --> Pixel_Model class loaded
INFO - 2018-10-22 13:59:12 --> Database Driver Class Initialized
INFO - 2018-10-22 13:59:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:59:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:59:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:59:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:59:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:59:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:59:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:59:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-22 13:59:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:59:12 --> Final output sent to browser
DEBUG - 2018-10-22 13:59:12 --> Total execution time: 0.6702
INFO - 2018-10-22 13:59:14 --> Config Class Initialized
INFO - 2018-10-22 13:59:14 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:59:14 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:59:14 --> Utf8 Class Initialized
INFO - 2018-10-22 13:59:14 --> URI Class Initialized
INFO - 2018-10-22 13:59:14 --> Router Class Initialized
INFO - 2018-10-22 13:59:14 --> Output Class Initialized
INFO - 2018-10-22 13:59:14 --> Security Class Initialized
DEBUG - 2018-10-22 13:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:59:14 --> CSRF cookie sent
INFO - 2018-10-22 13:59:14 --> Input Class Initialized
INFO - 2018-10-22 13:59:14 --> Language Class Initialized
INFO - 2018-10-22 13:59:14 --> Loader Class Initialized
INFO - 2018-10-22 13:59:14 --> Helper loaded: url_helper
INFO - 2018-10-22 13:59:14 --> Helper loaded: form_helper
INFO - 2018-10-22 13:59:14 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:59:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:59:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:59:14 --> User Agent Class Initialized
INFO - 2018-10-22 13:59:14 --> Controller Class Initialized
INFO - 2018-10-22 13:59:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:59:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:59:15 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:59:15 --> Pixel_Model class loaded
INFO - 2018-10-22 13:59:15 --> Database Driver Class Initialized
INFO - 2018-10-22 13:59:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:59:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:59:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:59:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:59:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:59:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:59:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:59:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-22 13:59:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:59:15 --> Final output sent to browser
DEBUG - 2018-10-22 13:59:15 --> Total execution time: 0.6301
INFO - 2018-10-22 13:59:17 --> Config Class Initialized
INFO - 2018-10-22 13:59:17 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:59:17 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:59:17 --> Utf8 Class Initialized
INFO - 2018-10-22 13:59:17 --> URI Class Initialized
INFO - 2018-10-22 13:59:17 --> Router Class Initialized
INFO - 2018-10-22 13:59:17 --> Output Class Initialized
INFO - 2018-10-22 13:59:17 --> Security Class Initialized
DEBUG - 2018-10-22 13:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:59:17 --> CSRF cookie sent
INFO - 2018-10-22 13:59:17 --> CSRF token verified
INFO - 2018-10-22 13:59:17 --> Input Class Initialized
INFO - 2018-10-22 13:59:17 --> Language Class Initialized
INFO - 2018-10-22 13:59:17 --> Loader Class Initialized
INFO - 2018-10-22 13:59:17 --> Helper loaded: url_helper
INFO - 2018-10-22 13:59:17 --> Helper loaded: form_helper
INFO - 2018-10-22 13:59:17 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:59:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:59:17 --> User Agent Class Initialized
INFO - 2018-10-22 13:59:17 --> Controller Class Initialized
INFO - 2018-10-22 13:59:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:59:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:59:17 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:59:17 --> Pixel_Model class loaded
INFO - 2018-10-22 13:59:17 --> Database Driver Class Initialized
INFO - 2018-10-22 13:59:17 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:59:17 --> Form Validation Class Initialized
INFO - 2018-10-22 13:59:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:59:17 --> Database Driver Class Initialized
INFO - 2018-10-22 13:59:17 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:59:17 --> Config Class Initialized
INFO - 2018-10-22 13:59:17 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:59:17 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:59:17 --> Utf8 Class Initialized
INFO - 2018-10-22 13:59:17 --> URI Class Initialized
INFO - 2018-10-22 13:59:17 --> Router Class Initialized
INFO - 2018-10-22 13:59:17 --> Output Class Initialized
INFO - 2018-10-22 13:59:17 --> Security Class Initialized
DEBUG - 2018-10-22 13:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:59:18 --> CSRF cookie sent
INFO - 2018-10-22 13:59:18 --> Input Class Initialized
INFO - 2018-10-22 13:59:18 --> Language Class Initialized
INFO - 2018-10-22 13:59:18 --> Loader Class Initialized
INFO - 2018-10-22 13:59:18 --> Helper loaded: url_helper
INFO - 2018-10-22 13:59:18 --> Helper loaded: form_helper
INFO - 2018-10-22 13:59:18 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:59:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:59:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:59:18 --> User Agent Class Initialized
INFO - 2018-10-22 13:59:18 --> Controller Class Initialized
INFO - 2018-10-22 13:59:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:59:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:59:18 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:59:18 --> Pixel_Model class loaded
INFO - 2018-10-22 13:59:18 --> Database Driver Class Initialized
INFO - 2018-10-22 13:59:18 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:59:18 --> Database Driver Class Initialized
INFO - 2018-10-22 13:59:18 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:59:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:59:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:59:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:59:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:59:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:59:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:59:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-22 13:59:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:59:18 --> Final output sent to browser
DEBUG - 2018-10-22 13:59:18 --> Total execution time: 0.6759
INFO - 2018-10-22 13:59:21 --> Config Class Initialized
INFO - 2018-10-22 13:59:21 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:59:21 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:59:21 --> Utf8 Class Initialized
INFO - 2018-10-22 13:59:21 --> URI Class Initialized
INFO - 2018-10-22 13:59:21 --> Router Class Initialized
INFO - 2018-10-22 13:59:21 --> Output Class Initialized
INFO - 2018-10-22 13:59:21 --> Security Class Initialized
DEBUG - 2018-10-22 13:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:59:21 --> CSRF cookie sent
INFO - 2018-10-22 13:59:21 --> CSRF token verified
INFO - 2018-10-22 13:59:21 --> Input Class Initialized
INFO - 2018-10-22 13:59:21 --> Language Class Initialized
INFO - 2018-10-22 13:59:22 --> Loader Class Initialized
INFO - 2018-10-22 13:59:22 --> Helper loaded: url_helper
INFO - 2018-10-22 13:59:22 --> Helper loaded: form_helper
INFO - 2018-10-22 13:59:22 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:59:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:59:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:59:22 --> User Agent Class Initialized
INFO - 2018-10-22 13:59:22 --> Controller Class Initialized
INFO - 2018-10-22 13:59:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:59:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:59:22 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:59:22 --> Pixel_Model class loaded
INFO - 2018-10-22 13:59:22 --> Database Driver Class Initialized
INFO - 2018-10-22 13:59:22 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:59:22 --> Form Validation Class Initialized
INFO - 2018-10-22 13:59:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:59:22 --> Database Driver Class Initialized
INFO - 2018-10-22 13:59:22 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:59:22 --> Config Class Initialized
INFO - 2018-10-22 13:59:22 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:59:22 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:59:22 --> Utf8 Class Initialized
INFO - 2018-10-22 13:59:22 --> URI Class Initialized
INFO - 2018-10-22 13:59:22 --> Router Class Initialized
INFO - 2018-10-22 13:59:22 --> Output Class Initialized
INFO - 2018-10-22 13:59:22 --> Security Class Initialized
DEBUG - 2018-10-22 13:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:59:22 --> CSRF cookie sent
INFO - 2018-10-22 13:59:22 --> Input Class Initialized
INFO - 2018-10-22 13:59:22 --> Language Class Initialized
INFO - 2018-10-22 13:59:22 --> Loader Class Initialized
INFO - 2018-10-22 13:59:22 --> Helper loaded: url_helper
INFO - 2018-10-22 13:59:22 --> Helper loaded: form_helper
INFO - 2018-10-22 13:59:22 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:59:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:59:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:59:22 --> User Agent Class Initialized
INFO - 2018-10-22 13:59:22 --> Controller Class Initialized
INFO - 2018-10-22 13:59:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:59:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:59:22 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:59:22 --> Pixel_Model class loaded
INFO - 2018-10-22 13:59:22 --> Database Driver Class Initialized
INFO - 2018-10-22 13:59:22 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:59:22 --> Database Driver Class Initialized
INFO - 2018-10-22 13:59:22 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:59:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:59:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:59:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:59:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:59:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:59:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:59:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/your_job.php
INFO - 2018-10-22 13:59:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:59:23 --> Final output sent to browser
DEBUG - 2018-10-22 13:59:23 --> Total execution time: 0.6727
INFO - 2018-10-22 13:59:25 --> Config Class Initialized
INFO - 2018-10-22 13:59:25 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:59:25 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:59:25 --> Utf8 Class Initialized
INFO - 2018-10-22 13:59:25 --> URI Class Initialized
INFO - 2018-10-22 13:59:25 --> Router Class Initialized
INFO - 2018-10-22 13:59:25 --> Output Class Initialized
INFO - 2018-10-22 13:59:25 --> Security Class Initialized
DEBUG - 2018-10-22 13:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:59:25 --> CSRF cookie sent
INFO - 2018-10-22 13:59:25 --> CSRF token verified
INFO - 2018-10-22 13:59:25 --> Input Class Initialized
INFO - 2018-10-22 13:59:25 --> Language Class Initialized
INFO - 2018-10-22 13:59:25 --> Loader Class Initialized
INFO - 2018-10-22 13:59:25 --> Helper loaded: url_helper
INFO - 2018-10-22 13:59:25 --> Helper loaded: form_helper
INFO - 2018-10-22 13:59:25 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:59:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:59:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:59:25 --> User Agent Class Initialized
INFO - 2018-10-22 13:59:25 --> Controller Class Initialized
INFO - 2018-10-22 13:59:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:59:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:59:25 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:59:25 --> Pixel_Model class loaded
INFO - 2018-10-22 13:59:25 --> Database Driver Class Initialized
INFO - 2018-10-22 13:59:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:59:25 --> Form Validation Class Initialized
INFO - 2018-10-22 13:59:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:59:25 --> Database Driver Class Initialized
INFO - 2018-10-22 13:59:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:59:26 --> Config Class Initialized
INFO - 2018-10-22 13:59:26 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:59:26 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:59:26 --> Utf8 Class Initialized
INFO - 2018-10-22 13:59:26 --> URI Class Initialized
INFO - 2018-10-22 13:59:26 --> Router Class Initialized
INFO - 2018-10-22 13:59:26 --> Output Class Initialized
INFO - 2018-10-22 13:59:26 --> Security Class Initialized
DEBUG - 2018-10-22 13:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:59:26 --> CSRF cookie sent
INFO - 2018-10-22 13:59:26 --> Input Class Initialized
INFO - 2018-10-22 13:59:26 --> Language Class Initialized
INFO - 2018-10-22 13:59:26 --> Loader Class Initialized
INFO - 2018-10-22 13:59:26 --> Helper loaded: url_helper
INFO - 2018-10-22 13:59:26 --> Helper loaded: form_helper
INFO - 2018-10-22 13:59:26 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:59:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:59:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:59:26 --> User Agent Class Initialized
INFO - 2018-10-22 13:59:26 --> Controller Class Initialized
INFO - 2018-10-22 13:59:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:59:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:59:26 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:59:26 --> Pixel_Model class loaded
INFO - 2018-10-22 13:59:26 --> Database Driver Class Initialized
INFO - 2018-10-22 13:59:26 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:59:26 --> Database Driver Class Initialized
INFO - 2018-10-22 13:59:26 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:59:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:59:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:59:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner.php
INFO - 2018-10-22 13:59:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:59:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:59:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:59:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:59:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/relation_ship_status.php
INFO - 2018-10-22 13:59:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:59:26 --> Final output sent to browser
DEBUG - 2018-10-22 13:59:26 --> Total execution time: 0.6746
INFO - 2018-10-22 13:59:30 --> Config Class Initialized
INFO - 2018-10-22 13:59:30 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:59:30 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:59:30 --> Utf8 Class Initialized
INFO - 2018-10-22 13:59:30 --> URI Class Initialized
INFO - 2018-10-22 13:59:30 --> Router Class Initialized
INFO - 2018-10-22 13:59:30 --> Output Class Initialized
INFO - 2018-10-22 13:59:30 --> Security Class Initialized
DEBUG - 2018-10-22 13:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:59:30 --> CSRF cookie sent
INFO - 2018-10-22 13:59:30 --> CSRF token verified
INFO - 2018-10-22 13:59:30 --> Input Class Initialized
INFO - 2018-10-22 13:59:30 --> Language Class Initialized
INFO - 2018-10-22 13:59:30 --> Loader Class Initialized
INFO - 2018-10-22 13:59:30 --> Helper loaded: url_helper
INFO - 2018-10-22 13:59:30 --> Helper loaded: form_helper
INFO - 2018-10-22 13:59:30 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:59:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:59:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:59:30 --> User Agent Class Initialized
INFO - 2018-10-22 13:59:30 --> Controller Class Initialized
INFO - 2018-10-22 13:59:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:59:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:59:30 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:59:30 --> Pixel_Model class loaded
INFO - 2018-10-22 13:59:30 --> Database Driver Class Initialized
INFO - 2018-10-22 13:59:30 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:59:30 --> Form Validation Class Initialized
INFO - 2018-10-22 13:59:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:59:30 --> Database Driver Class Initialized
INFO - 2018-10-22 13:59:30 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:59:31 --> Config Class Initialized
INFO - 2018-10-22 13:59:31 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:59:31 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:59:31 --> Utf8 Class Initialized
INFO - 2018-10-22 13:59:31 --> URI Class Initialized
INFO - 2018-10-22 13:59:31 --> Router Class Initialized
INFO - 2018-10-22 13:59:31 --> Output Class Initialized
INFO - 2018-10-22 13:59:31 --> Security Class Initialized
DEBUG - 2018-10-22 13:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:59:31 --> CSRF cookie sent
INFO - 2018-10-22 13:59:31 --> Input Class Initialized
INFO - 2018-10-22 13:59:31 --> Language Class Initialized
INFO - 2018-10-22 13:59:31 --> Loader Class Initialized
INFO - 2018-10-22 13:59:31 --> Helper loaded: url_helper
INFO - 2018-10-22 13:59:31 --> Helper loaded: form_helper
INFO - 2018-10-22 13:59:31 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:59:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:59:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:59:31 --> User Agent Class Initialized
INFO - 2018-10-22 13:59:31 --> Controller Class Initialized
INFO - 2018-10-22 13:59:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:59:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:59:31 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:59:31 --> Pixel_Model class loaded
INFO - 2018-10-22 13:59:31 --> Database Driver Class Initialized
INFO - 2018-10-22 13:59:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:59:31 --> Database Driver Class Initialized
INFO - 2018-10-22 13:59:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:59:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:59:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:59:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:59:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:59:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:59:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:59:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/income.php
INFO - 2018-10-22 13:59:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:59:31 --> Final output sent to browser
DEBUG - 2018-10-22 13:59:31 --> Total execution time: 0.6702
INFO - 2018-10-22 13:59:39 --> Config Class Initialized
INFO - 2018-10-22 13:59:39 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:59:39 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:59:39 --> Utf8 Class Initialized
INFO - 2018-10-22 13:59:39 --> URI Class Initialized
INFO - 2018-10-22 13:59:39 --> Router Class Initialized
INFO - 2018-10-22 13:59:39 --> Output Class Initialized
INFO - 2018-10-22 13:59:39 --> Security Class Initialized
DEBUG - 2018-10-22 13:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:59:39 --> CSRF cookie sent
INFO - 2018-10-22 13:59:39 --> CSRF token verified
INFO - 2018-10-22 13:59:39 --> Input Class Initialized
INFO - 2018-10-22 13:59:39 --> Language Class Initialized
INFO - 2018-10-22 13:59:39 --> Loader Class Initialized
INFO - 2018-10-22 13:59:39 --> Helper loaded: url_helper
INFO - 2018-10-22 13:59:39 --> Helper loaded: form_helper
INFO - 2018-10-22 13:59:39 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:59:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:59:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:59:39 --> User Agent Class Initialized
INFO - 2018-10-22 13:59:39 --> Controller Class Initialized
INFO - 2018-10-22 13:59:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:59:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:59:40 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:59:40 --> Pixel_Model class loaded
INFO - 2018-10-22 13:59:40 --> Database Driver Class Initialized
INFO - 2018-10-22 13:59:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:59:40 --> Form Validation Class Initialized
INFO - 2018-10-22 13:59:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:59:40 --> Database Driver Class Initialized
INFO - 2018-10-22 13:59:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:59:40 --> Config Class Initialized
INFO - 2018-10-22 13:59:40 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:59:40 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:59:40 --> Utf8 Class Initialized
INFO - 2018-10-22 13:59:40 --> URI Class Initialized
INFO - 2018-10-22 13:59:40 --> Router Class Initialized
INFO - 2018-10-22 13:59:40 --> Output Class Initialized
INFO - 2018-10-22 13:59:40 --> Security Class Initialized
DEBUG - 2018-10-22 13:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:59:40 --> CSRF cookie sent
INFO - 2018-10-22 13:59:40 --> Input Class Initialized
INFO - 2018-10-22 13:59:40 --> Language Class Initialized
INFO - 2018-10-22 13:59:40 --> Loader Class Initialized
INFO - 2018-10-22 13:59:40 --> Helper loaded: url_helper
INFO - 2018-10-22 13:59:40 --> Helper loaded: form_helper
INFO - 2018-10-22 13:59:40 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:59:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:59:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:59:40 --> User Agent Class Initialized
INFO - 2018-10-22 13:59:40 --> Controller Class Initialized
INFO - 2018-10-22 13:59:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:59:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:59:40 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:59:40 --> Pixel_Model class loaded
INFO - 2018-10-22 13:59:40 --> Database Driver Class Initialized
INFO - 2018-10-22 13:59:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:59:40 --> Database Driver Class Initialized
INFO - 2018-10-22 13:59:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:59:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:59:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:59:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:59:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:59:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:59:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:59:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/pension.php
INFO - 2018-10-22 13:59:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:59:40 --> Final output sent to browser
DEBUG - 2018-10-22 13:59:40 --> Total execution time: 0.6739
INFO - 2018-10-22 13:59:46 --> Config Class Initialized
INFO - 2018-10-22 13:59:46 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:59:46 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:59:46 --> Utf8 Class Initialized
INFO - 2018-10-22 13:59:46 --> URI Class Initialized
INFO - 2018-10-22 13:59:46 --> Router Class Initialized
INFO - 2018-10-22 13:59:46 --> Output Class Initialized
INFO - 2018-10-22 13:59:46 --> Security Class Initialized
DEBUG - 2018-10-22 13:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:59:46 --> CSRF cookie sent
INFO - 2018-10-22 13:59:46 --> CSRF token verified
INFO - 2018-10-22 13:59:46 --> Input Class Initialized
INFO - 2018-10-22 13:59:46 --> Language Class Initialized
INFO - 2018-10-22 13:59:46 --> Loader Class Initialized
INFO - 2018-10-22 13:59:46 --> Helper loaded: url_helper
INFO - 2018-10-22 13:59:46 --> Helper loaded: form_helper
INFO - 2018-10-22 13:59:46 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:59:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:59:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:59:46 --> User Agent Class Initialized
INFO - 2018-10-22 13:59:46 --> Controller Class Initialized
INFO - 2018-10-22 13:59:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:59:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:59:46 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:59:46 --> Pixel_Model class loaded
INFO - 2018-10-22 13:59:46 --> Database Driver Class Initialized
INFO - 2018-10-22 13:59:46 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:59:46 --> Form Validation Class Initialized
INFO - 2018-10-22 13:59:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 13:59:47 --> Database Driver Class Initialized
INFO - 2018-10-22 13:59:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:59:47 --> Config Class Initialized
INFO - 2018-10-22 13:59:47 --> Hooks Class Initialized
DEBUG - 2018-10-22 13:59:47 --> UTF-8 Support Enabled
INFO - 2018-10-22 13:59:47 --> Utf8 Class Initialized
INFO - 2018-10-22 13:59:47 --> URI Class Initialized
INFO - 2018-10-22 13:59:47 --> Router Class Initialized
INFO - 2018-10-22 13:59:47 --> Output Class Initialized
INFO - 2018-10-22 13:59:47 --> Security Class Initialized
DEBUG - 2018-10-22 13:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 13:59:47 --> CSRF cookie sent
INFO - 2018-10-22 13:59:47 --> Input Class Initialized
INFO - 2018-10-22 13:59:47 --> Language Class Initialized
INFO - 2018-10-22 13:59:47 --> Loader Class Initialized
INFO - 2018-10-22 13:59:47 --> Helper loaded: url_helper
INFO - 2018-10-22 13:59:47 --> Helper loaded: form_helper
INFO - 2018-10-22 13:59:47 --> Helper loaded: language_helper
DEBUG - 2018-10-22 13:59:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 13:59:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 13:59:47 --> User Agent Class Initialized
INFO - 2018-10-22 13:59:47 --> Controller Class Initialized
INFO - 2018-10-22 13:59:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 13:59:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 13:59:47 --> Helper loaded: custom_helper
INFO - 2018-10-22 13:59:47 --> Pixel_Model class loaded
INFO - 2018-10-22 13:59:47 --> Database Driver Class Initialized
INFO - 2018-10-22 13:59:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:59:47 --> Database Driver Class Initialized
INFO - 2018-10-22 13:59:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 13:59:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 13:59:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 13:59:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 13:59:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 13:59:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 13:59:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 13:59:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/home_title.php
INFO - 2018-10-22 13:59:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 13:59:47 --> Final output sent to browser
DEBUG - 2018-10-22 13:59:47 --> Total execution time: 0.6840
INFO - 2018-10-22 14:00:25 --> Config Class Initialized
INFO - 2018-10-22 14:00:25 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:00:25 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:00:25 --> Utf8 Class Initialized
INFO - 2018-10-22 14:00:25 --> URI Class Initialized
INFO - 2018-10-22 14:00:25 --> Router Class Initialized
INFO - 2018-10-22 14:00:25 --> Output Class Initialized
INFO - 2018-10-22 14:00:25 --> Security Class Initialized
DEBUG - 2018-10-22 14:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:00:26 --> CSRF cookie sent
INFO - 2018-10-22 14:00:26 --> Input Class Initialized
INFO - 2018-10-22 14:00:26 --> Language Class Initialized
INFO - 2018-10-22 14:00:26 --> Loader Class Initialized
INFO - 2018-10-22 14:00:26 --> Helper loaded: url_helper
INFO - 2018-10-22 14:00:26 --> Helper loaded: form_helper
INFO - 2018-10-22 14:00:26 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:00:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:00:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:00:26 --> User Agent Class Initialized
INFO - 2018-10-22 14:00:26 --> Controller Class Initialized
INFO - 2018-10-22 14:00:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:00:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:00:26 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:00:26 --> Pixel_Model class loaded
INFO - 2018-10-22 14:00:26 --> Database Driver Class Initialized
INFO - 2018-10-22 14:00:26 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:00:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 14:00:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 14:00:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 14:00:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 14:00:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 14:00:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 14:00:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-22 14:00:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 14:00:26 --> Final output sent to browser
DEBUG - 2018-10-22 14:00:26 --> Total execution time: 0.6551
INFO - 2018-10-22 14:00:34 --> Config Class Initialized
INFO - 2018-10-22 14:00:34 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:00:34 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:00:34 --> Utf8 Class Initialized
INFO - 2018-10-22 14:00:34 --> URI Class Initialized
INFO - 2018-10-22 14:00:34 --> Router Class Initialized
INFO - 2018-10-22 14:00:34 --> Output Class Initialized
INFO - 2018-10-22 14:00:34 --> Security Class Initialized
DEBUG - 2018-10-22 14:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:00:34 --> CSRF cookie sent
INFO - 2018-10-22 14:00:34 --> CSRF token verified
INFO - 2018-10-22 14:00:34 --> Input Class Initialized
INFO - 2018-10-22 14:00:34 --> Language Class Initialized
INFO - 2018-10-22 14:00:34 --> Loader Class Initialized
INFO - 2018-10-22 14:00:34 --> Helper loaded: url_helper
INFO - 2018-10-22 14:00:34 --> Helper loaded: form_helper
INFO - 2018-10-22 14:00:34 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:00:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:00:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:00:34 --> User Agent Class Initialized
INFO - 2018-10-22 14:00:34 --> Controller Class Initialized
INFO - 2018-10-22 14:00:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:00:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:00:34 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:00:34 --> Pixel_Model class loaded
INFO - 2018-10-22 14:00:34 --> Database Driver Class Initialized
INFO - 2018-10-22 14:00:34 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:00:34 --> Form Validation Class Initialized
INFO - 2018-10-22 14:00:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 14:00:34 --> Database Driver Class Initialized
INFO - 2018-10-22 14:00:34 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:00:35 --> Config Class Initialized
INFO - 2018-10-22 14:00:35 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:00:35 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:00:35 --> Utf8 Class Initialized
INFO - 2018-10-22 14:00:35 --> URI Class Initialized
INFO - 2018-10-22 14:00:35 --> Router Class Initialized
INFO - 2018-10-22 14:00:35 --> Output Class Initialized
INFO - 2018-10-22 14:00:35 --> Security Class Initialized
DEBUG - 2018-10-22 14:00:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:00:35 --> CSRF cookie sent
INFO - 2018-10-22 14:00:35 --> Input Class Initialized
INFO - 2018-10-22 14:00:35 --> Language Class Initialized
INFO - 2018-10-22 14:00:35 --> Loader Class Initialized
INFO - 2018-10-22 14:00:35 --> Helper loaded: url_helper
INFO - 2018-10-22 14:00:35 --> Helper loaded: form_helper
INFO - 2018-10-22 14:00:35 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:00:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:00:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:00:35 --> User Agent Class Initialized
INFO - 2018-10-22 14:00:35 --> Controller Class Initialized
INFO - 2018-10-22 14:00:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:00:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:00:35 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:00:35 --> Pixel_Model class loaded
INFO - 2018-10-22 14:00:35 --> Database Driver Class Initialized
INFO - 2018-10-22 14:00:35 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:00:35 --> Database Driver Class Initialized
INFO - 2018-10-22 14:00:35 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:00:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 14:00:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 14:00:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 14:00:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 14:00:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 14:00:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 14:00:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-22 14:00:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 14:00:35 --> Final output sent to browser
DEBUG - 2018-10-22 14:00:35 --> Total execution time: 0.6884
INFO - 2018-10-22 14:00:38 --> Config Class Initialized
INFO - 2018-10-22 14:00:38 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:00:38 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:00:38 --> Utf8 Class Initialized
INFO - 2018-10-22 14:00:38 --> URI Class Initialized
INFO - 2018-10-22 14:00:38 --> Router Class Initialized
INFO - 2018-10-22 14:00:38 --> Output Class Initialized
INFO - 2018-10-22 14:00:38 --> Security Class Initialized
DEBUG - 2018-10-22 14:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:00:38 --> CSRF cookie sent
INFO - 2018-10-22 14:00:38 --> CSRF token verified
INFO - 2018-10-22 14:00:38 --> Input Class Initialized
INFO - 2018-10-22 14:00:38 --> Language Class Initialized
INFO - 2018-10-22 14:00:38 --> Loader Class Initialized
INFO - 2018-10-22 14:00:38 --> Helper loaded: url_helper
INFO - 2018-10-22 14:00:38 --> Helper loaded: form_helper
INFO - 2018-10-22 14:00:38 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:00:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:00:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:00:38 --> User Agent Class Initialized
INFO - 2018-10-22 14:00:38 --> Controller Class Initialized
INFO - 2018-10-22 14:00:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:00:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:00:39 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:00:39 --> Pixel_Model class loaded
INFO - 2018-10-22 14:00:39 --> Database Driver Class Initialized
INFO - 2018-10-22 14:00:39 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:00:39 --> Form Validation Class Initialized
INFO - 2018-10-22 14:00:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 14:00:39 --> Database Driver Class Initialized
INFO - 2018-10-22 14:00:39 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:00:39 --> Config Class Initialized
INFO - 2018-10-22 14:00:39 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:00:39 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:00:39 --> Utf8 Class Initialized
INFO - 2018-10-22 14:00:39 --> URI Class Initialized
INFO - 2018-10-22 14:00:39 --> Router Class Initialized
INFO - 2018-10-22 14:00:39 --> Output Class Initialized
INFO - 2018-10-22 14:00:39 --> Security Class Initialized
DEBUG - 2018-10-22 14:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:00:39 --> CSRF cookie sent
INFO - 2018-10-22 14:00:39 --> Input Class Initialized
INFO - 2018-10-22 14:00:39 --> Language Class Initialized
INFO - 2018-10-22 14:00:39 --> Loader Class Initialized
INFO - 2018-10-22 14:00:39 --> Helper loaded: url_helper
INFO - 2018-10-22 14:00:39 --> Helper loaded: form_helper
INFO - 2018-10-22 14:00:39 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:00:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:00:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:00:39 --> User Agent Class Initialized
INFO - 2018-10-22 14:00:39 --> Controller Class Initialized
INFO - 2018-10-22 14:00:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:00:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:00:39 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:00:39 --> Pixel_Model class loaded
INFO - 2018-10-22 14:00:39 --> Database Driver Class Initialized
INFO - 2018-10-22 14:00:39 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:00:39 --> Database Driver Class Initialized
INFO - 2018-10-22 14:00:39 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:00:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 14:00:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 14:00:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 14:00:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 14:00:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 14:00:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 14:00:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/your_job.php
INFO - 2018-10-22 14:00:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 14:00:39 --> Final output sent to browser
DEBUG - 2018-10-22 14:00:39 --> Total execution time: 0.6757
INFO - 2018-10-22 14:00:41 --> Config Class Initialized
INFO - 2018-10-22 14:00:42 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:00:42 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:00:42 --> Utf8 Class Initialized
INFO - 2018-10-22 14:00:42 --> URI Class Initialized
INFO - 2018-10-22 14:00:42 --> Router Class Initialized
INFO - 2018-10-22 14:00:42 --> Output Class Initialized
INFO - 2018-10-22 14:00:42 --> Security Class Initialized
DEBUG - 2018-10-22 14:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:00:42 --> CSRF cookie sent
INFO - 2018-10-22 14:00:42 --> CSRF token verified
INFO - 2018-10-22 14:00:42 --> Input Class Initialized
INFO - 2018-10-22 14:00:42 --> Language Class Initialized
INFO - 2018-10-22 14:00:42 --> Loader Class Initialized
INFO - 2018-10-22 14:00:42 --> Helper loaded: url_helper
INFO - 2018-10-22 14:00:42 --> Helper loaded: form_helper
INFO - 2018-10-22 14:00:42 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:00:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:00:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:00:42 --> User Agent Class Initialized
INFO - 2018-10-22 14:00:42 --> Controller Class Initialized
INFO - 2018-10-22 14:00:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:00:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:00:42 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:00:42 --> Pixel_Model class loaded
INFO - 2018-10-22 14:00:42 --> Database Driver Class Initialized
INFO - 2018-10-22 14:00:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:00:42 --> Form Validation Class Initialized
INFO - 2018-10-22 14:00:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 14:00:42 --> Database Driver Class Initialized
INFO - 2018-10-22 14:00:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:00:42 --> Config Class Initialized
INFO - 2018-10-22 14:00:42 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:00:42 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:00:42 --> Utf8 Class Initialized
INFO - 2018-10-22 14:00:42 --> URI Class Initialized
INFO - 2018-10-22 14:00:42 --> Router Class Initialized
INFO - 2018-10-22 14:00:42 --> Output Class Initialized
INFO - 2018-10-22 14:00:42 --> Security Class Initialized
DEBUG - 2018-10-22 14:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:00:42 --> CSRF cookie sent
INFO - 2018-10-22 14:00:42 --> Input Class Initialized
INFO - 2018-10-22 14:00:42 --> Language Class Initialized
INFO - 2018-10-22 14:00:42 --> Loader Class Initialized
INFO - 2018-10-22 14:00:42 --> Helper loaded: url_helper
INFO - 2018-10-22 14:00:42 --> Helper loaded: form_helper
INFO - 2018-10-22 14:00:42 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:00:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:00:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:00:42 --> User Agent Class Initialized
INFO - 2018-10-22 14:00:42 --> Controller Class Initialized
INFO - 2018-10-22 14:00:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:00:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:00:43 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:00:43 --> Pixel_Model class loaded
INFO - 2018-10-22 14:00:43 --> Database Driver Class Initialized
INFO - 2018-10-22 14:00:43 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:00:43 --> Database Driver Class Initialized
INFO - 2018-10-22 14:00:43 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:00:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 14:00:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 14:00:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner.php
INFO - 2018-10-22 14:00:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 14:00:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 14:00:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 14:00:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 14:00:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/relation_ship_status.php
INFO - 2018-10-22 14:00:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 14:00:43 --> Final output sent to browser
DEBUG - 2018-10-22 14:00:43 --> Total execution time: 0.6947
INFO - 2018-10-22 14:00:46 --> Config Class Initialized
INFO - 2018-10-22 14:00:46 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:00:46 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:00:46 --> Utf8 Class Initialized
INFO - 2018-10-22 14:00:46 --> URI Class Initialized
INFO - 2018-10-22 14:00:46 --> Router Class Initialized
INFO - 2018-10-22 14:00:46 --> Output Class Initialized
INFO - 2018-10-22 14:00:46 --> Security Class Initialized
DEBUG - 2018-10-22 14:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:00:46 --> CSRF cookie sent
INFO - 2018-10-22 14:00:46 --> CSRF token verified
INFO - 2018-10-22 14:00:46 --> Input Class Initialized
INFO - 2018-10-22 14:00:46 --> Language Class Initialized
INFO - 2018-10-22 14:00:46 --> Loader Class Initialized
INFO - 2018-10-22 14:00:46 --> Helper loaded: url_helper
INFO - 2018-10-22 14:00:46 --> Helper loaded: form_helper
INFO - 2018-10-22 14:00:46 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:00:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:00:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:00:46 --> User Agent Class Initialized
INFO - 2018-10-22 14:00:46 --> Controller Class Initialized
INFO - 2018-10-22 14:00:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:00:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:00:47 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:00:47 --> Pixel_Model class loaded
INFO - 2018-10-22 14:00:47 --> Database Driver Class Initialized
INFO - 2018-10-22 14:00:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:00:47 --> Form Validation Class Initialized
INFO - 2018-10-22 14:00:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 14:00:47 --> Database Driver Class Initialized
INFO - 2018-10-22 14:00:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:00:47 --> Config Class Initialized
INFO - 2018-10-22 14:00:47 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:00:47 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:00:47 --> Utf8 Class Initialized
INFO - 2018-10-22 14:00:47 --> URI Class Initialized
INFO - 2018-10-22 14:00:47 --> Router Class Initialized
INFO - 2018-10-22 14:00:47 --> Output Class Initialized
INFO - 2018-10-22 14:00:47 --> Security Class Initialized
DEBUG - 2018-10-22 14:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:00:47 --> CSRF cookie sent
INFO - 2018-10-22 14:00:47 --> Input Class Initialized
INFO - 2018-10-22 14:00:47 --> Language Class Initialized
INFO - 2018-10-22 14:00:47 --> Loader Class Initialized
INFO - 2018-10-22 14:00:47 --> Helper loaded: url_helper
INFO - 2018-10-22 14:00:47 --> Helper loaded: form_helper
INFO - 2018-10-22 14:00:47 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:00:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:00:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:00:47 --> User Agent Class Initialized
INFO - 2018-10-22 14:00:47 --> Controller Class Initialized
INFO - 2018-10-22 14:00:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:00:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:00:47 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:00:47 --> Pixel_Model class loaded
INFO - 2018-10-22 14:00:47 --> Database Driver Class Initialized
INFO - 2018-10-22 14:00:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:00:47 --> Database Driver Class Initialized
INFO - 2018-10-22 14:00:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:00:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 14:00:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 14:00:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 14:00:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 14:00:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 14:00:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 14:00:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/income.php
INFO - 2018-10-22 14:00:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 14:00:47 --> Final output sent to browser
DEBUG - 2018-10-22 14:00:47 --> Total execution time: 0.6732
INFO - 2018-10-22 14:00:54 --> Config Class Initialized
INFO - 2018-10-22 14:00:54 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:00:54 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:00:54 --> Utf8 Class Initialized
INFO - 2018-10-22 14:00:54 --> URI Class Initialized
INFO - 2018-10-22 14:00:54 --> Router Class Initialized
INFO - 2018-10-22 14:00:54 --> Output Class Initialized
INFO - 2018-10-22 14:00:54 --> Security Class Initialized
DEBUG - 2018-10-22 14:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:00:54 --> CSRF cookie sent
INFO - 2018-10-22 14:00:54 --> CSRF token verified
INFO - 2018-10-22 14:00:54 --> Input Class Initialized
INFO - 2018-10-22 14:00:54 --> Language Class Initialized
INFO - 2018-10-22 14:00:54 --> Loader Class Initialized
INFO - 2018-10-22 14:00:54 --> Helper loaded: url_helper
INFO - 2018-10-22 14:00:54 --> Helper loaded: form_helper
INFO - 2018-10-22 14:00:54 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:00:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:00:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:00:54 --> User Agent Class Initialized
INFO - 2018-10-22 14:00:54 --> Controller Class Initialized
INFO - 2018-10-22 14:00:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:00:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:00:54 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:00:54 --> Pixel_Model class loaded
INFO - 2018-10-22 14:00:54 --> Database Driver Class Initialized
INFO - 2018-10-22 14:00:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:00:54 --> Form Validation Class Initialized
INFO - 2018-10-22 14:00:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 14:00:54 --> Database Driver Class Initialized
INFO - 2018-10-22 14:00:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:00:54 --> Config Class Initialized
INFO - 2018-10-22 14:00:54 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:00:54 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:00:54 --> Utf8 Class Initialized
INFO - 2018-10-22 14:00:54 --> URI Class Initialized
INFO - 2018-10-22 14:00:54 --> Router Class Initialized
INFO - 2018-10-22 14:00:54 --> Output Class Initialized
INFO - 2018-10-22 14:00:54 --> Security Class Initialized
DEBUG - 2018-10-22 14:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:00:54 --> CSRF cookie sent
INFO - 2018-10-22 14:00:54 --> Input Class Initialized
INFO - 2018-10-22 14:00:54 --> Language Class Initialized
INFO - 2018-10-22 14:00:54 --> Loader Class Initialized
INFO - 2018-10-22 14:00:54 --> Helper loaded: url_helper
INFO - 2018-10-22 14:00:54 --> Helper loaded: form_helper
INFO - 2018-10-22 14:00:55 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:00:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:00:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:00:55 --> User Agent Class Initialized
INFO - 2018-10-22 14:00:55 --> Controller Class Initialized
INFO - 2018-10-22 14:00:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:00:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:00:55 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:00:55 --> Pixel_Model class loaded
INFO - 2018-10-22 14:00:55 --> Database Driver Class Initialized
INFO - 2018-10-22 14:00:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:00:55 --> Database Driver Class Initialized
INFO - 2018-10-22 14:00:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:00:55 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 14:00:55 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 14:00:55 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 14:00:55 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 14:00:55 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 14:00:55 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 14:00:55 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/cohabitation.php
INFO - 2018-10-22 14:00:55 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 14:00:55 --> Final output sent to browser
DEBUG - 2018-10-22 14:00:55 --> Total execution time: 0.6716
INFO - 2018-10-22 14:01:02 --> Config Class Initialized
INFO - 2018-10-22 14:01:02 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:01:02 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:01:02 --> Utf8 Class Initialized
INFO - 2018-10-22 14:01:02 --> URI Class Initialized
INFO - 2018-10-22 14:01:02 --> Router Class Initialized
INFO - 2018-10-22 14:01:02 --> Output Class Initialized
INFO - 2018-10-22 14:01:02 --> Security Class Initialized
DEBUG - 2018-10-22 14:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:01:02 --> CSRF cookie sent
INFO - 2018-10-22 14:01:02 --> CSRF token verified
INFO - 2018-10-22 14:01:02 --> Input Class Initialized
INFO - 2018-10-22 14:01:02 --> Language Class Initialized
INFO - 2018-10-22 14:01:02 --> Loader Class Initialized
INFO - 2018-10-22 14:01:02 --> Helper loaded: url_helper
INFO - 2018-10-22 14:01:02 --> Helper loaded: form_helper
INFO - 2018-10-22 14:01:02 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:01:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:01:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:01:02 --> User Agent Class Initialized
INFO - 2018-10-22 14:01:02 --> Controller Class Initialized
INFO - 2018-10-22 14:01:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:01:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:01:02 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:01:02 --> Pixel_Model class loaded
INFO - 2018-10-22 14:01:02 --> Database Driver Class Initialized
INFO - 2018-10-22 14:01:02 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:01:02 --> Form Validation Class Initialized
INFO - 2018-10-22 14:01:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 14:01:02 --> Database Driver Class Initialized
INFO - 2018-10-22 14:01:02 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:01:03 --> Config Class Initialized
INFO - 2018-10-22 14:01:03 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:01:03 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:01:03 --> Utf8 Class Initialized
INFO - 2018-10-22 14:01:03 --> URI Class Initialized
INFO - 2018-10-22 14:01:03 --> Router Class Initialized
INFO - 2018-10-22 14:01:03 --> Output Class Initialized
INFO - 2018-10-22 14:01:03 --> Security Class Initialized
DEBUG - 2018-10-22 14:01:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:01:03 --> CSRF cookie sent
INFO - 2018-10-22 14:01:03 --> Input Class Initialized
INFO - 2018-10-22 14:01:03 --> Language Class Initialized
INFO - 2018-10-22 14:01:03 --> Loader Class Initialized
INFO - 2018-10-22 14:01:03 --> Helper loaded: url_helper
INFO - 2018-10-22 14:01:03 --> Helper loaded: form_helper
INFO - 2018-10-22 14:01:03 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:01:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:01:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:01:03 --> User Agent Class Initialized
INFO - 2018-10-22 14:01:03 --> Controller Class Initialized
INFO - 2018-10-22 14:01:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:01:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:01:03 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:01:03 --> Pixel_Model class loaded
INFO - 2018-10-22 14:01:03 --> Database Driver Class Initialized
INFO - 2018-10-22 14:01:03 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:01:03 --> Database Driver Class Initialized
INFO - 2018-10-22 14:01:03 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:01:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 14:01:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 14:01:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 14:01:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 14:01:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 14:01:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 14:01:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/pension.php
INFO - 2018-10-22 14:01:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 14:01:03 --> Final output sent to browser
DEBUG - 2018-10-22 14:01:03 --> Total execution time: 0.6743
INFO - 2018-10-22 14:01:06 --> Config Class Initialized
INFO - 2018-10-22 14:01:07 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:01:07 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:01:07 --> Utf8 Class Initialized
INFO - 2018-10-22 14:01:07 --> URI Class Initialized
INFO - 2018-10-22 14:01:07 --> Router Class Initialized
INFO - 2018-10-22 14:01:07 --> Output Class Initialized
INFO - 2018-10-22 14:01:07 --> Security Class Initialized
DEBUG - 2018-10-22 14:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:01:07 --> CSRF cookie sent
INFO - 2018-10-22 14:01:07 --> CSRF token verified
INFO - 2018-10-22 14:01:07 --> Input Class Initialized
INFO - 2018-10-22 14:01:07 --> Language Class Initialized
INFO - 2018-10-22 14:01:07 --> Loader Class Initialized
INFO - 2018-10-22 14:01:07 --> Helper loaded: url_helper
INFO - 2018-10-22 14:01:07 --> Helper loaded: form_helper
INFO - 2018-10-22 14:01:07 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:01:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:01:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:01:07 --> User Agent Class Initialized
INFO - 2018-10-22 14:01:07 --> Controller Class Initialized
INFO - 2018-10-22 14:01:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:01:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:01:07 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:01:07 --> Pixel_Model class loaded
INFO - 2018-10-22 14:01:07 --> Database Driver Class Initialized
INFO - 2018-10-22 14:01:07 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:01:07 --> Form Validation Class Initialized
INFO - 2018-10-22 14:01:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 14:01:07 --> Database Driver Class Initialized
INFO - 2018-10-22 14:01:07 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:01:07 --> Config Class Initialized
INFO - 2018-10-22 14:01:07 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:01:07 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:01:07 --> Utf8 Class Initialized
INFO - 2018-10-22 14:01:07 --> URI Class Initialized
INFO - 2018-10-22 14:01:07 --> Router Class Initialized
INFO - 2018-10-22 14:01:07 --> Output Class Initialized
INFO - 2018-10-22 14:01:07 --> Security Class Initialized
DEBUG - 2018-10-22 14:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:01:07 --> CSRF cookie sent
INFO - 2018-10-22 14:01:07 --> Input Class Initialized
INFO - 2018-10-22 14:01:07 --> Language Class Initialized
INFO - 2018-10-22 14:01:07 --> Loader Class Initialized
INFO - 2018-10-22 14:01:07 --> Helper loaded: url_helper
INFO - 2018-10-22 14:01:07 --> Helper loaded: form_helper
INFO - 2018-10-22 14:01:07 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:01:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:01:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:01:08 --> User Agent Class Initialized
INFO - 2018-10-22 14:01:08 --> Controller Class Initialized
INFO - 2018-10-22 14:01:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:01:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:01:08 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:01:08 --> Pixel_Model class loaded
INFO - 2018-10-22 14:01:08 --> Database Driver Class Initialized
INFO - 2018-10-22 14:01:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:01:08 --> Database Driver Class Initialized
INFO - 2018-10-22 14:01:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:01:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 14:01:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 14:01:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 14:01:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 14:01:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 14:01:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 14:01:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/inheritance.php
INFO - 2018-10-22 14:01:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 14:01:08 --> Final output sent to browser
DEBUG - 2018-10-22 14:01:08 --> Total execution time: 0.6888
INFO - 2018-10-22 14:01:10 --> Config Class Initialized
INFO - 2018-10-22 14:01:10 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:01:10 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:01:10 --> Utf8 Class Initialized
INFO - 2018-10-22 14:01:10 --> URI Class Initialized
INFO - 2018-10-22 14:01:10 --> Router Class Initialized
INFO - 2018-10-22 14:01:10 --> Output Class Initialized
INFO - 2018-10-22 14:01:10 --> Security Class Initialized
DEBUG - 2018-10-22 14:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:01:10 --> CSRF cookie sent
INFO - 2018-10-22 14:01:10 --> Input Class Initialized
INFO - 2018-10-22 14:01:10 --> Language Class Initialized
INFO - 2018-10-22 14:01:10 --> Loader Class Initialized
INFO - 2018-10-22 14:01:10 --> Helper loaded: url_helper
INFO - 2018-10-22 14:01:10 --> Helper loaded: form_helper
INFO - 2018-10-22 14:01:10 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:01:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:01:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:01:10 --> User Agent Class Initialized
INFO - 2018-10-22 14:01:10 --> Controller Class Initialized
INFO - 2018-10-22 14:01:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:01:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:01:10 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:01:10 --> Pixel_Model class loaded
INFO - 2018-10-22 14:01:10 --> Database Driver Class Initialized
INFO - 2018-10-22 14:01:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:01:10 --> Database Driver Class Initialized
INFO - 2018-10-22 14:01:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:01:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 14:01:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 14:01:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 14:01:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 14:01:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 14:01:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 14:01:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/pension.php
INFO - 2018-10-22 14:01:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 14:01:11 --> Final output sent to browser
DEBUG - 2018-10-22 14:01:11 --> Total execution time: 0.7076
INFO - 2018-10-22 14:01:11 --> Config Class Initialized
INFO - 2018-10-22 14:01:11 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:01:11 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:01:11 --> Utf8 Class Initialized
INFO - 2018-10-22 14:01:11 --> URI Class Initialized
INFO - 2018-10-22 14:01:11 --> Router Class Initialized
INFO - 2018-10-22 14:01:11 --> Output Class Initialized
INFO - 2018-10-22 14:01:11 --> Security Class Initialized
DEBUG - 2018-10-22 14:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:01:11 --> CSRF cookie sent
INFO - 2018-10-22 14:01:11 --> Input Class Initialized
INFO - 2018-10-22 14:01:11 --> Language Class Initialized
INFO - 2018-10-22 14:01:11 --> Loader Class Initialized
INFO - 2018-10-22 14:01:11 --> Helper loaded: url_helper
INFO - 2018-10-22 14:01:11 --> Helper loaded: form_helper
INFO - 2018-10-22 14:01:11 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:01:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:01:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:01:11 --> User Agent Class Initialized
INFO - 2018-10-22 14:01:11 --> Controller Class Initialized
INFO - 2018-10-22 14:01:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:01:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:01:11 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:01:11 --> Pixel_Model class loaded
INFO - 2018-10-22 14:01:11 --> Database Driver Class Initialized
INFO - 2018-10-22 14:01:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:01:12 --> Database Driver Class Initialized
INFO - 2018-10-22 14:01:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:01:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 14:01:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 14:01:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 14:01:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 14:01:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 14:01:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 14:01:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/cohabitation.php
INFO - 2018-10-22 14:01:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 14:01:12 --> Final output sent to browser
DEBUG - 2018-10-22 14:01:12 --> Total execution time: 0.7303
INFO - 2018-10-22 14:01:13 --> Config Class Initialized
INFO - 2018-10-22 14:01:13 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:01:13 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:01:13 --> Utf8 Class Initialized
INFO - 2018-10-22 14:01:13 --> URI Class Initialized
INFO - 2018-10-22 14:01:13 --> Router Class Initialized
INFO - 2018-10-22 14:01:13 --> Output Class Initialized
INFO - 2018-10-22 14:01:13 --> Security Class Initialized
DEBUG - 2018-10-22 14:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:01:13 --> CSRF cookie sent
INFO - 2018-10-22 14:01:13 --> Input Class Initialized
INFO - 2018-10-22 14:01:13 --> Language Class Initialized
INFO - 2018-10-22 14:01:13 --> Loader Class Initialized
INFO - 2018-10-22 14:01:13 --> Helper loaded: url_helper
INFO - 2018-10-22 14:01:13 --> Helper loaded: form_helper
INFO - 2018-10-22 14:01:13 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:01:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:01:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:01:13 --> User Agent Class Initialized
INFO - 2018-10-22 14:01:13 --> Controller Class Initialized
INFO - 2018-10-22 14:01:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:01:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:01:13 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:01:13 --> Pixel_Model class loaded
INFO - 2018-10-22 14:01:13 --> Database Driver Class Initialized
INFO - 2018-10-22 14:01:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:01:13 --> Database Driver Class Initialized
INFO - 2018-10-22 14:01:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:01:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 14:01:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 14:01:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 14:01:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 14:01:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 14:01:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 14:01:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/income.php
INFO - 2018-10-22 14:01:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 14:01:14 --> Final output sent to browser
DEBUG - 2018-10-22 14:01:14 --> Total execution time: 0.7053
INFO - 2018-10-22 14:01:20 --> Config Class Initialized
INFO - 2018-10-22 14:01:20 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:01:20 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:01:20 --> Utf8 Class Initialized
INFO - 2018-10-22 14:01:20 --> URI Class Initialized
INFO - 2018-10-22 14:01:20 --> Router Class Initialized
INFO - 2018-10-22 14:01:20 --> Output Class Initialized
INFO - 2018-10-22 14:01:20 --> Security Class Initialized
DEBUG - 2018-10-22 14:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:01:20 --> CSRF cookie sent
INFO - 2018-10-22 14:01:20 --> CSRF token verified
INFO - 2018-10-22 14:01:20 --> Input Class Initialized
INFO - 2018-10-22 14:01:20 --> Language Class Initialized
INFO - 2018-10-22 14:01:20 --> Loader Class Initialized
INFO - 2018-10-22 14:01:20 --> Helper loaded: url_helper
INFO - 2018-10-22 14:01:20 --> Helper loaded: form_helper
INFO - 2018-10-22 14:01:20 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:01:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:01:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:01:20 --> User Agent Class Initialized
INFO - 2018-10-22 14:01:20 --> Controller Class Initialized
INFO - 2018-10-22 14:01:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:01:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:01:20 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:01:20 --> Pixel_Model class loaded
INFO - 2018-10-22 14:01:20 --> Database Driver Class Initialized
INFO - 2018-10-22 14:01:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:01:20 --> Form Validation Class Initialized
INFO - 2018-10-22 14:01:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 14:01:20 --> Database Driver Class Initialized
INFO - 2018-10-22 14:01:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:01:20 --> Config Class Initialized
INFO - 2018-10-22 14:01:20 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:01:20 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:01:20 --> Utf8 Class Initialized
INFO - 2018-10-22 14:01:20 --> URI Class Initialized
INFO - 2018-10-22 14:01:20 --> Router Class Initialized
INFO - 2018-10-22 14:01:21 --> Output Class Initialized
INFO - 2018-10-22 14:01:21 --> Security Class Initialized
DEBUG - 2018-10-22 14:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:01:21 --> CSRF cookie sent
INFO - 2018-10-22 14:01:21 --> Input Class Initialized
INFO - 2018-10-22 14:01:21 --> Language Class Initialized
INFO - 2018-10-22 14:01:21 --> Loader Class Initialized
INFO - 2018-10-22 14:01:21 --> Helper loaded: url_helper
INFO - 2018-10-22 14:01:21 --> Helper loaded: form_helper
INFO - 2018-10-22 14:01:21 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:01:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:01:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:01:21 --> User Agent Class Initialized
INFO - 2018-10-22 14:01:21 --> Controller Class Initialized
INFO - 2018-10-22 14:01:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:01:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:01:21 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:01:21 --> Pixel_Model class loaded
INFO - 2018-10-22 14:01:21 --> Database Driver Class Initialized
INFO - 2018-10-22 14:01:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:01:21 --> Database Driver Class Initialized
INFO - 2018-10-22 14:01:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:01:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 14:01:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 14:01:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 14:01:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 14:01:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 14:01:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 14:01:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/cohabitation.php
INFO - 2018-10-22 14:01:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 14:01:21 --> Final output sent to browser
DEBUG - 2018-10-22 14:01:21 --> Total execution time: 0.6980
INFO - 2018-10-22 14:01:27 --> Config Class Initialized
INFO - 2018-10-22 14:01:27 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:01:27 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:01:27 --> Utf8 Class Initialized
INFO - 2018-10-22 14:01:27 --> URI Class Initialized
INFO - 2018-10-22 14:01:27 --> Router Class Initialized
INFO - 2018-10-22 14:01:27 --> Output Class Initialized
INFO - 2018-10-22 14:01:27 --> Security Class Initialized
DEBUG - 2018-10-22 14:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:01:27 --> CSRF cookie sent
INFO - 2018-10-22 14:01:27 --> CSRF token verified
INFO - 2018-10-22 14:01:27 --> Input Class Initialized
INFO - 2018-10-22 14:01:27 --> Language Class Initialized
INFO - 2018-10-22 14:01:27 --> Loader Class Initialized
INFO - 2018-10-22 14:01:27 --> Helper loaded: url_helper
INFO - 2018-10-22 14:01:27 --> Helper loaded: form_helper
INFO - 2018-10-22 14:01:27 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:01:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:01:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:01:27 --> User Agent Class Initialized
INFO - 2018-10-22 14:01:27 --> Controller Class Initialized
INFO - 2018-10-22 14:01:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:01:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:01:27 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:01:27 --> Pixel_Model class loaded
INFO - 2018-10-22 14:01:27 --> Database Driver Class Initialized
INFO - 2018-10-22 14:01:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:01:27 --> Form Validation Class Initialized
INFO - 2018-10-22 14:01:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 14:01:27 --> Database Driver Class Initialized
INFO - 2018-10-22 14:01:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:01:27 --> Config Class Initialized
INFO - 2018-10-22 14:01:27 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:01:27 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:01:27 --> Utf8 Class Initialized
INFO - 2018-10-22 14:01:27 --> URI Class Initialized
INFO - 2018-10-22 14:01:27 --> Router Class Initialized
INFO - 2018-10-22 14:01:27 --> Output Class Initialized
INFO - 2018-10-22 14:01:27 --> Security Class Initialized
DEBUG - 2018-10-22 14:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:01:28 --> CSRF cookie sent
INFO - 2018-10-22 14:01:28 --> Input Class Initialized
INFO - 2018-10-22 14:01:28 --> Language Class Initialized
INFO - 2018-10-22 14:01:28 --> Loader Class Initialized
INFO - 2018-10-22 14:01:28 --> Helper loaded: url_helper
INFO - 2018-10-22 14:01:28 --> Helper loaded: form_helper
INFO - 2018-10-22 14:01:28 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:01:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:01:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:01:28 --> User Agent Class Initialized
INFO - 2018-10-22 14:01:28 --> Controller Class Initialized
INFO - 2018-10-22 14:01:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:01:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:01:28 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:01:28 --> Pixel_Model class loaded
INFO - 2018-10-22 14:01:28 --> Database Driver Class Initialized
INFO - 2018-10-22 14:01:28 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:01:28 --> Database Driver Class Initialized
INFO - 2018-10-22 14:01:28 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:01:28 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 14:01:28 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 14:01:28 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 14:01:28 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 14:01:28 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 14:01:28 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 14:01:28 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/pension.php
INFO - 2018-10-22 14:01:28 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 14:01:28 --> Final output sent to browser
DEBUG - 2018-10-22 14:01:28 --> Total execution time: 0.6887
INFO - 2018-10-22 14:01:32 --> Config Class Initialized
INFO - 2018-10-22 14:01:32 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:01:32 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:01:32 --> Utf8 Class Initialized
INFO - 2018-10-22 14:01:32 --> URI Class Initialized
INFO - 2018-10-22 14:01:32 --> Router Class Initialized
INFO - 2018-10-22 14:01:32 --> Output Class Initialized
INFO - 2018-10-22 14:01:32 --> Security Class Initialized
DEBUG - 2018-10-22 14:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:01:32 --> CSRF cookie sent
INFO - 2018-10-22 14:01:32 --> CSRF token verified
INFO - 2018-10-22 14:01:32 --> Input Class Initialized
INFO - 2018-10-22 14:01:32 --> Language Class Initialized
INFO - 2018-10-22 14:01:32 --> Loader Class Initialized
INFO - 2018-10-22 14:01:32 --> Helper loaded: url_helper
INFO - 2018-10-22 14:01:32 --> Helper loaded: form_helper
INFO - 2018-10-22 14:01:32 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:01:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:01:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:01:32 --> User Agent Class Initialized
INFO - 2018-10-22 14:01:32 --> Controller Class Initialized
INFO - 2018-10-22 14:01:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:01:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:01:32 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:01:32 --> Pixel_Model class loaded
INFO - 2018-10-22 14:01:32 --> Database Driver Class Initialized
INFO - 2018-10-22 14:01:32 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:01:32 --> Form Validation Class Initialized
INFO - 2018-10-22 14:01:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 14:01:32 --> Database Driver Class Initialized
INFO - 2018-10-22 14:01:32 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:01:32 --> Config Class Initialized
INFO - 2018-10-22 14:01:32 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:01:32 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:01:32 --> Utf8 Class Initialized
INFO - 2018-10-22 14:01:32 --> URI Class Initialized
INFO - 2018-10-22 14:01:32 --> Router Class Initialized
INFO - 2018-10-22 14:01:32 --> Output Class Initialized
INFO - 2018-10-22 14:01:32 --> Security Class Initialized
DEBUG - 2018-10-22 14:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:01:32 --> CSRF cookie sent
INFO - 2018-10-22 14:01:32 --> Input Class Initialized
INFO - 2018-10-22 14:01:32 --> Language Class Initialized
INFO - 2018-10-22 14:01:32 --> Loader Class Initialized
INFO - 2018-10-22 14:01:32 --> Helper loaded: url_helper
INFO - 2018-10-22 14:01:33 --> Helper loaded: form_helper
INFO - 2018-10-22 14:01:33 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:01:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:01:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:01:33 --> User Agent Class Initialized
INFO - 2018-10-22 14:01:33 --> Controller Class Initialized
INFO - 2018-10-22 14:01:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:01:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:01:33 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:01:33 --> Pixel_Model class loaded
INFO - 2018-10-22 14:01:33 --> Database Driver Class Initialized
INFO - 2018-10-22 14:01:33 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:01:33 --> Database Driver Class Initialized
INFO - 2018-10-22 14:01:33 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:01:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 14:01:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 14:01:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 14:01:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 14:01:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 14:01:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 14:01:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/inheritance.php
INFO - 2018-10-22 14:01:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 14:01:33 --> Final output sent to browser
DEBUG - 2018-10-22 14:01:33 --> Total execution time: 0.7331
INFO - 2018-10-22 14:01:37 --> Config Class Initialized
INFO - 2018-10-22 14:01:37 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:01:37 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:01:37 --> Utf8 Class Initialized
INFO - 2018-10-22 14:01:37 --> URI Class Initialized
INFO - 2018-10-22 14:01:37 --> Router Class Initialized
INFO - 2018-10-22 14:01:37 --> Output Class Initialized
INFO - 2018-10-22 14:01:37 --> Security Class Initialized
DEBUG - 2018-10-22 14:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:01:37 --> CSRF cookie sent
INFO - 2018-10-22 14:01:37 --> CSRF token verified
INFO - 2018-10-22 14:01:37 --> Input Class Initialized
INFO - 2018-10-22 14:01:37 --> Language Class Initialized
INFO - 2018-10-22 14:01:37 --> Loader Class Initialized
INFO - 2018-10-22 14:01:37 --> Helper loaded: url_helper
INFO - 2018-10-22 14:01:37 --> Helper loaded: form_helper
INFO - 2018-10-22 14:01:37 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:01:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:01:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:01:37 --> User Agent Class Initialized
INFO - 2018-10-22 14:01:37 --> Controller Class Initialized
INFO - 2018-10-22 14:01:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:01:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:01:37 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:01:37 --> Pixel_Model class loaded
INFO - 2018-10-22 14:01:38 --> Database Driver Class Initialized
INFO - 2018-10-22 14:01:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:01:38 --> Form Validation Class Initialized
INFO - 2018-10-22 14:01:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 14:01:38 --> Database Driver Class Initialized
INFO - 2018-10-22 14:01:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:01:38 --> Config Class Initialized
INFO - 2018-10-22 14:01:38 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:01:38 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:01:38 --> Utf8 Class Initialized
INFO - 2018-10-22 14:01:38 --> URI Class Initialized
INFO - 2018-10-22 14:01:38 --> Router Class Initialized
INFO - 2018-10-22 14:01:38 --> Output Class Initialized
INFO - 2018-10-22 14:01:38 --> Security Class Initialized
DEBUG - 2018-10-22 14:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:01:38 --> CSRF cookie sent
INFO - 2018-10-22 14:01:38 --> Input Class Initialized
INFO - 2018-10-22 14:01:38 --> Language Class Initialized
INFO - 2018-10-22 14:01:38 --> Loader Class Initialized
INFO - 2018-10-22 14:01:38 --> Helper loaded: url_helper
INFO - 2018-10-22 14:01:38 --> Helper loaded: form_helper
INFO - 2018-10-22 14:01:38 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:01:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:01:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:01:38 --> User Agent Class Initialized
INFO - 2018-10-22 14:01:38 --> Controller Class Initialized
INFO - 2018-10-22 14:01:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:01:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:01:38 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:01:38 --> Pixel_Model class loaded
INFO - 2018-10-22 14:01:38 --> Database Driver Class Initialized
INFO - 2018-10-22 14:01:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:01:38 --> Database Driver Class Initialized
INFO - 2018-10-22 14:01:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:01:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 14:01:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 14:01:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 14:01:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 14:01:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 14:01:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 14:01:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/inheritance_maintained.php
INFO - 2018-10-22 14:01:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 14:01:38 --> Final output sent to browser
DEBUG - 2018-10-22 14:01:38 --> Total execution time: 0.7114
INFO - 2018-10-22 14:01:42 --> Config Class Initialized
INFO - 2018-10-22 14:01:42 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:01:42 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:01:42 --> Utf8 Class Initialized
INFO - 2018-10-22 14:01:42 --> URI Class Initialized
INFO - 2018-10-22 14:01:42 --> Router Class Initialized
INFO - 2018-10-22 14:01:42 --> Output Class Initialized
INFO - 2018-10-22 14:01:42 --> Security Class Initialized
DEBUG - 2018-10-22 14:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:01:42 --> CSRF cookie sent
INFO - 2018-10-22 14:01:42 --> Input Class Initialized
INFO - 2018-10-22 14:01:42 --> Language Class Initialized
INFO - 2018-10-22 14:01:42 --> Loader Class Initialized
INFO - 2018-10-22 14:01:42 --> Helper loaded: url_helper
INFO - 2018-10-22 14:01:42 --> Helper loaded: form_helper
INFO - 2018-10-22 14:01:42 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:01:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:01:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:01:42 --> User Agent Class Initialized
INFO - 2018-10-22 14:01:42 --> Controller Class Initialized
INFO - 2018-10-22 14:01:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:01:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:01:42 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:01:42 --> Pixel_Model class loaded
INFO - 2018-10-22 14:01:42 --> Database Driver Class Initialized
INFO - 2018-10-22 14:01:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:01:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 14:01:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 14:01:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 14:01:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 14:01:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 14:01:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 14:01:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-22 14:01:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 14:01:43 --> Final output sent to browser
DEBUG - 2018-10-22 14:01:43 --> Total execution time: 0.7566
INFO - 2018-10-22 14:01:56 --> Config Class Initialized
INFO - 2018-10-22 14:01:56 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:01:56 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:01:56 --> Utf8 Class Initialized
INFO - 2018-10-22 14:01:56 --> URI Class Initialized
INFO - 2018-10-22 14:01:56 --> Router Class Initialized
INFO - 2018-10-22 14:01:56 --> Output Class Initialized
INFO - 2018-10-22 14:01:56 --> Security Class Initialized
DEBUG - 2018-10-22 14:01:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:01:56 --> CSRF cookie sent
INFO - 2018-10-22 14:01:56 --> Input Class Initialized
INFO - 2018-10-22 14:01:56 --> Language Class Initialized
INFO - 2018-10-22 14:01:56 --> Loader Class Initialized
INFO - 2018-10-22 14:01:56 --> Helper loaded: url_helper
INFO - 2018-10-22 14:01:56 --> Helper loaded: form_helper
INFO - 2018-10-22 14:01:56 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:01:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:01:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:01:56 --> User Agent Class Initialized
INFO - 2018-10-22 14:01:56 --> Controller Class Initialized
INFO - 2018-10-22 14:01:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:01:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:01:56 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:01:56 --> Pixel_Model class loaded
INFO - 2018-10-22 14:01:56 --> Database Driver Class Initialized
INFO - 2018-10-22 14:01:57 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:01:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 14:01:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 14:01:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 14:01:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 14:01:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 14:01:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 14:01:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-22 14:01:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 14:01:57 --> Final output sent to browser
DEBUG - 2018-10-22 14:01:57 --> Total execution time: 0.7145
INFO - 2018-10-22 14:01:59 --> Config Class Initialized
INFO - 2018-10-22 14:01:59 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:01:59 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:01:59 --> Utf8 Class Initialized
INFO - 2018-10-22 14:01:59 --> URI Class Initialized
INFO - 2018-10-22 14:01:59 --> Router Class Initialized
INFO - 2018-10-22 14:01:59 --> Output Class Initialized
INFO - 2018-10-22 14:01:59 --> Security Class Initialized
DEBUG - 2018-10-22 14:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:01:59 --> CSRF cookie sent
INFO - 2018-10-22 14:01:59 --> CSRF token verified
INFO - 2018-10-22 14:01:59 --> Input Class Initialized
INFO - 2018-10-22 14:01:59 --> Language Class Initialized
INFO - 2018-10-22 14:01:59 --> Loader Class Initialized
INFO - 2018-10-22 14:01:59 --> Helper loaded: url_helper
INFO - 2018-10-22 14:01:59 --> Helper loaded: form_helper
INFO - 2018-10-22 14:01:59 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:01:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:01:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:01:59 --> User Agent Class Initialized
INFO - 2018-10-22 14:01:59 --> Controller Class Initialized
INFO - 2018-10-22 14:01:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:02:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:02:00 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:02:00 --> Pixel_Model class loaded
INFO - 2018-10-22 14:02:00 --> Database Driver Class Initialized
INFO - 2018-10-22 14:02:00 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:02:00 --> Form Validation Class Initialized
INFO - 2018-10-22 14:02:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 14:02:00 --> Database Driver Class Initialized
INFO - 2018-10-22 14:02:00 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:02:00 --> Config Class Initialized
INFO - 2018-10-22 14:02:00 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:02:00 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:02:00 --> Utf8 Class Initialized
INFO - 2018-10-22 14:02:00 --> URI Class Initialized
INFO - 2018-10-22 14:02:00 --> Router Class Initialized
INFO - 2018-10-22 14:02:00 --> Output Class Initialized
INFO - 2018-10-22 14:02:00 --> Security Class Initialized
DEBUG - 2018-10-22 14:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:02:00 --> CSRF cookie sent
INFO - 2018-10-22 14:02:00 --> Input Class Initialized
INFO - 2018-10-22 14:02:00 --> Language Class Initialized
INFO - 2018-10-22 14:02:00 --> Loader Class Initialized
INFO - 2018-10-22 14:02:00 --> Helper loaded: url_helper
INFO - 2018-10-22 14:02:00 --> Helper loaded: form_helper
INFO - 2018-10-22 14:02:00 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:02:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:02:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:02:00 --> User Agent Class Initialized
INFO - 2018-10-22 14:02:00 --> Controller Class Initialized
INFO - 2018-10-22 14:02:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:02:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:02:00 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:02:00 --> Pixel_Model class loaded
INFO - 2018-10-22 14:02:00 --> Database Driver Class Initialized
INFO - 2018-10-22 14:02:00 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:02:00 --> Database Driver Class Initialized
INFO - 2018-10-22 14:02:00 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:02:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 14:02:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 14:02:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 14:02:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 14:02:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 14:02:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 14:02:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-22 14:02:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 14:02:00 --> Final output sent to browser
DEBUG - 2018-10-22 14:02:01 --> Total execution time: 0.7089
INFO - 2018-10-22 14:02:03 --> Config Class Initialized
INFO - 2018-10-22 14:02:03 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:02:03 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:02:03 --> Utf8 Class Initialized
INFO - 2018-10-22 14:02:03 --> URI Class Initialized
INFO - 2018-10-22 14:02:03 --> Router Class Initialized
INFO - 2018-10-22 14:02:03 --> Output Class Initialized
INFO - 2018-10-22 14:02:03 --> Security Class Initialized
DEBUG - 2018-10-22 14:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:02:04 --> CSRF cookie sent
INFO - 2018-10-22 14:02:04 --> CSRF token verified
INFO - 2018-10-22 14:02:04 --> Input Class Initialized
INFO - 2018-10-22 14:02:04 --> Language Class Initialized
INFO - 2018-10-22 14:02:04 --> Loader Class Initialized
INFO - 2018-10-22 14:02:04 --> Helper loaded: url_helper
INFO - 2018-10-22 14:02:04 --> Helper loaded: form_helper
INFO - 2018-10-22 14:02:04 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:02:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:02:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:02:04 --> User Agent Class Initialized
INFO - 2018-10-22 14:02:04 --> Controller Class Initialized
INFO - 2018-10-22 14:02:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:02:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:02:04 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:02:04 --> Pixel_Model class loaded
INFO - 2018-10-22 14:02:04 --> Database Driver Class Initialized
INFO - 2018-10-22 14:02:04 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:02:04 --> Form Validation Class Initialized
INFO - 2018-10-22 14:02:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 14:02:04 --> Database Driver Class Initialized
INFO - 2018-10-22 14:02:04 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:02:04 --> Config Class Initialized
INFO - 2018-10-22 14:02:04 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:02:04 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:02:04 --> Utf8 Class Initialized
INFO - 2018-10-22 14:02:04 --> URI Class Initialized
INFO - 2018-10-22 14:02:04 --> Router Class Initialized
INFO - 2018-10-22 14:02:04 --> Output Class Initialized
INFO - 2018-10-22 14:02:04 --> Security Class Initialized
DEBUG - 2018-10-22 14:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:02:04 --> CSRF cookie sent
INFO - 2018-10-22 14:02:04 --> Input Class Initialized
INFO - 2018-10-22 14:02:04 --> Language Class Initialized
INFO - 2018-10-22 14:02:04 --> Loader Class Initialized
INFO - 2018-10-22 14:02:04 --> Helper loaded: url_helper
INFO - 2018-10-22 14:02:04 --> Helper loaded: form_helper
INFO - 2018-10-22 14:02:04 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:02:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:02:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:02:04 --> User Agent Class Initialized
INFO - 2018-10-22 14:02:04 --> Controller Class Initialized
INFO - 2018-10-22 14:02:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:02:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:02:04 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:02:04 --> Pixel_Model class loaded
INFO - 2018-10-22 14:02:04 --> Database Driver Class Initialized
INFO - 2018-10-22 14:02:05 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:02:05 --> Database Driver Class Initialized
INFO - 2018-10-22 14:02:05 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:02:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 14:02:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 14:02:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 14:02:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 14:02:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 14:02:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 14:02:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/your_job.php
INFO - 2018-10-22 14:02:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 14:02:05 --> Final output sent to browser
DEBUG - 2018-10-22 14:02:05 --> Total execution time: 0.7256
INFO - 2018-10-22 14:02:07 --> Config Class Initialized
INFO - 2018-10-22 14:02:07 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:02:07 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:02:07 --> Utf8 Class Initialized
INFO - 2018-10-22 14:02:07 --> URI Class Initialized
INFO - 2018-10-22 14:02:07 --> Router Class Initialized
INFO - 2018-10-22 14:02:07 --> Output Class Initialized
INFO - 2018-10-22 14:02:07 --> Security Class Initialized
DEBUG - 2018-10-22 14:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:02:07 --> CSRF cookie sent
INFO - 2018-10-22 14:02:07 --> CSRF token verified
INFO - 2018-10-22 14:02:07 --> Input Class Initialized
INFO - 2018-10-22 14:02:07 --> Language Class Initialized
INFO - 2018-10-22 14:02:08 --> Loader Class Initialized
INFO - 2018-10-22 14:02:08 --> Helper loaded: url_helper
INFO - 2018-10-22 14:02:08 --> Helper loaded: form_helper
INFO - 2018-10-22 14:02:08 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:02:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:02:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:02:08 --> User Agent Class Initialized
INFO - 2018-10-22 14:02:08 --> Controller Class Initialized
INFO - 2018-10-22 14:02:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:02:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:02:08 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:02:08 --> Pixel_Model class loaded
INFO - 2018-10-22 14:02:08 --> Database Driver Class Initialized
INFO - 2018-10-22 14:02:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:02:08 --> Form Validation Class Initialized
INFO - 2018-10-22 14:02:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 14:02:08 --> Database Driver Class Initialized
INFO - 2018-10-22 14:02:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:02:08 --> Config Class Initialized
INFO - 2018-10-22 14:02:08 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:02:08 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:02:08 --> Utf8 Class Initialized
INFO - 2018-10-22 14:02:08 --> URI Class Initialized
INFO - 2018-10-22 14:02:08 --> Router Class Initialized
INFO - 2018-10-22 14:02:08 --> Output Class Initialized
INFO - 2018-10-22 14:02:08 --> Security Class Initialized
DEBUG - 2018-10-22 14:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:02:08 --> CSRF cookie sent
INFO - 2018-10-22 14:02:08 --> Input Class Initialized
INFO - 2018-10-22 14:02:08 --> Language Class Initialized
INFO - 2018-10-22 14:02:08 --> Loader Class Initialized
INFO - 2018-10-22 14:02:08 --> Helper loaded: url_helper
INFO - 2018-10-22 14:02:08 --> Helper loaded: form_helper
INFO - 2018-10-22 14:02:08 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:02:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:02:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:02:08 --> User Agent Class Initialized
INFO - 2018-10-22 14:02:08 --> Controller Class Initialized
INFO - 2018-10-22 14:02:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:02:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:02:08 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:02:08 --> Pixel_Model class loaded
INFO - 2018-10-22 14:02:08 --> Database Driver Class Initialized
INFO - 2018-10-22 14:02:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:02:08 --> Database Driver Class Initialized
INFO - 2018-10-22 14:02:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:02:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 14:02:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 14:02:09 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner.php
INFO - 2018-10-22 14:02:09 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 14:02:09 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 14:02:09 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 14:02:09 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 14:02:09 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/relation_ship_status.php
INFO - 2018-10-22 14:02:09 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 14:02:09 --> Final output sent to browser
DEBUG - 2018-10-22 14:02:09 --> Total execution time: 0.7254
INFO - 2018-10-22 14:02:18 --> Config Class Initialized
INFO - 2018-10-22 14:02:18 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:02:18 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:02:18 --> Utf8 Class Initialized
INFO - 2018-10-22 14:02:18 --> URI Class Initialized
INFO - 2018-10-22 14:02:18 --> Router Class Initialized
INFO - 2018-10-22 14:02:18 --> Output Class Initialized
INFO - 2018-10-22 14:02:18 --> Security Class Initialized
DEBUG - 2018-10-22 14:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:02:18 --> CSRF cookie sent
INFO - 2018-10-22 14:02:18 --> CSRF token verified
INFO - 2018-10-22 14:02:18 --> Input Class Initialized
INFO - 2018-10-22 14:02:18 --> Language Class Initialized
INFO - 2018-10-22 14:02:18 --> Loader Class Initialized
INFO - 2018-10-22 14:02:18 --> Helper loaded: url_helper
INFO - 2018-10-22 14:02:18 --> Helper loaded: form_helper
INFO - 2018-10-22 14:02:18 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:02:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:02:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:02:18 --> User Agent Class Initialized
INFO - 2018-10-22 14:02:18 --> Controller Class Initialized
INFO - 2018-10-22 14:02:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:02:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:02:18 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:02:18 --> Pixel_Model class loaded
INFO - 2018-10-22 14:02:18 --> Database Driver Class Initialized
INFO - 2018-10-22 14:02:18 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:02:18 --> Form Validation Class Initialized
INFO - 2018-10-22 14:02:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 14:02:18 --> Database Driver Class Initialized
INFO - 2018-10-22 14:02:18 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:02:19 --> Config Class Initialized
INFO - 2018-10-22 14:02:19 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:02:19 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:02:19 --> Utf8 Class Initialized
INFO - 2018-10-22 14:02:19 --> URI Class Initialized
INFO - 2018-10-22 14:02:19 --> Router Class Initialized
INFO - 2018-10-22 14:02:19 --> Output Class Initialized
INFO - 2018-10-22 14:02:19 --> Security Class Initialized
DEBUG - 2018-10-22 14:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:02:19 --> CSRF cookie sent
INFO - 2018-10-22 14:02:19 --> Input Class Initialized
INFO - 2018-10-22 14:02:19 --> Language Class Initialized
INFO - 2018-10-22 14:02:19 --> Loader Class Initialized
INFO - 2018-10-22 14:02:19 --> Helper loaded: url_helper
INFO - 2018-10-22 14:02:19 --> Helper loaded: form_helper
INFO - 2018-10-22 14:02:19 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:02:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:02:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:02:19 --> User Agent Class Initialized
INFO - 2018-10-22 14:02:19 --> Controller Class Initialized
INFO - 2018-10-22 14:02:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:02:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:02:19 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:02:19 --> Pixel_Model class loaded
INFO - 2018-10-22 14:02:19 --> Database Driver Class Initialized
INFO - 2018-10-22 14:02:19 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:02:19 --> Database Driver Class Initialized
INFO - 2018-10-22 14:02:19 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:02:19 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 14:02:19 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 14:02:19 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 14:02:19 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 14:02:19 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 14:02:19 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 14:02:19 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/income.php
INFO - 2018-10-22 14:02:19 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 14:02:19 --> Final output sent to browser
DEBUG - 2018-10-22 14:02:19 --> Total execution time: 0.7373
INFO - 2018-10-22 14:02:29 --> Config Class Initialized
INFO - 2018-10-22 14:02:29 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:02:29 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:02:29 --> Utf8 Class Initialized
INFO - 2018-10-22 14:02:29 --> URI Class Initialized
INFO - 2018-10-22 14:02:29 --> Router Class Initialized
INFO - 2018-10-22 14:02:30 --> Output Class Initialized
INFO - 2018-10-22 14:02:30 --> Security Class Initialized
DEBUG - 2018-10-22 14:02:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:02:30 --> CSRF cookie sent
INFO - 2018-10-22 14:02:30 --> CSRF token verified
INFO - 2018-10-22 14:02:30 --> Input Class Initialized
INFO - 2018-10-22 14:02:30 --> Language Class Initialized
INFO - 2018-10-22 14:02:30 --> Loader Class Initialized
INFO - 2018-10-22 14:02:30 --> Helper loaded: url_helper
INFO - 2018-10-22 14:02:30 --> Helper loaded: form_helper
INFO - 2018-10-22 14:02:30 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:02:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:02:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:02:30 --> User Agent Class Initialized
INFO - 2018-10-22 14:02:30 --> Controller Class Initialized
INFO - 2018-10-22 14:02:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:02:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:02:30 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:02:30 --> Pixel_Model class loaded
INFO - 2018-10-22 14:02:30 --> Database Driver Class Initialized
INFO - 2018-10-22 14:02:30 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:02:30 --> Form Validation Class Initialized
INFO - 2018-10-22 14:02:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 14:02:30 --> Database Driver Class Initialized
INFO - 2018-10-22 14:02:30 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:02:30 --> Config Class Initialized
INFO - 2018-10-22 14:02:30 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:02:30 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:02:30 --> Utf8 Class Initialized
INFO - 2018-10-22 14:02:30 --> URI Class Initialized
INFO - 2018-10-22 14:02:30 --> Router Class Initialized
INFO - 2018-10-22 14:02:30 --> Output Class Initialized
INFO - 2018-10-22 14:02:30 --> Security Class Initialized
DEBUG - 2018-10-22 14:02:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:02:30 --> CSRF cookie sent
INFO - 2018-10-22 14:02:30 --> Input Class Initialized
INFO - 2018-10-22 14:02:30 --> Language Class Initialized
INFO - 2018-10-22 14:02:30 --> Loader Class Initialized
INFO - 2018-10-22 14:02:30 --> Helper loaded: url_helper
INFO - 2018-10-22 14:02:30 --> Helper loaded: form_helper
INFO - 2018-10-22 14:02:30 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:02:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:02:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:02:30 --> User Agent Class Initialized
INFO - 2018-10-22 14:02:30 --> Controller Class Initialized
INFO - 2018-10-22 14:02:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:02:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:02:31 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:02:31 --> Pixel_Model class loaded
INFO - 2018-10-22 14:02:31 --> Database Driver Class Initialized
INFO - 2018-10-22 14:02:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:02:31 --> Database Driver Class Initialized
INFO - 2018-10-22 14:02:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:02:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 14:02:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 14:02:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 14:02:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 14:02:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 14:02:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 14:02:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/cohabitation.php
INFO - 2018-10-22 14:02:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 14:02:31 --> Final output sent to browser
DEBUG - 2018-10-22 14:02:31 --> Total execution time: 0.7513
INFO - 2018-10-22 14:02:34 --> Config Class Initialized
INFO - 2018-10-22 14:02:34 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:02:34 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:02:34 --> Utf8 Class Initialized
INFO - 2018-10-22 14:02:34 --> URI Class Initialized
INFO - 2018-10-22 14:02:34 --> Router Class Initialized
INFO - 2018-10-22 14:02:34 --> Output Class Initialized
INFO - 2018-10-22 14:02:34 --> Security Class Initialized
DEBUG - 2018-10-22 14:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:02:34 --> CSRF cookie sent
INFO - 2018-10-22 14:02:34 --> CSRF token verified
INFO - 2018-10-22 14:02:34 --> Input Class Initialized
INFO - 2018-10-22 14:02:34 --> Language Class Initialized
INFO - 2018-10-22 14:02:34 --> Loader Class Initialized
INFO - 2018-10-22 14:02:34 --> Helper loaded: url_helper
INFO - 2018-10-22 14:02:34 --> Helper loaded: form_helper
INFO - 2018-10-22 14:02:34 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:02:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:02:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:02:34 --> User Agent Class Initialized
INFO - 2018-10-22 14:02:34 --> Controller Class Initialized
INFO - 2018-10-22 14:02:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:02:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:02:34 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:02:34 --> Pixel_Model class loaded
INFO - 2018-10-22 14:02:34 --> Database Driver Class Initialized
INFO - 2018-10-22 14:02:34 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:02:34 --> Form Validation Class Initialized
INFO - 2018-10-22 14:02:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 14:02:34 --> Database Driver Class Initialized
INFO - 2018-10-22 14:02:34 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:02:34 --> Config Class Initialized
INFO - 2018-10-22 14:02:34 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:02:34 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:02:34 --> Utf8 Class Initialized
INFO - 2018-10-22 14:02:35 --> URI Class Initialized
INFO - 2018-10-22 14:02:35 --> Router Class Initialized
INFO - 2018-10-22 14:02:35 --> Output Class Initialized
INFO - 2018-10-22 14:02:35 --> Security Class Initialized
DEBUG - 2018-10-22 14:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:02:35 --> CSRF cookie sent
INFO - 2018-10-22 14:02:35 --> Input Class Initialized
INFO - 2018-10-22 14:02:35 --> Language Class Initialized
INFO - 2018-10-22 14:02:35 --> Loader Class Initialized
INFO - 2018-10-22 14:02:35 --> Helper loaded: url_helper
INFO - 2018-10-22 14:02:35 --> Helper loaded: form_helper
INFO - 2018-10-22 14:02:35 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:02:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:02:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:02:35 --> User Agent Class Initialized
INFO - 2018-10-22 14:02:35 --> Controller Class Initialized
INFO - 2018-10-22 14:02:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:02:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:02:35 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:02:35 --> Pixel_Model class loaded
INFO - 2018-10-22 14:02:35 --> Database Driver Class Initialized
INFO - 2018-10-22 14:02:35 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:02:35 --> Database Driver Class Initialized
INFO - 2018-10-22 14:02:35 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:02:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 14:02:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 14:02:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 14:02:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 14:02:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 14:02:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 14:02:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/kids.php
INFO - 2018-10-22 14:02:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 14:02:35 --> Final output sent to browser
DEBUG - 2018-10-22 14:02:35 --> Total execution time: 0.7378
INFO - 2018-10-22 14:02:38 --> Config Class Initialized
INFO - 2018-10-22 14:02:38 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:02:38 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:02:38 --> Utf8 Class Initialized
INFO - 2018-10-22 14:02:38 --> URI Class Initialized
INFO - 2018-10-22 14:02:38 --> Router Class Initialized
INFO - 2018-10-22 14:02:38 --> Output Class Initialized
INFO - 2018-10-22 14:02:39 --> Security Class Initialized
DEBUG - 2018-10-22 14:02:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:02:39 --> CSRF cookie sent
INFO - 2018-10-22 14:02:39 --> Input Class Initialized
INFO - 2018-10-22 14:02:39 --> Language Class Initialized
INFO - 2018-10-22 14:02:39 --> Loader Class Initialized
INFO - 2018-10-22 14:02:39 --> Helper loaded: url_helper
INFO - 2018-10-22 14:02:39 --> Helper loaded: form_helper
INFO - 2018-10-22 14:02:39 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:02:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:02:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:02:39 --> User Agent Class Initialized
INFO - 2018-10-22 14:02:39 --> Controller Class Initialized
INFO - 2018-10-22 14:02:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:02:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:02:39 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:02:39 --> Pixel_Model class loaded
INFO - 2018-10-22 14:02:39 --> Database Driver Class Initialized
INFO - 2018-10-22 14:02:39 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:02:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 14:02:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 14:02:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 14:02:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 14:02:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 14:02:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 14:02:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-22 14:02:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 14:02:39 --> Final output sent to browser
DEBUG - 2018-10-22 14:02:39 --> Total execution time: 0.6926
INFO - 2018-10-22 14:03:06 --> Config Class Initialized
INFO - 2018-10-22 14:03:06 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:03:06 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:03:06 --> Utf8 Class Initialized
INFO - 2018-10-22 14:03:06 --> URI Class Initialized
INFO - 2018-10-22 14:03:06 --> Router Class Initialized
INFO - 2018-10-22 14:03:06 --> Output Class Initialized
INFO - 2018-10-22 14:03:06 --> Security Class Initialized
DEBUG - 2018-10-22 14:03:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:03:06 --> CSRF cookie sent
INFO - 2018-10-22 14:03:06 --> Input Class Initialized
INFO - 2018-10-22 14:03:06 --> Language Class Initialized
INFO - 2018-10-22 14:03:06 --> Loader Class Initialized
INFO - 2018-10-22 14:03:06 --> Helper loaded: url_helper
INFO - 2018-10-22 14:03:06 --> Helper loaded: form_helper
INFO - 2018-10-22 14:03:06 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:03:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:03:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:03:06 --> User Agent Class Initialized
INFO - 2018-10-22 14:03:06 --> Controller Class Initialized
INFO - 2018-10-22 14:03:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:03:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:03:06 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:03:06 --> Pixel_Model class loaded
INFO - 2018-10-22 14:03:06 --> Database Driver Class Initialized
INFO - 2018-10-22 14:03:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:03:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 14:03:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 14:03:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 14:03:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 14:03:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 14:03:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 14:03:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-22 14:03:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 14:03:07 --> Final output sent to browser
DEBUG - 2018-10-22 14:03:07 --> Total execution time: 0.6995
INFO - 2018-10-22 14:03:07 --> Config Class Initialized
INFO - 2018-10-22 14:03:07 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:03:07 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:03:07 --> Utf8 Class Initialized
INFO - 2018-10-22 14:03:07 --> URI Class Initialized
INFO - 2018-10-22 14:03:07 --> Router Class Initialized
INFO - 2018-10-22 14:03:07 --> Output Class Initialized
INFO - 2018-10-22 14:03:07 --> Security Class Initialized
DEBUG - 2018-10-22 14:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:03:07 --> CSRF cookie sent
INFO - 2018-10-22 14:03:07 --> Input Class Initialized
INFO - 2018-10-22 14:03:07 --> Language Class Initialized
INFO - 2018-10-22 14:03:07 --> Loader Class Initialized
INFO - 2018-10-22 14:03:07 --> Helper loaded: url_helper
INFO - 2018-10-22 14:03:07 --> Helper loaded: form_helper
INFO - 2018-10-22 14:03:07 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:03:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:03:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:03:07 --> User Agent Class Initialized
INFO - 2018-10-22 14:03:07 --> Controller Class Initialized
INFO - 2018-10-22 14:03:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:03:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:03:07 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:03:07 --> Pixel_Model class loaded
INFO - 2018-10-22 14:03:07 --> Database Driver Class Initialized
INFO - 2018-10-22 14:03:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:03:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 14:03:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 14:03:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 14:03:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 14:03:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 14:03:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 14:03:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-22 14:03:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 14:03:08 --> Final output sent to browser
DEBUG - 2018-10-22 14:03:08 --> Total execution time: 0.7210
INFO - 2018-10-22 14:03:09 --> Config Class Initialized
INFO - 2018-10-22 14:03:09 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:03:09 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:03:09 --> Utf8 Class Initialized
INFO - 2018-10-22 14:03:09 --> URI Class Initialized
INFO - 2018-10-22 14:03:09 --> Router Class Initialized
INFO - 2018-10-22 14:03:09 --> Output Class Initialized
INFO - 2018-10-22 14:03:09 --> Security Class Initialized
DEBUG - 2018-10-22 14:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:03:09 --> CSRF cookie sent
INFO - 2018-10-22 14:03:09 --> CSRF token verified
INFO - 2018-10-22 14:03:09 --> Input Class Initialized
INFO - 2018-10-22 14:03:09 --> Language Class Initialized
INFO - 2018-10-22 14:03:09 --> Loader Class Initialized
INFO - 2018-10-22 14:03:09 --> Helper loaded: url_helper
INFO - 2018-10-22 14:03:09 --> Helper loaded: form_helper
INFO - 2018-10-22 14:03:09 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:03:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:03:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:03:09 --> User Agent Class Initialized
INFO - 2018-10-22 14:03:09 --> Controller Class Initialized
INFO - 2018-10-22 14:03:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:03:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:03:10 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:03:10 --> Pixel_Model class loaded
INFO - 2018-10-22 14:03:10 --> Database Driver Class Initialized
INFO - 2018-10-22 14:03:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:03:10 --> Form Validation Class Initialized
INFO - 2018-10-22 14:03:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 14:03:10 --> Database Driver Class Initialized
INFO - 2018-10-22 14:03:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:03:10 --> Config Class Initialized
INFO - 2018-10-22 14:03:10 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:03:10 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:03:10 --> Utf8 Class Initialized
INFO - 2018-10-22 14:03:10 --> URI Class Initialized
INFO - 2018-10-22 14:03:10 --> Router Class Initialized
INFO - 2018-10-22 14:03:10 --> Output Class Initialized
INFO - 2018-10-22 14:03:10 --> Security Class Initialized
DEBUG - 2018-10-22 14:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:03:10 --> CSRF cookie sent
INFO - 2018-10-22 14:03:10 --> Input Class Initialized
INFO - 2018-10-22 14:03:10 --> Language Class Initialized
INFO - 2018-10-22 14:03:10 --> Loader Class Initialized
INFO - 2018-10-22 14:03:10 --> Helper loaded: url_helper
INFO - 2018-10-22 14:03:10 --> Helper loaded: form_helper
INFO - 2018-10-22 14:03:10 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:03:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:03:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:03:10 --> User Agent Class Initialized
INFO - 2018-10-22 14:03:10 --> Controller Class Initialized
INFO - 2018-10-22 14:03:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:03:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:03:10 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:03:10 --> Pixel_Model class loaded
INFO - 2018-10-22 14:03:10 --> Database Driver Class Initialized
INFO - 2018-10-22 14:03:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:03:10 --> Database Driver Class Initialized
INFO - 2018-10-22 14:03:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:03:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 14:03:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 14:03:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 14:03:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 14:03:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 14:03:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 14:03:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-22 14:03:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 14:03:10 --> Final output sent to browser
DEBUG - 2018-10-22 14:03:11 --> Total execution time: 0.7285
INFO - 2018-10-22 14:03:14 --> Config Class Initialized
INFO - 2018-10-22 14:03:14 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:03:14 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:03:14 --> Utf8 Class Initialized
INFO - 2018-10-22 14:03:14 --> URI Class Initialized
INFO - 2018-10-22 14:03:14 --> Router Class Initialized
INFO - 2018-10-22 14:03:14 --> Output Class Initialized
INFO - 2018-10-22 14:03:14 --> Security Class Initialized
DEBUG - 2018-10-22 14:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:03:14 --> CSRF cookie sent
INFO - 2018-10-22 14:03:14 --> CSRF token verified
INFO - 2018-10-22 14:03:14 --> Input Class Initialized
INFO - 2018-10-22 14:03:14 --> Language Class Initialized
INFO - 2018-10-22 14:03:14 --> Loader Class Initialized
INFO - 2018-10-22 14:03:14 --> Helper loaded: url_helper
INFO - 2018-10-22 14:03:14 --> Helper loaded: form_helper
INFO - 2018-10-22 14:03:14 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:03:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:03:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:03:14 --> User Agent Class Initialized
INFO - 2018-10-22 14:03:14 --> Controller Class Initialized
INFO - 2018-10-22 14:03:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:03:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:03:14 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:03:14 --> Pixel_Model class loaded
INFO - 2018-10-22 14:03:14 --> Database Driver Class Initialized
INFO - 2018-10-22 14:03:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:03:14 --> Form Validation Class Initialized
INFO - 2018-10-22 14:03:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 14:03:14 --> Database Driver Class Initialized
INFO - 2018-10-22 14:03:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:03:14 --> Config Class Initialized
INFO - 2018-10-22 14:03:14 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:03:14 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:03:15 --> Utf8 Class Initialized
INFO - 2018-10-22 14:03:15 --> URI Class Initialized
INFO - 2018-10-22 14:03:15 --> Router Class Initialized
INFO - 2018-10-22 14:03:15 --> Output Class Initialized
INFO - 2018-10-22 14:03:15 --> Security Class Initialized
DEBUG - 2018-10-22 14:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:03:15 --> CSRF cookie sent
INFO - 2018-10-22 14:03:15 --> Input Class Initialized
INFO - 2018-10-22 14:03:15 --> Language Class Initialized
INFO - 2018-10-22 14:03:15 --> Loader Class Initialized
INFO - 2018-10-22 14:03:15 --> Helper loaded: url_helper
INFO - 2018-10-22 14:03:15 --> Helper loaded: form_helper
INFO - 2018-10-22 14:03:15 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:03:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:03:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:03:15 --> User Agent Class Initialized
INFO - 2018-10-22 14:03:15 --> Controller Class Initialized
INFO - 2018-10-22 14:03:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:03:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:03:15 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:03:15 --> Pixel_Model class loaded
INFO - 2018-10-22 14:03:15 --> Database Driver Class Initialized
INFO - 2018-10-22 14:03:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:03:15 --> Database Driver Class Initialized
INFO - 2018-10-22 14:03:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:03:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 14:03:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 14:03:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 14:03:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 14:03:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 14:03:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 14:03:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/your_job.php
INFO - 2018-10-22 14:03:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 14:03:15 --> Final output sent to browser
DEBUG - 2018-10-22 14:03:15 --> Total execution time: 0.7257
INFO - 2018-10-22 14:03:19 --> Config Class Initialized
INFO - 2018-10-22 14:03:19 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:03:20 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:03:20 --> Utf8 Class Initialized
INFO - 2018-10-22 14:03:20 --> URI Class Initialized
INFO - 2018-10-22 14:03:20 --> Router Class Initialized
INFO - 2018-10-22 14:03:20 --> Output Class Initialized
INFO - 2018-10-22 14:03:20 --> Security Class Initialized
DEBUG - 2018-10-22 14:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:03:20 --> CSRF cookie sent
INFO - 2018-10-22 14:03:20 --> CSRF token verified
INFO - 2018-10-22 14:03:20 --> Input Class Initialized
INFO - 2018-10-22 14:03:20 --> Language Class Initialized
INFO - 2018-10-22 14:03:20 --> Loader Class Initialized
INFO - 2018-10-22 14:03:20 --> Helper loaded: url_helper
INFO - 2018-10-22 14:03:20 --> Helper loaded: form_helper
INFO - 2018-10-22 14:03:20 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:03:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:03:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:03:20 --> User Agent Class Initialized
INFO - 2018-10-22 14:03:20 --> Controller Class Initialized
INFO - 2018-10-22 14:03:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:03:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:03:20 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:03:20 --> Pixel_Model class loaded
INFO - 2018-10-22 14:03:20 --> Database Driver Class Initialized
INFO - 2018-10-22 14:03:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:03:20 --> Form Validation Class Initialized
INFO - 2018-10-22 14:03:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 14:03:20 --> Database Driver Class Initialized
INFO - 2018-10-22 14:03:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:03:20 --> Config Class Initialized
INFO - 2018-10-22 14:03:20 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:03:20 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:03:20 --> Utf8 Class Initialized
INFO - 2018-10-22 14:03:20 --> URI Class Initialized
INFO - 2018-10-22 14:03:20 --> Router Class Initialized
INFO - 2018-10-22 14:03:20 --> Output Class Initialized
INFO - 2018-10-22 14:03:20 --> Security Class Initialized
DEBUG - 2018-10-22 14:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:03:20 --> CSRF cookie sent
INFO - 2018-10-22 14:03:20 --> Input Class Initialized
INFO - 2018-10-22 14:03:20 --> Language Class Initialized
INFO - 2018-10-22 14:03:20 --> Loader Class Initialized
INFO - 2018-10-22 14:03:20 --> Helper loaded: url_helper
INFO - 2018-10-22 14:03:20 --> Helper loaded: form_helper
INFO - 2018-10-22 14:03:20 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:03:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:03:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:03:20 --> User Agent Class Initialized
INFO - 2018-10-22 14:03:21 --> Controller Class Initialized
INFO - 2018-10-22 14:03:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:03:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:03:21 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:03:21 --> Pixel_Model class loaded
INFO - 2018-10-22 14:03:21 --> Database Driver Class Initialized
INFO - 2018-10-22 14:03:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:03:21 --> Database Driver Class Initialized
INFO - 2018-10-22 14:03:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:03:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 14:03:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 14:03:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner.php
INFO - 2018-10-22 14:03:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 14:03:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 14:03:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 14:03:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 14:03:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/relation_ship_status.php
INFO - 2018-10-22 14:03:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 14:03:21 --> Final output sent to browser
DEBUG - 2018-10-22 14:03:21 --> Total execution time: 0.7549
INFO - 2018-10-22 14:03:26 --> Config Class Initialized
INFO - 2018-10-22 14:03:26 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:03:26 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:03:26 --> Utf8 Class Initialized
INFO - 2018-10-22 14:03:26 --> URI Class Initialized
INFO - 2018-10-22 14:03:26 --> Router Class Initialized
INFO - 2018-10-22 14:03:26 --> Output Class Initialized
INFO - 2018-10-22 14:03:26 --> Security Class Initialized
DEBUG - 2018-10-22 14:03:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:03:26 --> CSRF cookie sent
INFO - 2018-10-22 14:03:26 --> CSRF token verified
INFO - 2018-10-22 14:03:26 --> Input Class Initialized
INFO - 2018-10-22 14:03:26 --> Language Class Initialized
INFO - 2018-10-22 14:03:26 --> Loader Class Initialized
INFO - 2018-10-22 14:03:26 --> Helper loaded: url_helper
INFO - 2018-10-22 14:03:26 --> Helper loaded: form_helper
INFO - 2018-10-22 14:03:26 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:03:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:03:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:03:26 --> User Agent Class Initialized
INFO - 2018-10-22 14:03:26 --> Controller Class Initialized
INFO - 2018-10-22 14:03:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:03:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:03:26 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:03:26 --> Pixel_Model class loaded
INFO - 2018-10-22 14:03:26 --> Database Driver Class Initialized
INFO - 2018-10-22 14:03:26 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:03:26 --> Form Validation Class Initialized
INFO - 2018-10-22 14:03:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 14:03:26 --> Database Driver Class Initialized
INFO - 2018-10-22 14:03:26 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:03:26 --> Config Class Initialized
INFO - 2018-10-22 14:03:26 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:03:26 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:03:26 --> Utf8 Class Initialized
INFO - 2018-10-22 14:03:26 --> URI Class Initialized
INFO - 2018-10-22 14:03:26 --> Router Class Initialized
INFO - 2018-10-22 14:03:26 --> Output Class Initialized
INFO - 2018-10-22 14:03:26 --> Security Class Initialized
DEBUG - 2018-10-22 14:03:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:03:26 --> CSRF cookie sent
INFO - 2018-10-22 14:03:26 --> Input Class Initialized
INFO - 2018-10-22 14:03:26 --> Language Class Initialized
INFO - 2018-10-22 14:03:26 --> Loader Class Initialized
INFO - 2018-10-22 14:03:27 --> Helper loaded: url_helper
INFO - 2018-10-22 14:03:27 --> Helper loaded: form_helper
INFO - 2018-10-22 14:03:27 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:03:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:03:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:03:27 --> User Agent Class Initialized
INFO - 2018-10-22 14:03:27 --> Controller Class Initialized
INFO - 2018-10-22 14:03:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:03:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:03:27 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:03:27 --> Pixel_Model class loaded
INFO - 2018-10-22 14:03:27 --> Database Driver Class Initialized
INFO - 2018-10-22 14:03:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:03:27 --> Database Driver Class Initialized
INFO - 2018-10-22 14:03:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:03:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 14:03:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 14:03:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 14:03:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 14:03:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 14:03:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 14:03:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/income.php
INFO - 2018-10-22 14:03:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 14:03:27 --> Final output sent to browser
DEBUG - 2018-10-22 14:03:27 --> Total execution time: 0.7093
INFO - 2018-10-22 14:03:31 --> Config Class Initialized
INFO - 2018-10-22 14:03:31 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:03:31 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:03:31 --> Utf8 Class Initialized
INFO - 2018-10-22 14:03:31 --> URI Class Initialized
INFO - 2018-10-22 14:03:31 --> Router Class Initialized
INFO - 2018-10-22 14:03:31 --> Output Class Initialized
INFO - 2018-10-22 14:03:31 --> Security Class Initialized
DEBUG - 2018-10-22 14:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:03:31 --> CSRF cookie sent
INFO - 2018-10-22 14:03:31 --> CSRF token verified
INFO - 2018-10-22 14:03:31 --> Input Class Initialized
INFO - 2018-10-22 14:03:31 --> Language Class Initialized
INFO - 2018-10-22 14:03:31 --> Loader Class Initialized
INFO - 2018-10-22 14:03:31 --> Helper loaded: url_helper
INFO - 2018-10-22 14:03:31 --> Helper loaded: form_helper
INFO - 2018-10-22 14:03:31 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:03:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:03:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:03:31 --> User Agent Class Initialized
INFO - 2018-10-22 14:03:31 --> Controller Class Initialized
INFO - 2018-10-22 14:03:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:03:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:03:31 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:03:31 --> Pixel_Model class loaded
INFO - 2018-10-22 14:03:31 --> Database Driver Class Initialized
INFO - 2018-10-22 14:03:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:03:31 --> Form Validation Class Initialized
INFO - 2018-10-22 14:03:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 14:03:31 --> Database Driver Class Initialized
INFO - 2018-10-22 14:03:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:03:31 --> Config Class Initialized
INFO - 2018-10-22 14:03:31 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:03:31 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:03:31 --> Utf8 Class Initialized
INFO - 2018-10-22 14:03:31 --> URI Class Initialized
INFO - 2018-10-22 14:03:31 --> Router Class Initialized
INFO - 2018-10-22 14:03:31 --> Output Class Initialized
INFO - 2018-10-22 14:03:31 --> Security Class Initialized
DEBUG - 2018-10-22 14:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:03:31 --> CSRF cookie sent
INFO - 2018-10-22 14:03:32 --> Input Class Initialized
INFO - 2018-10-22 14:03:32 --> Language Class Initialized
INFO - 2018-10-22 14:03:32 --> Loader Class Initialized
INFO - 2018-10-22 14:03:32 --> Helper loaded: url_helper
INFO - 2018-10-22 14:03:32 --> Helper loaded: form_helper
INFO - 2018-10-22 14:03:32 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:03:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:03:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:03:32 --> User Agent Class Initialized
INFO - 2018-10-22 14:03:32 --> Controller Class Initialized
INFO - 2018-10-22 14:03:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:03:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:03:32 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:03:32 --> Pixel_Model class loaded
INFO - 2018-10-22 14:03:32 --> Database Driver Class Initialized
INFO - 2018-10-22 14:03:32 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:03:32 --> Database Driver Class Initialized
INFO - 2018-10-22 14:03:32 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:03:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 14:03:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 14:03:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 14:03:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 14:03:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 14:03:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 14:03:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/marriage.php
INFO - 2018-10-22 14:03:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 14:03:32 --> Final output sent to browser
DEBUG - 2018-10-22 14:03:32 --> Total execution time: 0.7469
INFO - 2018-10-22 14:09:35 --> Config Class Initialized
INFO - 2018-10-22 14:09:35 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:09:35 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:09:35 --> Utf8 Class Initialized
INFO - 2018-10-22 14:09:35 --> URI Class Initialized
INFO - 2018-10-22 14:09:35 --> Router Class Initialized
INFO - 2018-10-22 14:09:35 --> Output Class Initialized
INFO - 2018-10-22 14:09:35 --> Security Class Initialized
DEBUG - 2018-10-22 14:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:09:35 --> CSRF cookie sent
INFO - 2018-10-22 14:09:35 --> Input Class Initialized
INFO - 2018-10-22 14:09:35 --> Language Class Initialized
INFO - 2018-10-22 14:09:35 --> Loader Class Initialized
INFO - 2018-10-22 14:09:35 --> Helper loaded: url_helper
INFO - 2018-10-22 14:09:35 --> Helper loaded: form_helper
INFO - 2018-10-22 14:09:36 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:09:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:09:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:09:36 --> User Agent Class Initialized
INFO - 2018-10-22 14:09:36 --> Controller Class Initialized
INFO - 2018-10-22 14:09:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:09:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:09:36 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:09:36 --> Pixel_Model class loaded
INFO - 2018-10-22 14:09:36 --> Database Driver Class Initialized
INFO - 2018-10-22 14:09:36 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:09:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 14:09:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 14:09:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 14:09:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 14:09:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 14:09:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 14:09:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-22 14:09:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 14:09:36 --> Final output sent to browser
DEBUG - 2018-10-22 14:09:36 --> Total execution time: 0.7183
INFO - 2018-10-22 14:09:39 --> Config Class Initialized
INFO - 2018-10-22 14:09:39 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:09:39 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:09:39 --> Utf8 Class Initialized
INFO - 2018-10-22 14:09:39 --> URI Class Initialized
INFO - 2018-10-22 14:09:39 --> Router Class Initialized
INFO - 2018-10-22 14:09:39 --> Output Class Initialized
INFO - 2018-10-22 14:09:39 --> Security Class Initialized
DEBUG - 2018-10-22 14:09:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:09:39 --> CSRF cookie sent
INFO - 2018-10-22 14:09:39 --> Input Class Initialized
INFO - 2018-10-22 14:09:39 --> Language Class Initialized
INFO - 2018-10-22 14:09:39 --> Loader Class Initialized
INFO - 2018-10-22 14:09:39 --> Helper loaded: url_helper
INFO - 2018-10-22 14:09:40 --> Helper loaded: form_helper
INFO - 2018-10-22 14:09:40 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:09:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:09:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:09:40 --> User Agent Class Initialized
INFO - 2018-10-22 14:09:40 --> Controller Class Initialized
INFO - 2018-10-22 14:09:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:09:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:09:40 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:09:40 --> Pixel_Model class loaded
INFO - 2018-10-22 14:09:40 --> Database Driver Class Initialized
INFO - 2018-10-22 14:09:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:09:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 14:09:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 14:09:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 14:09:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 14:09:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 14:09:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 14:09:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-22 14:09:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 14:09:40 --> Final output sent to browser
DEBUG - 2018-10-22 14:09:40 --> Total execution time: 0.7345
INFO - 2018-10-22 14:15:13 --> Config Class Initialized
INFO - 2018-10-22 14:15:14 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:15:15 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:15:15 --> Utf8 Class Initialized
INFO - 2018-10-22 14:15:15 --> URI Class Initialized
INFO - 2018-10-22 14:15:15 --> Router Class Initialized
INFO - 2018-10-22 14:15:15 --> Output Class Initialized
INFO - 2018-10-22 14:15:15 --> Security Class Initialized
DEBUG - 2018-10-22 14:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:15:15 --> CSRF cookie sent
INFO - 2018-10-22 14:15:15 --> Input Class Initialized
INFO - 2018-10-22 14:15:16 --> Language Class Initialized
INFO - 2018-10-22 14:15:16 --> Loader Class Initialized
INFO - 2018-10-22 14:15:17 --> Helper loaded: url_helper
INFO - 2018-10-22 14:15:17 --> Helper loaded: form_helper
INFO - 2018-10-22 14:15:17 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:15:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:15:17 --> User Agent Class Initialized
INFO - 2018-10-22 14:15:18 --> Controller Class Initialized
INFO - 2018-10-22 14:15:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:15:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:15:19 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:15:19 --> Pixel_Model class loaded
INFO - 2018-10-22 14:15:20 --> Database Driver Class Initialized
INFO - 2018-10-22 14:15:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:15:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 14:15:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 14:15:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 14:15:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 14:15:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 14:15:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 14:15:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-22 14:15:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 14:15:22 --> Final output sent to browser
DEBUG - 2018-10-22 14:15:22 --> Total execution time: 11.6668
INFO - 2018-10-22 14:21:39 --> Config Class Initialized
INFO - 2018-10-22 14:21:39 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:21:39 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:21:39 --> Utf8 Class Initialized
INFO - 2018-10-22 14:21:39 --> URI Class Initialized
INFO - 2018-10-22 14:21:39 --> Router Class Initialized
INFO - 2018-10-22 14:21:39 --> Output Class Initialized
INFO - 2018-10-22 14:21:39 --> Security Class Initialized
DEBUG - 2018-10-22 14:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:21:39 --> CSRF cookie sent
INFO - 2018-10-22 14:21:39 --> Input Class Initialized
INFO - 2018-10-22 14:21:39 --> Language Class Initialized
INFO - 2018-10-22 14:21:39 --> Loader Class Initialized
INFO - 2018-10-22 14:21:40 --> Helper loaded: url_helper
INFO - 2018-10-22 14:21:40 --> Helper loaded: form_helper
INFO - 2018-10-22 14:21:40 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:21:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:21:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:21:40 --> User Agent Class Initialized
INFO - 2018-10-22 14:21:40 --> Controller Class Initialized
INFO - 2018-10-22 14:21:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:21:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:21:40 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:21:40 --> Pixel_Model class loaded
INFO - 2018-10-22 14:21:40 --> Database Driver Class Initialized
INFO - 2018-10-22 14:21:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:21:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 14:21:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 14:21:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 14:21:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 14:21:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 14:21:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 14:21:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-22 14:21:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 14:21:40 --> Final output sent to browser
DEBUG - 2018-10-22 14:21:40 --> Total execution time: 0.6981
INFO - 2018-10-22 14:21:42 --> Config Class Initialized
INFO - 2018-10-22 14:21:42 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:21:42 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:21:42 --> Utf8 Class Initialized
INFO - 2018-10-22 14:21:42 --> URI Class Initialized
INFO - 2018-10-22 14:21:42 --> Router Class Initialized
INFO - 2018-10-22 14:21:42 --> Output Class Initialized
INFO - 2018-10-22 14:21:42 --> Security Class Initialized
DEBUG - 2018-10-22 14:21:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:21:42 --> CSRF cookie sent
INFO - 2018-10-22 14:21:43 --> CSRF token verified
INFO - 2018-10-22 14:21:43 --> Input Class Initialized
INFO - 2018-10-22 14:21:43 --> Language Class Initialized
INFO - 2018-10-22 14:21:43 --> Loader Class Initialized
INFO - 2018-10-22 14:21:43 --> Helper loaded: url_helper
INFO - 2018-10-22 14:21:43 --> Helper loaded: form_helper
INFO - 2018-10-22 14:21:43 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:21:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:21:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:21:43 --> User Agent Class Initialized
INFO - 2018-10-22 14:21:43 --> Controller Class Initialized
INFO - 2018-10-22 14:21:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:21:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:21:43 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:21:43 --> Pixel_Model class loaded
INFO - 2018-10-22 14:21:43 --> Database Driver Class Initialized
INFO - 2018-10-22 14:21:43 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:21:43 --> Form Validation Class Initialized
INFO - 2018-10-22 14:21:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 14:21:43 --> Database Driver Class Initialized
INFO - 2018-10-22 14:21:43 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:21:43 --> Config Class Initialized
INFO - 2018-10-22 14:21:43 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:21:43 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:21:43 --> Utf8 Class Initialized
INFO - 2018-10-22 14:21:43 --> URI Class Initialized
INFO - 2018-10-22 14:21:43 --> Router Class Initialized
INFO - 2018-10-22 14:21:43 --> Output Class Initialized
INFO - 2018-10-22 14:21:43 --> Security Class Initialized
DEBUG - 2018-10-22 14:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:21:43 --> CSRF cookie sent
INFO - 2018-10-22 14:21:43 --> Input Class Initialized
INFO - 2018-10-22 14:21:43 --> Language Class Initialized
INFO - 2018-10-22 14:21:43 --> Loader Class Initialized
INFO - 2018-10-22 14:21:43 --> Helper loaded: url_helper
INFO - 2018-10-22 14:21:43 --> Helper loaded: form_helper
INFO - 2018-10-22 14:21:43 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:21:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:21:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:21:44 --> User Agent Class Initialized
INFO - 2018-10-22 14:21:44 --> Controller Class Initialized
INFO - 2018-10-22 14:21:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:21:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:21:44 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:21:44 --> Pixel_Model class loaded
INFO - 2018-10-22 14:21:44 --> Database Driver Class Initialized
INFO - 2018-10-22 14:21:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:21:44 --> Database Driver Class Initialized
INFO - 2018-10-22 14:21:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:21:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 14:21:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 14:21:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 14:21:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 14:21:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 14:21:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 14:21:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-22 14:21:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 14:21:44 --> Final output sent to browser
DEBUG - 2018-10-22 14:21:44 --> Total execution time: 0.7866
INFO - 2018-10-22 14:21:47 --> Config Class Initialized
INFO - 2018-10-22 14:21:47 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:21:47 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:21:47 --> Utf8 Class Initialized
INFO - 2018-10-22 14:21:47 --> URI Class Initialized
INFO - 2018-10-22 14:21:47 --> Router Class Initialized
INFO - 2018-10-22 14:21:47 --> Output Class Initialized
INFO - 2018-10-22 14:21:47 --> Security Class Initialized
DEBUG - 2018-10-22 14:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:21:47 --> CSRF cookie sent
INFO - 2018-10-22 14:21:47 --> CSRF token verified
INFO - 2018-10-22 14:21:47 --> Input Class Initialized
INFO - 2018-10-22 14:21:47 --> Language Class Initialized
INFO - 2018-10-22 14:21:47 --> Loader Class Initialized
INFO - 2018-10-22 14:21:47 --> Helper loaded: url_helper
INFO - 2018-10-22 14:21:47 --> Helper loaded: form_helper
INFO - 2018-10-22 14:21:47 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:21:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:21:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:21:47 --> User Agent Class Initialized
INFO - 2018-10-22 14:21:47 --> Controller Class Initialized
INFO - 2018-10-22 14:21:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:21:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:21:47 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:21:47 --> Pixel_Model class loaded
INFO - 2018-10-22 14:21:47 --> Database Driver Class Initialized
INFO - 2018-10-22 14:21:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:21:47 --> Form Validation Class Initialized
INFO - 2018-10-22 14:21:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 14:21:47 --> Database Driver Class Initialized
INFO - 2018-10-22 14:21:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:21:48 --> Config Class Initialized
INFO - 2018-10-22 14:21:48 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:21:48 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:21:48 --> Utf8 Class Initialized
INFO - 2018-10-22 14:21:48 --> URI Class Initialized
INFO - 2018-10-22 14:21:48 --> Router Class Initialized
INFO - 2018-10-22 14:21:48 --> Output Class Initialized
INFO - 2018-10-22 14:21:48 --> Security Class Initialized
DEBUG - 2018-10-22 14:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:21:48 --> CSRF cookie sent
INFO - 2018-10-22 14:21:48 --> Input Class Initialized
INFO - 2018-10-22 14:21:48 --> Language Class Initialized
INFO - 2018-10-22 14:21:48 --> Loader Class Initialized
INFO - 2018-10-22 14:21:48 --> Helper loaded: url_helper
INFO - 2018-10-22 14:21:48 --> Helper loaded: form_helper
INFO - 2018-10-22 14:21:48 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:21:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:21:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:21:48 --> User Agent Class Initialized
INFO - 2018-10-22 14:21:48 --> Controller Class Initialized
INFO - 2018-10-22 14:21:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:21:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:21:48 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:21:48 --> Pixel_Model class loaded
INFO - 2018-10-22 14:21:48 --> Database Driver Class Initialized
INFO - 2018-10-22 14:21:48 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:21:48 --> Database Driver Class Initialized
INFO - 2018-10-22 14:21:48 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:21:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 14:21:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 14:21:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 14:21:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 14:21:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 14:21:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 14:21:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/your_job.php
INFO - 2018-10-22 14:21:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 14:21:48 --> Final output sent to browser
DEBUG - 2018-10-22 14:21:48 --> Total execution time: 0.7518
INFO - 2018-10-22 14:21:51 --> Config Class Initialized
INFO - 2018-10-22 14:21:51 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:21:51 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:21:51 --> Utf8 Class Initialized
INFO - 2018-10-22 14:21:51 --> URI Class Initialized
INFO - 2018-10-22 14:21:51 --> Router Class Initialized
INFO - 2018-10-22 14:21:51 --> Output Class Initialized
INFO - 2018-10-22 14:21:51 --> Security Class Initialized
DEBUG - 2018-10-22 14:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:21:51 --> CSRF cookie sent
INFO - 2018-10-22 14:21:51 --> CSRF token verified
INFO - 2018-10-22 14:21:51 --> Input Class Initialized
INFO - 2018-10-22 14:21:51 --> Language Class Initialized
INFO - 2018-10-22 14:21:51 --> Loader Class Initialized
INFO - 2018-10-22 14:21:51 --> Helper loaded: url_helper
INFO - 2018-10-22 14:21:51 --> Helper loaded: form_helper
INFO - 2018-10-22 14:21:51 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:21:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:21:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:21:51 --> User Agent Class Initialized
INFO - 2018-10-22 14:21:51 --> Controller Class Initialized
INFO - 2018-10-22 14:21:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:21:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:21:51 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:21:51 --> Pixel_Model class loaded
INFO - 2018-10-22 14:21:51 --> Database Driver Class Initialized
INFO - 2018-10-22 14:21:51 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:21:51 --> Form Validation Class Initialized
INFO - 2018-10-22 14:21:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 14:21:51 --> Database Driver Class Initialized
INFO - 2018-10-22 14:21:51 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:21:51 --> Config Class Initialized
INFO - 2018-10-22 14:21:52 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:21:52 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:21:52 --> Utf8 Class Initialized
INFO - 2018-10-22 14:21:52 --> URI Class Initialized
INFO - 2018-10-22 14:21:52 --> Router Class Initialized
INFO - 2018-10-22 14:21:52 --> Output Class Initialized
INFO - 2018-10-22 14:21:52 --> Security Class Initialized
DEBUG - 2018-10-22 14:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:21:52 --> CSRF cookie sent
INFO - 2018-10-22 14:21:52 --> Input Class Initialized
INFO - 2018-10-22 14:21:52 --> Language Class Initialized
INFO - 2018-10-22 14:21:52 --> Loader Class Initialized
INFO - 2018-10-22 14:21:52 --> Helper loaded: url_helper
INFO - 2018-10-22 14:21:52 --> Helper loaded: form_helper
INFO - 2018-10-22 14:21:52 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:21:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:21:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:21:52 --> User Agent Class Initialized
INFO - 2018-10-22 14:21:52 --> Controller Class Initialized
INFO - 2018-10-22 14:21:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:21:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:21:52 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:21:52 --> Pixel_Model class loaded
INFO - 2018-10-22 14:21:52 --> Database Driver Class Initialized
INFO - 2018-10-22 14:21:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:21:52 --> Database Driver Class Initialized
INFO - 2018-10-22 14:21:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:21:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 14:21:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 14:21:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner.php
INFO - 2018-10-22 14:21:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 14:21:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 14:21:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 14:21:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 14:21:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/relation_ship_status.php
INFO - 2018-10-22 14:21:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 14:21:52 --> Final output sent to browser
DEBUG - 2018-10-22 14:21:52 --> Total execution time: 0.7625
INFO - 2018-10-22 14:21:56 --> Config Class Initialized
INFO - 2018-10-22 14:21:56 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:21:56 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:21:56 --> Utf8 Class Initialized
INFO - 2018-10-22 14:21:56 --> URI Class Initialized
INFO - 2018-10-22 14:21:56 --> Router Class Initialized
INFO - 2018-10-22 14:21:56 --> Output Class Initialized
INFO - 2018-10-22 14:21:56 --> Security Class Initialized
DEBUG - 2018-10-22 14:21:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:21:56 --> CSRF cookie sent
INFO - 2018-10-22 14:21:56 --> CSRF token verified
INFO - 2018-10-22 14:21:56 --> Input Class Initialized
INFO - 2018-10-22 14:21:56 --> Language Class Initialized
INFO - 2018-10-22 14:21:56 --> Loader Class Initialized
INFO - 2018-10-22 14:21:56 --> Helper loaded: url_helper
INFO - 2018-10-22 14:21:56 --> Helper loaded: form_helper
INFO - 2018-10-22 14:21:56 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:21:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:21:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:21:56 --> User Agent Class Initialized
INFO - 2018-10-22 14:21:56 --> Controller Class Initialized
INFO - 2018-10-22 14:21:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:21:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:21:56 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:21:56 --> Pixel_Model class loaded
INFO - 2018-10-22 14:21:56 --> Database Driver Class Initialized
INFO - 2018-10-22 14:21:56 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:21:56 --> Form Validation Class Initialized
INFO - 2018-10-22 14:21:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 14:21:56 --> Database Driver Class Initialized
INFO - 2018-10-22 14:21:56 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:21:56 --> Config Class Initialized
INFO - 2018-10-22 14:21:56 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:21:56 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:21:56 --> Utf8 Class Initialized
INFO - 2018-10-22 14:21:56 --> URI Class Initialized
INFO - 2018-10-22 14:21:56 --> Router Class Initialized
INFO - 2018-10-22 14:21:56 --> Output Class Initialized
INFO - 2018-10-22 14:21:56 --> Security Class Initialized
DEBUG - 2018-10-22 14:21:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:21:56 --> CSRF cookie sent
INFO - 2018-10-22 14:21:56 --> Input Class Initialized
INFO - 2018-10-22 14:21:56 --> Language Class Initialized
INFO - 2018-10-22 14:21:57 --> Loader Class Initialized
INFO - 2018-10-22 14:21:57 --> Helper loaded: url_helper
INFO - 2018-10-22 14:21:57 --> Helper loaded: form_helper
INFO - 2018-10-22 14:21:57 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:21:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:21:57 --> User Agent Class Initialized
INFO - 2018-10-22 14:21:57 --> Controller Class Initialized
INFO - 2018-10-22 14:21:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:21:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:21:57 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:21:57 --> Pixel_Model class loaded
INFO - 2018-10-22 14:21:57 --> Database Driver Class Initialized
INFO - 2018-10-22 14:21:57 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:21:57 --> Database Driver Class Initialized
INFO - 2018-10-22 14:21:57 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:21:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 14:21:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 14:21:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 14:21:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 14:21:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 14:21:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 14:21:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/income.php
INFO - 2018-10-22 14:21:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 14:21:57 --> Final output sent to browser
DEBUG - 2018-10-22 14:21:57 --> Total execution time: 0.7529
INFO - 2018-10-22 14:22:05 --> Config Class Initialized
INFO - 2018-10-22 14:22:05 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:22:05 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:22:05 --> Utf8 Class Initialized
INFO - 2018-10-22 14:22:05 --> URI Class Initialized
INFO - 2018-10-22 14:22:05 --> Router Class Initialized
INFO - 2018-10-22 14:22:05 --> Output Class Initialized
INFO - 2018-10-22 14:22:05 --> Security Class Initialized
DEBUG - 2018-10-22 14:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:22:05 --> CSRF cookie sent
INFO - 2018-10-22 14:22:05 --> CSRF token verified
INFO - 2018-10-22 14:22:05 --> Input Class Initialized
INFO - 2018-10-22 14:22:05 --> Language Class Initialized
INFO - 2018-10-22 14:22:05 --> Loader Class Initialized
INFO - 2018-10-22 14:22:06 --> Helper loaded: url_helper
INFO - 2018-10-22 14:22:06 --> Helper loaded: form_helper
INFO - 2018-10-22 14:22:06 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:22:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:22:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:22:06 --> User Agent Class Initialized
INFO - 2018-10-22 14:22:06 --> Controller Class Initialized
INFO - 2018-10-22 14:22:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:22:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:22:06 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:22:06 --> Pixel_Model class loaded
INFO - 2018-10-22 14:22:06 --> Database Driver Class Initialized
INFO - 2018-10-22 14:22:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:22:06 --> Form Validation Class Initialized
INFO - 2018-10-22 14:22:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 14:22:06 --> Database Driver Class Initialized
INFO - 2018-10-22 14:22:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:22:06 --> Config Class Initialized
INFO - 2018-10-22 14:22:06 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:22:06 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:22:06 --> Utf8 Class Initialized
INFO - 2018-10-22 14:22:06 --> URI Class Initialized
INFO - 2018-10-22 14:22:06 --> Router Class Initialized
INFO - 2018-10-22 14:22:06 --> Output Class Initialized
INFO - 2018-10-22 14:22:06 --> Security Class Initialized
DEBUG - 2018-10-22 14:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:22:06 --> CSRF cookie sent
INFO - 2018-10-22 14:22:06 --> Input Class Initialized
INFO - 2018-10-22 14:22:06 --> Language Class Initialized
INFO - 2018-10-22 14:22:06 --> Loader Class Initialized
INFO - 2018-10-22 14:22:06 --> Helper loaded: url_helper
INFO - 2018-10-22 14:22:06 --> Helper loaded: form_helper
INFO - 2018-10-22 14:22:06 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:22:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:22:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:22:06 --> User Agent Class Initialized
INFO - 2018-10-22 14:22:06 --> Controller Class Initialized
INFO - 2018-10-22 14:22:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:22:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:22:06 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:22:06 --> Pixel_Model class loaded
INFO - 2018-10-22 14:22:06 --> Database Driver Class Initialized
INFO - 2018-10-22 14:22:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:22:06 --> Database Driver Class Initialized
INFO - 2018-10-22 14:22:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:22:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 14:22:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 14:22:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 14:22:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 14:22:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 14:22:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 14:22:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/pension.php
INFO - 2018-10-22 14:22:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 14:22:07 --> Final output sent to browser
DEBUG - 2018-10-22 14:22:07 --> Total execution time: 0.7896
INFO - 2018-10-22 14:22:18 --> Config Class Initialized
INFO - 2018-10-22 14:22:18 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:22:18 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:22:18 --> Utf8 Class Initialized
INFO - 2018-10-22 14:22:19 --> URI Class Initialized
INFO - 2018-10-22 14:22:19 --> Router Class Initialized
INFO - 2018-10-22 14:22:19 --> Output Class Initialized
INFO - 2018-10-22 14:22:19 --> Security Class Initialized
DEBUG - 2018-10-22 14:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:22:19 --> CSRF cookie sent
INFO - 2018-10-22 14:22:19 --> CSRF token verified
INFO - 2018-10-22 14:22:19 --> Input Class Initialized
INFO - 2018-10-22 14:22:19 --> Language Class Initialized
INFO - 2018-10-22 14:22:19 --> Loader Class Initialized
INFO - 2018-10-22 14:22:19 --> Helper loaded: url_helper
INFO - 2018-10-22 14:22:19 --> Helper loaded: form_helper
INFO - 2018-10-22 14:22:19 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:22:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:22:19 --> User Agent Class Initialized
INFO - 2018-10-22 14:22:19 --> Controller Class Initialized
INFO - 2018-10-22 14:22:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:22:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:22:19 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:22:19 --> Pixel_Model class loaded
INFO - 2018-10-22 14:22:19 --> Database Driver Class Initialized
INFO - 2018-10-22 14:22:19 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:22:19 --> Form Validation Class Initialized
INFO - 2018-10-22 14:22:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 14:22:19 --> Database Driver Class Initialized
INFO - 2018-10-22 14:22:19 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:22:19 --> Config Class Initialized
INFO - 2018-10-22 14:22:19 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:22:19 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:22:19 --> Utf8 Class Initialized
INFO - 2018-10-22 14:22:19 --> URI Class Initialized
INFO - 2018-10-22 14:22:19 --> Router Class Initialized
INFO - 2018-10-22 14:22:19 --> Output Class Initialized
INFO - 2018-10-22 14:22:19 --> Security Class Initialized
DEBUG - 2018-10-22 14:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:22:19 --> CSRF cookie sent
INFO - 2018-10-22 14:22:19 --> Input Class Initialized
INFO - 2018-10-22 14:22:19 --> Language Class Initialized
INFO - 2018-10-22 14:22:19 --> Loader Class Initialized
INFO - 2018-10-22 14:22:19 --> Helper loaded: url_helper
INFO - 2018-10-22 14:22:19 --> Helper loaded: form_helper
INFO - 2018-10-22 14:22:19 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:22:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:22:20 --> User Agent Class Initialized
INFO - 2018-10-22 14:22:20 --> Controller Class Initialized
INFO - 2018-10-22 14:22:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:22:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:22:20 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:22:20 --> Pixel_Model class loaded
INFO - 2018-10-22 14:22:20 --> Database Driver Class Initialized
INFO - 2018-10-22 14:22:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:22:20 --> Database Driver Class Initialized
INFO - 2018-10-22 14:22:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:22:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 14:22:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 14:22:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 14:22:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 14:22:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 14:22:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 14:22:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/home_title.php
INFO - 2018-10-22 14:22:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 14:22:20 --> Final output sent to browser
DEBUG - 2018-10-22 14:22:20 --> Total execution time: 0.7967
INFO - 2018-10-22 14:22:25 --> Config Class Initialized
INFO - 2018-10-22 14:22:25 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:22:25 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:22:25 --> Utf8 Class Initialized
INFO - 2018-10-22 14:22:26 --> URI Class Initialized
INFO - 2018-10-22 14:22:26 --> Router Class Initialized
INFO - 2018-10-22 14:22:26 --> Output Class Initialized
INFO - 2018-10-22 14:22:26 --> Security Class Initialized
DEBUG - 2018-10-22 14:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:22:26 --> CSRF cookie sent
INFO - 2018-10-22 14:22:26 --> CSRF token verified
INFO - 2018-10-22 14:22:26 --> Input Class Initialized
INFO - 2018-10-22 14:22:26 --> Language Class Initialized
INFO - 2018-10-22 14:22:26 --> Loader Class Initialized
INFO - 2018-10-22 14:22:26 --> Helper loaded: url_helper
INFO - 2018-10-22 14:22:26 --> Helper loaded: form_helper
INFO - 2018-10-22 14:22:26 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:22:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:22:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:22:26 --> User Agent Class Initialized
INFO - 2018-10-22 14:22:26 --> Controller Class Initialized
INFO - 2018-10-22 14:22:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:22:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:22:26 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:22:26 --> Pixel_Model class loaded
INFO - 2018-10-22 14:22:26 --> Database Driver Class Initialized
INFO - 2018-10-22 14:22:26 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:22:26 --> Form Validation Class Initialized
INFO - 2018-10-22 14:22:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 14:22:26 --> Database Driver Class Initialized
INFO - 2018-10-22 14:22:26 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:22:26 --> Config Class Initialized
INFO - 2018-10-22 14:22:26 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:22:26 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:22:26 --> Utf8 Class Initialized
INFO - 2018-10-22 14:22:26 --> URI Class Initialized
INFO - 2018-10-22 14:22:26 --> Router Class Initialized
INFO - 2018-10-22 14:22:26 --> Output Class Initialized
INFO - 2018-10-22 14:22:26 --> Security Class Initialized
DEBUG - 2018-10-22 14:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:22:26 --> CSRF cookie sent
INFO - 2018-10-22 14:22:26 --> Input Class Initialized
INFO - 2018-10-22 14:22:26 --> Language Class Initialized
INFO - 2018-10-22 14:22:26 --> Loader Class Initialized
INFO - 2018-10-22 14:22:26 --> Helper loaded: url_helper
INFO - 2018-10-22 14:22:26 --> Helper loaded: form_helper
INFO - 2018-10-22 14:22:26 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:22:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:22:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:22:26 --> User Agent Class Initialized
INFO - 2018-10-22 14:22:26 --> Controller Class Initialized
INFO - 2018-10-22 14:22:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:22:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:22:27 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:22:27 --> Pixel_Model class loaded
INFO - 2018-10-22 14:22:27 --> Database Driver Class Initialized
INFO - 2018-10-22 14:22:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:22:27 --> Database Driver Class Initialized
INFO - 2018-10-22 14:22:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:22:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 14:22:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 14:22:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 14:22:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 14:22:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 14:22:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 14:22:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/financial.php
INFO - 2018-10-22 14:22:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 14:22:27 --> Final output sent to browser
DEBUG - 2018-10-22 14:22:27 --> Total execution time: 0.8553
INFO - 2018-10-22 14:22:33 --> Config Class Initialized
INFO - 2018-10-22 14:22:33 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:22:33 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:22:33 --> Utf8 Class Initialized
INFO - 2018-10-22 14:22:33 --> URI Class Initialized
INFO - 2018-10-22 14:22:33 --> Router Class Initialized
INFO - 2018-10-22 14:22:33 --> Output Class Initialized
INFO - 2018-10-22 14:22:33 --> Security Class Initialized
DEBUG - 2018-10-22 14:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:22:33 --> CSRF cookie sent
INFO - 2018-10-22 14:22:33 --> CSRF token verified
INFO - 2018-10-22 14:22:33 --> Input Class Initialized
INFO - 2018-10-22 14:22:33 --> Language Class Initialized
INFO - 2018-10-22 14:22:33 --> Loader Class Initialized
INFO - 2018-10-22 14:22:33 --> Helper loaded: url_helper
INFO - 2018-10-22 14:22:33 --> Helper loaded: form_helper
INFO - 2018-10-22 14:22:33 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:22:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:22:34 --> User Agent Class Initialized
INFO - 2018-10-22 14:22:34 --> Controller Class Initialized
INFO - 2018-10-22 14:22:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:22:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:22:34 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:22:34 --> Pixel_Model class loaded
INFO - 2018-10-22 14:22:34 --> Database Driver Class Initialized
INFO - 2018-10-22 14:22:34 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:22:34 --> Form Validation Class Initialized
INFO - 2018-10-22 14:22:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 14:22:34 --> Database Driver Class Initialized
INFO - 2018-10-22 14:22:34 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:22:34 --> Config Class Initialized
INFO - 2018-10-22 14:22:34 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:22:34 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:22:34 --> Utf8 Class Initialized
INFO - 2018-10-22 14:22:34 --> URI Class Initialized
INFO - 2018-10-22 14:22:34 --> Router Class Initialized
INFO - 2018-10-22 14:22:34 --> Output Class Initialized
INFO - 2018-10-22 14:22:34 --> Security Class Initialized
DEBUG - 2018-10-22 14:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:22:34 --> CSRF cookie sent
INFO - 2018-10-22 14:22:34 --> Input Class Initialized
INFO - 2018-10-22 14:22:34 --> Language Class Initialized
INFO - 2018-10-22 14:22:34 --> Loader Class Initialized
INFO - 2018-10-22 14:22:34 --> Helper loaded: url_helper
INFO - 2018-10-22 14:22:34 --> Helper loaded: form_helper
INFO - 2018-10-22 14:22:34 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:22:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:22:34 --> User Agent Class Initialized
INFO - 2018-10-22 14:22:34 --> Controller Class Initialized
INFO - 2018-10-22 14:22:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:22:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:22:34 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:22:34 --> Pixel_Model class loaded
INFO - 2018-10-22 14:22:34 --> Database Driver Class Initialized
INFO - 2018-10-22 14:22:34 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:22:34 --> Database Driver Class Initialized
INFO - 2018-10-22 14:22:34 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:22:34 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 14:22:34 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 14:22:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 14:22:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 14:22:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 14:22:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 14:22:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/spouse_info.php
INFO - 2018-10-22 14:22:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 14:22:35 --> Final output sent to browser
DEBUG - 2018-10-22 14:22:35 --> Total execution time: 0.8250
INFO - 2018-10-22 14:22:40 --> Config Class Initialized
INFO - 2018-10-22 14:22:40 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:22:40 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:22:40 --> Utf8 Class Initialized
INFO - 2018-10-22 14:22:40 --> URI Class Initialized
INFO - 2018-10-22 14:22:40 --> Router Class Initialized
INFO - 2018-10-22 14:22:40 --> Output Class Initialized
INFO - 2018-10-22 14:22:40 --> Security Class Initialized
DEBUG - 2018-10-22 14:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:22:40 --> CSRF cookie sent
INFO - 2018-10-22 14:22:40 --> CSRF token verified
INFO - 2018-10-22 14:22:40 --> Input Class Initialized
INFO - 2018-10-22 14:22:40 --> Language Class Initialized
INFO - 2018-10-22 14:22:40 --> Loader Class Initialized
INFO - 2018-10-22 14:22:40 --> Helper loaded: url_helper
INFO - 2018-10-22 14:22:40 --> Helper loaded: form_helper
INFO - 2018-10-22 14:22:40 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:22:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:22:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:22:40 --> User Agent Class Initialized
INFO - 2018-10-22 14:22:40 --> Controller Class Initialized
INFO - 2018-10-22 14:22:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:22:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:22:40 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:22:40 --> Pixel_Model class loaded
INFO - 2018-10-22 14:22:40 --> Database Driver Class Initialized
INFO - 2018-10-22 14:22:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:22:40 --> Form Validation Class Initialized
INFO - 2018-10-22 14:22:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 14:22:40 --> Database Driver Class Initialized
INFO - 2018-10-22 14:22:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:22:41 --> Config Class Initialized
INFO - 2018-10-22 14:22:41 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:22:41 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:22:41 --> Utf8 Class Initialized
INFO - 2018-10-22 14:22:41 --> URI Class Initialized
INFO - 2018-10-22 14:22:41 --> Router Class Initialized
INFO - 2018-10-22 14:22:41 --> Output Class Initialized
INFO - 2018-10-22 14:22:41 --> Security Class Initialized
DEBUG - 2018-10-22 14:22:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:22:41 --> CSRF cookie sent
INFO - 2018-10-22 14:22:41 --> Input Class Initialized
INFO - 2018-10-22 14:22:41 --> Language Class Initialized
INFO - 2018-10-22 14:22:41 --> Loader Class Initialized
INFO - 2018-10-22 14:22:41 --> Helper loaded: url_helper
INFO - 2018-10-22 14:22:41 --> Helper loaded: form_helper
INFO - 2018-10-22 14:22:41 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:22:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:22:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:22:41 --> User Agent Class Initialized
INFO - 2018-10-22 14:22:41 --> Controller Class Initialized
INFO - 2018-10-22 14:22:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:22:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:22:41 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:22:41 --> Pixel_Model class loaded
INFO - 2018-10-22 14:22:41 --> Database Driver Class Initialized
INFO - 2018-10-22 14:22:41 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:22:41 --> Database Driver Class Initialized
INFO - 2018-10-22 14:22:41 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:22:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 14:22:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 14:22:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 14:22:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 14:22:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 14:22:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 14:22:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/spouse_job.php
INFO - 2018-10-22 14:22:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 14:22:41 --> Final output sent to browser
DEBUG - 2018-10-22 14:22:41 --> Total execution time: 0.8295
INFO - 2018-10-22 14:22:55 --> Config Class Initialized
INFO - 2018-10-22 14:22:55 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:22:55 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:22:55 --> Utf8 Class Initialized
INFO - 2018-10-22 14:22:55 --> URI Class Initialized
INFO - 2018-10-22 14:22:55 --> Router Class Initialized
INFO - 2018-10-22 14:22:55 --> Output Class Initialized
INFO - 2018-10-22 14:22:55 --> Security Class Initialized
DEBUG - 2018-10-22 14:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:22:55 --> CSRF cookie sent
INFO - 2018-10-22 14:22:55 --> CSRF token verified
INFO - 2018-10-22 14:22:56 --> Input Class Initialized
INFO - 2018-10-22 14:22:56 --> Language Class Initialized
INFO - 2018-10-22 14:22:56 --> Loader Class Initialized
INFO - 2018-10-22 14:22:56 --> Helper loaded: url_helper
INFO - 2018-10-22 14:22:56 --> Helper loaded: form_helper
INFO - 2018-10-22 14:22:56 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:22:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:22:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:22:56 --> User Agent Class Initialized
INFO - 2018-10-22 14:22:56 --> Controller Class Initialized
INFO - 2018-10-22 14:22:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:22:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:22:56 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:22:56 --> Pixel_Model class loaded
INFO - 2018-10-22 14:22:56 --> Database Driver Class Initialized
INFO - 2018-10-22 14:22:56 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:22:56 --> Form Validation Class Initialized
INFO - 2018-10-22 14:22:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 14:22:56 --> Database Driver Class Initialized
INFO - 2018-10-22 14:22:56 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:22:56 --> Config Class Initialized
INFO - 2018-10-22 14:22:56 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:22:56 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:22:56 --> Utf8 Class Initialized
INFO - 2018-10-22 14:22:56 --> URI Class Initialized
INFO - 2018-10-22 14:22:56 --> Router Class Initialized
INFO - 2018-10-22 14:22:56 --> Output Class Initialized
INFO - 2018-10-22 14:22:56 --> Security Class Initialized
DEBUG - 2018-10-22 14:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:22:56 --> CSRF cookie sent
INFO - 2018-10-22 14:22:56 --> Input Class Initialized
INFO - 2018-10-22 14:22:56 --> Language Class Initialized
INFO - 2018-10-22 14:22:56 --> Loader Class Initialized
INFO - 2018-10-22 14:22:56 --> Helper loaded: url_helper
INFO - 2018-10-22 14:22:56 --> Helper loaded: form_helper
INFO - 2018-10-22 14:22:56 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:22:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:22:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:22:56 --> User Agent Class Initialized
INFO - 2018-10-22 14:22:56 --> Controller Class Initialized
INFO - 2018-10-22 14:22:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:22:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:22:56 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:22:56 --> Pixel_Model class loaded
INFO - 2018-10-22 14:22:56 --> Database Driver Class Initialized
INFO - 2018-10-22 14:22:57 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:22:57 --> Database Driver Class Initialized
INFO - 2018-10-22 14:22:57 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:22:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 14:22:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 14:22:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 14:22:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 14:22:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 14:22:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 14:22:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/affectionate_salutation.php
INFO - 2018-10-22 14:22:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 14:22:57 --> Final output sent to browser
DEBUG - 2018-10-22 14:22:57 --> Total execution time: 0.7874
INFO - 2018-10-22 14:23:58 --> Config Class Initialized
INFO - 2018-10-22 14:23:58 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:23:58 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:23:59 --> Utf8 Class Initialized
INFO - 2018-10-22 14:23:59 --> URI Class Initialized
INFO - 2018-10-22 14:23:59 --> Router Class Initialized
INFO - 2018-10-22 14:23:59 --> Output Class Initialized
INFO - 2018-10-22 14:23:59 --> Security Class Initialized
DEBUG - 2018-10-22 14:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:23:59 --> CSRF cookie sent
INFO - 2018-10-22 14:23:59 --> Input Class Initialized
INFO - 2018-10-22 14:23:59 --> Language Class Initialized
INFO - 2018-10-22 14:23:59 --> Loader Class Initialized
INFO - 2018-10-22 14:23:59 --> Helper loaded: url_helper
INFO - 2018-10-22 14:23:59 --> Helper loaded: form_helper
INFO - 2018-10-22 14:23:59 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:23:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:23:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:23:59 --> User Agent Class Initialized
INFO - 2018-10-22 14:23:59 --> Controller Class Initialized
INFO - 2018-10-22 14:23:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:23:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:23:59 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:23:59 --> Pixel_Model class loaded
INFO - 2018-10-22 14:23:59 --> Database Driver Class Initialized
INFO - 2018-10-22 14:23:59 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:23:59 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 14:23:59 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 14:24:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 14:24:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 14:24:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 14:24:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 14:24:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-22 14:24:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 14:24:00 --> Final output sent to browser
DEBUG - 2018-10-22 14:24:00 --> Total execution time: 1.3286
INFO - 2018-10-22 14:24:02 --> Config Class Initialized
INFO - 2018-10-22 14:24:02 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:24:02 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:24:02 --> Utf8 Class Initialized
INFO - 2018-10-22 14:24:02 --> URI Class Initialized
INFO - 2018-10-22 14:24:02 --> Router Class Initialized
INFO - 2018-10-22 14:24:02 --> Output Class Initialized
INFO - 2018-10-22 14:24:03 --> Security Class Initialized
DEBUG - 2018-10-22 14:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:24:03 --> CSRF cookie sent
INFO - 2018-10-22 14:24:03 --> CSRF token verified
INFO - 2018-10-22 14:24:03 --> Input Class Initialized
INFO - 2018-10-22 14:24:03 --> Language Class Initialized
INFO - 2018-10-22 14:24:03 --> Loader Class Initialized
INFO - 2018-10-22 14:24:03 --> Helper loaded: url_helper
INFO - 2018-10-22 14:24:03 --> Helper loaded: form_helper
INFO - 2018-10-22 14:24:03 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:24:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:24:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:24:03 --> User Agent Class Initialized
INFO - 2018-10-22 14:24:03 --> Controller Class Initialized
INFO - 2018-10-22 14:24:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:24:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:24:03 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:24:03 --> Pixel_Model class loaded
INFO - 2018-10-22 14:24:03 --> Database Driver Class Initialized
INFO - 2018-10-22 14:24:03 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:24:03 --> Form Validation Class Initialized
INFO - 2018-10-22 14:24:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 14:24:03 --> Database Driver Class Initialized
INFO - 2018-10-22 14:24:03 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:24:03 --> Config Class Initialized
INFO - 2018-10-22 14:24:03 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:24:03 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:24:03 --> Utf8 Class Initialized
INFO - 2018-10-22 14:24:03 --> URI Class Initialized
INFO - 2018-10-22 14:24:03 --> Router Class Initialized
INFO - 2018-10-22 14:24:03 --> Output Class Initialized
INFO - 2018-10-22 14:24:03 --> Security Class Initialized
DEBUG - 2018-10-22 14:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:24:03 --> CSRF cookie sent
INFO - 2018-10-22 14:24:03 --> Input Class Initialized
INFO - 2018-10-22 14:24:03 --> Language Class Initialized
INFO - 2018-10-22 14:24:03 --> Loader Class Initialized
INFO - 2018-10-22 14:24:03 --> Helper loaded: url_helper
INFO - 2018-10-22 14:24:03 --> Helper loaded: form_helper
INFO - 2018-10-22 14:24:03 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:24:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:24:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:24:04 --> User Agent Class Initialized
INFO - 2018-10-22 14:24:04 --> Controller Class Initialized
INFO - 2018-10-22 14:24:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:24:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:24:04 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:24:04 --> Pixel_Model class loaded
INFO - 2018-10-22 14:24:04 --> Database Driver Class Initialized
INFO - 2018-10-22 14:24:04 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:24:04 --> Database Driver Class Initialized
INFO - 2018-10-22 14:24:04 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:24:04 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 14:24:04 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 14:24:04 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 14:24:04 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 14:24:04 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 14:24:04 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 14:24:04 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-22 14:24:04 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 14:24:04 --> Final output sent to browser
DEBUG - 2018-10-22 14:24:04 --> Total execution time: 0.8247
INFO - 2018-10-22 14:24:07 --> Config Class Initialized
INFO - 2018-10-22 14:24:07 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:24:07 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:24:07 --> Utf8 Class Initialized
INFO - 2018-10-22 14:24:07 --> URI Class Initialized
INFO - 2018-10-22 14:24:07 --> Router Class Initialized
INFO - 2018-10-22 14:24:07 --> Output Class Initialized
INFO - 2018-10-22 14:24:07 --> Security Class Initialized
DEBUG - 2018-10-22 14:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:24:07 --> CSRF cookie sent
INFO - 2018-10-22 14:24:07 --> CSRF token verified
INFO - 2018-10-22 14:24:07 --> Input Class Initialized
INFO - 2018-10-22 14:24:07 --> Language Class Initialized
INFO - 2018-10-22 14:24:07 --> Loader Class Initialized
INFO - 2018-10-22 14:24:07 --> Helper loaded: url_helper
INFO - 2018-10-22 14:24:07 --> Helper loaded: form_helper
INFO - 2018-10-22 14:24:07 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:24:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:24:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:24:07 --> User Agent Class Initialized
INFO - 2018-10-22 14:24:07 --> Controller Class Initialized
INFO - 2018-10-22 14:24:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:24:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:24:07 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:24:07 --> Pixel_Model class loaded
INFO - 2018-10-22 14:24:07 --> Database Driver Class Initialized
INFO - 2018-10-22 14:24:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:24:08 --> Form Validation Class Initialized
INFO - 2018-10-22 14:24:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 14:24:08 --> Database Driver Class Initialized
INFO - 2018-10-22 14:24:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:24:08 --> Config Class Initialized
INFO - 2018-10-22 14:24:08 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:24:08 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:24:08 --> Utf8 Class Initialized
INFO - 2018-10-22 14:24:08 --> URI Class Initialized
INFO - 2018-10-22 14:24:08 --> Router Class Initialized
INFO - 2018-10-22 14:24:08 --> Output Class Initialized
INFO - 2018-10-22 14:24:08 --> Security Class Initialized
DEBUG - 2018-10-22 14:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:24:08 --> CSRF cookie sent
INFO - 2018-10-22 14:24:08 --> Input Class Initialized
INFO - 2018-10-22 14:24:08 --> Language Class Initialized
INFO - 2018-10-22 14:24:08 --> Loader Class Initialized
INFO - 2018-10-22 14:24:08 --> Helper loaded: url_helper
INFO - 2018-10-22 14:24:08 --> Helper loaded: form_helper
INFO - 2018-10-22 14:24:08 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:24:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:24:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:24:08 --> User Agent Class Initialized
INFO - 2018-10-22 14:24:08 --> Controller Class Initialized
INFO - 2018-10-22 14:24:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:24:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:24:08 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:24:08 --> Pixel_Model class loaded
INFO - 2018-10-22 14:24:08 --> Database Driver Class Initialized
INFO - 2018-10-22 14:24:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:24:08 --> Database Driver Class Initialized
INFO - 2018-10-22 14:24:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:24:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 14:24:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 14:24:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 14:24:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 14:24:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 14:24:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 14:24:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/your_job.php
INFO - 2018-10-22 14:24:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 14:24:08 --> Final output sent to browser
DEBUG - 2018-10-22 14:24:09 --> Total execution time: 0.7664
INFO - 2018-10-22 14:24:11 --> Config Class Initialized
INFO - 2018-10-22 14:24:11 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:24:11 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:24:11 --> Utf8 Class Initialized
INFO - 2018-10-22 14:24:11 --> URI Class Initialized
INFO - 2018-10-22 14:24:11 --> Router Class Initialized
INFO - 2018-10-22 14:24:11 --> Output Class Initialized
INFO - 2018-10-22 14:24:11 --> Security Class Initialized
DEBUG - 2018-10-22 14:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:24:11 --> CSRF cookie sent
INFO - 2018-10-22 14:24:11 --> CSRF token verified
INFO - 2018-10-22 14:24:11 --> Input Class Initialized
INFO - 2018-10-22 14:24:11 --> Language Class Initialized
INFO - 2018-10-22 14:24:11 --> Loader Class Initialized
INFO - 2018-10-22 14:24:11 --> Helper loaded: url_helper
INFO - 2018-10-22 14:24:11 --> Helper loaded: form_helper
INFO - 2018-10-22 14:24:11 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:24:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:24:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:24:11 --> User Agent Class Initialized
INFO - 2018-10-22 14:24:11 --> Controller Class Initialized
INFO - 2018-10-22 14:24:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:24:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:24:11 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:24:11 --> Pixel_Model class loaded
INFO - 2018-10-22 14:24:11 --> Database Driver Class Initialized
INFO - 2018-10-22 14:24:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:24:11 --> Form Validation Class Initialized
INFO - 2018-10-22 14:24:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 14:24:11 --> Database Driver Class Initialized
INFO - 2018-10-22 14:24:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:24:11 --> Config Class Initialized
INFO - 2018-10-22 14:24:11 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:24:11 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:24:11 --> Utf8 Class Initialized
INFO - 2018-10-22 14:24:11 --> URI Class Initialized
INFO - 2018-10-22 14:24:11 --> Router Class Initialized
INFO - 2018-10-22 14:24:11 --> Output Class Initialized
INFO - 2018-10-22 14:24:11 --> Security Class Initialized
DEBUG - 2018-10-22 14:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:24:12 --> CSRF cookie sent
INFO - 2018-10-22 14:24:12 --> Input Class Initialized
INFO - 2018-10-22 14:24:12 --> Language Class Initialized
INFO - 2018-10-22 14:24:12 --> Loader Class Initialized
INFO - 2018-10-22 14:24:12 --> Helper loaded: url_helper
INFO - 2018-10-22 14:24:12 --> Helper loaded: form_helper
INFO - 2018-10-22 14:24:12 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:24:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:24:12 --> User Agent Class Initialized
INFO - 2018-10-22 14:24:12 --> Controller Class Initialized
INFO - 2018-10-22 14:24:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:24:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:24:12 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:24:12 --> Pixel_Model class loaded
INFO - 2018-10-22 14:24:12 --> Database Driver Class Initialized
INFO - 2018-10-22 14:24:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:24:12 --> Database Driver Class Initialized
INFO - 2018-10-22 14:24:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:24:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 14:24:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 14:24:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner.php
INFO - 2018-10-22 14:24:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 14:24:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 14:24:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 14:24:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 14:24:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/relation_ship_status.php
INFO - 2018-10-22 14:24:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 14:24:12 --> Final output sent to browser
DEBUG - 2018-10-22 14:24:12 --> Total execution time: 0.7930
INFO - 2018-10-22 14:24:14 --> Config Class Initialized
INFO - 2018-10-22 14:24:14 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:24:14 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:24:14 --> Utf8 Class Initialized
INFO - 2018-10-22 14:24:14 --> URI Class Initialized
INFO - 2018-10-22 14:24:14 --> Router Class Initialized
INFO - 2018-10-22 14:24:15 --> Output Class Initialized
INFO - 2018-10-22 14:24:15 --> Security Class Initialized
DEBUG - 2018-10-22 14:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:24:15 --> CSRF cookie sent
INFO - 2018-10-22 14:24:15 --> CSRF token verified
INFO - 2018-10-22 14:24:15 --> Input Class Initialized
INFO - 2018-10-22 14:24:15 --> Language Class Initialized
INFO - 2018-10-22 14:24:15 --> Loader Class Initialized
INFO - 2018-10-22 14:24:15 --> Helper loaded: url_helper
INFO - 2018-10-22 14:24:15 --> Helper loaded: form_helper
INFO - 2018-10-22 14:24:15 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:24:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:24:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:24:15 --> User Agent Class Initialized
INFO - 2018-10-22 14:24:15 --> Controller Class Initialized
INFO - 2018-10-22 14:24:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:24:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:24:15 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:24:15 --> Pixel_Model class loaded
INFO - 2018-10-22 14:24:15 --> Database Driver Class Initialized
INFO - 2018-10-22 14:24:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:24:15 --> Form Validation Class Initialized
INFO - 2018-10-22 14:24:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 14:24:15 --> Database Driver Class Initialized
INFO - 2018-10-22 14:24:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:24:15 --> Config Class Initialized
INFO - 2018-10-22 14:24:15 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:24:15 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:24:15 --> Utf8 Class Initialized
INFO - 2018-10-22 14:24:15 --> URI Class Initialized
INFO - 2018-10-22 14:24:15 --> Router Class Initialized
INFO - 2018-10-22 14:24:15 --> Output Class Initialized
INFO - 2018-10-22 14:24:15 --> Security Class Initialized
DEBUG - 2018-10-22 14:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:24:15 --> CSRF cookie sent
INFO - 2018-10-22 14:24:15 --> Input Class Initialized
INFO - 2018-10-22 14:24:15 --> Language Class Initialized
INFO - 2018-10-22 14:24:15 --> Loader Class Initialized
INFO - 2018-10-22 14:24:15 --> Helper loaded: url_helper
INFO - 2018-10-22 14:24:15 --> Helper loaded: form_helper
INFO - 2018-10-22 14:24:15 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:24:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:24:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:24:15 --> User Agent Class Initialized
INFO - 2018-10-22 14:24:15 --> Controller Class Initialized
INFO - 2018-10-22 14:24:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:24:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:24:16 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:24:16 --> Pixel_Model class loaded
INFO - 2018-10-22 14:24:16 --> Database Driver Class Initialized
INFO - 2018-10-22 14:24:16 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:24:16 --> Database Driver Class Initialized
INFO - 2018-10-22 14:24:16 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:24:16 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 14:24:16 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 14:24:16 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 14:24:16 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 14:24:16 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 14:24:16 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 14:24:16 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/income.php
INFO - 2018-10-22 14:24:16 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 14:24:16 --> Final output sent to browser
DEBUG - 2018-10-22 14:24:16 --> Total execution time: 0.7785
INFO - 2018-10-22 14:24:17 --> Config Class Initialized
INFO - 2018-10-22 14:24:17 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:24:17 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:24:17 --> Utf8 Class Initialized
INFO - 2018-10-22 14:24:17 --> URI Class Initialized
INFO - 2018-10-22 14:24:17 --> Router Class Initialized
INFO - 2018-10-22 14:24:17 --> Output Class Initialized
INFO - 2018-10-22 14:24:17 --> Security Class Initialized
DEBUG - 2018-10-22 14:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:24:17 --> CSRF cookie sent
INFO - 2018-10-22 14:24:17 --> CSRF token verified
INFO - 2018-10-22 14:24:17 --> Input Class Initialized
INFO - 2018-10-22 14:24:17 --> Language Class Initialized
INFO - 2018-10-22 14:24:17 --> Loader Class Initialized
INFO - 2018-10-22 14:24:17 --> Helper loaded: url_helper
INFO - 2018-10-22 14:24:17 --> Helper loaded: form_helper
INFO - 2018-10-22 14:24:17 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:24:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:24:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:24:17 --> User Agent Class Initialized
INFO - 2018-10-22 14:24:17 --> Controller Class Initialized
INFO - 2018-10-22 14:24:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:24:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:24:17 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:24:17 --> Pixel_Model class loaded
INFO - 2018-10-22 14:24:18 --> Database Driver Class Initialized
INFO - 2018-10-22 14:24:18 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:24:18 --> Form Validation Class Initialized
INFO - 2018-10-22 14:24:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 14:24:18 --> Database Driver Class Initialized
INFO - 2018-10-22 14:24:18 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:24:18 --> Config Class Initialized
INFO - 2018-10-22 14:24:18 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:24:18 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:24:18 --> Utf8 Class Initialized
INFO - 2018-10-22 14:24:18 --> URI Class Initialized
INFO - 2018-10-22 14:24:18 --> Router Class Initialized
INFO - 2018-10-22 14:24:18 --> Output Class Initialized
INFO - 2018-10-22 14:24:18 --> Security Class Initialized
DEBUG - 2018-10-22 14:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:24:18 --> CSRF cookie sent
INFO - 2018-10-22 14:24:18 --> Input Class Initialized
INFO - 2018-10-22 14:24:18 --> Language Class Initialized
INFO - 2018-10-22 14:24:18 --> Loader Class Initialized
INFO - 2018-10-22 14:24:18 --> Helper loaded: url_helper
INFO - 2018-10-22 14:24:18 --> Helper loaded: form_helper
INFO - 2018-10-22 14:24:18 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:24:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:24:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:24:18 --> User Agent Class Initialized
INFO - 2018-10-22 14:24:18 --> Controller Class Initialized
INFO - 2018-10-22 14:24:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:24:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:24:18 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:24:18 --> Pixel_Model class loaded
INFO - 2018-10-22 14:24:18 --> Database Driver Class Initialized
INFO - 2018-10-22 14:24:18 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:24:18 --> Database Driver Class Initialized
INFO - 2018-10-22 14:24:18 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:24:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 14:24:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 14:24:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 14:24:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 14:24:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 14:24:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 14:24:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/pension.php
INFO - 2018-10-22 14:24:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 14:24:18 --> Final output sent to browser
DEBUG - 2018-10-22 14:24:19 --> Total execution time: 0.7829
INFO - 2018-10-22 14:24:19 --> Config Class Initialized
INFO - 2018-10-22 14:24:20 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:24:20 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:24:20 --> Utf8 Class Initialized
INFO - 2018-10-22 14:24:20 --> URI Class Initialized
INFO - 2018-10-22 14:24:20 --> Router Class Initialized
INFO - 2018-10-22 14:24:20 --> Output Class Initialized
INFO - 2018-10-22 14:24:20 --> Security Class Initialized
DEBUG - 2018-10-22 14:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:24:20 --> CSRF cookie sent
INFO - 2018-10-22 14:24:20 --> CSRF token verified
INFO - 2018-10-22 14:24:20 --> Input Class Initialized
INFO - 2018-10-22 14:24:20 --> Language Class Initialized
INFO - 2018-10-22 14:24:20 --> Loader Class Initialized
INFO - 2018-10-22 14:24:20 --> Helper loaded: url_helper
INFO - 2018-10-22 14:24:20 --> Helper loaded: form_helper
INFO - 2018-10-22 14:24:20 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:24:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:24:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:24:20 --> User Agent Class Initialized
INFO - 2018-10-22 14:24:20 --> Controller Class Initialized
INFO - 2018-10-22 14:24:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:24:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:24:20 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:24:20 --> Pixel_Model class loaded
INFO - 2018-10-22 14:24:20 --> Database Driver Class Initialized
INFO - 2018-10-22 14:24:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:24:20 --> Form Validation Class Initialized
INFO - 2018-10-22 14:24:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-22 14:24:20 --> Database Driver Class Initialized
INFO - 2018-10-22 14:24:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:24:20 --> Config Class Initialized
INFO - 2018-10-22 14:24:20 --> Hooks Class Initialized
DEBUG - 2018-10-22 14:24:20 --> UTF-8 Support Enabled
INFO - 2018-10-22 14:24:20 --> Utf8 Class Initialized
INFO - 2018-10-22 14:24:20 --> URI Class Initialized
INFO - 2018-10-22 14:24:20 --> Router Class Initialized
INFO - 2018-10-22 14:24:20 --> Output Class Initialized
INFO - 2018-10-22 14:24:20 --> Security Class Initialized
DEBUG - 2018-10-22 14:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-22 14:24:20 --> CSRF cookie sent
INFO - 2018-10-22 14:24:20 --> Input Class Initialized
INFO - 2018-10-22 14:24:20 --> Language Class Initialized
INFO - 2018-10-22 14:24:21 --> Loader Class Initialized
INFO - 2018-10-22 14:24:21 --> Helper loaded: url_helper
INFO - 2018-10-22 14:24:21 --> Helper loaded: form_helper
INFO - 2018-10-22 14:24:21 --> Helper loaded: language_helper
DEBUG - 2018-10-22 14:24:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-22 14:24:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-22 14:24:21 --> User Agent Class Initialized
INFO - 2018-10-22 14:24:21 --> Controller Class Initialized
INFO - 2018-10-22 14:24:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-22 14:24:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-22 14:24:21 --> Helper loaded: custom_helper
INFO - 2018-10-22 14:24:21 --> Pixel_Model class loaded
INFO - 2018-10-22 14:24:21 --> Database Driver Class Initialized
INFO - 2018-10-22 14:24:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:24:21 --> Database Driver Class Initialized
INFO - 2018-10-22 14:24:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-22 14:24:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-22 14:24:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-22 14:24:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-22 14:24:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-22 14:24:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-22 14:24:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-22 14:24:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/inheritance.php
INFO - 2018-10-22 14:24:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-22 14:24:21 --> Final output sent to browser
DEBUG - 2018-10-22 14:24:21 --> Total execution time: 0.8250

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-10-23 13:52:03 --> Config Class Initialized
INFO - 2018-10-23 13:52:03 --> Hooks Class Initialized
DEBUG - 2018-10-23 13:52:03 --> UTF-8 Support Enabled
INFO - 2018-10-23 13:52:03 --> Utf8 Class Initialized
INFO - 2018-10-23 13:52:03 --> URI Class Initialized
DEBUG - 2018-10-23 13:52:03 --> No URI present. Default controller set.
INFO - 2018-10-23 13:52:03 --> Router Class Initialized
INFO - 2018-10-23 13:52:03 --> Output Class Initialized
INFO - 2018-10-23 13:52:03 --> Security Class Initialized
DEBUG - 2018-10-23 13:52:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 13:52:03 --> CSRF cookie sent
INFO - 2018-10-23 13:52:03 --> Input Class Initialized
INFO - 2018-10-23 13:52:03 --> Language Class Initialized
INFO - 2018-10-23 13:52:03 --> Loader Class Initialized
INFO - 2018-10-23 13:52:03 --> Helper loaded: url_helper
INFO - 2018-10-23 13:52:03 --> Helper loaded: form_helper
INFO - 2018-10-23 13:52:03 --> Helper loaded: language_helper
DEBUG - 2018-10-23 13:52:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 13:52:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 13:52:04 --> User Agent Class Initialized
INFO - 2018-10-23 13:52:04 --> Controller Class Initialized
INFO - 2018-10-23 13:52:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 13:52:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 13:52:04 --> Helper loaded: custom_helper
INFO - 2018-10-23 13:52:04 --> Pixel_Model class loaded
INFO - 2018-10-23 13:52:04 --> Database Driver Class Initialized
INFO - 2018-10-23 13:52:04 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 13:52:04 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 13:52:04 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 13:52:04 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-23 13:52:04 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 13:52:04 --> Final output sent to browser
DEBUG - 2018-10-23 13:52:04 --> Total execution time: 1.3515
INFO - 2018-10-23 13:52:06 --> Config Class Initialized
INFO - 2018-10-23 13:52:06 --> Hooks Class Initialized
DEBUG - 2018-10-23 13:52:06 --> UTF-8 Support Enabled
INFO - 2018-10-23 13:52:06 --> Utf8 Class Initialized
INFO - 2018-10-23 13:52:06 --> URI Class Initialized
INFO - 2018-10-23 13:52:06 --> Router Class Initialized
INFO - 2018-10-23 13:52:06 --> Output Class Initialized
INFO - 2018-10-23 13:52:07 --> Security Class Initialized
DEBUG - 2018-10-23 13:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 13:52:07 --> CSRF cookie sent
INFO - 2018-10-23 13:52:07 --> Input Class Initialized
INFO - 2018-10-23 13:52:07 --> Language Class Initialized
INFO - 2018-10-23 13:52:07 --> Loader Class Initialized
INFO - 2018-10-23 13:52:07 --> Helper loaded: url_helper
INFO - 2018-10-23 13:52:07 --> Helper loaded: form_helper
INFO - 2018-10-23 13:52:07 --> Helper loaded: language_helper
DEBUG - 2018-10-23 13:52:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 13:52:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 13:52:07 --> User Agent Class Initialized
INFO - 2018-10-23 13:52:07 --> Controller Class Initialized
INFO - 2018-10-23 13:52:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 13:52:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 13:52:07 --> Helper loaded: custom_helper
INFO - 2018-10-23 13:52:07 --> Pixel_Model class loaded
INFO - 2018-10-23 13:52:07 --> Database Driver Class Initialized
INFO - 2018-10-23 13:52:07 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 13:52:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 13:52:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 13:52:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 13:52:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 13:52:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 13:52:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 13:52:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-23 13:52:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 13:52:07 --> Final output sent to browser
DEBUG - 2018-10-23 13:52:07 --> Total execution time: 0.5751
INFO - 2018-10-23 13:52:09 --> Config Class Initialized
INFO - 2018-10-23 13:52:09 --> Hooks Class Initialized
DEBUG - 2018-10-23 13:52:09 --> UTF-8 Support Enabled
INFO - 2018-10-23 13:52:09 --> Utf8 Class Initialized
INFO - 2018-10-23 13:52:09 --> URI Class Initialized
INFO - 2018-10-23 13:52:09 --> Router Class Initialized
INFO - 2018-10-23 13:52:09 --> Output Class Initialized
INFO - 2018-10-23 13:52:09 --> Security Class Initialized
DEBUG - 2018-10-23 13:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 13:52:09 --> CSRF cookie sent
INFO - 2018-10-23 13:52:09 --> CSRF token verified
INFO - 2018-10-23 13:52:09 --> Input Class Initialized
INFO - 2018-10-23 13:52:09 --> Language Class Initialized
INFO - 2018-10-23 13:52:09 --> Loader Class Initialized
INFO - 2018-10-23 13:52:09 --> Helper loaded: url_helper
INFO - 2018-10-23 13:52:09 --> Helper loaded: form_helper
INFO - 2018-10-23 13:52:09 --> Helper loaded: language_helper
DEBUG - 2018-10-23 13:52:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 13:52:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 13:52:09 --> User Agent Class Initialized
INFO - 2018-10-23 13:52:09 --> Controller Class Initialized
INFO - 2018-10-23 13:52:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 13:52:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 13:52:09 --> Helper loaded: custom_helper
INFO - 2018-10-23 13:52:09 --> Pixel_Model class loaded
INFO - 2018-10-23 13:52:09 --> Database Driver Class Initialized
INFO - 2018-10-23 13:52:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 13:52:09 --> Form Validation Class Initialized
INFO - 2018-10-23 13:52:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 13:52:09 --> Database Driver Class Initialized
INFO - 2018-10-23 13:52:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 13:52:09 --> Config Class Initialized
INFO - 2018-10-23 13:52:09 --> Hooks Class Initialized
DEBUG - 2018-10-23 13:52:09 --> UTF-8 Support Enabled
INFO - 2018-10-23 13:52:09 --> Utf8 Class Initialized
INFO - 2018-10-23 13:52:09 --> URI Class Initialized
DEBUG - 2018-10-23 13:52:09 --> No URI present. Default controller set.
INFO - 2018-10-23 13:52:09 --> Router Class Initialized
INFO - 2018-10-23 13:52:09 --> Output Class Initialized
INFO - 2018-10-23 13:52:09 --> Security Class Initialized
DEBUG - 2018-10-23 13:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 13:52:09 --> CSRF cookie sent
INFO - 2018-10-23 13:52:09 --> Input Class Initialized
INFO - 2018-10-23 13:52:10 --> Language Class Initialized
INFO - 2018-10-23 13:52:10 --> Loader Class Initialized
INFO - 2018-10-23 13:52:10 --> Helper loaded: url_helper
INFO - 2018-10-23 13:52:10 --> Helper loaded: form_helper
INFO - 2018-10-23 13:52:10 --> Helper loaded: language_helper
DEBUG - 2018-10-23 13:52:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 13:52:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 13:52:10 --> User Agent Class Initialized
INFO - 2018-10-23 13:52:10 --> Controller Class Initialized
INFO - 2018-10-23 13:52:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 13:52:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 13:52:10 --> Helper loaded: custom_helper
INFO - 2018-10-23 13:52:10 --> Pixel_Model class loaded
INFO - 2018-10-23 13:52:10 --> Database Driver Class Initialized
INFO - 2018-10-23 13:52:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 13:52:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 13:52:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 13:52:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-23 13:52:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 13:52:10 --> Final output sent to browser
DEBUG - 2018-10-23 13:52:10 --> Total execution time: 0.2525
INFO - 2018-10-23 13:52:15 --> Config Class Initialized
INFO - 2018-10-23 13:52:15 --> Hooks Class Initialized
DEBUG - 2018-10-23 13:52:15 --> UTF-8 Support Enabled
INFO - 2018-10-23 13:52:15 --> Utf8 Class Initialized
INFO - 2018-10-23 13:52:15 --> URI Class Initialized
INFO - 2018-10-23 13:52:15 --> Router Class Initialized
INFO - 2018-10-23 13:52:15 --> Output Class Initialized
INFO - 2018-10-23 13:52:15 --> Security Class Initialized
DEBUG - 2018-10-23 13:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 13:52:15 --> CSRF cookie sent
INFO - 2018-10-23 13:52:15 --> CSRF token verified
INFO - 2018-10-23 13:52:15 --> Input Class Initialized
INFO - 2018-10-23 13:52:15 --> Language Class Initialized
INFO - 2018-10-23 13:52:15 --> Loader Class Initialized
INFO - 2018-10-23 13:52:15 --> Helper loaded: url_helper
INFO - 2018-10-23 13:52:15 --> Helper loaded: form_helper
INFO - 2018-10-23 13:52:15 --> Helper loaded: language_helper
DEBUG - 2018-10-23 13:52:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 13:52:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 13:52:15 --> User Agent Class Initialized
INFO - 2018-10-23 13:52:15 --> Controller Class Initialized
INFO - 2018-10-23 13:52:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 13:52:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 13:52:15 --> Helper loaded: custom_helper
INFO - 2018-10-23 13:52:15 --> Pixel_Model class loaded
INFO - 2018-10-23 13:52:15 --> Database Driver Class Initialized
INFO - 2018-10-23 13:52:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 13:52:15 --> Form Validation Class Initialized
INFO - 2018-10-23 13:52:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 13:52:15 --> Database Driver Class Initialized
INFO - 2018-10-23 13:52:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 13:52:15 --> Config Class Initialized
INFO - 2018-10-23 13:52:15 --> Hooks Class Initialized
DEBUG - 2018-10-23 13:52:15 --> UTF-8 Support Enabled
INFO - 2018-10-23 13:52:15 --> Utf8 Class Initialized
INFO - 2018-10-23 13:52:15 --> URI Class Initialized
DEBUG - 2018-10-23 13:52:15 --> No URI present. Default controller set.
INFO - 2018-10-23 13:52:15 --> Router Class Initialized
INFO - 2018-10-23 13:52:15 --> Output Class Initialized
INFO - 2018-10-23 13:52:15 --> Security Class Initialized
DEBUG - 2018-10-23 13:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 13:52:15 --> CSRF cookie sent
INFO - 2018-10-23 13:52:15 --> Input Class Initialized
INFO - 2018-10-23 13:52:15 --> Language Class Initialized
INFO - 2018-10-23 13:52:16 --> Loader Class Initialized
INFO - 2018-10-23 13:52:16 --> Helper loaded: url_helper
INFO - 2018-10-23 13:52:16 --> Helper loaded: form_helper
INFO - 2018-10-23 13:52:16 --> Helper loaded: language_helper
DEBUG - 2018-10-23 13:52:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 13:52:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 13:52:16 --> User Agent Class Initialized
INFO - 2018-10-23 13:52:16 --> Controller Class Initialized
INFO - 2018-10-23 13:52:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 13:52:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 13:52:16 --> Helper loaded: custom_helper
INFO - 2018-10-23 13:52:16 --> Pixel_Model class loaded
INFO - 2018-10-23 13:52:16 --> Database Driver Class Initialized
INFO - 2018-10-23 13:52:16 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 13:52:16 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 13:52:16 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 13:52:16 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-23 13:52:16 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 13:52:16 --> Final output sent to browser
DEBUG - 2018-10-23 13:52:16 --> Total execution time: 0.3265
INFO - 2018-10-23 14:10:05 --> Config Class Initialized
INFO - 2018-10-23 14:10:05 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:10:05 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:10:05 --> Utf8 Class Initialized
INFO - 2018-10-23 14:10:05 --> URI Class Initialized
DEBUG - 2018-10-23 14:10:05 --> No URI present. Default controller set.
INFO - 2018-10-23 14:10:05 --> Router Class Initialized
INFO - 2018-10-23 14:10:05 --> Output Class Initialized
INFO - 2018-10-23 14:10:05 --> Security Class Initialized
DEBUG - 2018-10-23 14:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:10:05 --> CSRF cookie sent
INFO - 2018-10-23 14:10:05 --> Input Class Initialized
INFO - 2018-10-23 14:10:05 --> Language Class Initialized
INFO - 2018-10-23 14:10:05 --> Loader Class Initialized
INFO - 2018-10-23 14:10:05 --> Helper loaded: url_helper
INFO - 2018-10-23 14:10:05 --> Helper loaded: form_helper
INFO - 2018-10-23 14:10:05 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:10:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:10:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:10:05 --> User Agent Class Initialized
INFO - 2018-10-23 14:10:05 --> Controller Class Initialized
INFO - 2018-10-23 14:10:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:10:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:10:05 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:10:05 --> Pixel_Model class loaded
INFO - 2018-10-23 14:10:05 --> Database Driver Class Initialized
INFO - 2018-10-23 14:10:05 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:10:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:10:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:10:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-23 14:10:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:10:05 --> Final output sent to browser
DEBUG - 2018-10-23 14:10:05 --> Total execution time: 0.3378
INFO - 2018-10-23 14:10:48 --> Config Class Initialized
INFO - 2018-10-23 14:10:48 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:10:48 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:10:48 --> Utf8 Class Initialized
INFO - 2018-10-23 14:10:48 --> URI Class Initialized
INFO - 2018-10-23 14:10:48 --> Router Class Initialized
INFO - 2018-10-23 14:10:48 --> Output Class Initialized
INFO - 2018-10-23 14:10:48 --> Security Class Initialized
DEBUG - 2018-10-23 14:10:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:10:48 --> CSRF cookie sent
INFO - 2018-10-23 14:10:48 --> Input Class Initialized
INFO - 2018-10-23 14:10:48 --> Language Class Initialized
INFO - 2018-10-23 14:10:48 --> Loader Class Initialized
INFO - 2018-10-23 14:10:48 --> Helper loaded: url_helper
INFO - 2018-10-23 14:10:48 --> Helper loaded: form_helper
INFO - 2018-10-23 14:10:48 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:10:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:10:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:10:48 --> User Agent Class Initialized
INFO - 2018-10-23 14:10:48 --> Controller Class Initialized
INFO - 2018-10-23 14:10:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:10:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:10:48 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:10:48 --> Pixel_Model class loaded
INFO - 2018-10-23 14:10:48 --> Database Driver Class Initialized
INFO - 2018-10-23 14:10:48 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:10:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:10:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:10:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:10:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:10:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:10:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:10:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-23 14:10:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:10:48 --> Final output sent to browser
DEBUG - 2018-10-23 14:10:48 --> Total execution time: 0.3117
INFO - 2018-10-23 14:10:50 --> Config Class Initialized
INFO - 2018-10-23 14:10:50 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:10:50 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:10:50 --> Utf8 Class Initialized
INFO - 2018-10-23 14:10:50 --> URI Class Initialized
INFO - 2018-10-23 14:10:50 --> Router Class Initialized
INFO - 2018-10-23 14:10:50 --> Output Class Initialized
INFO - 2018-10-23 14:10:50 --> Security Class Initialized
DEBUG - 2018-10-23 14:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:10:50 --> CSRF cookie sent
INFO - 2018-10-23 14:10:50 --> CSRF token verified
INFO - 2018-10-23 14:10:50 --> Input Class Initialized
INFO - 2018-10-23 14:10:50 --> Language Class Initialized
INFO - 2018-10-23 14:10:50 --> Loader Class Initialized
INFO - 2018-10-23 14:10:50 --> Helper loaded: url_helper
INFO - 2018-10-23 14:10:50 --> Helper loaded: form_helper
INFO - 2018-10-23 14:10:50 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:10:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:10:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:10:50 --> User Agent Class Initialized
INFO - 2018-10-23 14:10:50 --> Controller Class Initialized
INFO - 2018-10-23 14:10:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:10:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:10:50 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:10:50 --> Pixel_Model class loaded
INFO - 2018-10-23 14:10:50 --> Database Driver Class Initialized
INFO - 2018-10-23 14:10:50 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:10:50 --> Form Validation Class Initialized
INFO - 2018-10-23 14:10:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:10:50 --> Database Driver Class Initialized
INFO - 2018-10-23 14:10:50 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:10:50 --> Config Class Initialized
INFO - 2018-10-23 14:10:50 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:10:50 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:10:50 --> Utf8 Class Initialized
INFO - 2018-10-23 14:10:50 --> URI Class Initialized
DEBUG - 2018-10-23 14:10:50 --> No URI present. Default controller set.
INFO - 2018-10-23 14:10:50 --> Router Class Initialized
INFO - 2018-10-23 14:10:50 --> Output Class Initialized
INFO - 2018-10-23 14:10:50 --> Security Class Initialized
DEBUG - 2018-10-23 14:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:10:50 --> CSRF cookie sent
INFO - 2018-10-23 14:10:50 --> Input Class Initialized
INFO - 2018-10-23 14:10:50 --> Language Class Initialized
INFO - 2018-10-23 14:10:50 --> Loader Class Initialized
INFO - 2018-10-23 14:10:50 --> Helper loaded: url_helper
INFO - 2018-10-23 14:10:50 --> Helper loaded: form_helper
INFO - 2018-10-23 14:10:50 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:10:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:10:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:10:50 --> User Agent Class Initialized
INFO - 2018-10-23 14:10:50 --> Controller Class Initialized
INFO - 2018-10-23 14:10:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:10:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:10:50 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:10:50 --> Pixel_Model class loaded
INFO - 2018-10-23 14:10:50 --> Database Driver Class Initialized
INFO - 2018-10-23 14:10:50 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:10:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:10:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:10:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-23 14:10:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:10:50 --> Final output sent to browser
DEBUG - 2018-10-23 14:10:50 --> Total execution time: 0.2662
INFO - 2018-10-23 14:10:53 --> Config Class Initialized
INFO - 2018-10-23 14:10:53 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:10:53 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:10:53 --> Utf8 Class Initialized
INFO - 2018-10-23 14:10:53 --> URI Class Initialized
INFO - 2018-10-23 14:10:53 --> Router Class Initialized
INFO - 2018-10-23 14:10:53 --> Output Class Initialized
INFO - 2018-10-23 14:10:53 --> Security Class Initialized
DEBUG - 2018-10-23 14:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:10:53 --> CSRF cookie sent
INFO - 2018-10-23 14:10:53 --> Input Class Initialized
INFO - 2018-10-23 14:10:53 --> Language Class Initialized
INFO - 2018-10-23 14:10:53 --> Loader Class Initialized
INFO - 2018-10-23 14:10:53 --> Helper loaded: url_helper
INFO - 2018-10-23 14:10:53 --> Helper loaded: form_helper
INFO - 2018-10-23 14:10:53 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:10:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:10:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:10:53 --> User Agent Class Initialized
INFO - 2018-10-23 14:10:53 --> Controller Class Initialized
INFO - 2018-10-23 14:10:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:10:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:10:53 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:10:53 --> Pixel_Model class loaded
INFO - 2018-10-23 14:10:53 --> Database Driver Class Initialized
INFO - 2018-10-23 14:10:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:10:53 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:10:53 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:10:53 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:10:53 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:10:53 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:10:53 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:10:53 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-23 14:10:53 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:10:53 --> Final output sent to browser
DEBUG - 2018-10-23 14:10:53 --> Total execution time: 0.3449
INFO - 2018-10-23 14:11:23 --> Config Class Initialized
INFO - 2018-10-23 14:11:24 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:11:24 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:11:24 --> Utf8 Class Initialized
INFO - 2018-10-23 14:11:24 --> URI Class Initialized
INFO - 2018-10-23 14:11:24 --> Router Class Initialized
INFO - 2018-10-23 14:11:24 --> Output Class Initialized
INFO - 2018-10-23 14:11:24 --> Security Class Initialized
DEBUG - 2018-10-23 14:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:11:24 --> CSRF cookie sent
INFO - 2018-10-23 14:11:24 --> Input Class Initialized
INFO - 2018-10-23 14:11:24 --> Language Class Initialized
INFO - 2018-10-23 14:11:24 --> Loader Class Initialized
INFO - 2018-10-23 14:11:24 --> Helper loaded: url_helper
INFO - 2018-10-23 14:11:24 --> Helper loaded: form_helper
INFO - 2018-10-23 14:11:24 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:11:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:11:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:11:24 --> User Agent Class Initialized
INFO - 2018-10-23 14:11:24 --> Controller Class Initialized
INFO - 2018-10-23 14:11:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:11:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:11:24 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:11:24 --> Pixel_Model class loaded
INFO - 2018-10-23 14:11:24 --> Database Driver Class Initialized
INFO - 2018-10-23 14:11:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:11:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:11:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:11:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:11:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:11:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:11:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:11:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-23 14:11:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:11:24 --> Final output sent to browser
DEBUG - 2018-10-23 14:11:24 --> Total execution time: 0.3152
INFO - 2018-10-23 14:11:26 --> Config Class Initialized
INFO - 2018-10-23 14:11:26 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:11:26 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:11:26 --> Utf8 Class Initialized
INFO - 2018-10-23 14:11:26 --> URI Class Initialized
INFO - 2018-10-23 14:11:26 --> Router Class Initialized
INFO - 2018-10-23 14:11:26 --> Output Class Initialized
INFO - 2018-10-23 14:11:26 --> Security Class Initialized
DEBUG - 2018-10-23 14:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:11:26 --> CSRF cookie sent
INFO - 2018-10-23 14:11:26 --> Input Class Initialized
INFO - 2018-10-23 14:11:26 --> Language Class Initialized
INFO - 2018-10-23 14:11:26 --> Loader Class Initialized
INFO - 2018-10-23 14:11:26 --> Helper loaded: url_helper
INFO - 2018-10-23 14:11:26 --> Helper loaded: form_helper
INFO - 2018-10-23 14:11:26 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:11:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:11:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:11:26 --> User Agent Class Initialized
INFO - 2018-10-23 14:11:26 --> Controller Class Initialized
INFO - 2018-10-23 14:11:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:11:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:11:26 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:11:26 --> Pixel_Model class loaded
INFO - 2018-10-23 14:11:26 --> Database Driver Class Initialized
INFO - 2018-10-23 14:11:26 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:11:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:11:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:11:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:11:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:11:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:11:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:11:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-23 14:11:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:11:26 --> Final output sent to browser
DEBUG - 2018-10-23 14:11:26 --> Total execution time: 0.3276
INFO - 2018-10-23 14:11:28 --> Config Class Initialized
INFO - 2018-10-23 14:11:28 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:11:28 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:11:28 --> Utf8 Class Initialized
INFO - 2018-10-23 14:11:28 --> URI Class Initialized
DEBUG - 2018-10-23 14:11:28 --> No URI present. Default controller set.
INFO - 2018-10-23 14:11:28 --> Router Class Initialized
INFO - 2018-10-23 14:11:28 --> Output Class Initialized
INFO - 2018-10-23 14:11:28 --> Security Class Initialized
DEBUG - 2018-10-23 14:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:11:28 --> CSRF cookie sent
INFO - 2018-10-23 14:11:28 --> Input Class Initialized
INFO - 2018-10-23 14:11:28 --> Language Class Initialized
INFO - 2018-10-23 14:11:28 --> Loader Class Initialized
INFO - 2018-10-23 14:11:28 --> Helper loaded: url_helper
INFO - 2018-10-23 14:11:28 --> Helper loaded: form_helper
INFO - 2018-10-23 14:11:28 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:11:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:11:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:11:28 --> User Agent Class Initialized
INFO - 2018-10-23 14:11:28 --> Controller Class Initialized
INFO - 2018-10-23 14:11:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:11:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:11:28 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:11:28 --> Pixel_Model class loaded
INFO - 2018-10-23 14:11:28 --> Database Driver Class Initialized
INFO - 2018-10-23 14:11:28 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:11:28 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:11:28 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:11:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-23 14:11:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:11:29 --> Final output sent to browser
DEBUG - 2018-10-23 14:11:29 --> Total execution time: 0.3339
INFO - 2018-10-23 14:11:32 --> Config Class Initialized
INFO - 2018-10-23 14:11:32 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:11:32 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:11:32 --> Utf8 Class Initialized
INFO - 2018-10-23 14:11:32 --> URI Class Initialized
INFO - 2018-10-23 14:11:32 --> Router Class Initialized
INFO - 2018-10-23 14:11:32 --> Output Class Initialized
INFO - 2018-10-23 14:11:32 --> Security Class Initialized
DEBUG - 2018-10-23 14:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:11:32 --> CSRF cookie sent
INFO - 2018-10-23 14:11:32 --> CSRF token verified
INFO - 2018-10-23 14:11:32 --> Input Class Initialized
INFO - 2018-10-23 14:11:32 --> Language Class Initialized
INFO - 2018-10-23 14:11:32 --> Loader Class Initialized
INFO - 2018-10-23 14:11:32 --> Helper loaded: url_helper
INFO - 2018-10-23 14:11:32 --> Helper loaded: form_helper
INFO - 2018-10-23 14:11:32 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:11:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:11:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:11:32 --> User Agent Class Initialized
INFO - 2018-10-23 14:11:32 --> Controller Class Initialized
INFO - 2018-10-23 14:11:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:11:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:11:32 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:11:32 --> Pixel_Model class loaded
INFO - 2018-10-23 14:11:32 --> Database Driver Class Initialized
INFO - 2018-10-23 14:11:32 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:11:32 --> Form Validation Class Initialized
INFO - 2018-10-23 14:11:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:11:32 --> Database Driver Class Initialized
INFO - 2018-10-23 14:11:32 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:11:32 --> Config Class Initialized
INFO - 2018-10-23 14:11:32 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:11:32 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:11:32 --> Utf8 Class Initialized
INFO - 2018-10-23 14:11:32 --> URI Class Initialized
DEBUG - 2018-10-23 14:11:32 --> No URI present. Default controller set.
INFO - 2018-10-23 14:11:32 --> Router Class Initialized
INFO - 2018-10-23 14:11:32 --> Output Class Initialized
INFO - 2018-10-23 14:11:32 --> Security Class Initialized
DEBUG - 2018-10-23 14:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:11:32 --> CSRF cookie sent
INFO - 2018-10-23 14:11:32 --> Input Class Initialized
INFO - 2018-10-23 14:11:32 --> Language Class Initialized
INFO - 2018-10-23 14:11:32 --> Loader Class Initialized
INFO - 2018-10-23 14:11:32 --> Helper loaded: url_helper
INFO - 2018-10-23 14:11:32 --> Helper loaded: form_helper
INFO - 2018-10-23 14:11:32 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:11:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:11:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:11:32 --> User Agent Class Initialized
INFO - 2018-10-23 14:11:32 --> Controller Class Initialized
INFO - 2018-10-23 14:11:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:11:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:11:33 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:11:33 --> Pixel_Model class loaded
INFO - 2018-10-23 14:11:33 --> Database Driver Class Initialized
INFO - 2018-10-23 14:11:33 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:11:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:11:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:11:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-23 14:11:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:11:33 --> Final output sent to browser
DEBUG - 2018-10-23 14:11:33 --> Total execution time: 0.3404
INFO - 2018-10-23 14:11:35 --> Config Class Initialized
INFO - 2018-10-23 14:11:35 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:11:35 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:11:35 --> Utf8 Class Initialized
INFO - 2018-10-23 14:11:35 --> URI Class Initialized
INFO - 2018-10-23 14:11:35 --> Router Class Initialized
INFO - 2018-10-23 14:11:35 --> Output Class Initialized
INFO - 2018-10-23 14:11:35 --> Security Class Initialized
DEBUG - 2018-10-23 14:11:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:11:35 --> CSRF cookie sent
INFO - 2018-10-23 14:11:35 --> Input Class Initialized
INFO - 2018-10-23 14:11:35 --> Language Class Initialized
INFO - 2018-10-23 14:11:35 --> Loader Class Initialized
INFO - 2018-10-23 14:11:35 --> Helper loaded: url_helper
INFO - 2018-10-23 14:11:35 --> Helper loaded: form_helper
INFO - 2018-10-23 14:11:35 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:11:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:11:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:11:35 --> User Agent Class Initialized
INFO - 2018-10-23 14:11:35 --> Controller Class Initialized
INFO - 2018-10-23 14:11:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:11:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:11:35 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:11:35 --> Pixel_Model class loaded
INFO - 2018-10-23 14:11:35 --> Database Driver Class Initialized
INFO - 2018-10-23 14:11:35 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:11:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:11:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:11:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:11:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:11:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:11:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:11:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-23 14:11:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:11:35 --> Final output sent to browser
DEBUG - 2018-10-23 14:11:35 --> Total execution time: 0.3953
INFO - 2018-10-23 14:11:38 --> Config Class Initialized
INFO - 2018-10-23 14:11:38 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:11:38 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:11:38 --> Utf8 Class Initialized
INFO - 2018-10-23 14:11:38 --> URI Class Initialized
INFO - 2018-10-23 14:11:38 --> Router Class Initialized
INFO - 2018-10-23 14:11:38 --> Output Class Initialized
INFO - 2018-10-23 14:11:38 --> Security Class Initialized
DEBUG - 2018-10-23 14:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:11:38 --> CSRF cookie sent
INFO - 2018-10-23 14:11:38 --> CSRF token verified
INFO - 2018-10-23 14:11:38 --> Input Class Initialized
INFO - 2018-10-23 14:11:38 --> Language Class Initialized
INFO - 2018-10-23 14:11:38 --> Loader Class Initialized
INFO - 2018-10-23 14:11:38 --> Helper loaded: url_helper
INFO - 2018-10-23 14:11:38 --> Helper loaded: form_helper
INFO - 2018-10-23 14:11:38 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:11:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:11:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:11:38 --> User Agent Class Initialized
INFO - 2018-10-23 14:11:38 --> Controller Class Initialized
INFO - 2018-10-23 14:11:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:11:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:11:38 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:11:38 --> Pixel_Model class loaded
INFO - 2018-10-23 14:11:38 --> Database Driver Class Initialized
INFO - 2018-10-23 14:11:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:11:38 --> Form Validation Class Initialized
INFO - 2018-10-23 14:11:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:11:38 --> Database Driver Class Initialized
INFO - 2018-10-23 14:11:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:11:38 --> Config Class Initialized
INFO - 2018-10-23 14:11:38 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:11:38 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:11:38 --> Utf8 Class Initialized
INFO - 2018-10-23 14:11:38 --> URI Class Initialized
DEBUG - 2018-10-23 14:11:38 --> No URI present. Default controller set.
INFO - 2018-10-23 14:11:38 --> Router Class Initialized
INFO - 2018-10-23 14:11:38 --> Output Class Initialized
INFO - 2018-10-23 14:11:38 --> Security Class Initialized
DEBUG - 2018-10-23 14:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:11:38 --> CSRF cookie sent
INFO - 2018-10-23 14:11:38 --> Input Class Initialized
INFO - 2018-10-23 14:11:38 --> Language Class Initialized
INFO - 2018-10-23 14:11:38 --> Loader Class Initialized
INFO - 2018-10-23 14:11:38 --> Helper loaded: url_helper
INFO - 2018-10-23 14:11:38 --> Helper loaded: form_helper
INFO - 2018-10-23 14:11:38 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:11:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:11:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:11:38 --> User Agent Class Initialized
INFO - 2018-10-23 14:11:38 --> Controller Class Initialized
INFO - 2018-10-23 14:11:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:11:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:11:38 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:11:38 --> Pixel_Model class loaded
INFO - 2018-10-23 14:11:38 --> Database Driver Class Initialized
INFO - 2018-10-23 14:11:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:11:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:11:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:11:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-23 14:11:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:11:38 --> Final output sent to browser
DEBUG - 2018-10-23 14:11:38 --> Total execution time: 0.2817
INFO - 2018-10-23 14:12:13 --> Config Class Initialized
INFO - 2018-10-23 14:12:13 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:12:13 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:12:13 --> Utf8 Class Initialized
INFO - 2018-10-23 14:12:13 --> URI Class Initialized
DEBUG - 2018-10-23 14:12:13 --> No URI present. Default controller set.
INFO - 2018-10-23 14:12:13 --> Router Class Initialized
INFO - 2018-10-23 14:12:13 --> Output Class Initialized
INFO - 2018-10-23 14:12:13 --> Security Class Initialized
DEBUG - 2018-10-23 14:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:12:13 --> CSRF cookie sent
INFO - 2018-10-23 14:12:13 --> Input Class Initialized
INFO - 2018-10-23 14:12:13 --> Language Class Initialized
INFO - 2018-10-23 14:12:13 --> Loader Class Initialized
INFO - 2018-10-23 14:12:13 --> Helper loaded: url_helper
INFO - 2018-10-23 14:12:13 --> Helper loaded: form_helper
INFO - 2018-10-23 14:12:13 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:12:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:12:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:12:13 --> User Agent Class Initialized
INFO - 2018-10-23 14:12:13 --> Controller Class Initialized
INFO - 2018-10-23 14:12:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:12:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:12:13 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:12:13 --> Pixel_Model class loaded
INFO - 2018-10-23 14:12:13 --> Database Driver Class Initialized
INFO - 2018-10-23 14:12:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:12:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:12:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:12:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-23 14:12:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:12:13 --> Final output sent to browser
DEBUG - 2018-10-23 14:12:13 --> Total execution time: 0.3196
INFO - 2018-10-23 14:12:15 --> Config Class Initialized
INFO - 2018-10-23 14:12:15 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:12:15 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:12:15 --> Utf8 Class Initialized
INFO - 2018-10-23 14:12:15 --> URI Class Initialized
INFO - 2018-10-23 14:12:15 --> Router Class Initialized
INFO - 2018-10-23 14:12:15 --> Output Class Initialized
INFO - 2018-10-23 14:12:16 --> Security Class Initialized
DEBUG - 2018-10-23 14:12:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:12:16 --> CSRF cookie sent
INFO - 2018-10-23 14:12:16 --> Input Class Initialized
INFO - 2018-10-23 14:12:16 --> Language Class Initialized
INFO - 2018-10-23 14:12:16 --> Loader Class Initialized
INFO - 2018-10-23 14:12:16 --> Helper loaded: url_helper
INFO - 2018-10-23 14:12:16 --> Helper loaded: form_helper
INFO - 2018-10-23 14:12:16 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:12:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:12:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:12:16 --> User Agent Class Initialized
INFO - 2018-10-23 14:12:16 --> Controller Class Initialized
INFO - 2018-10-23 14:12:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:12:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:12:16 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:12:16 --> Pixel_Model class loaded
INFO - 2018-10-23 14:12:16 --> Database Driver Class Initialized
INFO - 2018-10-23 14:12:16 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:12:16 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:12:16 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:12:16 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:12:16 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:12:16 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:12:16 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:12:16 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-23 14:12:16 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:12:16 --> Final output sent to browser
DEBUG - 2018-10-23 14:12:16 --> Total execution time: 0.4160
INFO - 2018-10-23 14:12:18 --> Config Class Initialized
INFO - 2018-10-23 14:12:18 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:12:18 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:12:18 --> Utf8 Class Initialized
INFO - 2018-10-23 14:12:18 --> URI Class Initialized
INFO - 2018-10-23 14:12:18 --> Router Class Initialized
INFO - 2018-10-23 14:12:18 --> Output Class Initialized
INFO - 2018-10-23 14:12:18 --> Security Class Initialized
DEBUG - 2018-10-23 14:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:12:18 --> CSRF cookie sent
INFO - 2018-10-23 14:12:18 --> CSRF token verified
INFO - 2018-10-23 14:12:18 --> Input Class Initialized
INFO - 2018-10-23 14:12:18 --> Language Class Initialized
INFO - 2018-10-23 14:12:18 --> Loader Class Initialized
INFO - 2018-10-23 14:12:18 --> Helper loaded: url_helper
INFO - 2018-10-23 14:12:18 --> Helper loaded: form_helper
INFO - 2018-10-23 14:12:18 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:12:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:12:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:12:18 --> User Agent Class Initialized
INFO - 2018-10-23 14:12:18 --> Controller Class Initialized
INFO - 2018-10-23 14:12:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:12:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:12:18 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:12:18 --> Pixel_Model class loaded
INFO - 2018-10-23 14:12:18 --> Database Driver Class Initialized
INFO - 2018-10-23 14:12:18 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:12:18 --> Form Validation Class Initialized
INFO - 2018-10-23 14:12:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:12:18 --> Database Driver Class Initialized
INFO - 2018-10-23 14:12:18 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:12:18 --> Config Class Initialized
INFO - 2018-10-23 14:12:18 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:12:18 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:12:18 --> Utf8 Class Initialized
INFO - 2018-10-23 14:12:18 --> URI Class Initialized
INFO - 2018-10-23 14:12:18 --> Router Class Initialized
INFO - 2018-10-23 14:12:18 --> Output Class Initialized
INFO - 2018-10-23 14:12:18 --> Security Class Initialized
DEBUG - 2018-10-23 14:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:12:18 --> CSRF cookie sent
INFO - 2018-10-23 14:12:18 --> Input Class Initialized
INFO - 2018-10-23 14:12:18 --> Language Class Initialized
INFO - 2018-10-23 14:12:18 --> Loader Class Initialized
INFO - 2018-10-23 14:12:18 --> Helper loaded: url_helper
INFO - 2018-10-23 14:12:18 --> Helper loaded: form_helper
INFO - 2018-10-23 14:12:18 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:12:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:12:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:12:18 --> User Agent Class Initialized
INFO - 2018-10-23 14:12:18 --> Controller Class Initialized
INFO - 2018-10-23 14:12:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:12:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:12:18 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:12:18 --> Pixel_Model class loaded
INFO - 2018-10-23 14:12:18 --> Database Driver Class Initialized
INFO - 2018-10-23 14:12:18 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:12:18 --> Database Driver Class Initialized
INFO - 2018-10-23 14:12:18 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:12:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:12:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:12:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:12:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:12:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:12:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:12:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-23 14:12:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:12:18 --> Final output sent to browser
DEBUG - 2018-10-23 14:12:19 --> Total execution time: 0.3919
INFO - 2018-10-23 14:12:20 --> Config Class Initialized
INFO - 2018-10-23 14:12:20 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:12:20 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:12:20 --> Utf8 Class Initialized
INFO - 2018-10-23 14:12:20 --> URI Class Initialized
INFO - 2018-10-23 14:12:20 --> Router Class Initialized
INFO - 2018-10-23 14:12:20 --> Output Class Initialized
INFO - 2018-10-23 14:12:20 --> Security Class Initialized
DEBUG - 2018-10-23 14:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:12:20 --> CSRF cookie sent
INFO - 2018-10-23 14:12:20 --> Input Class Initialized
INFO - 2018-10-23 14:12:20 --> Language Class Initialized
INFO - 2018-10-23 14:12:20 --> Loader Class Initialized
INFO - 2018-10-23 14:12:20 --> Helper loaded: url_helper
INFO - 2018-10-23 14:12:20 --> Helper loaded: form_helper
INFO - 2018-10-23 14:12:20 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:12:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:12:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:12:20 --> User Agent Class Initialized
INFO - 2018-10-23 14:12:20 --> Controller Class Initialized
INFO - 2018-10-23 14:12:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:12:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:12:20 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:12:20 --> Pixel_Model class loaded
INFO - 2018-10-23 14:12:20 --> Database Driver Class Initialized
INFO - 2018-10-23 14:12:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:12:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:12:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:12:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:12:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:12:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:12:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:12:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-23 14:12:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:12:20 --> Final output sent to browser
DEBUG - 2018-10-23 14:12:20 --> Total execution time: 0.3914
INFO - 2018-10-23 14:12:20 --> Config Class Initialized
INFO - 2018-10-23 14:12:20 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:12:20 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:12:20 --> Utf8 Class Initialized
INFO - 2018-10-23 14:12:20 --> URI Class Initialized
DEBUG - 2018-10-23 14:12:20 --> No URI present. Default controller set.
INFO - 2018-10-23 14:12:20 --> Router Class Initialized
INFO - 2018-10-23 14:12:20 --> Output Class Initialized
INFO - 2018-10-23 14:12:20 --> Security Class Initialized
DEBUG - 2018-10-23 14:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:12:20 --> CSRF cookie sent
INFO - 2018-10-23 14:12:20 --> Input Class Initialized
INFO - 2018-10-23 14:12:20 --> Language Class Initialized
INFO - 2018-10-23 14:12:20 --> Loader Class Initialized
INFO - 2018-10-23 14:12:20 --> Helper loaded: url_helper
INFO - 2018-10-23 14:12:20 --> Helper loaded: form_helper
INFO - 2018-10-23 14:12:20 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:12:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:12:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:12:21 --> User Agent Class Initialized
INFO - 2018-10-23 14:12:21 --> Controller Class Initialized
INFO - 2018-10-23 14:12:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:12:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:12:21 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:12:21 --> Pixel_Model class loaded
INFO - 2018-10-23 14:12:21 --> Database Driver Class Initialized
INFO - 2018-10-23 14:12:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:12:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:12:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:12:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-23 14:12:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:12:21 --> Final output sent to browser
DEBUG - 2018-10-23 14:12:21 --> Total execution time: 0.3817
INFO - 2018-10-23 14:12:24 --> Config Class Initialized
INFO - 2018-10-23 14:12:24 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:12:24 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:12:24 --> Utf8 Class Initialized
INFO - 2018-10-23 14:12:24 --> URI Class Initialized
INFO - 2018-10-23 14:12:24 --> Router Class Initialized
INFO - 2018-10-23 14:12:24 --> Output Class Initialized
INFO - 2018-10-23 14:12:24 --> Security Class Initialized
DEBUG - 2018-10-23 14:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:12:24 --> CSRF cookie sent
INFO - 2018-10-23 14:12:24 --> CSRF token verified
INFO - 2018-10-23 14:12:24 --> Input Class Initialized
INFO - 2018-10-23 14:12:24 --> Language Class Initialized
INFO - 2018-10-23 14:12:24 --> Loader Class Initialized
INFO - 2018-10-23 14:12:24 --> Helper loaded: url_helper
INFO - 2018-10-23 14:12:24 --> Helper loaded: form_helper
INFO - 2018-10-23 14:12:24 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:12:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:12:24 --> User Agent Class Initialized
INFO - 2018-10-23 14:12:24 --> Controller Class Initialized
INFO - 2018-10-23 14:12:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:12:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:12:24 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:12:24 --> Pixel_Model class loaded
INFO - 2018-10-23 14:12:24 --> Database Driver Class Initialized
INFO - 2018-10-23 14:12:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:12:24 --> Form Validation Class Initialized
INFO - 2018-10-23 14:12:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:12:24 --> Database Driver Class Initialized
INFO - 2018-10-23 14:12:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:12:24 --> Config Class Initialized
INFO - 2018-10-23 14:12:24 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:12:24 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:12:24 --> Utf8 Class Initialized
INFO - 2018-10-23 14:12:24 --> URI Class Initialized
INFO - 2018-10-23 14:12:24 --> Router Class Initialized
INFO - 2018-10-23 14:12:24 --> Output Class Initialized
INFO - 2018-10-23 14:12:24 --> Security Class Initialized
DEBUG - 2018-10-23 14:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:12:24 --> CSRF cookie sent
INFO - 2018-10-23 14:12:24 --> Input Class Initialized
INFO - 2018-10-23 14:12:24 --> Language Class Initialized
INFO - 2018-10-23 14:12:24 --> Loader Class Initialized
INFO - 2018-10-23 14:12:24 --> Helper loaded: url_helper
INFO - 2018-10-23 14:12:24 --> Helper loaded: form_helper
INFO - 2018-10-23 14:12:24 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:12:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:12:24 --> User Agent Class Initialized
INFO - 2018-10-23 14:12:24 --> Controller Class Initialized
INFO - 2018-10-23 14:12:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:12:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:12:24 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:12:24 --> Pixel_Model class loaded
INFO - 2018-10-23 14:12:24 --> Database Driver Class Initialized
INFO - 2018-10-23 14:12:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:12:24 --> Database Driver Class Initialized
INFO - 2018-10-23 14:12:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:12:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:12:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:12:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:12:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:12:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:12:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:12:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-23 14:12:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:12:24 --> Final output sent to browser
DEBUG - 2018-10-23 14:12:24 --> Total execution time: 0.4098
INFO - 2018-10-23 14:12:27 --> Config Class Initialized
INFO - 2018-10-23 14:12:27 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:12:27 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:12:27 --> Utf8 Class Initialized
INFO - 2018-10-23 14:12:27 --> URI Class Initialized
INFO - 2018-10-23 14:12:27 --> Router Class Initialized
INFO - 2018-10-23 14:12:27 --> Output Class Initialized
INFO - 2018-10-23 14:12:27 --> Security Class Initialized
DEBUG - 2018-10-23 14:12:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:12:27 --> CSRF cookie sent
INFO - 2018-10-23 14:12:27 --> Input Class Initialized
INFO - 2018-10-23 14:12:27 --> Language Class Initialized
INFO - 2018-10-23 14:12:27 --> Loader Class Initialized
INFO - 2018-10-23 14:12:27 --> Helper loaded: url_helper
INFO - 2018-10-23 14:12:27 --> Helper loaded: form_helper
INFO - 2018-10-23 14:12:27 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:12:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:12:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:12:27 --> User Agent Class Initialized
INFO - 2018-10-23 14:12:27 --> Controller Class Initialized
INFO - 2018-10-23 14:12:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:12:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:12:27 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:12:27 --> Pixel_Model class loaded
INFO - 2018-10-23 14:12:27 --> Database Driver Class Initialized
INFO - 2018-10-23 14:12:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:12:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:12:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:12:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:12:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:12:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:12:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:12:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-23 14:12:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:12:27 --> Final output sent to browser
DEBUG - 2018-10-23 14:12:27 --> Total execution time: 0.3456
INFO - 2018-10-23 14:13:05 --> Config Class Initialized
INFO - 2018-10-23 14:13:05 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:13:05 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:13:05 --> Utf8 Class Initialized
INFO - 2018-10-23 14:13:05 --> URI Class Initialized
DEBUG - 2018-10-23 14:13:05 --> No URI present. Default controller set.
INFO - 2018-10-23 14:13:05 --> Router Class Initialized
INFO - 2018-10-23 14:13:05 --> Output Class Initialized
INFO - 2018-10-23 14:13:05 --> Security Class Initialized
DEBUG - 2018-10-23 14:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:13:05 --> CSRF cookie sent
INFO - 2018-10-23 14:13:05 --> Input Class Initialized
INFO - 2018-10-23 14:13:05 --> Language Class Initialized
INFO - 2018-10-23 14:13:05 --> Loader Class Initialized
INFO - 2018-10-23 14:13:05 --> Helper loaded: url_helper
INFO - 2018-10-23 14:13:05 --> Helper loaded: form_helper
INFO - 2018-10-23 14:13:05 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:13:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:13:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:13:05 --> User Agent Class Initialized
INFO - 2018-10-23 14:13:05 --> Controller Class Initialized
INFO - 2018-10-23 14:13:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:13:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:13:05 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:13:05 --> Pixel_Model class loaded
INFO - 2018-10-23 14:13:05 --> Database Driver Class Initialized
INFO - 2018-10-23 14:13:05 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:13:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:13:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:13:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-23 14:13:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:13:05 --> Final output sent to browser
DEBUG - 2018-10-23 14:13:05 --> Total execution time: 0.3223
INFO - 2018-10-23 14:13:09 --> Config Class Initialized
INFO - 2018-10-23 14:13:09 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:13:09 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:13:09 --> Utf8 Class Initialized
INFO - 2018-10-23 14:13:09 --> URI Class Initialized
INFO - 2018-10-23 14:13:09 --> Router Class Initialized
INFO - 2018-10-23 14:13:09 --> Output Class Initialized
INFO - 2018-10-23 14:13:09 --> Security Class Initialized
DEBUG - 2018-10-23 14:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:13:09 --> CSRF cookie sent
INFO - 2018-10-23 14:13:09 --> CSRF token verified
INFO - 2018-10-23 14:13:09 --> Input Class Initialized
INFO - 2018-10-23 14:13:09 --> Language Class Initialized
INFO - 2018-10-23 14:13:09 --> Loader Class Initialized
INFO - 2018-10-23 14:13:09 --> Helper loaded: url_helper
INFO - 2018-10-23 14:13:09 --> Helper loaded: form_helper
INFO - 2018-10-23 14:13:09 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:13:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:13:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:13:09 --> User Agent Class Initialized
INFO - 2018-10-23 14:13:09 --> Controller Class Initialized
INFO - 2018-10-23 14:13:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:13:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:13:09 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:13:09 --> Pixel_Model class loaded
INFO - 2018-10-23 14:13:09 --> Database Driver Class Initialized
INFO - 2018-10-23 14:13:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:13:09 --> Form Validation Class Initialized
INFO - 2018-10-23 14:13:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:13:09 --> Database Driver Class Initialized
INFO - 2018-10-23 14:13:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:13:09 --> Config Class Initialized
INFO - 2018-10-23 14:13:09 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:13:09 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:13:09 --> Utf8 Class Initialized
INFO - 2018-10-23 14:13:09 --> URI Class Initialized
INFO - 2018-10-23 14:13:09 --> Router Class Initialized
INFO - 2018-10-23 14:13:09 --> Output Class Initialized
INFO - 2018-10-23 14:13:09 --> Security Class Initialized
DEBUG - 2018-10-23 14:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:13:09 --> CSRF cookie sent
INFO - 2018-10-23 14:13:09 --> Input Class Initialized
INFO - 2018-10-23 14:13:09 --> Language Class Initialized
INFO - 2018-10-23 14:13:09 --> Loader Class Initialized
INFO - 2018-10-23 14:13:09 --> Helper loaded: url_helper
INFO - 2018-10-23 14:13:09 --> Helper loaded: form_helper
INFO - 2018-10-23 14:13:09 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:13:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:13:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:13:09 --> User Agent Class Initialized
INFO - 2018-10-23 14:13:09 --> Controller Class Initialized
INFO - 2018-10-23 14:13:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:13:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:13:09 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:13:09 --> Pixel_Model class loaded
INFO - 2018-10-23 14:13:09 --> Database Driver Class Initialized
INFO - 2018-10-23 14:13:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:13:09 --> Database Driver Class Initialized
INFO - 2018-10-23 14:13:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:13:09 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:13:09 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:13:09 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:13:09 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:13:09 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:13:09 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:13:09 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-23 14:13:09 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:13:09 --> Final output sent to browser
DEBUG - 2018-10-23 14:13:09 --> Total execution time: 0.3944
INFO - 2018-10-23 14:13:11 --> Config Class Initialized
INFO - 2018-10-23 14:13:11 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:13:11 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:13:11 --> Utf8 Class Initialized
INFO - 2018-10-23 14:13:11 --> URI Class Initialized
DEBUG - 2018-10-23 14:13:11 --> No URI present. Default controller set.
INFO - 2018-10-23 14:13:11 --> Router Class Initialized
INFO - 2018-10-23 14:13:11 --> Output Class Initialized
INFO - 2018-10-23 14:13:11 --> Security Class Initialized
DEBUG - 2018-10-23 14:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:13:11 --> CSRF cookie sent
INFO - 2018-10-23 14:13:11 --> Input Class Initialized
INFO - 2018-10-23 14:13:11 --> Language Class Initialized
INFO - 2018-10-23 14:13:11 --> Loader Class Initialized
INFO - 2018-10-23 14:13:11 --> Helper loaded: url_helper
INFO - 2018-10-23 14:13:11 --> Helper loaded: form_helper
INFO - 2018-10-23 14:13:11 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:13:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:13:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:13:11 --> User Agent Class Initialized
INFO - 2018-10-23 14:13:11 --> Controller Class Initialized
INFO - 2018-10-23 14:13:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:13:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:13:11 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:13:11 --> Pixel_Model class loaded
INFO - 2018-10-23 14:13:11 --> Database Driver Class Initialized
INFO - 2018-10-23 14:13:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:13:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:13:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:13:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-23 14:13:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:13:11 --> Final output sent to browser
DEBUG - 2018-10-23 14:13:11 --> Total execution time: 0.3262
INFO - 2018-10-23 14:13:13 --> Config Class Initialized
INFO - 2018-10-23 14:13:13 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:13:13 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:13:13 --> Utf8 Class Initialized
INFO - 2018-10-23 14:13:13 --> URI Class Initialized
INFO - 2018-10-23 14:13:13 --> Router Class Initialized
INFO - 2018-10-23 14:13:13 --> Output Class Initialized
INFO - 2018-10-23 14:13:13 --> Security Class Initialized
DEBUG - 2018-10-23 14:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:13:13 --> CSRF cookie sent
INFO - 2018-10-23 14:13:13 --> Input Class Initialized
INFO - 2018-10-23 14:13:13 --> Language Class Initialized
INFO - 2018-10-23 14:13:13 --> Loader Class Initialized
INFO - 2018-10-23 14:13:13 --> Helper loaded: url_helper
INFO - 2018-10-23 14:13:13 --> Helper loaded: form_helper
INFO - 2018-10-23 14:13:13 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:13:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:13:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:13:13 --> User Agent Class Initialized
INFO - 2018-10-23 14:13:13 --> Controller Class Initialized
INFO - 2018-10-23 14:13:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:13:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:13:13 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:13:13 --> Pixel_Model class loaded
INFO - 2018-10-23 14:13:13 --> Database Driver Class Initialized
INFO - 2018-10-23 14:13:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:13:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:13:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:13:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:13:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:13:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:13:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:13:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-23 14:13:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:13:13 --> Final output sent to browser
DEBUG - 2018-10-23 14:13:13 --> Total execution time: 0.4376
INFO - 2018-10-23 14:13:15 --> Config Class Initialized
INFO - 2018-10-23 14:13:15 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:13:15 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:13:15 --> Utf8 Class Initialized
INFO - 2018-10-23 14:13:15 --> URI Class Initialized
INFO - 2018-10-23 14:13:15 --> Router Class Initialized
INFO - 2018-10-23 14:13:15 --> Output Class Initialized
INFO - 2018-10-23 14:13:15 --> Security Class Initialized
DEBUG - 2018-10-23 14:13:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:13:15 --> CSRF cookie sent
INFO - 2018-10-23 14:13:15 --> CSRF token verified
INFO - 2018-10-23 14:13:15 --> Input Class Initialized
INFO - 2018-10-23 14:13:15 --> Language Class Initialized
INFO - 2018-10-23 14:13:15 --> Loader Class Initialized
INFO - 2018-10-23 14:13:15 --> Helper loaded: url_helper
INFO - 2018-10-23 14:13:15 --> Helper loaded: form_helper
INFO - 2018-10-23 14:13:15 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:13:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:13:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:13:15 --> User Agent Class Initialized
INFO - 2018-10-23 14:13:15 --> Controller Class Initialized
INFO - 2018-10-23 14:13:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:13:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:13:15 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:13:15 --> Pixel_Model class loaded
INFO - 2018-10-23 14:13:15 --> Database Driver Class Initialized
INFO - 2018-10-23 14:13:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:13:15 --> Form Validation Class Initialized
INFO - 2018-10-23 14:13:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:13:15 --> Database Driver Class Initialized
INFO - 2018-10-23 14:13:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:13:15 --> Config Class Initialized
INFO - 2018-10-23 14:13:15 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:13:15 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:13:15 --> Utf8 Class Initialized
INFO - 2018-10-23 14:13:15 --> URI Class Initialized
INFO - 2018-10-23 14:13:15 --> Router Class Initialized
INFO - 2018-10-23 14:13:15 --> Output Class Initialized
INFO - 2018-10-23 14:13:15 --> Security Class Initialized
DEBUG - 2018-10-23 14:13:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:13:15 --> CSRF cookie sent
INFO - 2018-10-23 14:13:15 --> Input Class Initialized
INFO - 2018-10-23 14:13:15 --> Language Class Initialized
INFO - 2018-10-23 14:13:15 --> Loader Class Initialized
INFO - 2018-10-23 14:13:15 --> Helper loaded: url_helper
INFO - 2018-10-23 14:13:15 --> Helper loaded: form_helper
INFO - 2018-10-23 14:13:15 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:13:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:13:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:13:15 --> User Agent Class Initialized
INFO - 2018-10-23 14:13:15 --> Controller Class Initialized
INFO - 2018-10-23 14:13:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:13:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:13:15 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:13:15 --> Pixel_Model class loaded
INFO - 2018-10-23 14:13:15 --> Database Driver Class Initialized
INFO - 2018-10-23 14:13:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:13:15 --> Database Driver Class Initialized
INFO - 2018-10-23 14:13:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:13:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:13:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:13:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:13:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:13:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:13:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:13:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-23 14:13:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:13:16 --> Final output sent to browser
DEBUG - 2018-10-23 14:13:16 --> Total execution time: 0.3778
INFO - 2018-10-23 14:13:21 --> Config Class Initialized
INFO - 2018-10-23 14:13:21 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:13:21 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:13:21 --> Utf8 Class Initialized
INFO - 2018-10-23 14:13:21 --> URI Class Initialized
INFO - 2018-10-23 14:13:21 --> Router Class Initialized
INFO - 2018-10-23 14:13:21 --> Output Class Initialized
INFO - 2018-10-23 14:13:21 --> Security Class Initialized
DEBUG - 2018-10-23 14:13:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:13:21 --> CSRF cookie sent
INFO - 2018-10-23 14:13:21 --> CSRF token verified
INFO - 2018-10-23 14:13:21 --> Input Class Initialized
INFO - 2018-10-23 14:13:21 --> Language Class Initialized
INFO - 2018-10-23 14:13:21 --> Loader Class Initialized
INFO - 2018-10-23 14:13:21 --> Helper loaded: url_helper
INFO - 2018-10-23 14:13:21 --> Helper loaded: form_helper
INFO - 2018-10-23 14:13:21 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:13:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:13:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:13:21 --> User Agent Class Initialized
INFO - 2018-10-23 14:13:21 --> Controller Class Initialized
INFO - 2018-10-23 14:13:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:13:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:13:21 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:13:21 --> Pixel_Model class loaded
INFO - 2018-10-23 14:13:21 --> Database Driver Class Initialized
INFO - 2018-10-23 14:13:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:13:21 --> Form Validation Class Initialized
INFO - 2018-10-23 14:13:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:13:21 --> Database Driver Class Initialized
INFO - 2018-10-23 14:13:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:13:21 --> Config Class Initialized
INFO - 2018-10-23 14:13:21 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:13:21 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:13:21 --> Utf8 Class Initialized
INFO - 2018-10-23 14:13:21 --> URI Class Initialized
INFO - 2018-10-23 14:13:21 --> Router Class Initialized
INFO - 2018-10-23 14:13:21 --> Output Class Initialized
INFO - 2018-10-23 14:13:21 --> Security Class Initialized
DEBUG - 2018-10-23 14:13:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:13:21 --> CSRF cookie sent
INFO - 2018-10-23 14:13:21 --> Input Class Initialized
INFO - 2018-10-23 14:13:21 --> Language Class Initialized
INFO - 2018-10-23 14:13:21 --> Loader Class Initialized
INFO - 2018-10-23 14:13:21 --> Helper loaded: url_helper
INFO - 2018-10-23 14:13:21 --> Helper loaded: form_helper
INFO - 2018-10-23 14:13:21 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:13:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:13:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:13:21 --> User Agent Class Initialized
INFO - 2018-10-23 14:13:21 --> Controller Class Initialized
INFO - 2018-10-23 14:13:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:13:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:13:21 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:13:21 --> Pixel_Model class loaded
INFO - 2018-10-23 14:13:21 --> Database Driver Class Initialized
INFO - 2018-10-23 14:13:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:13:21 --> Database Driver Class Initialized
INFO - 2018-10-23 14:13:22 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:13:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:13:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:13:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:13:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:13:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:13:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:13:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/your_job.php
INFO - 2018-10-23 14:13:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:13:22 --> Final output sent to browser
DEBUG - 2018-10-23 14:13:22 --> Total execution time: 0.3952
INFO - 2018-10-23 14:13:23 --> Config Class Initialized
INFO - 2018-10-23 14:13:23 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:13:23 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:13:23 --> Utf8 Class Initialized
INFO - 2018-10-23 14:13:23 --> URI Class Initialized
INFO - 2018-10-23 14:13:23 --> Router Class Initialized
INFO - 2018-10-23 14:13:23 --> Output Class Initialized
INFO - 2018-10-23 14:13:23 --> Security Class Initialized
DEBUG - 2018-10-23 14:13:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:13:23 --> CSRF cookie sent
INFO - 2018-10-23 14:13:23 --> CSRF token verified
INFO - 2018-10-23 14:13:24 --> Input Class Initialized
INFO - 2018-10-23 14:13:24 --> Language Class Initialized
INFO - 2018-10-23 14:13:24 --> Loader Class Initialized
INFO - 2018-10-23 14:13:24 --> Helper loaded: url_helper
INFO - 2018-10-23 14:13:24 --> Helper loaded: form_helper
INFO - 2018-10-23 14:13:24 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:13:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:13:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:13:24 --> User Agent Class Initialized
INFO - 2018-10-23 14:13:24 --> Controller Class Initialized
INFO - 2018-10-23 14:13:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:13:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:13:24 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:13:24 --> Pixel_Model class loaded
INFO - 2018-10-23 14:13:24 --> Database Driver Class Initialized
INFO - 2018-10-23 14:13:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:13:24 --> Form Validation Class Initialized
INFO - 2018-10-23 14:13:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:13:24 --> Database Driver Class Initialized
INFO - 2018-10-23 14:13:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:13:24 --> Config Class Initialized
INFO - 2018-10-23 14:13:24 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:13:24 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:13:24 --> Utf8 Class Initialized
INFO - 2018-10-23 14:13:24 --> URI Class Initialized
INFO - 2018-10-23 14:13:24 --> Router Class Initialized
INFO - 2018-10-23 14:13:24 --> Output Class Initialized
INFO - 2018-10-23 14:13:24 --> Security Class Initialized
DEBUG - 2018-10-23 14:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:13:24 --> CSRF cookie sent
INFO - 2018-10-23 14:13:24 --> Input Class Initialized
INFO - 2018-10-23 14:13:24 --> Language Class Initialized
INFO - 2018-10-23 14:13:24 --> Loader Class Initialized
INFO - 2018-10-23 14:13:24 --> Helper loaded: url_helper
INFO - 2018-10-23 14:13:24 --> Helper loaded: form_helper
INFO - 2018-10-23 14:13:24 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:13:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:13:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:13:24 --> User Agent Class Initialized
INFO - 2018-10-23 14:13:24 --> Controller Class Initialized
INFO - 2018-10-23 14:13:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:13:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:13:24 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:13:24 --> Pixel_Model class loaded
INFO - 2018-10-23 14:13:24 --> Database Driver Class Initialized
INFO - 2018-10-23 14:13:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:13:24 --> Database Driver Class Initialized
INFO - 2018-10-23 14:13:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:13:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:13:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:13:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner.php
INFO - 2018-10-23 14:13:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:13:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:13:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:13:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:13:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/relation_ship_status.php
INFO - 2018-10-23 14:13:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:13:24 --> Final output sent to browser
DEBUG - 2018-10-23 14:13:24 --> Total execution time: 0.4157
INFO - 2018-10-23 14:13:45 --> Config Class Initialized
INFO - 2018-10-23 14:13:45 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:13:45 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:13:45 --> Utf8 Class Initialized
INFO - 2018-10-23 14:13:45 --> URI Class Initialized
INFO - 2018-10-23 14:13:45 --> Router Class Initialized
INFO - 2018-10-23 14:13:45 --> Output Class Initialized
INFO - 2018-10-23 14:13:45 --> Security Class Initialized
DEBUG - 2018-10-23 14:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:13:45 --> CSRF cookie sent
INFO - 2018-10-23 14:13:45 --> CSRF token verified
INFO - 2018-10-23 14:13:45 --> Input Class Initialized
INFO - 2018-10-23 14:13:45 --> Language Class Initialized
INFO - 2018-10-23 14:13:45 --> Loader Class Initialized
INFO - 2018-10-23 14:13:45 --> Helper loaded: url_helper
INFO - 2018-10-23 14:13:45 --> Helper loaded: form_helper
INFO - 2018-10-23 14:13:45 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:13:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:13:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:13:45 --> User Agent Class Initialized
INFO - 2018-10-23 14:13:45 --> Controller Class Initialized
INFO - 2018-10-23 14:13:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:13:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:13:45 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:13:45 --> Pixel_Model class loaded
INFO - 2018-10-23 14:13:45 --> Database Driver Class Initialized
INFO - 2018-10-23 14:13:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:13:45 --> Form Validation Class Initialized
INFO - 2018-10-23 14:13:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:13:45 --> Database Driver Class Initialized
INFO - 2018-10-23 14:13:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:13:45 --> Config Class Initialized
INFO - 2018-10-23 14:13:45 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:13:45 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:13:45 --> Utf8 Class Initialized
INFO - 2018-10-23 14:13:45 --> URI Class Initialized
INFO - 2018-10-23 14:13:45 --> Router Class Initialized
INFO - 2018-10-23 14:13:45 --> Output Class Initialized
INFO - 2018-10-23 14:13:45 --> Security Class Initialized
DEBUG - 2018-10-23 14:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:13:45 --> CSRF cookie sent
INFO - 2018-10-23 14:13:45 --> Input Class Initialized
INFO - 2018-10-23 14:13:45 --> Language Class Initialized
INFO - 2018-10-23 14:13:45 --> Loader Class Initialized
INFO - 2018-10-23 14:13:45 --> Helper loaded: url_helper
INFO - 2018-10-23 14:13:45 --> Helper loaded: form_helper
INFO - 2018-10-23 14:13:45 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:13:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:13:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:13:45 --> User Agent Class Initialized
INFO - 2018-10-23 14:13:45 --> Controller Class Initialized
INFO - 2018-10-23 14:13:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:13:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:13:45 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:13:45 --> Pixel_Model class loaded
INFO - 2018-10-23 14:13:45 --> Database Driver Class Initialized
INFO - 2018-10-23 14:13:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:13:45 --> Database Driver Class Initialized
INFO - 2018-10-23 14:13:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:13:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:13:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:13:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:13:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:13:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:13:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:13:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/income.php
INFO - 2018-10-23 14:13:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:13:46 --> Final output sent to browser
DEBUG - 2018-10-23 14:13:46 --> Total execution time: 0.6036
INFO - 2018-10-23 14:13:52 --> Config Class Initialized
INFO - 2018-10-23 14:13:52 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:13:52 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:13:53 --> Utf8 Class Initialized
INFO - 2018-10-23 14:13:53 --> URI Class Initialized
INFO - 2018-10-23 14:13:53 --> Router Class Initialized
INFO - 2018-10-23 14:13:53 --> Output Class Initialized
INFO - 2018-10-23 14:13:53 --> Security Class Initialized
DEBUG - 2018-10-23 14:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:13:53 --> CSRF cookie sent
INFO - 2018-10-23 14:13:53 --> CSRF token verified
INFO - 2018-10-23 14:13:53 --> Input Class Initialized
INFO - 2018-10-23 14:13:53 --> Language Class Initialized
INFO - 2018-10-23 14:13:53 --> Loader Class Initialized
INFO - 2018-10-23 14:13:53 --> Helper loaded: url_helper
INFO - 2018-10-23 14:13:53 --> Helper loaded: form_helper
INFO - 2018-10-23 14:13:53 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:13:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:13:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:13:53 --> User Agent Class Initialized
INFO - 2018-10-23 14:13:53 --> Controller Class Initialized
INFO - 2018-10-23 14:13:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:13:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:13:53 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:13:53 --> Pixel_Model class loaded
INFO - 2018-10-23 14:13:53 --> Database Driver Class Initialized
INFO - 2018-10-23 14:13:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:13:53 --> Form Validation Class Initialized
INFO - 2018-10-23 14:13:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:13:53 --> Database Driver Class Initialized
INFO - 2018-10-23 14:13:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:13:53 --> Config Class Initialized
INFO - 2018-10-23 14:13:53 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:13:53 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:13:53 --> Utf8 Class Initialized
INFO - 2018-10-23 14:13:53 --> URI Class Initialized
INFO - 2018-10-23 14:13:53 --> Router Class Initialized
INFO - 2018-10-23 14:13:53 --> Output Class Initialized
INFO - 2018-10-23 14:13:53 --> Security Class Initialized
DEBUG - 2018-10-23 14:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:13:53 --> CSRF cookie sent
INFO - 2018-10-23 14:13:53 --> Input Class Initialized
INFO - 2018-10-23 14:13:53 --> Language Class Initialized
INFO - 2018-10-23 14:13:53 --> Loader Class Initialized
INFO - 2018-10-23 14:13:53 --> Helper loaded: url_helper
INFO - 2018-10-23 14:13:53 --> Helper loaded: form_helper
INFO - 2018-10-23 14:13:53 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:13:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:13:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:13:53 --> User Agent Class Initialized
INFO - 2018-10-23 14:13:53 --> Controller Class Initialized
INFO - 2018-10-23 14:13:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:13:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:13:53 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:13:53 --> Pixel_Model class loaded
INFO - 2018-10-23 14:13:53 --> Database Driver Class Initialized
INFO - 2018-10-23 14:13:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:13:53 --> Database Driver Class Initialized
INFO - 2018-10-23 14:13:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:13:53 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:13:53 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:13:53 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:13:53 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:13:53 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:13:53 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:13:53 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/marriage.php
INFO - 2018-10-23 14:13:53 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:13:53 --> Final output sent to browser
DEBUG - 2018-10-23 14:13:53 --> Total execution time: 0.4860
INFO - 2018-10-23 14:14:06 --> Config Class Initialized
INFO - 2018-10-23 14:14:06 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:14:06 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:14:06 --> Utf8 Class Initialized
INFO - 2018-10-23 14:14:06 --> URI Class Initialized
INFO - 2018-10-23 14:14:06 --> Router Class Initialized
INFO - 2018-10-23 14:14:06 --> Output Class Initialized
INFO - 2018-10-23 14:14:06 --> Security Class Initialized
DEBUG - 2018-10-23 14:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:14:06 --> CSRF cookie sent
INFO - 2018-10-23 14:14:06 --> Input Class Initialized
INFO - 2018-10-23 14:14:06 --> Language Class Initialized
INFO - 2018-10-23 14:14:06 --> Loader Class Initialized
INFO - 2018-10-23 14:14:06 --> Helper loaded: url_helper
INFO - 2018-10-23 14:14:06 --> Helper loaded: form_helper
INFO - 2018-10-23 14:14:06 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:14:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:14:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:14:06 --> User Agent Class Initialized
INFO - 2018-10-23 14:14:06 --> Controller Class Initialized
INFO - 2018-10-23 14:14:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:14:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:14:06 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:14:06 --> Pixel_Model class loaded
INFO - 2018-10-23 14:14:06 --> Database Driver Class Initialized
INFO - 2018-10-23 14:14:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:14:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:14:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:14:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:14:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:14:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:14:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:14:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-23 14:14:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:14:07 --> Final output sent to browser
DEBUG - 2018-10-23 14:14:07 --> Total execution time: 0.3757
INFO - 2018-10-23 14:14:08 --> Config Class Initialized
INFO - 2018-10-23 14:14:08 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:14:08 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:14:09 --> Utf8 Class Initialized
INFO - 2018-10-23 14:14:09 --> URI Class Initialized
INFO - 2018-10-23 14:14:09 --> Router Class Initialized
INFO - 2018-10-23 14:14:09 --> Output Class Initialized
INFO - 2018-10-23 14:14:09 --> Security Class Initialized
DEBUG - 2018-10-23 14:14:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:14:09 --> CSRF cookie sent
INFO - 2018-10-23 14:14:09 --> CSRF token verified
INFO - 2018-10-23 14:14:09 --> Input Class Initialized
INFO - 2018-10-23 14:14:09 --> Language Class Initialized
INFO - 2018-10-23 14:14:09 --> Loader Class Initialized
INFO - 2018-10-23 14:14:09 --> Helper loaded: url_helper
INFO - 2018-10-23 14:14:09 --> Helper loaded: form_helper
INFO - 2018-10-23 14:14:09 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:14:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:14:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:14:09 --> User Agent Class Initialized
INFO - 2018-10-23 14:14:09 --> Controller Class Initialized
INFO - 2018-10-23 14:14:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:14:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:14:09 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:14:09 --> Pixel_Model class loaded
INFO - 2018-10-23 14:14:09 --> Database Driver Class Initialized
INFO - 2018-10-23 14:14:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:14:09 --> Form Validation Class Initialized
INFO - 2018-10-23 14:14:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:14:09 --> Database Driver Class Initialized
INFO - 2018-10-23 14:14:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:14:09 --> Config Class Initialized
INFO - 2018-10-23 14:14:09 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:14:09 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:14:09 --> Utf8 Class Initialized
INFO - 2018-10-23 14:14:09 --> URI Class Initialized
INFO - 2018-10-23 14:14:09 --> Router Class Initialized
INFO - 2018-10-23 14:14:09 --> Output Class Initialized
INFO - 2018-10-23 14:14:09 --> Security Class Initialized
DEBUG - 2018-10-23 14:14:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:14:09 --> CSRF cookie sent
INFO - 2018-10-23 14:14:09 --> Input Class Initialized
INFO - 2018-10-23 14:14:09 --> Language Class Initialized
INFO - 2018-10-23 14:14:09 --> Loader Class Initialized
INFO - 2018-10-23 14:14:09 --> Helper loaded: url_helper
INFO - 2018-10-23 14:14:09 --> Helper loaded: form_helper
INFO - 2018-10-23 14:14:09 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:14:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:14:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:14:09 --> User Agent Class Initialized
INFO - 2018-10-23 14:14:09 --> Controller Class Initialized
INFO - 2018-10-23 14:14:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:14:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:14:09 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:14:09 --> Pixel_Model class loaded
INFO - 2018-10-23 14:14:09 --> Database Driver Class Initialized
INFO - 2018-10-23 14:14:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:14:09 --> Database Driver Class Initialized
INFO - 2018-10-23 14:14:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:14:09 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:14:09 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:14:09 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:14:09 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:14:09 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:14:09 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:14:09 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-23 14:14:09 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:14:09 --> Final output sent to browser
DEBUG - 2018-10-23 14:14:09 --> Total execution time: 0.3805
INFO - 2018-10-23 14:14:12 --> Config Class Initialized
INFO - 2018-10-23 14:14:12 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:14:12 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:14:12 --> Utf8 Class Initialized
INFO - 2018-10-23 14:14:12 --> URI Class Initialized
INFO - 2018-10-23 14:14:12 --> Router Class Initialized
INFO - 2018-10-23 14:14:12 --> Output Class Initialized
INFO - 2018-10-23 14:14:12 --> Security Class Initialized
DEBUG - 2018-10-23 14:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:14:12 --> CSRF cookie sent
INFO - 2018-10-23 14:14:12 --> CSRF token verified
INFO - 2018-10-23 14:14:12 --> Input Class Initialized
INFO - 2018-10-23 14:14:12 --> Language Class Initialized
INFO - 2018-10-23 14:14:12 --> Loader Class Initialized
INFO - 2018-10-23 14:14:12 --> Helper loaded: url_helper
INFO - 2018-10-23 14:14:12 --> Helper loaded: form_helper
INFO - 2018-10-23 14:14:12 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:14:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:14:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:14:12 --> User Agent Class Initialized
INFO - 2018-10-23 14:14:12 --> Controller Class Initialized
INFO - 2018-10-23 14:14:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:14:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:14:12 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:14:12 --> Pixel_Model class loaded
INFO - 2018-10-23 14:14:12 --> Database Driver Class Initialized
INFO - 2018-10-23 14:14:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:14:12 --> Form Validation Class Initialized
INFO - 2018-10-23 14:14:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:14:12 --> Database Driver Class Initialized
INFO - 2018-10-23 14:14:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:14:12 --> Config Class Initialized
INFO - 2018-10-23 14:14:12 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:14:12 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:14:12 --> Utf8 Class Initialized
INFO - 2018-10-23 14:14:12 --> URI Class Initialized
INFO - 2018-10-23 14:14:12 --> Router Class Initialized
INFO - 2018-10-23 14:14:12 --> Output Class Initialized
INFO - 2018-10-23 14:14:12 --> Security Class Initialized
DEBUG - 2018-10-23 14:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:14:12 --> CSRF cookie sent
INFO - 2018-10-23 14:14:12 --> Input Class Initialized
INFO - 2018-10-23 14:14:12 --> Language Class Initialized
INFO - 2018-10-23 14:14:12 --> Loader Class Initialized
INFO - 2018-10-23 14:14:12 --> Helper loaded: url_helper
INFO - 2018-10-23 14:14:12 --> Helper loaded: form_helper
INFO - 2018-10-23 14:14:12 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:14:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:14:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:14:12 --> User Agent Class Initialized
INFO - 2018-10-23 14:14:12 --> Controller Class Initialized
INFO - 2018-10-23 14:14:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:14:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:14:12 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:14:13 --> Pixel_Model class loaded
INFO - 2018-10-23 14:14:13 --> Database Driver Class Initialized
INFO - 2018-10-23 14:14:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:14:13 --> Database Driver Class Initialized
INFO - 2018-10-23 14:14:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:14:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:14:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:14:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:14:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:14:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:14:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:14:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/your_job.php
INFO - 2018-10-23 14:14:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:14:13 --> Final output sent to browser
DEBUG - 2018-10-23 14:14:13 --> Total execution time: 0.3755
INFO - 2018-10-23 14:14:15 --> Config Class Initialized
INFO - 2018-10-23 14:14:15 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:14:15 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:14:15 --> Utf8 Class Initialized
INFO - 2018-10-23 14:14:15 --> URI Class Initialized
INFO - 2018-10-23 14:14:15 --> Router Class Initialized
INFO - 2018-10-23 14:14:15 --> Output Class Initialized
INFO - 2018-10-23 14:14:15 --> Security Class Initialized
DEBUG - 2018-10-23 14:14:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:14:15 --> CSRF cookie sent
INFO - 2018-10-23 14:14:15 --> CSRF token verified
INFO - 2018-10-23 14:14:15 --> Input Class Initialized
INFO - 2018-10-23 14:14:15 --> Language Class Initialized
INFO - 2018-10-23 14:14:15 --> Loader Class Initialized
INFO - 2018-10-23 14:14:15 --> Helper loaded: url_helper
INFO - 2018-10-23 14:14:15 --> Helper loaded: form_helper
INFO - 2018-10-23 14:14:15 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:14:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:14:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:14:15 --> User Agent Class Initialized
INFO - 2018-10-23 14:14:15 --> Controller Class Initialized
INFO - 2018-10-23 14:14:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:14:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:14:15 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:14:15 --> Pixel_Model class loaded
INFO - 2018-10-23 14:14:15 --> Database Driver Class Initialized
INFO - 2018-10-23 14:14:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:14:15 --> Form Validation Class Initialized
INFO - 2018-10-23 14:14:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:14:15 --> Database Driver Class Initialized
INFO - 2018-10-23 14:14:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:14:15 --> Config Class Initialized
INFO - 2018-10-23 14:14:15 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:14:15 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:14:15 --> Utf8 Class Initialized
INFO - 2018-10-23 14:14:15 --> URI Class Initialized
INFO - 2018-10-23 14:14:15 --> Router Class Initialized
INFO - 2018-10-23 14:14:15 --> Output Class Initialized
INFO - 2018-10-23 14:14:15 --> Security Class Initialized
DEBUG - 2018-10-23 14:14:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:14:15 --> CSRF cookie sent
INFO - 2018-10-23 14:14:15 --> Input Class Initialized
INFO - 2018-10-23 14:14:15 --> Language Class Initialized
INFO - 2018-10-23 14:14:15 --> Loader Class Initialized
INFO - 2018-10-23 14:14:15 --> Helper loaded: url_helper
INFO - 2018-10-23 14:14:15 --> Helper loaded: form_helper
INFO - 2018-10-23 14:14:15 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:14:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:14:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:14:15 --> User Agent Class Initialized
INFO - 2018-10-23 14:14:15 --> Controller Class Initialized
INFO - 2018-10-23 14:14:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:14:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:14:15 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:14:15 --> Pixel_Model class loaded
INFO - 2018-10-23 14:14:15 --> Database Driver Class Initialized
INFO - 2018-10-23 14:14:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:14:15 --> Database Driver Class Initialized
INFO - 2018-10-23 14:14:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:14:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:14:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:14:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner.php
INFO - 2018-10-23 14:14:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:14:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:14:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:14:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:14:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/relation_ship_status.php
INFO - 2018-10-23 14:14:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:14:15 --> Final output sent to browser
DEBUG - 2018-10-23 14:14:15 --> Total execution time: 0.4040
INFO - 2018-10-23 14:14:18 --> Config Class Initialized
INFO - 2018-10-23 14:14:18 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:14:18 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:14:18 --> Utf8 Class Initialized
INFO - 2018-10-23 14:14:18 --> URI Class Initialized
INFO - 2018-10-23 14:14:18 --> Router Class Initialized
INFO - 2018-10-23 14:14:18 --> Output Class Initialized
INFO - 2018-10-23 14:14:18 --> Security Class Initialized
DEBUG - 2018-10-23 14:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:14:18 --> CSRF cookie sent
INFO - 2018-10-23 14:14:18 --> CSRF token verified
INFO - 2018-10-23 14:14:18 --> Input Class Initialized
INFO - 2018-10-23 14:14:18 --> Language Class Initialized
INFO - 2018-10-23 14:14:18 --> Loader Class Initialized
INFO - 2018-10-23 14:14:18 --> Helper loaded: url_helper
INFO - 2018-10-23 14:14:18 --> Helper loaded: form_helper
INFO - 2018-10-23 14:14:18 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:14:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:14:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:14:18 --> User Agent Class Initialized
INFO - 2018-10-23 14:14:18 --> Controller Class Initialized
INFO - 2018-10-23 14:14:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:14:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:14:18 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:14:18 --> Pixel_Model class loaded
INFO - 2018-10-23 14:14:18 --> Database Driver Class Initialized
INFO - 2018-10-23 14:14:18 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:14:18 --> Form Validation Class Initialized
INFO - 2018-10-23 14:14:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:14:18 --> Database Driver Class Initialized
INFO - 2018-10-23 14:14:18 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:14:18 --> Config Class Initialized
INFO - 2018-10-23 14:14:18 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:14:18 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:14:18 --> Utf8 Class Initialized
INFO - 2018-10-23 14:14:18 --> URI Class Initialized
INFO - 2018-10-23 14:14:18 --> Router Class Initialized
INFO - 2018-10-23 14:14:18 --> Output Class Initialized
INFO - 2018-10-23 14:14:18 --> Security Class Initialized
DEBUG - 2018-10-23 14:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:14:18 --> CSRF cookie sent
INFO - 2018-10-23 14:14:18 --> Input Class Initialized
INFO - 2018-10-23 14:14:18 --> Language Class Initialized
INFO - 2018-10-23 14:14:18 --> Loader Class Initialized
INFO - 2018-10-23 14:14:18 --> Helper loaded: url_helper
INFO - 2018-10-23 14:14:18 --> Helper loaded: form_helper
INFO - 2018-10-23 14:14:18 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:14:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:14:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:14:18 --> User Agent Class Initialized
INFO - 2018-10-23 14:14:18 --> Controller Class Initialized
INFO - 2018-10-23 14:14:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:14:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:14:18 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:14:18 --> Pixel_Model class loaded
INFO - 2018-10-23 14:14:18 --> Database Driver Class Initialized
INFO - 2018-10-23 14:14:18 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:14:18 --> Database Driver Class Initialized
INFO - 2018-10-23 14:14:18 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:14:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:14:19 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:14:19 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:14:19 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:14:19 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:14:19 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:14:19 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/income.php
INFO - 2018-10-23 14:14:19 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:14:19 --> Final output sent to browser
DEBUG - 2018-10-23 14:14:19 --> Total execution time: 0.3720
INFO - 2018-10-23 14:14:20 --> Config Class Initialized
INFO - 2018-10-23 14:14:20 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:14:20 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:14:20 --> Utf8 Class Initialized
INFO - 2018-10-23 14:14:20 --> URI Class Initialized
INFO - 2018-10-23 14:14:20 --> Router Class Initialized
INFO - 2018-10-23 14:14:20 --> Output Class Initialized
INFO - 2018-10-23 14:14:20 --> Security Class Initialized
DEBUG - 2018-10-23 14:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:14:20 --> CSRF cookie sent
INFO - 2018-10-23 14:14:20 --> CSRF token verified
INFO - 2018-10-23 14:14:20 --> Input Class Initialized
INFO - 2018-10-23 14:14:20 --> Language Class Initialized
INFO - 2018-10-23 14:14:20 --> Loader Class Initialized
INFO - 2018-10-23 14:14:20 --> Helper loaded: url_helper
INFO - 2018-10-23 14:14:20 --> Helper loaded: form_helper
INFO - 2018-10-23 14:14:20 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:14:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:14:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:14:20 --> User Agent Class Initialized
INFO - 2018-10-23 14:14:20 --> Controller Class Initialized
INFO - 2018-10-23 14:14:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:14:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:14:20 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:14:20 --> Pixel_Model class loaded
INFO - 2018-10-23 14:14:20 --> Database Driver Class Initialized
INFO - 2018-10-23 14:14:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:14:20 --> Form Validation Class Initialized
INFO - 2018-10-23 14:14:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:14:20 --> Database Driver Class Initialized
INFO - 2018-10-23 14:14:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:14:20 --> Config Class Initialized
INFO - 2018-10-23 14:14:20 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:14:20 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:14:20 --> Utf8 Class Initialized
INFO - 2018-10-23 14:14:20 --> URI Class Initialized
INFO - 2018-10-23 14:14:20 --> Router Class Initialized
INFO - 2018-10-23 14:14:20 --> Output Class Initialized
INFO - 2018-10-23 14:14:20 --> Security Class Initialized
DEBUG - 2018-10-23 14:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:14:20 --> CSRF cookie sent
INFO - 2018-10-23 14:14:20 --> Input Class Initialized
INFO - 2018-10-23 14:14:20 --> Language Class Initialized
INFO - 2018-10-23 14:14:20 --> Loader Class Initialized
INFO - 2018-10-23 14:14:20 --> Helper loaded: url_helper
INFO - 2018-10-23 14:14:20 --> Helper loaded: form_helper
INFO - 2018-10-23 14:14:20 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:14:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:14:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:14:20 --> User Agent Class Initialized
INFO - 2018-10-23 14:14:20 --> Controller Class Initialized
INFO - 2018-10-23 14:14:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:14:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:14:20 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:14:20 --> Pixel_Model class loaded
INFO - 2018-10-23 14:14:20 --> Database Driver Class Initialized
INFO - 2018-10-23 14:14:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:14:20 --> Database Driver Class Initialized
INFO - 2018-10-23 14:14:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:14:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:14:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:14:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:14:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:14:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:14:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:14:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/pension.php
INFO - 2018-10-23 14:14:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:14:21 --> Final output sent to browser
DEBUG - 2018-10-23 14:14:21 --> Total execution time: 0.5408
INFO - 2018-10-23 14:14:24 --> Config Class Initialized
INFO - 2018-10-23 14:14:24 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:14:24 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:14:24 --> Utf8 Class Initialized
INFO - 2018-10-23 14:14:24 --> URI Class Initialized
INFO - 2018-10-23 14:14:24 --> Router Class Initialized
INFO - 2018-10-23 14:14:24 --> Output Class Initialized
INFO - 2018-10-23 14:14:24 --> Security Class Initialized
DEBUG - 2018-10-23 14:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:14:24 --> CSRF cookie sent
INFO - 2018-10-23 14:14:24 --> CSRF token verified
INFO - 2018-10-23 14:14:24 --> Input Class Initialized
INFO - 2018-10-23 14:14:24 --> Language Class Initialized
INFO - 2018-10-23 14:14:24 --> Loader Class Initialized
INFO - 2018-10-23 14:14:24 --> Helper loaded: url_helper
INFO - 2018-10-23 14:14:24 --> Helper loaded: form_helper
INFO - 2018-10-23 14:14:24 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:14:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:14:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:14:24 --> User Agent Class Initialized
INFO - 2018-10-23 14:14:24 --> Controller Class Initialized
INFO - 2018-10-23 14:14:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:14:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:14:24 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:14:24 --> Pixel_Model class loaded
INFO - 2018-10-23 14:14:24 --> Database Driver Class Initialized
INFO - 2018-10-23 14:14:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:14:24 --> Form Validation Class Initialized
INFO - 2018-10-23 14:14:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:14:24 --> Database Driver Class Initialized
INFO - 2018-10-23 14:14:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:14:24 --> Config Class Initialized
INFO - 2018-10-23 14:14:24 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:14:24 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:14:24 --> Utf8 Class Initialized
INFO - 2018-10-23 14:14:24 --> URI Class Initialized
INFO - 2018-10-23 14:14:24 --> Router Class Initialized
INFO - 2018-10-23 14:14:24 --> Output Class Initialized
INFO - 2018-10-23 14:14:24 --> Security Class Initialized
DEBUG - 2018-10-23 14:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:14:24 --> CSRF cookie sent
INFO - 2018-10-23 14:14:24 --> Input Class Initialized
INFO - 2018-10-23 14:14:24 --> Language Class Initialized
INFO - 2018-10-23 14:14:24 --> Loader Class Initialized
INFO - 2018-10-23 14:14:24 --> Helper loaded: url_helper
INFO - 2018-10-23 14:14:24 --> Helper loaded: form_helper
INFO - 2018-10-23 14:14:24 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:14:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:14:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:14:24 --> User Agent Class Initialized
INFO - 2018-10-23 14:14:24 --> Controller Class Initialized
INFO - 2018-10-23 14:14:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:14:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:14:24 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:14:24 --> Pixel_Model class loaded
INFO - 2018-10-23 14:14:24 --> Database Driver Class Initialized
INFO - 2018-10-23 14:14:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:14:24 --> Database Driver Class Initialized
INFO - 2018-10-23 14:14:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:14:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:14:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:14:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:14:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:14:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:14:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:14:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/home_title.php
INFO - 2018-10-23 14:14:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:14:25 --> Final output sent to browser
DEBUG - 2018-10-23 14:14:25 --> Total execution time: 0.4331
INFO - 2018-10-23 14:15:22 --> Config Class Initialized
INFO - 2018-10-23 14:15:22 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:15:22 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:15:22 --> Utf8 Class Initialized
INFO - 2018-10-23 14:15:22 --> URI Class Initialized
INFO - 2018-10-23 14:15:22 --> Router Class Initialized
INFO - 2018-10-23 14:15:22 --> Output Class Initialized
INFO - 2018-10-23 14:15:22 --> Security Class Initialized
DEBUG - 2018-10-23 14:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:15:22 --> CSRF cookie sent
INFO - 2018-10-23 14:15:22 --> Input Class Initialized
INFO - 2018-10-23 14:15:22 --> Language Class Initialized
INFO - 2018-10-23 14:15:22 --> Loader Class Initialized
INFO - 2018-10-23 14:15:23 --> Helper loaded: url_helper
INFO - 2018-10-23 14:15:23 --> Helper loaded: form_helper
INFO - 2018-10-23 14:15:23 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:15:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:15:23 --> User Agent Class Initialized
INFO - 2018-10-23 14:15:23 --> Controller Class Initialized
INFO - 2018-10-23 14:15:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:15:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:15:23 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:15:23 --> Pixel_Model class loaded
INFO - 2018-10-23 14:15:23 --> Database Driver Class Initialized
INFO - 2018-10-23 14:15:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:15:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:15:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:15:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:15:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:15:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:15:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:15:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-23 14:15:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:15:23 --> Final output sent to browser
DEBUG - 2018-10-23 14:15:23 --> Total execution time: 0.3694
INFO - 2018-10-23 14:15:24 --> Config Class Initialized
INFO - 2018-10-23 14:15:24 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:15:24 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:15:24 --> Utf8 Class Initialized
INFO - 2018-10-23 14:15:24 --> URI Class Initialized
DEBUG - 2018-10-23 14:15:24 --> No URI present. Default controller set.
INFO - 2018-10-23 14:15:24 --> Router Class Initialized
INFO - 2018-10-23 14:15:24 --> Output Class Initialized
INFO - 2018-10-23 14:15:24 --> Security Class Initialized
DEBUG - 2018-10-23 14:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:15:24 --> CSRF cookie sent
INFO - 2018-10-23 14:15:24 --> Input Class Initialized
INFO - 2018-10-23 14:15:24 --> Language Class Initialized
INFO - 2018-10-23 14:15:24 --> Loader Class Initialized
INFO - 2018-10-23 14:15:24 --> Helper loaded: url_helper
INFO - 2018-10-23 14:15:24 --> Helper loaded: form_helper
INFO - 2018-10-23 14:15:24 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:15:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:15:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:15:25 --> User Agent Class Initialized
INFO - 2018-10-23 14:15:25 --> Controller Class Initialized
INFO - 2018-10-23 14:15:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:15:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:15:25 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:15:25 --> Pixel_Model class loaded
INFO - 2018-10-23 14:15:25 --> Database Driver Class Initialized
INFO - 2018-10-23 14:15:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:15:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:15:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:15:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-23 14:15:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:15:25 --> Final output sent to browser
DEBUG - 2018-10-23 14:15:25 --> Total execution time: 0.3357
INFO - 2018-10-23 14:15:26 --> Config Class Initialized
INFO - 2018-10-23 14:15:26 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:15:26 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:15:26 --> Utf8 Class Initialized
INFO - 2018-10-23 14:15:26 --> URI Class Initialized
INFO - 2018-10-23 14:15:26 --> Router Class Initialized
INFO - 2018-10-23 14:15:26 --> Output Class Initialized
INFO - 2018-10-23 14:15:26 --> Security Class Initialized
DEBUG - 2018-10-23 14:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:15:26 --> CSRF cookie sent
INFO - 2018-10-23 14:15:26 --> Input Class Initialized
INFO - 2018-10-23 14:15:26 --> Language Class Initialized
INFO - 2018-10-23 14:15:26 --> Loader Class Initialized
INFO - 2018-10-23 14:15:26 --> Helper loaded: url_helper
INFO - 2018-10-23 14:15:26 --> Helper loaded: form_helper
INFO - 2018-10-23 14:15:26 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:15:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:15:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:15:26 --> User Agent Class Initialized
INFO - 2018-10-23 14:15:26 --> Controller Class Initialized
INFO - 2018-10-23 14:15:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:15:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:15:27 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:15:27 --> Pixel_Model class loaded
INFO - 2018-10-23 14:15:27 --> Database Driver Class Initialized
INFO - 2018-10-23 14:15:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:15:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:15:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:15:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:15:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:15:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:15:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:15:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-23 14:15:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:15:27 --> Final output sent to browser
DEBUG - 2018-10-23 14:15:27 --> Total execution time: 0.4812
INFO - 2018-10-23 14:15:29 --> Config Class Initialized
INFO - 2018-10-23 14:15:29 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:15:29 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:15:29 --> Utf8 Class Initialized
INFO - 2018-10-23 14:15:29 --> URI Class Initialized
INFO - 2018-10-23 14:15:29 --> Router Class Initialized
INFO - 2018-10-23 14:15:29 --> Output Class Initialized
INFO - 2018-10-23 14:15:29 --> Security Class Initialized
DEBUG - 2018-10-23 14:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:15:29 --> CSRF cookie sent
INFO - 2018-10-23 14:15:29 --> CSRF token verified
INFO - 2018-10-23 14:15:29 --> Input Class Initialized
INFO - 2018-10-23 14:15:29 --> Language Class Initialized
INFO - 2018-10-23 14:15:29 --> Loader Class Initialized
INFO - 2018-10-23 14:15:29 --> Helper loaded: url_helper
INFO - 2018-10-23 14:15:29 --> Helper loaded: form_helper
INFO - 2018-10-23 14:15:29 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:15:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:15:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:15:29 --> User Agent Class Initialized
INFO - 2018-10-23 14:15:29 --> Controller Class Initialized
INFO - 2018-10-23 14:15:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:15:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:15:29 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:15:29 --> Pixel_Model class loaded
INFO - 2018-10-23 14:15:29 --> Database Driver Class Initialized
INFO - 2018-10-23 14:15:29 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:15:29 --> Form Validation Class Initialized
INFO - 2018-10-23 14:15:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:15:29 --> Database Driver Class Initialized
INFO - 2018-10-23 14:15:29 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:15:29 --> Config Class Initialized
INFO - 2018-10-23 14:15:29 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:15:29 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:15:29 --> Utf8 Class Initialized
INFO - 2018-10-23 14:15:29 --> URI Class Initialized
INFO - 2018-10-23 14:15:29 --> Router Class Initialized
INFO - 2018-10-23 14:15:29 --> Output Class Initialized
INFO - 2018-10-23 14:15:29 --> Security Class Initialized
DEBUG - 2018-10-23 14:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:15:30 --> CSRF cookie sent
INFO - 2018-10-23 14:15:30 --> Input Class Initialized
INFO - 2018-10-23 14:15:30 --> Language Class Initialized
INFO - 2018-10-23 14:15:30 --> Loader Class Initialized
INFO - 2018-10-23 14:15:30 --> Helper loaded: url_helper
INFO - 2018-10-23 14:15:30 --> Helper loaded: form_helper
INFO - 2018-10-23 14:15:30 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:15:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:15:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:15:30 --> User Agent Class Initialized
INFO - 2018-10-23 14:15:30 --> Controller Class Initialized
INFO - 2018-10-23 14:15:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:15:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:15:30 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:15:30 --> Pixel_Model class loaded
INFO - 2018-10-23 14:15:30 --> Database Driver Class Initialized
INFO - 2018-10-23 14:15:30 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:15:30 --> Database Driver Class Initialized
INFO - 2018-10-23 14:15:30 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:15:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:15:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:15:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:15:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:15:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:15:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:15:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-23 14:15:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:15:30 --> Final output sent to browser
DEBUG - 2018-10-23 14:15:30 --> Total execution time: 0.3994
INFO - 2018-10-23 14:15:32 --> Config Class Initialized
INFO - 2018-10-23 14:15:32 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:15:32 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:15:32 --> Utf8 Class Initialized
INFO - 2018-10-23 14:15:32 --> URI Class Initialized
INFO - 2018-10-23 14:15:32 --> Router Class Initialized
INFO - 2018-10-23 14:15:32 --> Output Class Initialized
INFO - 2018-10-23 14:15:32 --> Security Class Initialized
DEBUG - 2018-10-23 14:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:15:33 --> CSRF cookie sent
INFO - 2018-10-23 14:15:33 --> CSRF token verified
INFO - 2018-10-23 14:15:33 --> Input Class Initialized
INFO - 2018-10-23 14:15:33 --> Language Class Initialized
INFO - 2018-10-23 14:15:33 --> Loader Class Initialized
INFO - 2018-10-23 14:15:33 --> Helper loaded: url_helper
INFO - 2018-10-23 14:15:33 --> Helper loaded: form_helper
INFO - 2018-10-23 14:15:33 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:15:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:15:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:15:33 --> User Agent Class Initialized
INFO - 2018-10-23 14:15:33 --> Controller Class Initialized
INFO - 2018-10-23 14:15:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:15:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:15:33 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:15:33 --> Pixel_Model class loaded
INFO - 2018-10-23 14:15:33 --> Database Driver Class Initialized
INFO - 2018-10-23 14:15:33 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:15:33 --> Form Validation Class Initialized
INFO - 2018-10-23 14:15:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:15:33 --> Database Driver Class Initialized
INFO - 2018-10-23 14:15:33 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:15:33 --> Config Class Initialized
INFO - 2018-10-23 14:15:33 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:15:33 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:15:33 --> Utf8 Class Initialized
INFO - 2018-10-23 14:15:33 --> URI Class Initialized
INFO - 2018-10-23 14:15:33 --> Router Class Initialized
INFO - 2018-10-23 14:15:33 --> Output Class Initialized
INFO - 2018-10-23 14:15:33 --> Security Class Initialized
DEBUG - 2018-10-23 14:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:15:33 --> CSRF cookie sent
INFO - 2018-10-23 14:15:33 --> Input Class Initialized
INFO - 2018-10-23 14:15:33 --> Language Class Initialized
INFO - 2018-10-23 14:15:33 --> Loader Class Initialized
INFO - 2018-10-23 14:15:33 --> Helper loaded: url_helper
INFO - 2018-10-23 14:15:33 --> Helper loaded: form_helper
INFO - 2018-10-23 14:15:33 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:15:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:15:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:15:33 --> User Agent Class Initialized
INFO - 2018-10-23 14:15:33 --> Controller Class Initialized
INFO - 2018-10-23 14:15:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:15:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:15:33 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:15:33 --> Pixel_Model class loaded
INFO - 2018-10-23 14:15:33 --> Database Driver Class Initialized
INFO - 2018-10-23 14:15:33 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:15:33 --> Database Driver Class Initialized
INFO - 2018-10-23 14:15:33 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:15:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:15:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:15:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:15:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:15:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:15:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:15:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/your_job.php
INFO - 2018-10-23 14:15:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:15:33 --> Final output sent to browser
DEBUG - 2018-10-23 14:15:33 --> Total execution time: 0.4235
INFO - 2018-10-23 14:15:37 --> Config Class Initialized
INFO - 2018-10-23 14:15:37 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:15:37 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:15:37 --> Utf8 Class Initialized
INFO - 2018-10-23 14:15:37 --> URI Class Initialized
INFO - 2018-10-23 14:15:37 --> Router Class Initialized
INFO - 2018-10-23 14:15:37 --> Output Class Initialized
INFO - 2018-10-23 14:15:37 --> Security Class Initialized
DEBUG - 2018-10-23 14:15:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:15:37 --> CSRF cookie sent
INFO - 2018-10-23 14:15:37 --> CSRF token verified
INFO - 2018-10-23 14:15:37 --> Input Class Initialized
INFO - 2018-10-23 14:15:37 --> Language Class Initialized
INFO - 2018-10-23 14:15:37 --> Loader Class Initialized
INFO - 2018-10-23 14:15:37 --> Helper loaded: url_helper
INFO - 2018-10-23 14:15:37 --> Helper loaded: form_helper
INFO - 2018-10-23 14:15:37 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:15:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:15:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:15:37 --> User Agent Class Initialized
INFO - 2018-10-23 14:15:37 --> Controller Class Initialized
INFO - 2018-10-23 14:15:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:15:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:15:37 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:15:37 --> Pixel_Model class loaded
INFO - 2018-10-23 14:15:37 --> Database Driver Class Initialized
INFO - 2018-10-23 14:15:37 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:15:37 --> Form Validation Class Initialized
INFO - 2018-10-23 14:15:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:15:37 --> Database Driver Class Initialized
INFO - 2018-10-23 14:15:37 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:15:37 --> Config Class Initialized
INFO - 2018-10-23 14:15:37 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:15:37 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:15:37 --> Utf8 Class Initialized
INFO - 2018-10-23 14:15:37 --> URI Class Initialized
INFO - 2018-10-23 14:15:37 --> Router Class Initialized
INFO - 2018-10-23 14:15:37 --> Output Class Initialized
INFO - 2018-10-23 14:15:37 --> Security Class Initialized
DEBUG - 2018-10-23 14:15:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:15:37 --> CSRF cookie sent
INFO - 2018-10-23 14:15:37 --> Input Class Initialized
INFO - 2018-10-23 14:15:37 --> Language Class Initialized
INFO - 2018-10-23 14:15:37 --> Loader Class Initialized
INFO - 2018-10-23 14:15:37 --> Helper loaded: url_helper
INFO - 2018-10-23 14:15:37 --> Helper loaded: form_helper
INFO - 2018-10-23 14:15:37 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:15:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:15:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:15:37 --> User Agent Class Initialized
INFO - 2018-10-23 14:15:37 --> Controller Class Initialized
INFO - 2018-10-23 14:15:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:15:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:15:37 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:15:37 --> Pixel_Model class loaded
INFO - 2018-10-23 14:15:37 --> Database Driver Class Initialized
INFO - 2018-10-23 14:15:37 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:15:37 --> Database Driver Class Initialized
INFO - 2018-10-23 14:15:37 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:15:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:15:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:15:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner.php
INFO - 2018-10-23 14:15:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:15:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:15:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:15:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:15:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/relation_ship_status.php
INFO - 2018-10-23 14:15:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:15:37 --> Final output sent to browser
DEBUG - 2018-10-23 14:15:37 --> Total execution time: 0.4209
INFO - 2018-10-23 14:15:45 --> Config Class Initialized
INFO - 2018-10-23 14:15:45 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:15:45 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:15:45 --> Utf8 Class Initialized
INFO - 2018-10-23 14:15:45 --> URI Class Initialized
INFO - 2018-10-23 14:15:45 --> Router Class Initialized
INFO - 2018-10-23 14:15:45 --> Output Class Initialized
INFO - 2018-10-23 14:15:45 --> Security Class Initialized
DEBUG - 2018-10-23 14:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:15:45 --> CSRF cookie sent
INFO - 2018-10-23 14:15:46 --> CSRF token verified
INFO - 2018-10-23 14:15:46 --> Input Class Initialized
INFO - 2018-10-23 14:15:46 --> Language Class Initialized
INFO - 2018-10-23 14:15:46 --> Loader Class Initialized
INFO - 2018-10-23 14:15:46 --> Helper loaded: url_helper
INFO - 2018-10-23 14:15:46 --> Helper loaded: form_helper
INFO - 2018-10-23 14:15:46 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:15:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:15:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:15:46 --> User Agent Class Initialized
INFO - 2018-10-23 14:15:46 --> Controller Class Initialized
INFO - 2018-10-23 14:15:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:15:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:15:46 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:15:46 --> Pixel_Model class loaded
INFO - 2018-10-23 14:15:46 --> Database Driver Class Initialized
INFO - 2018-10-23 14:15:46 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:15:46 --> Form Validation Class Initialized
INFO - 2018-10-23 14:15:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:15:46 --> Database Driver Class Initialized
INFO - 2018-10-23 14:15:46 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:15:46 --> Config Class Initialized
INFO - 2018-10-23 14:15:46 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:15:46 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:15:46 --> Utf8 Class Initialized
INFO - 2018-10-23 14:15:46 --> URI Class Initialized
INFO - 2018-10-23 14:15:46 --> Router Class Initialized
INFO - 2018-10-23 14:15:46 --> Output Class Initialized
INFO - 2018-10-23 14:15:46 --> Security Class Initialized
DEBUG - 2018-10-23 14:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:15:46 --> CSRF cookie sent
INFO - 2018-10-23 14:15:46 --> Input Class Initialized
INFO - 2018-10-23 14:15:46 --> Language Class Initialized
INFO - 2018-10-23 14:15:46 --> Loader Class Initialized
INFO - 2018-10-23 14:15:46 --> Helper loaded: url_helper
INFO - 2018-10-23 14:15:46 --> Helper loaded: form_helper
INFO - 2018-10-23 14:15:46 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:15:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:15:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:15:46 --> User Agent Class Initialized
INFO - 2018-10-23 14:15:46 --> Controller Class Initialized
INFO - 2018-10-23 14:15:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:15:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:15:46 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:15:46 --> Pixel_Model class loaded
INFO - 2018-10-23 14:15:46 --> Database Driver Class Initialized
INFO - 2018-10-23 14:15:46 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:15:46 --> Database Driver Class Initialized
INFO - 2018-10-23 14:15:46 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:15:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:15:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:15:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:15:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:15:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:15:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:15:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/income.php
INFO - 2018-10-23 14:15:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:15:46 --> Final output sent to browser
DEBUG - 2018-10-23 14:15:46 --> Total execution time: 0.4183
INFO - 2018-10-23 14:15:48 --> Config Class Initialized
INFO - 2018-10-23 14:15:48 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:15:48 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:15:48 --> Utf8 Class Initialized
INFO - 2018-10-23 14:15:48 --> URI Class Initialized
INFO - 2018-10-23 14:15:48 --> Router Class Initialized
INFO - 2018-10-23 14:15:48 --> Output Class Initialized
INFO - 2018-10-23 14:15:48 --> Security Class Initialized
DEBUG - 2018-10-23 14:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:15:48 --> CSRF cookie sent
INFO - 2018-10-23 14:15:48 --> CSRF token verified
INFO - 2018-10-23 14:15:48 --> Input Class Initialized
INFO - 2018-10-23 14:15:48 --> Language Class Initialized
INFO - 2018-10-23 14:15:48 --> Loader Class Initialized
INFO - 2018-10-23 14:15:48 --> Helper loaded: url_helper
INFO - 2018-10-23 14:15:48 --> Helper loaded: form_helper
INFO - 2018-10-23 14:15:48 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:15:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:15:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:15:48 --> User Agent Class Initialized
INFO - 2018-10-23 14:15:48 --> Controller Class Initialized
INFO - 2018-10-23 14:15:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:15:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:15:48 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:15:48 --> Pixel_Model class loaded
INFO - 2018-10-23 14:15:48 --> Database Driver Class Initialized
INFO - 2018-10-23 14:15:48 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:15:48 --> Form Validation Class Initialized
INFO - 2018-10-23 14:15:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:15:48 --> Database Driver Class Initialized
INFO - 2018-10-23 14:15:48 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:15:48 --> Config Class Initialized
INFO - 2018-10-23 14:15:48 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:15:48 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:15:48 --> Utf8 Class Initialized
INFO - 2018-10-23 14:15:48 --> URI Class Initialized
INFO - 2018-10-23 14:15:48 --> Router Class Initialized
INFO - 2018-10-23 14:15:48 --> Output Class Initialized
INFO - 2018-10-23 14:15:48 --> Security Class Initialized
DEBUG - 2018-10-23 14:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:15:48 --> CSRF cookie sent
INFO - 2018-10-23 14:15:48 --> Input Class Initialized
INFO - 2018-10-23 14:15:48 --> Language Class Initialized
INFO - 2018-10-23 14:15:48 --> Loader Class Initialized
INFO - 2018-10-23 14:15:48 --> Helper loaded: url_helper
INFO - 2018-10-23 14:15:48 --> Helper loaded: form_helper
INFO - 2018-10-23 14:15:48 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:15:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:15:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:15:48 --> User Agent Class Initialized
INFO - 2018-10-23 14:15:48 --> Controller Class Initialized
INFO - 2018-10-23 14:15:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:15:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:15:48 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:15:48 --> Pixel_Model class loaded
INFO - 2018-10-23 14:15:48 --> Database Driver Class Initialized
INFO - 2018-10-23 14:15:48 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:15:49 --> Database Driver Class Initialized
INFO - 2018-10-23 14:15:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:15:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:15:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:15:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:15:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:15:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:15:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:15:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/pension.php
INFO - 2018-10-23 14:15:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:15:49 --> Final output sent to browser
DEBUG - 2018-10-23 14:15:49 --> Total execution time: 0.4113
INFO - 2018-10-23 14:15:51 --> Config Class Initialized
INFO - 2018-10-23 14:15:51 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:15:51 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:15:51 --> Utf8 Class Initialized
INFO - 2018-10-23 14:15:51 --> URI Class Initialized
INFO - 2018-10-23 14:15:51 --> Router Class Initialized
INFO - 2018-10-23 14:15:51 --> Output Class Initialized
INFO - 2018-10-23 14:15:51 --> Security Class Initialized
DEBUG - 2018-10-23 14:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:15:51 --> CSRF cookie sent
INFO - 2018-10-23 14:15:51 --> Input Class Initialized
INFO - 2018-10-23 14:15:51 --> Language Class Initialized
INFO - 2018-10-23 14:15:51 --> Loader Class Initialized
INFO - 2018-10-23 14:15:51 --> Helper loaded: url_helper
INFO - 2018-10-23 14:15:51 --> Helper loaded: form_helper
INFO - 2018-10-23 14:15:51 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:15:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:15:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:15:51 --> User Agent Class Initialized
INFO - 2018-10-23 14:15:51 --> Controller Class Initialized
INFO - 2018-10-23 14:15:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:15:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:15:51 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:15:51 --> Pixel_Model class loaded
INFO - 2018-10-23 14:15:51 --> Database Driver Class Initialized
INFO - 2018-10-23 14:15:51 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:15:51 --> Database Driver Class Initialized
INFO - 2018-10-23 14:15:51 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:15:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:15:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:15:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:15:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:15:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:15:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:15:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/income.php
INFO - 2018-10-23 14:15:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:15:51 --> Final output sent to browser
DEBUG - 2018-10-23 14:15:51 --> Total execution time: 0.4446
INFO - 2018-10-23 14:15:52 --> Config Class Initialized
INFO - 2018-10-23 14:15:52 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:15:52 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:15:52 --> Utf8 Class Initialized
INFO - 2018-10-23 14:15:52 --> URI Class Initialized
INFO - 2018-10-23 14:15:52 --> Router Class Initialized
INFO - 2018-10-23 14:15:52 --> Output Class Initialized
INFO - 2018-10-23 14:15:52 --> Security Class Initialized
DEBUG - 2018-10-23 14:15:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:15:52 --> CSRF cookie sent
INFO - 2018-10-23 14:15:52 --> Input Class Initialized
INFO - 2018-10-23 14:15:52 --> Language Class Initialized
INFO - 2018-10-23 14:15:52 --> Loader Class Initialized
INFO - 2018-10-23 14:15:52 --> Helper loaded: url_helper
INFO - 2018-10-23 14:15:52 --> Helper loaded: form_helper
INFO - 2018-10-23 14:15:52 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:15:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:15:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:15:52 --> User Agent Class Initialized
INFO - 2018-10-23 14:15:52 --> Controller Class Initialized
INFO - 2018-10-23 14:15:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:15:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:15:52 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:15:52 --> Pixel_Model class loaded
INFO - 2018-10-23 14:15:52 --> Database Driver Class Initialized
INFO - 2018-10-23 14:15:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:15:52 --> Database Driver Class Initialized
INFO - 2018-10-23 14:15:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:15:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:15:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:15:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner.php
INFO - 2018-10-23 14:15:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:15:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:15:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:15:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:15:53 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/relation_ship_status.php
INFO - 2018-10-23 14:15:53 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:15:53 --> Final output sent to browser
DEBUG - 2018-10-23 14:15:53 --> Total execution time: 0.4409
INFO - 2018-10-23 14:15:55 --> Config Class Initialized
INFO - 2018-10-23 14:15:55 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:15:55 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:15:55 --> Utf8 Class Initialized
INFO - 2018-10-23 14:15:55 --> URI Class Initialized
INFO - 2018-10-23 14:15:55 --> Router Class Initialized
INFO - 2018-10-23 14:15:55 --> Output Class Initialized
INFO - 2018-10-23 14:15:55 --> Security Class Initialized
DEBUG - 2018-10-23 14:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:15:55 --> CSRF cookie sent
INFO - 2018-10-23 14:15:55 --> CSRF token verified
INFO - 2018-10-23 14:15:55 --> Input Class Initialized
INFO - 2018-10-23 14:15:55 --> Language Class Initialized
INFO - 2018-10-23 14:15:55 --> Loader Class Initialized
INFO - 2018-10-23 14:15:55 --> Helper loaded: url_helper
INFO - 2018-10-23 14:15:55 --> Helper loaded: form_helper
INFO - 2018-10-23 14:15:55 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:15:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:15:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:15:55 --> User Agent Class Initialized
INFO - 2018-10-23 14:15:55 --> Controller Class Initialized
INFO - 2018-10-23 14:15:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:15:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:15:55 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:15:55 --> Pixel_Model class loaded
INFO - 2018-10-23 14:15:55 --> Database Driver Class Initialized
INFO - 2018-10-23 14:15:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:15:55 --> Form Validation Class Initialized
INFO - 2018-10-23 14:15:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:15:55 --> Database Driver Class Initialized
INFO - 2018-10-23 14:15:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:15:55 --> Config Class Initialized
INFO - 2018-10-23 14:15:55 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:15:55 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:15:55 --> Utf8 Class Initialized
INFO - 2018-10-23 14:15:56 --> URI Class Initialized
INFO - 2018-10-23 14:15:56 --> Router Class Initialized
INFO - 2018-10-23 14:15:56 --> Output Class Initialized
INFO - 2018-10-23 14:15:56 --> Security Class Initialized
DEBUG - 2018-10-23 14:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:15:56 --> CSRF cookie sent
INFO - 2018-10-23 14:15:56 --> Input Class Initialized
INFO - 2018-10-23 14:15:56 --> Language Class Initialized
INFO - 2018-10-23 14:15:56 --> Loader Class Initialized
INFO - 2018-10-23 14:15:56 --> Helper loaded: url_helper
INFO - 2018-10-23 14:15:56 --> Helper loaded: form_helper
INFO - 2018-10-23 14:15:56 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:15:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:15:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:15:56 --> User Agent Class Initialized
INFO - 2018-10-23 14:15:56 --> Controller Class Initialized
INFO - 2018-10-23 14:15:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:15:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:15:56 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:15:56 --> Pixel_Model class loaded
INFO - 2018-10-23 14:15:56 --> Database Driver Class Initialized
INFO - 2018-10-23 14:15:56 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:15:56 --> Database Driver Class Initialized
INFO - 2018-10-23 14:15:56 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:15:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:15:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:15:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:15:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:15:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:15:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:15:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/income.php
INFO - 2018-10-23 14:15:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:15:56 --> Final output sent to browser
DEBUG - 2018-10-23 14:15:56 --> Total execution time: 0.4330
INFO - 2018-10-23 14:15:57 --> Config Class Initialized
INFO - 2018-10-23 14:15:57 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:15:57 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:15:57 --> Utf8 Class Initialized
INFO - 2018-10-23 14:15:57 --> URI Class Initialized
INFO - 2018-10-23 14:15:57 --> Router Class Initialized
INFO - 2018-10-23 14:15:57 --> Output Class Initialized
INFO - 2018-10-23 14:15:57 --> Security Class Initialized
DEBUG - 2018-10-23 14:15:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:15:57 --> CSRF cookie sent
INFO - 2018-10-23 14:15:57 --> CSRF token verified
INFO - 2018-10-23 14:15:57 --> Input Class Initialized
INFO - 2018-10-23 14:15:57 --> Language Class Initialized
INFO - 2018-10-23 14:15:57 --> Loader Class Initialized
INFO - 2018-10-23 14:15:57 --> Helper loaded: url_helper
INFO - 2018-10-23 14:15:57 --> Helper loaded: form_helper
INFO - 2018-10-23 14:15:57 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:15:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:15:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:15:57 --> User Agent Class Initialized
INFO - 2018-10-23 14:15:57 --> Controller Class Initialized
INFO - 2018-10-23 14:15:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:15:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:15:57 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:15:57 --> Pixel_Model class loaded
INFO - 2018-10-23 14:15:57 --> Database Driver Class Initialized
INFO - 2018-10-23 14:15:57 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:15:57 --> Form Validation Class Initialized
INFO - 2018-10-23 14:15:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:15:57 --> Database Driver Class Initialized
INFO - 2018-10-23 14:15:57 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:15:58 --> Config Class Initialized
INFO - 2018-10-23 14:15:58 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:15:58 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:15:58 --> Utf8 Class Initialized
INFO - 2018-10-23 14:15:58 --> URI Class Initialized
INFO - 2018-10-23 14:15:58 --> Router Class Initialized
INFO - 2018-10-23 14:15:58 --> Output Class Initialized
INFO - 2018-10-23 14:15:58 --> Security Class Initialized
DEBUG - 2018-10-23 14:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:15:58 --> CSRF cookie sent
INFO - 2018-10-23 14:15:58 --> Input Class Initialized
INFO - 2018-10-23 14:15:58 --> Language Class Initialized
INFO - 2018-10-23 14:15:58 --> Loader Class Initialized
INFO - 2018-10-23 14:15:58 --> Helper loaded: url_helper
INFO - 2018-10-23 14:15:58 --> Helper loaded: form_helper
INFO - 2018-10-23 14:15:58 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:15:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:15:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:15:58 --> User Agent Class Initialized
INFO - 2018-10-23 14:15:58 --> Controller Class Initialized
INFO - 2018-10-23 14:15:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:15:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:15:58 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:15:58 --> Pixel_Model class loaded
INFO - 2018-10-23 14:15:58 --> Database Driver Class Initialized
INFO - 2018-10-23 14:15:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:15:58 --> Database Driver Class Initialized
INFO - 2018-10-23 14:15:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:15:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:15:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:15:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:15:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:15:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:15:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:15:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/pension.php
INFO - 2018-10-23 14:15:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:15:58 --> Final output sent to browser
DEBUG - 2018-10-23 14:15:58 --> Total execution time: 0.4217
INFO - 2018-10-23 14:16:23 --> Config Class Initialized
INFO - 2018-10-23 14:16:23 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:16:23 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:16:23 --> Utf8 Class Initialized
INFO - 2018-10-23 14:16:23 --> URI Class Initialized
INFO - 2018-10-23 14:16:23 --> Router Class Initialized
INFO - 2018-10-23 14:16:23 --> Output Class Initialized
INFO - 2018-10-23 14:16:23 --> Security Class Initialized
DEBUG - 2018-10-23 14:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:16:23 --> CSRF cookie sent
INFO - 2018-10-23 14:16:23 --> Input Class Initialized
INFO - 2018-10-23 14:16:23 --> Language Class Initialized
INFO - 2018-10-23 14:16:23 --> Loader Class Initialized
INFO - 2018-10-23 14:16:23 --> Helper loaded: url_helper
INFO - 2018-10-23 14:16:23 --> Helper loaded: form_helper
INFO - 2018-10-23 14:16:23 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:16:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:16:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:16:23 --> User Agent Class Initialized
INFO - 2018-10-23 14:16:23 --> Controller Class Initialized
INFO - 2018-10-23 14:16:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:16:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:16:23 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:16:23 --> Pixel_Model class loaded
INFO - 2018-10-23 14:16:23 --> Database Driver Class Initialized
INFO - 2018-10-23 14:16:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:16:23 --> Database Driver Class Initialized
INFO - 2018-10-23 14:16:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:16:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:16:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:16:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:16:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:16:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:16:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:16:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/income.php
INFO - 2018-10-23 14:16:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:16:23 --> Final output sent to browser
DEBUG - 2018-10-23 14:16:23 --> Total execution time: 0.4430
INFO - 2018-10-23 14:16:24 --> Config Class Initialized
INFO - 2018-10-23 14:16:24 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:16:24 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:16:24 --> Utf8 Class Initialized
INFO - 2018-10-23 14:16:24 --> URI Class Initialized
INFO - 2018-10-23 14:16:24 --> Router Class Initialized
INFO - 2018-10-23 14:16:24 --> Output Class Initialized
INFO - 2018-10-23 14:16:24 --> Security Class Initialized
DEBUG - 2018-10-23 14:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:16:24 --> CSRF cookie sent
INFO - 2018-10-23 14:16:24 --> Input Class Initialized
INFO - 2018-10-23 14:16:24 --> Language Class Initialized
INFO - 2018-10-23 14:16:24 --> Loader Class Initialized
INFO - 2018-10-23 14:16:24 --> Helper loaded: url_helper
INFO - 2018-10-23 14:16:24 --> Helper loaded: form_helper
INFO - 2018-10-23 14:16:24 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:16:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:16:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:16:24 --> User Agent Class Initialized
INFO - 2018-10-23 14:16:24 --> Controller Class Initialized
INFO - 2018-10-23 14:16:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:16:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:16:24 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:16:24 --> Pixel_Model class loaded
INFO - 2018-10-23 14:16:24 --> Database Driver Class Initialized
INFO - 2018-10-23 14:16:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:16:24 --> Database Driver Class Initialized
INFO - 2018-10-23 14:16:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:16:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:16:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:16:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner.php
INFO - 2018-10-23 14:16:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:16:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:16:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:16:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:16:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/relation_ship_status.php
INFO - 2018-10-23 14:16:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:16:24 --> Final output sent to browser
DEBUG - 2018-10-23 14:16:24 --> Total execution time: 0.4601
INFO - 2018-10-23 14:17:16 --> Config Class Initialized
INFO - 2018-10-23 14:17:16 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:17:16 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:17:16 --> Utf8 Class Initialized
INFO - 2018-10-23 14:17:16 --> URI Class Initialized
INFO - 2018-10-23 14:17:16 --> Router Class Initialized
INFO - 2018-10-23 14:17:17 --> Output Class Initialized
INFO - 2018-10-23 14:17:17 --> Security Class Initialized
DEBUG - 2018-10-23 14:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:17:17 --> CSRF cookie sent
INFO - 2018-10-23 14:17:17 --> Input Class Initialized
INFO - 2018-10-23 14:17:17 --> Language Class Initialized
INFO - 2018-10-23 14:17:17 --> Loader Class Initialized
INFO - 2018-10-23 14:17:17 --> Helper loaded: url_helper
INFO - 2018-10-23 14:17:17 --> Helper loaded: form_helper
INFO - 2018-10-23 14:17:17 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:17:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:17:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:17:17 --> User Agent Class Initialized
INFO - 2018-10-23 14:17:17 --> Controller Class Initialized
INFO - 2018-10-23 14:17:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:17:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:17:17 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:17:17 --> Pixel_Model class loaded
INFO - 2018-10-23 14:17:17 --> Database Driver Class Initialized
INFO - 2018-10-23 14:17:17 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:17:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:17:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:17:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:17:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:17:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:17:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:17:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-23 14:17:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:17:17 --> Final output sent to browser
DEBUG - 2018-10-23 14:17:17 --> Total execution time: 0.3892
INFO - 2018-10-23 14:17:19 --> Config Class Initialized
INFO - 2018-10-23 14:17:19 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:17:19 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:17:19 --> Utf8 Class Initialized
INFO - 2018-10-23 14:17:19 --> URI Class Initialized
INFO - 2018-10-23 14:17:19 --> Router Class Initialized
INFO - 2018-10-23 14:17:19 --> Output Class Initialized
INFO - 2018-10-23 14:17:19 --> Security Class Initialized
DEBUG - 2018-10-23 14:17:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:17:19 --> CSRF cookie sent
INFO - 2018-10-23 14:17:19 --> CSRF token verified
INFO - 2018-10-23 14:17:19 --> Input Class Initialized
INFO - 2018-10-23 14:17:19 --> Language Class Initialized
INFO - 2018-10-23 14:17:19 --> Loader Class Initialized
INFO - 2018-10-23 14:17:19 --> Helper loaded: url_helper
INFO - 2018-10-23 14:17:19 --> Helper loaded: form_helper
INFO - 2018-10-23 14:17:19 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:17:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:17:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:17:19 --> User Agent Class Initialized
INFO - 2018-10-23 14:17:19 --> Controller Class Initialized
INFO - 2018-10-23 14:17:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:17:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:17:19 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:17:19 --> Pixel_Model class loaded
INFO - 2018-10-23 14:17:19 --> Database Driver Class Initialized
INFO - 2018-10-23 14:17:19 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:17:19 --> Form Validation Class Initialized
INFO - 2018-10-23 14:17:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:17:19 --> Database Driver Class Initialized
INFO - 2018-10-23 14:17:19 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:17:19 --> Config Class Initialized
INFO - 2018-10-23 14:17:19 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:17:19 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:17:19 --> Utf8 Class Initialized
INFO - 2018-10-23 14:17:19 --> URI Class Initialized
INFO - 2018-10-23 14:17:19 --> Router Class Initialized
INFO - 2018-10-23 14:17:19 --> Output Class Initialized
INFO - 2018-10-23 14:17:19 --> Security Class Initialized
DEBUG - 2018-10-23 14:17:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:17:19 --> CSRF cookie sent
INFO - 2018-10-23 14:17:19 --> Input Class Initialized
INFO - 2018-10-23 14:17:19 --> Language Class Initialized
INFO - 2018-10-23 14:17:19 --> Loader Class Initialized
INFO - 2018-10-23 14:17:19 --> Helper loaded: url_helper
INFO - 2018-10-23 14:17:19 --> Helper loaded: form_helper
INFO - 2018-10-23 14:17:19 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:17:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:17:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:17:19 --> User Agent Class Initialized
INFO - 2018-10-23 14:17:19 --> Controller Class Initialized
INFO - 2018-10-23 14:17:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:17:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:17:19 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:17:19 --> Pixel_Model class loaded
INFO - 2018-10-23 14:17:19 --> Database Driver Class Initialized
INFO - 2018-10-23 14:17:19 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:17:19 --> Database Driver Class Initialized
INFO - 2018-10-23 14:17:19 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:17:19 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:17:19 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:17:19 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:17:19 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:17:19 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:17:19 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:17:19 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-23 14:17:19 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:17:19 --> Final output sent to browser
DEBUG - 2018-10-23 14:17:19 --> Total execution time: 0.4453
INFO - 2018-10-23 14:17:22 --> Config Class Initialized
INFO - 2018-10-23 14:17:22 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:17:22 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:17:22 --> Utf8 Class Initialized
INFO - 2018-10-23 14:17:22 --> URI Class Initialized
INFO - 2018-10-23 14:17:22 --> Router Class Initialized
INFO - 2018-10-23 14:17:22 --> Output Class Initialized
INFO - 2018-10-23 14:17:22 --> Security Class Initialized
DEBUG - 2018-10-23 14:17:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:17:22 --> CSRF cookie sent
INFO - 2018-10-23 14:17:22 --> CSRF token verified
INFO - 2018-10-23 14:17:22 --> Input Class Initialized
INFO - 2018-10-23 14:17:22 --> Language Class Initialized
INFO - 2018-10-23 14:17:22 --> Loader Class Initialized
INFO - 2018-10-23 14:17:22 --> Helper loaded: url_helper
INFO - 2018-10-23 14:17:22 --> Helper loaded: form_helper
INFO - 2018-10-23 14:17:22 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:17:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:17:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:17:22 --> User Agent Class Initialized
INFO - 2018-10-23 14:17:22 --> Controller Class Initialized
INFO - 2018-10-23 14:17:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:17:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:17:22 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:17:22 --> Pixel_Model class loaded
INFO - 2018-10-23 14:17:22 --> Database Driver Class Initialized
INFO - 2018-10-23 14:17:22 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:17:22 --> Form Validation Class Initialized
INFO - 2018-10-23 14:17:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:17:23 --> Database Driver Class Initialized
INFO - 2018-10-23 14:17:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:17:23 --> Config Class Initialized
INFO - 2018-10-23 14:17:23 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:17:23 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:17:23 --> Utf8 Class Initialized
INFO - 2018-10-23 14:17:23 --> URI Class Initialized
INFO - 2018-10-23 14:17:23 --> Router Class Initialized
INFO - 2018-10-23 14:17:23 --> Output Class Initialized
INFO - 2018-10-23 14:17:23 --> Security Class Initialized
DEBUG - 2018-10-23 14:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:17:23 --> CSRF cookie sent
INFO - 2018-10-23 14:17:23 --> Input Class Initialized
INFO - 2018-10-23 14:17:23 --> Language Class Initialized
INFO - 2018-10-23 14:17:23 --> Loader Class Initialized
INFO - 2018-10-23 14:17:23 --> Helper loaded: url_helper
INFO - 2018-10-23 14:17:23 --> Helper loaded: form_helper
INFO - 2018-10-23 14:17:23 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:17:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:17:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:17:23 --> User Agent Class Initialized
INFO - 2018-10-23 14:17:23 --> Controller Class Initialized
INFO - 2018-10-23 14:17:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:17:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:17:23 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:17:23 --> Pixel_Model class loaded
INFO - 2018-10-23 14:17:23 --> Database Driver Class Initialized
INFO - 2018-10-23 14:17:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:17:23 --> Database Driver Class Initialized
INFO - 2018-10-23 14:17:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:17:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:17:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:17:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:17:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:17:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:17:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:17:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/your_job.php
INFO - 2018-10-23 14:17:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:17:23 --> Final output sent to browser
DEBUG - 2018-10-23 14:17:23 --> Total execution time: 0.4415
INFO - 2018-10-23 14:17:24 --> Config Class Initialized
INFO - 2018-10-23 14:17:24 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:17:24 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:17:24 --> Utf8 Class Initialized
INFO - 2018-10-23 14:17:24 --> URI Class Initialized
INFO - 2018-10-23 14:17:24 --> Router Class Initialized
INFO - 2018-10-23 14:17:24 --> Output Class Initialized
INFO - 2018-10-23 14:17:24 --> Security Class Initialized
DEBUG - 2018-10-23 14:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:17:24 --> CSRF cookie sent
INFO - 2018-10-23 14:17:24 --> CSRF token verified
INFO - 2018-10-23 14:17:24 --> Input Class Initialized
INFO - 2018-10-23 14:17:24 --> Language Class Initialized
INFO - 2018-10-23 14:17:24 --> Loader Class Initialized
INFO - 2018-10-23 14:17:24 --> Helper loaded: url_helper
INFO - 2018-10-23 14:17:24 --> Helper loaded: form_helper
INFO - 2018-10-23 14:17:24 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:17:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:17:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:17:24 --> User Agent Class Initialized
INFO - 2018-10-23 14:17:24 --> Controller Class Initialized
INFO - 2018-10-23 14:17:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:17:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:17:24 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:17:24 --> Pixel_Model class loaded
INFO - 2018-10-23 14:17:24 --> Database Driver Class Initialized
INFO - 2018-10-23 14:17:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:17:24 --> Form Validation Class Initialized
INFO - 2018-10-23 14:17:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:17:24 --> Database Driver Class Initialized
INFO - 2018-10-23 14:17:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:17:25 --> Config Class Initialized
INFO - 2018-10-23 14:17:25 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:17:25 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:17:25 --> Utf8 Class Initialized
INFO - 2018-10-23 14:17:25 --> URI Class Initialized
INFO - 2018-10-23 14:17:25 --> Router Class Initialized
INFO - 2018-10-23 14:17:25 --> Output Class Initialized
INFO - 2018-10-23 14:17:25 --> Security Class Initialized
DEBUG - 2018-10-23 14:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:17:25 --> CSRF cookie sent
INFO - 2018-10-23 14:17:25 --> Input Class Initialized
INFO - 2018-10-23 14:17:25 --> Language Class Initialized
INFO - 2018-10-23 14:17:25 --> Loader Class Initialized
INFO - 2018-10-23 14:17:25 --> Helper loaded: url_helper
INFO - 2018-10-23 14:17:25 --> Helper loaded: form_helper
INFO - 2018-10-23 14:17:25 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:17:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:17:25 --> User Agent Class Initialized
INFO - 2018-10-23 14:17:25 --> Controller Class Initialized
INFO - 2018-10-23 14:17:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:17:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:17:25 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:17:25 --> Pixel_Model class loaded
INFO - 2018-10-23 14:17:25 --> Database Driver Class Initialized
INFO - 2018-10-23 14:17:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:17:25 --> Database Driver Class Initialized
INFO - 2018-10-23 14:17:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:17:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:17:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:17:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner.php
INFO - 2018-10-23 14:17:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:17:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:17:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:17:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:17:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/relation_ship_status.php
INFO - 2018-10-23 14:17:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:17:25 --> Final output sent to browser
DEBUG - 2018-10-23 14:17:25 --> Total execution time: 0.4286
INFO - 2018-10-23 14:17:47 --> Config Class Initialized
INFO - 2018-10-23 14:17:47 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:17:47 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:17:47 --> Utf8 Class Initialized
INFO - 2018-10-23 14:17:47 --> URI Class Initialized
DEBUG - 2018-10-23 14:17:47 --> No URI present. Default controller set.
INFO - 2018-10-23 14:17:47 --> Router Class Initialized
INFO - 2018-10-23 14:17:47 --> Output Class Initialized
INFO - 2018-10-23 14:17:47 --> Security Class Initialized
DEBUG - 2018-10-23 14:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:17:47 --> CSRF cookie sent
INFO - 2018-10-23 14:17:47 --> Input Class Initialized
INFO - 2018-10-23 14:17:47 --> Language Class Initialized
INFO - 2018-10-23 14:17:47 --> Loader Class Initialized
INFO - 2018-10-23 14:17:47 --> Helper loaded: url_helper
INFO - 2018-10-23 14:17:47 --> Helper loaded: form_helper
INFO - 2018-10-23 14:17:47 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:17:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:17:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:17:47 --> User Agent Class Initialized
INFO - 2018-10-23 14:17:47 --> Controller Class Initialized
INFO - 2018-10-23 14:17:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:17:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:17:47 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:17:47 --> Pixel_Model class loaded
INFO - 2018-10-23 14:17:48 --> Database Driver Class Initialized
INFO - 2018-10-23 14:17:48 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:17:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:17:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:17:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-23 14:17:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:17:48 --> Final output sent to browser
DEBUG - 2018-10-23 14:17:48 --> Total execution time: 0.3882
INFO - 2018-10-23 14:17:50 --> Config Class Initialized
INFO - 2018-10-23 14:17:50 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:17:50 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:17:50 --> Utf8 Class Initialized
INFO - 2018-10-23 14:17:50 --> URI Class Initialized
INFO - 2018-10-23 14:17:50 --> Router Class Initialized
INFO - 2018-10-23 14:17:50 --> Output Class Initialized
INFO - 2018-10-23 14:17:50 --> Security Class Initialized
DEBUG - 2018-10-23 14:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:17:50 --> CSRF cookie sent
INFO - 2018-10-23 14:17:50 --> Input Class Initialized
INFO - 2018-10-23 14:17:50 --> Language Class Initialized
INFO - 2018-10-23 14:17:50 --> Loader Class Initialized
INFO - 2018-10-23 14:17:50 --> Helper loaded: url_helper
INFO - 2018-10-23 14:17:50 --> Helper loaded: form_helper
INFO - 2018-10-23 14:17:50 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:17:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:17:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:17:50 --> User Agent Class Initialized
INFO - 2018-10-23 14:17:50 --> Controller Class Initialized
INFO - 2018-10-23 14:17:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:17:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:17:51 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:17:51 --> Pixel_Model class loaded
INFO - 2018-10-23 14:17:51 --> Database Driver Class Initialized
INFO - 2018-10-23 14:17:51 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:17:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:17:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:17:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:17:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:17:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:17:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:17:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-23 14:17:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:17:51 --> Final output sent to browser
DEBUG - 2018-10-23 14:17:51 --> Total execution time: 0.5041
INFO - 2018-10-23 14:17:53 --> Config Class Initialized
INFO - 2018-10-23 14:17:53 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:17:53 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:17:53 --> Utf8 Class Initialized
INFO - 2018-10-23 14:17:53 --> URI Class Initialized
INFO - 2018-10-23 14:17:53 --> Router Class Initialized
INFO - 2018-10-23 14:17:53 --> Output Class Initialized
INFO - 2018-10-23 14:17:53 --> Security Class Initialized
DEBUG - 2018-10-23 14:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:17:53 --> CSRF cookie sent
INFO - 2018-10-23 14:17:53 --> CSRF token verified
INFO - 2018-10-23 14:17:53 --> Input Class Initialized
INFO - 2018-10-23 14:17:53 --> Language Class Initialized
INFO - 2018-10-23 14:17:53 --> Loader Class Initialized
INFO - 2018-10-23 14:17:53 --> Helper loaded: url_helper
INFO - 2018-10-23 14:17:53 --> Helper loaded: form_helper
INFO - 2018-10-23 14:17:53 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:17:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:17:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:17:53 --> User Agent Class Initialized
INFO - 2018-10-23 14:17:53 --> Controller Class Initialized
INFO - 2018-10-23 14:17:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:17:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:17:53 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:17:53 --> Pixel_Model class loaded
INFO - 2018-10-23 14:17:53 --> Database Driver Class Initialized
INFO - 2018-10-23 14:17:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:17:53 --> Form Validation Class Initialized
INFO - 2018-10-23 14:17:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:17:54 --> Database Driver Class Initialized
INFO - 2018-10-23 14:17:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:17:54 --> Config Class Initialized
INFO - 2018-10-23 14:17:54 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:17:54 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:17:54 --> Utf8 Class Initialized
INFO - 2018-10-23 14:17:54 --> URI Class Initialized
INFO - 2018-10-23 14:17:54 --> Router Class Initialized
INFO - 2018-10-23 14:17:54 --> Output Class Initialized
INFO - 2018-10-23 14:17:54 --> Security Class Initialized
DEBUG - 2018-10-23 14:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:17:54 --> CSRF cookie sent
INFO - 2018-10-23 14:17:54 --> Input Class Initialized
INFO - 2018-10-23 14:17:54 --> Language Class Initialized
INFO - 2018-10-23 14:17:54 --> Loader Class Initialized
INFO - 2018-10-23 14:17:54 --> Helper loaded: url_helper
INFO - 2018-10-23 14:17:54 --> Helper loaded: form_helper
INFO - 2018-10-23 14:17:54 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:17:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:17:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:17:54 --> User Agent Class Initialized
INFO - 2018-10-23 14:17:54 --> Controller Class Initialized
INFO - 2018-10-23 14:17:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:17:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:17:54 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:17:54 --> Pixel_Model class loaded
INFO - 2018-10-23 14:17:54 --> Database Driver Class Initialized
INFO - 2018-10-23 14:17:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:17:54 --> Database Driver Class Initialized
INFO - 2018-10-23 14:17:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:17:54 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:17:54 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:17:54 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:17:54 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:17:54 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:17:54 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:17:54 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-23 14:17:54 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:17:54 --> Final output sent to browser
DEBUG - 2018-10-23 14:17:54 --> Total execution time: 0.4682
INFO - 2018-10-23 14:17:57 --> Config Class Initialized
INFO - 2018-10-23 14:17:57 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:17:57 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:17:57 --> Utf8 Class Initialized
INFO - 2018-10-23 14:17:57 --> URI Class Initialized
INFO - 2018-10-23 14:17:57 --> Router Class Initialized
INFO - 2018-10-23 14:17:57 --> Output Class Initialized
INFO - 2018-10-23 14:17:57 --> Security Class Initialized
DEBUG - 2018-10-23 14:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:17:57 --> CSRF cookie sent
INFO - 2018-10-23 14:17:57 --> CSRF token verified
INFO - 2018-10-23 14:17:57 --> Input Class Initialized
INFO - 2018-10-23 14:17:57 --> Language Class Initialized
INFO - 2018-10-23 14:17:57 --> Loader Class Initialized
INFO - 2018-10-23 14:17:57 --> Helper loaded: url_helper
INFO - 2018-10-23 14:17:57 --> Helper loaded: form_helper
INFO - 2018-10-23 14:17:57 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:17:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:17:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:17:57 --> User Agent Class Initialized
INFO - 2018-10-23 14:17:57 --> Controller Class Initialized
INFO - 2018-10-23 14:17:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:17:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:17:57 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:17:57 --> Pixel_Model class loaded
INFO - 2018-10-23 14:17:57 --> Database Driver Class Initialized
INFO - 2018-10-23 14:17:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:17:58 --> Form Validation Class Initialized
INFO - 2018-10-23 14:17:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:17:58 --> Database Driver Class Initialized
INFO - 2018-10-23 14:17:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:17:58 --> Config Class Initialized
INFO - 2018-10-23 14:17:58 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:17:58 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:17:58 --> Utf8 Class Initialized
INFO - 2018-10-23 14:17:58 --> URI Class Initialized
INFO - 2018-10-23 14:17:58 --> Router Class Initialized
INFO - 2018-10-23 14:17:58 --> Output Class Initialized
INFO - 2018-10-23 14:17:58 --> Security Class Initialized
DEBUG - 2018-10-23 14:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:17:58 --> CSRF cookie sent
INFO - 2018-10-23 14:17:58 --> Input Class Initialized
INFO - 2018-10-23 14:17:58 --> Language Class Initialized
INFO - 2018-10-23 14:17:58 --> Loader Class Initialized
INFO - 2018-10-23 14:17:58 --> Helper loaded: url_helper
INFO - 2018-10-23 14:17:58 --> Helper loaded: form_helper
INFO - 2018-10-23 14:17:58 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:17:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:17:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:17:58 --> User Agent Class Initialized
INFO - 2018-10-23 14:17:58 --> Controller Class Initialized
INFO - 2018-10-23 14:17:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:17:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:17:58 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:17:58 --> Pixel_Model class loaded
INFO - 2018-10-23 14:17:58 --> Database Driver Class Initialized
INFO - 2018-10-23 14:17:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:17:58 --> Database Driver Class Initialized
INFO - 2018-10-23 14:17:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:17:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:17:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:17:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:17:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:17:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:17:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:17:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/your_job.php
INFO - 2018-10-23 14:17:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:17:58 --> Final output sent to browser
DEBUG - 2018-10-23 14:17:58 --> Total execution time: 0.4196
INFO - 2018-10-23 14:18:00 --> Config Class Initialized
INFO - 2018-10-23 14:18:00 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:18:00 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:18:00 --> Utf8 Class Initialized
INFO - 2018-10-23 14:18:00 --> URI Class Initialized
INFO - 2018-10-23 14:18:00 --> Router Class Initialized
INFO - 2018-10-23 14:18:00 --> Output Class Initialized
INFO - 2018-10-23 14:18:00 --> Security Class Initialized
DEBUG - 2018-10-23 14:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:18:00 --> CSRF cookie sent
INFO - 2018-10-23 14:18:00 --> CSRF token verified
INFO - 2018-10-23 14:18:00 --> Input Class Initialized
INFO - 2018-10-23 14:18:00 --> Language Class Initialized
INFO - 2018-10-23 14:18:00 --> Loader Class Initialized
INFO - 2018-10-23 14:18:00 --> Helper loaded: url_helper
INFO - 2018-10-23 14:18:00 --> Helper loaded: form_helper
INFO - 2018-10-23 14:18:00 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:18:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:18:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:18:00 --> User Agent Class Initialized
INFO - 2018-10-23 14:18:01 --> Controller Class Initialized
INFO - 2018-10-23 14:18:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:18:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:18:01 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:18:01 --> Pixel_Model class loaded
INFO - 2018-10-23 14:18:01 --> Database Driver Class Initialized
INFO - 2018-10-23 14:18:01 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:18:01 --> Form Validation Class Initialized
INFO - 2018-10-23 14:18:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:18:01 --> Database Driver Class Initialized
INFO - 2018-10-23 14:18:01 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:18:01 --> Config Class Initialized
INFO - 2018-10-23 14:18:01 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:18:01 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:18:01 --> Utf8 Class Initialized
INFO - 2018-10-23 14:18:01 --> URI Class Initialized
INFO - 2018-10-23 14:18:01 --> Router Class Initialized
INFO - 2018-10-23 14:18:01 --> Output Class Initialized
INFO - 2018-10-23 14:18:01 --> Security Class Initialized
DEBUG - 2018-10-23 14:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:18:01 --> CSRF cookie sent
INFO - 2018-10-23 14:18:01 --> Input Class Initialized
INFO - 2018-10-23 14:18:01 --> Language Class Initialized
INFO - 2018-10-23 14:18:01 --> Loader Class Initialized
INFO - 2018-10-23 14:18:01 --> Helper loaded: url_helper
INFO - 2018-10-23 14:18:01 --> Helper loaded: form_helper
INFO - 2018-10-23 14:18:01 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:18:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:18:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:18:01 --> User Agent Class Initialized
INFO - 2018-10-23 14:18:01 --> Controller Class Initialized
INFO - 2018-10-23 14:18:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:18:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:18:01 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:18:01 --> Pixel_Model class loaded
INFO - 2018-10-23 14:18:01 --> Database Driver Class Initialized
INFO - 2018-10-23 14:18:01 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:18:01 --> Database Driver Class Initialized
INFO - 2018-10-23 14:18:01 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:18:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:18:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:18:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner.php
INFO - 2018-10-23 14:18:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:18:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:18:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:18:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:18:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/relation_ship_status.php
INFO - 2018-10-23 14:18:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:18:01 --> Final output sent to browser
DEBUG - 2018-10-23 14:18:01 --> Total execution time: 0.4709
INFO - 2018-10-23 14:19:04 --> Config Class Initialized
INFO - 2018-10-23 14:19:04 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:19:04 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:19:04 --> Utf8 Class Initialized
INFO - 2018-10-23 14:19:04 --> URI Class Initialized
DEBUG - 2018-10-23 14:19:04 --> No URI present. Default controller set.
INFO - 2018-10-23 14:19:04 --> Router Class Initialized
INFO - 2018-10-23 14:19:04 --> Output Class Initialized
INFO - 2018-10-23 14:19:04 --> Security Class Initialized
DEBUG - 2018-10-23 14:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:19:04 --> CSRF cookie sent
INFO - 2018-10-23 14:19:04 --> Input Class Initialized
INFO - 2018-10-23 14:19:04 --> Language Class Initialized
INFO - 2018-10-23 14:19:04 --> Loader Class Initialized
INFO - 2018-10-23 14:19:04 --> Helper loaded: url_helper
INFO - 2018-10-23 14:19:04 --> Helper loaded: form_helper
INFO - 2018-10-23 14:19:04 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:19:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:19:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:19:04 --> User Agent Class Initialized
INFO - 2018-10-23 14:19:04 --> Controller Class Initialized
INFO - 2018-10-23 14:19:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:19:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:19:04 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:19:04 --> Pixel_Model class loaded
INFO - 2018-10-23 14:19:04 --> Database Driver Class Initialized
INFO - 2018-10-23 14:19:04 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:19:04 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:19:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:19:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-23 14:19:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:19:05 --> Final output sent to browser
DEBUG - 2018-10-23 14:19:05 --> Total execution time: 0.4024
INFO - 2018-10-23 14:19:07 --> Config Class Initialized
INFO - 2018-10-23 14:19:07 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:19:07 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:19:07 --> Utf8 Class Initialized
INFO - 2018-10-23 14:19:07 --> URI Class Initialized
INFO - 2018-10-23 14:19:07 --> Router Class Initialized
INFO - 2018-10-23 14:19:07 --> Output Class Initialized
INFO - 2018-10-23 14:19:07 --> Security Class Initialized
DEBUG - 2018-10-23 14:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:19:07 --> CSRF cookie sent
INFO - 2018-10-23 14:19:07 --> Input Class Initialized
INFO - 2018-10-23 14:19:07 --> Language Class Initialized
INFO - 2018-10-23 14:19:07 --> Loader Class Initialized
INFO - 2018-10-23 14:19:07 --> Helper loaded: url_helper
INFO - 2018-10-23 14:19:07 --> Helper loaded: form_helper
INFO - 2018-10-23 14:19:08 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:19:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:19:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:19:08 --> User Agent Class Initialized
INFO - 2018-10-23 14:19:08 --> Controller Class Initialized
INFO - 2018-10-23 14:19:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:19:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:19:08 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:19:08 --> Pixel_Model class loaded
INFO - 2018-10-23 14:19:08 --> Database Driver Class Initialized
INFO - 2018-10-23 14:19:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:19:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:19:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:19:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:19:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:19:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:19:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:19:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-23 14:19:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:19:08 --> Final output sent to browser
DEBUG - 2018-10-23 14:19:08 --> Total execution time: 0.4786
INFO - 2018-10-23 14:19:10 --> Config Class Initialized
INFO - 2018-10-23 14:19:10 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:19:10 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:19:10 --> Utf8 Class Initialized
INFO - 2018-10-23 14:19:10 --> URI Class Initialized
INFO - 2018-10-23 14:19:10 --> Router Class Initialized
INFO - 2018-10-23 14:19:10 --> Output Class Initialized
INFO - 2018-10-23 14:19:10 --> Security Class Initialized
DEBUG - 2018-10-23 14:19:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:19:10 --> CSRF cookie sent
INFO - 2018-10-23 14:19:10 --> CSRF token verified
INFO - 2018-10-23 14:19:10 --> Input Class Initialized
INFO - 2018-10-23 14:19:10 --> Language Class Initialized
INFO - 2018-10-23 14:19:10 --> Loader Class Initialized
INFO - 2018-10-23 14:19:10 --> Helper loaded: url_helper
INFO - 2018-10-23 14:19:10 --> Helper loaded: form_helper
INFO - 2018-10-23 14:19:10 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:19:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:19:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:19:10 --> User Agent Class Initialized
INFO - 2018-10-23 14:19:10 --> Controller Class Initialized
INFO - 2018-10-23 14:19:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:19:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:19:10 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:19:10 --> Pixel_Model class loaded
INFO - 2018-10-23 14:19:10 --> Database Driver Class Initialized
INFO - 2018-10-23 14:19:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:19:10 --> Form Validation Class Initialized
INFO - 2018-10-23 14:19:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:19:10 --> Database Driver Class Initialized
INFO - 2018-10-23 14:19:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:19:10 --> Config Class Initialized
INFO - 2018-10-23 14:19:10 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:19:10 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:19:10 --> Utf8 Class Initialized
INFO - 2018-10-23 14:19:10 --> URI Class Initialized
INFO - 2018-10-23 14:19:10 --> Router Class Initialized
INFO - 2018-10-23 14:19:10 --> Output Class Initialized
INFO - 2018-10-23 14:19:10 --> Security Class Initialized
DEBUG - 2018-10-23 14:19:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:19:10 --> CSRF cookie sent
INFO - 2018-10-23 14:19:10 --> Input Class Initialized
INFO - 2018-10-23 14:19:10 --> Language Class Initialized
INFO - 2018-10-23 14:19:10 --> Loader Class Initialized
INFO - 2018-10-23 14:19:10 --> Helper loaded: url_helper
INFO - 2018-10-23 14:19:10 --> Helper loaded: form_helper
INFO - 2018-10-23 14:19:10 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:19:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:19:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:19:10 --> User Agent Class Initialized
INFO - 2018-10-23 14:19:10 --> Controller Class Initialized
INFO - 2018-10-23 14:19:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:19:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:19:10 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:19:10 --> Pixel_Model class loaded
INFO - 2018-10-23 14:19:10 --> Database Driver Class Initialized
INFO - 2018-10-23 14:19:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:19:10 --> Database Driver Class Initialized
INFO - 2018-10-23 14:19:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:19:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:19:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:19:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:19:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:19:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:19:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:19:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-23 14:19:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:19:11 --> Final output sent to browser
DEBUG - 2018-10-23 14:19:11 --> Total execution time: 0.4627
INFO - 2018-10-23 14:19:14 --> Config Class Initialized
INFO - 2018-10-23 14:19:14 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:19:14 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:19:14 --> Utf8 Class Initialized
INFO - 2018-10-23 14:19:14 --> URI Class Initialized
INFO - 2018-10-23 14:19:14 --> Router Class Initialized
INFO - 2018-10-23 14:19:14 --> Output Class Initialized
INFO - 2018-10-23 14:19:14 --> Security Class Initialized
DEBUG - 2018-10-23 14:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:19:14 --> CSRF cookie sent
INFO - 2018-10-23 14:19:14 --> CSRF token verified
INFO - 2018-10-23 14:19:14 --> Input Class Initialized
INFO - 2018-10-23 14:19:14 --> Language Class Initialized
INFO - 2018-10-23 14:19:14 --> Loader Class Initialized
INFO - 2018-10-23 14:19:14 --> Helper loaded: url_helper
INFO - 2018-10-23 14:19:14 --> Helper loaded: form_helper
INFO - 2018-10-23 14:19:14 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:19:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:19:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:19:14 --> User Agent Class Initialized
INFO - 2018-10-23 14:19:14 --> Controller Class Initialized
INFO - 2018-10-23 14:19:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:19:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:19:14 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:19:14 --> Pixel_Model class loaded
INFO - 2018-10-23 14:19:14 --> Database Driver Class Initialized
INFO - 2018-10-23 14:19:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:19:14 --> Form Validation Class Initialized
INFO - 2018-10-23 14:19:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:19:14 --> Database Driver Class Initialized
INFO - 2018-10-23 14:19:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:19:14 --> Config Class Initialized
INFO - 2018-10-23 14:19:14 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:19:14 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:19:14 --> Utf8 Class Initialized
INFO - 2018-10-23 14:19:14 --> URI Class Initialized
INFO - 2018-10-23 14:19:14 --> Router Class Initialized
INFO - 2018-10-23 14:19:14 --> Output Class Initialized
INFO - 2018-10-23 14:19:14 --> Security Class Initialized
DEBUG - 2018-10-23 14:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:19:14 --> CSRF cookie sent
INFO - 2018-10-23 14:19:14 --> Input Class Initialized
INFO - 2018-10-23 14:19:14 --> Language Class Initialized
INFO - 2018-10-23 14:19:14 --> Loader Class Initialized
INFO - 2018-10-23 14:19:14 --> Helper loaded: url_helper
INFO - 2018-10-23 14:19:14 --> Helper loaded: form_helper
INFO - 2018-10-23 14:19:14 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:19:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:19:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:19:14 --> User Agent Class Initialized
INFO - 2018-10-23 14:19:14 --> Controller Class Initialized
INFO - 2018-10-23 14:19:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:19:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:19:14 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:19:14 --> Pixel_Model class loaded
INFO - 2018-10-23 14:19:14 --> Database Driver Class Initialized
INFO - 2018-10-23 14:19:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:19:14 --> Database Driver Class Initialized
INFO - 2018-10-23 14:19:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:19:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:19:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:19:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:19:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:19:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:19:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:19:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/your_job.php
INFO - 2018-10-23 14:19:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:19:15 --> Final output sent to browser
DEBUG - 2018-10-23 14:19:15 --> Total execution time: 0.4551
INFO - 2018-10-23 14:19:16 --> Config Class Initialized
INFO - 2018-10-23 14:19:16 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:19:16 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:19:16 --> Utf8 Class Initialized
INFO - 2018-10-23 14:19:16 --> URI Class Initialized
INFO - 2018-10-23 14:19:16 --> Router Class Initialized
INFO - 2018-10-23 14:19:16 --> Output Class Initialized
INFO - 2018-10-23 14:19:16 --> Security Class Initialized
DEBUG - 2018-10-23 14:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:19:16 --> CSRF cookie sent
INFO - 2018-10-23 14:19:16 --> CSRF token verified
INFO - 2018-10-23 14:19:16 --> Input Class Initialized
INFO - 2018-10-23 14:19:16 --> Language Class Initialized
INFO - 2018-10-23 14:19:16 --> Loader Class Initialized
INFO - 2018-10-23 14:19:16 --> Helper loaded: url_helper
INFO - 2018-10-23 14:19:16 --> Helper loaded: form_helper
INFO - 2018-10-23 14:19:16 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:19:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:19:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:19:16 --> User Agent Class Initialized
INFO - 2018-10-23 14:19:16 --> Controller Class Initialized
INFO - 2018-10-23 14:19:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:19:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:19:16 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:19:16 --> Pixel_Model class loaded
INFO - 2018-10-23 14:19:16 --> Database Driver Class Initialized
INFO - 2018-10-23 14:19:16 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:19:16 --> Form Validation Class Initialized
INFO - 2018-10-23 14:19:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:19:16 --> Database Driver Class Initialized
INFO - 2018-10-23 14:19:16 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:19:16 --> Config Class Initialized
INFO - 2018-10-23 14:19:16 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:19:16 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:19:16 --> Utf8 Class Initialized
INFO - 2018-10-23 14:19:16 --> URI Class Initialized
INFO - 2018-10-23 14:19:16 --> Router Class Initialized
INFO - 2018-10-23 14:19:16 --> Output Class Initialized
INFO - 2018-10-23 14:19:16 --> Security Class Initialized
DEBUG - 2018-10-23 14:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:19:16 --> CSRF cookie sent
INFO - 2018-10-23 14:19:16 --> Input Class Initialized
INFO - 2018-10-23 14:19:16 --> Language Class Initialized
INFO - 2018-10-23 14:19:16 --> Loader Class Initialized
INFO - 2018-10-23 14:19:16 --> Helper loaded: url_helper
INFO - 2018-10-23 14:19:16 --> Helper loaded: form_helper
INFO - 2018-10-23 14:19:16 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:19:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:19:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:19:16 --> User Agent Class Initialized
INFO - 2018-10-23 14:19:16 --> Controller Class Initialized
INFO - 2018-10-23 14:19:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:19:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:19:16 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:19:16 --> Pixel_Model class loaded
INFO - 2018-10-23 14:19:16 --> Database Driver Class Initialized
INFO - 2018-10-23 14:19:16 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:19:16 --> Database Driver Class Initialized
INFO - 2018-10-23 14:19:16 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:19:16 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:19:16 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:19:16 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner.php
INFO - 2018-10-23 14:19:16 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:19:16 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:19:16 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:19:16 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:19:16 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/relation_ship_status.php
INFO - 2018-10-23 14:19:16 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:19:16 --> Final output sent to browser
DEBUG - 2018-10-23 14:19:17 --> Total execution time: 0.4535
INFO - 2018-10-23 14:19:19 --> Config Class Initialized
INFO - 2018-10-23 14:19:19 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:19:19 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:19:19 --> Utf8 Class Initialized
INFO - 2018-10-23 14:19:19 --> URI Class Initialized
INFO - 2018-10-23 14:19:19 --> Router Class Initialized
INFO - 2018-10-23 14:19:19 --> Output Class Initialized
INFO - 2018-10-23 14:19:19 --> Security Class Initialized
DEBUG - 2018-10-23 14:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:19:19 --> CSRF cookie sent
INFO - 2018-10-23 14:19:19 --> CSRF token verified
INFO - 2018-10-23 14:19:19 --> Input Class Initialized
INFO - 2018-10-23 14:19:19 --> Language Class Initialized
INFO - 2018-10-23 14:19:19 --> Loader Class Initialized
INFO - 2018-10-23 14:19:19 --> Helper loaded: url_helper
INFO - 2018-10-23 14:19:19 --> Helper loaded: form_helper
INFO - 2018-10-23 14:19:19 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:19:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:19:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:19:19 --> User Agent Class Initialized
INFO - 2018-10-23 14:19:19 --> Controller Class Initialized
INFO - 2018-10-23 14:19:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:19:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:19:19 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:19:19 --> Pixel_Model class loaded
INFO - 2018-10-23 14:19:19 --> Database Driver Class Initialized
INFO - 2018-10-23 14:19:19 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:19:19 --> Form Validation Class Initialized
INFO - 2018-10-23 14:19:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:19:19 --> Database Driver Class Initialized
INFO - 2018-10-23 14:19:19 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:19:19 --> Config Class Initialized
INFO - 2018-10-23 14:19:19 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:19:19 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:19:19 --> Utf8 Class Initialized
INFO - 2018-10-23 14:19:19 --> URI Class Initialized
INFO - 2018-10-23 14:19:19 --> Router Class Initialized
INFO - 2018-10-23 14:19:19 --> Output Class Initialized
INFO - 2018-10-23 14:19:19 --> Security Class Initialized
DEBUG - 2018-10-23 14:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:19:19 --> CSRF cookie sent
INFO - 2018-10-23 14:19:20 --> Input Class Initialized
INFO - 2018-10-23 14:19:20 --> Language Class Initialized
INFO - 2018-10-23 14:19:20 --> Loader Class Initialized
INFO - 2018-10-23 14:19:20 --> Helper loaded: url_helper
INFO - 2018-10-23 14:19:20 --> Helper loaded: form_helper
INFO - 2018-10-23 14:19:20 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:19:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:19:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:19:20 --> User Agent Class Initialized
INFO - 2018-10-23 14:19:20 --> Controller Class Initialized
INFO - 2018-10-23 14:19:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:19:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:19:20 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:19:20 --> Pixel_Model class loaded
INFO - 2018-10-23 14:19:20 --> Database Driver Class Initialized
INFO - 2018-10-23 14:19:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:19:20 --> Database Driver Class Initialized
INFO - 2018-10-23 14:19:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:19:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:19:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:19:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:19:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:19:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:19:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:19:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/income.php
INFO - 2018-10-23 14:19:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:19:20 --> Final output sent to browser
DEBUG - 2018-10-23 14:19:20 --> Total execution time: 0.4969
INFO - 2018-10-23 14:19:23 --> Config Class Initialized
INFO - 2018-10-23 14:19:23 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:19:24 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:19:24 --> Utf8 Class Initialized
INFO - 2018-10-23 14:19:24 --> URI Class Initialized
INFO - 2018-10-23 14:19:24 --> Router Class Initialized
INFO - 2018-10-23 14:19:24 --> Output Class Initialized
INFO - 2018-10-23 14:19:24 --> Security Class Initialized
DEBUG - 2018-10-23 14:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:19:24 --> CSRF cookie sent
INFO - 2018-10-23 14:19:24 --> CSRF token verified
INFO - 2018-10-23 14:19:24 --> Input Class Initialized
INFO - 2018-10-23 14:19:24 --> Language Class Initialized
INFO - 2018-10-23 14:19:24 --> Loader Class Initialized
INFO - 2018-10-23 14:19:24 --> Helper loaded: url_helper
INFO - 2018-10-23 14:19:24 --> Helper loaded: form_helper
INFO - 2018-10-23 14:19:24 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:19:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:19:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:19:24 --> User Agent Class Initialized
INFO - 2018-10-23 14:19:24 --> Controller Class Initialized
INFO - 2018-10-23 14:19:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:19:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:19:24 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:19:24 --> Pixel_Model class loaded
INFO - 2018-10-23 14:19:24 --> Database Driver Class Initialized
INFO - 2018-10-23 14:19:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:19:24 --> Form Validation Class Initialized
INFO - 2018-10-23 14:19:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:19:24 --> Database Driver Class Initialized
INFO - 2018-10-23 14:19:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:19:24 --> Config Class Initialized
INFO - 2018-10-23 14:19:24 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:19:24 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:19:24 --> Utf8 Class Initialized
INFO - 2018-10-23 14:19:24 --> URI Class Initialized
INFO - 2018-10-23 14:19:24 --> Router Class Initialized
INFO - 2018-10-23 14:19:24 --> Output Class Initialized
INFO - 2018-10-23 14:19:24 --> Security Class Initialized
DEBUG - 2018-10-23 14:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:19:24 --> CSRF cookie sent
INFO - 2018-10-23 14:19:24 --> Input Class Initialized
INFO - 2018-10-23 14:19:24 --> Language Class Initialized
INFO - 2018-10-23 14:19:24 --> Loader Class Initialized
INFO - 2018-10-23 14:19:24 --> Helper loaded: url_helper
INFO - 2018-10-23 14:19:24 --> Helper loaded: form_helper
INFO - 2018-10-23 14:19:24 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:19:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:19:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:19:24 --> User Agent Class Initialized
INFO - 2018-10-23 14:19:24 --> Controller Class Initialized
INFO - 2018-10-23 14:19:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:19:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:19:24 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:19:24 --> Pixel_Model class loaded
INFO - 2018-10-23 14:19:24 --> Database Driver Class Initialized
INFO - 2018-10-23 14:19:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:19:24 --> Database Driver Class Initialized
INFO - 2018-10-23 14:19:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:19:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:19:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:19:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:19:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:19:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:19:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:19:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/marriage.php
INFO - 2018-10-23 14:19:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:19:24 --> Final output sent to browser
DEBUG - 2018-10-23 14:19:24 --> Total execution time: 0.4471
INFO - 2018-10-23 14:19:58 --> Config Class Initialized
INFO - 2018-10-23 14:19:58 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:19:58 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:19:58 --> Utf8 Class Initialized
INFO - 2018-10-23 14:19:58 --> URI Class Initialized
INFO - 2018-10-23 14:19:58 --> Router Class Initialized
INFO - 2018-10-23 14:19:58 --> Output Class Initialized
INFO - 2018-10-23 14:19:58 --> Security Class Initialized
DEBUG - 2018-10-23 14:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:19:58 --> CSRF cookie sent
INFO - 2018-10-23 14:19:58 --> CSRF token verified
INFO - 2018-10-23 14:19:58 --> Input Class Initialized
INFO - 2018-10-23 14:19:58 --> Language Class Initialized
INFO - 2018-10-23 14:19:58 --> Loader Class Initialized
INFO - 2018-10-23 14:19:58 --> Helper loaded: url_helper
INFO - 2018-10-23 14:19:58 --> Helper loaded: form_helper
INFO - 2018-10-23 14:19:58 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:19:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:19:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:19:58 --> User Agent Class Initialized
INFO - 2018-10-23 14:19:58 --> Controller Class Initialized
INFO - 2018-10-23 14:19:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:19:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:19:58 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:19:58 --> Pixel_Model class loaded
INFO - 2018-10-23 14:19:58 --> Database Driver Class Initialized
INFO - 2018-10-23 14:19:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:19:58 --> Form Validation Class Initialized
INFO - 2018-10-23 14:19:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:19:58 --> Database Driver Class Initialized
INFO - 2018-10-23 14:19:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:19:58 --> Config Class Initialized
INFO - 2018-10-23 14:19:58 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:19:58 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:19:58 --> Utf8 Class Initialized
INFO - 2018-10-23 14:19:58 --> URI Class Initialized
INFO - 2018-10-23 14:19:58 --> Router Class Initialized
INFO - 2018-10-23 14:19:58 --> Output Class Initialized
INFO - 2018-10-23 14:19:58 --> Security Class Initialized
DEBUG - 2018-10-23 14:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:19:58 --> CSRF cookie sent
INFO - 2018-10-23 14:19:58 --> Input Class Initialized
INFO - 2018-10-23 14:19:58 --> Language Class Initialized
INFO - 2018-10-23 14:19:58 --> Loader Class Initialized
INFO - 2018-10-23 14:19:58 --> Helper loaded: url_helper
INFO - 2018-10-23 14:19:58 --> Helper loaded: form_helper
INFO - 2018-10-23 14:19:58 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:19:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:19:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:19:58 --> User Agent Class Initialized
INFO - 2018-10-23 14:19:58 --> Controller Class Initialized
INFO - 2018-10-23 14:19:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:19:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:19:58 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:19:58 --> Pixel_Model class loaded
INFO - 2018-10-23 14:19:58 --> Database Driver Class Initialized
INFO - 2018-10-23 14:19:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:19:58 --> Database Driver Class Initialized
INFO - 2018-10-23 14:19:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:19:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:19:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:19:59 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:19:59 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:19:59 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:19:59 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:19:59 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/kids.php
INFO - 2018-10-23 14:19:59 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:19:59 --> Final output sent to browser
DEBUG - 2018-10-23 14:19:59 --> Total execution time: 0.5414
INFO - 2018-10-23 14:20:07 --> Config Class Initialized
INFO - 2018-10-23 14:20:07 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:20:07 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:20:07 --> Utf8 Class Initialized
INFO - 2018-10-23 14:20:07 --> URI Class Initialized
INFO - 2018-10-23 14:20:07 --> Router Class Initialized
INFO - 2018-10-23 14:20:07 --> Output Class Initialized
INFO - 2018-10-23 14:20:07 --> Security Class Initialized
DEBUG - 2018-10-23 14:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:20:07 --> CSRF cookie sent
INFO - 2018-10-23 14:20:07 --> CSRF token verified
INFO - 2018-10-23 14:20:07 --> Input Class Initialized
INFO - 2018-10-23 14:20:07 --> Language Class Initialized
INFO - 2018-10-23 14:20:07 --> Loader Class Initialized
INFO - 2018-10-23 14:20:07 --> Helper loaded: url_helper
INFO - 2018-10-23 14:20:08 --> Helper loaded: form_helper
INFO - 2018-10-23 14:20:08 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:20:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:20:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:20:08 --> User Agent Class Initialized
INFO - 2018-10-23 14:20:08 --> Controller Class Initialized
INFO - 2018-10-23 14:20:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:20:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:20:08 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:20:08 --> Pixel_Model class loaded
INFO - 2018-10-23 14:20:08 --> Database Driver Class Initialized
INFO - 2018-10-23 14:20:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:20:08 --> Form Validation Class Initialized
INFO - 2018-10-23 14:20:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:20:08 --> Database Driver Class Initialized
INFO - 2018-10-23 14:20:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:20:08 --> Config Class Initialized
INFO - 2018-10-23 14:20:08 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:20:08 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:20:08 --> Utf8 Class Initialized
INFO - 2018-10-23 14:20:08 --> URI Class Initialized
INFO - 2018-10-23 14:20:08 --> Router Class Initialized
INFO - 2018-10-23 14:20:08 --> Output Class Initialized
INFO - 2018-10-23 14:20:08 --> Security Class Initialized
DEBUG - 2018-10-23 14:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:20:08 --> CSRF cookie sent
INFO - 2018-10-23 14:20:08 --> Input Class Initialized
INFO - 2018-10-23 14:20:08 --> Language Class Initialized
INFO - 2018-10-23 14:20:08 --> Loader Class Initialized
INFO - 2018-10-23 14:20:08 --> Helper loaded: url_helper
INFO - 2018-10-23 14:20:08 --> Helper loaded: form_helper
INFO - 2018-10-23 14:20:08 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:20:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:20:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:20:08 --> User Agent Class Initialized
INFO - 2018-10-23 14:20:08 --> Controller Class Initialized
INFO - 2018-10-23 14:20:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:20:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:20:08 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:20:08 --> Pixel_Model class loaded
INFO - 2018-10-23 14:20:08 --> Database Driver Class Initialized
INFO - 2018-10-23 14:20:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:20:08 --> Database Driver Class Initialized
INFO - 2018-10-23 14:20:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:20:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:20:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:20:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:20:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:20:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:20:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:20:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/pension.php
INFO - 2018-10-23 14:20:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:20:08 --> Final output sent to browser
DEBUG - 2018-10-23 14:20:08 --> Total execution time: 0.4868
INFO - 2018-10-23 14:20:11 --> Config Class Initialized
INFO - 2018-10-23 14:20:11 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:20:11 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:20:11 --> Utf8 Class Initialized
INFO - 2018-10-23 14:20:11 --> URI Class Initialized
INFO - 2018-10-23 14:20:11 --> Router Class Initialized
INFO - 2018-10-23 14:20:11 --> Output Class Initialized
INFO - 2018-10-23 14:20:11 --> Security Class Initialized
DEBUG - 2018-10-23 14:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:20:11 --> CSRF cookie sent
INFO - 2018-10-23 14:20:12 --> CSRF token verified
INFO - 2018-10-23 14:20:12 --> Input Class Initialized
INFO - 2018-10-23 14:20:12 --> Language Class Initialized
INFO - 2018-10-23 14:20:12 --> Loader Class Initialized
INFO - 2018-10-23 14:20:12 --> Helper loaded: url_helper
INFO - 2018-10-23 14:20:12 --> Helper loaded: form_helper
INFO - 2018-10-23 14:20:12 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:20:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:20:12 --> User Agent Class Initialized
INFO - 2018-10-23 14:20:12 --> Controller Class Initialized
INFO - 2018-10-23 14:20:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:20:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:20:12 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:20:12 --> Pixel_Model class loaded
INFO - 2018-10-23 14:20:12 --> Database Driver Class Initialized
INFO - 2018-10-23 14:20:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:20:12 --> Form Validation Class Initialized
INFO - 2018-10-23 14:20:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:20:12 --> Database Driver Class Initialized
INFO - 2018-10-23 14:20:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:20:12 --> Config Class Initialized
INFO - 2018-10-23 14:20:12 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:20:12 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:20:12 --> Utf8 Class Initialized
INFO - 2018-10-23 14:20:12 --> URI Class Initialized
INFO - 2018-10-23 14:20:12 --> Router Class Initialized
INFO - 2018-10-23 14:20:12 --> Output Class Initialized
INFO - 2018-10-23 14:20:12 --> Security Class Initialized
DEBUG - 2018-10-23 14:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:20:12 --> CSRF cookie sent
INFO - 2018-10-23 14:20:12 --> Input Class Initialized
INFO - 2018-10-23 14:20:12 --> Language Class Initialized
INFO - 2018-10-23 14:20:12 --> Loader Class Initialized
INFO - 2018-10-23 14:20:12 --> Helper loaded: url_helper
INFO - 2018-10-23 14:20:12 --> Helper loaded: form_helper
INFO - 2018-10-23 14:20:12 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:20:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:20:12 --> User Agent Class Initialized
INFO - 2018-10-23 14:20:12 --> Controller Class Initialized
INFO - 2018-10-23 14:20:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:20:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:20:12 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:20:12 --> Pixel_Model class loaded
INFO - 2018-10-23 14:20:12 --> Database Driver Class Initialized
INFO - 2018-10-23 14:20:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:20:12 --> Database Driver Class Initialized
INFO - 2018-10-23 14:20:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:20:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:20:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:20:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:20:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:20:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:20:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:20:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/inheritance.php
INFO - 2018-10-23 14:20:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:20:12 --> Final output sent to browser
DEBUG - 2018-10-23 14:20:12 --> Total execution time: 0.5774
INFO - 2018-10-23 14:20:17 --> Config Class Initialized
INFO - 2018-10-23 14:20:17 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:20:17 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:20:17 --> Utf8 Class Initialized
INFO - 2018-10-23 14:20:17 --> URI Class Initialized
DEBUG - 2018-10-23 14:20:17 --> No URI present. Default controller set.
INFO - 2018-10-23 14:20:17 --> Router Class Initialized
INFO - 2018-10-23 14:20:17 --> Output Class Initialized
INFO - 2018-10-23 14:20:17 --> Security Class Initialized
DEBUG - 2018-10-23 14:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:20:17 --> CSRF cookie sent
INFO - 2018-10-23 14:20:17 --> Input Class Initialized
INFO - 2018-10-23 14:20:17 --> Language Class Initialized
INFO - 2018-10-23 14:20:17 --> Loader Class Initialized
INFO - 2018-10-23 14:20:17 --> Helper loaded: url_helper
INFO - 2018-10-23 14:20:17 --> Helper loaded: form_helper
INFO - 2018-10-23 14:20:17 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:20:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:20:17 --> User Agent Class Initialized
INFO - 2018-10-23 14:20:17 --> Controller Class Initialized
INFO - 2018-10-23 14:20:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:20:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:20:17 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:20:17 --> Pixel_Model class loaded
INFO - 2018-10-23 14:20:17 --> Database Driver Class Initialized
INFO - 2018-10-23 14:20:18 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:20:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:20:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:20:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-23 14:20:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:20:18 --> Final output sent to browser
DEBUG - 2018-10-23 14:20:18 --> Total execution time: 0.4195
INFO - 2018-10-23 14:20:21 --> Config Class Initialized
INFO - 2018-10-23 14:20:21 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:20:21 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:20:21 --> Utf8 Class Initialized
INFO - 2018-10-23 14:20:21 --> URI Class Initialized
INFO - 2018-10-23 14:20:21 --> Router Class Initialized
INFO - 2018-10-23 14:20:21 --> Output Class Initialized
INFO - 2018-10-23 14:20:22 --> Security Class Initialized
DEBUG - 2018-10-23 14:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:20:22 --> CSRF cookie sent
INFO - 2018-10-23 14:20:22 --> CSRF token verified
INFO - 2018-10-23 14:20:22 --> Input Class Initialized
INFO - 2018-10-23 14:20:22 --> Language Class Initialized
INFO - 2018-10-23 14:20:22 --> Loader Class Initialized
INFO - 2018-10-23 14:20:22 --> Helper loaded: url_helper
INFO - 2018-10-23 14:20:22 --> Helper loaded: form_helper
INFO - 2018-10-23 14:20:22 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:20:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:20:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:20:22 --> User Agent Class Initialized
INFO - 2018-10-23 14:20:22 --> Controller Class Initialized
INFO - 2018-10-23 14:20:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:20:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:20:22 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:20:22 --> Pixel_Model class loaded
INFO - 2018-10-23 14:20:22 --> Database Driver Class Initialized
INFO - 2018-10-23 14:20:22 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:20:22 --> Form Validation Class Initialized
INFO - 2018-10-23 14:20:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:20:22 --> Database Driver Class Initialized
INFO - 2018-10-23 14:20:22 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:20:22 --> Config Class Initialized
INFO - 2018-10-23 14:20:22 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:20:22 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:20:22 --> Utf8 Class Initialized
INFO - 2018-10-23 14:20:22 --> URI Class Initialized
INFO - 2018-10-23 14:20:22 --> Router Class Initialized
INFO - 2018-10-23 14:20:22 --> Output Class Initialized
INFO - 2018-10-23 14:20:22 --> Security Class Initialized
DEBUG - 2018-10-23 14:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:20:22 --> CSRF cookie sent
INFO - 2018-10-23 14:20:22 --> Input Class Initialized
INFO - 2018-10-23 14:20:22 --> Language Class Initialized
INFO - 2018-10-23 14:20:22 --> Loader Class Initialized
INFO - 2018-10-23 14:20:22 --> Helper loaded: url_helper
INFO - 2018-10-23 14:20:22 --> Helper loaded: form_helper
INFO - 2018-10-23 14:20:22 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:20:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:20:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:20:22 --> User Agent Class Initialized
INFO - 2018-10-23 14:20:22 --> Controller Class Initialized
INFO - 2018-10-23 14:20:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:20:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:20:22 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:20:22 --> Pixel_Model class loaded
INFO - 2018-10-23 14:20:22 --> Database Driver Class Initialized
INFO - 2018-10-23 14:20:22 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:20:22 --> Database Driver Class Initialized
INFO - 2018-10-23 14:20:22 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:20:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:20:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:20:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:20:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:20:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:20:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:20:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-23 14:20:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:20:22 --> Final output sent to browser
DEBUG - 2018-10-23 14:20:23 --> Total execution time: 0.5427
INFO - 2018-10-23 14:20:25 --> Config Class Initialized
INFO - 2018-10-23 14:20:25 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:20:25 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:20:25 --> Utf8 Class Initialized
INFO - 2018-10-23 14:20:25 --> URI Class Initialized
INFO - 2018-10-23 14:20:25 --> Router Class Initialized
INFO - 2018-10-23 14:20:25 --> Output Class Initialized
INFO - 2018-10-23 14:20:25 --> Security Class Initialized
DEBUG - 2018-10-23 14:20:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:20:25 --> CSRF cookie sent
INFO - 2018-10-23 14:20:25 --> CSRF token verified
INFO - 2018-10-23 14:20:25 --> Input Class Initialized
INFO - 2018-10-23 14:20:25 --> Language Class Initialized
INFO - 2018-10-23 14:20:25 --> Loader Class Initialized
INFO - 2018-10-23 14:20:25 --> Helper loaded: url_helper
INFO - 2018-10-23 14:20:25 --> Helper loaded: form_helper
INFO - 2018-10-23 14:20:25 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:20:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:20:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:20:26 --> User Agent Class Initialized
INFO - 2018-10-23 14:20:26 --> Controller Class Initialized
INFO - 2018-10-23 14:20:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:20:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:20:26 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:20:26 --> Pixel_Model class loaded
INFO - 2018-10-23 14:20:26 --> Database Driver Class Initialized
INFO - 2018-10-23 14:20:26 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:20:26 --> Form Validation Class Initialized
INFO - 2018-10-23 14:20:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:20:26 --> Database Driver Class Initialized
INFO - 2018-10-23 14:20:26 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:20:26 --> Config Class Initialized
INFO - 2018-10-23 14:20:26 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:20:26 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:20:26 --> Utf8 Class Initialized
INFO - 2018-10-23 14:20:26 --> URI Class Initialized
INFO - 2018-10-23 14:20:26 --> Router Class Initialized
INFO - 2018-10-23 14:20:26 --> Output Class Initialized
INFO - 2018-10-23 14:20:26 --> Security Class Initialized
DEBUG - 2018-10-23 14:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:20:26 --> CSRF cookie sent
INFO - 2018-10-23 14:20:26 --> Input Class Initialized
INFO - 2018-10-23 14:20:26 --> Language Class Initialized
INFO - 2018-10-23 14:20:26 --> Loader Class Initialized
INFO - 2018-10-23 14:20:26 --> Helper loaded: url_helper
INFO - 2018-10-23 14:20:26 --> Helper loaded: form_helper
INFO - 2018-10-23 14:20:26 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:20:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:20:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:20:26 --> User Agent Class Initialized
INFO - 2018-10-23 14:20:26 --> Controller Class Initialized
INFO - 2018-10-23 14:20:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:20:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:20:26 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:20:26 --> Pixel_Model class loaded
INFO - 2018-10-23 14:20:26 --> Database Driver Class Initialized
INFO - 2018-10-23 14:20:26 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:20:26 --> Database Driver Class Initialized
INFO - 2018-10-23 14:20:26 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:20:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:20:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:20:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:20:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:20:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:20:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:20:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/your_job.php
INFO - 2018-10-23 14:20:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:20:26 --> Final output sent to browser
DEBUG - 2018-10-23 14:20:26 --> Total execution time: 0.4828
INFO - 2018-10-23 14:20:27 --> Config Class Initialized
INFO - 2018-10-23 14:20:27 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:20:27 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:20:27 --> Utf8 Class Initialized
INFO - 2018-10-23 14:20:27 --> URI Class Initialized
INFO - 2018-10-23 14:20:27 --> Router Class Initialized
INFO - 2018-10-23 14:20:27 --> Output Class Initialized
INFO - 2018-10-23 14:20:27 --> Security Class Initialized
DEBUG - 2018-10-23 14:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:20:27 --> CSRF cookie sent
INFO - 2018-10-23 14:20:27 --> CSRF token verified
INFO - 2018-10-23 14:20:27 --> Input Class Initialized
INFO - 2018-10-23 14:20:27 --> Language Class Initialized
INFO - 2018-10-23 14:20:27 --> Loader Class Initialized
INFO - 2018-10-23 14:20:27 --> Helper loaded: url_helper
INFO - 2018-10-23 14:20:27 --> Helper loaded: form_helper
INFO - 2018-10-23 14:20:27 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:20:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:20:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:20:28 --> User Agent Class Initialized
INFO - 2018-10-23 14:20:28 --> Controller Class Initialized
INFO - 2018-10-23 14:20:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:20:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:20:28 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:20:28 --> Pixel_Model class loaded
INFO - 2018-10-23 14:20:28 --> Database Driver Class Initialized
INFO - 2018-10-23 14:20:28 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:20:28 --> Form Validation Class Initialized
INFO - 2018-10-23 14:20:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:20:28 --> Database Driver Class Initialized
INFO - 2018-10-23 14:20:28 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:20:28 --> Config Class Initialized
INFO - 2018-10-23 14:20:28 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:20:28 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:20:28 --> Utf8 Class Initialized
INFO - 2018-10-23 14:20:28 --> URI Class Initialized
INFO - 2018-10-23 14:20:28 --> Router Class Initialized
INFO - 2018-10-23 14:20:28 --> Output Class Initialized
INFO - 2018-10-23 14:20:28 --> Security Class Initialized
DEBUG - 2018-10-23 14:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:20:28 --> CSRF cookie sent
INFO - 2018-10-23 14:20:28 --> Input Class Initialized
INFO - 2018-10-23 14:20:28 --> Language Class Initialized
INFO - 2018-10-23 14:20:28 --> Loader Class Initialized
INFO - 2018-10-23 14:20:28 --> Helper loaded: url_helper
INFO - 2018-10-23 14:20:28 --> Helper loaded: form_helper
INFO - 2018-10-23 14:20:28 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:20:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:20:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:20:28 --> User Agent Class Initialized
INFO - 2018-10-23 14:20:28 --> Controller Class Initialized
INFO - 2018-10-23 14:20:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:20:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:20:28 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:20:28 --> Pixel_Model class loaded
INFO - 2018-10-23 14:20:28 --> Database Driver Class Initialized
INFO - 2018-10-23 14:20:28 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:20:28 --> Database Driver Class Initialized
INFO - 2018-10-23 14:20:28 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:20:28 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:20:28 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:20:28 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner.php
INFO - 2018-10-23 14:20:28 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:20:28 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:20:28 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:20:28 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:20:28 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/relation_ship_status.php
INFO - 2018-10-23 14:20:28 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:20:28 --> Final output sent to browser
DEBUG - 2018-10-23 14:20:28 --> Total execution time: 0.4753
INFO - 2018-10-23 14:20:31 --> Config Class Initialized
INFO - 2018-10-23 14:20:31 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:20:31 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:20:31 --> Utf8 Class Initialized
INFO - 2018-10-23 14:20:31 --> URI Class Initialized
INFO - 2018-10-23 14:20:31 --> Router Class Initialized
INFO - 2018-10-23 14:20:31 --> Output Class Initialized
INFO - 2018-10-23 14:20:31 --> Security Class Initialized
DEBUG - 2018-10-23 14:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:20:31 --> CSRF cookie sent
INFO - 2018-10-23 14:20:31 --> CSRF token verified
INFO - 2018-10-23 14:20:31 --> Input Class Initialized
INFO - 2018-10-23 14:20:31 --> Language Class Initialized
INFO - 2018-10-23 14:20:31 --> Loader Class Initialized
INFO - 2018-10-23 14:20:31 --> Helper loaded: url_helper
INFO - 2018-10-23 14:20:31 --> Helper loaded: form_helper
INFO - 2018-10-23 14:20:31 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:20:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:20:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:20:31 --> User Agent Class Initialized
INFO - 2018-10-23 14:20:31 --> Controller Class Initialized
INFO - 2018-10-23 14:20:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:20:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:20:31 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:20:31 --> Pixel_Model class loaded
INFO - 2018-10-23 14:20:31 --> Database Driver Class Initialized
INFO - 2018-10-23 14:20:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:20:31 --> Form Validation Class Initialized
INFO - 2018-10-23 14:20:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:20:31 --> Database Driver Class Initialized
INFO - 2018-10-23 14:20:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:20:31 --> Config Class Initialized
INFO - 2018-10-23 14:20:31 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:20:31 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:20:31 --> Utf8 Class Initialized
INFO - 2018-10-23 14:20:32 --> URI Class Initialized
INFO - 2018-10-23 14:20:32 --> Router Class Initialized
INFO - 2018-10-23 14:20:32 --> Output Class Initialized
INFO - 2018-10-23 14:20:32 --> Security Class Initialized
DEBUG - 2018-10-23 14:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:20:32 --> CSRF cookie sent
INFO - 2018-10-23 14:20:32 --> Input Class Initialized
INFO - 2018-10-23 14:20:32 --> Language Class Initialized
INFO - 2018-10-23 14:20:32 --> Loader Class Initialized
INFO - 2018-10-23 14:20:32 --> Helper loaded: url_helper
INFO - 2018-10-23 14:20:32 --> Helper loaded: form_helper
INFO - 2018-10-23 14:20:32 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:20:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:20:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:20:32 --> User Agent Class Initialized
INFO - 2018-10-23 14:20:32 --> Controller Class Initialized
INFO - 2018-10-23 14:20:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:20:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:20:32 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:20:32 --> Pixel_Model class loaded
INFO - 2018-10-23 14:20:32 --> Database Driver Class Initialized
INFO - 2018-10-23 14:20:32 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:20:32 --> Database Driver Class Initialized
INFO - 2018-10-23 14:20:32 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:20:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:20:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:20:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:20:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:20:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:20:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:20:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/income.php
INFO - 2018-10-23 14:20:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:20:32 --> Final output sent to browser
DEBUG - 2018-10-23 14:20:32 --> Total execution time: 0.4601
INFO - 2018-10-23 14:20:36 --> Config Class Initialized
INFO - 2018-10-23 14:20:36 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:20:36 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:20:36 --> Utf8 Class Initialized
INFO - 2018-10-23 14:20:36 --> URI Class Initialized
INFO - 2018-10-23 14:20:36 --> Router Class Initialized
INFO - 2018-10-23 14:20:36 --> Output Class Initialized
INFO - 2018-10-23 14:20:36 --> Security Class Initialized
DEBUG - 2018-10-23 14:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:20:36 --> CSRF cookie sent
INFO - 2018-10-23 14:20:36 --> CSRF token verified
INFO - 2018-10-23 14:20:36 --> Input Class Initialized
INFO - 2018-10-23 14:20:36 --> Language Class Initialized
INFO - 2018-10-23 14:20:36 --> Loader Class Initialized
INFO - 2018-10-23 14:20:36 --> Helper loaded: url_helper
INFO - 2018-10-23 14:20:36 --> Helper loaded: form_helper
INFO - 2018-10-23 14:20:36 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:20:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:20:36 --> User Agent Class Initialized
INFO - 2018-10-23 14:20:36 --> Controller Class Initialized
INFO - 2018-10-23 14:20:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:20:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:20:36 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:20:36 --> Pixel_Model class loaded
INFO - 2018-10-23 14:20:36 --> Database Driver Class Initialized
INFO - 2018-10-23 14:20:36 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:20:36 --> Form Validation Class Initialized
INFO - 2018-10-23 14:20:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:20:36 --> Database Driver Class Initialized
INFO - 2018-10-23 14:20:36 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:20:36 --> Config Class Initialized
INFO - 2018-10-23 14:20:36 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:20:36 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:20:36 --> Utf8 Class Initialized
INFO - 2018-10-23 14:20:36 --> URI Class Initialized
INFO - 2018-10-23 14:20:36 --> Router Class Initialized
INFO - 2018-10-23 14:20:36 --> Output Class Initialized
INFO - 2018-10-23 14:20:36 --> Security Class Initialized
DEBUG - 2018-10-23 14:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:20:36 --> CSRF cookie sent
INFO - 2018-10-23 14:20:36 --> Input Class Initialized
INFO - 2018-10-23 14:20:36 --> Language Class Initialized
INFO - 2018-10-23 14:20:36 --> Loader Class Initialized
INFO - 2018-10-23 14:20:36 --> Helper loaded: url_helper
INFO - 2018-10-23 14:20:37 --> Helper loaded: form_helper
INFO - 2018-10-23 14:20:37 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:20:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:20:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:20:37 --> User Agent Class Initialized
INFO - 2018-10-23 14:20:37 --> Controller Class Initialized
INFO - 2018-10-23 14:20:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:20:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:20:37 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:20:37 --> Pixel_Model class loaded
INFO - 2018-10-23 14:20:37 --> Database Driver Class Initialized
INFO - 2018-10-23 14:20:37 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:20:37 --> Database Driver Class Initialized
INFO - 2018-10-23 14:20:37 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:20:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:20:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:20:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:20:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:20:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:20:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:20:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/pension.php
INFO - 2018-10-23 14:20:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:20:37 --> Final output sent to browser
DEBUG - 2018-10-23 14:20:37 --> Total execution time: 0.4742
INFO - 2018-10-23 14:24:12 --> Config Class Initialized
INFO - 2018-10-23 14:24:12 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:24:12 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:24:12 --> Utf8 Class Initialized
INFO - 2018-10-23 14:24:12 --> URI Class Initialized
INFO - 2018-10-23 14:24:12 --> Router Class Initialized
INFO - 2018-10-23 14:24:12 --> Output Class Initialized
INFO - 2018-10-23 14:24:12 --> Security Class Initialized
DEBUG - 2018-10-23 14:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:24:12 --> CSRF cookie sent
INFO - 2018-10-23 14:24:12 --> Input Class Initialized
INFO - 2018-10-23 14:24:12 --> Language Class Initialized
ERROR - 2018-10-23 14:24:12 --> 404 Page Not Found: Assets/css
INFO - 2018-10-23 14:25:41 --> Config Class Initialized
INFO - 2018-10-23 14:25:41 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:25:41 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:25:41 --> Utf8 Class Initialized
INFO - 2018-10-23 14:25:41 --> URI Class Initialized
INFO - 2018-10-23 14:25:41 --> Router Class Initialized
INFO - 2018-10-23 14:25:41 --> Output Class Initialized
INFO - 2018-10-23 14:25:41 --> Security Class Initialized
DEBUG - 2018-10-23 14:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:25:41 --> CSRF cookie sent
INFO - 2018-10-23 14:25:41 --> Input Class Initialized
INFO - 2018-10-23 14:25:41 --> Language Class Initialized
INFO - 2018-10-23 14:25:41 --> Loader Class Initialized
INFO - 2018-10-23 14:25:41 --> Helper loaded: url_helper
INFO - 2018-10-23 14:25:41 --> Helper loaded: form_helper
INFO - 2018-10-23 14:25:41 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:25:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:25:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:25:41 --> User Agent Class Initialized
INFO - 2018-10-23 14:25:41 --> Controller Class Initialized
INFO - 2018-10-23 14:25:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:25:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:25:41 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:25:41 --> Pixel_Model class loaded
INFO - 2018-10-23 14:25:41 --> Database Driver Class Initialized
INFO - 2018-10-23 14:25:41 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:25:41 --> Database Driver Class Initialized
INFO - 2018-10-23 14:25:41 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:25:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:25:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:25:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:25:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:25:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:25:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:25:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/pension.php
INFO - 2018-10-23 14:25:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:25:41 --> Final output sent to browser
DEBUG - 2018-10-23 14:25:41 --> Total execution time: 0.4902
INFO - 2018-10-23 14:25:42 --> Config Class Initialized
INFO - 2018-10-23 14:25:42 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:25:42 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:25:42 --> Utf8 Class Initialized
INFO - 2018-10-23 14:25:42 --> URI Class Initialized
INFO - 2018-10-23 14:25:42 --> Router Class Initialized
INFO - 2018-10-23 14:25:42 --> Output Class Initialized
INFO - 2018-10-23 14:25:42 --> Security Class Initialized
DEBUG - 2018-10-23 14:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:25:42 --> CSRF cookie sent
INFO - 2018-10-23 14:25:42 --> Input Class Initialized
INFO - 2018-10-23 14:25:42 --> Language Class Initialized
ERROR - 2018-10-23 14:25:42 --> 404 Page Not Found: Assets/css
INFO - 2018-10-23 14:30:45 --> Config Class Initialized
INFO - 2018-10-23 14:30:45 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:30:45 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:30:45 --> Utf8 Class Initialized
INFO - 2018-10-23 14:30:45 --> URI Class Initialized
INFO - 2018-10-23 14:30:45 --> Router Class Initialized
INFO - 2018-10-23 14:30:45 --> Output Class Initialized
INFO - 2018-10-23 14:30:45 --> Security Class Initialized
DEBUG - 2018-10-23 14:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:30:45 --> CSRF cookie sent
INFO - 2018-10-23 14:30:45 --> Input Class Initialized
INFO - 2018-10-23 14:30:45 --> Language Class Initialized
INFO - 2018-10-23 14:30:45 --> Loader Class Initialized
INFO - 2018-10-23 14:30:45 --> Helper loaded: url_helper
INFO - 2018-10-23 14:30:45 --> Helper loaded: form_helper
INFO - 2018-10-23 14:30:46 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:30:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:30:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:30:46 --> User Agent Class Initialized
INFO - 2018-10-23 14:30:46 --> Controller Class Initialized
INFO - 2018-10-23 14:30:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:30:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:30:46 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:30:46 --> Pixel_Model class loaded
INFO - 2018-10-23 14:30:46 --> Database Driver Class Initialized
INFO - 2018-10-23 14:30:46 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:30:46 --> Database Driver Class Initialized
INFO - 2018-10-23 14:30:46 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:30:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:30:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:30:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:30:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:30:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:30:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:30:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/pension.php
INFO - 2018-10-23 14:30:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:30:46 --> Final output sent to browser
DEBUG - 2018-10-23 14:30:46 --> Total execution time: 0.5198
INFO - 2018-10-23 14:31:29 --> Config Class Initialized
INFO - 2018-10-23 14:31:29 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:31:29 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:31:29 --> Utf8 Class Initialized
INFO - 2018-10-23 14:31:29 --> URI Class Initialized
INFO - 2018-10-23 14:31:29 --> Router Class Initialized
INFO - 2018-10-23 14:31:29 --> Output Class Initialized
INFO - 2018-10-23 14:31:29 --> Security Class Initialized
DEBUG - 2018-10-23 14:31:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:31:29 --> CSRF cookie sent
INFO - 2018-10-23 14:31:29 --> Input Class Initialized
INFO - 2018-10-23 14:31:29 --> Language Class Initialized
INFO - 2018-10-23 14:31:29 --> Loader Class Initialized
INFO - 2018-10-23 14:31:29 --> Helper loaded: url_helper
INFO - 2018-10-23 14:31:29 --> Helper loaded: form_helper
INFO - 2018-10-23 14:31:29 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:31:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:31:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:31:29 --> User Agent Class Initialized
INFO - 2018-10-23 14:31:29 --> Controller Class Initialized
INFO - 2018-10-23 14:31:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:31:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:31:29 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:31:29 --> Pixel_Model class loaded
INFO - 2018-10-23 14:31:29 --> Database Driver Class Initialized
INFO - 2018-10-23 14:31:29 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:31:29 --> Database Driver Class Initialized
INFO - 2018-10-23 14:31:29 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:31:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:31:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:31:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:31:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:31:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:31:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:31:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/pension.php
INFO - 2018-10-23 14:31:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:31:29 --> Final output sent to browser
DEBUG - 2018-10-23 14:31:29 --> Total execution time: 0.5430
INFO - 2018-10-23 14:32:40 --> Config Class Initialized
INFO - 2018-10-23 14:32:40 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:32:40 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:32:40 --> Utf8 Class Initialized
INFO - 2018-10-23 14:32:40 --> URI Class Initialized
INFO - 2018-10-23 14:32:40 --> Router Class Initialized
INFO - 2018-10-23 14:32:40 --> Output Class Initialized
INFO - 2018-10-23 14:32:40 --> Security Class Initialized
DEBUG - 2018-10-23 14:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:32:40 --> CSRF cookie sent
INFO - 2018-10-23 14:32:40 --> Input Class Initialized
INFO - 2018-10-23 14:32:40 --> Language Class Initialized
INFO - 2018-10-23 14:32:40 --> Loader Class Initialized
INFO - 2018-10-23 14:32:40 --> Helper loaded: url_helper
INFO - 2018-10-23 14:32:40 --> Helper loaded: form_helper
INFO - 2018-10-23 14:32:40 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:32:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:32:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:32:40 --> User Agent Class Initialized
INFO - 2018-10-23 14:32:40 --> Controller Class Initialized
INFO - 2018-10-23 14:32:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:32:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:32:40 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:32:40 --> Pixel_Model class loaded
INFO - 2018-10-23 14:32:40 --> Database Driver Class Initialized
INFO - 2018-10-23 14:32:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:32:40 --> Database Driver Class Initialized
INFO - 2018-10-23 14:32:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:32:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:32:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:32:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:32:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:32:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:32:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:32:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/pension.php
INFO - 2018-10-23 14:32:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:32:40 --> Final output sent to browser
DEBUG - 2018-10-23 14:32:40 --> Total execution time: 0.5398
INFO - 2018-10-23 14:32:42 --> Config Class Initialized
INFO - 2018-10-23 14:32:42 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:32:42 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:32:42 --> Utf8 Class Initialized
INFO - 2018-10-23 14:32:42 --> URI Class Initialized
INFO - 2018-10-23 14:32:42 --> Router Class Initialized
INFO - 2018-10-23 14:32:42 --> Output Class Initialized
INFO - 2018-10-23 14:32:42 --> Security Class Initialized
DEBUG - 2018-10-23 14:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:32:42 --> CSRF cookie sent
INFO - 2018-10-23 14:32:42 --> CSRF token verified
INFO - 2018-10-23 14:32:42 --> Input Class Initialized
INFO - 2018-10-23 14:32:42 --> Language Class Initialized
INFO - 2018-10-23 14:32:42 --> Loader Class Initialized
INFO - 2018-10-23 14:32:42 --> Helper loaded: url_helper
INFO - 2018-10-23 14:32:42 --> Helper loaded: form_helper
INFO - 2018-10-23 14:32:42 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:32:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:32:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:32:42 --> User Agent Class Initialized
INFO - 2018-10-23 14:32:42 --> Controller Class Initialized
INFO - 2018-10-23 14:32:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:32:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:32:42 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:32:42 --> Pixel_Model class loaded
INFO - 2018-10-23 14:32:42 --> Database Driver Class Initialized
INFO - 2018-10-23 14:32:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:32:42 --> Form Validation Class Initialized
INFO - 2018-10-23 14:32:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:32:42 --> Database Driver Class Initialized
INFO - 2018-10-23 14:32:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:32:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:32:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:32:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:32:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:32:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:32:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_errors.php
INFO - 2018-10-23 14:32:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:32:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/pension.php
INFO - 2018-10-23 14:32:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:32:42 --> Final output sent to browser
DEBUG - 2018-10-23 14:32:42 --> Total execution time: 0.5759
INFO - 2018-10-23 14:32:48 --> Config Class Initialized
INFO - 2018-10-23 14:32:48 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:32:48 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:32:48 --> Utf8 Class Initialized
INFO - 2018-10-23 14:32:48 --> URI Class Initialized
INFO - 2018-10-23 14:32:48 --> Router Class Initialized
INFO - 2018-10-23 14:32:48 --> Output Class Initialized
INFO - 2018-10-23 14:32:48 --> Security Class Initialized
DEBUG - 2018-10-23 14:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:32:48 --> CSRF cookie sent
INFO - 2018-10-23 14:32:48 --> CSRF token verified
INFO - 2018-10-23 14:32:48 --> Input Class Initialized
INFO - 2018-10-23 14:32:48 --> Language Class Initialized
INFO - 2018-10-23 14:32:48 --> Loader Class Initialized
INFO - 2018-10-23 14:32:48 --> Helper loaded: url_helper
INFO - 2018-10-23 14:32:48 --> Helper loaded: form_helper
INFO - 2018-10-23 14:32:49 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:32:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:32:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:32:49 --> User Agent Class Initialized
INFO - 2018-10-23 14:32:49 --> Controller Class Initialized
INFO - 2018-10-23 14:32:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:32:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:32:49 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:32:49 --> Pixel_Model class loaded
INFO - 2018-10-23 14:32:49 --> Database Driver Class Initialized
INFO - 2018-10-23 14:32:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:32:49 --> Form Validation Class Initialized
INFO - 2018-10-23 14:32:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:32:49 --> Database Driver Class Initialized
INFO - 2018-10-23 14:32:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:32:49 --> Config Class Initialized
INFO - 2018-10-23 14:32:49 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:32:49 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:32:49 --> Utf8 Class Initialized
INFO - 2018-10-23 14:32:49 --> URI Class Initialized
INFO - 2018-10-23 14:32:49 --> Router Class Initialized
INFO - 2018-10-23 14:32:49 --> Output Class Initialized
INFO - 2018-10-23 14:32:49 --> Security Class Initialized
DEBUG - 2018-10-23 14:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:32:49 --> CSRF cookie sent
INFO - 2018-10-23 14:32:49 --> Input Class Initialized
INFO - 2018-10-23 14:32:49 --> Language Class Initialized
INFO - 2018-10-23 14:32:49 --> Loader Class Initialized
INFO - 2018-10-23 14:32:49 --> Helper loaded: url_helper
INFO - 2018-10-23 14:32:49 --> Helper loaded: form_helper
INFO - 2018-10-23 14:32:49 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:32:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:32:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:32:49 --> User Agent Class Initialized
INFO - 2018-10-23 14:32:49 --> Controller Class Initialized
INFO - 2018-10-23 14:32:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:32:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:32:49 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:32:49 --> Pixel_Model class loaded
INFO - 2018-10-23 14:32:49 --> Database Driver Class Initialized
INFO - 2018-10-23 14:32:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:32:49 --> Database Driver Class Initialized
INFO - 2018-10-23 14:32:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:32:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:32:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:32:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:32:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:32:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:32:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:32:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/home_title.php
INFO - 2018-10-23 14:32:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:32:49 --> Final output sent to browser
DEBUG - 2018-10-23 14:32:49 --> Total execution time: 0.5004
INFO - 2018-10-23 14:33:01 --> Config Class Initialized
INFO - 2018-10-23 14:33:01 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:33:01 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:33:01 --> Utf8 Class Initialized
INFO - 2018-10-23 14:33:01 --> URI Class Initialized
INFO - 2018-10-23 14:33:01 --> Router Class Initialized
INFO - 2018-10-23 14:33:01 --> Output Class Initialized
INFO - 2018-10-23 14:33:01 --> Security Class Initialized
DEBUG - 2018-10-23 14:33:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:33:01 --> CSRF cookie sent
INFO - 2018-10-23 14:33:01 --> Input Class Initialized
INFO - 2018-10-23 14:33:01 --> Language Class Initialized
INFO - 2018-10-23 14:33:01 --> Loader Class Initialized
INFO - 2018-10-23 14:33:01 --> Helper loaded: url_helper
INFO - 2018-10-23 14:33:01 --> Helper loaded: form_helper
INFO - 2018-10-23 14:33:01 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:33:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:33:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:33:01 --> User Agent Class Initialized
INFO - 2018-10-23 14:33:01 --> Controller Class Initialized
INFO - 2018-10-23 14:33:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:33:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:33:01 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:33:01 --> Pixel_Model class loaded
INFO - 2018-10-23 14:33:01 --> Database Driver Class Initialized
INFO - 2018-10-23 14:33:01 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:33:01 --> Database Driver Class Initialized
INFO - 2018-10-23 14:33:01 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:33:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:33:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:33:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:33:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:33:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:33:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:33:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/home_title.php
INFO - 2018-10-23 14:33:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:33:02 --> Final output sent to browser
DEBUG - 2018-10-23 14:33:02 --> Total execution time: 0.5142
INFO - 2018-10-23 14:33:03 --> Config Class Initialized
INFO - 2018-10-23 14:33:03 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:33:03 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:33:03 --> Utf8 Class Initialized
INFO - 2018-10-23 14:33:03 --> URI Class Initialized
INFO - 2018-10-23 14:33:03 --> Router Class Initialized
INFO - 2018-10-23 14:33:03 --> Output Class Initialized
INFO - 2018-10-23 14:33:03 --> Security Class Initialized
DEBUG - 2018-10-23 14:33:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:33:03 --> CSRF cookie sent
INFO - 2018-10-23 14:33:03 --> Input Class Initialized
INFO - 2018-10-23 14:33:03 --> Language Class Initialized
INFO - 2018-10-23 14:33:03 --> Loader Class Initialized
INFO - 2018-10-23 14:33:04 --> Helper loaded: url_helper
INFO - 2018-10-23 14:33:04 --> Helper loaded: form_helper
INFO - 2018-10-23 14:33:04 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:33:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:33:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:33:04 --> User Agent Class Initialized
INFO - 2018-10-23 14:33:04 --> Controller Class Initialized
INFO - 2018-10-23 14:33:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:33:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:33:04 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:33:04 --> Pixel_Model class loaded
INFO - 2018-10-23 14:33:04 --> Database Driver Class Initialized
INFO - 2018-10-23 14:33:04 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:33:04 --> Database Driver Class Initialized
INFO - 2018-10-23 14:33:04 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:33:04 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:33:04 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:33:04 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:33:04 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:33:04 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:33:04 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:33:04 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/pension.php
INFO - 2018-10-23 14:33:04 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:33:04 --> Final output sent to browser
DEBUG - 2018-10-23 14:33:04 --> Total execution time: 0.5148
INFO - 2018-10-23 14:33:38 --> Config Class Initialized
INFO - 2018-10-23 14:33:38 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:33:38 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:33:38 --> Utf8 Class Initialized
INFO - 2018-10-23 14:33:38 --> URI Class Initialized
INFO - 2018-10-23 14:33:38 --> Router Class Initialized
INFO - 2018-10-23 14:33:38 --> Output Class Initialized
INFO - 2018-10-23 14:33:38 --> Security Class Initialized
DEBUG - 2018-10-23 14:33:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:33:38 --> CSRF cookie sent
INFO - 2018-10-23 14:33:38 --> Input Class Initialized
INFO - 2018-10-23 14:33:38 --> Language Class Initialized
INFO - 2018-10-23 14:33:38 --> Loader Class Initialized
INFO - 2018-10-23 14:33:38 --> Helper loaded: url_helper
INFO - 2018-10-23 14:33:38 --> Helper loaded: form_helper
INFO - 2018-10-23 14:33:38 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:33:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:33:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:33:38 --> User Agent Class Initialized
INFO - 2018-10-23 14:33:38 --> Controller Class Initialized
INFO - 2018-10-23 14:33:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:33:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:33:38 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:33:38 --> Pixel_Model class loaded
INFO - 2018-10-23 14:33:38 --> Database Driver Class Initialized
INFO - 2018-10-23 14:33:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:33:38 --> Database Driver Class Initialized
INFO - 2018-10-23 14:33:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:33:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:33:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:33:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:33:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:33:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:33:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:33:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/pension.php
INFO - 2018-10-23 14:33:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:33:38 --> Final output sent to browser
DEBUG - 2018-10-23 14:33:38 --> Total execution time: 0.4935
INFO - 2018-10-23 14:33:43 --> Config Class Initialized
INFO - 2018-10-23 14:33:43 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:33:43 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:33:43 --> Utf8 Class Initialized
INFO - 2018-10-23 14:33:43 --> URI Class Initialized
INFO - 2018-10-23 14:33:43 --> Router Class Initialized
INFO - 2018-10-23 14:33:43 --> Output Class Initialized
INFO - 2018-10-23 14:33:43 --> Security Class Initialized
DEBUG - 2018-10-23 14:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:33:43 --> CSRF cookie sent
INFO - 2018-10-23 14:33:43 --> CSRF token verified
INFO - 2018-10-23 14:33:43 --> Input Class Initialized
INFO - 2018-10-23 14:33:43 --> Language Class Initialized
INFO - 2018-10-23 14:33:43 --> Loader Class Initialized
INFO - 2018-10-23 14:33:43 --> Helper loaded: url_helper
INFO - 2018-10-23 14:33:43 --> Helper loaded: form_helper
INFO - 2018-10-23 14:33:43 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:33:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:33:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:33:43 --> User Agent Class Initialized
INFO - 2018-10-23 14:33:43 --> Controller Class Initialized
INFO - 2018-10-23 14:33:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:33:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:33:43 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:33:43 --> Pixel_Model class loaded
INFO - 2018-10-23 14:33:43 --> Database Driver Class Initialized
INFO - 2018-10-23 14:33:43 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:33:43 --> Form Validation Class Initialized
INFO - 2018-10-23 14:33:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:33:43 --> Database Driver Class Initialized
INFO - 2018-10-23 14:33:43 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:33:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:33:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:33:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:33:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:33:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:33:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_errors.php
INFO - 2018-10-23 14:33:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:33:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/pension.php
INFO - 2018-10-23 14:33:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:33:43 --> Final output sent to browser
DEBUG - 2018-10-23 14:33:43 --> Total execution time: 0.5767
INFO - 2018-10-23 14:34:32 --> Config Class Initialized
INFO - 2018-10-23 14:34:32 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:34:32 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:34:32 --> Utf8 Class Initialized
INFO - 2018-10-23 14:34:32 --> URI Class Initialized
INFO - 2018-10-23 14:34:32 --> Router Class Initialized
INFO - 2018-10-23 14:34:32 --> Output Class Initialized
INFO - 2018-10-23 14:34:32 --> Security Class Initialized
DEBUG - 2018-10-23 14:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:34:33 --> CSRF cookie sent
INFO - 2018-10-23 14:34:33 --> Input Class Initialized
INFO - 2018-10-23 14:34:33 --> Language Class Initialized
INFO - 2018-10-23 14:34:33 --> Loader Class Initialized
INFO - 2018-10-23 14:34:33 --> Helper loaded: url_helper
INFO - 2018-10-23 14:34:33 --> Helper loaded: form_helper
INFO - 2018-10-23 14:34:33 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:34:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:34:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:34:33 --> User Agent Class Initialized
INFO - 2018-10-23 14:34:33 --> Controller Class Initialized
INFO - 2018-10-23 14:34:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:34:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:34:33 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:34:33 --> Pixel_Model class loaded
INFO - 2018-10-23 14:34:33 --> Database Driver Class Initialized
INFO - 2018-10-23 14:34:33 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:34:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:34:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:34:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:34:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:34:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:34:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:34:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-23 14:34:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:34:33 --> Final output sent to browser
DEBUG - 2018-10-23 14:34:33 --> Total execution time: 0.4892
INFO - 2018-10-23 14:34:34 --> Config Class Initialized
INFO - 2018-10-23 14:34:34 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:34:34 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:34:34 --> Utf8 Class Initialized
INFO - 2018-10-23 14:34:34 --> URI Class Initialized
INFO - 2018-10-23 14:34:34 --> Router Class Initialized
INFO - 2018-10-23 14:34:34 --> Output Class Initialized
INFO - 2018-10-23 14:34:34 --> Security Class Initialized
DEBUG - 2018-10-23 14:34:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:34:34 --> CSRF cookie sent
INFO - 2018-10-23 14:34:34 --> CSRF token verified
INFO - 2018-10-23 14:34:34 --> Input Class Initialized
INFO - 2018-10-23 14:34:34 --> Language Class Initialized
INFO - 2018-10-23 14:34:34 --> Loader Class Initialized
INFO - 2018-10-23 14:34:34 --> Helper loaded: url_helper
INFO - 2018-10-23 14:34:34 --> Helper loaded: form_helper
INFO - 2018-10-23 14:34:34 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:34:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:34:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:34:34 --> User Agent Class Initialized
INFO - 2018-10-23 14:34:34 --> Controller Class Initialized
INFO - 2018-10-23 14:34:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:34:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:34:35 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:34:35 --> Pixel_Model class loaded
INFO - 2018-10-23 14:34:35 --> Database Driver Class Initialized
INFO - 2018-10-23 14:34:35 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:34:35 --> Form Validation Class Initialized
INFO - 2018-10-23 14:34:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:34:35 --> Database Driver Class Initialized
INFO - 2018-10-23 14:34:35 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:34:35 --> Config Class Initialized
INFO - 2018-10-23 14:34:35 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:34:35 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:34:35 --> Utf8 Class Initialized
INFO - 2018-10-23 14:34:35 --> URI Class Initialized
INFO - 2018-10-23 14:34:35 --> Router Class Initialized
INFO - 2018-10-23 14:34:35 --> Output Class Initialized
INFO - 2018-10-23 14:34:35 --> Security Class Initialized
DEBUG - 2018-10-23 14:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:34:35 --> CSRF cookie sent
INFO - 2018-10-23 14:34:35 --> Input Class Initialized
INFO - 2018-10-23 14:34:35 --> Language Class Initialized
INFO - 2018-10-23 14:34:35 --> Loader Class Initialized
INFO - 2018-10-23 14:34:35 --> Helper loaded: url_helper
INFO - 2018-10-23 14:34:35 --> Helper loaded: form_helper
INFO - 2018-10-23 14:34:35 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:34:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:34:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:34:35 --> User Agent Class Initialized
INFO - 2018-10-23 14:34:35 --> Controller Class Initialized
INFO - 2018-10-23 14:34:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:34:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:34:35 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:34:35 --> Pixel_Model class loaded
INFO - 2018-10-23 14:34:35 --> Database Driver Class Initialized
INFO - 2018-10-23 14:34:35 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:34:35 --> Database Driver Class Initialized
INFO - 2018-10-23 14:34:35 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:34:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:34:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:34:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:34:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:34:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:34:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:34:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-23 14:34:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:34:35 --> Final output sent to browser
DEBUG - 2018-10-23 14:34:35 --> Total execution time: 0.4924
INFO - 2018-10-23 14:37:54 --> Config Class Initialized
INFO - 2018-10-23 14:37:54 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:37:54 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:37:55 --> Utf8 Class Initialized
INFO - 2018-10-23 14:37:55 --> URI Class Initialized
INFO - 2018-10-23 14:37:55 --> Router Class Initialized
INFO - 2018-10-23 14:37:55 --> Output Class Initialized
INFO - 2018-10-23 14:37:55 --> Security Class Initialized
DEBUG - 2018-10-23 14:37:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:37:55 --> CSRF cookie sent
INFO - 2018-10-23 14:37:55 --> Input Class Initialized
INFO - 2018-10-23 14:37:55 --> Language Class Initialized
INFO - 2018-10-23 14:37:55 --> Loader Class Initialized
INFO - 2018-10-23 14:37:55 --> Helper loaded: url_helper
INFO - 2018-10-23 14:37:55 --> Helper loaded: form_helper
INFO - 2018-10-23 14:37:55 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:37:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:37:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:37:55 --> User Agent Class Initialized
INFO - 2018-10-23 14:37:55 --> Controller Class Initialized
INFO - 2018-10-23 14:37:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:37:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:37:55 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:37:55 --> Pixel_Model class loaded
INFO - 2018-10-23 14:37:55 --> Database Driver Class Initialized
INFO - 2018-10-23 14:37:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:37:55 --> Database Driver Class Initialized
INFO - 2018-10-23 14:37:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:37:55 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:37:55 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:37:55 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:37:55 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:37:55 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:37:55 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:37:55 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-23 14:37:55 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:37:55 --> Final output sent to browser
DEBUG - 2018-10-23 14:37:55 --> Total execution time: 0.5002
INFO - 2018-10-23 14:38:42 --> Config Class Initialized
INFO - 2018-10-23 14:38:42 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:38:42 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:38:42 --> Utf8 Class Initialized
INFO - 2018-10-23 14:38:42 --> URI Class Initialized
INFO - 2018-10-23 14:38:43 --> Router Class Initialized
INFO - 2018-10-23 14:38:43 --> Output Class Initialized
INFO - 2018-10-23 14:38:43 --> Security Class Initialized
DEBUG - 2018-10-23 14:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:38:43 --> CSRF cookie sent
INFO - 2018-10-23 14:38:43 --> Input Class Initialized
INFO - 2018-10-23 14:38:43 --> Language Class Initialized
INFO - 2018-10-23 14:38:43 --> Loader Class Initialized
INFO - 2018-10-23 14:38:43 --> Helper loaded: url_helper
INFO - 2018-10-23 14:38:43 --> Helper loaded: form_helper
INFO - 2018-10-23 14:38:43 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:38:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:38:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:38:43 --> User Agent Class Initialized
INFO - 2018-10-23 14:38:43 --> Controller Class Initialized
INFO - 2018-10-23 14:38:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:38:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:38:43 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:38:43 --> Pixel_Model class loaded
INFO - 2018-10-23 14:38:43 --> Database Driver Class Initialized
INFO - 2018-10-23 14:38:43 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:38:43 --> Database Driver Class Initialized
INFO - 2018-10-23 14:38:43 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:38:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:38:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:38:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:38:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:38:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:38:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:38:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-23 14:38:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:38:43 --> Final output sent to browser
DEBUG - 2018-10-23 14:38:43 --> Total execution time: 0.5038
INFO - 2018-10-23 14:39:24 --> Config Class Initialized
INFO - 2018-10-23 14:39:24 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:39:24 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:39:24 --> Utf8 Class Initialized
INFO - 2018-10-23 14:39:24 --> URI Class Initialized
INFO - 2018-10-23 14:39:24 --> Router Class Initialized
INFO - 2018-10-23 14:39:24 --> Output Class Initialized
INFO - 2018-10-23 14:39:24 --> Security Class Initialized
DEBUG - 2018-10-23 14:39:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:39:24 --> CSRF cookie sent
INFO - 2018-10-23 14:39:24 --> Input Class Initialized
INFO - 2018-10-23 14:39:24 --> Language Class Initialized
INFO - 2018-10-23 14:39:24 --> Loader Class Initialized
INFO - 2018-10-23 14:39:24 --> Helper loaded: url_helper
INFO - 2018-10-23 14:39:24 --> Helper loaded: form_helper
INFO - 2018-10-23 14:39:24 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:39:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:39:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:39:24 --> User Agent Class Initialized
INFO - 2018-10-23 14:39:24 --> Controller Class Initialized
INFO - 2018-10-23 14:39:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:39:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:39:24 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:39:24 --> Pixel_Model class loaded
INFO - 2018-10-23 14:39:24 --> Database Driver Class Initialized
INFO - 2018-10-23 14:39:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:39:24 --> Database Driver Class Initialized
INFO - 2018-10-23 14:39:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:39:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:39:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:39:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:39:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:39:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:39:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:39:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-23 14:39:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:39:24 --> Final output sent to browser
DEBUG - 2018-10-23 14:39:24 --> Total execution time: 0.5008
INFO - 2018-10-23 14:39:52 --> Config Class Initialized
INFO - 2018-10-23 14:39:52 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:39:52 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:39:52 --> Utf8 Class Initialized
INFO - 2018-10-23 14:39:52 --> URI Class Initialized
INFO - 2018-10-23 14:39:52 --> Router Class Initialized
INFO - 2018-10-23 14:39:52 --> Output Class Initialized
INFO - 2018-10-23 14:39:52 --> Security Class Initialized
DEBUG - 2018-10-23 14:39:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:39:52 --> CSRF cookie sent
INFO - 2018-10-23 14:39:52 --> Input Class Initialized
INFO - 2018-10-23 14:39:52 --> Language Class Initialized
INFO - 2018-10-23 14:39:52 --> Loader Class Initialized
INFO - 2018-10-23 14:39:52 --> Helper loaded: url_helper
INFO - 2018-10-23 14:39:52 --> Helper loaded: form_helper
INFO - 2018-10-23 14:39:52 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:39:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:39:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:39:53 --> User Agent Class Initialized
INFO - 2018-10-23 14:39:53 --> Controller Class Initialized
INFO - 2018-10-23 14:39:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:39:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:39:53 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:39:53 --> Pixel_Model class loaded
INFO - 2018-10-23 14:39:53 --> Database Driver Class Initialized
INFO - 2018-10-23 14:39:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:39:53 --> Database Driver Class Initialized
INFO - 2018-10-23 14:39:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:39:53 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:39:53 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:39:53 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:39:53 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:39:53 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:39:53 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:39:53 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-23 14:39:53 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:39:53 --> Final output sent to browser
DEBUG - 2018-10-23 14:39:53 --> Total execution time: 0.5047
INFO - 2018-10-23 14:39:59 --> Config Class Initialized
INFO - 2018-10-23 14:39:59 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:39:59 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:39:59 --> Utf8 Class Initialized
INFO - 2018-10-23 14:39:59 --> URI Class Initialized
INFO - 2018-10-23 14:39:59 --> Router Class Initialized
INFO - 2018-10-23 14:39:59 --> Output Class Initialized
INFO - 2018-10-23 14:39:59 --> Security Class Initialized
DEBUG - 2018-10-23 14:39:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:39:59 --> CSRF cookie sent
INFO - 2018-10-23 14:39:59 --> Input Class Initialized
INFO - 2018-10-23 14:39:59 --> Language Class Initialized
ERROR - 2018-10-23 14:39:59 --> 404 Page Not Found: Assets/css
INFO - 2018-10-23 14:41:24 --> Config Class Initialized
INFO - 2018-10-23 14:41:24 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:41:24 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:41:24 --> Utf8 Class Initialized
INFO - 2018-10-23 14:41:24 --> URI Class Initialized
INFO - 2018-10-23 14:41:24 --> Router Class Initialized
INFO - 2018-10-23 14:41:24 --> Output Class Initialized
INFO - 2018-10-23 14:41:24 --> Security Class Initialized
DEBUG - 2018-10-23 14:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:41:24 --> CSRF cookie sent
INFO - 2018-10-23 14:41:24 --> Input Class Initialized
INFO - 2018-10-23 14:41:24 --> Language Class Initialized
INFO - 2018-10-23 14:41:24 --> Loader Class Initialized
INFO - 2018-10-23 14:41:24 --> Helper loaded: url_helper
INFO - 2018-10-23 14:41:24 --> Helper loaded: form_helper
INFO - 2018-10-23 14:41:24 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:41:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:41:24 --> User Agent Class Initialized
INFO - 2018-10-23 14:41:24 --> Controller Class Initialized
INFO - 2018-10-23 14:41:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:41:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:41:24 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:41:25 --> Pixel_Model class loaded
INFO - 2018-10-23 14:41:25 --> Database Driver Class Initialized
INFO - 2018-10-23 14:41:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:41:25 --> Database Driver Class Initialized
INFO - 2018-10-23 14:41:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:41:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:41:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:41:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:41:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:41:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:41:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:41:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-23 14:41:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:41:25 --> Final output sent to browser
DEBUG - 2018-10-23 14:41:25 --> Total execution time: 0.5138
INFO - 2018-10-23 14:41:25 --> Config Class Initialized
INFO - 2018-10-23 14:41:25 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:41:25 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:41:25 --> Utf8 Class Initialized
INFO - 2018-10-23 14:41:25 --> URI Class Initialized
INFO - 2018-10-23 14:41:25 --> Router Class Initialized
INFO - 2018-10-23 14:41:25 --> Output Class Initialized
INFO - 2018-10-23 14:41:25 --> Security Class Initialized
DEBUG - 2018-10-23 14:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:41:25 --> CSRF cookie sent
INFO - 2018-10-23 14:41:25 --> Input Class Initialized
INFO - 2018-10-23 14:41:25 --> Language Class Initialized
ERROR - 2018-10-23 14:41:25 --> 404 Page Not Found: Assets/css
INFO - 2018-10-23 14:42:00 --> Config Class Initialized
INFO - 2018-10-23 14:42:00 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:42:00 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:42:00 --> Utf8 Class Initialized
INFO - 2018-10-23 14:42:00 --> URI Class Initialized
INFO - 2018-10-23 14:42:00 --> Router Class Initialized
INFO - 2018-10-23 14:42:00 --> Output Class Initialized
INFO - 2018-10-23 14:42:00 --> Security Class Initialized
DEBUG - 2018-10-23 14:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:42:00 --> CSRF cookie sent
INFO - 2018-10-23 14:42:00 --> CSRF token verified
INFO - 2018-10-23 14:42:00 --> Input Class Initialized
INFO - 2018-10-23 14:42:00 --> Language Class Initialized
INFO - 2018-10-23 14:42:00 --> Loader Class Initialized
INFO - 2018-10-23 14:42:00 --> Helper loaded: url_helper
INFO - 2018-10-23 14:42:00 --> Helper loaded: form_helper
INFO - 2018-10-23 14:42:00 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:42:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:42:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:42:00 --> User Agent Class Initialized
INFO - 2018-10-23 14:42:00 --> Controller Class Initialized
INFO - 2018-10-23 14:42:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:42:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:42:00 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:42:00 --> Pixel_Model class loaded
INFO - 2018-10-23 14:42:00 --> Database Driver Class Initialized
INFO - 2018-10-23 14:42:00 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:42:00 --> Form Validation Class Initialized
INFO - 2018-10-23 14:42:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:42:00 --> Database Driver Class Initialized
INFO - 2018-10-23 14:42:00 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:42:00 --> Config Class Initialized
INFO - 2018-10-23 14:42:00 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:42:00 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:42:00 --> Utf8 Class Initialized
INFO - 2018-10-23 14:42:00 --> URI Class Initialized
INFO - 2018-10-23 14:42:00 --> Router Class Initialized
INFO - 2018-10-23 14:42:00 --> Output Class Initialized
INFO - 2018-10-23 14:42:00 --> Security Class Initialized
DEBUG - 2018-10-23 14:42:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:42:01 --> CSRF cookie sent
INFO - 2018-10-23 14:42:01 --> Input Class Initialized
INFO - 2018-10-23 14:42:01 --> Language Class Initialized
INFO - 2018-10-23 14:42:01 --> Loader Class Initialized
INFO - 2018-10-23 14:42:01 --> Helper loaded: url_helper
INFO - 2018-10-23 14:42:01 --> Helper loaded: form_helper
INFO - 2018-10-23 14:42:01 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:42:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:42:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:42:01 --> User Agent Class Initialized
INFO - 2018-10-23 14:42:01 --> Controller Class Initialized
INFO - 2018-10-23 14:42:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:42:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:42:01 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:42:01 --> Pixel_Model class loaded
INFO - 2018-10-23 14:42:01 --> Database Driver Class Initialized
INFO - 2018-10-23 14:42:01 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:42:01 --> Database Driver Class Initialized
INFO - 2018-10-23 14:42:01 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:42:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:42:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:42:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:42:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:42:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:42:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:42:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/your_job.php
INFO - 2018-10-23 14:42:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:42:01 --> Final output sent to browser
DEBUG - 2018-10-23 14:42:01 --> Total execution time: 0.5057
INFO - 2018-10-23 14:42:03 --> Config Class Initialized
INFO - 2018-10-23 14:42:03 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:42:03 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:42:03 --> Utf8 Class Initialized
INFO - 2018-10-23 14:42:03 --> URI Class Initialized
INFO - 2018-10-23 14:42:03 --> Router Class Initialized
INFO - 2018-10-23 14:42:03 --> Output Class Initialized
INFO - 2018-10-23 14:42:03 --> Security Class Initialized
DEBUG - 2018-10-23 14:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:42:03 --> CSRF cookie sent
INFO - 2018-10-23 14:42:03 --> CSRF token verified
INFO - 2018-10-23 14:42:03 --> Input Class Initialized
INFO - 2018-10-23 14:42:03 --> Language Class Initialized
INFO - 2018-10-23 14:42:03 --> Loader Class Initialized
INFO - 2018-10-23 14:42:03 --> Helper loaded: url_helper
INFO - 2018-10-23 14:42:03 --> Helper loaded: form_helper
INFO - 2018-10-23 14:42:03 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:42:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:42:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:42:03 --> User Agent Class Initialized
INFO - 2018-10-23 14:42:03 --> Controller Class Initialized
INFO - 2018-10-23 14:42:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:42:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:42:03 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:42:03 --> Pixel_Model class loaded
INFO - 2018-10-23 14:42:03 --> Database Driver Class Initialized
INFO - 2018-10-23 14:42:03 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:42:03 --> Form Validation Class Initialized
INFO - 2018-10-23 14:42:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:42:03 --> Database Driver Class Initialized
INFO - 2018-10-23 14:42:03 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:42:03 --> Config Class Initialized
INFO - 2018-10-23 14:42:03 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:42:03 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:42:03 --> Utf8 Class Initialized
INFO - 2018-10-23 14:42:03 --> URI Class Initialized
INFO - 2018-10-23 14:42:03 --> Router Class Initialized
INFO - 2018-10-23 14:42:03 --> Output Class Initialized
INFO - 2018-10-23 14:42:03 --> Security Class Initialized
DEBUG - 2018-10-23 14:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:42:03 --> CSRF cookie sent
INFO - 2018-10-23 14:42:03 --> Input Class Initialized
INFO - 2018-10-23 14:42:03 --> Language Class Initialized
INFO - 2018-10-23 14:42:03 --> Loader Class Initialized
INFO - 2018-10-23 14:42:03 --> Helper loaded: url_helper
INFO - 2018-10-23 14:42:03 --> Helper loaded: form_helper
INFO - 2018-10-23 14:42:03 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:42:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:42:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:42:03 --> User Agent Class Initialized
INFO - 2018-10-23 14:42:03 --> Controller Class Initialized
INFO - 2018-10-23 14:42:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:42:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:42:03 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:42:03 --> Pixel_Model class loaded
INFO - 2018-10-23 14:42:03 --> Database Driver Class Initialized
INFO - 2018-10-23 14:42:04 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:42:04 --> Database Driver Class Initialized
INFO - 2018-10-23 14:42:04 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:42:04 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:42:04 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:42:04 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner.php
INFO - 2018-10-23 14:42:04 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:42:04 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:42:04 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:42:04 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:42:04 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/relation_ship_status.php
INFO - 2018-10-23 14:42:04 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:42:04 --> Final output sent to browser
DEBUG - 2018-10-23 14:42:04 --> Total execution time: 0.5219
INFO - 2018-10-23 14:42:10 --> Config Class Initialized
INFO - 2018-10-23 14:42:10 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:42:10 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:42:10 --> Utf8 Class Initialized
INFO - 2018-10-23 14:42:10 --> URI Class Initialized
INFO - 2018-10-23 14:42:10 --> Router Class Initialized
INFO - 2018-10-23 14:42:10 --> Output Class Initialized
INFO - 2018-10-23 14:42:10 --> Security Class Initialized
DEBUG - 2018-10-23 14:42:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:42:10 --> CSRF cookie sent
INFO - 2018-10-23 14:42:10 --> CSRF token verified
INFO - 2018-10-23 14:42:10 --> Input Class Initialized
INFO - 2018-10-23 14:42:10 --> Language Class Initialized
INFO - 2018-10-23 14:42:10 --> Loader Class Initialized
INFO - 2018-10-23 14:42:10 --> Helper loaded: url_helper
INFO - 2018-10-23 14:42:10 --> Helper loaded: form_helper
INFO - 2018-10-23 14:42:10 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:42:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:42:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:42:10 --> User Agent Class Initialized
INFO - 2018-10-23 14:42:10 --> Controller Class Initialized
INFO - 2018-10-23 14:42:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:42:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:42:10 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:42:10 --> Pixel_Model class loaded
INFO - 2018-10-23 14:42:10 --> Database Driver Class Initialized
INFO - 2018-10-23 14:42:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:42:10 --> Form Validation Class Initialized
INFO - 2018-10-23 14:42:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:42:10 --> Database Driver Class Initialized
INFO - 2018-10-23 14:42:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:42:10 --> Config Class Initialized
INFO - 2018-10-23 14:42:10 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:42:10 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:42:10 --> Utf8 Class Initialized
INFO - 2018-10-23 14:42:10 --> URI Class Initialized
INFO - 2018-10-23 14:42:10 --> Router Class Initialized
INFO - 2018-10-23 14:42:10 --> Output Class Initialized
INFO - 2018-10-23 14:42:10 --> Security Class Initialized
DEBUG - 2018-10-23 14:42:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:42:10 --> CSRF cookie sent
INFO - 2018-10-23 14:42:10 --> Input Class Initialized
INFO - 2018-10-23 14:42:10 --> Language Class Initialized
INFO - 2018-10-23 14:42:10 --> Loader Class Initialized
INFO - 2018-10-23 14:42:10 --> Helper loaded: url_helper
INFO - 2018-10-23 14:42:10 --> Helper loaded: form_helper
INFO - 2018-10-23 14:42:10 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:42:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:42:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:42:10 --> User Agent Class Initialized
INFO - 2018-10-23 14:42:10 --> Controller Class Initialized
INFO - 2018-10-23 14:42:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:42:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:42:10 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:42:10 --> Pixel_Model class loaded
INFO - 2018-10-23 14:42:11 --> Database Driver Class Initialized
INFO - 2018-10-23 14:42:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:42:11 --> Database Driver Class Initialized
INFO - 2018-10-23 14:42:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:42:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:42:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:42:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:42:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:42:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:42:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:42:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/income.php
INFO - 2018-10-23 14:42:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:42:11 --> Final output sent to browser
DEBUG - 2018-10-23 14:42:11 --> Total execution time: 0.4919
INFO - 2018-10-23 14:42:12 --> Config Class Initialized
INFO - 2018-10-23 14:42:12 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:42:12 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:42:12 --> Utf8 Class Initialized
INFO - 2018-10-23 14:42:12 --> URI Class Initialized
INFO - 2018-10-23 14:42:12 --> Router Class Initialized
INFO - 2018-10-23 14:42:12 --> Output Class Initialized
INFO - 2018-10-23 14:42:12 --> Security Class Initialized
DEBUG - 2018-10-23 14:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:42:12 --> CSRF cookie sent
INFO - 2018-10-23 14:42:12 --> CSRF token verified
INFO - 2018-10-23 14:42:12 --> Input Class Initialized
INFO - 2018-10-23 14:42:12 --> Language Class Initialized
INFO - 2018-10-23 14:42:12 --> Loader Class Initialized
INFO - 2018-10-23 14:42:12 --> Helper loaded: url_helper
INFO - 2018-10-23 14:42:12 --> Helper loaded: form_helper
INFO - 2018-10-23 14:42:12 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:42:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:42:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:42:12 --> User Agent Class Initialized
INFO - 2018-10-23 14:42:12 --> Controller Class Initialized
INFO - 2018-10-23 14:42:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:42:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:42:12 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:42:12 --> Pixel_Model class loaded
INFO - 2018-10-23 14:42:12 --> Database Driver Class Initialized
INFO - 2018-10-23 14:42:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:42:12 --> Form Validation Class Initialized
INFO - 2018-10-23 14:42:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:42:12 --> Database Driver Class Initialized
INFO - 2018-10-23 14:42:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:42:12 --> Config Class Initialized
INFO - 2018-10-23 14:42:12 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:42:12 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:42:12 --> Utf8 Class Initialized
INFO - 2018-10-23 14:42:12 --> URI Class Initialized
INFO - 2018-10-23 14:42:12 --> Router Class Initialized
INFO - 2018-10-23 14:42:12 --> Output Class Initialized
INFO - 2018-10-23 14:42:12 --> Security Class Initialized
DEBUG - 2018-10-23 14:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:42:12 --> CSRF cookie sent
INFO - 2018-10-23 14:42:12 --> Input Class Initialized
INFO - 2018-10-23 14:42:12 --> Language Class Initialized
INFO - 2018-10-23 14:42:12 --> Loader Class Initialized
INFO - 2018-10-23 14:42:12 --> Helper loaded: url_helper
INFO - 2018-10-23 14:42:12 --> Helper loaded: form_helper
INFO - 2018-10-23 14:42:12 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:42:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:42:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:42:13 --> User Agent Class Initialized
INFO - 2018-10-23 14:42:13 --> Controller Class Initialized
INFO - 2018-10-23 14:42:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:42:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:42:13 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:42:13 --> Pixel_Model class loaded
INFO - 2018-10-23 14:42:13 --> Database Driver Class Initialized
INFO - 2018-10-23 14:42:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:42:13 --> Database Driver Class Initialized
INFO - 2018-10-23 14:42:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:42:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:42:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:42:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:42:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:42:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:42:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:42:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/pension.php
INFO - 2018-10-23 14:42:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:42:13 --> Final output sent to browser
DEBUG - 2018-10-23 14:42:13 --> Total execution time: 0.4926
INFO - 2018-10-23 14:42:19 --> Config Class Initialized
INFO - 2018-10-23 14:42:19 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:42:19 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:42:19 --> Utf8 Class Initialized
INFO - 2018-10-23 14:42:19 --> URI Class Initialized
INFO - 2018-10-23 14:42:19 --> Router Class Initialized
INFO - 2018-10-23 14:42:19 --> Output Class Initialized
INFO - 2018-10-23 14:42:19 --> Security Class Initialized
DEBUG - 2018-10-23 14:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:42:19 --> CSRF cookie sent
INFO - 2018-10-23 14:42:19 --> CSRF token verified
INFO - 2018-10-23 14:42:19 --> Input Class Initialized
INFO - 2018-10-23 14:42:19 --> Language Class Initialized
INFO - 2018-10-23 14:42:19 --> Loader Class Initialized
INFO - 2018-10-23 14:42:19 --> Helper loaded: url_helper
INFO - 2018-10-23 14:42:19 --> Helper loaded: form_helper
INFO - 2018-10-23 14:42:19 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:42:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:42:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:42:19 --> User Agent Class Initialized
INFO - 2018-10-23 14:42:19 --> Controller Class Initialized
INFO - 2018-10-23 14:42:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:42:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:42:19 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:42:19 --> Pixel_Model class loaded
INFO - 2018-10-23 14:42:20 --> Database Driver Class Initialized
INFO - 2018-10-23 14:42:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:42:20 --> Form Validation Class Initialized
INFO - 2018-10-23 14:42:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:42:20 --> Database Driver Class Initialized
INFO - 2018-10-23 14:42:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:42:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:42:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:42:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:42:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:42:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:42:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_errors.php
INFO - 2018-10-23 14:42:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:42:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/pension.php
INFO - 2018-10-23 14:42:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:42:20 --> Final output sent to browser
DEBUG - 2018-10-23 14:42:20 --> Total execution time: 0.6035
INFO - 2018-10-23 14:42:22 --> Config Class Initialized
INFO - 2018-10-23 14:42:22 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:42:22 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:42:22 --> Utf8 Class Initialized
INFO - 2018-10-23 14:42:22 --> URI Class Initialized
INFO - 2018-10-23 14:42:22 --> Router Class Initialized
INFO - 2018-10-23 14:42:22 --> Output Class Initialized
INFO - 2018-10-23 14:42:22 --> Security Class Initialized
DEBUG - 2018-10-23 14:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:42:22 --> CSRF cookie sent
INFO - 2018-10-23 14:42:22 --> CSRF token verified
INFO - 2018-10-23 14:42:22 --> Input Class Initialized
INFO - 2018-10-23 14:42:22 --> Language Class Initialized
INFO - 2018-10-23 14:42:22 --> Loader Class Initialized
INFO - 2018-10-23 14:42:22 --> Helper loaded: url_helper
INFO - 2018-10-23 14:42:22 --> Helper loaded: form_helper
INFO - 2018-10-23 14:42:22 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:42:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:42:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:42:22 --> User Agent Class Initialized
INFO - 2018-10-23 14:42:22 --> Controller Class Initialized
INFO - 2018-10-23 14:42:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:42:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:42:22 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:42:22 --> Pixel_Model class loaded
INFO - 2018-10-23 14:42:22 --> Database Driver Class Initialized
INFO - 2018-10-23 14:42:22 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:42:22 --> Form Validation Class Initialized
INFO - 2018-10-23 14:42:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:42:22 --> Database Driver Class Initialized
INFO - 2018-10-23 14:42:22 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:42:22 --> Config Class Initialized
INFO - 2018-10-23 14:42:22 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:42:22 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:42:22 --> Utf8 Class Initialized
INFO - 2018-10-23 14:42:22 --> URI Class Initialized
INFO - 2018-10-23 14:42:22 --> Router Class Initialized
INFO - 2018-10-23 14:42:22 --> Output Class Initialized
INFO - 2018-10-23 14:42:22 --> Security Class Initialized
DEBUG - 2018-10-23 14:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:42:22 --> CSRF cookie sent
INFO - 2018-10-23 14:42:22 --> Input Class Initialized
INFO - 2018-10-23 14:42:22 --> Language Class Initialized
INFO - 2018-10-23 14:42:22 --> Loader Class Initialized
INFO - 2018-10-23 14:42:22 --> Helper loaded: url_helper
INFO - 2018-10-23 14:42:22 --> Helper loaded: form_helper
INFO - 2018-10-23 14:42:22 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:42:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:42:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:42:22 --> User Agent Class Initialized
INFO - 2018-10-23 14:42:22 --> Controller Class Initialized
INFO - 2018-10-23 14:42:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:42:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:42:22 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:42:22 --> Pixel_Model class loaded
INFO - 2018-10-23 14:42:22 --> Database Driver Class Initialized
INFO - 2018-10-23 14:42:22 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:42:22 --> Database Driver Class Initialized
INFO - 2018-10-23 14:42:22 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:42:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:42:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:42:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:42:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:42:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:42:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:42:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/home_title.php
INFO - 2018-10-23 14:42:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:42:23 --> Final output sent to browser
DEBUG - 2018-10-23 14:42:23 --> Total execution time: 0.5041
INFO - 2018-10-23 14:42:28 --> Config Class Initialized
INFO - 2018-10-23 14:42:28 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:42:28 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:42:29 --> Utf8 Class Initialized
INFO - 2018-10-23 14:42:29 --> URI Class Initialized
INFO - 2018-10-23 14:42:29 --> Router Class Initialized
INFO - 2018-10-23 14:42:29 --> Output Class Initialized
INFO - 2018-10-23 14:42:29 --> Security Class Initialized
DEBUG - 2018-10-23 14:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:42:29 --> CSRF cookie sent
INFO - 2018-10-23 14:42:29 --> Input Class Initialized
INFO - 2018-10-23 14:42:29 --> Language Class Initialized
INFO - 2018-10-23 14:42:29 --> Loader Class Initialized
INFO - 2018-10-23 14:42:29 --> Helper loaded: url_helper
INFO - 2018-10-23 14:42:29 --> Helper loaded: form_helper
INFO - 2018-10-23 14:42:29 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:42:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:42:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:42:29 --> User Agent Class Initialized
INFO - 2018-10-23 14:42:29 --> Controller Class Initialized
INFO - 2018-10-23 14:42:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:42:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:42:29 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:42:29 --> Pixel_Model class loaded
INFO - 2018-10-23 14:42:29 --> Database Driver Class Initialized
INFO - 2018-10-23 14:42:29 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:42:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:42:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:42:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:42:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:42:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:42:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:42:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-23 14:42:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:42:29 --> Final output sent to browser
DEBUG - 2018-10-23 14:42:29 --> Total execution time: 0.4856
INFO - 2018-10-23 14:42:41 --> Config Class Initialized
INFO - 2018-10-23 14:42:41 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:42:41 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:42:41 --> Utf8 Class Initialized
INFO - 2018-10-23 14:42:41 --> URI Class Initialized
INFO - 2018-10-23 14:42:41 --> Router Class Initialized
INFO - 2018-10-23 14:42:41 --> Output Class Initialized
INFO - 2018-10-23 14:42:41 --> Security Class Initialized
DEBUG - 2018-10-23 14:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:42:42 --> CSRF cookie sent
INFO - 2018-10-23 14:42:42 --> Input Class Initialized
INFO - 2018-10-23 14:42:42 --> Language Class Initialized
INFO - 2018-10-23 14:42:42 --> Loader Class Initialized
INFO - 2018-10-23 14:42:42 --> Helper loaded: url_helper
INFO - 2018-10-23 14:42:42 --> Helper loaded: form_helper
INFO - 2018-10-23 14:42:42 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:42:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:42:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:42:42 --> User Agent Class Initialized
INFO - 2018-10-23 14:42:42 --> Controller Class Initialized
INFO - 2018-10-23 14:42:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:42:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:42:42 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:42:42 --> Pixel_Model class loaded
INFO - 2018-10-23 14:42:42 --> Database Driver Class Initialized
INFO - 2018-10-23 14:42:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:42:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:42:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:42:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:42:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:42:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:42:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:42:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-23 14:42:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:42:42 --> Final output sent to browser
DEBUG - 2018-10-23 14:42:42 --> Total execution time: 0.4944
INFO - 2018-10-23 14:42:44 --> Config Class Initialized
INFO - 2018-10-23 14:42:44 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:42:44 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:42:44 --> Utf8 Class Initialized
INFO - 2018-10-23 14:42:44 --> URI Class Initialized
INFO - 2018-10-23 14:42:44 --> Router Class Initialized
INFO - 2018-10-23 14:42:44 --> Output Class Initialized
INFO - 2018-10-23 14:42:44 --> Security Class Initialized
DEBUG - 2018-10-23 14:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:42:44 --> CSRF cookie sent
INFO - 2018-10-23 14:42:44 --> Input Class Initialized
INFO - 2018-10-23 14:42:44 --> Language Class Initialized
INFO - 2018-10-23 14:42:44 --> Loader Class Initialized
INFO - 2018-10-23 14:42:44 --> Helper loaded: url_helper
INFO - 2018-10-23 14:42:44 --> Helper loaded: form_helper
INFO - 2018-10-23 14:42:44 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:42:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:42:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:42:44 --> User Agent Class Initialized
INFO - 2018-10-23 14:42:44 --> Controller Class Initialized
INFO - 2018-10-23 14:42:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:42:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:42:44 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:42:44 --> Pixel_Model class loaded
INFO - 2018-10-23 14:42:44 --> Database Driver Class Initialized
INFO - 2018-10-23 14:42:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:42:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:42:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:42:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:42:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:42:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:42:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:42:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-23 14:42:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:42:44 --> Final output sent to browser
DEBUG - 2018-10-23 14:42:44 --> Total execution time: 0.5153
INFO - 2018-10-23 14:42:47 --> Config Class Initialized
INFO - 2018-10-23 14:42:47 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:42:47 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:42:47 --> Utf8 Class Initialized
INFO - 2018-10-23 14:42:47 --> URI Class Initialized
INFO - 2018-10-23 14:42:47 --> Router Class Initialized
INFO - 2018-10-23 14:42:47 --> Output Class Initialized
INFO - 2018-10-23 14:42:47 --> Security Class Initialized
DEBUG - 2018-10-23 14:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:42:47 --> CSRF cookie sent
INFO - 2018-10-23 14:42:47 --> CSRF token verified
INFO - 2018-10-23 14:42:47 --> Input Class Initialized
INFO - 2018-10-23 14:42:47 --> Language Class Initialized
INFO - 2018-10-23 14:42:47 --> Loader Class Initialized
INFO - 2018-10-23 14:42:47 --> Helper loaded: url_helper
INFO - 2018-10-23 14:42:47 --> Helper loaded: form_helper
INFO - 2018-10-23 14:42:48 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:42:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:42:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:42:48 --> User Agent Class Initialized
INFO - 2018-10-23 14:42:48 --> Controller Class Initialized
INFO - 2018-10-23 14:42:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:42:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:42:48 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:42:48 --> Pixel_Model class loaded
INFO - 2018-10-23 14:42:48 --> Database Driver Class Initialized
INFO - 2018-10-23 14:42:48 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:42:48 --> Form Validation Class Initialized
INFO - 2018-10-23 14:42:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:42:48 --> Database Driver Class Initialized
INFO - 2018-10-23 14:42:48 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:42:48 --> Config Class Initialized
INFO - 2018-10-23 14:42:48 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:42:48 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:42:48 --> Utf8 Class Initialized
INFO - 2018-10-23 14:42:48 --> URI Class Initialized
INFO - 2018-10-23 14:42:48 --> Router Class Initialized
INFO - 2018-10-23 14:42:48 --> Output Class Initialized
INFO - 2018-10-23 14:42:48 --> Security Class Initialized
DEBUG - 2018-10-23 14:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:42:48 --> CSRF cookie sent
INFO - 2018-10-23 14:42:48 --> Input Class Initialized
INFO - 2018-10-23 14:42:48 --> Language Class Initialized
INFO - 2018-10-23 14:42:48 --> Loader Class Initialized
INFO - 2018-10-23 14:42:48 --> Helper loaded: url_helper
INFO - 2018-10-23 14:42:48 --> Helper loaded: form_helper
INFO - 2018-10-23 14:42:48 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:42:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:42:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:42:48 --> User Agent Class Initialized
INFO - 2018-10-23 14:42:48 --> Controller Class Initialized
INFO - 2018-10-23 14:42:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:42:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:42:48 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:42:48 --> Pixel_Model class loaded
INFO - 2018-10-23 14:42:48 --> Database Driver Class Initialized
INFO - 2018-10-23 14:42:48 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:42:48 --> Database Driver Class Initialized
INFO - 2018-10-23 14:42:48 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:42:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:42:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:42:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:42:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:42:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:42:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:42:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-23 14:42:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:42:48 --> Final output sent to browser
DEBUG - 2018-10-23 14:42:48 --> Total execution time: 0.5328
INFO - 2018-10-23 14:42:52 --> Config Class Initialized
INFO - 2018-10-23 14:42:52 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:42:52 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:42:52 --> Utf8 Class Initialized
INFO - 2018-10-23 14:42:52 --> URI Class Initialized
INFO - 2018-10-23 14:42:52 --> Router Class Initialized
INFO - 2018-10-23 14:42:52 --> Output Class Initialized
INFO - 2018-10-23 14:42:52 --> Security Class Initialized
DEBUG - 2018-10-23 14:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:42:52 --> CSRF cookie sent
INFO - 2018-10-23 14:42:52 --> CSRF token verified
INFO - 2018-10-23 14:42:52 --> Input Class Initialized
INFO - 2018-10-23 14:42:52 --> Language Class Initialized
INFO - 2018-10-23 14:42:52 --> Loader Class Initialized
INFO - 2018-10-23 14:42:52 --> Helper loaded: url_helper
INFO - 2018-10-23 14:42:52 --> Helper loaded: form_helper
INFO - 2018-10-23 14:42:52 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:42:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:42:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:42:52 --> User Agent Class Initialized
INFO - 2018-10-23 14:42:52 --> Controller Class Initialized
INFO - 2018-10-23 14:42:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:42:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:42:52 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:42:52 --> Pixel_Model class loaded
INFO - 2018-10-23 14:42:52 --> Database Driver Class Initialized
INFO - 2018-10-23 14:42:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:42:52 --> Form Validation Class Initialized
INFO - 2018-10-23 14:42:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:42:53 --> Database Driver Class Initialized
INFO - 2018-10-23 14:42:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:42:53 --> Config Class Initialized
INFO - 2018-10-23 14:42:53 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:42:53 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:42:53 --> Utf8 Class Initialized
INFO - 2018-10-23 14:42:53 --> URI Class Initialized
INFO - 2018-10-23 14:42:53 --> Router Class Initialized
INFO - 2018-10-23 14:42:53 --> Output Class Initialized
INFO - 2018-10-23 14:42:53 --> Security Class Initialized
DEBUG - 2018-10-23 14:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:42:53 --> CSRF cookie sent
INFO - 2018-10-23 14:42:53 --> Input Class Initialized
INFO - 2018-10-23 14:42:53 --> Language Class Initialized
INFO - 2018-10-23 14:42:53 --> Loader Class Initialized
INFO - 2018-10-23 14:42:53 --> Helper loaded: url_helper
INFO - 2018-10-23 14:42:53 --> Helper loaded: form_helper
INFO - 2018-10-23 14:42:53 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:42:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:42:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:42:53 --> User Agent Class Initialized
INFO - 2018-10-23 14:42:53 --> Controller Class Initialized
INFO - 2018-10-23 14:42:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:42:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:42:53 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:42:53 --> Pixel_Model class loaded
INFO - 2018-10-23 14:42:53 --> Database Driver Class Initialized
INFO - 2018-10-23 14:42:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:42:53 --> Database Driver Class Initialized
INFO - 2018-10-23 14:42:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:42:53 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:42:53 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:42:53 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:42:53 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:42:53 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:42:53 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:42:53 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/your_job.php
INFO - 2018-10-23 14:42:53 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:42:53 --> Final output sent to browser
DEBUG - 2018-10-23 14:42:53 --> Total execution time: 0.5267
INFO - 2018-10-23 14:42:54 --> Config Class Initialized
INFO - 2018-10-23 14:42:54 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:42:54 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:42:54 --> Utf8 Class Initialized
INFO - 2018-10-23 14:42:54 --> URI Class Initialized
INFO - 2018-10-23 14:42:54 --> Router Class Initialized
INFO - 2018-10-23 14:42:54 --> Output Class Initialized
INFO - 2018-10-23 14:42:54 --> Security Class Initialized
DEBUG - 2018-10-23 14:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:42:54 --> CSRF cookie sent
INFO - 2018-10-23 14:42:55 --> CSRF token verified
INFO - 2018-10-23 14:42:55 --> Input Class Initialized
INFO - 2018-10-23 14:42:55 --> Language Class Initialized
INFO - 2018-10-23 14:42:55 --> Loader Class Initialized
INFO - 2018-10-23 14:42:55 --> Helper loaded: url_helper
INFO - 2018-10-23 14:42:55 --> Helper loaded: form_helper
INFO - 2018-10-23 14:42:55 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:42:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:42:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:42:55 --> User Agent Class Initialized
INFO - 2018-10-23 14:42:55 --> Controller Class Initialized
INFO - 2018-10-23 14:42:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:42:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:42:55 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:42:55 --> Pixel_Model class loaded
INFO - 2018-10-23 14:42:55 --> Database Driver Class Initialized
INFO - 2018-10-23 14:42:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:42:55 --> Form Validation Class Initialized
INFO - 2018-10-23 14:42:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:42:55 --> Database Driver Class Initialized
INFO - 2018-10-23 14:42:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:42:55 --> Config Class Initialized
INFO - 2018-10-23 14:42:55 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:42:55 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:42:55 --> Utf8 Class Initialized
INFO - 2018-10-23 14:42:55 --> URI Class Initialized
INFO - 2018-10-23 14:42:55 --> Router Class Initialized
INFO - 2018-10-23 14:42:55 --> Output Class Initialized
INFO - 2018-10-23 14:42:55 --> Security Class Initialized
DEBUG - 2018-10-23 14:42:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:42:55 --> CSRF cookie sent
INFO - 2018-10-23 14:42:55 --> Input Class Initialized
INFO - 2018-10-23 14:42:55 --> Language Class Initialized
INFO - 2018-10-23 14:42:55 --> Loader Class Initialized
INFO - 2018-10-23 14:42:55 --> Helper loaded: url_helper
INFO - 2018-10-23 14:42:55 --> Helper loaded: form_helper
INFO - 2018-10-23 14:42:55 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:42:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:42:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:42:55 --> User Agent Class Initialized
INFO - 2018-10-23 14:42:55 --> Controller Class Initialized
INFO - 2018-10-23 14:42:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:42:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:42:55 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:42:55 --> Pixel_Model class loaded
INFO - 2018-10-23 14:42:55 --> Database Driver Class Initialized
INFO - 2018-10-23 14:42:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:42:55 --> Database Driver Class Initialized
INFO - 2018-10-23 14:42:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:42:55 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:42:55 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:42:55 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner.php
INFO - 2018-10-23 14:42:55 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:42:55 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:42:55 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:42:55 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:42:55 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/relation_ship_status.php
INFO - 2018-10-23 14:42:55 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:42:55 --> Final output sent to browser
DEBUG - 2018-10-23 14:42:55 --> Total execution time: 0.5469
INFO - 2018-10-23 14:43:07 --> Config Class Initialized
INFO - 2018-10-23 14:43:07 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:43:07 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:43:07 --> Utf8 Class Initialized
INFO - 2018-10-23 14:43:07 --> URI Class Initialized
INFO - 2018-10-23 14:43:07 --> Router Class Initialized
INFO - 2018-10-23 14:43:07 --> Output Class Initialized
INFO - 2018-10-23 14:43:07 --> Security Class Initialized
DEBUG - 2018-10-23 14:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:43:07 --> CSRF cookie sent
INFO - 2018-10-23 14:43:07 --> CSRF token verified
INFO - 2018-10-23 14:43:07 --> Input Class Initialized
INFO - 2018-10-23 14:43:07 --> Language Class Initialized
INFO - 2018-10-23 14:43:07 --> Loader Class Initialized
INFO - 2018-10-23 14:43:07 --> Helper loaded: url_helper
INFO - 2018-10-23 14:43:07 --> Helper loaded: form_helper
INFO - 2018-10-23 14:43:07 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:43:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:43:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:43:07 --> User Agent Class Initialized
INFO - 2018-10-23 14:43:07 --> Controller Class Initialized
INFO - 2018-10-23 14:43:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:43:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:43:07 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:43:07 --> Pixel_Model class loaded
INFO - 2018-10-23 14:43:07 --> Database Driver Class Initialized
INFO - 2018-10-23 14:43:07 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:43:07 --> Form Validation Class Initialized
INFO - 2018-10-23 14:43:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:43:07 --> Database Driver Class Initialized
INFO - 2018-10-23 14:43:07 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:43:07 --> Config Class Initialized
INFO - 2018-10-23 14:43:07 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:43:07 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:43:07 --> Utf8 Class Initialized
INFO - 2018-10-23 14:43:07 --> URI Class Initialized
INFO - 2018-10-23 14:43:07 --> Router Class Initialized
INFO - 2018-10-23 14:43:07 --> Output Class Initialized
INFO - 2018-10-23 14:43:07 --> Security Class Initialized
DEBUG - 2018-10-23 14:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:43:07 --> CSRF cookie sent
INFO - 2018-10-23 14:43:07 --> Input Class Initialized
INFO - 2018-10-23 14:43:07 --> Language Class Initialized
INFO - 2018-10-23 14:43:07 --> Loader Class Initialized
INFO - 2018-10-23 14:43:08 --> Helper loaded: url_helper
INFO - 2018-10-23 14:43:08 --> Helper loaded: form_helper
INFO - 2018-10-23 14:43:08 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:43:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:43:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:43:08 --> User Agent Class Initialized
INFO - 2018-10-23 14:43:08 --> Controller Class Initialized
INFO - 2018-10-23 14:43:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:43:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:43:08 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:43:08 --> Pixel_Model class loaded
INFO - 2018-10-23 14:43:08 --> Database Driver Class Initialized
INFO - 2018-10-23 14:43:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:43:08 --> Database Driver Class Initialized
INFO - 2018-10-23 14:43:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:43:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:43:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:43:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:43:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:43:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:43:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:43:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/income.php
INFO - 2018-10-23 14:43:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:43:08 --> Final output sent to browser
DEBUG - 2018-10-23 14:43:08 --> Total execution time: 0.5502
INFO - 2018-10-23 14:43:14 --> Config Class Initialized
INFO - 2018-10-23 14:43:14 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:43:14 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:43:14 --> Utf8 Class Initialized
INFO - 2018-10-23 14:43:14 --> URI Class Initialized
INFO - 2018-10-23 14:43:14 --> Router Class Initialized
INFO - 2018-10-23 14:43:14 --> Output Class Initialized
INFO - 2018-10-23 14:43:14 --> Security Class Initialized
DEBUG - 2018-10-23 14:43:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:43:14 --> CSRF cookie sent
INFO - 2018-10-23 14:43:14 --> CSRF token verified
INFO - 2018-10-23 14:43:14 --> Input Class Initialized
INFO - 2018-10-23 14:43:14 --> Language Class Initialized
INFO - 2018-10-23 14:43:14 --> Loader Class Initialized
INFO - 2018-10-23 14:43:14 --> Helper loaded: url_helper
INFO - 2018-10-23 14:43:14 --> Helper loaded: form_helper
INFO - 2018-10-23 14:43:14 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:43:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:43:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:43:14 --> User Agent Class Initialized
INFO - 2018-10-23 14:43:14 --> Controller Class Initialized
INFO - 2018-10-23 14:43:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:43:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:43:14 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:43:14 --> Pixel_Model class loaded
INFO - 2018-10-23 14:43:14 --> Database Driver Class Initialized
INFO - 2018-10-23 14:43:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:43:14 --> Form Validation Class Initialized
INFO - 2018-10-23 14:43:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:43:14 --> Database Driver Class Initialized
INFO - 2018-10-23 14:43:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:43:14 --> Config Class Initialized
INFO - 2018-10-23 14:43:14 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:43:14 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:43:14 --> Utf8 Class Initialized
INFO - 2018-10-23 14:43:14 --> URI Class Initialized
INFO - 2018-10-23 14:43:14 --> Router Class Initialized
INFO - 2018-10-23 14:43:14 --> Output Class Initialized
INFO - 2018-10-23 14:43:14 --> Security Class Initialized
DEBUG - 2018-10-23 14:43:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:43:14 --> CSRF cookie sent
INFO - 2018-10-23 14:43:14 --> Input Class Initialized
INFO - 2018-10-23 14:43:14 --> Language Class Initialized
INFO - 2018-10-23 14:43:14 --> Loader Class Initialized
INFO - 2018-10-23 14:43:14 --> Helper loaded: url_helper
INFO - 2018-10-23 14:43:14 --> Helper loaded: form_helper
INFO - 2018-10-23 14:43:14 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:43:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:43:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:43:14 --> User Agent Class Initialized
INFO - 2018-10-23 14:43:14 --> Controller Class Initialized
INFO - 2018-10-23 14:43:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:43:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:43:14 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:43:14 --> Pixel_Model class loaded
INFO - 2018-10-23 14:43:14 --> Database Driver Class Initialized
INFO - 2018-10-23 14:43:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:43:14 --> Database Driver Class Initialized
INFO - 2018-10-23 14:43:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:43:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:43:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:43:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:43:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:43:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:43:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:43:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/pension.php
INFO - 2018-10-23 14:43:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:43:15 --> Final output sent to browser
DEBUG - 2018-10-23 14:43:15 --> Total execution time: 0.5366
INFO - 2018-10-23 14:43:16 --> Config Class Initialized
INFO - 2018-10-23 14:43:16 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:43:16 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:43:16 --> Utf8 Class Initialized
INFO - 2018-10-23 14:43:16 --> URI Class Initialized
INFO - 2018-10-23 14:43:16 --> Router Class Initialized
INFO - 2018-10-23 14:43:16 --> Output Class Initialized
INFO - 2018-10-23 14:43:16 --> Security Class Initialized
DEBUG - 2018-10-23 14:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:43:16 --> CSRF cookie sent
INFO - 2018-10-23 14:43:16 --> CSRF token verified
INFO - 2018-10-23 14:43:16 --> Input Class Initialized
INFO - 2018-10-23 14:43:16 --> Language Class Initialized
INFO - 2018-10-23 14:43:16 --> Loader Class Initialized
INFO - 2018-10-23 14:43:16 --> Helper loaded: url_helper
INFO - 2018-10-23 14:43:16 --> Helper loaded: form_helper
INFO - 2018-10-23 14:43:16 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:43:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:43:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:43:16 --> User Agent Class Initialized
INFO - 2018-10-23 14:43:16 --> Controller Class Initialized
INFO - 2018-10-23 14:43:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:43:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:43:16 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:43:16 --> Pixel_Model class loaded
INFO - 2018-10-23 14:43:16 --> Database Driver Class Initialized
INFO - 2018-10-23 14:43:16 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:43:16 --> Form Validation Class Initialized
INFO - 2018-10-23 14:43:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:43:16 --> Database Driver Class Initialized
INFO - 2018-10-23 14:43:16 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:43:16 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:43:16 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:43:16 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:43:16 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:43:16 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:43:16 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_errors.php
INFO - 2018-10-23 14:43:16 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:43:16 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/pension.php
INFO - 2018-10-23 14:43:16 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:43:16 --> Final output sent to browser
DEBUG - 2018-10-23 14:43:16 --> Total execution time: 0.6184
INFO - 2018-10-23 14:43:19 --> Config Class Initialized
INFO - 2018-10-23 14:43:19 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:43:19 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:43:19 --> Utf8 Class Initialized
INFO - 2018-10-23 14:43:19 --> URI Class Initialized
INFO - 2018-10-23 14:43:19 --> Router Class Initialized
INFO - 2018-10-23 14:43:19 --> Output Class Initialized
INFO - 2018-10-23 14:43:19 --> Security Class Initialized
DEBUG - 2018-10-23 14:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:43:19 --> CSRF cookie sent
INFO - 2018-10-23 14:43:19 --> CSRF token verified
INFO - 2018-10-23 14:43:19 --> Input Class Initialized
INFO - 2018-10-23 14:43:19 --> Language Class Initialized
INFO - 2018-10-23 14:43:19 --> Loader Class Initialized
INFO - 2018-10-23 14:43:19 --> Helper loaded: url_helper
INFO - 2018-10-23 14:43:19 --> Helper loaded: form_helper
INFO - 2018-10-23 14:43:19 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:43:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:43:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:43:19 --> User Agent Class Initialized
INFO - 2018-10-23 14:43:19 --> Controller Class Initialized
INFO - 2018-10-23 14:43:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:43:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:43:19 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:43:19 --> Pixel_Model class loaded
INFO - 2018-10-23 14:43:19 --> Database Driver Class Initialized
INFO - 2018-10-23 14:43:19 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:43:19 --> Form Validation Class Initialized
INFO - 2018-10-23 14:43:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:43:20 --> Database Driver Class Initialized
INFO - 2018-10-23 14:43:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:43:20 --> Config Class Initialized
INFO - 2018-10-23 14:43:20 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:43:20 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:43:20 --> Utf8 Class Initialized
INFO - 2018-10-23 14:43:20 --> URI Class Initialized
INFO - 2018-10-23 14:43:20 --> Router Class Initialized
INFO - 2018-10-23 14:43:20 --> Output Class Initialized
INFO - 2018-10-23 14:43:20 --> Security Class Initialized
DEBUG - 2018-10-23 14:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:43:20 --> CSRF cookie sent
INFO - 2018-10-23 14:43:20 --> Input Class Initialized
INFO - 2018-10-23 14:43:20 --> Language Class Initialized
INFO - 2018-10-23 14:43:20 --> Loader Class Initialized
INFO - 2018-10-23 14:43:20 --> Helper loaded: url_helper
INFO - 2018-10-23 14:43:20 --> Helper loaded: form_helper
INFO - 2018-10-23 14:43:20 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:43:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:43:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:43:20 --> User Agent Class Initialized
INFO - 2018-10-23 14:43:20 --> Controller Class Initialized
INFO - 2018-10-23 14:43:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:43:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:43:20 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:43:20 --> Pixel_Model class loaded
INFO - 2018-10-23 14:43:20 --> Database Driver Class Initialized
INFO - 2018-10-23 14:43:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:43:20 --> Database Driver Class Initialized
INFO - 2018-10-23 14:43:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:43:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:43:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:43:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:43:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:43:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:43:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:43:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/home_title.php
INFO - 2018-10-23 14:43:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:43:20 --> Final output sent to browser
DEBUG - 2018-10-23 14:43:20 --> Total execution time: 0.5524
INFO - 2018-10-23 14:43:31 --> Config Class Initialized
INFO - 2018-10-23 14:43:31 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:43:31 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:43:31 --> Utf8 Class Initialized
INFO - 2018-10-23 14:43:31 --> URI Class Initialized
INFO - 2018-10-23 14:43:31 --> Router Class Initialized
INFO - 2018-10-23 14:43:31 --> Output Class Initialized
INFO - 2018-10-23 14:43:31 --> Security Class Initialized
DEBUG - 2018-10-23 14:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:43:31 --> CSRF cookie sent
INFO - 2018-10-23 14:43:31 --> Input Class Initialized
INFO - 2018-10-23 14:43:31 --> Language Class Initialized
INFO - 2018-10-23 14:43:31 --> Loader Class Initialized
INFO - 2018-10-23 14:43:31 --> Helper loaded: url_helper
INFO - 2018-10-23 14:43:31 --> Helper loaded: form_helper
INFO - 2018-10-23 14:43:31 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:43:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:43:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:43:31 --> User Agent Class Initialized
INFO - 2018-10-23 14:43:31 --> Controller Class Initialized
INFO - 2018-10-23 14:43:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:43:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:43:31 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:43:31 --> Pixel_Model class loaded
INFO - 2018-10-23 14:43:31 --> Database Driver Class Initialized
INFO - 2018-10-23 14:43:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:43:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:43:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:43:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:43:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:43:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:43:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:43:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-23 14:43:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:43:31 --> Final output sent to browser
DEBUG - 2018-10-23 14:43:31 --> Total execution time: 0.5154
INFO - 2018-10-23 14:43:33 --> Config Class Initialized
INFO - 2018-10-23 14:43:33 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:43:33 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:43:33 --> Utf8 Class Initialized
INFO - 2018-10-23 14:43:33 --> URI Class Initialized
INFO - 2018-10-23 14:43:33 --> Router Class Initialized
INFO - 2018-10-23 14:43:33 --> Output Class Initialized
INFO - 2018-10-23 14:43:33 --> Security Class Initialized
DEBUG - 2018-10-23 14:43:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:43:33 --> CSRF cookie sent
INFO - 2018-10-23 14:43:33 --> CSRF token verified
INFO - 2018-10-23 14:43:33 --> Input Class Initialized
INFO - 2018-10-23 14:43:33 --> Language Class Initialized
INFO - 2018-10-23 14:43:33 --> Loader Class Initialized
INFO - 2018-10-23 14:43:33 --> Helper loaded: url_helper
INFO - 2018-10-23 14:43:33 --> Helper loaded: form_helper
INFO - 2018-10-23 14:43:33 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:43:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:43:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:43:34 --> User Agent Class Initialized
INFO - 2018-10-23 14:43:34 --> Controller Class Initialized
INFO - 2018-10-23 14:43:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:43:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:43:34 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:43:34 --> Pixel_Model class loaded
INFO - 2018-10-23 14:43:34 --> Database Driver Class Initialized
INFO - 2018-10-23 14:43:34 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:43:34 --> Form Validation Class Initialized
INFO - 2018-10-23 14:43:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:43:34 --> Database Driver Class Initialized
INFO - 2018-10-23 14:43:34 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:43:34 --> Config Class Initialized
INFO - 2018-10-23 14:43:34 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:43:34 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:43:34 --> Utf8 Class Initialized
INFO - 2018-10-23 14:43:34 --> URI Class Initialized
INFO - 2018-10-23 14:43:34 --> Router Class Initialized
INFO - 2018-10-23 14:43:34 --> Output Class Initialized
INFO - 2018-10-23 14:43:34 --> Security Class Initialized
DEBUG - 2018-10-23 14:43:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:43:34 --> CSRF cookie sent
INFO - 2018-10-23 14:43:34 --> Input Class Initialized
INFO - 2018-10-23 14:43:34 --> Language Class Initialized
INFO - 2018-10-23 14:43:34 --> Loader Class Initialized
INFO - 2018-10-23 14:43:34 --> Helper loaded: url_helper
INFO - 2018-10-23 14:43:34 --> Helper loaded: form_helper
INFO - 2018-10-23 14:43:34 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:43:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:43:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:43:34 --> User Agent Class Initialized
INFO - 2018-10-23 14:43:34 --> Controller Class Initialized
INFO - 2018-10-23 14:43:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:43:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:43:34 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:43:34 --> Pixel_Model class loaded
INFO - 2018-10-23 14:43:34 --> Database Driver Class Initialized
INFO - 2018-10-23 14:43:34 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:43:34 --> Database Driver Class Initialized
INFO - 2018-10-23 14:43:34 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:43:34 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:43:34 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:43:34 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:43:34 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:43:34 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:43:34 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:43:34 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-23 14:43:34 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:43:34 --> Final output sent to browser
DEBUG - 2018-10-23 14:43:34 --> Total execution time: 0.5533
INFO - 2018-10-23 14:43:37 --> Config Class Initialized
INFO - 2018-10-23 14:43:37 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:43:37 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:43:37 --> Utf8 Class Initialized
INFO - 2018-10-23 14:43:37 --> URI Class Initialized
INFO - 2018-10-23 14:43:37 --> Router Class Initialized
INFO - 2018-10-23 14:43:37 --> Output Class Initialized
INFO - 2018-10-23 14:43:38 --> Security Class Initialized
DEBUG - 2018-10-23 14:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:43:38 --> CSRF cookie sent
INFO - 2018-10-23 14:43:38 --> CSRF token verified
INFO - 2018-10-23 14:43:38 --> Input Class Initialized
INFO - 2018-10-23 14:43:38 --> Language Class Initialized
INFO - 2018-10-23 14:43:38 --> Loader Class Initialized
INFO - 2018-10-23 14:43:38 --> Helper loaded: url_helper
INFO - 2018-10-23 14:43:38 --> Helper loaded: form_helper
INFO - 2018-10-23 14:43:38 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:43:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:43:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:43:38 --> User Agent Class Initialized
INFO - 2018-10-23 14:43:38 --> Controller Class Initialized
INFO - 2018-10-23 14:43:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:43:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:43:38 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:43:38 --> Pixel_Model class loaded
INFO - 2018-10-23 14:43:38 --> Database Driver Class Initialized
INFO - 2018-10-23 14:43:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:43:38 --> Form Validation Class Initialized
INFO - 2018-10-23 14:43:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:43:38 --> Database Driver Class Initialized
INFO - 2018-10-23 14:43:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:43:38 --> Config Class Initialized
INFO - 2018-10-23 14:43:38 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:43:38 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:43:38 --> Utf8 Class Initialized
INFO - 2018-10-23 14:43:38 --> URI Class Initialized
INFO - 2018-10-23 14:43:38 --> Router Class Initialized
INFO - 2018-10-23 14:43:38 --> Output Class Initialized
INFO - 2018-10-23 14:43:38 --> Security Class Initialized
DEBUG - 2018-10-23 14:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:43:38 --> CSRF cookie sent
INFO - 2018-10-23 14:43:38 --> Input Class Initialized
INFO - 2018-10-23 14:43:38 --> Language Class Initialized
INFO - 2018-10-23 14:43:38 --> Loader Class Initialized
INFO - 2018-10-23 14:43:38 --> Helper loaded: url_helper
INFO - 2018-10-23 14:43:38 --> Helper loaded: form_helper
INFO - 2018-10-23 14:43:38 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:43:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:43:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:43:38 --> User Agent Class Initialized
INFO - 2018-10-23 14:43:38 --> Controller Class Initialized
INFO - 2018-10-23 14:43:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:43:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:43:38 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:43:38 --> Pixel_Model class loaded
INFO - 2018-10-23 14:43:38 --> Database Driver Class Initialized
INFO - 2018-10-23 14:43:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:43:38 --> Database Driver Class Initialized
INFO - 2018-10-23 14:43:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:43:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:43:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:43:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:43:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:43:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:43:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:43:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/your_job.php
INFO - 2018-10-23 14:43:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:43:38 --> Final output sent to browser
DEBUG - 2018-10-23 14:43:38 --> Total execution time: 0.5372
INFO - 2018-10-23 14:43:39 --> Config Class Initialized
INFO - 2018-10-23 14:43:39 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:43:39 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:43:39 --> Utf8 Class Initialized
INFO - 2018-10-23 14:43:39 --> URI Class Initialized
INFO - 2018-10-23 14:43:39 --> Router Class Initialized
INFO - 2018-10-23 14:43:39 --> Output Class Initialized
INFO - 2018-10-23 14:43:39 --> Security Class Initialized
DEBUG - 2018-10-23 14:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:43:40 --> CSRF cookie sent
INFO - 2018-10-23 14:43:40 --> CSRF token verified
INFO - 2018-10-23 14:43:40 --> Input Class Initialized
INFO - 2018-10-23 14:43:40 --> Language Class Initialized
INFO - 2018-10-23 14:43:40 --> Loader Class Initialized
INFO - 2018-10-23 14:43:40 --> Helper loaded: url_helper
INFO - 2018-10-23 14:43:40 --> Helper loaded: form_helper
INFO - 2018-10-23 14:43:40 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:43:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:43:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:43:40 --> User Agent Class Initialized
INFO - 2018-10-23 14:43:40 --> Controller Class Initialized
INFO - 2018-10-23 14:43:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:43:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:43:40 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:43:40 --> Pixel_Model class loaded
INFO - 2018-10-23 14:43:40 --> Database Driver Class Initialized
INFO - 2018-10-23 14:43:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:43:40 --> Form Validation Class Initialized
INFO - 2018-10-23 14:43:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:43:40 --> Database Driver Class Initialized
INFO - 2018-10-23 14:43:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:43:40 --> Config Class Initialized
INFO - 2018-10-23 14:43:40 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:43:40 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:43:40 --> Utf8 Class Initialized
INFO - 2018-10-23 14:43:40 --> URI Class Initialized
INFO - 2018-10-23 14:43:40 --> Router Class Initialized
INFO - 2018-10-23 14:43:40 --> Output Class Initialized
INFO - 2018-10-23 14:43:40 --> Security Class Initialized
DEBUG - 2018-10-23 14:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:43:40 --> CSRF cookie sent
INFO - 2018-10-23 14:43:40 --> Input Class Initialized
INFO - 2018-10-23 14:43:40 --> Language Class Initialized
INFO - 2018-10-23 14:43:40 --> Loader Class Initialized
INFO - 2018-10-23 14:43:40 --> Helper loaded: url_helper
INFO - 2018-10-23 14:43:40 --> Helper loaded: form_helper
INFO - 2018-10-23 14:43:40 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:43:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:43:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:43:40 --> User Agent Class Initialized
INFO - 2018-10-23 14:43:40 --> Controller Class Initialized
INFO - 2018-10-23 14:43:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:43:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:43:40 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:43:40 --> Pixel_Model class loaded
INFO - 2018-10-23 14:43:40 --> Database Driver Class Initialized
INFO - 2018-10-23 14:43:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:43:40 --> Database Driver Class Initialized
INFO - 2018-10-23 14:43:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:43:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:43:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:43:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner.php
INFO - 2018-10-23 14:43:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:43:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:43:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:43:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:43:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/relation_ship_status.php
INFO - 2018-10-23 14:43:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:43:40 --> Final output sent to browser
DEBUG - 2018-10-23 14:43:40 --> Total execution time: 0.5645
INFO - 2018-10-23 14:43:48 --> Config Class Initialized
INFO - 2018-10-23 14:43:48 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:43:48 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:43:48 --> Utf8 Class Initialized
INFO - 2018-10-23 14:43:48 --> URI Class Initialized
INFO - 2018-10-23 14:43:48 --> Router Class Initialized
INFO - 2018-10-23 14:43:48 --> Output Class Initialized
INFO - 2018-10-23 14:43:48 --> Security Class Initialized
DEBUG - 2018-10-23 14:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:43:49 --> CSRF cookie sent
INFO - 2018-10-23 14:43:49 --> CSRF token verified
INFO - 2018-10-23 14:43:49 --> Input Class Initialized
INFO - 2018-10-23 14:43:49 --> Language Class Initialized
INFO - 2018-10-23 14:43:49 --> Loader Class Initialized
INFO - 2018-10-23 14:43:49 --> Helper loaded: url_helper
INFO - 2018-10-23 14:43:49 --> Helper loaded: form_helper
INFO - 2018-10-23 14:43:49 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:43:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:43:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:43:49 --> User Agent Class Initialized
INFO - 2018-10-23 14:43:49 --> Controller Class Initialized
INFO - 2018-10-23 14:43:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:43:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:43:49 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:43:49 --> Pixel_Model class loaded
INFO - 2018-10-23 14:43:49 --> Database Driver Class Initialized
INFO - 2018-10-23 14:43:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:43:49 --> Form Validation Class Initialized
INFO - 2018-10-23 14:43:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:43:49 --> Database Driver Class Initialized
INFO - 2018-10-23 14:43:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:43:49 --> Config Class Initialized
INFO - 2018-10-23 14:43:49 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:43:49 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:43:49 --> Utf8 Class Initialized
INFO - 2018-10-23 14:43:49 --> URI Class Initialized
INFO - 2018-10-23 14:43:49 --> Router Class Initialized
INFO - 2018-10-23 14:43:49 --> Output Class Initialized
INFO - 2018-10-23 14:43:49 --> Security Class Initialized
DEBUG - 2018-10-23 14:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:43:49 --> CSRF cookie sent
INFO - 2018-10-23 14:43:49 --> Input Class Initialized
INFO - 2018-10-23 14:43:49 --> Language Class Initialized
INFO - 2018-10-23 14:43:49 --> Loader Class Initialized
INFO - 2018-10-23 14:43:49 --> Helper loaded: url_helper
INFO - 2018-10-23 14:43:49 --> Helper loaded: form_helper
INFO - 2018-10-23 14:43:49 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:43:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:43:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:43:49 --> User Agent Class Initialized
INFO - 2018-10-23 14:43:49 --> Controller Class Initialized
INFO - 2018-10-23 14:43:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:43:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:43:49 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:43:49 --> Pixel_Model class loaded
INFO - 2018-10-23 14:43:49 --> Database Driver Class Initialized
INFO - 2018-10-23 14:43:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:43:49 --> Database Driver Class Initialized
INFO - 2018-10-23 14:43:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:43:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:43:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:43:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:43:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:43:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:43:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:43:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/income.php
INFO - 2018-10-23 14:43:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:43:49 --> Final output sent to browser
DEBUG - 2018-10-23 14:43:49 --> Total execution time: 0.5605
INFO - 2018-10-23 14:43:53 --> Config Class Initialized
INFO - 2018-10-23 14:43:53 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:43:53 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:43:53 --> Utf8 Class Initialized
INFO - 2018-10-23 14:43:53 --> URI Class Initialized
INFO - 2018-10-23 14:43:53 --> Router Class Initialized
INFO - 2018-10-23 14:43:53 --> Output Class Initialized
INFO - 2018-10-23 14:43:53 --> Security Class Initialized
DEBUG - 2018-10-23 14:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:43:53 --> CSRF cookie sent
INFO - 2018-10-23 14:43:53 --> CSRF token verified
INFO - 2018-10-23 14:43:53 --> Input Class Initialized
INFO - 2018-10-23 14:43:53 --> Language Class Initialized
INFO - 2018-10-23 14:43:54 --> Loader Class Initialized
INFO - 2018-10-23 14:43:54 --> Helper loaded: url_helper
INFO - 2018-10-23 14:43:54 --> Helper loaded: form_helper
INFO - 2018-10-23 14:43:54 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:43:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:43:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:43:54 --> User Agent Class Initialized
INFO - 2018-10-23 14:43:54 --> Controller Class Initialized
INFO - 2018-10-23 14:43:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:43:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:43:54 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:43:54 --> Pixel_Model class loaded
INFO - 2018-10-23 14:43:54 --> Database Driver Class Initialized
INFO - 2018-10-23 14:43:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:43:54 --> Form Validation Class Initialized
INFO - 2018-10-23 14:43:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:43:54 --> Database Driver Class Initialized
INFO - 2018-10-23 14:43:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:43:54 --> Config Class Initialized
INFO - 2018-10-23 14:43:54 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:43:54 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:43:54 --> Utf8 Class Initialized
INFO - 2018-10-23 14:43:54 --> URI Class Initialized
INFO - 2018-10-23 14:43:54 --> Router Class Initialized
INFO - 2018-10-23 14:43:54 --> Output Class Initialized
INFO - 2018-10-23 14:43:54 --> Security Class Initialized
DEBUG - 2018-10-23 14:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:43:54 --> CSRF cookie sent
INFO - 2018-10-23 14:43:54 --> Input Class Initialized
INFO - 2018-10-23 14:43:54 --> Language Class Initialized
INFO - 2018-10-23 14:43:54 --> Loader Class Initialized
INFO - 2018-10-23 14:43:54 --> Helper loaded: url_helper
INFO - 2018-10-23 14:43:54 --> Helper loaded: form_helper
INFO - 2018-10-23 14:43:54 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:43:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:43:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:43:54 --> User Agent Class Initialized
INFO - 2018-10-23 14:43:54 --> Controller Class Initialized
INFO - 2018-10-23 14:43:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:43:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:43:54 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:43:54 --> Pixel_Model class loaded
INFO - 2018-10-23 14:43:54 --> Database Driver Class Initialized
INFO - 2018-10-23 14:43:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:43:54 --> Database Driver Class Initialized
INFO - 2018-10-23 14:43:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:43:54 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:43:54 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:43:54 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:43:54 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:43:54 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:43:54 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:43:54 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/pension.php
INFO - 2018-10-23 14:43:54 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:43:54 --> Final output sent to browser
DEBUG - 2018-10-23 14:43:54 --> Total execution time: 0.5707
INFO - 2018-10-23 14:43:57 --> Config Class Initialized
INFO - 2018-10-23 14:43:57 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:43:57 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:43:57 --> Utf8 Class Initialized
INFO - 2018-10-23 14:43:57 --> URI Class Initialized
INFO - 2018-10-23 14:43:57 --> Router Class Initialized
INFO - 2018-10-23 14:43:57 --> Output Class Initialized
INFO - 2018-10-23 14:43:57 --> Security Class Initialized
DEBUG - 2018-10-23 14:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:43:57 --> CSRF cookie sent
INFO - 2018-10-23 14:43:57 --> CSRF token verified
INFO - 2018-10-23 14:43:57 --> Input Class Initialized
INFO - 2018-10-23 14:43:57 --> Language Class Initialized
INFO - 2018-10-23 14:43:57 --> Loader Class Initialized
INFO - 2018-10-23 14:43:57 --> Helper loaded: url_helper
INFO - 2018-10-23 14:43:57 --> Helper loaded: form_helper
INFO - 2018-10-23 14:43:57 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:43:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:43:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:43:57 --> User Agent Class Initialized
INFO - 2018-10-23 14:43:57 --> Controller Class Initialized
INFO - 2018-10-23 14:43:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:43:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:43:58 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:43:58 --> Pixel_Model class loaded
INFO - 2018-10-23 14:43:58 --> Database Driver Class Initialized
INFO - 2018-10-23 14:43:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:43:58 --> Form Validation Class Initialized
INFO - 2018-10-23 14:43:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:43:58 --> Database Driver Class Initialized
INFO - 2018-10-23 14:43:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:43:58 --> Config Class Initialized
INFO - 2018-10-23 14:43:58 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:43:58 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:43:58 --> Utf8 Class Initialized
INFO - 2018-10-23 14:43:58 --> URI Class Initialized
INFO - 2018-10-23 14:43:58 --> Router Class Initialized
INFO - 2018-10-23 14:43:58 --> Output Class Initialized
INFO - 2018-10-23 14:43:58 --> Security Class Initialized
DEBUG - 2018-10-23 14:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:43:58 --> CSRF cookie sent
INFO - 2018-10-23 14:43:58 --> Input Class Initialized
INFO - 2018-10-23 14:43:58 --> Language Class Initialized
INFO - 2018-10-23 14:43:58 --> Loader Class Initialized
INFO - 2018-10-23 14:43:58 --> Helper loaded: url_helper
INFO - 2018-10-23 14:43:58 --> Helper loaded: form_helper
INFO - 2018-10-23 14:43:58 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:43:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:43:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:43:58 --> User Agent Class Initialized
INFO - 2018-10-23 14:43:58 --> Controller Class Initialized
INFO - 2018-10-23 14:43:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:43:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:43:58 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:43:58 --> Pixel_Model class loaded
INFO - 2018-10-23 14:43:58 --> Database Driver Class Initialized
INFO - 2018-10-23 14:43:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:43:58 --> Database Driver Class Initialized
INFO - 2018-10-23 14:43:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:43:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:43:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:43:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:43:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:43:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:43:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:43:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/home_title.php
INFO - 2018-10-23 14:43:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:43:58 --> Final output sent to browser
DEBUG - 2018-10-23 14:43:58 --> Total execution time: 0.5778
INFO - 2018-10-23 14:44:01 --> Config Class Initialized
INFO - 2018-10-23 14:44:01 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:44:01 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:44:01 --> Utf8 Class Initialized
INFO - 2018-10-23 14:44:01 --> URI Class Initialized
INFO - 2018-10-23 14:44:01 --> Router Class Initialized
INFO - 2018-10-23 14:44:01 --> Output Class Initialized
INFO - 2018-10-23 14:44:01 --> Security Class Initialized
DEBUG - 2018-10-23 14:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:44:01 --> CSRF cookie sent
INFO - 2018-10-23 14:44:01 --> Input Class Initialized
INFO - 2018-10-23 14:44:01 --> Language Class Initialized
INFO - 2018-10-23 14:44:01 --> Loader Class Initialized
INFO - 2018-10-23 14:44:01 --> Helper loaded: url_helper
INFO - 2018-10-23 14:44:01 --> Helper loaded: form_helper
INFO - 2018-10-23 14:44:01 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:44:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:44:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:44:01 --> User Agent Class Initialized
INFO - 2018-10-23 14:44:01 --> Controller Class Initialized
INFO - 2018-10-23 14:44:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:44:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:44:01 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:44:01 --> Pixel_Model class loaded
INFO - 2018-10-23 14:44:01 --> Database Driver Class Initialized
INFO - 2018-10-23 14:44:01 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:44:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:44:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:44:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:44:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:44:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:44:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:44:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-23 14:44:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:44:01 --> Final output sent to browser
DEBUG - 2018-10-23 14:44:01 --> Total execution time: 0.5227
INFO - 2018-10-23 14:44:04 --> Config Class Initialized
INFO - 2018-10-23 14:44:04 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:44:04 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:44:04 --> Utf8 Class Initialized
INFO - 2018-10-23 14:44:04 --> URI Class Initialized
INFO - 2018-10-23 14:44:04 --> Router Class Initialized
INFO - 2018-10-23 14:44:04 --> Output Class Initialized
INFO - 2018-10-23 14:44:04 --> Security Class Initialized
DEBUG - 2018-10-23 14:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:44:04 --> CSRF cookie sent
INFO - 2018-10-23 14:44:04 --> Input Class Initialized
INFO - 2018-10-23 14:44:04 --> Language Class Initialized
INFO - 2018-10-23 14:44:04 --> Loader Class Initialized
INFO - 2018-10-23 14:44:04 --> Helper loaded: url_helper
INFO - 2018-10-23 14:44:04 --> Helper loaded: form_helper
INFO - 2018-10-23 14:44:04 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:44:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:44:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:44:04 --> User Agent Class Initialized
INFO - 2018-10-23 14:44:04 --> Controller Class Initialized
INFO - 2018-10-23 14:44:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:44:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:44:04 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:44:04 --> Pixel_Model class loaded
INFO - 2018-10-23 14:44:04 --> Database Driver Class Initialized
INFO - 2018-10-23 14:44:04 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:44:04 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:44:04 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:44:04 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:44:04 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:44:04 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:44:04 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:44:04 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-23 14:44:04 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:44:04 --> Final output sent to browser
DEBUG - 2018-10-23 14:44:04 --> Total execution time: 0.5396
INFO - 2018-10-23 14:44:11 --> Config Class Initialized
INFO - 2018-10-23 14:44:11 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:44:11 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:44:11 --> Utf8 Class Initialized
INFO - 2018-10-23 14:44:11 --> URI Class Initialized
INFO - 2018-10-23 14:44:11 --> Router Class Initialized
INFO - 2018-10-23 14:44:11 --> Output Class Initialized
INFO - 2018-10-23 14:44:11 --> Security Class Initialized
DEBUG - 2018-10-23 14:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:44:11 --> CSRF cookie sent
INFO - 2018-10-23 14:44:11 --> Input Class Initialized
INFO - 2018-10-23 14:44:11 --> Language Class Initialized
INFO - 2018-10-23 14:44:11 --> Loader Class Initialized
INFO - 2018-10-23 14:44:11 --> Helper loaded: url_helper
INFO - 2018-10-23 14:44:11 --> Helper loaded: form_helper
INFO - 2018-10-23 14:44:11 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:44:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:44:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:44:11 --> User Agent Class Initialized
INFO - 2018-10-23 14:44:11 --> Controller Class Initialized
INFO - 2018-10-23 14:44:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:44:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:44:11 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:44:11 --> Pixel_Model class loaded
INFO - 2018-10-23 14:44:11 --> Database Driver Class Initialized
INFO - 2018-10-23 14:44:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:44:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:44:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:44:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:44:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:44:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:44:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:44:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-23 14:44:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:44:11 --> Final output sent to browser
DEBUG - 2018-10-23 14:44:11 --> Total execution time: 0.5213
INFO - 2018-10-23 14:44:14 --> Config Class Initialized
INFO - 2018-10-23 14:44:14 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:44:14 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:44:14 --> Utf8 Class Initialized
INFO - 2018-10-23 14:44:14 --> URI Class Initialized
INFO - 2018-10-23 14:44:14 --> Router Class Initialized
INFO - 2018-10-23 14:44:14 --> Output Class Initialized
INFO - 2018-10-23 14:44:14 --> Security Class Initialized
DEBUG - 2018-10-23 14:44:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:44:14 --> CSRF cookie sent
INFO - 2018-10-23 14:44:14 --> CSRF token verified
INFO - 2018-10-23 14:44:14 --> Input Class Initialized
INFO - 2018-10-23 14:44:14 --> Language Class Initialized
INFO - 2018-10-23 14:44:14 --> Loader Class Initialized
INFO - 2018-10-23 14:44:14 --> Helper loaded: url_helper
INFO - 2018-10-23 14:44:14 --> Helper loaded: form_helper
INFO - 2018-10-23 14:44:14 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:44:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:44:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:44:14 --> User Agent Class Initialized
INFO - 2018-10-23 14:44:14 --> Controller Class Initialized
INFO - 2018-10-23 14:44:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:44:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:44:14 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:44:14 --> Pixel_Model class loaded
INFO - 2018-10-23 14:44:14 --> Database Driver Class Initialized
INFO - 2018-10-23 14:44:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:44:14 --> Form Validation Class Initialized
INFO - 2018-10-23 14:44:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:44:14 --> Database Driver Class Initialized
INFO - 2018-10-23 14:44:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:44:14 --> Config Class Initialized
INFO - 2018-10-23 14:44:14 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:44:14 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:44:14 --> Utf8 Class Initialized
INFO - 2018-10-23 14:44:14 --> URI Class Initialized
INFO - 2018-10-23 14:44:14 --> Router Class Initialized
INFO - 2018-10-23 14:44:14 --> Output Class Initialized
INFO - 2018-10-23 14:44:15 --> Security Class Initialized
DEBUG - 2018-10-23 14:44:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:44:15 --> CSRF cookie sent
INFO - 2018-10-23 14:44:15 --> Input Class Initialized
INFO - 2018-10-23 14:44:15 --> Language Class Initialized
INFO - 2018-10-23 14:44:15 --> Loader Class Initialized
INFO - 2018-10-23 14:44:15 --> Helper loaded: url_helper
INFO - 2018-10-23 14:44:15 --> Helper loaded: form_helper
INFO - 2018-10-23 14:44:15 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:44:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:44:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:44:15 --> User Agent Class Initialized
INFO - 2018-10-23 14:44:15 --> Controller Class Initialized
INFO - 2018-10-23 14:44:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:44:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:44:15 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:44:15 --> Pixel_Model class loaded
INFO - 2018-10-23 14:44:15 --> Database Driver Class Initialized
INFO - 2018-10-23 14:44:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:44:15 --> Database Driver Class Initialized
INFO - 2018-10-23 14:44:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:44:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:44:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:44:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:44:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:44:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:44:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:44:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-23 14:44:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:44:15 --> Final output sent to browser
DEBUG - 2018-10-23 14:44:15 --> Total execution time: 0.5735
INFO - 2018-10-23 14:44:18 --> Config Class Initialized
INFO - 2018-10-23 14:44:18 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:44:18 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:44:18 --> Utf8 Class Initialized
INFO - 2018-10-23 14:44:18 --> URI Class Initialized
INFO - 2018-10-23 14:44:18 --> Router Class Initialized
INFO - 2018-10-23 14:44:18 --> Output Class Initialized
INFO - 2018-10-23 14:44:18 --> Security Class Initialized
DEBUG - 2018-10-23 14:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:44:18 --> CSRF cookie sent
INFO - 2018-10-23 14:44:18 --> CSRF token verified
INFO - 2018-10-23 14:44:18 --> Input Class Initialized
INFO - 2018-10-23 14:44:18 --> Language Class Initialized
INFO - 2018-10-23 14:44:18 --> Loader Class Initialized
INFO - 2018-10-23 14:44:18 --> Helper loaded: url_helper
INFO - 2018-10-23 14:44:18 --> Helper loaded: form_helper
INFO - 2018-10-23 14:44:18 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:44:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:44:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:44:18 --> User Agent Class Initialized
INFO - 2018-10-23 14:44:18 --> Controller Class Initialized
INFO - 2018-10-23 14:44:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:44:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:44:18 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:44:18 --> Pixel_Model class loaded
INFO - 2018-10-23 14:44:18 --> Database Driver Class Initialized
INFO - 2018-10-23 14:44:18 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:44:18 --> Form Validation Class Initialized
INFO - 2018-10-23 14:44:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:44:18 --> Database Driver Class Initialized
INFO - 2018-10-23 14:44:18 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:44:18 --> Config Class Initialized
INFO - 2018-10-23 14:44:18 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:44:18 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:44:18 --> Utf8 Class Initialized
INFO - 2018-10-23 14:44:18 --> URI Class Initialized
INFO - 2018-10-23 14:44:18 --> Router Class Initialized
INFO - 2018-10-23 14:44:18 --> Output Class Initialized
INFO - 2018-10-23 14:44:18 --> Security Class Initialized
DEBUG - 2018-10-23 14:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:44:18 --> CSRF cookie sent
INFO - 2018-10-23 14:44:18 --> Input Class Initialized
INFO - 2018-10-23 14:44:19 --> Language Class Initialized
INFO - 2018-10-23 14:44:19 --> Loader Class Initialized
INFO - 2018-10-23 14:44:19 --> Helper loaded: url_helper
INFO - 2018-10-23 14:44:19 --> Helper loaded: form_helper
INFO - 2018-10-23 14:44:19 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:44:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:44:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:44:19 --> User Agent Class Initialized
INFO - 2018-10-23 14:44:19 --> Controller Class Initialized
INFO - 2018-10-23 14:44:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:44:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:44:19 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:44:19 --> Pixel_Model class loaded
INFO - 2018-10-23 14:44:19 --> Database Driver Class Initialized
INFO - 2018-10-23 14:44:19 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:44:19 --> Database Driver Class Initialized
INFO - 2018-10-23 14:44:19 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:44:19 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:44:19 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:44:19 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:44:19 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:44:19 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:44:19 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:44:19 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/your_job.php
INFO - 2018-10-23 14:44:19 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:44:19 --> Final output sent to browser
DEBUG - 2018-10-23 14:44:19 --> Total execution time: 0.5759
INFO - 2018-10-23 14:44:21 --> Config Class Initialized
INFO - 2018-10-23 14:44:21 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:44:21 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:44:21 --> Utf8 Class Initialized
INFO - 2018-10-23 14:44:21 --> URI Class Initialized
INFO - 2018-10-23 14:44:21 --> Router Class Initialized
INFO - 2018-10-23 14:44:21 --> Output Class Initialized
INFO - 2018-10-23 14:44:21 --> Security Class Initialized
DEBUG - 2018-10-23 14:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:44:21 --> CSRF cookie sent
INFO - 2018-10-23 14:44:21 --> CSRF token verified
INFO - 2018-10-23 14:44:21 --> Input Class Initialized
INFO - 2018-10-23 14:44:21 --> Language Class Initialized
INFO - 2018-10-23 14:44:21 --> Loader Class Initialized
INFO - 2018-10-23 14:44:21 --> Helper loaded: url_helper
INFO - 2018-10-23 14:44:21 --> Helper loaded: form_helper
INFO - 2018-10-23 14:44:21 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:44:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:44:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:44:21 --> User Agent Class Initialized
INFO - 2018-10-23 14:44:21 --> Controller Class Initialized
INFO - 2018-10-23 14:44:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:44:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:44:21 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:44:21 --> Pixel_Model class loaded
INFO - 2018-10-23 14:44:21 --> Database Driver Class Initialized
INFO - 2018-10-23 14:44:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:44:21 --> Form Validation Class Initialized
INFO - 2018-10-23 14:44:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:44:21 --> Database Driver Class Initialized
INFO - 2018-10-23 14:44:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:44:21 --> Config Class Initialized
INFO - 2018-10-23 14:44:21 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:44:21 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:44:21 --> Utf8 Class Initialized
INFO - 2018-10-23 14:44:21 --> URI Class Initialized
INFO - 2018-10-23 14:44:21 --> Router Class Initialized
INFO - 2018-10-23 14:44:21 --> Output Class Initialized
INFO - 2018-10-23 14:44:21 --> Security Class Initialized
DEBUG - 2018-10-23 14:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:44:21 --> CSRF cookie sent
INFO - 2018-10-23 14:44:21 --> Input Class Initialized
INFO - 2018-10-23 14:44:21 --> Language Class Initialized
INFO - 2018-10-23 14:44:21 --> Loader Class Initialized
INFO - 2018-10-23 14:44:21 --> Helper loaded: url_helper
INFO - 2018-10-23 14:44:21 --> Helper loaded: form_helper
INFO - 2018-10-23 14:44:21 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:44:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:44:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:44:22 --> User Agent Class Initialized
INFO - 2018-10-23 14:44:22 --> Controller Class Initialized
INFO - 2018-10-23 14:44:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:44:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:44:22 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:44:22 --> Pixel_Model class loaded
INFO - 2018-10-23 14:44:22 --> Database Driver Class Initialized
INFO - 2018-10-23 14:44:22 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:44:22 --> Database Driver Class Initialized
INFO - 2018-10-23 14:44:22 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:44:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:44:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:44:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner.php
INFO - 2018-10-23 14:44:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:44:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:44:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:44:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:44:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/relation_ship_status.php
INFO - 2018-10-23 14:44:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:44:22 --> Final output sent to browser
DEBUG - 2018-10-23 14:44:22 --> Total execution time: 0.5751
INFO - 2018-10-23 14:44:24 --> Config Class Initialized
INFO - 2018-10-23 14:44:24 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:44:24 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:44:24 --> Utf8 Class Initialized
INFO - 2018-10-23 14:44:24 --> URI Class Initialized
INFO - 2018-10-23 14:44:24 --> Router Class Initialized
INFO - 2018-10-23 14:44:24 --> Output Class Initialized
INFO - 2018-10-23 14:44:24 --> Security Class Initialized
DEBUG - 2018-10-23 14:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:44:24 --> CSRF cookie sent
INFO - 2018-10-23 14:44:24 --> CSRF token verified
INFO - 2018-10-23 14:44:24 --> Input Class Initialized
INFO - 2018-10-23 14:44:24 --> Language Class Initialized
INFO - 2018-10-23 14:44:24 --> Loader Class Initialized
INFO - 2018-10-23 14:44:24 --> Helper loaded: url_helper
INFO - 2018-10-23 14:44:24 --> Helper loaded: form_helper
INFO - 2018-10-23 14:44:24 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:44:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:44:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:44:24 --> User Agent Class Initialized
INFO - 2018-10-23 14:44:24 --> Controller Class Initialized
INFO - 2018-10-23 14:44:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:44:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:44:24 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:44:24 --> Pixel_Model class loaded
INFO - 2018-10-23 14:44:24 --> Database Driver Class Initialized
INFO - 2018-10-23 14:44:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:44:25 --> Form Validation Class Initialized
INFO - 2018-10-23 14:44:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:44:25 --> Database Driver Class Initialized
INFO - 2018-10-23 14:44:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:44:25 --> Config Class Initialized
INFO - 2018-10-23 14:44:25 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:44:25 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:44:25 --> Utf8 Class Initialized
INFO - 2018-10-23 14:44:25 --> URI Class Initialized
INFO - 2018-10-23 14:44:25 --> Router Class Initialized
INFO - 2018-10-23 14:44:25 --> Output Class Initialized
INFO - 2018-10-23 14:44:25 --> Security Class Initialized
DEBUG - 2018-10-23 14:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:44:25 --> CSRF cookie sent
INFO - 2018-10-23 14:44:25 --> Input Class Initialized
INFO - 2018-10-23 14:44:25 --> Language Class Initialized
INFO - 2018-10-23 14:44:25 --> Loader Class Initialized
INFO - 2018-10-23 14:44:25 --> Helper loaded: url_helper
INFO - 2018-10-23 14:44:25 --> Helper loaded: form_helper
INFO - 2018-10-23 14:44:25 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:44:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:44:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:44:25 --> User Agent Class Initialized
INFO - 2018-10-23 14:44:25 --> Controller Class Initialized
INFO - 2018-10-23 14:44:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:44:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:44:25 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:44:25 --> Pixel_Model class loaded
INFO - 2018-10-23 14:44:25 --> Database Driver Class Initialized
INFO - 2018-10-23 14:44:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:44:25 --> Database Driver Class Initialized
INFO - 2018-10-23 14:44:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:44:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:44:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:44:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:44:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:44:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:44:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:44:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/income.php
INFO - 2018-10-23 14:44:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:44:25 --> Final output sent to browser
DEBUG - 2018-10-23 14:44:25 --> Total execution time: 0.5885
INFO - 2018-10-23 14:44:26 --> Config Class Initialized
INFO - 2018-10-23 14:44:26 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:44:26 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:44:26 --> Utf8 Class Initialized
INFO - 2018-10-23 14:44:26 --> URI Class Initialized
INFO - 2018-10-23 14:44:26 --> Router Class Initialized
INFO - 2018-10-23 14:44:27 --> Output Class Initialized
INFO - 2018-10-23 14:44:27 --> Security Class Initialized
DEBUG - 2018-10-23 14:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:44:27 --> CSRF cookie sent
INFO - 2018-10-23 14:44:27 --> CSRF token verified
INFO - 2018-10-23 14:44:27 --> Input Class Initialized
INFO - 2018-10-23 14:44:27 --> Language Class Initialized
INFO - 2018-10-23 14:44:27 --> Loader Class Initialized
INFO - 2018-10-23 14:44:27 --> Helper loaded: url_helper
INFO - 2018-10-23 14:44:27 --> Helper loaded: form_helper
INFO - 2018-10-23 14:44:27 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:44:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:44:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:44:27 --> User Agent Class Initialized
INFO - 2018-10-23 14:44:27 --> Controller Class Initialized
INFO - 2018-10-23 14:44:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:44:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:44:27 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:44:27 --> Pixel_Model class loaded
INFO - 2018-10-23 14:44:27 --> Database Driver Class Initialized
INFO - 2018-10-23 14:44:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:44:27 --> Form Validation Class Initialized
INFO - 2018-10-23 14:44:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:44:27 --> Database Driver Class Initialized
INFO - 2018-10-23 14:44:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:44:27 --> Config Class Initialized
INFO - 2018-10-23 14:44:27 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:44:27 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:44:27 --> Utf8 Class Initialized
INFO - 2018-10-23 14:44:27 --> URI Class Initialized
INFO - 2018-10-23 14:44:27 --> Router Class Initialized
INFO - 2018-10-23 14:44:27 --> Output Class Initialized
INFO - 2018-10-23 14:44:27 --> Security Class Initialized
DEBUG - 2018-10-23 14:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:44:27 --> CSRF cookie sent
INFO - 2018-10-23 14:44:27 --> Input Class Initialized
INFO - 2018-10-23 14:44:27 --> Language Class Initialized
INFO - 2018-10-23 14:44:27 --> Loader Class Initialized
INFO - 2018-10-23 14:44:27 --> Helper loaded: url_helper
INFO - 2018-10-23 14:44:27 --> Helper loaded: form_helper
INFO - 2018-10-23 14:44:27 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:44:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:44:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:44:27 --> User Agent Class Initialized
INFO - 2018-10-23 14:44:27 --> Controller Class Initialized
INFO - 2018-10-23 14:44:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:44:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:44:27 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:44:27 --> Pixel_Model class loaded
INFO - 2018-10-23 14:44:27 --> Database Driver Class Initialized
INFO - 2018-10-23 14:44:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:44:27 --> Database Driver Class Initialized
INFO - 2018-10-23 14:44:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:44:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:44:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:44:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:44:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:44:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:44:28 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:44:28 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/pension.php
INFO - 2018-10-23 14:44:28 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:44:28 --> Final output sent to browser
DEBUG - 2018-10-23 14:44:28 --> Total execution time: 0.5653
INFO - 2018-10-23 14:44:29 --> Config Class Initialized
INFO - 2018-10-23 14:44:29 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:44:29 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:44:29 --> Utf8 Class Initialized
INFO - 2018-10-23 14:44:29 --> URI Class Initialized
INFO - 2018-10-23 14:44:29 --> Router Class Initialized
INFO - 2018-10-23 14:44:29 --> Output Class Initialized
INFO - 2018-10-23 14:44:29 --> Security Class Initialized
DEBUG - 2018-10-23 14:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:44:29 --> CSRF cookie sent
INFO - 2018-10-23 14:44:29 --> CSRF token verified
INFO - 2018-10-23 14:44:29 --> Input Class Initialized
INFO - 2018-10-23 14:44:29 --> Language Class Initialized
INFO - 2018-10-23 14:44:29 --> Loader Class Initialized
INFO - 2018-10-23 14:44:29 --> Helper loaded: url_helper
INFO - 2018-10-23 14:44:29 --> Helper loaded: form_helper
INFO - 2018-10-23 14:44:29 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:44:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:44:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:44:29 --> User Agent Class Initialized
INFO - 2018-10-23 14:44:29 --> Controller Class Initialized
INFO - 2018-10-23 14:44:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:44:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:44:29 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:44:29 --> Pixel_Model class loaded
INFO - 2018-10-23 14:44:29 --> Database Driver Class Initialized
INFO - 2018-10-23 14:44:29 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:44:29 --> Form Validation Class Initialized
INFO - 2018-10-23 14:44:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:44:29 --> Database Driver Class Initialized
INFO - 2018-10-23 14:44:29 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:44:29 --> Config Class Initialized
INFO - 2018-10-23 14:44:29 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:44:29 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:44:29 --> Utf8 Class Initialized
INFO - 2018-10-23 14:44:29 --> URI Class Initialized
INFO - 2018-10-23 14:44:29 --> Router Class Initialized
INFO - 2018-10-23 14:44:29 --> Output Class Initialized
INFO - 2018-10-23 14:44:29 --> Security Class Initialized
DEBUG - 2018-10-23 14:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:44:30 --> CSRF cookie sent
INFO - 2018-10-23 14:44:30 --> Input Class Initialized
INFO - 2018-10-23 14:44:30 --> Language Class Initialized
INFO - 2018-10-23 14:44:30 --> Loader Class Initialized
INFO - 2018-10-23 14:44:30 --> Helper loaded: url_helper
INFO - 2018-10-23 14:44:30 --> Helper loaded: form_helper
INFO - 2018-10-23 14:44:30 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:44:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:44:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:44:30 --> User Agent Class Initialized
INFO - 2018-10-23 14:44:30 --> Controller Class Initialized
INFO - 2018-10-23 14:44:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:44:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:44:30 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:44:30 --> Pixel_Model class loaded
INFO - 2018-10-23 14:44:30 --> Database Driver Class Initialized
INFO - 2018-10-23 14:44:30 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:44:30 --> Database Driver Class Initialized
INFO - 2018-10-23 14:44:30 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:44:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:44:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:44:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:44:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:44:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:44:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:44:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/home_title.php
INFO - 2018-10-23 14:44:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:44:30 --> Final output sent to browser
DEBUG - 2018-10-23 14:44:30 --> Total execution time: 0.5867
INFO - 2018-10-23 14:44:41 --> Config Class Initialized
INFO - 2018-10-23 14:44:41 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:44:42 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:44:42 --> Utf8 Class Initialized
INFO - 2018-10-23 14:44:42 --> URI Class Initialized
INFO - 2018-10-23 14:44:42 --> Router Class Initialized
INFO - 2018-10-23 14:44:42 --> Output Class Initialized
INFO - 2018-10-23 14:44:42 --> Security Class Initialized
DEBUG - 2018-10-23 14:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:44:42 --> CSRF cookie sent
INFO - 2018-10-23 14:44:42 --> Input Class Initialized
INFO - 2018-10-23 14:44:42 --> Language Class Initialized
INFO - 2018-10-23 14:44:42 --> Loader Class Initialized
INFO - 2018-10-23 14:44:42 --> Helper loaded: url_helper
INFO - 2018-10-23 14:44:42 --> Helper loaded: form_helper
INFO - 2018-10-23 14:44:42 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:44:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:44:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:44:42 --> User Agent Class Initialized
INFO - 2018-10-23 14:44:42 --> Controller Class Initialized
INFO - 2018-10-23 14:44:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:44:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:44:42 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:44:42 --> Pixel_Model class loaded
INFO - 2018-10-23 14:44:42 --> Database Driver Class Initialized
INFO - 2018-10-23 14:44:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:44:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:44:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:44:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:44:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:44:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:44:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:44:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-23 14:44:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:44:42 --> Final output sent to browser
DEBUG - 2018-10-23 14:44:42 --> Total execution time: 0.5619
INFO - 2018-10-23 14:44:44 --> Config Class Initialized
INFO - 2018-10-23 14:44:44 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:44:44 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:44:44 --> Utf8 Class Initialized
INFO - 2018-10-23 14:44:44 --> URI Class Initialized
INFO - 2018-10-23 14:44:44 --> Router Class Initialized
INFO - 2018-10-23 14:44:44 --> Output Class Initialized
INFO - 2018-10-23 14:44:44 --> Security Class Initialized
DEBUG - 2018-10-23 14:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:44:44 --> CSRF cookie sent
INFO - 2018-10-23 14:44:44 --> CSRF token verified
INFO - 2018-10-23 14:44:44 --> Input Class Initialized
INFO - 2018-10-23 14:44:44 --> Language Class Initialized
INFO - 2018-10-23 14:44:44 --> Loader Class Initialized
INFO - 2018-10-23 14:44:44 --> Helper loaded: url_helper
INFO - 2018-10-23 14:44:44 --> Helper loaded: form_helper
INFO - 2018-10-23 14:44:44 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:44:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:44:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:44:44 --> User Agent Class Initialized
INFO - 2018-10-23 14:44:44 --> Controller Class Initialized
INFO - 2018-10-23 14:44:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:44:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:44:44 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:44:44 --> Pixel_Model class loaded
INFO - 2018-10-23 14:44:44 --> Database Driver Class Initialized
INFO - 2018-10-23 14:44:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:44:45 --> Form Validation Class Initialized
INFO - 2018-10-23 14:44:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:44:45 --> Database Driver Class Initialized
INFO - 2018-10-23 14:44:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:44:45 --> Config Class Initialized
INFO - 2018-10-23 14:44:45 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:44:45 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:44:45 --> Utf8 Class Initialized
INFO - 2018-10-23 14:44:45 --> URI Class Initialized
INFO - 2018-10-23 14:44:45 --> Router Class Initialized
INFO - 2018-10-23 14:44:45 --> Output Class Initialized
INFO - 2018-10-23 14:44:45 --> Security Class Initialized
DEBUG - 2018-10-23 14:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:44:45 --> CSRF cookie sent
INFO - 2018-10-23 14:44:45 --> Input Class Initialized
INFO - 2018-10-23 14:44:45 --> Language Class Initialized
INFO - 2018-10-23 14:44:45 --> Loader Class Initialized
INFO - 2018-10-23 14:44:45 --> Helper loaded: url_helper
INFO - 2018-10-23 14:44:45 --> Helper loaded: form_helper
INFO - 2018-10-23 14:44:45 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:44:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:44:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:44:45 --> User Agent Class Initialized
INFO - 2018-10-23 14:44:45 --> Controller Class Initialized
INFO - 2018-10-23 14:44:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:44:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:44:45 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:44:45 --> Pixel_Model class loaded
INFO - 2018-10-23 14:44:45 --> Database Driver Class Initialized
INFO - 2018-10-23 14:44:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:44:45 --> Database Driver Class Initialized
INFO - 2018-10-23 14:44:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:44:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:44:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:44:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:44:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:44:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:44:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:44:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-23 14:44:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:44:45 --> Final output sent to browser
DEBUG - 2018-10-23 14:44:45 --> Total execution time: 0.5979
INFO - 2018-10-23 14:44:48 --> Config Class Initialized
INFO - 2018-10-23 14:44:48 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:44:48 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:44:48 --> Utf8 Class Initialized
INFO - 2018-10-23 14:44:48 --> URI Class Initialized
INFO - 2018-10-23 14:44:48 --> Router Class Initialized
INFO - 2018-10-23 14:44:48 --> Output Class Initialized
INFO - 2018-10-23 14:44:48 --> Security Class Initialized
DEBUG - 2018-10-23 14:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:44:48 --> CSRF cookie sent
INFO - 2018-10-23 14:44:48 --> CSRF token verified
INFO - 2018-10-23 14:44:48 --> Input Class Initialized
INFO - 2018-10-23 14:44:48 --> Language Class Initialized
INFO - 2018-10-23 14:44:48 --> Loader Class Initialized
INFO - 2018-10-23 14:44:48 --> Helper loaded: url_helper
INFO - 2018-10-23 14:44:48 --> Helper loaded: form_helper
INFO - 2018-10-23 14:44:48 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:44:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:44:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:44:48 --> User Agent Class Initialized
INFO - 2018-10-23 14:44:48 --> Controller Class Initialized
INFO - 2018-10-23 14:44:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:44:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:44:48 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:44:48 --> Pixel_Model class loaded
INFO - 2018-10-23 14:44:48 --> Database Driver Class Initialized
INFO - 2018-10-23 14:44:48 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:44:48 --> Form Validation Class Initialized
INFO - 2018-10-23 14:44:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:44:48 --> Database Driver Class Initialized
INFO - 2018-10-23 14:44:48 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:44:48 --> Config Class Initialized
INFO - 2018-10-23 14:44:48 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:44:48 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:44:48 --> Utf8 Class Initialized
INFO - 2018-10-23 14:44:48 --> URI Class Initialized
INFO - 2018-10-23 14:44:48 --> Router Class Initialized
INFO - 2018-10-23 14:44:48 --> Output Class Initialized
INFO - 2018-10-23 14:44:48 --> Security Class Initialized
DEBUG - 2018-10-23 14:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:44:48 --> CSRF cookie sent
INFO - 2018-10-23 14:44:48 --> Input Class Initialized
INFO - 2018-10-23 14:44:48 --> Language Class Initialized
INFO - 2018-10-23 14:44:48 --> Loader Class Initialized
INFO - 2018-10-23 14:44:48 --> Helper loaded: url_helper
INFO - 2018-10-23 14:44:48 --> Helper loaded: form_helper
INFO - 2018-10-23 14:44:48 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:44:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:44:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:44:49 --> User Agent Class Initialized
INFO - 2018-10-23 14:44:49 --> Controller Class Initialized
INFO - 2018-10-23 14:44:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:44:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:44:49 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:44:49 --> Pixel_Model class loaded
INFO - 2018-10-23 14:44:49 --> Database Driver Class Initialized
INFO - 2018-10-23 14:44:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:44:49 --> Database Driver Class Initialized
INFO - 2018-10-23 14:44:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:44:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:44:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:44:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:44:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:44:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:44:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:44:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/your_job.php
INFO - 2018-10-23 14:44:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:44:49 --> Final output sent to browser
DEBUG - 2018-10-23 14:44:49 --> Total execution time: 0.5998
INFO - 2018-10-23 14:44:51 --> Config Class Initialized
INFO - 2018-10-23 14:44:51 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:44:51 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:44:51 --> Utf8 Class Initialized
INFO - 2018-10-23 14:44:51 --> URI Class Initialized
INFO - 2018-10-23 14:44:51 --> Router Class Initialized
INFO - 2018-10-23 14:44:51 --> Output Class Initialized
INFO - 2018-10-23 14:44:51 --> Security Class Initialized
DEBUG - 2018-10-23 14:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:44:51 --> CSRF cookie sent
INFO - 2018-10-23 14:44:51 --> CSRF token verified
INFO - 2018-10-23 14:44:51 --> Input Class Initialized
INFO - 2018-10-23 14:44:51 --> Language Class Initialized
INFO - 2018-10-23 14:44:51 --> Loader Class Initialized
INFO - 2018-10-23 14:44:51 --> Helper loaded: url_helper
INFO - 2018-10-23 14:44:51 --> Helper loaded: form_helper
INFO - 2018-10-23 14:44:51 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:44:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:44:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:44:51 --> User Agent Class Initialized
INFO - 2018-10-23 14:44:51 --> Controller Class Initialized
INFO - 2018-10-23 14:44:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:44:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:44:51 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:44:51 --> Pixel_Model class loaded
INFO - 2018-10-23 14:44:51 --> Database Driver Class Initialized
INFO - 2018-10-23 14:44:51 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:44:51 --> Form Validation Class Initialized
INFO - 2018-10-23 14:44:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:44:51 --> Database Driver Class Initialized
INFO - 2018-10-23 14:44:51 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:44:51 --> Config Class Initialized
INFO - 2018-10-23 14:44:51 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:44:51 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:44:51 --> Utf8 Class Initialized
INFO - 2018-10-23 14:44:51 --> URI Class Initialized
INFO - 2018-10-23 14:44:51 --> Router Class Initialized
INFO - 2018-10-23 14:44:51 --> Output Class Initialized
INFO - 2018-10-23 14:44:51 --> Security Class Initialized
DEBUG - 2018-10-23 14:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:44:52 --> CSRF cookie sent
INFO - 2018-10-23 14:44:52 --> Input Class Initialized
INFO - 2018-10-23 14:44:52 --> Language Class Initialized
INFO - 2018-10-23 14:44:52 --> Loader Class Initialized
INFO - 2018-10-23 14:44:52 --> Helper loaded: url_helper
INFO - 2018-10-23 14:44:52 --> Helper loaded: form_helper
INFO - 2018-10-23 14:44:52 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:44:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:44:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:44:52 --> User Agent Class Initialized
INFO - 2018-10-23 14:44:52 --> Controller Class Initialized
INFO - 2018-10-23 14:44:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:44:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:44:52 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:44:52 --> Pixel_Model class loaded
INFO - 2018-10-23 14:44:52 --> Database Driver Class Initialized
INFO - 2018-10-23 14:44:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:44:52 --> Database Driver Class Initialized
INFO - 2018-10-23 14:44:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:44:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:44:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:44:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner.php
INFO - 2018-10-23 14:44:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:44:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:44:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:44:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:44:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/relation_ship_status.php
INFO - 2018-10-23 14:44:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:44:52 --> Final output sent to browser
DEBUG - 2018-10-23 14:44:52 --> Total execution time: 0.6091
INFO - 2018-10-23 14:44:56 --> Config Class Initialized
INFO - 2018-10-23 14:44:56 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:44:56 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:44:56 --> Utf8 Class Initialized
INFO - 2018-10-23 14:44:56 --> URI Class Initialized
INFO - 2018-10-23 14:44:56 --> Router Class Initialized
INFO - 2018-10-23 14:44:56 --> Output Class Initialized
INFO - 2018-10-23 14:44:56 --> Security Class Initialized
DEBUG - 2018-10-23 14:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:44:56 --> CSRF cookie sent
INFO - 2018-10-23 14:44:56 --> CSRF token verified
INFO - 2018-10-23 14:44:56 --> Input Class Initialized
INFO - 2018-10-23 14:44:56 --> Language Class Initialized
INFO - 2018-10-23 14:44:56 --> Loader Class Initialized
INFO - 2018-10-23 14:44:56 --> Helper loaded: url_helper
INFO - 2018-10-23 14:44:56 --> Helper loaded: form_helper
INFO - 2018-10-23 14:44:56 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:44:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:44:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:44:57 --> User Agent Class Initialized
INFO - 2018-10-23 14:44:57 --> Controller Class Initialized
INFO - 2018-10-23 14:44:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:44:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:44:57 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:44:57 --> Pixel_Model class loaded
INFO - 2018-10-23 14:44:57 --> Database Driver Class Initialized
INFO - 2018-10-23 14:44:57 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:44:57 --> Form Validation Class Initialized
INFO - 2018-10-23 14:44:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:44:57 --> Database Driver Class Initialized
INFO - 2018-10-23 14:44:57 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:44:57 --> Config Class Initialized
INFO - 2018-10-23 14:44:57 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:44:57 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:44:57 --> Utf8 Class Initialized
INFO - 2018-10-23 14:44:57 --> URI Class Initialized
INFO - 2018-10-23 14:44:57 --> Router Class Initialized
INFO - 2018-10-23 14:44:57 --> Output Class Initialized
INFO - 2018-10-23 14:44:57 --> Security Class Initialized
DEBUG - 2018-10-23 14:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:44:57 --> CSRF cookie sent
INFO - 2018-10-23 14:44:57 --> Input Class Initialized
INFO - 2018-10-23 14:44:57 --> Language Class Initialized
INFO - 2018-10-23 14:44:57 --> Loader Class Initialized
INFO - 2018-10-23 14:44:57 --> Helper loaded: url_helper
INFO - 2018-10-23 14:44:57 --> Helper loaded: form_helper
INFO - 2018-10-23 14:44:57 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:44:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:44:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:44:57 --> User Agent Class Initialized
INFO - 2018-10-23 14:44:57 --> Controller Class Initialized
INFO - 2018-10-23 14:44:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:44:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:44:57 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:44:57 --> Pixel_Model class loaded
INFO - 2018-10-23 14:44:57 --> Database Driver Class Initialized
INFO - 2018-10-23 14:44:57 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:44:57 --> Database Driver Class Initialized
INFO - 2018-10-23 14:44:57 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:44:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:44:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:44:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:44:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:44:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:44:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:44:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/income.php
INFO - 2018-10-23 14:44:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:44:57 --> Final output sent to browser
DEBUG - 2018-10-23 14:44:57 --> Total execution time: 0.5737
INFO - 2018-10-23 14:44:59 --> Config Class Initialized
INFO - 2018-10-23 14:45:00 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:45:00 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:45:00 --> Utf8 Class Initialized
INFO - 2018-10-23 14:45:00 --> URI Class Initialized
INFO - 2018-10-23 14:45:00 --> Router Class Initialized
INFO - 2018-10-23 14:45:00 --> Output Class Initialized
INFO - 2018-10-23 14:45:00 --> Security Class Initialized
DEBUG - 2018-10-23 14:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:45:00 --> CSRF cookie sent
INFO - 2018-10-23 14:45:00 --> CSRF token verified
INFO - 2018-10-23 14:45:00 --> Input Class Initialized
INFO - 2018-10-23 14:45:00 --> Language Class Initialized
INFO - 2018-10-23 14:45:00 --> Loader Class Initialized
INFO - 2018-10-23 14:45:00 --> Helper loaded: url_helper
INFO - 2018-10-23 14:45:00 --> Helper loaded: form_helper
INFO - 2018-10-23 14:45:00 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:45:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:45:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:45:00 --> User Agent Class Initialized
INFO - 2018-10-23 14:45:00 --> Controller Class Initialized
INFO - 2018-10-23 14:45:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:45:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:45:00 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:45:00 --> Pixel_Model class loaded
INFO - 2018-10-23 14:45:00 --> Database Driver Class Initialized
INFO - 2018-10-23 14:45:00 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:45:00 --> Form Validation Class Initialized
INFO - 2018-10-23 14:45:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:45:00 --> Database Driver Class Initialized
INFO - 2018-10-23 14:45:00 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:45:00 --> Config Class Initialized
INFO - 2018-10-23 14:45:00 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:45:00 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:45:00 --> Utf8 Class Initialized
INFO - 2018-10-23 14:45:00 --> URI Class Initialized
INFO - 2018-10-23 14:45:00 --> Router Class Initialized
INFO - 2018-10-23 14:45:00 --> Output Class Initialized
INFO - 2018-10-23 14:45:00 --> Security Class Initialized
DEBUG - 2018-10-23 14:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:45:00 --> CSRF cookie sent
INFO - 2018-10-23 14:45:00 --> Input Class Initialized
INFO - 2018-10-23 14:45:00 --> Language Class Initialized
INFO - 2018-10-23 14:45:00 --> Loader Class Initialized
INFO - 2018-10-23 14:45:00 --> Helper loaded: url_helper
INFO - 2018-10-23 14:45:00 --> Helper loaded: form_helper
INFO - 2018-10-23 14:45:00 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:45:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:45:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:45:00 --> User Agent Class Initialized
INFO - 2018-10-23 14:45:00 --> Controller Class Initialized
INFO - 2018-10-23 14:45:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:45:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:45:00 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:45:00 --> Pixel_Model class loaded
INFO - 2018-10-23 14:45:00 --> Database Driver Class Initialized
INFO - 2018-10-23 14:45:00 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:45:01 --> Database Driver Class Initialized
INFO - 2018-10-23 14:45:01 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:45:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:45:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:45:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:45:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:45:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:45:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:45:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/cohabitation.php
INFO - 2018-10-23 14:45:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:45:01 --> Final output sent to browser
DEBUG - 2018-10-23 14:45:01 --> Total execution time: 0.6296
INFO - 2018-10-23 14:45:04 --> Config Class Initialized
INFO - 2018-10-23 14:45:04 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:45:04 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:45:05 --> Utf8 Class Initialized
INFO - 2018-10-23 14:45:05 --> URI Class Initialized
INFO - 2018-10-23 14:45:05 --> Router Class Initialized
INFO - 2018-10-23 14:45:05 --> Output Class Initialized
INFO - 2018-10-23 14:45:05 --> Security Class Initialized
DEBUG - 2018-10-23 14:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:45:05 --> CSRF cookie sent
INFO - 2018-10-23 14:45:05 --> Input Class Initialized
INFO - 2018-10-23 14:45:05 --> Language Class Initialized
INFO - 2018-10-23 14:45:05 --> Loader Class Initialized
INFO - 2018-10-23 14:45:05 --> Helper loaded: url_helper
INFO - 2018-10-23 14:45:05 --> Helper loaded: form_helper
INFO - 2018-10-23 14:45:05 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:45:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:45:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:45:05 --> User Agent Class Initialized
INFO - 2018-10-23 14:45:05 --> Controller Class Initialized
INFO - 2018-10-23 14:45:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:45:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:45:05 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:45:05 --> Pixel_Model class loaded
INFO - 2018-10-23 14:45:05 --> Database Driver Class Initialized
INFO - 2018-10-23 14:45:05 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:45:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:45:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:45:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:45:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:45:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:45:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:45:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-23 14:45:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:45:05 --> Final output sent to browser
DEBUG - 2018-10-23 14:45:05 --> Total execution time: 0.5578
INFO - 2018-10-23 14:45:07 --> Config Class Initialized
INFO - 2018-10-23 14:45:07 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:45:07 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:45:07 --> Utf8 Class Initialized
INFO - 2018-10-23 14:45:07 --> URI Class Initialized
INFO - 2018-10-23 14:45:07 --> Router Class Initialized
INFO - 2018-10-23 14:45:07 --> Output Class Initialized
INFO - 2018-10-23 14:45:07 --> Security Class Initialized
DEBUG - 2018-10-23 14:45:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:45:07 --> CSRF cookie sent
INFO - 2018-10-23 14:45:07 --> Input Class Initialized
INFO - 2018-10-23 14:45:07 --> Language Class Initialized
INFO - 2018-10-23 14:45:07 --> Loader Class Initialized
INFO - 2018-10-23 14:45:07 --> Helper loaded: url_helper
INFO - 2018-10-23 14:45:07 --> Helper loaded: form_helper
INFO - 2018-10-23 14:45:07 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:45:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:45:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:45:07 --> User Agent Class Initialized
INFO - 2018-10-23 14:45:07 --> Controller Class Initialized
INFO - 2018-10-23 14:45:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:45:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:45:07 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:45:07 --> Pixel_Model class loaded
INFO - 2018-10-23 14:45:07 --> Database Driver Class Initialized
INFO - 2018-10-23 14:45:07 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:45:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:45:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:45:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:45:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:45:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:45:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:45:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-23 14:45:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:45:07 --> Final output sent to browser
DEBUG - 2018-10-23 14:45:07 --> Total execution time: 0.5759
INFO - 2018-10-23 14:45:23 --> Config Class Initialized
INFO - 2018-10-23 14:45:23 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:45:23 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:45:23 --> Utf8 Class Initialized
INFO - 2018-10-23 14:45:23 --> URI Class Initialized
INFO - 2018-10-23 14:45:23 --> Router Class Initialized
INFO - 2018-10-23 14:45:23 --> Output Class Initialized
INFO - 2018-10-23 14:45:23 --> Security Class Initialized
DEBUG - 2018-10-23 14:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:45:23 --> CSRF cookie sent
INFO - 2018-10-23 14:45:23 --> CSRF token verified
INFO - 2018-10-23 14:45:23 --> Input Class Initialized
INFO - 2018-10-23 14:45:23 --> Language Class Initialized
INFO - 2018-10-23 14:45:23 --> Loader Class Initialized
INFO - 2018-10-23 14:45:23 --> Helper loaded: url_helper
INFO - 2018-10-23 14:45:23 --> Helper loaded: form_helper
INFO - 2018-10-23 14:45:23 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:45:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:45:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:45:23 --> User Agent Class Initialized
INFO - 2018-10-23 14:45:23 --> Controller Class Initialized
INFO - 2018-10-23 14:45:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:45:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:45:23 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:45:23 --> Pixel_Model class loaded
INFO - 2018-10-23 14:45:23 --> Database Driver Class Initialized
INFO - 2018-10-23 14:45:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:45:23 --> Form Validation Class Initialized
INFO - 2018-10-23 14:45:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:45:23 --> Database Driver Class Initialized
INFO - 2018-10-23 14:45:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:45:23 --> Config Class Initialized
INFO - 2018-10-23 14:45:23 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:45:23 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:45:23 --> Utf8 Class Initialized
INFO - 2018-10-23 14:45:23 --> URI Class Initialized
INFO - 2018-10-23 14:45:23 --> Router Class Initialized
INFO - 2018-10-23 14:45:23 --> Output Class Initialized
INFO - 2018-10-23 14:45:23 --> Security Class Initialized
DEBUG - 2018-10-23 14:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:45:23 --> CSRF cookie sent
INFO - 2018-10-23 14:45:23 --> Input Class Initialized
INFO - 2018-10-23 14:45:23 --> Language Class Initialized
INFO - 2018-10-23 14:45:23 --> Loader Class Initialized
INFO - 2018-10-23 14:45:23 --> Helper loaded: url_helper
INFO - 2018-10-23 14:45:23 --> Helper loaded: form_helper
INFO - 2018-10-23 14:45:23 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:45:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:45:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:45:23 --> User Agent Class Initialized
INFO - 2018-10-23 14:45:23 --> Controller Class Initialized
INFO - 2018-10-23 14:45:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:45:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:45:23 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:45:23 --> Pixel_Model class loaded
INFO - 2018-10-23 14:45:23 --> Database Driver Class Initialized
INFO - 2018-10-23 14:45:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:45:24 --> Database Driver Class Initialized
INFO - 2018-10-23 14:45:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:45:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:45:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:45:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:45:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:45:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:45:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:45:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-23 14:45:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:45:24 --> Final output sent to browser
DEBUG - 2018-10-23 14:45:24 --> Total execution time: 0.5831
INFO - 2018-10-23 14:45:26 --> Config Class Initialized
INFO - 2018-10-23 14:45:26 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:45:26 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:45:26 --> Utf8 Class Initialized
INFO - 2018-10-23 14:45:26 --> URI Class Initialized
INFO - 2018-10-23 14:45:26 --> Router Class Initialized
INFO - 2018-10-23 14:45:26 --> Output Class Initialized
INFO - 2018-10-23 14:45:26 --> Security Class Initialized
DEBUG - 2018-10-23 14:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:45:26 --> CSRF cookie sent
INFO - 2018-10-23 14:45:26 --> CSRF token verified
INFO - 2018-10-23 14:45:26 --> Input Class Initialized
INFO - 2018-10-23 14:45:26 --> Language Class Initialized
INFO - 2018-10-23 14:45:26 --> Loader Class Initialized
INFO - 2018-10-23 14:45:26 --> Helper loaded: url_helper
INFO - 2018-10-23 14:45:26 --> Helper loaded: form_helper
INFO - 2018-10-23 14:45:26 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:45:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:45:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:45:26 --> User Agent Class Initialized
INFO - 2018-10-23 14:45:26 --> Controller Class Initialized
INFO - 2018-10-23 14:45:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:45:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:45:27 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:45:27 --> Pixel_Model class loaded
INFO - 2018-10-23 14:45:27 --> Database Driver Class Initialized
INFO - 2018-10-23 14:45:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:45:27 --> Form Validation Class Initialized
INFO - 2018-10-23 14:45:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:45:27 --> Database Driver Class Initialized
INFO - 2018-10-23 14:45:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:45:27 --> Config Class Initialized
INFO - 2018-10-23 14:45:27 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:45:27 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:45:27 --> Utf8 Class Initialized
INFO - 2018-10-23 14:45:27 --> URI Class Initialized
INFO - 2018-10-23 14:45:27 --> Router Class Initialized
INFO - 2018-10-23 14:45:27 --> Output Class Initialized
INFO - 2018-10-23 14:45:27 --> Security Class Initialized
DEBUG - 2018-10-23 14:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:45:27 --> CSRF cookie sent
INFO - 2018-10-23 14:45:27 --> Input Class Initialized
INFO - 2018-10-23 14:45:27 --> Language Class Initialized
INFO - 2018-10-23 14:45:27 --> Loader Class Initialized
INFO - 2018-10-23 14:45:27 --> Helper loaded: url_helper
INFO - 2018-10-23 14:45:27 --> Helper loaded: form_helper
INFO - 2018-10-23 14:45:27 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:45:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:45:27 --> User Agent Class Initialized
INFO - 2018-10-23 14:45:27 --> Controller Class Initialized
INFO - 2018-10-23 14:45:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:45:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:45:27 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:45:27 --> Pixel_Model class loaded
INFO - 2018-10-23 14:45:27 --> Database Driver Class Initialized
INFO - 2018-10-23 14:45:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:45:27 --> Database Driver Class Initialized
INFO - 2018-10-23 14:45:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:45:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:45:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:45:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:45:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:45:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:45:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:45:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/your_job.php
INFO - 2018-10-23 14:45:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:45:27 --> Final output sent to browser
DEBUG - 2018-10-23 14:45:27 --> Total execution time: 0.5954
INFO - 2018-10-23 14:45:29 --> Config Class Initialized
INFO - 2018-10-23 14:45:29 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:45:29 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:45:29 --> Utf8 Class Initialized
INFO - 2018-10-23 14:45:29 --> URI Class Initialized
INFO - 2018-10-23 14:45:29 --> Router Class Initialized
INFO - 2018-10-23 14:45:29 --> Output Class Initialized
INFO - 2018-10-23 14:45:29 --> Security Class Initialized
DEBUG - 2018-10-23 14:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:45:29 --> CSRF cookie sent
INFO - 2018-10-23 14:45:29 --> CSRF token verified
INFO - 2018-10-23 14:45:29 --> Input Class Initialized
INFO - 2018-10-23 14:45:29 --> Language Class Initialized
INFO - 2018-10-23 14:45:29 --> Loader Class Initialized
INFO - 2018-10-23 14:45:29 --> Helper loaded: url_helper
INFO - 2018-10-23 14:45:29 --> Helper loaded: form_helper
INFO - 2018-10-23 14:45:29 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:45:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:45:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:45:29 --> User Agent Class Initialized
INFO - 2018-10-23 14:45:29 --> Controller Class Initialized
INFO - 2018-10-23 14:45:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:45:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:45:29 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:45:29 --> Pixel_Model class loaded
INFO - 2018-10-23 14:45:29 --> Database Driver Class Initialized
INFO - 2018-10-23 14:45:29 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:45:29 --> Form Validation Class Initialized
INFO - 2018-10-23 14:45:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:45:30 --> Database Driver Class Initialized
INFO - 2018-10-23 14:45:30 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:45:30 --> Config Class Initialized
INFO - 2018-10-23 14:45:30 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:45:30 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:45:30 --> Utf8 Class Initialized
INFO - 2018-10-23 14:45:30 --> URI Class Initialized
INFO - 2018-10-23 14:45:30 --> Router Class Initialized
INFO - 2018-10-23 14:45:30 --> Output Class Initialized
INFO - 2018-10-23 14:45:30 --> Security Class Initialized
DEBUG - 2018-10-23 14:45:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:45:30 --> CSRF cookie sent
INFO - 2018-10-23 14:45:30 --> Input Class Initialized
INFO - 2018-10-23 14:45:30 --> Language Class Initialized
INFO - 2018-10-23 14:45:30 --> Loader Class Initialized
INFO - 2018-10-23 14:45:30 --> Helper loaded: url_helper
INFO - 2018-10-23 14:45:30 --> Helper loaded: form_helper
INFO - 2018-10-23 14:45:30 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:45:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:45:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:45:30 --> User Agent Class Initialized
INFO - 2018-10-23 14:45:30 --> Controller Class Initialized
INFO - 2018-10-23 14:45:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:45:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:45:30 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:45:30 --> Pixel_Model class loaded
INFO - 2018-10-23 14:45:30 --> Database Driver Class Initialized
INFO - 2018-10-23 14:45:30 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:45:30 --> Database Driver Class Initialized
INFO - 2018-10-23 14:45:30 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:45:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:45:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:45:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner.php
INFO - 2018-10-23 14:45:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:45:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:45:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:45:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:45:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/relation_ship_status.php
INFO - 2018-10-23 14:45:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:45:30 --> Final output sent to browser
DEBUG - 2018-10-23 14:45:30 --> Total execution time: 0.6066
INFO - 2018-10-23 14:45:33 --> Config Class Initialized
INFO - 2018-10-23 14:45:33 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:45:34 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:45:34 --> Utf8 Class Initialized
INFO - 2018-10-23 14:45:34 --> URI Class Initialized
INFO - 2018-10-23 14:45:34 --> Router Class Initialized
INFO - 2018-10-23 14:45:34 --> Output Class Initialized
INFO - 2018-10-23 14:45:34 --> Security Class Initialized
DEBUG - 2018-10-23 14:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:45:34 --> CSRF cookie sent
INFO - 2018-10-23 14:45:34 --> CSRF token verified
INFO - 2018-10-23 14:45:34 --> Input Class Initialized
INFO - 2018-10-23 14:45:34 --> Language Class Initialized
INFO - 2018-10-23 14:45:34 --> Loader Class Initialized
INFO - 2018-10-23 14:45:34 --> Helper loaded: url_helper
INFO - 2018-10-23 14:45:34 --> Helper loaded: form_helper
INFO - 2018-10-23 14:45:34 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:45:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:45:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:45:34 --> User Agent Class Initialized
INFO - 2018-10-23 14:45:34 --> Controller Class Initialized
INFO - 2018-10-23 14:45:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:45:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:45:34 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:45:34 --> Pixel_Model class loaded
INFO - 2018-10-23 14:45:34 --> Database Driver Class Initialized
INFO - 2018-10-23 14:45:34 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:45:34 --> Form Validation Class Initialized
INFO - 2018-10-23 14:45:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:45:34 --> Database Driver Class Initialized
INFO - 2018-10-23 14:45:34 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:45:34 --> Config Class Initialized
INFO - 2018-10-23 14:45:34 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:45:34 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:45:34 --> Utf8 Class Initialized
INFO - 2018-10-23 14:45:34 --> URI Class Initialized
INFO - 2018-10-23 14:45:34 --> Router Class Initialized
INFO - 2018-10-23 14:45:34 --> Output Class Initialized
INFO - 2018-10-23 14:45:34 --> Security Class Initialized
DEBUG - 2018-10-23 14:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:45:34 --> CSRF cookie sent
INFO - 2018-10-23 14:45:34 --> Input Class Initialized
INFO - 2018-10-23 14:45:34 --> Language Class Initialized
INFO - 2018-10-23 14:45:34 --> Loader Class Initialized
INFO - 2018-10-23 14:45:34 --> Helper loaded: url_helper
INFO - 2018-10-23 14:45:34 --> Helper loaded: form_helper
INFO - 2018-10-23 14:45:34 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:45:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:45:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:45:34 --> User Agent Class Initialized
INFO - 2018-10-23 14:45:34 --> Controller Class Initialized
INFO - 2018-10-23 14:45:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:45:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:45:34 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:45:34 --> Pixel_Model class loaded
INFO - 2018-10-23 14:45:34 --> Database Driver Class Initialized
INFO - 2018-10-23 14:45:34 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:45:34 --> Database Driver Class Initialized
INFO - 2018-10-23 14:45:34 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:45:34 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:45:34 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:45:34 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:45:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:45:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:45:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:45:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/income.php
INFO - 2018-10-23 14:45:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:45:35 --> Final output sent to browser
DEBUG - 2018-10-23 14:45:35 --> Total execution time: 0.5649
INFO - 2018-10-23 14:45:38 --> Config Class Initialized
INFO - 2018-10-23 14:45:38 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:45:38 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:45:38 --> Utf8 Class Initialized
INFO - 2018-10-23 14:45:38 --> URI Class Initialized
INFO - 2018-10-23 14:45:38 --> Router Class Initialized
INFO - 2018-10-23 14:45:38 --> Output Class Initialized
INFO - 2018-10-23 14:45:38 --> Security Class Initialized
DEBUG - 2018-10-23 14:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:45:38 --> CSRF cookie sent
INFO - 2018-10-23 14:45:38 --> CSRF token verified
INFO - 2018-10-23 14:45:38 --> Input Class Initialized
INFO - 2018-10-23 14:45:38 --> Language Class Initialized
INFO - 2018-10-23 14:45:38 --> Loader Class Initialized
INFO - 2018-10-23 14:45:38 --> Helper loaded: url_helper
INFO - 2018-10-23 14:45:38 --> Helper loaded: form_helper
INFO - 2018-10-23 14:45:38 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:45:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:45:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:45:38 --> User Agent Class Initialized
INFO - 2018-10-23 14:45:38 --> Controller Class Initialized
INFO - 2018-10-23 14:45:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:45:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:45:39 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:45:39 --> Pixel_Model class loaded
INFO - 2018-10-23 14:45:39 --> Database Driver Class Initialized
INFO - 2018-10-23 14:45:39 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:45:39 --> Form Validation Class Initialized
INFO - 2018-10-23 14:45:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:45:39 --> Database Driver Class Initialized
INFO - 2018-10-23 14:45:39 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:45:39 --> Config Class Initialized
INFO - 2018-10-23 14:45:39 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:45:39 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:45:39 --> Utf8 Class Initialized
INFO - 2018-10-23 14:45:39 --> URI Class Initialized
INFO - 2018-10-23 14:45:39 --> Router Class Initialized
INFO - 2018-10-23 14:45:39 --> Output Class Initialized
INFO - 2018-10-23 14:45:39 --> Security Class Initialized
DEBUG - 2018-10-23 14:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:45:39 --> CSRF cookie sent
INFO - 2018-10-23 14:45:39 --> Input Class Initialized
INFO - 2018-10-23 14:45:39 --> Language Class Initialized
INFO - 2018-10-23 14:45:39 --> Loader Class Initialized
INFO - 2018-10-23 14:45:39 --> Helper loaded: url_helper
INFO - 2018-10-23 14:45:39 --> Helper loaded: form_helper
INFO - 2018-10-23 14:45:39 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:45:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:45:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:45:39 --> User Agent Class Initialized
INFO - 2018-10-23 14:45:39 --> Controller Class Initialized
INFO - 2018-10-23 14:45:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:45:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:45:39 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:45:39 --> Pixel_Model class loaded
INFO - 2018-10-23 14:45:39 --> Database Driver Class Initialized
INFO - 2018-10-23 14:45:39 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:45:39 --> Database Driver Class Initialized
INFO - 2018-10-23 14:45:39 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:45:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:45:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:45:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:45:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:45:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:45:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:45:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/cohabitation.php
INFO - 2018-10-23 14:45:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:45:39 --> Final output sent to browser
DEBUG - 2018-10-23 14:45:39 --> Total execution time: 0.5758
INFO - 2018-10-23 14:45:43 --> Config Class Initialized
INFO - 2018-10-23 14:45:43 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:45:43 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:45:43 --> Utf8 Class Initialized
INFO - 2018-10-23 14:45:43 --> URI Class Initialized
INFO - 2018-10-23 14:45:43 --> Router Class Initialized
INFO - 2018-10-23 14:45:43 --> Output Class Initialized
INFO - 2018-10-23 14:45:43 --> Security Class Initialized
DEBUG - 2018-10-23 14:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:45:43 --> CSRF cookie sent
INFO - 2018-10-23 14:45:43 --> CSRF token verified
INFO - 2018-10-23 14:45:43 --> Input Class Initialized
INFO - 2018-10-23 14:45:43 --> Language Class Initialized
INFO - 2018-10-23 14:45:43 --> Loader Class Initialized
INFO - 2018-10-23 14:45:43 --> Helper loaded: url_helper
INFO - 2018-10-23 14:45:43 --> Helper loaded: form_helper
INFO - 2018-10-23 14:45:43 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:45:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:45:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:45:44 --> User Agent Class Initialized
INFO - 2018-10-23 14:45:44 --> Controller Class Initialized
INFO - 2018-10-23 14:45:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:45:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:45:44 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:45:44 --> Pixel_Model class loaded
INFO - 2018-10-23 14:45:44 --> Database Driver Class Initialized
INFO - 2018-10-23 14:45:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:45:44 --> Form Validation Class Initialized
INFO - 2018-10-23 14:45:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:45:44 --> Database Driver Class Initialized
INFO - 2018-10-23 14:45:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:45:44 --> Config Class Initialized
INFO - 2018-10-23 14:45:44 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:45:44 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:45:44 --> Utf8 Class Initialized
INFO - 2018-10-23 14:45:44 --> URI Class Initialized
INFO - 2018-10-23 14:45:44 --> Router Class Initialized
INFO - 2018-10-23 14:45:44 --> Output Class Initialized
INFO - 2018-10-23 14:45:44 --> Security Class Initialized
DEBUG - 2018-10-23 14:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:45:44 --> CSRF cookie sent
INFO - 2018-10-23 14:45:44 --> Input Class Initialized
INFO - 2018-10-23 14:45:44 --> Language Class Initialized
INFO - 2018-10-23 14:45:44 --> Loader Class Initialized
INFO - 2018-10-23 14:45:44 --> Helper loaded: url_helper
INFO - 2018-10-23 14:45:44 --> Helper loaded: form_helper
INFO - 2018-10-23 14:45:44 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:45:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:45:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:45:44 --> User Agent Class Initialized
INFO - 2018-10-23 14:45:44 --> Controller Class Initialized
INFO - 2018-10-23 14:45:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:45:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:45:44 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:45:44 --> Pixel_Model class loaded
INFO - 2018-10-23 14:45:44 --> Database Driver Class Initialized
INFO - 2018-10-23 14:45:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:45:44 --> Database Driver Class Initialized
INFO - 2018-10-23 14:45:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:45:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:45:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:45:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:45:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:45:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:45:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:45:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/kids.php
INFO - 2018-10-23 14:45:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:45:44 --> Final output sent to browser
DEBUG - 2018-10-23 14:45:44 --> Total execution time: 0.5772
INFO - 2018-10-23 14:45:47 --> Config Class Initialized
INFO - 2018-10-23 14:45:47 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:45:47 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:45:47 --> Utf8 Class Initialized
INFO - 2018-10-23 14:45:47 --> URI Class Initialized
INFO - 2018-10-23 14:45:47 --> Router Class Initialized
INFO - 2018-10-23 14:45:47 --> Output Class Initialized
INFO - 2018-10-23 14:45:47 --> Security Class Initialized
DEBUG - 2018-10-23 14:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:45:47 --> CSRF cookie sent
INFO - 2018-10-23 14:45:47 --> CSRF token verified
INFO - 2018-10-23 14:45:47 --> Input Class Initialized
INFO - 2018-10-23 14:45:47 --> Language Class Initialized
INFO - 2018-10-23 14:45:47 --> Loader Class Initialized
INFO - 2018-10-23 14:45:47 --> Helper loaded: url_helper
INFO - 2018-10-23 14:45:47 --> Helper loaded: form_helper
INFO - 2018-10-23 14:45:48 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:45:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:45:48 --> User Agent Class Initialized
INFO - 2018-10-23 14:45:48 --> Controller Class Initialized
INFO - 2018-10-23 14:45:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:45:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:45:48 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:45:48 --> Pixel_Model class loaded
INFO - 2018-10-23 14:45:48 --> Database Driver Class Initialized
INFO - 2018-10-23 14:45:48 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:45:48 --> Form Validation Class Initialized
INFO - 2018-10-23 14:45:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:45:48 --> Database Driver Class Initialized
INFO - 2018-10-23 14:45:48 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:45:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:45:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:45:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:45:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:45:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:45:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_errors.php
INFO - 2018-10-23 14:45:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:45:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/kids.php
INFO - 2018-10-23 14:45:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:45:48 --> Final output sent to browser
DEBUG - 2018-10-23 14:45:48 --> Total execution time: 0.6691
INFO - 2018-10-23 14:45:52 --> Config Class Initialized
INFO - 2018-10-23 14:45:52 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:45:52 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:45:52 --> Utf8 Class Initialized
INFO - 2018-10-23 14:45:52 --> URI Class Initialized
INFO - 2018-10-23 14:45:52 --> Router Class Initialized
INFO - 2018-10-23 14:45:52 --> Output Class Initialized
INFO - 2018-10-23 14:45:52 --> Security Class Initialized
DEBUG - 2018-10-23 14:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:45:52 --> CSRF cookie sent
INFO - 2018-10-23 14:45:52 --> CSRF token verified
INFO - 2018-10-23 14:45:52 --> Input Class Initialized
INFO - 2018-10-23 14:45:52 --> Language Class Initialized
INFO - 2018-10-23 14:45:52 --> Loader Class Initialized
INFO - 2018-10-23 14:45:52 --> Helper loaded: url_helper
INFO - 2018-10-23 14:45:52 --> Helper loaded: form_helper
INFO - 2018-10-23 14:45:52 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:45:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:45:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:45:52 --> User Agent Class Initialized
INFO - 2018-10-23 14:45:52 --> Controller Class Initialized
INFO - 2018-10-23 14:45:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:45:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:45:53 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:45:53 --> Pixel_Model class loaded
INFO - 2018-10-23 14:45:53 --> Database Driver Class Initialized
INFO - 2018-10-23 14:45:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:45:53 --> Form Validation Class Initialized
INFO - 2018-10-23 14:45:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:45:53 --> Database Driver Class Initialized
INFO - 2018-10-23 14:45:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:45:53 --> Config Class Initialized
INFO - 2018-10-23 14:45:53 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:45:53 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:45:53 --> Utf8 Class Initialized
INFO - 2018-10-23 14:45:53 --> URI Class Initialized
INFO - 2018-10-23 14:45:53 --> Router Class Initialized
INFO - 2018-10-23 14:45:53 --> Output Class Initialized
INFO - 2018-10-23 14:45:53 --> Security Class Initialized
DEBUG - 2018-10-23 14:45:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:45:53 --> CSRF cookie sent
INFO - 2018-10-23 14:45:53 --> Input Class Initialized
INFO - 2018-10-23 14:45:53 --> Language Class Initialized
INFO - 2018-10-23 14:45:53 --> Loader Class Initialized
INFO - 2018-10-23 14:45:53 --> Helper loaded: url_helper
INFO - 2018-10-23 14:45:53 --> Helper loaded: form_helper
INFO - 2018-10-23 14:45:53 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:45:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:45:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:45:53 --> User Agent Class Initialized
INFO - 2018-10-23 14:45:53 --> Controller Class Initialized
INFO - 2018-10-23 14:45:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:45:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:45:53 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:45:53 --> Pixel_Model class loaded
INFO - 2018-10-23 14:45:53 --> Database Driver Class Initialized
INFO - 2018-10-23 14:45:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:45:53 --> Database Driver Class Initialized
INFO - 2018-10-23 14:45:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:45:53 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:45:53 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:45:53 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:45:53 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:45:53 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:45:53 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:45:53 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/pension.php
INFO - 2018-10-23 14:45:53 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:45:53 --> Final output sent to browser
DEBUG - 2018-10-23 14:45:53 --> Total execution time: 0.6165
INFO - 2018-10-23 14:45:56 --> Config Class Initialized
INFO - 2018-10-23 14:45:56 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:45:56 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:45:56 --> Utf8 Class Initialized
INFO - 2018-10-23 14:45:56 --> URI Class Initialized
INFO - 2018-10-23 14:45:56 --> Router Class Initialized
INFO - 2018-10-23 14:45:56 --> Output Class Initialized
INFO - 2018-10-23 14:45:56 --> Security Class Initialized
DEBUG - 2018-10-23 14:45:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:45:56 --> CSRF cookie sent
INFO - 2018-10-23 14:45:56 --> CSRF token verified
INFO - 2018-10-23 14:45:56 --> Input Class Initialized
INFO - 2018-10-23 14:45:56 --> Language Class Initialized
INFO - 2018-10-23 14:45:56 --> Loader Class Initialized
INFO - 2018-10-23 14:45:56 --> Helper loaded: url_helper
INFO - 2018-10-23 14:45:56 --> Helper loaded: form_helper
INFO - 2018-10-23 14:45:56 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:45:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:45:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:45:56 --> User Agent Class Initialized
INFO - 2018-10-23 14:45:56 --> Controller Class Initialized
INFO - 2018-10-23 14:45:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:45:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:45:56 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:45:56 --> Pixel_Model class loaded
INFO - 2018-10-23 14:45:56 --> Database Driver Class Initialized
INFO - 2018-10-23 14:45:56 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:45:56 --> Form Validation Class Initialized
INFO - 2018-10-23 14:45:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:45:56 --> Database Driver Class Initialized
INFO - 2018-10-23 14:45:56 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:45:56 --> Config Class Initialized
INFO - 2018-10-23 14:45:56 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:45:56 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:45:56 --> Utf8 Class Initialized
INFO - 2018-10-23 14:45:56 --> URI Class Initialized
INFO - 2018-10-23 14:45:56 --> Router Class Initialized
INFO - 2018-10-23 14:45:56 --> Output Class Initialized
INFO - 2018-10-23 14:45:56 --> Security Class Initialized
DEBUG - 2018-10-23 14:45:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:45:56 --> CSRF cookie sent
INFO - 2018-10-23 14:45:57 --> Input Class Initialized
INFO - 2018-10-23 14:45:57 --> Language Class Initialized
INFO - 2018-10-23 14:45:57 --> Loader Class Initialized
INFO - 2018-10-23 14:45:57 --> Helper loaded: url_helper
INFO - 2018-10-23 14:45:57 --> Helper loaded: form_helper
INFO - 2018-10-23 14:45:57 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:45:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:45:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:45:57 --> User Agent Class Initialized
INFO - 2018-10-23 14:45:57 --> Controller Class Initialized
INFO - 2018-10-23 14:45:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:45:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:45:57 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:45:57 --> Pixel_Model class loaded
INFO - 2018-10-23 14:45:57 --> Database Driver Class Initialized
INFO - 2018-10-23 14:45:57 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:45:57 --> Database Driver Class Initialized
INFO - 2018-10-23 14:45:57 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:45:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:45:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:45:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:45:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:45:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:45:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:45:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/inheritance.php
INFO - 2018-10-23 14:45:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:45:57 --> Final output sent to browser
DEBUG - 2018-10-23 14:45:57 --> Total execution time: 0.6900
INFO - 2018-10-23 14:45:59 --> Config Class Initialized
INFO - 2018-10-23 14:45:59 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:45:59 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:45:59 --> Utf8 Class Initialized
INFO - 2018-10-23 14:46:00 --> URI Class Initialized
INFO - 2018-10-23 14:46:00 --> Router Class Initialized
INFO - 2018-10-23 14:46:00 --> Output Class Initialized
INFO - 2018-10-23 14:46:00 --> Security Class Initialized
DEBUG - 2018-10-23 14:46:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:46:00 --> CSRF cookie sent
INFO - 2018-10-23 14:46:00 --> Input Class Initialized
INFO - 2018-10-23 14:46:00 --> Language Class Initialized
INFO - 2018-10-23 14:46:00 --> Loader Class Initialized
INFO - 2018-10-23 14:46:00 --> Helper loaded: url_helper
INFO - 2018-10-23 14:46:00 --> Helper loaded: form_helper
INFO - 2018-10-23 14:46:00 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:46:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:46:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:46:00 --> User Agent Class Initialized
INFO - 2018-10-23 14:46:00 --> Controller Class Initialized
INFO - 2018-10-23 14:46:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:46:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:46:00 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:46:00 --> Pixel_Model class loaded
INFO - 2018-10-23 14:46:00 --> Database Driver Class Initialized
INFO - 2018-10-23 14:46:00 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:46:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:46:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:46:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:46:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:46:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:46:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:46:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-23 14:46:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:46:00 --> Final output sent to browser
DEBUG - 2018-10-23 14:46:00 --> Total execution time: 0.5958
INFO - 2018-10-23 14:46:12 --> Config Class Initialized
INFO - 2018-10-23 14:46:12 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:46:12 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:46:12 --> Utf8 Class Initialized
INFO - 2018-10-23 14:46:12 --> URI Class Initialized
INFO - 2018-10-23 14:46:12 --> Router Class Initialized
INFO - 2018-10-23 14:46:12 --> Output Class Initialized
INFO - 2018-10-23 14:46:12 --> Security Class Initialized
DEBUG - 2018-10-23 14:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:46:12 --> CSRF cookie sent
INFO - 2018-10-23 14:46:12 --> CSRF token verified
INFO - 2018-10-23 14:46:12 --> Input Class Initialized
INFO - 2018-10-23 14:46:12 --> Language Class Initialized
INFO - 2018-10-23 14:46:12 --> Loader Class Initialized
INFO - 2018-10-23 14:46:12 --> Helper loaded: url_helper
INFO - 2018-10-23 14:46:12 --> Helper loaded: form_helper
INFO - 2018-10-23 14:46:12 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:46:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:46:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:46:12 --> User Agent Class Initialized
INFO - 2018-10-23 14:46:12 --> Controller Class Initialized
INFO - 2018-10-23 14:46:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:46:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:46:12 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:46:12 --> Pixel_Model class loaded
INFO - 2018-10-23 14:46:12 --> Database Driver Class Initialized
INFO - 2018-10-23 14:46:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:46:12 --> Form Validation Class Initialized
INFO - 2018-10-23 14:46:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:46:12 --> Database Driver Class Initialized
INFO - 2018-10-23 14:46:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:46:13 --> Config Class Initialized
INFO - 2018-10-23 14:46:13 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:46:13 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:46:13 --> Utf8 Class Initialized
INFO - 2018-10-23 14:46:13 --> URI Class Initialized
INFO - 2018-10-23 14:46:13 --> Router Class Initialized
INFO - 2018-10-23 14:46:13 --> Output Class Initialized
INFO - 2018-10-23 14:46:13 --> Security Class Initialized
DEBUG - 2018-10-23 14:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:46:13 --> CSRF cookie sent
INFO - 2018-10-23 14:46:13 --> Input Class Initialized
INFO - 2018-10-23 14:46:13 --> Language Class Initialized
INFO - 2018-10-23 14:46:13 --> Loader Class Initialized
INFO - 2018-10-23 14:46:13 --> Helper loaded: url_helper
INFO - 2018-10-23 14:46:13 --> Helper loaded: form_helper
INFO - 2018-10-23 14:46:13 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:46:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:46:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:46:13 --> User Agent Class Initialized
INFO - 2018-10-23 14:46:13 --> Controller Class Initialized
INFO - 2018-10-23 14:46:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:46:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:46:13 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:46:13 --> Pixel_Model class loaded
INFO - 2018-10-23 14:46:13 --> Database Driver Class Initialized
INFO - 2018-10-23 14:46:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:46:13 --> Database Driver Class Initialized
INFO - 2018-10-23 14:46:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:46:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:46:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:46:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:46:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:46:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:46:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:46:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-23 14:46:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:46:13 --> Final output sent to browser
DEBUG - 2018-10-23 14:46:13 --> Total execution time: 0.5794
INFO - 2018-10-23 14:46:16 --> Config Class Initialized
INFO - 2018-10-23 14:46:16 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:46:16 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:46:16 --> Utf8 Class Initialized
INFO - 2018-10-23 14:46:16 --> URI Class Initialized
INFO - 2018-10-23 14:46:16 --> Router Class Initialized
INFO - 2018-10-23 14:46:16 --> Output Class Initialized
INFO - 2018-10-23 14:46:16 --> Security Class Initialized
DEBUG - 2018-10-23 14:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:46:16 --> CSRF cookie sent
INFO - 2018-10-23 14:46:16 --> CSRF token verified
INFO - 2018-10-23 14:46:16 --> Input Class Initialized
INFO - 2018-10-23 14:46:16 --> Language Class Initialized
INFO - 2018-10-23 14:46:16 --> Loader Class Initialized
INFO - 2018-10-23 14:46:16 --> Helper loaded: url_helper
INFO - 2018-10-23 14:46:16 --> Helper loaded: form_helper
INFO - 2018-10-23 14:46:16 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:46:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:46:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:46:16 --> User Agent Class Initialized
INFO - 2018-10-23 14:46:16 --> Controller Class Initialized
INFO - 2018-10-23 14:46:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:46:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:46:16 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:46:16 --> Pixel_Model class loaded
INFO - 2018-10-23 14:46:16 --> Database Driver Class Initialized
INFO - 2018-10-23 14:46:16 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:46:16 --> Form Validation Class Initialized
INFO - 2018-10-23 14:46:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:46:16 --> Database Driver Class Initialized
INFO - 2018-10-23 14:46:16 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:46:17 --> Config Class Initialized
INFO - 2018-10-23 14:46:17 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:46:17 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:46:17 --> Utf8 Class Initialized
INFO - 2018-10-23 14:46:17 --> URI Class Initialized
INFO - 2018-10-23 14:46:17 --> Router Class Initialized
INFO - 2018-10-23 14:46:17 --> Output Class Initialized
INFO - 2018-10-23 14:46:17 --> Security Class Initialized
DEBUG - 2018-10-23 14:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:46:17 --> CSRF cookie sent
INFO - 2018-10-23 14:46:17 --> Input Class Initialized
INFO - 2018-10-23 14:46:17 --> Language Class Initialized
INFO - 2018-10-23 14:46:17 --> Loader Class Initialized
INFO - 2018-10-23 14:46:17 --> Helper loaded: url_helper
INFO - 2018-10-23 14:46:17 --> Helper loaded: form_helper
INFO - 2018-10-23 14:46:17 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:46:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:46:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:46:17 --> User Agent Class Initialized
INFO - 2018-10-23 14:46:17 --> Controller Class Initialized
INFO - 2018-10-23 14:46:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:46:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:46:17 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:46:17 --> Pixel_Model class loaded
INFO - 2018-10-23 14:46:17 --> Database Driver Class Initialized
INFO - 2018-10-23 14:46:17 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:46:17 --> Database Driver Class Initialized
INFO - 2018-10-23 14:46:17 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:46:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:46:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:46:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:46:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:46:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:46:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:46:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/your_job.php
INFO - 2018-10-23 14:46:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:46:17 --> Final output sent to browser
DEBUG - 2018-10-23 14:46:17 --> Total execution time: 0.5878
INFO - 2018-10-23 14:46:20 --> Config Class Initialized
INFO - 2018-10-23 14:46:20 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:46:20 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:46:20 --> Utf8 Class Initialized
INFO - 2018-10-23 14:46:20 --> URI Class Initialized
INFO - 2018-10-23 14:46:21 --> Router Class Initialized
INFO - 2018-10-23 14:46:21 --> Output Class Initialized
INFO - 2018-10-23 14:46:21 --> Security Class Initialized
DEBUG - 2018-10-23 14:46:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:46:21 --> CSRF cookie sent
INFO - 2018-10-23 14:46:21 --> CSRF token verified
INFO - 2018-10-23 14:46:21 --> Input Class Initialized
INFO - 2018-10-23 14:46:21 --> Language Class Initialized
INFO - 2018-10-23 14:46:21 --> Loader Class Initialized
INFO - 2018-10-23 14:46:21 --> Helper loaded: url_helper
INFO - 2018-10-23 14:46:21 --> Helper loaded: form_helper
INFO - 2018-10-23 14:46:21 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:46:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:46:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:46:21 --> User Agent Class Initialized
INFO - 2018-10-23 14:46:21 --> Controller Class Initialized
INFO - 2018-10-23 14:46:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:46:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:46:21 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:46:21 --> Pixel_Model class loaded
INFO - 2018-10-23 14:46:21 --> Database Driver Class Initialized
INFO - 2018-10-23 14:46:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:46:21 --> Form Validation Class Initialized
INFO - 2018-10-23 14:46:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:46:21 --> Database Driver Class Initialized
INFO - 2018-10-23 14:46:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:46:21 --> Config Class Initialized
INFO - 2018-10-23 14:46:21 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:46:21 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:46:21 --> Utf8 Class Initialized
INFO - 2018-10-23 14:46:21 --> URI Class Initialized
INFO - 2018-10-23 14:46:21 --> Router Class Initialized
INFO - 2018-10-23 14:46:21 --> Output Class Initialized
INFO - 2018-10-23 14:46:21 --> Security Class Initialized
DEBUG - 2018-10-23 14:46:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:46:21 --> CSRF cookie sent
INFO - 2018-10-23 14:46:21 --> Input Class Initialized
INFO - 2018-10-23 14:46:21 --> Language Class Initialized
INFO - 2018-10-23 14:46:21 --> Loader Class Initialized
INFO - 2018-10-23 14:46:21 --> Helper loaded: url_helper
INFO - 2018-10-23 14:46:21 --> Helper loaded: form_helper
INFO - 2018-10-23 14:46:21 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:46:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:46:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:46:21 --> User Agent Class Initialized
INFO - 2018-10-23 14:46:21 --> Controller Class Initialized
INFO - 2018-10-23 14:46:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:46:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:46:21 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:46:21 --> Pixel_Model class loaded
INFO - 2018-10-23 14:46:21 --> Database Driver Class Initialized
INFO - 2018-10-23 14:46:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:46:21 --> Database Driver Class Initialized
INFO - 2018-10-23 14:46:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:46:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:46:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:46:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner.php
INFO - 2018-10-23 14:46:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:46:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:46:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:46:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:46:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/relation_ship_status.php
INFO - 2018-10-23 14:46:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:46:22 --> Final output sent to browser
DEBUG - 2018-10-23 14:46:22 --> Total execution time: 0.6021
INFO - 2018-10-23 14:46:28 --> Config Class Initialized
INFO - 2018-10-23 14:46:28 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:46:28 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:46:28 --> Utf8 Class Initialized
INFO - 2018-10-23 14:46:28 --> URI Class Initialized
INFO - 2018-10-23 14:46:28 --> Router Class Initialized
INFO - 2018-10-23 14:46:28 --> Output Class Initialized
INFO - 2018-10-23 14:46:28 --> Security Class Initialized
DEBUG - 2018-10-23 14:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:46:28 --> CSRF cookie sent
INFO - 2018-10-23 14:46:28 --> CSRF token verified
INFO - 2018-10-23 14:46:28 --> Input Class Initialized
INFO - 2018-10-23 14:46:28 --> Language Class Initialized
INFO - 2018-10-23 14:46:28 --> Loader Class Initialized
INFO - 2018-10-23 14:46:28 --> Helper loaded: url_helper
INFO - 2018-10-23 14:46:28 --> Helper loaded: form_helper
INFO - 2018-10-23 14:46:28 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:46:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:46:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:46:29 --> User Agent Class Initialized
INFO - 2018-10-23 14:46:29 --> Controller Class Initialized
INFO - 2018-10-23 14:46:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:46:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:46:29 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:46:29 --> Pixel_Model class loaded
INFO - 2018-10-23 14:46:29 --> Database Driver Class Initialized
INFO - 2018-10-23 14:46:29 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:46:29 --> Form Validation Class Initialized
INFO - 2018-10-23 14:46:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:46:29 --> Database Driver Class Initialized
INFO - 2018-10-23 14:46:29 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:46:29 --> Config Class Initialized
INFO - 2018-10-23 14:46:29 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:46:29 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:46:29 --> Utf8 Class Initialized
INFO - 2018-10-23 14:46:29 --> URI Class Initialized
INFO - 2018-10-23 14:46:29 --> Router Class Initialized
INFO - 2018-10-23 14:46:29 --> Output Class Initialized
INFO - 2018-10-23 14:46:29 --> Security Class Initialized
DEBUG - 2018-10-23 14:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:46:29 --> CSRF cookie sent
INFO - 2018-10-23 14:46:29 --> Input Class Initialized
INFO - 2018-10-23 14:46:29 --> Language Class Initialized
INFO - 2018-10-23 14:46:29 --> Loader Class Initialized
INFO - 2018-10-23 14:46:29 --> Helper loaded: url_helper
INFO - 2018-10-23 14:46:29 --> Helper loaded: form_helper
INFO - 2018-10-23 14:46:29 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:46:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:46:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:46:29 --> User Agent Class Initialized
INFO - 2018-10-23 14:46:29 --> Controller Class Initialized
INFO - 2018-10-23 14:46:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:46:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:46:29 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:46:29 --> Pixel_Model class loaded
INFO - 2018-10-23 14:46:29 --> Database Driver Class Initialized
INFO - 2018-10-23 14:46:29 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:46:29 --> Database Driver Class Initialized
INFO - 2018-10-23 14:46:29 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:46:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:46:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:46:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:46:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:46:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:46:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:46:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/income.php
INFO - 2018-10-23 14:46:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:46:29 --> Final output sent to browser
DEBUG - 2018-10-23 14:46:29 --> Total execution time: 0.5983
INFO - 2018-10-23 14:46:31 --> Config Class Initialized
INFO - 2018-10-23 14:46:31 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:46:31 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:46:31 --> Utf8 Class Initialized
INFO - 2018-10-23 14:46:31 --> URI Class Initialized
INFO - 2018-10-23 14:46:31 --> Router Class Initialized
INFO - 2018-10-23 14:46:31 --> Output Class Initialized
INFO - 2018-10-23 14:46:31 --> Security Class Initialized
DEBUG - 2018-10-23 14:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:46:31 --> CSRF cookie sent
INFO - 2018-10-23 14:46:31 --> CSRF token verified
INFO - 2018-10-23 14:46:31 --> Input Class Initialized
INFO - 2018-10-23 14:46:31 --> Language Class Initialized
INFO - 2018-10-23 14:46:31 --> Loader Class Initialized
INFO - 2018-10-23 14:46:31 --> Helper loaded: url_helper
INFO - 2018-10-23 14:46:31 --> Helper loaded: form_helper
INFO - 2018-10-23 14:46:31 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:46:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:46:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:46:31 --> User Agent Class Initialized
INFO - 2018-10-23 14:46:31 --> Controller Class Initialized
INFO - 2018-10-23 14:46:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:46:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:46:31 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:46:31 --> Pixel_Model class loaded
INFO - 2018-10-23 14:46:31 --> Database Driver Class Initialized
INFO - 2018-10-23 14:46:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:46:31 --> Form Validation Class Initialized
INFO - 2018-10-23 14:46:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:46:31 --> Database Driver Class Initialized
INFO - 2018-10-23 14:46:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:46:31 --> Config Class Initialized
INFO - 2018-10-23 14:46:31 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:46:31 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:46:31 --> Utf8 Class Initialized
INFO - 2018-10-23 14:46:31 --> URI Class Initialized
INFO - 2018-10-23 14:46:31 --> Router Class Initialized
INFO - 2018-10-23 14:46:31 --> Output Class Initialized
INFO - 2018-10-23 14:46:31 --> Security Class Initialized
DEBUG - 2018-10-23 14:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:46:31 --> CSRF cookie sent
INFO - 2018-10-23 14:46:31 --> Input Class Initialized
INFO - 2018-10-23 14:46:31 --> Language Class Initialized
INFO - 2018-10-23 14:46:31 --> Loader Class Initialized
INFO - 2018-10-23 14:46:31 --> Helper loaded: url_helper
INFO - 2018-10-23 14:46:31 --> Helper loaded: form_helper
INFO - 2018-10-23 14:46:31 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:46:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:46:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:46:32 --> User Agent Class Initialized
INFO - 2018-10-23 14:46:32 --> Controller Class Initialized
INFO - 2018-10-23 14:46:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:46:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:46:32 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:46:32 --> Pixel_Model class loaded
INFO - 2018-10-23 14:46:32 --> Database Driver Class Initialized
INFO - 2018-10-23 14:46:32 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:46:32 --> Database Driver Class Initialized
INFO - 2018-10-23 14:46:32 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:46:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:46:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:46:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:46:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:46:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:46:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:46:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/marriage.php
INFO - 2018-10-23 14:46:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:46:32 --> Final output sent to browser
DEBUG - 2018-10-23 14:46:32 --> Total execution time: 0.5767
INFO - 2018-10-23 14:46:36 --> Config Class Initialized
INFO - 2018-10-23 14:46:36 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:46:36 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:46:36 --> Utf8 Class Initialized
INFO - 2018-10-23 14:46:36 --> URI Class Initialized
INFO - 2018-10-23 14:46:36 --> Router Class Initialized
INFO - 2018-10-23 14:46:36 --> Output Class Initialized
INFO - 2018-10-23 14:46:36 --> Security Class Initialized
DEBUG - 2018-10-23 14:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:46:36 --> CSRF cookie sent
INFO - 2018-10-23 14:46:36 --> CSRF token verified
INFO - 2018-10-23 14:46:36 --> Input Class Initialized
INFO - 2018-10-23 14:46:37 --> Language Class Initialized
INFO - 2018-10-23 14:46:37 --> Loader Class Initialized
INFO - 2018-10-23 14:46:37 --> Helper loaded: url_helper
INFO - 2018-10-23 14:46:37 --> Helper loaded: form_helper
INFO - 2018-10-23 14:46:37 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:46:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:46:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:46:37 --> User Agent Class Initialized
INFO - 2018-10-23 14:46:37 --> Controller Class Initialized
INFO - 2018-10-23 14:46:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:46:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:46:37 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:46:37 --> Pixel_Model class loaded
INFO - 2018-10-23 14:46:37 --> Database Driver Class Initialized
INFO - 2018-10-23 14:46:37 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:46:37 --> Form Validation Class Initialized
INFO - 2018-10-23 14:46:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:46:37 --> Database Driver Class Initialized
INFO - 2018-10-23 14:46:37 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:46:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:46:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:46:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:46:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:46:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:46:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_errors.php
INFO - 2018-10-23 14:46:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:46:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/marriage.php
INFO - 2018-10-23 14:46:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:46:37 --> Final output sent to browser
DEBUG - 2018-10-23 14:46:37 --> Total execution time: 0.6743
INFO - 2018-10-23 14:46:40 --> Config Class Initialized
INFO - 2018-10-23 14:46:40 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:46:40 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:46:40 --> Utf8 Class Initialized
INFO - 2018-10-23 14:46:40 --> URI Class Initialized
INFO - 2018-10-23 14:46:40 --> Router Class Initialized
INFO - 2018-10-23 14:46:40 --> Output Class Initialized
INFO - 2018-10-23 14:46:40 --> Security Class Initialized
DEBUG - 2018-10-23 14:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:46:40 --> CSRF cookie sent
INFO - 2018-10-23 14:46:40 --> CSRF token verified
INFO - 2018-10-23 14:46:40 --> Input Class Initialized
INFO - 2018-10-23 14:46:40 --> Language Class Initialized
INFO - 2018-10-23 14:46:40 --> Loader Class Initialized
INFO - 2018-10-23 14:46:40 --> Helper loaded: url_helper
INFO - 2018-10-23 14:46:40 --> Helper loaded: form_helper
INFO - 2018-10-23 14:46:40 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:46:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:46:40 --> User Agent Class Initialized
INFO - 2018-10-23 14:46:40 --> Controller Class Initialized
INFO - 2018-10-23 14:46:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:46:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:46:40 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:46:40 --> Pixel_Model class loaded
INFO - 2018-10-23 14:46:40 --> Database Driver Class Initialized
INFO - 2018-10-23 14:46:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:46:40 --> Form Validation Class Initialized
INFO - 2018-10-23 14:46:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:46:40 --> Database Driver Class Initialized
INFO - 2018-10-23 14:46:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:46:40 --> Config Class Initialized
INFO - 2018-10-23 14:46:40 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:46:40 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:46:40 --> Utf8 Class Initialized
INFO - 2018-10-23 14:46:40 --> URI Class Initialized
INFO - 2018-10-23 14:46:40 --> Router Class Initialized
INFO - 2018-10-23 14:46:40 --> Output Class Initialized
INFO - 2018-10-23 14:46:40 --> Security Class Initialized
DEBUG - 2018-10-23 14:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:46:40 --> CSRF cookie sent
INFO - 2018-10-23 14:46:40 --> Input Class Initialized
INFO - 2018-10-23 14:46:40 --> Language Class Initialized
INFO - 2018-10-23 14:46:40 --> Loader Class Initialized
INFO - 2018-10-23 14:46:40 --> Helper loaded: url_helper
INFO - 2018-10-23 14:46:40 --> Helper loaded: form_helper
INFO - 2018-10-23 14:46:40 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:46:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:46:40 --> User Agent Class Initialized
INFO - 2018-10-23 14:46:40 --> Controller Class Initialized
INFO - 2018-10-23 14:46:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:46:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:46:41 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:46:41 --> Pixel_Model class loaded
INFO - 2018-10-23 14:46:41 --> Database Driver Class Initialized
INFO - 2018-10-23 14:46:41 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:46:41 --> Database Driver Class Initialized
INFO - 2018-10-23 14:46:41 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:46:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:46:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:46:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:46:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:46:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:46:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:46:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/pension.php
INFO - 2018-10-23 14:46:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:46:41 --> Final output sent to browser
DEBUG - 2018-10-23 14:46:41 --> Total execution time: 0.5941
INFO - 2018-10-23 14:46:45 --> Config Class Initialized
INFO - 2018-10-23 14:46:45 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:46:45 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:46:45 --> Utf8 Class Initialized
INFO - 2018-10-23 14:46:45 --> URI Class Initialized
INFO - 2018-10-23 14:46:45 --> Router Class Initialized
INFO - 2018-10-23 14:46:45 --> Output Class Initialized
INFO - 2018-10-23 14:46:45 --> Security Class Initialized
DEBUG - 2018-10-23 14:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:46:45 --> CSRF cookie sent
INFO - 2018-10-23 14:46:45 --> CSRF token verified
INFO - 2018-10-23 14:46:45 --> Input Class Initialized
INFO - 2018-10-23 14:46:45 --> Language Class Initialized
INFO - 2018-10-23 14:46:45 --> Loader Class Initialized
INFO - 2018-10-23 14:46:45 --> Helper loaded: url_helper
INFO - 2018-10-23 14:46:45 --> Helper loaded: form_helper
INFO - 2018-10-23 14:46:45 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:46:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:46:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:46:45 --> User Agent Class Initialized
INFO - 2018-10-23 14:46:45 --> Controller Class Initialized
INFO - 2018-10-23 14:46:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:46:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:46:45 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:46:45 --> Pixel_Model class loaded
INFO - 2018-10-23 14:46:45 --> Database Driver Class Initialized
INFO - 2018-10-23 14:46:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:46:45 --> Form Validation Class Initialized
INFO - 2018-10-23 14:46:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:46:45 --> Database Driver Class Initialized
INFO - 2018-10-23 14:46:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:46:46 --> Config Class Initialized
INFO - 2018-10-23 14:46:46 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:46:46 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:46:46 --> Utf8 Class Initialized
INFO - 2018-10-23 14:46:46 --> URI Class Initialized
INFO - 2018-10-23 14:46:46 --> Router Class Initialized
INFO - 2018-10-23 14:46:46 --> Output Class Initialized
INFO - 2018-10-23 14:46:46 --> Security Class Initialized
DEBUG - 2018-10-23 14:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:46:46 --> CSRF cookie sent
INFO - 2018-10-23 14:46:46 --> Input Class Initialized
INFO - 2018-10-23 14:46:46 --> Language Class Initialized
INFO - 2018-10-23 14:46:46 --> Loader Class Initialized
INFO - 2018-10-23 14:46:46 --> Helper loaded: url_helper
INFO - 2018-10-23 14:46:46 --> Helper loaded: form_helper
INFO - 2018-10-23 14:46:46 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:46:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:46:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:46:46 --> User Agent Class Initialized
INFO - 2018-10-23 14:46:46 --> Controller Class Initialized
INFO - 2018-10-23 14:46:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:46:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:46:46 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:46:46 --> Pixel_Model class loaded
INFO - 2018-10-23 14:46:46 --> Database Driver Class Initialized
INFO - 2018-10-23 14:46:46 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:46:46 --> Database Driver Class Initialized
INFO - 2018-10-23 14:46:46 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:46:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:46:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:46:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:46:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:46:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:46:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:46:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/inheritance.php
INFO - 2018-10-23 14:46:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:46:46 --> Final output sent to browser
DEBUG - 2018-10-23 14:46:46 --> Total execution time: 0.6113
INFO - 2018-10-23 14:47:42 --> Config Class Initialized
INFO - 2018-10-23 14:47:43 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:47:43 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:47:43 --> Utf8 Class Initialized
INFO - 2018-10-23 14:47:43 --> URI Class Initialized
INFO - 2018-10-23 14:47:43 --> Router Class Initialized
INFO - 2018-10-23 14:47:43 --> Output Class Initialized
INFO - 2018-10-23 14:47:43 --> Security Class Initialized
DEBUG - 2018-10-23 14:47:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:47:43 --> CSRF cookie sent
INFO - 2018-10-23 14:47:43 --> Input Class Initialized
INFO - 2018-10-23 14:47:43 --> Language Class Initialized
INFO - 2018-10-23 14:47:43 --> Loader Class Initialized
INFO - 2018-10-23 14:47:43 --> Helper loaded: url_helper
INFO - 2018-10-23 14:47:43 --> Helper loaded: form_helper
INFO - 2018-10-23 14:47:43 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:47:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:47:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:47:43 --> User Agent Class Initialized
INFO - 2018-10-23 14:47:43 --> Controller Class Initialized
INFO - 2018-10-23 14:47:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:47:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:47:43 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:47:43 --> Pixel_Model class loaded
INFO - 2018-10-23 14:47:43 --> Database Driver Class Initialized
INFO - 2018-10-23 14:47:43 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:47:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:47:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:47:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:47:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:47:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:47:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:47:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-23 14:47:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:47:43 --> Final output sent to browser
DEBUG - 2018-10-23 14:47:43 --> Total execution time: 0.5658
INFO - 2018-10-23 14:47:46 --> Config Class Initialized
INFO - 2018-10-23 14:47:46 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:47:46 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:47:46 --> Utf8 Class Initialized
INFO - 2018-10-23 14:47:46 --> URI Class Initialized
INFO - 2018-10-23 14:47:46 --> Router Class Initialized
INFO - 2018-10-23 14:47:46 --> Output Class Initialized
INFO - 2018-10-23 14:47:46 --> Security Class Initialized
DEBUG - 2018-10-23 14:47:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:47:46 --> CSRF cookie sent
INFO - 2018-10-23 14:47:46 --> CSRF token verified
INFO - 2018-10-23 14:47:46 --> Input Class Initialized
INFO - 2018-10-23 14:47:46 --> Language Class Initialized
INFO - 2018-10-23 14:47:46 --> Loader Class Initialized
INFO - 2018-10-23 14:47:46 --> Helper loaded: url_helper
INFO - 2018-10-23 14:47:46 --> Helper loaded: form_helper
INFO - 2018-10-23 14:47:46 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:47:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:47:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:47:46 --> User Agent Class Initialized
INFO - 2018-10-23 14:47:46 --> Controller Class Initialized
INFO - 2018-10-23 14:47:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:47:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:47:46 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:47:46 --> Pixel_Model class loaded
INFO - 2018-10-23 14:47:46 --> Database Driver Class Initialized
INFO - 2018-10-23 14:47:46 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:47:46 --> Form Validation Class Initialized
INFO - 2018-10-23 14:47:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 14:47:46 --> Database Driver Class Initialized
INFO - 2018-10-23 14:47:46 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:47:46 --> Config Class Initialized
INFO - 2018-10-23 14:47:46 --> Hooks Class Initialized
DEBUG - 2018-10-23 14:47:46 --> UTF-8 Support Enabled
INFO - 2018-10-23 14:47:46 --> Utf8 Class Initialized
INFO - 2018-10-23 14:47:46 --> URI Class Initialized
INFO - 2018-10-23 14:47:46 --> Router Class Initialized
INFO - 2018-10-23 14:47:46 --> Output Class Initialized
INFO - 2018-10-23 14:47:46 --> Security Class Initialized
DEBUG - 2018-10-23 14:47:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 14:47:46 --> CSRF cookie sent
INFO - 2018-10-23 14:47:46 --> Input Class Initialized
INFO - 2018-10-23 14:47:46 --> Language Class Initialized
INFO - 2018-10-23 14:47:47 --> Loader Class Initialized
INFO - 2018-10-23 14:47:47 --> Helper loaded: url_helper
INFO - 2018-10-23 14:47:47 --> Helper loaded: form_helper
INFO - 2018-10-23 14:47:47 --> Helper loaded: language_helper
DEBUG - 2018-10-23 14:47:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 14:47:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 14:47:47 --> User Agent Class Initialized
INFO - 2018-10-23 14:47:47 --> Controller Class Initialized
INFO - 2018-10-23 14:47:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 14:47:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 14:47:47 --> Helper loaded: custom_helper
INFO - 2018-10-23 14:47:47 --> Pixel_Model class loaded
INFO - 2018-10-23 14:47:47 --> Database Driver Class Initialized
INFO - 2018-10-23 14:47:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:47:47 --> Database Driver Class Initialized
INFO - 2018-10-23 14:47:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 14:47:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 14:47:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 14:47:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 14:47:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 14:47:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 14:47:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 14:47:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-23 14:47:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 14:47:47 --> Final output sent to browser
DEBUG - 2018-10-23 14:47:47 --> Total execution time: 0.6145
INFO - 2018-10-23 16:45:34 --> Config Class Initialized
INFO - 2018-10-23 16:45:34 --> Hooks Class Initialized
DEBUG - 2018-10-23 16:45:34 --> UTF-8 Support Enabled
INFO - 2018-10-23 16:45:34 --> Utf8 Class Initialized
INFO - 2018-10-23 16:45:34 --> URI Class Initialized
DEBUG - 2018-10-23 16:45:34 --> No URI present. Default controller set.
INFO - 2018-10-23 16:45:34 --> Router Class Initialized
INFO - 2018-10-23 16:45:34 --> Output Class Initialized
INFO - 2018-10-23 16:45:34 --> Security Class Initialized
DEBUG - 2018-10-23 16:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 16:45:34 --> CSRF cookie sent
INFO - 2018-10-23 16:45:34 --> Input Class Initialized
INFO - 2018-10-23 16:45:35 --> Language Class Initialized
INFO - 2018-10-23 16:45:35 --> Loader Class Initialized
INFO - 2018-10-23 16:45:35 --> Helper loaded: url_helper
INFO - 2018-10-23 16:45:35 --> Helper loaded: form_helper
INFO - 2018-10-23 16:45:35 --> Helper loaded: language_helper
DEBUG - 2018-10-23 16:45:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 16:45:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 16:45:35 --> User Agent Class Initialized
INFO - 2018-10-23 16:45:35 --> Controller Class Initialized
INFO - 2018-10-23 16:45:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 16:45:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 16:45:35 --> Helper loaded: custom_helper
INFO - 2018-10-23 16:45:35 --> Pixel_Model class loaded
INFO - 2018-10-23 16:45:35 --> Database Driver Class Initialized
INFO - 2018-10-23 16:45:35 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 16:45:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 16:45:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 16:45:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-23 16:45:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 16:45:35 --> Final output sent to browser
DEBUG - 2018-10-23 16:45:36 --> Total execution time: 1.8058
INFO - 2018-10-23 16:46:10 --> Config Class Initialized
INFO - 2018-10-23 16:46:10 --> Hooks Class Initialized
DEBUG - 2018-10-23 16:46:10 --> UTF-8 Support Enabled
INFO - 2018-10-23 16:46:10 --> Utf8 Class Initialized
INFO - 2018-10-23 16:46:10 --> URI Class Initialized
INFO - 2018-10-23 16:46:10 --> Router Class Initialized
INFO - 2018-10-23 16:46:10 --> Output Class Initialized
INFO - 2018-10-23 16:46:10 --> Security Class Initialized
DEBUG - 2018-10-23 16:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 16:46:10 --> CSRF cookie sent
INFO - 2018-10-23 16:46:10 --> CSRF token verified
INFO - 2018-10-23 16:46:10 --> Input Class Initialized
INFO - 2018-10-23 16:46:10 --> Language Class Initialized
INFO - 2018-10-23 16:46:10 --> Loader Class Initialized
INFO - 2018-10-23 16:46:10 --> Helper loaded: url_helper
INFO - 2018-10-23 16:46:10 --> Helper loaded: form_helper
INFO - 2018-10-23 16:46:10 --> Helper loaded: language_helper
DEBUG - 2018-10-23 16:46:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 16:46:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 16:46:10 --> User Agent Class Initialized
INFO - 2018-10-23 16:46:11 --> Controller Class Initialized
INFO - 2018-10-23 16:46:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 16:46:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 16:46:11 --> Helper loaded: custom_helper
INFO - 2018-10-23 16:46:11 --> Pixel_Model class loaded
INFO - 2018-10-23 16:46:11 --> Database Driver Class Initialized
INFO - 2018-10-23 16:46:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 16:46:11 --> Form Validation Class Initialized
INFO - 2018-10-23 16:46:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 16:46:11 --> Database Driver Class Initialized
INFO - 2018-10-23 16:46:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 16:46:11 --> Config Class Initialized
INFO - 2018-10-23 16:46:11 --> Hooks Class Initialized
DEBUG - 2018-10-23 16:46:11 --> UTF-8 Support Enabled
INFO - 2018-10-23 16:46:11 --> Utf8 Class Initialized
INFO - 2018-10-23 16:46:11 --> URI Class Initialized
INFO - 2018-10-23 16:46:11 --> Router Class Initialized
INFO - 2018-10-23 16:46:11 --> Output Class Initialized
INFO - 2018-10-23 16:46:11 --> Security Class Initialized
DEBUG - 2018-10-23 16:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 16:46:11 --> CSRF cookie sent
INFO - 2018-10-23 16:46:11 --> Input Class Initialized
INFO - 2018-10-23 16:46:11 --> Language Class Initialized
INFO - 2018-10-23 16:46:11 --> Loader Class Initialized
INFO - 2018-10-23 16:46:11 --> Helper loaded: url_helper
INFO - 2018-10-23 16:46:11 --> Helper loaded: form_helper
INFO - 2018-10-23 16:46:11 --> Helper loaded: language_helper
DEBUG - 2018-10-23 16:46:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 16:46:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 16:46:11 --> User Agent Class Initialized
INFO - 2018-10-23 16:46:11 --> Controller Class Initialized
INFO - 2018-10-23 16:46:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 16:46:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 16:46:11 --> Helper loaded: custom_helper
INFO - 2018-10-23 16:46:11 --> Pixel_Model class loaded
INFO - 2018-10-23 16:46:11 --> Database Driver Class Initialized
INFO - 2018-10-23 16:46:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 16:46:11 --> Database Driver Class Initialized
INFO - 2018-10-23 16:46:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 16:46:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 16:46:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 16:46:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 16:46:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 16:46:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 16:46:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 16:46:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-23 16:46:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 16:46:12 --> Final output sent to browser
DEBUG - 2018-10-23 16:46:12 --> Total execution time: 0.8204
INFO - 2018-10-23 16:52:09 --> Config Class Initialized
INFO - 2018-10-23 16:52:10 --> Hooks Class Initialized
DEBUG - 2018-10-23 16:52:10 --> UTF-8 Support Enabled
INFO - 2018-10-23 16:52:10 --> Utf8 Class Initialized
INFO - 2018-10-23 16:52:10 --> URI Class Initialized
INFO - 2018-10-23 16:52:10 --> Router Class Initialized
INFO - 2018-10-23 16:52:10 --> Output Class Initialized
INFO - 2018-10-23 16:52:10 --> Security Class Initialized
DEBUG - 2018-10-23 16:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 16:52:10 --> CSRF cookie sent
INFO - 2018-10-23 16:52:10 --> Input Class Initialized
INFO - 2018-10-23 16:52:10 --> Language Class Initialized
INFO - 2018-10-23 16:52:10 --> Loader Class Initialized
INFO - 2018-10-23 16:52:10 --> Helper loaded: url_helper
INFO - 2018-10-23 16:52:10 --> Helper loaded: form_helper
INFO - 2018-10-23 16:52:10 --> Helper loaded: language_helper
DEBUG - 2018-10-23 16:52:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 16:52:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 16:52:10 --> User Agent Class Initialized
INFO - 2018-10-23 16:52:10 --> Controller Class Initialized
INFO - 2018-10-23 16:52:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 16:52:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 16:52:10 --> Helper loaded: custom_helper
INFO - 2018-10-23 16:52:10 --> Pixel_Model class loaded
INFO - 2018-10-23 16:52:10 --> Database Driver Class Initialized
INFO - 2018-10-23 16:52:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 16:52:10 --> Config Class Initialized
INFO - 2018-10-23 16:52:10 --> Hooks Class Initialized
DEBUG - 2018-10-23 16:52:10 --> UTF-8 Support Enabled
INFO - 2018-10-23 16:52:10 --> Utf8 Class Initialized
INFO - 2018-10-23 16:52:10 --> URI Class Initialized
INFO - 2018-10-23 16:52:10 --> Router Class Initialized
INFO - 2018-10-23 16:52:10 --> Output Class Initialized
INFO - 2018-10-23 16:52:10 --> Security Class Initialized
DEBUG - 2018-10-23 16:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 16:52:10 --> CSRF cookie sent
INFO - 2018-10-23 16:52:10 --> Input Class Initialized
INFO - 2018-10-23 16:52:10 --> Language Class Initialized
INFO - 2018-10-23 16:52:10 --> Loader Class Initialized
INFO - 2018-10-23 16:52:10 --> Helper loaded: url_helper
INFO - 2018-10-23 16:52:10 --> Helper loaded: form_helper
INFO - 2018-10-23 16:52:10 --> Helper loaded: language_helper
DEBUG - 2018-10-23 16:52:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 16:52:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 16:52:10 --> User Agent Class Initialized
INFO - 2018-10-23 16:52:10 --> Controller Class Initialized
INFO - 2018-10-23 16:52:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 16:52:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 16:52:10 --> Helper loaded: custom_helper
INFO - 2018-10-23 16:52:10 --> Pixel_Model class loaded
INFO - 2018-10-23 16:52:10 --> Database Driver Class Initialized
INFO - 2018-10-23 16:52:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 16:52:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 16:52:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 16:52:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 16:52:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 16:52:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 16:52:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 16:52:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-23 16:52:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 16:52:11 --> Final output sent to browser
DEBUG - 2018-10-23 16:52:11 --> Total execution time: 0.6426
INFO - 2018-10-23 16:52:12 --> Config Class Initialized
INFO - 2018-10-23 16:52:12 --> Hooks Class Initialized
DEBUG - 2018-10-23 16:52:12 --> UTF-8 Support Enabled
INFO - 2018-10-23 16:52:12 --> Utf8 Class Initialized
INFO - 2018-10-23 16:52:12 --> URI Class Initialized
INFO - 2018-10-23 16:52:12 --> Router Class Initialized
INFO - 2018-10-23 16:52:12 --> Output Class Initialized
INFO - 2018-10-23 16:52:12 --> Security Class Initialized
DEBUG - 2018-10-23 16:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 16:52:13 --> CSRF cookie sent
INFO - 2018-10-23 16:52:13 --> Input Class Initialized
INFO - 2018-10-23 16:52:13 --> Language Class Initialized
INFO - 2018-10-23 16:52:13 --> Loader Class Initialized
INFO - 2018-10-23 16:52:13 --> Helper loaded: url_helper
INFO - 2018-10-23 16:52:13 --> Helper loaded: form_helper
INFO - 2018-10-23 16:52:13 --> Helper loaded: language_helper
DEBUG - 2018-10-23 16:52:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 16:52:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 16:52:13 --> User Agent Class Initialized
INFO - 2018-10-23 16:52:13 --> Controller Class Initialized
INFO - 2018-10-23 16:52:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 16:52:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 16:52:13 --> Helper loaded: custom_helper
INFO - 2018-10-23 16:52:13 --> Pixel_Model class loaded
INFO - 2018-10-23 16:52:13 --> Database Driver Class Initialized
INFO - 2018-10-23 16:52:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 16:52:13 --> Config Class Initialized
INFO - 2018-10-23 16:52:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 16:52:13 --> Hooks Class Initialized
INFO - 2018-10-23 16:52:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 16:52:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
DEBUG - 2018-10-23 16:52:13 --> UTF-8 Support Enabled
INFO - 2018-10-23 16:52:13 --> Utf8 Class Initialized
INFO - 2018-10-23 16:52:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 16:52:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 16:52:13 --> URI Class Initialized
INFO - 2018-10-23 16:52:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 16:52:13 --> Router Class Initialized
INFO - 2018-10-23 16:52:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-23 16:52:13 --> Output Class Initialized
INFO - 2018-10-23 16:52:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 16:52:13 --> Security Class Initialized
INFO - 2018-10-23 16:52:13 --> Final output sent to browser
DEBUG - 2018-10-23 16:52:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-10-23 16:52:13 --> Total execution time: 0.5762
INFO - 2018-10-23 16:52:13 --> CSRF cookie sent
INFO - 2018-10-23 16:52:13 --> Input Class Initialized
INFO - 2018-10-23 16:52:13 --> Language Class Initialized
INFO - 2018-10-23 16:52:13 --> Loader Class Initialized
INFO - 2018-10-23 16:52:13 --> Helper loaded: url_helper
INFO - 2018-10-23 16:52:13 --> Config Class Initialized
INFO - 2018-10-23 16:52:13 --> Hooks Class Initialized
INFO - 2018-10-23 16:52:13 --> Helper loaded: form_helper
INFO - 2018-10-23 16:52:13 --> Helper loaded: language_helper
DEBUG - 2018-10-23 16:52:13 --> UTF-8 Support Enabled
INFO - 2018-10-23 16:52:13 --> Utf8 Class Initialized
DEBUG - 2018-10-23 16:52:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 16:52:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 16:52:13 --> URI Class Initialized
INFO - 2018-10-23 16:52:13 --> Router Class Initialized
INFO - 2018-10-23 16:52:13 --> User Agent Class Initialized
INFO - 2018-10-23 16:52:13 --> Output Class Initialized
INFO - 2018-10-23 16:52:13 --> Controller Class Initialized
INFO - 2018-10-23 16:52:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 16:52:13 --> Security Class Initialized
INFO - 2018-10-23 16:52:13 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-23 16:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 16:52:13 --> CSRF cookie sent
INFO - 2018-10-23 16:52:13 --> Helper loaded: custom_helper
INFO - 2018-10-23 16:52:13 --> Input Class Initialized
INFO - 2018-10-23 16:52:13 --> Pixel_Model class loaded
INFO - 2018-10-23 16:52:13 --> Language Class Initialized
INFO - 2018-10-23 16:52:13 --> Database Driver Class Initialized
INFO - 2018-10-23 16:52:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 16:52:13 --> Loader Class Initialized
INFO - 2018-10-23 16:52:13 --> Helper loaded: url_helper
INFO - 2018-10-23 16:52:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 16:52:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 16:52:13 --> Helper loaded: form_helper
INFO - 2018-10-23 16:52:13 --> Helper loaded: language_helper
INFO - 2018-10-23 16:52:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 16:52:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
DEBUG - 2018-10-23 16:52:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 16:52:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 16:52:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 16:52:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-23 16:52:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 16:52:13 --> Final output sent to browser
DEBUG - 2018-10-23 16:52:13 --> Total execution time: 0.5652
INFO - 2018-10-23 16:52:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 16:52:13 --> User Agent Class Initialized
INFO - 2018-10-23 16:52:13 --> Controller Class Initialized
INFO - 2018-10-23 16:52:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 16:52:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 16:52:13 --> Helper loaded: custom_helper
INFO - 2018-10-23 16:52:13 --> Pixel_Model class loaded
INFO - 2018-10-23 16:52:14 --> Database Driver Class Initialized
INFO - 2018-10-23 16:52:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 16:52:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 16:52:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 16:52:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 16:52:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 16:52:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 16:52:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 16:52:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-23 16:52:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 16:52:14 --> Config Class Initialized
INFO - 2018-10-23 16:52:14 --> Hooks Class Initialized
INFO - 2018-10-23 16:52:14 --> Final output sent to browser
DEBUG - 2018-10-23 16:52:14 --> Total execution time: 0.6656
DEBUG - 2018-10-23 16:52:14 --> UTF-8 Support Enabled
INFO - 2018-10-23 16:52:14 --> Utf8 Class Initialized
INFO - 2018-10-23 16:52:14 --> URI Class Initialized
DEBUG - 2018-10-23 16:52:14 --> No URI present. Default controller set.
INFO - 2018-10-23 16:52:14 --> Router Class Initialized
INFO - 2018-10-23 16:52:14 --> Output Class Initialized
INFO - 2018-10-23 16:52:14 --> Security Class Initialized
DEBUG - 2018-10-23 16:52:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 16:52:14 --> CSRF cookie sent
INFO - 2018-10-23 16:52:14 --> Input Class Initialized
INFO - 2018-10-23 16:52:14 --> Language Class Initialized
INFO - 2018-10-23 16:52:14 --> Loader Class Initialized
INFO - 2018-10-23 16:52:14 --> Helper loaded: url_helper
INFO - 2018-10-23 16:52:14 --> Helper loaded: form_helper
INFO - 2018-10-23 16:52:14 --> Helper loaded: language_helper
DEBUG - 2018-10-23 16:52:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 16:52:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 16:52:14 --> User Agent Class Initialized
INFO - 2018-10-23 16:52:14 --> Controller Class Initialized
INFO - 2018-10-23 16:52:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 16:52:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 16:52:14 --> Helper loaded: custom_helper
INFO - 2018-10-23 16:52:14 --> Pixel_Model class loaded
INFO - 2018-10-23 16:52:14 --> Database Driver Class Initialized
INFO - 2018-10-23 16:52:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 16:52:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 16:52:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 16:52:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-23 16:52:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 16:52:14 --> Final output sent to browser
DEBUG - 2018-10-23 16:52:14 --> Total execution time: 0.5396
INFO - 2018-10-23 16:52:14 --> Config Class Initialized
INFO - 2018-10-23 16:52:14 --> Hooks Class Initialized
DEBUG - 2018-10-23 16:52:14 --> UTF-8 Support Enabled
INFO - 2018-10-23 16:52:14 --> Utf8 Class Initialized
INFO - 2018-10-23 16:52:14 --> URI Class Initialized
DEBUG - 2018-10-23 16:52:14 --> No URI present. Default controller set.
INFO - 2018-10-23 16:52:14 --> Router Class Initialized
INFO - 2018-10-23 16:52:14 --> Output Class Initialized
INFO - 2018-10-23 16:52:14 --> Security Class Initialized
DEBUG - 2018-10-23 16:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 16:52:15 --> CSRF cookie sent
INFO - 2018-10-23 16:52:15 --> Input Class Initialized
INFO - 2018-10-23 16:52:15 --> Language Class Initialized
INFO - 2018-10-23 16:52:15 --> Loader Class Initialized
INFO - 2018-10-23 16:52:15 --> Helper loaded: url_helper
INFO - 2018-10-23 16:52:15 --> Helper loaded: form_helper
INFO - 2018-10-23 16:52:15 --> Helper loaded: language_helper
DEBUG - 2018-10-23 16:52:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 16:52:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 16:52:15 --> User Agent Class Initialized
INFO - 2018-10-23 16:52:15 --> Controller Class Initialized
INFO - 2018-10-23 16:52:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 16:52:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 16:52:15 --> Helper loaded: custom_helper
INFO - 2018-10-23 16:52:15 --> Pixel_Model class loaded
INFO - 2018-10-23 16:52:15 --> Database Driver Class Initialized
INFO - 2018-10-23 16:52:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 16:52:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 16:52:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 16:52:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-23 16:52:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 16:52:15 --> Final output sent to browser
DEBUG - 2018-10-23 16:52:15 --> Total execution time: 0.5713
INFO - 2018-10-23 16:52:18 --> Config Class Initialized
INFO - 2018-10-23 16:52:18 --> Hooks Class Initialized
DEBUG - 2018-10-23 16:52:18 --> UTF-8 Support Enabled
INFO - 2018-10-23 16:52:18 --> Utf8 Class Initialized
INFO - 2018-10-23 16:52:18 --> URI Class Initialized
INFO - 2018-10-23 16:52:19 --> Router Class Initialized
INFO - 2018-10-23 16:52:19 --> Output Class Initialized
INFO - 2018-10-23 16:52:19 --> Security Class Initialized
DEBUG - 2018-10-23 16:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 16:52:19 --> CSRF cookie sent
INFO - 2018-10-23 16:52:19 --> CSRF token verified
INFO - 2018-10-23 16:52:19 --> Input Class Initialized
INFO - 2018-10-23 16:52:19 --> Language Class Initialized
INFO - 2018-10-23 16:52:19 --> Loader Class Initialized
INFO - 2018-10-23 16:52:19 --> Helper loaded: url_helper
INFO - 2018-10-23 16:52:19 --> Helper loaded: form_helper
INFO - 2018-10-23 16:52:19 --> Helper loaded: language_helper
DEBUG - 2018-10-23 16:52:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 16:52:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 16:52:19 --> User Agent Class Initialized
INFO - 2018-10-23 16:52:19 --> Controller Class Initialized
INFO - 2018-10-23 16:52:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 16:52:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 16:52:19 --> Helper loaded: custom_helper
INFO - 2018-10-23 16:52:19 --> Pixel_Model class loaded
INFO - 2018-10-23 16:52:19 --> Database Driver Class Initialized
INFO - 2018-10-23 16:52:19 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 16:52:19 --> Form Validation Class Initialized
INFO - 2018-10-23 16:52:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 16:52:19 --> Database Driver Class Initialized
INFO - 2018-10-23 16:52:19 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 16:52:19 --> Config Class Initialized
INFO - 2018-10-23 16:52:19 --> Hooks Class Initialized
DEBUG - 2018-10-23 16:52:19 --> UTF-8 Support Enabled
INFO - 2018-10-23 16:52:19 --> Utf8 Class Initialized
INFO - 2018-10-23 16:52:19 --> URI Class Initialized
INFO - 2018-10-23 16:52:19 --> Router Class Initialized
INFO - 2018-10-23 16:52:19 --> Output Class Initialized
INFO - 2018-10-23 16:52:19 --> Security Class Initialized
DEBUG - 2018-10-23 16:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 16:52:19 --> CSRF cookie sent
INFO - 2018-10-23 16:52:19 --> Input Class Initialized
INFO - 2018-10-23 16:52:19 --> Language Class Initialized
INFO - 2018-10-23 16:52:19 --> Loader Class Initialized
INFO - 2018-10-23 16:52:19 --> Helper loaded: url_helper
INFO - 2018-10-23 16:52:19 --> Helper loaded: form_helper
INFO - 2018-10-23 16:52:19 --> Helper loaded: language_helper
DEBUG - 2018-10-23 16:52:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 16:52:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 16:52:19 --> User Agent Class Initialized
INFO - 2018-10-23 16:52:19 --> Controller Class Initialized
INFO - 2018-10-23 16:52:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 16:52:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 16:52:19 --> Helper loaded: custom_helper
INFO - 2018-10-23 16:52:19 --> Pixel_Model class loaded
INFO - 2018-10-23 16:52:19 --> Database Driver Class Initialized
INFO - 2018-10-23 16:52:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 16:52:20 --> Database Driver Class Initialized
INFO - 2018-10-23 16:52:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 16:52:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 16:52:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 16:52:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 16:52:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 16:52:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 16:52:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 16:52:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-23 16:52:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 16:52:20 --> Final output sent to browser
DEBUG - 2018-10-23 16:52:20 --> Total execution time: 0.6879
INFO - 2018-10-23 16:52:22 --> Config Class Initialized
INFO - 2018-10-23 16:52:22 --> Hooks Class Initialized
DEBUG - 2018-10-23 16:52:22 --> UTF-8 Support Enabled
INFO - 2018-10-23 16:52:22 --> Utf8 Class Initialized
INFO - 2018-10-23 16:52:22 --> URI Class Initialized
DEBUG - 2018-10-23 16:52:22 --> No URI present. Default controller set.
INFO - 2018-10-23 16:52:22 --> Router Class Initialized
INFO - 2018-10-23 16:52:22 --> Output Class Initialized
INFO - 2018-10-23 16:52:22 --> Security Class Initialized
DEBUG - 2018-10-23 16:52:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 16:52:22 --> CSRF cookie sent
INFO - 2018-10-23 16:52:22 --> Input Class Initialized
INFO - 2018-10-23 16:52:22 --> Language Class Initialized
INFO - 2018-10-23 16:52:22 --> Loader Class Initialized
INFO - 2018-10-23 16:52:22 --> Helper loaded: url_helper
INFO - 2018-10-23 16:52:22 --> Helper loaded: form_helper
INFO - 2018-10-23 16:52:22 --> Helper loaded: language_helper
DEBUG - 2018-10-23 16:52:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 16:52:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 16:52:22 --> User Agent Class Initialized
INFO - 2018-10-23 16:52:22 --> Controller Class Initialized
INFO - 2018-10-23 16:52:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 16:52:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 16:52:22 --> Helper loaded: custom_helper
INFO - 2018-10-23 16:52:22 --> Pixel_Model class loaded
INFO - 2018-10-23 16:52:22 --> Database Driver Class Initialized
INFO - 2018-10-23 16:52:22 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 16:52:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 16:52:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 16:52:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-23 16:52:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 16:52:22 --> Final output sent to browser
DEBUG - 2018-10-23 16:52:22 --> Total execution time: 0.5290
INFO - 2018-10-23 16:52:43 --> Config Class Initialized
INFO - 2018-10-23 16:52:43 --> Hooks Class Initialized
DEBUG - 2018-10-23 16:52:43 --> UTF-8 Support Enabled
INFO - 2018-10-23 16:52:43 --> Utf8 Class Initialized
INFO - 2018-10-23 16:52:43 --> URI Class Initialized
DEBUG - 2018-10-23 16:52:43 --> No URI present. Default controller set.
INFO - 2018-10-23 16:52:43 --> Router Class Initialized
INFO - 2018-10-23 16:52:43 --> Output Class Initialized
INFO - 2018-10-23 16:52:43 --> Security Class Initialized
DEBUG - 2018-10-23 16:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 16:52:43 --> CSRF cookie sent
INFO - 2018-10-23 16:52:43 --> Input Class Initialized
INFO - 2018-10-23 16:52:43 --> Language Class Initialized
INFO - 2018-10-23 16:52:43 --> Loader Class Initialized
INFO - 2018-10-23 16:52:43 --> Helper loaded: url_helper
INFO - 2018-10-23 16:52:43 --> Helper loaded: form_helper
INFO - 2018-10-23 16:52:43 --> Helper loaded: language_helper
DEBUG - 2018-10-23 16:52:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 16:52:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 16:52:43 --> User Agent Class Initialized
INFO - 2018-10-23 16:52:43 --> Controller Class Initialized
INFO - 2018-10-23 16:52:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 16:52:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 16:52:43 --> Helper loaded: custom_helper
INFO - 2018-10-23 16:52:43 --> Pixel_Model class loaded
INFO - 2018-10-23 16:52:43 --> Database Driver Class Initialized
INFO - 2018-10-23 16:52:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 16:52:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 16:52:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 16:52:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-23 16:52:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 16:52:44 --> Final output sent to browser
DEBUG - 2018-10-23 16:52:44 --> Total execution time: 0.5481
INFO - 2018-10-23 16:52:55 --> Config Class Initialized
INFO - 2018-10-23 16:52:55 --> Hooks Class Initialized
DEBUG - 2018-10-23 16:52:55 --> UTF-8 Support Enabled
INFO - 2018-10-23 16:52:55 --> Utf8 Class Initialized
INFO - 2018-10-23 16:52:55 --> URI Class Initialized
INFO - 2018-10-23 16:52:55 --> Router Class Initialized
INFO - 2018-10-23 16:52:55 --> Output Class Initialized
INFO - 2018-10-23 16:52:55 --> Security Class Initialized
DEBUG - 2018-10-23 16:52:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 16:52:55 --> CSRF cookie sent
INFO - 2018-10-23 16:52:55 --> CSRF token verified
INFO - 2018-10-23 16:52:55 --> Input Class Initialized
INFO - 2018-10-23 16:52:55 --> Language Class Initialized
INFO - 2018-10-23 16:52:55 --> Loader Class Initialized
INFO - 2018-10-23 16:52:55 --> Helper loaded: url_helper
INFO - 2018-10-23 16:52:55 --> Helper loaded: form_helper
INFO - 2018-10-23 16:52:55 --> Helper loaded: language_helper
DEBUG - 2018-10-23 16:52:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 16:52:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 16:52:55 --> User Agent Class Initialized
INFO - 2018-10-23 16:52:55 --> Controller Class Initialized
INFO - 2018-10-23 16:52:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 16:52:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 16:52:55 --> Helper loaded: custom_helper
INFO - 2018-10-23 16:52:55 --> Pixel_Model class loaded
INFO - 2018-10-23 16:52:55 --> Database Driver Class Initialized
INFO - 2018-10-23 16:52:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 16:52:55 --> Form Validation Class Initialized
INFO - 2018-10-23 16:52:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 16:52:55 --> Database Driver Class Initialized
INFO - 2018-10-23 16:52:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 16:52:55 --> Config Class Initialized
INFO - 2018-10-23 16:52:55 --> Hooks Class Initialized
DEBUG - 2018-10-23 16:52:55 --> UTF-8 Support Enabled
INFO - 2018-10-23 16:52:56 --> Utf8 Class Initialized
INFO - 2018-10-23 16:52:56 --> URI Class Initialized
INFO - 2018-10-23 16:52:56 --> Router Class Initialized
INFO - 2018-10-23 16:52:56 --> Output Class Initialized
INFO - 2018-10-23 16:52:56 --> Security Class Initialized
DEBUG - 2018-10-23 16:52:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 16:52:56 --> CSRF cookie sent
INFO - 2018-10-23 16:52:56 --> Input Class Initialized
INFO - 2018-10-23 16:52:56 --> Language Class Initialized
INFO - 2018-10-23 16:52:56 --> Loader Class Initialized
INFO - 2018-10-23 16:52:56 --> Helper loaded: url_helper
INFO - 2018-10-23 16:52:56 --> Helper loaded: form_helper
INFO - 2018-10-23 16:52:56 --> Helper loaded: language_helper
DEBUG - 2018-10-23 16:52:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 16:52:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 16:52:56 --> User Agent Class Initialized
INFO - 2018-10-23 16:52:56 --> Controller Class Initialized
INFO - 2018-10-23 16:52:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 16:52:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 16:52:56 --> Helper loaded: custom_helper
INFO - 2018-10-23 16:52:56 --> Pixel_Model class loaded
INFO - 2018-10-23 16:52:56 --> Database Driver Class Initialized
INFO - 2018-10-23 16:52:56 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 16:52:56 --> Database Driver Class Initialized
INFO - 2018-10-23 16:52:56 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 16:52:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 16:52:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 16:52:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 16:52:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 16:52:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 16:52:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 16:52:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-23 16:52:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 16:52:56 --> Final output sent to browser
DEBUG - 2018-10-23 16:52:56 --> Total execution time: 0.6952
INFO - 2018-10-23 16:54:02 --> Config Class Initialized
INFO - 2018-10-23 16:54:02 --> Hooks Class Initialized
DEBUG - 2018-10-23 16:54:02 --> UTF-8 Support Enabled
INFO - 2018-10-23 16:54:02 --> Utf8 Class Initialized
INFO - 2018-10-23 16:54:02 --> URI Class Initialized
DEBUG - 2018-10-23 16:54:02 --> No URI present. Default controller set.
INFO - 2018-10-23 16:54:02 --> Router Class Initialized
INFO - 2018-10-23 16:54:02 --> Output Class Initialized
INFO - 2018-10-23 16:54:02 --> Security Class Initialized
DEBUG - 2018-10-23 16:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 16:54:02 --> CSRF cookie sent
INFO - 2018-10-23 16:54:02 --> Input Class Initialized
INFO - 2018-10-23 16:54:02 --> Language Class Initialized
INFO - 2018-10-23 16:54:02 --> Loader Class Initialized
INFO - 2018-10-23 16:54:02 --> Helper loaded: url_helper
INFO - 2018-10-23 16:54:02 --> Helper loaded: form_helper
INFO - 2018-10-23 16:54:02 --> Helper loaded: language_helper
DEBUG - 2018-10-23 16:54:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 16:54:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 16:54:02 --> User Agent Class Initialized
INFO - 2018-10-23 16:54:02 --> Controller Class Initialized
INFO - 2018-10-23 16:54:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 16:54:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 16:54:02 --> Helper loaded: custom_helper
INFO - 2018-10-23 16:54:02 --> Pixel_Model class loaded
INFO - 2018-10-23 16:54:02 --> Database Driver Class Initialized
INFO - 2018-10-23 16:54:02 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 16:54:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 16:54:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 16:54:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-23 16:54:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 16:54:02 --> Final output sent to browser
DEBUG - 2018-10-23 16:54:02 --> Total execution time: 0.5254
INFO - 2018-10-23 16:54:05 --> Config Class Initialized
INFO - 2018-10-23 16:54:06 --> Hooks Class Initialized
DEBUG - 2018-10-23 16:54:06 --> UTF-8 Support Enabled
INFO - 2018-10-23 16:54:06 --> Utf8 Class Initialized
INFO - 2018-10-23 16:54:06 --> URI Class Initialized
INFO - 2018-10-23 16:54:06 --> Router Class Initialized
INFO - 2018-10-23 16:54:06 --> Output Class Initialized
INFO - 2018-10-23 16:54:06 --> Security Class Initialized
DEBUG - 2018-10-23 16:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 16:54:06 --> CSRF cookie sent
INFO - 2018-10-23 16:54:06 --> CSRF token verified
INFO - 2018-10-23 16:54:06 --> Input Class Initialized
INFO - 2018-10-23 16:54:06 --> Language Class Initialized
INFO - 2018-10-23 16:54:06 --> Loader Class Initialized
INFO - 2018-10-23 16:54:06 --> Helper loaded: url_helper
INFO - 2018-10-23 16:54:06 --> Helper loaded: form_helper
INFO - 2018-10-23 16:54:06 --> Helper loaded: language_helper
DEBUG - 2018-10-23 16:54:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 16:54:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 16:54:06 --> User Agent Class Initialized
INFO - 2018-10-23 16:54:06 --> Controller Class Initialized
INFO - 2018-10-23 16:54:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 16:54:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 16:54:06 --> Helper loaded: custom_helper
INFO - 2018-10-23 16:54:06 --> Pixel_Model class loaded
INFO - 2018-10-23 16:54:06 --> Database Driver Class Initialized
INFO - 2018-10-23 16:54:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 16:54:06 --> Form Validation Class Initialized
INFO - 2018-10-23 16:54:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 16:54:06 --> Database Driver Class Initialized
INFO - 2018-10-23 16:54:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 16:54:06 --> Config Class Initialized
INFO - 2018-10-23 16:54:06 --> Hooks Class Initialized
DEBUG - 2018-10-23 16:54:06 --> UTF-8 Support Enabled
INFO - 2018-10-23 16:54:06 --> Utf8 Class Initialized
INFO - 2018-10-23 16:54:06 --> URI Class Initialized
INFO - 2018-10-23 16:54:06 --> Router Class Initialized
INFO - 2018-10-23 16:54:06 --> Output Class Initialized
INFO - 2018-10-23 16:54:06 --> Security Class Initialized
DEBUG - 2018-10-23 16:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 16:54:06 --> CSRF cookie sent
INFO - 2018-10-23 16:54:06 --> Input Class Initialized
INFO - 2018-10-23 16:54:06 --> Language Class Initialized
INFO - 2018-10-23 16:54:06 --> Loader Class Initialized
INFO - 2018-10-23 16:54:06 --> Helper loaded: url_helper
INFO - 2018-10-23 16:54:06 --> Helper loaded: form_helper
INFO - 2018-10-23 16:54:06 --> Helper loaded: language_helper
DEBUG - 2018-10-23 16:54:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 16:54:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 16:54:06 --> User Agent Class Initialized
INFO - 2018-10-23 16:54:06 --> Controller Class Initialized
INFO - 2018-10-23 16:54:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 16:54:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 16:54:07 --> Helper loaded: custom_helper
INFO - 2018-10-23 16:54:07 --> Pixel_Model class loaded
INFO - 2018-10-23 16:54:07 --> Database Driver Class Initialized
INFO - 2018-10-23 16:54:07 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 16:54:07 --> Database Driver Class Initialized
INFO - 2018-10-23 16:54:07 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 16:54:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 16:54:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 16:54:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 16:54:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 16:54:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 16:54:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 16:54:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-23 16:54:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 16:54:07 --> Final output sent to browser
DEBUG - 2018-10-23 16:54:07 --> Total execution time: 0.6612
INFO - 2018-10-23 16:54:33 --> Config Class Initialized
INFO - 2018-10-23 16:54:33 --> Hooks Class Initialized
DEBUG - 2018-10-23 16:54:33 --> UTF-8 Support Enabled
INFO - 2018-10-23 16:54:33 --> Utf8 Class Initialized
INFO - 2018-10-23 16:54:34 --> URI Class Initialized
DEBUG - 2018-10-23 16:54:34 --> No URI present. Default controller set.
INFO - 2018-10-23 16:54:34 --> Router Class Initialized
INFO - 2018-10-23 16:54:34 --> Output Class Initialized
INFO - 2018-10-23 16:54:34 --> Security Class Initialized
DEBUG - 2018-10-23 16:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 16:54:34 --> CSRF cookie sent
INFO - 2018-10-23 16:54:34 --> Input Class Initialized
INFO - 2018-10-23 16:54:34 --> Language Class Initialized
INFO - 2018-10-23 16:54:34 --> Loader Class Initialized
INFO - 2018-10-23 16:54:34 --> Helper loaded: url_helper
INFO - 2018-10-23 16:54:34 --> Helper loaded: form_helper
INFO - 2018-10-23 16:54:34 --> Helper loaded: language_helper
DEBUG - 2018-10-23 16:54:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 16:54:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 16:54:34 --> User Agent Class Initialized
INFO - 2018-10-23 16:54:34 --> Controller Class Initialized
INFO - 2018-10-23 16:54:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 16:54:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 16:54:34 --> Helper loaded: custom_helper
INFO - 2018-10-23 16:54:34 --> Pixel_Model class loaded
INFO - 2018-10-23 16:54:34 --> Database Driver Class Initialized
INFO - 2018-10-23 16:54:34 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 16:54:34 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 16:54:34 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 16:54:34 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-23 16:54:34 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 16:54:34 --> Final output sent to browser
DEBUG - 2018-10-23 16:54:34 --> Total execution time: 0.5402
INFO - 2018-10-23 16:54:35 --> Config Class Initialized
INFO - 2018-10-23 16:54:35 --> Hooks Class Initialized
DEBUG - 2018-10-23 16:54:35 --> UTF-8 Support Enabled
INFO - 2018-10-23 16:54:35 --> Utf8 Class Initialized
INFO - 2018-10-23 16:54:35 --> URI Class Initialized
DEBUG - 2018-10-23 16:54:35 --> No URI present. Default controller set.
INFO - 2018-10-23 16:54:35 --> Router Class Initialized
INFO - 2018-10-23 16:54:35 --> Output Class Initialized
INFO - 2018-10-23 16:54:35 --> Security Class Initialized
DEBUG - 2018-10-23 16:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 16:54:36 --> CSRF cookie sent
INFO - 2018-10-23 16:54:36 --> Input Class Initialized
INFO - 2018-10-23 16:54:36 --> Language Class Initialized
INFO - 2018-10-23 16:54:36 --> Loader Class Initialized
INFO - 2018-10-23 16:54:36 --> Helper loaded: url_helper
INFO - 2018-10-23 16:54:36 --> Helper loaded: form_helper
INFO - 2018-10-23 16:54:36 --> Helper loaded: language_helper
DEBUG - 2018-10-23 16:54:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 16:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 16:54:36 --> User Agent Class Initialized
INFO - 2018-10-23 16:54:36 --> Controller Class Initialized
INFO - 2018-10-23 16:54:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 16:54:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 16:54:36 --> Helper loaded: custom_helper
INFO - 2018-10-23 16:54:36 --> Pixel_Model class loaded
INFO - 2018-10-23 16:54:36 --> Database Driver Class Initialized
INFO - 2018-10-23 16:54:36 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 16:54:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 16:54:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 16:54:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-23 16:54:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 16:54:36 --> Final output sent to browser
DEBUG - 2018-10-23 16:54:36 --> Total execution time: 0.5936
INFO - 2018-10-23 16:54:40 --> Config Class Initialized
INFO - 2018-10-23 16:54:40 --> Hooks Class Initialized
DEBUG - 2018-10-23 16:54:40 --> UTF-8 Support Enabled
INFO - 2018-10-23 16:54:40 --> Utf8 Class Initialized
INFO - 2018-10-23 16:54:41 --> URI Class Initialized
INFO - 2018-10-23 16:54:41 --> Router Class Initialized
INFO - 2018-10-23 16:54:41 --> Output Class Initialized
INFO - 2018-10-23 16:54:41 --> Security Class Initialized
DEBUG - 2018-10-23 16:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 16:54:41 --> CSRF cookie sent
INFO - 2018-10-23 16:54:41 --> CSRF token verified
INFO - 2018-10-23 16:54:41 --> Input Class Initialized
INFO - 2018-10-23 16:54:41 --> Language Class Initialized
INFO - 2018-10-23 16:54:41 --> Loader Class Initialized
INFO - 2018-10-23 16:54:41 --> Helper loaded: url_helper
INFO - 2018-10-23 16:54:41 --> Helper loaded: form_helper
INFO - 2018-10-23 16:54:41 --> Helper loaded: language_helper
DEBUG - 2018-10-23 16:54:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 16:54:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 16:54:41 --> User Agent Class Initialized
INFO - 2018-10-23 16:54:41 --> Controller Class Initialized
INFO - 2018-10-23 16:54:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 16:54:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 16:54:41 --> Helper loaded: custom_helper
INFO - 2018-10-23 16:54:41 --> Pixel_Model class loaded
INFO - 2018-10-23 16:54:41 --> Database Driver Class Initialized
INFO - 2018-10-23 16:54:41 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 16:54:41 --> Form Validation Class Initialized
INFO - 2018-10-23 16:54:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-23 16:54:41 --> Database Driver Class Initialized
INFO - 2018-10-23 16:54:41 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 16:54:41 --> Config Class Initialized
INFO - 2018-10-23 16:54:41 --> Hooks Class Initialized
DEBUG - 2018-10-23 16:54:41 --> UTF-8 Support Enabled
INFO - 2018-10-23 16:54:41 --> Utf8 Class Initialized
INFO - 2018-10-23 16:54:41 --> URI Class Initialized
INFO - 2018-10-23 16:54:41 --> Router Class Initialized
INFO - 2018-10-23 16:54:41 --> Output Class Initialized
INFO - 2018-10-23 16:54:41 --> Security Class Initialized
DEBUG - 2018-10-23 16:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 16:54:41 --> CSRF cookie sent
INFO - 2018-10-23 16:54:41 --> Input Class Initialized
INFO - 2018-10-23 16:54:41 --> Language Class Initialized
INFO - 2018-10-23 16:54:41 --> Loader Class Initialized
INFO - 2018-10-23 16:54:41 --> Helper loaded: url_helper
INFO - 2018-10-23 16:54:41 --> Helper loaded: form_helper
INFO - 2018-10-23 16:54:41 --> Helper loaded: language_helper
DEBUG - 2018-10-23 16:54:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 16:54:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 16:54:41 --> User Agent Class Initialized
INFO - 2018-10-23 16:54:41 --> Controller Class Initialized
INFO - 2018-10-23 16:54:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 16:54:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 16:54:42 --> Helper loaded: custom_helper
INFO - 2018-10-23 16:54:42 --> Pixel_Model class loaded
INFO - 2018-10-23 16:54:42 --> Database Driver Class Initialized
INFO - 2018-10-23 16:54:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 16:54:42 --> Database Driver Class Initialized
INFO - 2018-10-23 16:54:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 16:54:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 16:54:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 16:54:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 16:54:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 16:54:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 16:54:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 16:54:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-23 16:54:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 16:54:42 --> Final output sent to browser
DEBUG - 2018-10-23 16:54:42 --> Total execution time: 0.6705
INFO - 2018-10-23 16:54:57 --> Config Class Initialized
INFO - 2018-10-23 16:54:57 --> Hooks Class Initialized
DEBUG - 2018-10-23 16:54:57 --> UTF-8 Support Enabled
INFO - 2018-10-23 16:54:57 --> Utf8 Class Initialized
INFO - 2018-10-23 16:54:57 --> URI Class Initialized
INFO - 2018-10-23 16:54:57 --> Router Class Initialized
INFO - 2018-10-23 16:54:57 --> Output Class Initialized
INFO - 2018-10-23 16:54:57 --> Security Class Initialized
DEBUG - 2018-10-23 16:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 16:54:57 --> CSRF cookie sent
INFO - 2018-10-23 16:54:57 --> Input Class Initialized
INFO - 2018-10-23 16:54:57 --> Language Class Initialized
INFO - 2018-10-23 16:54:57 --> Loader Class Initialized
INFO - 2018-10-23 16:54:57 --> Helper loaded: url_helper
INFO - 2018-10-23 16:54:57 --> Helper loaded: form_helper
INFO - 2018-10-23 16:54:57 --> Helper loaded: language_helper
DEBUG - 2018-10-23 16:54:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 16:54:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 16:54:57 --> User Agent Class Initialized
INFO - 2018-10-23 16:54:57 --> Controller Class Initialized
INFO - 2018-10-23 16:54:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 16:54:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 16:54:57 --> Helper loaded: custom_helper
INFO - 2018-10-23 16:54:57 --> Pixel_Model class loaded
INFO - 2018-10-23 16:54:57 --> Database Driver Class Initialized
INFO - 2018-10-23 16:54:57 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 16:54:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 16:54:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 16:54:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 16:54:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 16:54:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 16:54:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 16:54:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-23 16:54:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 16:54:58 --> Final output sent to browser
DEBUG - 2018-10-23 16:54:58 --> Total execution time: 0.6215
INFO - 2018-10-23 16:54:59 --> Config Class Initialized
INFO - 2018-10-23 16:54:59 --> Hooks Class Initialized
DEBUG - 2018-10-23 16:54:59 --> UTF-8 Support Enabled
INFO - 2018-10-23 16:54:59 --> Utf8 Class Initialized
INFO - 2018-10-23 16:54:59 --> URI Class Initialized
DEBUG - 2018-10-23 16:54:59 --> No URI present. Default controller set.
INFO - 2018-10-23 16:54:59 --> Router Class Initialized
INFO - 2018-10-23 16:54:59 --> Output Class Initialized
INFO - 2018-10-23 16:54:59 --> Security Class Initialized
DEBUG - 2018-10-23 16:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 16:54:59 --> CSRF cookie sent
INFO - 2018-10-23 16:54:59 --> Input Class Initialized
INFO - 2018-10-23 16:54:59 --> Language Class Initialized
INFO - 2018-10-23 16:54:59 --> Loader Class Initialized
INFO - 2018-10-23 16:54:59 --> Helper loaded: url_helper
INFO - 2018-10-23 16:54:59 --> Helper loaded: form_helper
INFO - 2018-10-23 16:54:59 --> Helper loaded: language_helper
DEBUG - 2018-10-23 16:54:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 16:54:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 16:54:59 --> User Agent Class Initialized
INFO - 2018-10-23 16:54:59 --> Controller Class Initialized
INFO - 2018-10-23 16:54:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 16:54:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 16:54:59 --> Helper loaded: custom_helper
INFO - 2018-10-23 16:54:59 --> Pixel_Model class loaded
INFO - 2018-10-23 16:54:59 --> Database Driver Class Initialized
INFO - 2018-10-23 16:55:00 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 16:55:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 16:55:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 16:55:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-23 16:55:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 16:55:00 --> Final output sent to browser
DEBUG - 2018-10-23 16:55:00 --> Total execution time: 0.5723
INFO - 2018-10-23 16:55:00 --> Config Class Initialized
INFO - 2018-10-23 16:55:00 --> Hooks Class Initialized
DEBUG - 2018-10-23 16:55:00 --> UTF-8 Support Enabled
INFO - 2018-10-23 16:55:00 --> Utf8 Class Initialized
INFO - 2018-10-23 16:55:00 --> URI Class Initialized
DEBUG - 2018-10-23 16:55:00 --> No URI present. Default controller set.
INFO - 2018-10-23 16:55:00 --> Router Class Initialized
INFO - 2018-10-23 16:55:00 --> Output Class Initialized
INFO - 2018-10-23 16:55:00 --> Security Class Initialized
DEBUG - 2018-10-23 16:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 16:55:01 --> CSRF cookie sent
INFO - 2018-10-23 16:55:01 --> Input Class Initialized
INFO - 2018-10-23 16:55:01 --> Language Class Initialized
INFO - 2018-10-23 16:55:01 --> Loader Class Initialized
INFO - 2018-10-23 16:55:01 --> Helper loaded: url_helper
INFO - 2018-10-23 16:55:01 --> Helper loaded: form_helper
INFO - 2018-10-23 16:55:01 --> Helper loaded: language_helper
DEBUG - 2018-10-23 16:55:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 16:55:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 16:55:01 --> User Agent Class Initialized
INFO - 2018-10-23 16:55:01 --> Controller Class Initialized
INFO - 2018-10-23 16:55:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 16:55:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 16:55:01 --> Helper loaded: custom_helper
INFO - 2018-10-23 16:55:01 --> Pixel_Model class loaded
INFO - 2018-10-23 16:55:01 --> Database Driver Class Initialized
INFO - 2018-10-23 16:55:01 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 16:55:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 16:55:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 16:55:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-23 16:55:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 16:55:01 --> Final output sent to browser
DEBUG - 2018-10-23 16:55:01 --> Total execution time: 0.5979
INFO - 2018-10-23 16:55:04 --> Config Class Initialized
INFO - 2018-10-23 16:55:04 --> Hooks Class Initialized
DEBUG - 2018-10-23 16:55:05 --> UTF-8 Support Enabled
INFO - 2018-10-23 16:55:05 --> Utf8 Class Initialized
INFO - 2018-10-23 16:55:05 --> URI Class Initialized
INFO - 2018-10-23 16:55:05 --> Router Class Initialized
INFO - 2018-10-23 16:55:05 --> Output Class Initialized
INFO - 2018-10-23 16:55:05 --> Security Class Initialized
DEBUG - 2018-10-23 16:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 16:55:05 --> CSRF cookie sent
INFO - 2018-10-23 16:55:05 --> CSRF token verified
INFO - 2018-10-23 16:55:05 --> Input Class Initialized
INFO - 2018-10-23 16:55:05 --> Language Class Initialized
INFO - 2018-10-23 16:55:05 --> Loader Class Initialized
INFO - 2018-10-23 16:55:05 --> Helper loaded: url_helper
INFO - 2018-10-23 16:55:05 --> Helper loaded: form_helper
INFO - 2018-10-23 16:55:05 --> Helper loaded: language_helper
DEBUG - 2018-10-23 16:55:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 16:55:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 16:55:05 --> User Agent Class Initialized
INFO - 2018-10-23 16:55:05 --> Controller Class Initialized
INFO - 2018-10-23 16:55:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 16:55:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 16:55:05 --> Helper loaded: custom_helper
INFO - 2018-10-23 16:55:05 --> Pixel_Model class loaded
INFO - 2018-10-23 16:55:05 --> Database Driver Class Initialized
INFO - 2018-10-23 16:55:05 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 16:55:50 --> Config Class Initialized
INFO - 2018-10-23 16:55:50 --> Hooks Class Initialized
DEBUG - 2018-10-23 16:55:50 --> UTF-8 Support Enabled
INFO - 2018-10-23 16:55:50 --> Utf8 Class Initialized
INFO - 2018-10-23 16:55:50 --> URI Class Initialized
DEBUG - 2018-10-23 16:55:51 --> No URI present. Default controller set.
INFO - 2018-10-23 16:55:51 --> Router Class Initialized
INFO - 2018-10-23 16:55:51 --> Output Class Initialized
INFO - 2018-10-23 16:55:51 --> Security Class Initialized
DEBUG - 2018-10-23 16:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 16:55:51 --> CSRF cookie sent
INFO - 2018-10-23 16:55:51 --> Input Class Initialized
INFO - 2018-10-23 16:55:51 --> Language Class Initialized
INFO - 2018-10-23 16:55:51 --> Loader Class Initialized
INFO - 2018-10-23 16:55:51 --> Helper loaded: url_helper
INFO - 2018-10-23 16:55:51 --> Helper loaded: form_helper
INFO - 2018-10-23 16:55:51 --> Helper loaded: language_helper
DEBUG - 2018-10-23 16:55:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 16:55:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 16:55:51 --> User Agent Class Initialized
INFO - 2018-10-23 16:55:51 --> Controller Class Initialized
INFO - 2018-10-23 16:55:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 16:55:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 16:55:51 --> Helper loaded: custom_helper
INFO - 2018-10-23 16:55:51 --> Pixel_Model class loaded
INFO - 2018-10-23 16:55:51 --> Database Driver Class Initialized
INFO - 2018-10-23 16:55:51 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 16:55:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 16:55:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 16:55:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-23 16:55:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 16:55:51 --> Final output sent to browser
DEBUG - 2018-10-23 16:55:51 --> Total execution time: 0.5669
INFO - 2018-10-23 16:55:52 --> Config Class Initialized
INFO - 2018-10-23 16:55:52 --> Hooks Class Initialized
DEBUG - 2018-10-23 16:55:52 --> UTF-8 Support Enabled
INFO - 2018-10-23 16:55:52 --> Utf8 Class Initialized
INFO - 2018-10-23 16:55:52 --> URI Class Initialized
DEBUG - 2018-10-23 16:55:52 --> No URI present. Default controller set.
INFO - 2018-10-23 16:55:52 --> Router Class Initialized
INFO - 2018-10-23 16:55:52 --> Output Class Initialized
INFO - 2018-10-23 16:55:52 --> Security Class Initialized
DEBUG - 2018-10-23 16:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 16:55:52 --> CSRF cookie sent
INFO - 2018-10-23 16:55:52 --> Input Class Initialized
INFO - 2018-10-23 16:55:52 --> Language Class Initialized
INFO - 2018-10-23 16:55:52 --> Loader Class Initialized
INFO - 2018-10-23 16:55:52 --> Helper loaded: url_helper
INFO - 2018-10-23 16:55:52 --> Helper loaded: form_helper
INFO - 2018-10-23 16:55:52 --> Helper loaded: language_helper
DEBUG - 2018-10-23 16:55:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 16:55:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 16:55:52 --> User Agent Class Initialized
INFO - 2018-10-23 16:55:52 --> Controller Class Initialized
INFO - 2018-10-23 16:55:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 16:55:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 16:55:52 --> Helper loaded: custom_helper
INFO - 2018-10-23 16:55:52 --> Pixel_Model class loaded
INFO - 2018-10-23 16:55:52 --> Database Driver Class Initialized
INFO - 2018-10-23 16:55:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 16:55:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 16:55:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 16:55:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-23 16:55:53 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 16:55:53 --> Final output sent to browser
DEBUG - 2018-10-23 16:55:53 --> Total execution time: 0.5526
INFO - 2018-10-23 16:55:53 --> Config Class Initialized
INFO - 2018-10-23 16:55:53 --> Hooks Class Initialized
DEBUG - 2018-10-23 16:55:53 --> UTF-8 Support Enabled
INFO - 2018-10-23 16:55:53 --> Utf8 Class Initialized
INFO - 2018-10-23 16:55:53 --> URI Class Initialized
DEBUG - 2018-10-23 16:55:53 --> No URI present. Default controller set.
INFO - 2018-10-23 16:55:53 --> Router Class Initialized
INFO - 2018-10-23 16:55:53 --> Output Class Initialized
INFO - 2018-10-23 16:55:53 --> Security Class Initialized
DEBUG - 2018-10-23 16:55:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 16:55:53 --> CSRF cookie sent
INFO - 2018-10-23 16:55:53 --> Input Class Initialized
INFO - 2018-10-23 16:55:53 --> Language Class Initialized
INFO - 2018-10-23 16:55:53 --> Loader Class Initialized
INFO - 2018-10-23 16:55:53 --> Helper loaded: url_helper
INFO - 2018-10-23 16:55:53 --> Helper loaded: form_helper
INFO - 2018-10-23 16:55:53 --> Helper loaded: language_helper
DEBUG - 2018-10-23 16:55:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 16:55:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 16:55:53 --> User Agent Class Initialized
INFO - 2018-10-23 16:55:53 --> Controller Class Initialized
INFO - 2018-10-23 16:55:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 16:55:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 16:55:53 --> Helper loaded: custom_helper
INFO - 2018-10-23 16:55:53 --> Pixel_Model class loaded
INFO - 2018-10-23 16:55:53 --> Database Driver Class Initialized
INFO - 2018-10-23 16:55:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 16:55:53 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 16:55:53 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 16:55:53 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-23 16:55:53 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 16:55:53 --> Final output sent to browser
DEBUG - 2018-10-23 16:55:53 --> Total execution time: 0.5566
INFO - 2018-10-23 16:55:58 --> Config Class Initialized
INFO - 2018-10-23 16:55:58 --> Hooks Class Initialized
DEBUG - 2018-10-23 16:55:58 --> UTF-8 Support Enabled
INFO - 2018-10-23 16:55:58 --> Utf8 Class Initialized
INFO - 2018-10-23 16:55:58 --> URI Class Initialized
INFO - 2018-10-23 16:55:58 --> Router Class Initialized
INFO - 2018-10-23 16:55:58 --> Output Class Initialized
INFO - 2018-10-23 16:55:58 --> Security Class Initialized
DEBUG - 2018-10-23 16:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 16:55:58 --> CSRF cookie sent
INFO - 2018-10-23 16:55:58 --> CSRF token verified
INFO - 2018-10-23 16:55:58 --> Input Class Initialized
INFO - 2018-10-23 16:55:58 --> Language Class Initialized
INFO - 2018-10-23 16:55:58 --> Loader Class Initialized
INFO - 2018-10-23 16:55:58 --> Helper loaded: url_helper
INFO - 2018-10-23 16:55:58 --> Helper loaded: form_helper
INFO - 2018-10-23 16:55:58 --> Helper loaded: language_helper
DEBUG - 2018-10-23 16:55:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 16:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 16:55:58 --> User Agent Class Initialized
INFO - 2018-10-23 16:55:58 --> Controller Class Initialized
INFO - 2018-10-23 16:55:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 16:55:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 16:55:58 --> Helper loaded: custom_helper
INFO - 2018-10-23 16:55:58 --> Pixel_Model class loaded
INFO - 2018-10-23 16:55:58 --> Database Driver Class Initialized
INFO - 2018-10-23 16:55:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 16:56:09 --> Config Class Initialized
INFO - 2018-10-23 16:56:09 --> Hooks Class Initialized
DEBUG - 2018-10-23 16:56:09 --> UTF-8 Support Enabled
INFO - 2018-10-23 16:56:09 --> Utf8 Class Initialized
INFO - 2018-10-23 16:56:09 --> URI Class Initialized
DEBUG - 2018-10-23 16:56:09 --> No URI present. Default controller set.
INFO - 2018-10-23 16:56:09 --> Router Class Initialized
INFO - 2018-10-23 16:56:09 --> Output Class Initialized
INFO - 2018-10-23 16:56:09 --> Security Class Initialized
DEBUG - 2018-10-23 16:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 16:56:09 --> CSRF cookie sent
INFO - 2018-10-23 16:56:10 --> Input Class Initialized
INFO - 2018-10-23 16:56:10 --> Language Class Initialized
INFO - 2018-10-23 16:56:10 --> Loader Class Initialized
INFO - 2018-10-23 16:56:10 --> Helper loaded: url_helper
INFO - 2018-10-23 16:56:10 --> Helper loaded: form_helper
INFO - 2018-10-23 16:56:10 --> Helper loaded: language_helper
DEBUG - 2018-10-23 16:56:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 16:56:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 16:56:10 --> User Agent Class Initialized
INFO - 2018-10-23 16:56:10 --> Controller Class Initialized
INFO - 2018-10-23 16:56:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 16:56:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 16:56:10 --> Helper loaded: custom_helper
INFO - 2018-10-23 16:56:10 --> Pixel_Model class loaded
INFO - 2018-10-23 16:56:10 --> Database Driver Class Initialized
INFO - 2018-10-23 16:56:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 16:56:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 16:56:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 16:56:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-23 16:56:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 16:56:10 --> Final output sent to browser
DEBUG - 2018-10-23 16:56:10 --> Total execution time: 0.5280
INFO - 2018-10-23 16:56:25 --> Config Class Initialized
INFO - 2018-10-23 16:56:25 --> Hooks Class Initialized
DEBUG - 2018-10-23 16:56:25 --> UTF-8 Support Enabled
INFO - 2018-10-23 16:56:25 --> Utf8 Class Initialized
INFO - 2018-10-23 16:56:25 --> URI Class Initialized
DEBUG - 2018-10-23 16:56:25 --> No URI present. Default controller set.
INFO - 2018-10-23 16:56:25 --> Router Class Initialized
INFO - 2018-10-23 16:56:25 --> Output Class Initialized
INFO - 2018-10-23 16:56:25 --> Security Class Initialized
DEBUG - 2018-10-23 16:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 16:56:25 --> CSRF cookie sent
INFO - 2018-10-23 16:56:25 --> Input Class Initialized
INFO - 2018-10-23 16:56:25 --> Language Class Initialized
INFO - 2018-10-23 16:56:25 --> Loader Class Initialized
INFO - 2018-10-23 16:56:25 --> Helper loaded: url_helper
INFO - 2018-10-23 16:56:25 --> Helper loaded: form_helper
INFO - 2018-10-23 16:56:25 --> Helper loaded: language_helper
DEBUG - 2018-10-23 16:56:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 16:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 16:56:25 --> User Agent Class Initialized
INFO - 2018-10-23 16:56:25 --> Controller Class Initialized
INFO - 2018-10-23 16:56:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 16:56:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 16:56:25 --> Helper loaded: custom_helper
INFO - 2018-10-23 16:56:25 --> Pixel_Model class loaded
INFO - 2018-10-23 16:56:25 --> Database Driver Class Initialized
INFO - 2018-10-23 16:56:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 16:56:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 16:56:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 16:56:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-23 16:56:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 16:56:26 --> Final output sent to browser
DEBUG - 2018-10-23 16:56:26 --> Total execution time: 0.5577
INFO - 2018-10-23 16:56:27 --> Config Class Initialized
INFO - 2018-10-23 16:56:27 --> Hooks Class Initialized
DEBUG - 2018-10-23 16:56:27 --> UTF-8 Support Enabled
INFO - 2018-10-23 16:56:27 --> Utf8 Class Initialized
INFO - 2018-10-23 16:56:27 --> URI Class Initialized
DEBUG - 2018-10-23 16:56:27 --> No URI present. Default controller set.
INFO - 2018-10-23 16:56:27 --> Router Class Initialized
INFO - 2018-10-23 16:56:27 --> Output Class Initialized
INFO - 2018-10-23 16:56:27 --> Security Class Initialized
DEBUG - 2018-10-23 16:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 16:56:27 --> CSRF cookie sent
INFO - 2018-10-23 16:56:27 --> Input Class Initialized
INFO - 2018-10-23 16:56:27 --> Language Class Initialized
INFO - 2018-10-23 16:56:27 --> Loader Class Initialized
INFO - 2018-10-23 16:56:27 --> Helper loaded: url_helper
INFO - 2018-10-23 16:56:27 --> Helper loaded: form_helper
INFO - 2018-10-23 16:56:27 --> Helper loaded: language_helper
DEBUG - 2018-10-23 16:56:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 16:56:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 16:56:27 --> User Agent Class Initialized
INFO - 2018-10-23 16:56:27 --> Controller Class Initialized
INFO - 2018-10-23 16:56:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 16:56:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 16:56:28 --> Helper loaded: custom_helper
INFO - 2018-10-23 16:56:28 --> Pixel_Model class loaded
INFO - 2018-10-23 16:56:28 --> Database Driver Class Initialized
INFO - 2018-10-23 16:56:28 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 16:56:28 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 16:56:28 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 16:56:28 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-23 16:56:28 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 16:56:28 --> Final output sent to browser
DEBUG - 2018-10-23 16:56:28 --> Total execution time: 0.5796
INFO - 2018-10-23 16:56:49 --> Config Class Initialized
INFO - 2018-10-23 16:56:49 --> Hooks Class Initialized
DEBUG - 2018-10-23 16:56:49 --> UTF-8 Support Enabled
INFO - 2018-10-23 16:56:49 --> Utf8 Class Initialized
INFO - 2018-10-23 16:56:49 --> URI Class Initialized
INFO - 2018-10-23 16:56:49 --> Router Class Initialized
INFO - 2018-10-23 16:56:49 --> Output Class Initialized
INFO - 2018-10-23 16:56:49 --> Security Class Initialized
DEBUG - 2018-10-23 16:56:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 16:56:49 --> CSRF cookie sent
INFO - 2018-10-23 16:56:49 --> CSRF token verified
INFO - 2018-10-23 16:56:49 --> Input Class Initialized
INFO - 2018-10-23 16:56:49 --> Language Class Initialized
INFO - 2018-10-23 16:56:49 --> Loader Class Initialized
INFO - 2018-10-23 16:56:49 --> Helper loaded: url_helper
INFO - 2018-10-23 16:56:50 --> Helper loaded: form_helper
INFO - 2018-10-23 16:56:50 --> Helper loaded: language_helper
DEBUG - 2018-10-23 16:56:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 16:56:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 16:56:50 --> User Agent Class Initialized
INFO - 2018-10-23 16:56:50 --> Controller Class Initialized
INFO - 2018-10-23 16:56:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 16:56:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 16:56:50 --> Helper loaded: custom_helper
INFO - 2018-10-23 16:56:50 --> Pixel_Model class loaded
INFO - 2018-10-23 16:56:50 --> Database Driver Class Initialized
INFO - 2018-10-23 16:56:50 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 16:56:50 --> Database Driver Class Initialized
INFO - 2018-10-23 16:56:50 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 16:56:50 --> Config Class Initialized
INFO - 2018-10-23 16:56:50 --> Hooks Class Initialized
DEBUG - 2018-10-23 16:56:50 --> UTF-8 Support Enabled
INFO - 2018-10-23 16:56:50 --> Utf8 Class Initialized
INFO - 2018-10-23 16:56:50 --> URI Class Initialized
INFO - 2018-10-23 16:56:50 --> Router Class Initialized
INFO - 2018-10-23 16:56:50 --> Output Class Initialized
INFO - 2018-10-23 16:56:50 --> Security Class Initialized
DEBUG - 2018-10-23 16:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 16:56:50 --> CSRF cookie sent
INFO - 2018-10-23 16:56:50 --> Input Class Initialized
INFO - 2018-10-23 16:56:50 --> Language Class Initialized
INFO - 2018-10-23 16:56:50 --> Loader Class Initialized
INFO - 2018-10-23 16:56:50 --> Helper loaded: url_helper
INFO - 2018-10-23 16:56:50 --> Helper loaded: form_helper
INFO - 2018-10-23 16:56:50 --> Helper loaded: language_helper
DEBUG - 2018-10-23 16:56:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 16:56:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 16:56:50 --> User Agent Class Initialized
INFO - 2018-10-23 16:56:50 --> Controller Class Initialized
INFO - 2018-10-23 16:56:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 16:56:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 16:56:50 --> Helper loaded: custom_helper
INFO - 2018-10-23 16:56:50 --> Pixel_Model class loaded
INFO - 2018-10-23 16:56:50 --> Database Driver Class Initialized
INFO - 2018-10-23 16:56:50 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 16:56:50 --> Database Driver Class Initialized
INFO - 2018-10-23 16:56:50 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 16:56:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 16:56:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 16:56:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 16:56:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 16:56:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 16:56:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 16:56:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-23 16:56:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 16:56:51 --> Final output sent to browser
DEBUG - 2018-10-23 16:56:51 --> Total execution time: 0.6831
INFO - 2018-10-23 16:59:31 --> Config Class Initialized
INFO - 2018-10-23 16:59:31 --> Hooks Class Initialized
DEBUG - 2018-10-23 16:59:31 --> UTF-8 Support Enabled
INFO - 2018-10-23 16:59:31 --> Utf8 Class Initialized
INFO - 2018-10-23 16:59:32 --> URI Class Initialized
DEBUG - 2018-10-23 16:59:32 --> No URI present. Default controller set.
INFO - 2018-10-23 16:59:32 --> Router Class Initialized
INFO - 2018-10-23 16:59:32 --> Output Class Initialized
INFO - 2018-10-23 16:59:32 --> Security Class Initialized
DEBUG - 2018-10-23 16:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 16:59:32 --> CSRF cookie sent
INFO - 2018-10-23 16:59:32 --> Input Class Initialized
INFO - 2018-10-23 16:59:32 --> Language Class Initialized
INFO - 2018-10-23 16:59:32 --> Loader Class Initialized
INFO - 2018-10-23 16:59:32 --> Helper loaded: url_helper
INFO - 2018-10-23 16:59:32 --> Helper loaded: form_helper
INFO - 2018-10-23 16:59:32 --> Helper loaded: language_helper
DEBUG - 2018-10-23 16:59:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 16:59:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 16:59:32 --> User Agent Class Initialized
INFO - 2018-10-23 16:59:32 --> Controller Class Initialized
INFO - 2018-10-23 16:59:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 16:59:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 16:59:32 --> Helper loaded: custom_helper
INFO - 2018-10-23 16:59:32 --> Pixel_Model class loaded
INFO - 2018-10-23 16:59:32 --> Database Driver Class Initialized
INFO - 2018-10-23 16:59:32 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 16:59:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 16:59:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 16:59:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-23 16:59:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 16:59:32 --> Final output sent to browser
DEBUG - 2018-10-23 16:59:32 --> Total execution time: 0.5501
INFO - 2018-10-23 17:01:36 --> Config Class Initialized
INFO - 2018-10-23 17:01:36 --> Hooks Class Initialized
DEBUG - 2018-10-23 17:01:36 --> UTF-8 Support Enabled
INFO - 2018-10-23 17:01:36 --> Utf8 Class Initialized
INFO - 2018-10-23 17:01:36 --> URI Class Initialized
DEBUG - 2018-10-23 17:01:36 --> No URI present. Default controller set.
INFO - 2018-10-23 17:01:36 --> Router Class Initialized
INFO - 2018-10-23 17:01:36 --> Output Class Initialized
INFO - 2018-10-23 17:01:36 --> Security Class Initialized
DEBUG - 2018-10-23 17:01:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 17:01:36 --> CSRF cookie sent
INFO - 2018-10-23 17:01:36 --> Input Class Initialized
INFO - 2018-10-23 17:01:36 --> Language Class Initialized
INFO - 2018-10-23 17:01:36 --> Loader Class Initialized
INFO - 2018-10-23 17:01:36 --> Helper loaded: url_helper
INFO - 2018-10-23 17:01:36 --> Helper loaded: form_helper
INFO - 2018-10-23 17:01:36 --> Helper loaded: language_helper
DEBUG - 2018-10-23 17:01:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 17:01:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 17:01:36 --> User Agent Class Initialized
INFO - 2018-10-23 17:01:36 --> Controller Class Initialized
INFO - 2018-10-23 17:01:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 17:01:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 17:01:36 --> Helper loaded: custom_helper
INFO - 2018-10-23 17:01:36 --> Pixel_Model class loaded
INFO - 2018-10-23 17:01:36 --> Database Driver Class Initialized
INFO - 2018-10-23 17:01:36 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 17:01:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 17:01:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 17:01:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-23 17:01:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 17:01:36 --> Final output sent to browser
DEBUG - 2018-10-23 17:01:36 --> Total execution time: 0.5673
INFO - 2018-10-23 17:01:40 --> Config Class Initialized
INFO - 2018-10-23 17:01:40 --> Hooks Class Initialized
DEBUG - 2018-10-23 17:01:40 --> UTF-8 Support Enabled
INFO - 2018-10-23 17:01:40 --> Utf8 Class Initialized
INFO - 2018-10-23 17:01:40 --> URI Class Initialized
INFO - 2018-10-23 17:01:40 --> Router Class Initialized
INFO - 2018-10-23 17:01:40 --> Output Class Initialized
INFO - 2018-10-23 17:01:40 --> Security Class Initialized
DEBUG - 2018-10-23 17:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 17:01:40 --> CSRF cookie sent
INFO - 2018-10-23 17:01:40 --> CSRF token verified
INFO - 2018-10-23 17:01:40 --> Input Class Initialized
INFO - 2018-10-23 17:01:40 --> Language Class Initialized
INFO - 2018-10-23 17:01:40 --> Loader Class Initialized
INFO - 2018-10-23 17:01:40 --> Helper loaded: url_helper
INFO - 2018-10-23 17:01:40 --> Helper loaded: form_helper
INFO - 2018-10-23 17:01:40 --> Helper loaded: language_helper
DEBUG - 2018-10-23 17:01:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 17:01:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 17:01:40 --> User Agent Class Initialized
INFO - 2018-10-23 17:01:40 --> Controller Class Initialized
INFO - 2018-10-23 17:01:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 17:01:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 17:01:40 --> Helper loaded: custom_helper
INFO - 2018-10-23 17:01:40 --> Pixel_Model class loaded
INFO - 2018-10-23 17:01:40 --> Database Driver Class Initialized
INFO - 2018-10-23 17:01:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 17:01:49 --> Config Class Initialized
INFO - 2018-10-23 17:01:49 --> Hooks Class Initialized
DEBUG - 2018-10-23 17:01:49 --> UTF-8 Support Enabled
INFO - 2018-10-23 17:01:49 --> Utf8 Class Initialized
INFO - 2018-10-23 17:01:49 --> URI Class Initialized
DEBUG - 2018-10-23 17:01:49 --> No URI present. Default controller set.
INFO - 2018-10-23 17:01:49 --> Router Class Initialized
INFO - 2018-10-23 17:01:49 --> Output Class Initialized
INFO - 2018-10-23 17:01:49 --> Security Class Initialized
DEBUG - 2018-10-23 17:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 17:01:49 --> CSRF cookie sent
INFO - 2018-10-23 17:01:49 --> Input Class Initialized
INFO - 2018-10-23 17:01:49 --> Language Class Initialized
INFO - 2018-10-23 17:01:49 --> Loader Class Initialized
INFO - 2018-10-23 17:01:50 --> Helper loaded: url_helper
INFO - 2018-10-23 17:01:50 --> Helper loaded: form_helper
INFO - 2018-10-23 17:01:50 --> Helper loaded: language_helper
DEBUG - 2018-10-23 17:01:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 17:01:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 17:01:50 --> User Agent Class Initialized
INFO - 2018-10-23 17:01:50 --> Controller Class Initialized
INFO - 2018-10-23 17:01:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 17:01:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 17:01:50 --> Helper loaded: custom_helper
INFO - 2018-10-23 17:01:50 --> Pixel_Model class loaded
INFO - 2018-10-23 17:01:50 --> Database Driver Class Initialized
INFO - 2018-10-23 17:01:50 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 17:01:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 17:01:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 17:01:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-23 17:01:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 17:01:50 --> Final output sent to browser
DEBUG - 2018-10-23 17:01:50 --> Total execution time: 0.5718
INFO - 2018-10-23 17:01:50 --> Config Class Initialized
INFO - 2018-10-23 17:01:50 --> Hooks Class Initialized
DEBUG - 2018-10-23 17:01:50 --> UTF-8 Support Enabled
INFO - 2018-10-23 17:01:50 --> Utf8 Class Initialized
INFO - 2018-10-23 17:01:50 --> URI Class Initialized
DEBUG - 2018-10-23 17:01:50 --> No URI present. Default controller set.
INFO - 2018-10-23 17:01:50 --> Router Class Initialized
INFO - 2018-10-23 17:01:50 --> Output Class Initialized
INFO - 2018-10-23 17:01:50 --> Security Class Initialized
DEBUG - 2018-10-23 17:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 17:01:51 --> CSRF cookie sent
INFO - 2018-10-23 17:01:51 --> Input Class Initialized
INFO - 2018-10-23 17:01:51 --> Language Class Initialized
INFO - 2018-10-23 17:01:51 --> Loader Class Initialized
INFO - 2018-10-23 17:01:51 --> Helper loaded: url_helper
INFO - 2018-10-23 17:01:51 --> Helper loaded: form_helper
INFO - 2018-10-23 17:01:51 --> Helper loaded: language_helper
DEBUG - 2018-10-23 17:01:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 17:01:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 17:01:51 --> User Agent Class Initialized
INFO - 2018-10-23 17:01:51 --> Controller Class Initialized
INFO - 2018-10-23 17:01:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 17:01:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 17:01:51 --> Helper loaded: custom_helper
INFO - 2018-10-23 17:01:51 --> Pixel_Model class loaded
INFO - 2018-10-23 17:01:51 --> Database Driver Class Initialized
INFO - 2018-10-23 17:01:51 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 17:01:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 17:01:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 17:01:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-23 17:01:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 17:01:51 --> Final output sent to browser
DEBUG - 2018-10-23 17:01:51 --> Total execution time: 0.6247
INFO - 2018-10-23 17:01:57 --> Config Class Initialized
INFO - 2018-10-23 17:01:57 --> Hooks Class Initialized
DEBUG - 2018-10-23 17:01:57 --> UTF-8 Support Enabled
INFO - 2018-10-23 17:01:57 --> Utf8 Class Initialized
INFO - 2018-10-23 17:01:57 --> URI Class Initialized
INFO - 2018-10-23 17:01:57 --> Router Class Initialized
INFO - 2018-10-23 17:01:57 --> Output Class Initialized
INFO - 2018-10-23 17:01:57 --> Security Class Initialized
DEBUG - 2018-10-23 17:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 17:01:57 --> CSRF cookie sent
INFO - 2018-10-23 17:01:57 --> Input Class Initialized
INFO - 2018-10-23 17:01:57 --> Language Class Initialized
INFO - 2018-10-23 17:01:57 --> Loader Class Initialized
INFO - 2018-10-23 17:01:57 --> Helper loaded: url_helper
INFO - 2018-10-23 17:01:57 --> Helper loaded: form_helper
INFO - 2018-10-23 17:01:57 --> Helper loaded: language_helper
DEBUG - 2018-10-23 17:01:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 17:01:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 17:01:57 --> User Agent Class Initialized
INFO - 2018-10-23 17:01:57 --> Controller Class Initialized
INFO - 2018-10-23 17:01:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 17:01:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 17:01:57 --> Helper loaded: custom_helper
INFO - 2018-10-23 17:01:57 --> Pixel_Model class loaded
INFO - 2018-10-23 17:01:57 --> Database Driver Class Initialized
INFO - 2018-10-23 17:01:57 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 17:01:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 17:01:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 17:01:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 17:01:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 17:01:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 17:01:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 17:01:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-23 17:01:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 17:01:58 --> Final output sent to browser
DEBUG - 2018-10-23 17:01:58 --> Total execution time: 0.6635
INFO - 2018-10-23 17:01:59 --> Config Class Initialized
INFO - 2018-10-23 17:01:59 --> Hooks Class Initialized
DEBUG - 2018-10-23 17:01:59 --> UTF-8 Support Enabled
INFO - 2018-10-23 17:01:59 --> Utf8 Class Initialized
INFO - 2018-10-23 17:01:59 --> URI Class Initialized
DEBUG - 2018-10-23 17:01:59 --> No URI present. Default controller set.
INFO - 2018-10-23 17:01:59 --> Router Class Initialized
INFO - 2018-10-23 17:02:00 --> Output Class Initialized
INFO - 2018-10-23 17:02:00 --> Security Class Initialized
DEBUG - 2018-10-23 17:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 17:02:00 --> CSRF cookie sent
INFO - 2018-10-23 17:02:00 --> Input Class Initialized
INFO - 2018-10-23 17:02:00 --> Language Class Initialized
INFO - 2018-10-23 17:02:00 --> Loader Class Initialized
INFO - 2018-10-23 17:02:00 --> Helper loaded: url_helper
INFO - 2018-10-23 17:02:00 --> Helper loaded: form_helper
INFO - 2018-10-23 17:02:00 --> Helper loaded: language_helper
DEBUG - 2018-10-23 17:02:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 17:02:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 17:02:00 --> User Agent Class Initialized
INFO - 2018-10-23 17:02:00 --> Controller Class Initialized
INFO - 2018-10-23 17:02:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 17:02:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 17:02:00 --> Helper loaded: custom_helper
INFO - 2018-10-23 17:02:00 --> Pixel_Model class loaded
INFO - 2018-10-23 17:02:00 --> Database Driver Class Initialized
INFO - 2018-10-23 17:02:00 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 17:02:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 17:02:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 17:02:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-23 17:02:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 17:02:00 --> Final output sent to browser
DEBUG - 2018-10-23 17:02:00 --> Total execution time: 0.5685
INFO - 2018-10-23 17:02:03 --> Config Class Initialized
INFO - 2018-10-23 17:02:03 --> Hooks Class Initialized
DEBUG - 2018-10-23 17:02:03 --> UTF-8 Support Enabled
INFO - 2018-10-23 17:02:03 --> Utf8 Class Initialized
INFO - 2018-10-23 17:02:03 --> URI Class Initialized
INFO - 2018-10-23 17:02:03 --> Router Class Initialized
INFO - 2018-10-23 17:02:03 --> Output Class Initialized
INFO - 2018-10-23 17:02:03 --> Security Class Initialized
DEBUG - 2018-10-23 17:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 17:02:04 --> CSRF cookie sent
INFO - 2018-10-23 17:02:04 --> CSRF token verified
INFO - 2018-10-23 17:02:04 --> Input Class Initialized
INFO - 2018-10-23 17:02:04 --> Language Class Initialized
INFO - 2018-10-23 17:02:04 --> Loader Class Initialized
INFO - 2018-10-23 17:02:04 --> Helper loaded: url_helper
INFO - 2018-10-23 17:02:04 --> Helper loaded: form_helper
INFO - 2018-10-23 17:02:04 --> Helper loaded: language_helper
DEBUG - 2018-10-23 17:02:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 17:02:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 17:02:04 --> User Agent Class Initialized
INFO - 2018-10-23 17:02:04 --> Controller Class Initialized
INFO - 2018-10-23 17:02:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 17:02:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 17:02:04 --> Helper loaded: custom_helper
INFO - 2018-10-23 17:02:04 --> Pixel_Model class loaded
INFO - 2018-10-23 17:02:04 --> Database Driver Class Initialized
INFO - 2018-10-23 17:02:04 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 17:02:46 --> Config Class Initialized
INFO - 2018-10-23 17:02:46 --> Hooks Class Initialized
DEBUG - 2018-10-23 17:02:46 --> UTF-8 Support Enabled
INFO - 2018-10-23 17:02:46 --> Utf8 Class Initialized
INFO - 2018-10-23 17:02:46 --> URI Class Initialized
INFO - 2018-10-23 17:02:46 --> Router Class Initialized
INFO - 2018-10-23 17:02:46 --> Output Class Initialized
INFO - 2018-10-23 17:02:46 --> Security Class Initialized
DEBUG - 2018-10-23 17:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 17:02:46 --> CSRF cookie sent
INFO - 2018-10-23 17:02:46 --> CSRF token verified
INFO - 2018-10-23 17:02:46 --> Input Class Initialized
INFO - 2018-10-23 17:02:46 --> Language Class Initialized
INFO - 2018-10-23 17:02:46 --> Loader Class Initialized
INFO - 2018-10-23 17:02:46 --> Helper loaded: url_helper
INFO - 2018-10-23 17:02:46 --> Helper loaded: form_helper
INFO - 2018-10-23 17:02:47 --> Helper loaded: language_helper
DEBUG - 2018-10-23 17:02:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 17:02:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 17:02:47 --> User Agent Class Initialized
INFO - 2018-10-23 17:02:47 --> Controller Class Initialized
INFO - 2018-10-23 17:02:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 17:02:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 17:02:47 --> Helper loaded: custom_helper
INFO - 2018-10-23 17:02:47 --> Pixel_Model class loaded
INFO - 2018-10-23 17:02:47 --> Database Driver Class Initialized
INFO - 2018-10-23 17:02:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 17:02:47 --> Database Driver Class Initialized
INFO - 2018-10-23 17:02:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 17:02:59 --> Config Class Initialized
INFO - 2018-10-23 17:02:59 --> Hooks Class Initialized
DEBUG - 2018-10-23 17:02:59 --> UTF-8 Support Enabled
INFO - 2018-10-23 17:02:59 --> Utf8 Class Initialized
INFO - 2018-10-23 17:02:59 --> URI Class Initialized
INFO - 2018-10-23 17:02:59 --> Router Class Initialized
INFO - 2018-10-23 17:02:59 --> Output Class Initialized
INFO - 2018-10-23 17:02:59 --> Security Class Initialized
DEBUG - 2018-10-23 17:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 17:02:59 --> CSRF cookie sent
INFO - 2018-10-23 17:02:59 --> CSRF token verified
INFO - 2018-10-23 17:02:59 --> Input Class Initialized
INFO - 2018-10-23 17:02:59 --> Language Class Initialized
INFO - 2018-10-23 17:02:59 --> Loader Class Initialized
INFO - 2018-10-23 17:03:00 --> Helper loaded: url_helper
INFO - 2018-10-23 17:03:00 --> Helper loaded: form_helper
INFO - 2018-10-23 17:03:00 --> Helper loaded: language_helper
DEBUG - 2018-10-23 17:03:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 17:03:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 17:03:00 --> User Agent Class Initialized
INFO - 2018-10-23 17:03:00 --> Controller Class Initialized
INFO - 2018-10-23 17:03:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 17:03:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 17:03:00 --> Helper loaded: custom_helper
INFO - 2018-10-23 17:03:00 --> Pixel_Model class loaded
INFO - 2018-10-23 17:03:00 --> Database Driver Class Initialized
INFO - 2018-10-23 17:03:00 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 17:03:00 --> Database Driver Class Initialized
INFO - 2018-10-23 17:03:00 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 17:03:05 --> Config Class Initialized
INFO - 2018-10-23 17:03:05 --> Hooks Class Initialized
DEBUG - 2018-10-23 17:03:05 --> UTF-8 Support Enabled
INFO - 2018-10-23 17:03:05 --> Utf8 Class Initialized
INFO - 2018-10-23 17:03:05 --> URI Class Initialized
DEBUG - 2018-10-23 17:03:05 --> No URI present. Default controller set.
INFO - 2018-10-23 17:03:06 --> Router Class Initialized
INFO - 2018-10-23 17:03:06 --> Output Class Initialized
INFO - 2018-10-23 17:03:06 --> Security Class Initialized
DEBUG - 2018-10-23 17:03:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 17:03:06 --> CSRF cookie sent
INFO - 2018-10-23 17:03:06 --> Input Class Initialized
INFO - 2018-10-23 17:03:06 --> Language Class Initialized
INFO - 2018-10-23 17:03:06 --> Loader Class Initialized
INFO - 2018-10-23 17:03:06 --> Helper loaded: url_helper
INFO - 2018-10-23 17:03:06 --> Helper loaded: form_helper
INFO - 2018-10-23 17:03:06 --> Helper loaded: language_helper
DEBUG - 2018-10-23 17:03:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 17:03:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 17:03:06 --> User Agent Class Initialized
INFO - 2018-10-23 17:03:06 --> Controller Class Initialized
INFO - 2018-10-23 17:03:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 17:03:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 17:03:06 --> Helper loaded: custom_helper
INFO - 2018-10-23 17:03:06 --> Pixel_Model class loaded
INFO - 2018-10-23 17:03:06 --> Database Driver Class Initialized
INFO - 2018-10-23 17:03:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 17:03:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 17:03:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 17:03:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-23 17:03:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 17:03:06 --> Final output sent to browser
DEBUG - 2018-10-23 17:03:06 --> Total execution time: 0.5739
INFO - 2018-10-23 17:03:12 --> Config Class Initialized
INFO - 2018-10-23 17:03:12 --> Hooks Class Initialized
DEBUG - 2018-10-23 17:03:12 --> UTF-8 Support Enabled
INFO - 2018-10-23 17:03:12 --> Utf8 Class Initialized
INFO - 2018-10-23 17:03:12 --> URI Class Initialized
DEBUG - 2018-10-23 17:03:12 --> No URI present. Default controller set.
INFO - 2018-10-23 17:03:12 --> Router Class Initialized
INFO - 2018-10-23 17:03:12 --> Output Class Initialized
INFO - 2018-10-23 17:03:12 --> Security Class Initialized
DEBUG - 2018-10-23 17:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 17:03:12 --> CSRF cookie sent
INFO - 2018-10-23 17:03:12 --> Input Class Initialized
INFO - 2018-10-23 17:03:12 --> Language Class Initialized
INFO - 2018-10-23 17:03:12 --> Loader Class Initialized
INFO - 2018-10-23 17:03:12 --> Helper loaded: url_helper
INFO - 2018-10-23 17:03:12 --> Helper loaded: form_helper
INFO - 2018-10-23 17:03:12 --> Helper loaded: language_helper
DEBUG - 2018-10-23 17:03:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 17:03:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 17:03:12 --> User Agent Class Initialized
INFO - 2018-10-23 17:03:12 --> Controller Class Initialized
INFO - 2018-10-23 17:03:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 17:03:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 17:03:12 --> Helper loaded: custom_helper
INFO - 2018-10-23 17:03:12 --> Pixel_Model class loaded
INFO - 2018-10-23 17:03:12 --> Database Driver Class Initialized
INFO - 2018-10-23 17:03:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 17:03:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 17:03:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 17:03:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-23 17:03:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 17:03:12 --> Final output sent to browser
DEBUG - 2018-10-23 17:03:12 --> Total execution time: 0.6201
INFO - 2018-10-23 17:03:16 --> Config Class Initialized
INFO - 2018-10-23 17:03:16 --> Hooks Class Initialized
DEBUG - 2018-10-23 17:03:16 --> UTF-8 Support Enabled
INFO - 2018-10-23 17:03:16 --> Utf8 Class Initialized
INFO - 2018-10-23 17:03:16 --> URI Class Initialized
INFO - 2018-10-23 17:03:16 --> Router Class Initialized
INFO - 2018-10-23 17:03:16 --> Output Class Initialized
INFO - 2018-10-23 17:03:17 --> Security Class Initialized
DEBUG - 2018-10-23 17:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 17:03:17 --> CSRF cookie sent
INFO - 2018-10-23 17:03:17 --> CSRF token verified
INFO - 2018-10-23 17:03:17 --> Input Class Initialized
INFO - 2018-10-23 17:03:17 --> Language Class Initialized
INFO - 2018-10-23 17:03:17 --> Loader Class Initialized
INFO - 2018-10-23 17:03:17 --> Helper loaded: url_helper
INFO - 2018-10-23 17:03:17 --> Helper loaded: form_helper
INFO - 2018-10-23 17:03:17 --> Helper loaded: language_helper
DEBUG - 2018-10-23 17:03:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 17:03:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 17:03:17 --> User Agent Class Initialized
INFO - 2018-10-23 17:03:17 --> Controller Class Initialized
INFO - 2018-10-23 17:03:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 17:03:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 17:03:17 --> Helper loaded: custom_helper
INFO - 2018-10-23 17:03:17 --> Pixel_Model class loaded
INFO - 2018-10-23 17:03:17 --> Database Driver Class Initialized
INFO - 2018-10-23 17:03:17 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 17:03:17 --> Database Driver Class Initialized
INFO - 2018-10-23 17:03:17 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 17:03:38 --> Config Class Initialized
INFO - 2018-10-23 17:03:38 --> Hooks Class Initialized
DEBUG - 2018-10-23 17:03:38 --> UTF-8 Support Enabled
INFO - 2018-10-23 17:03:38 --> Utf8 Class Initialized
INFO - 2018-10-23 17:03:38 --> URI Class Initialized
INFO - 2018-10-23 17:03:38 --> Router Class Initialized
INFO - 2018-10-23 17:03:38 --> Output Class Initialized
INFO - 2018-10-23 17:03:38 --> Security Class Initialized
DEBUG - 2018-10-23 17:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 17:03:38 --> CSRF cookie sent
INFO - 2018-10-23 17:03:38 --> CSRF token verified
INFO - 2018-10-23 17:03:38 --> Input Class Initialized
INFO - 2018-10-23 17:03:38 --> Language Class Initialized
INFO - 2018-10-23 17:03:38 --> Loader Class Initialized
INFO - 2018-10-23 17:03:38 --> Helper loaded: url_helper
INFO - 2018-10-23 17:03:38 --> Helper loaded: form_helper
INFO - 2018-10-23 17:03:38 --> Helper loaded: language_helper
DEBUG - 2018-10-23 17:03:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 17:03:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 17:03:38 --> User Agent Class Initialized
INFO - 2018-10-23 17:03:38 --> Controller Class Initialized
INFO - 2018-10-23 17:03:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 17:03:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 17:03:38 --> Helper loaded: custom_helper
INFO - 2018-10-23 17:03:38 --> Pixel_Model class loaded
INFO - 2018-10-23 17:03:38 --> Database Driver Class Initialized
INFO - 2018-10-23 17:03:39 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 17:03:39 --> Database Driver Class Initialized
INFO - 2018-10-23 17:03:39 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 17:03:53 --> Config Class Initialized
INFO - 2018-10-23 17:03:53 --> Hooks Class Initialized
DEBUG - 2018-10-23 17:03:54 --> UTF-8 Support Enabled
INFO - 2018-10-23 17:03:54 --> Utf8 Class Initialized
INFO - 2018-10-23 17:03:54 --> URI Class Initialized
INFO - 2018-10-23 17:03:54 --> Router Class Initialized
INFO - 2018-10-23 17:03:54 --> Output Class Initialized
INFO - 2018-10-23 17:03:54 --> Security Class Initialized
DEBUG - 2018-10-23 17:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 17:03:54 --> CSRF cookie sent
INFO - 2018-10-23 17:03:54 --> CSRF token verified
INFO - 2018-10-23 17:03:54 --> Input Class Initialized
INFO - 2018-10-23 17:03:54 --> Language Class Initialized
INFO - 2018-10-23 17:03:54 --> Loader Class Initialized
INFO - 2018-10-23 17:03:54 --> Helper loaded: url_helper
INFO - 2018-10-23 17:03:54 --> Helper loaded: form_helper
INFO - 2018-10-23 17:03:54 --> Helper loaded: language_helper
DEBUG - 2018-10-23 17:03:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 17:03:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 17:03:54 --> User Agent Class Initialized
INFO - 2018-10-23 17:03:54 --> Controller Class Initialized
INFO - 2018-10-23 17:03:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 17:03:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 17:03:54 --> Helper loaded: custom_helper
INFO - 2018-10-23 17:03:54 --> Pixel_Model class loaded
INFO - 2018-10-23 17:03:54 --> Database Driver Class Initialized
INFO - 2018-10-23 17:03:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 17:03:54 --> Database Driver Class Initialized
INFO - 2018-10-23 17:03:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 17:04:04 --> Config Class Initialized
INFO - 2018-10-23 17:04:04 --> Hooks Class Initialized
DEBUG - 2018-10-23 17:04:04 --> UTF-8 Support Enabled
INFO - 2018-10-23 17:04:04 --> Utf8 Class Initialized
INFO - 2018-10-23 17:04:04 --> URI Class Initialized
INFO - 2018-10-23 17:04:04 --> Router Class Initialized
INFO - 2018-10-23 17:04:04 --> Output Class Initialized
INFO - 2018-10-23 17:04:04 --> Security Class Initialized
DEBUG - 2018-10-23 17:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 17:04:04 --> CSRF cookie sent
INFO - 2018-10-23 17:04:04 --> CSRF token verified
INFO - 2018-10-23 17:04:04 --> Input Class Initialized
INFO - 2018-10-23 17:04:04 --> Language Class Initialized
INFO - 2018-10-23 17:04:04 --> Loader Class Initialized
INFO - 2018-10-23 17:04:04 --> Helper loaded: url_helper
INFO - 2018-10-23 17:04:04 --> Helper loaded: form_helper
INFO - 2018-10-23 17:04:04 --> Helper loaded: language_helper
DEBUG - 2018-10-23 17:04:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 17:04:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 17:04:04 --> User Agent Class Initialized
INFO - 2018-10-23 17:04:04 --> Controller Class Initialized
INFO - 2018-10-23 17:04:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 17:04:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 17:04:05 --> Helper loaded: custom_helper
INFO - 2018-10-23 17:04:05 --> Pixel_Model class loaded
INFO - 2018-10-23 17:04:05 --> Database Driver Class Initialized
INFO - 2018-10-23 17:04:05 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 17:04:05 --> Database Driver Class Initialized
INFO - 2018-10-23 17:04:05 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 17:04:30 --> Config Class Initialized
INFO - 2018-10-23 17:04:30 --> Hooks Class Initialized
DEBUG - 2018-10-23 17:04:30 --> UTF-8 Support Enabled
INFO - 2018-10-23 17:04:30 --> Utf8 Class Initialized
INFO - 2018-10-23 17:04:30 --> URI Class Initialized
INFO - 2018-10-23 17:04:30 --> Router Class Initialized
INFO - 2018-10-23 17:04:30 --> Output Class Initialized
INFO - 2018-10-23 17:04:30 --> Security Class Initialized
DEBUG - 2018-10-23 17:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 17:04:30 --> CSRF cookie sent
INFO - 2018-10-23 17:04:30 --> CSRF token verified
INFO - 2018-10-23 17:04:30 --> Input Class Initialized
INFO - 2018-10-23 17:04:30 --> Language Class Initialized
INFO - 2018-10-23 17:04:30 --> Loader Class Initialized
INFO - 2018-10-23 17:04:30 --> Helper loaded: url_helper
INFO - 2018-10-23 17:04:30 --> Helper loaded: form_helper
INFO - 2018-10-23 17:04:30 --> Helper loaded: language_helper
DEBUG - 2018-10-23 17:04:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 17:04:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 17:04:30 --> User Agent Class Initialized
INFO - 2018-10-23 17:04:30 --> Controller Class Initialized
INFO - 2018-10-23 17:04:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 17:04:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 17:04:30 --> Helper loaded: custom_helper
INFO - 2018-10-23 17:04:30 --> Pixel_Model class loaded
INFO - 2018-10-23 17:04:30 --> Database Driver Class Initialized
INFO - 2018-10-23 17:04:30 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 17:04:30 --> Database Driver Class Initialized
INFO - 2018-10-23 17:04:30 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 17:04:41 --> Config Class Initialized
INFO - 2018-10-23 17:04:41 --> Hooks Class Initialized
DEBUG - 2018-10-23 17:04:41 --> UTF-8 Support Enabled
INFO - 2018-10-23 17:04:41 --> Utf8 Class Initialized
INFO - 2018-10-23 17:04:41 --> URI Class Initialized
DEBUG - 2018-10-23 17:04:41 --> No URI present. Default controller set.
INFO - 2018-10-23 17:04:41 --> Router Class Initialized
INFO - 2018-10-23 17:04:41 --> Output Class Initialized
INFO - 2018-10-23 17:04:41 --> Security Class Initialized
DEBUG - 2018-10-23 17:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 17:04:41 --> CSRF cookie sent
INFO - 2018-10-23 17:04:41 --> Input Class Initialized
INFO - 2018-10-23 17:04:41 --> Language Class Initialized
INFO - 2018-10-23 17:04:41 --> Loader Class Initialized
INFO - 2018-10-23 17:04:41 --> Helper loaded: url_helper
INFO - 2018-10-23 17:04:41 --> Helper loaded: form_helper
INFO - 2018-10-23 17:04:41 --> Helper loaded: language_helper
DEBUG - 2018-10-23 17:04:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 17:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 17:04:41 --> User Agent Class Initialized
INFO - 2018-10-23 17:04:41 --> Controller Class Initialized
INFO - 2018-10-23 17:04:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 17:04:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 17:04:41 --> Helper loaded: custom_helper
INFO - 2018-10-23 17:04:41 --> Pixel_Model class loaded
INFO - 2018-10-23 17:04:41 --> Database Driver Class Initialized
INFO - 2018-10-23 17:04:41 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 17:04:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 17:04:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 17:04:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-23 17:04:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 17:04:41 --> Final output sent to browser
DEBUG - 2018-10-23 17:04:41 --> Total execution time: 0.5557
INFO - 2018-10-23 17:04:43 --> Config Class Initialized
INFO - 2018-10-23 17:04:43 --> Hooks Class Initialized
DEBUG - 2018-10-23 17:04:43 --> UTF-8 Support Enabled
INFO - 2018-10-23 17:04:43 --> Utf8 Class Initialized
INFO - 2018-10-23 17:04:43 --> URI Class Initialized
DEBUG - 2018-10-23 17:04:43 --> No URI present. Default controller set.
INFO - 2018-10-23 17:04:43 --> Router Class Initialized
INFO - 2018-10-23 17:04:43 --> Output Class Initialized
INFO - 2018-10-23 17:04:43 --> Security Class Initialized
DEBUG - 2018-10-23 17:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 17:04:43 --> CSRF cookie sent
INFO - 2018-10-23 17:04:43 --> Input Class Initialized
INFO - 2018-10-23 17:04:43 --> Language Class Initialized
INFO - 2018-10-23 17:04:43 --> Loader Class Initialized
INFO - 2018-10-23 17:04:43 --> Helper loaded: url_helper
INFO - 2018-10-23 17:04:43 --> Helper loaded: form_helper
INFO - 2018-10-23 17:04:43 --> Helper loaded: language_helper
DEBUG - 2018-10-23 17:04:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 17:04:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 17:04:43 --> User Agent Class Initialized
INFO - 2018-10-23 17:04:43 --> Controller Class Initialized
INFO - 2018-10-23 17:04:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 17:04:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 17:04:43 --> Helper loaded: custom_helper
INFO - 2018-10-23 17:04:43 --> Pixel_Model class loaded
INFO - 2018-10-23 17:04:43 --> Database Driver Class Initialized
INFO - 2018-10-23 17:04:43 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 17:04:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 17:04:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 17:04:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-23 17:04:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 17:04:43 --> Final output sent to browser
DEBUG - 2018-10-23 17:04:43 --> Total execution time: 0.6578
INFO - 2018-10-23 17:04:47 --> Config Class Initialized
INFO - 2018-10-23 17:04:47 --> Hooks Class Initialized
DEBUG - 2018-10-23 17:04:47 --> UTF-8 Support Enabled
INFO - 2018-10-23 17:04:47 --> Utf8 Class Initialized
INFO - 2018-10-23 17:04:47 --> URI Class Initialized
INFO - 2018-10-23 17:04:47 --> Router Class Initialized
INFO - 2018-10-23 17:04:47 --> Output Class Initialized
INFO - 2018-10-23 17:04:47 --> Security Class Initialized
DEBUG - 2018-10-23 17:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 17:04:47 --> CSRF cookie sent
INFO - 2018-10-23 17:04:47 --> CSRF token verified
INFO - 2018-10-23 17:04:47 --> Input Class Initialized
INFO - 2018-10-23 17:04:47 --> Language Class Initialized
INFO - 2018-10-23 17:04:47 --> Loader Class Initialized
INFO - 2018-10-23 17:04:47 --> Helper loaded: url_helper
INFO - 2018-10-23 17:04:47 --> Helper loaded: form_helper
INFO - 2018-10-23 17:04:47 --> Helper loaded: language_helper
DEBUG - 2018-10-23 17:04:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 17:04:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 17:04:47 --> User Agent Class Initialized
INFO - 2018-10-23 17:04:47 --> Controller Class Initialized
INFO - 2018-10-23 17:04:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 17:04:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 17:04:47 --> Helper loaded: custom_helper
INFO - 2018-10-23 17:04:47 --> Pixel_Model class loaded
INFO - 2018-10-23 17:04:47 --> Database Driver Class Initialized
INFO - 2018-10-23 17:04:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 17:04:47 --> Database Driver Class Initialized
INFO - 2018-10-23 17:04:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 17:05:26 --> Config Class Initialized
INFO - 2018-10-23 17:05:26 --> Hooks Class Initialized
DEBUG - 2018-10-23 17:05:26 --> UTF-8 Support Enabled
INFO - 2018-10-23 17:05:26 --> Utf8 Class Initialized
INFO - 2018-10-23 17:05:26 --> URI Class Initialized
INFO - 2018-10-23 17:05:26 --> Router Class Initialized
INFO - 2018-10-23 17:05:26 --> Output Class Initialized
INFO - 2018-10-23 17:05:26 --> Security Class Initialized
DEBUG - 2018-10-23 17:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 17:05:26 --> CSRF cookie sent
INFO - 2018-10-23 17:05:26 --> CSRF token verified
INFO - 2018-10-23 17:05:26 --> Input Class Initialized
INFO - 2018-10-23 17:05:26 --> Language Class Initialized
INFO - 2018-10-23 17:05:26 --> Loader Class Initialized
INFO - 2018-10-23 17:05:26 --> Helper loaded: url_helper
INFO - 2018-10-23 17:05:26 --> Helper loaded: form_helper
INFO - 2018-10-23 17:05:26 --> Helper loaded: language_helper
DEBUG - 2018-10-23 17:05:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 17:05:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 17:05:26 --> User Agent Class Initialized
INFO - 2018-10-23 17:05:26 --> Controller Class Initialized
INFO - 2018-10-23 17:05:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 17:05:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 17:05:26 --> Helper loaded: custom_helper
INFO - 2018-10-23 17:05:26 --> Pixel_Model class loaded
INFO - 2018-10-23 17:05:26 --> Database Driver Class Initialized
INFO - 2018-10-23 17:05:26 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 17:05:26 --> Database Driver Class Initialized
INFO - 2018-10-23 17:05:26 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 17:05:31 --> Config Class Initialized
INFO - 2018-10-23 17:05:31 --> Hooks Class Initialized
DEBUG - 2018-10-23 17:05:31 --> UTF-8 Support Enabled
INFO - 2018-10-23 17:05:31 --> Utf8 Class Initialized
INFO - 2018-10-23 17:05:31 --> URI Class Initialized
DEBUG - 2018-10-23 17:05:31 --> No URI present. Default controller set.
INFO - 2018-10-23 17:05:31 --> Router Class Initialized
INFO - 2018-10-23 17:05:31 --> Output Class Initialized
INFO - 2018-10-23 17:05:31 --> Security Class Initialized
DEBUG - 2018-10-23 17:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 17:05:31 --> CSRF cookie sent
INFO - 2018-10-23 17:05:31 --> Input Class Initialized
INFO - 2018-10-23 17:05:31 --> Language Class Initialized
INFO - 2018-10-23 17:05:31 --> Loader Class Initialized
INFO - 2018-10-23 17:05:31 --> Helper loaded: url_helper
INFO - 2018-10-23 17:05:31 --> Helper loaded: form_helper
INFO - 2018-10-23 17:05:31 --> Helper loaded: language_helper
DEBUG - 2018-10-23 17:05:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 17:05:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 17:05:31 --> User Agent Class Initialized
INFO - 2018-10-23 17:05:31 --> Controller Class Initialized
INFO - 2018-10-23 17:05:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 17:05:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 17:05:31 --> Helper loaded: custom_helper
INFO - 2018-10-23 17:05:31 --> Pixel_Model class loaded
INFO - 2018-10-23 17:05:31 --> Database Driver Class Initialized
INFO - 2018-10-23 17:05:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 17:05:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 17:05:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 17:05:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-23 17:05:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 17:05:31 --> Final output sent to browser
DEBUG - 2018-10-23 17:05:32 --> Total execution time: 0.5790
INFO - 2018-10-23 17:05:32 --> Config Class Initialized
INFO - 2018-10-23 17:05:32 --> Hooks Class Initialized
DEBUG - 2018-10-23 17:05:32 --> UTF-8 Support Enabled
INFO - 2018-10-23 17:05:32 --> Utf8 Class Initialized
INFO - 2018-10-23 17:05:32 --> URI Class Initialized
DEBUG - 2018-10-23 17:05:32 --> No URI present. Default controller set.
INFO - 2018-10-23 17:05:32 --> Router Class Initialized
INFO - 2018-10-23 17:05:32 --> Output Class Initialized
INFO - 2018-10-23 17:05:32 --> Security Class Initialized
DEBUG - 2018-10-23 17:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 17:05:32 --> CSRF cookie sent
INFO - 2018-10-23 17:05:32 --> Input Class Initialized
INFO - 2018-10-23 17:05:32 --> Language Class Initialized
INFO - 2018-10-23 17:05:32 --> Loader Class Initialized
INFO - 2018-10-23 17:05:32 --> Helper loaded: url_helper
INFO - 2018-10-23 17:05:32 --> Helper loaded: form_helper
INFO - 2018-10-23 17:05:33 --> Helper loaded: language_helper
DEBUG - 2018-10-23 17:05:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 17:05:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 17:05:33 --> User Agent Class Initialized
INFO - 2018-10-23 17:05:33 --> Controller Class Initialized
INFO - 2018-10-23 17:05:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 17:05:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 17:05:33 --> Helper loaded: custom_helper
INFO - 2018-10-23 17:05:33 --> Pixel_Model class loaded
INFO - 2018-10-23 17:05:33 --> Database Driver Class Initialized
INFO - 2018-10-23 17:05:33 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 17:05:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 17:05:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 17:05:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-23 17:05:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 17:05:33 --> Final output sent to browser
DEBUG - 2018-10-23 17:05:33 --> Total execution time: 0.6333
INFO - 2018-10-23 17:05:36 --> Config Class Initialized
INFO - 2018-10-23 17:05:36 --> Hooks Class Initialized
DEBUG - 2018-10-23 17:05:36 --> UTF-8 Support Enabled
INFO - 2018-10-23 17:05:36 --> Utf8 Class Initialized
INFO - 2018-10-23 17:05:36 --> URI Class Initialized
INFO - 2018-10-23 17:05:36 --> Router Class Initialized
INFO - 2018-10-23 17:05:36 --> Output Class Initialized
INFO - 2018-10-23 17:05:36 --> Security Class Initialized
DEBUG - 2018-10-23 17:05:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 17:05:36 --> CSRF cookie sent
INFO - 2018-10-23 17:05:36 --> CSRF token verified
INFO - 2018-10-23 17:05:37 --> Input Class Initialized
INFO - 2018-10-23 17:05:37 --> Language Class Initialized
INFO - 2018-10-23 17:05:37 --> Loader Class Initialized
INFO - 2018-10-23 17:05:37 --> Helper loaded: url_helper
INFO - 2018-10-23 17:05:37 --> Helper loaded: form_helper
INFO - 2018-10-23 17:05:37 --> Helper loaded: language_helper
DEBUG - 2018-10-23 17:05:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 17:05:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 17:05:37 --> User Agent Class Initialized
INFO - 2018-10-23 17:05:37 --> Controller Class Initialized
INFO - 2018-10-23 17:05:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 17:05:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 17:05:37 --> Helper loaded: custom_helper
INFO - 2018-10-23 17:05:37 --> Pixel_Model class loaded
INFO - 2018-10-23 17:05:37 --> Database Driver Class Initialized
INFO - 2018-10-23 17:05:37 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 17:05:37 --> Database Driver Class Initialized
INFO - 2018-10-23 17:05:37 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 17:05:52 --> Config Class Initialized
INFO - 2018-10-23 17:05:52 --> Hooks Class Initialized
DEBUG - 2018-10-23 17:05:52 --> UTF-8 Support Enabled
INFO - 2018-10-23 17:05:52 --> Utf8 Class Initialized
INFO - 2018-10-23 17:05:52 --> URI Class Initialized
INFO - 2018-10-23 17:05:52 --> Router Class Initialized
INFO - 2018-10-23 17:05:52 --> Output Class Initialized
INFO - 2018-10-23 17:05:52 --> Security Class Initialized
DEBUG - 2018-10-23 17:05:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 17:05:52 --> CSRF cookie sent
INFO - 2018-10-23 17:05:52 --> CSRF token verified
INFO - 2018-10-23 17:05:52 --> Input Class Initialized
INFO - 2018-10-23 17:05:52 --> Language Class Initialized
INFO - 2018-10-23 17:05:52 --> Loader Class Initialized
INFO - 2018-10-23 17:05:52 --> Helper loaded: url_helper
INFO - 2018-10-23 17:05:53 --> Helper loaded: form_helper
INFO - 2018-10-23 17:05:53 --> Helper loaded: language_helper
DEBUG - 2018-10-23 17:05:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 17:05:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 17:05:53 --> User Agent Class Initialized
INFO - 2018-10-23 17:05:53 --> Controller Class Initialized
INFO - 2018-10-23 17:05:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 17:05:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 17:05:53 --> Helper loaded: custom_helper
INFO - 2018-10-23 17:05:53 --> Pixel_Model class loaded
INFO - 2018-10-23 17:05:53 --> Database Driver Class Initialized
INFO - 2018-10-23 17:05:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 17:05:53 --> Database Driver Class Initialized
INFO - 2018-10-23 17:05:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 17:06:24 --> Config Class Initialized
INFO - 2018-10-23 17:06:24 --> Hooks Class Initialized
DEBUG - 2018-10-23 17:06:24 --> UTF-8 Support Enabled
INFO - 2018-10-23 17:06:24 --> Utf8 Class Initialized
INFO - 2018-10-23 17:06:24 --> URI Class Initialized
INFO - 2018-10-23 17:06:24 --> Router Class Initialized
INFO - 2018-10-23 17:06:24 --> Output Class Initialized
INFO - 2018-10-23 17:06:24 --> Security Class Initialized
DEBUG - 2018-10-23 17:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 17:06:24 --> CSRF cookie sent
INFO - 2018-10-23 17:06:24 --> CSRF token verified
INFO - 2018-10-23 17:06:24 --> Input Class Initialized
INFO - 2018-10-23 17:06:24 --> Language Class Initialized
INFO - 2018-10-23 17:06:24 --> Loader Class Initialized
INFO - 2018-10-23 17:06:24 --> Helper loaded: url_helper
INFO - 2018-10-23 17:06:24 --> Helper loaded: form_helper
INFO - 2018-10-23 17:06:24 --> Helper loaded: language_helper
DEBUG - 2018-10-23 17:06:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 17:06:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 17:06:24 --> User Agent Class Initialized
INFO - 2018-10-23 17:06:24 --> Controller Class Initialized
INFO - 2018-10-23 17:06:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 17:06:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 17:06:24 --> Helper loaded: custom_helper
INFO - 2018-10-23 17:06:24 --> Pixel_Model class loaded
INFO - 2018-10-23 17:06:24 --> Database Driver Class Initialized
INFO - 2018-10-23 17:06:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 17:06:24 --> Database Driver Class Initialized
INFO - 2018-10-23 17:06:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 17:06:37 --> Config Class Initialized
INFO - 2018-10-23 17:06:37 --> Hooks Class Initialized
DEBUG - 2018-10-23 17:06:37 --> UTF-8 Support Enabled
INFO - 2018-10-23 17:06:37 --> Utf8 Class Initialized
INFO - 2018-10-23 17:06:37 --> URI Class Initialized
INFO - 2018-10-23 17:06:37 --> Router Class Initialized
INFO - 2018-10-23 17:06:37 --> Output Class Initialized
INFO - 2018-10-23 17:06:37 --> Security Class Initialized
DEBUG - 2018-10-23 17:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 17:06:37 --> CSRF cookie sent
INFO - 2018-10-23 17:06:37 --> CSRF token verified
INFO - 2018-10-23 17:06:37 --> Input Class Initialized
INFO - 2018-10-23 17:06:37 --> Language Class Initialized
INFO - 2018-10-23 17:06:37 --> Loader Class Initialized
INFO - 2018-10-23 17:06:37 --> Helper loaded: url_helper
INFO - 2018-10-23 17:06:37 --> Helper loaded: form_helper
INFO - 2018-10-23 17:06:37 --> Helper loaded: language_helper
DEBUG - 2018-10-23 17:06:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 17:06:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 17:06:37 --> User Agent Class Initialized
INFO - 2018-10-23 17:06:37 --> Controller Class Initialized
INFO - 2018-10-23 17:06:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 17:06:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 17:06:37 --> Helper loaded: custom_helper
INFO - 2018-10-23 17:06:37 --> Pixel_Model class loaded
INFO - 2018-10-23 17:06:37 --> Database Driver Class Initialized
INFO - 2018-10-23 17:06:37 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 17:06:37 --> Database Driver Class Initialized
INFO - 2018-10-23 17:06:37 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 17:07:48 --> Config Class Initialized
INFO - 2018-10-23 17:07:48 --> Hooks Class Initialized
DEBUG - 2018-10-23 17:07:48 --> UTF-8 Support Enabled
INFO - 2018-10-23 17:07:49 --> Utf8 Class Initialized
INFO - 2018-10-23 17:07:49 --> URI Class Initialized
INFO - 2018-10-23 17:07:49 --> Router Class Initialized
INFO - 2018-10-23 17:07:49 --> Output Class Initialized
INFO - 2018-10-23 17:07:49 --> Security Class Initialized
DEBUG - 2018-10-23 17:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 17:07:49 --> CSRF cookie sent
INFO - 2018-10-23 17:07:49 --> CSRF token verified
INFO - 2018-10-23 17:07:49 --> Input Class Initialized
INFO - 2018-10-23 17:07:49 --> Language Class Initialized
INFO - 2018-10-23 17:07:49 --> Loader Class Initialized
INFO - 2018-10-23 17:07:49 --> Helper loaded: url_helper
INFO - 2018-10-23 17:07:49 --> Helper loaded: form_helper
INFO - 2018-10-23 17:07:49 --> Helper loaded: language_helper
DEBUG - 2018-10-23 17:07:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 17:07:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 17:07:49 --> User Agent Class Initialized
INFO - 2018-10-23 17:07:49 --> Controller Class Initialized
INFO - 2018-10-23 17:07:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 17:07:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 17:07:49 --> Helper loaded: custom_helper
INFO - 2018-10-23 17:07:49 --> Pixel_Model class loaded
INFO - 2018-10-23 17:07:49 --> Database Driver Class Initialized
INFO - 2018-10-23 17:07:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 17:07:49 --> Database Driver Class Initialized
INFO - 2018-10-23 17:07:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 17:08:08 --> Config Class Initialized
INFO - 2018-10-23 17:08:09 --> Hooks Class Initialized
DEBUG - 2018-10-23 17:08:09 --> UTF-8 Support Enabled
INFO - 2018-10-23 17:08:09 --> Utf8 Class Initialized
INFO - 2018-10-23 17:08:09 --> URI Class Initialized
INFO - 2018-10-23 17:08:09 --> Router Class Initialized
INFO - 2018-10-23 17:08:09 --> Output Class Initialized
INFO - 2018-10-23 17:08:09 --> Security Class Initialized
DEBUG - 2018-10-23 17:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 17:08:09 --> CSRF cookie sent
INFO - 2018-10-23 17:08:09 --> CSRF token verified
INFO - 2018-10-23 17:08:09 --> Input Class Initialized
INFO - 2018-10-23 17:08:09 --> Language Class Initialized
INFO - 2018-10-23 17:08:09 --> Loader Class Initialized
INFO - 2018-10-23 17:08:09 --> Helper loaded: url_helper
INFO - 2018-10-23 17:08:09 --> Helper loaded: form_helper
INFO - 2018-10-23 17:08:09 --> Helper loaded: language_helper
DEBUG - 2018-10-23 17:08:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 17:08:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 17:08:09 --> User Agent Class Initialized
INFO - 2018-10-23 17:08:09 --> Controller Class Initialized
INFO - 2018-10-23 17:08:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 17:08:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 17:08:09 --> Helper loaded: custom_helper
INFO - 2018-10-23 17:08:09 --> Pixel_Model class loaded
INFO - 2018-10-23 17:08:09 --> Database Driver Class Initialized
INFO - 2018-10-23 17:08:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 17:08:09 --> Database Driver Class Initialized
INFO - 2018-10-23 17:08:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 17:12:32 --> Config Class Initialized
INFO - 2018-10-23 17:12:32 --> Hooks Class Initialized
DEBUG - 2018-10-23 17:12:32 --> UTF-8 Support Enabled
INFO - 2018-10-23 17:12:32 --> Utf8 Class Initialized
INFO - 2018-10-23 17:12:32 --> URI Class Initialized
DEBUG - 2018-10-23 17:12:32 --> No URI present. Default controller set.
INFO - 2018-10-23 17:12:32 --> Router Class Initialized
INFO - 2018-10-23 17:12:32 --> Output Class Initialized
INFO - 2018-10-23 17:12:32 --> Security Class Initialized
DEBUG - 2018-10-23 17:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 17:12:32 --> CSRF cookie sent
INFO - 2018-10-23 17:12:32 --> Input Class Initialized
INFO - 2018-10-23 17:12:32 --> Language Class Initialized
INFO - 2018-10-23 17:12:33 --> Loader Class Initialized
INFO - 2018-10-23 17:12:33 --> Helper loaded: url_helper
INFO - 2018-10-23 17:12:33 --> Helper loaded: form_helper
INFO - 2018-10-23 17:12:33 --> Helper loaded: language_helper
DEBUG - 2018-10-23 17:12:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 17:12:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 17:12:33 --> User Agent Class Initialized
INFO - 2018-10-23 17:12:33 --> Controller Class Initialized
INFO - 2018-10-23 17:12:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 17:12:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 17:12:33 --> Helper loaded: custom_helper
INFO - 2018-10-23 17:12:33 --> Pixel_Model class loaded
INFO - 2018-10-23 17:12:33 --> Database Driver Class Initialized
INFO - 2018-10-23 17:12:33 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 17:12:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 17:12:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 17:12:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-23 17:12:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 17:12:33 --> Final output sent to browser
DEBUG - 2018-10-23 17:12:33 --> Total execution time: 0.6224
INFO - 2018-10-23 17:12:39 --> Config Class Initialized
INFO - 2018-10-23 17:12:39 --> Hooks Class Initialized
DEBUG - 2018-10-23 17:12:39 --> UTF-8 Support Enabled
INFO - 2018-10-23 17:12:39 --> Utf8 Class Initialized
INFO - 2018-10-23 17:12:39 --> URI Class Initialized
INFO - 2018-10-23 17:12:39 --> Router Class Initialized
INFO - 2018-10-23 17:12:39 --> Output Class Initialized
INFO - 2018-10-23 17:12:39 --> Security Class Initialized
DEBUG - 2018-10-23 17:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 17:12:39 --> CSRF cookie sent
INFO - 2018-10-23 17:12:39 --> CSRF token verified
INFO - 2018-10-23 17:12:39 --> Input Class Initialized
INFO - 2018-10-23 17:12:39 --> Language Class Initialized
INFO - 2018-10-23 17:12:39 --> Loader Class Initialized
INFO - 2018-10-23 17:12:39 --> Helper loaded: url_helper
INFO - 2018-10-23 17:12:39 --> Helper loaded: form_helper
INFO - 2018-10-23 17:12:39 --> Helper loaded: language_helper
DEBUG - 2018-10-23 17:12:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 17:12:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 17:12:39 --> User Agent Class Initialized
INFO - 2018-10-23 17:12:39 --> Controller Class Initialized
INFO - 2018-10-23 17:12:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 17:12:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 17:12:39 --> Helper loaded: custom_helper
INFO - 2018-10-23 17:12:40 --> Pixel_Model class loaded
INFO - 2018-10-23 17:12:40 --> Database Driver Class Initialized
INFO - 2018-10-23 17:12:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 17:12:40 --> Database Driver Class Initialized
INFO - 2018-10-23 17:12:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 17:12:40 --> Config Class Initialized
INFO - 2018-10-23 17:12:40 --> Hooks Class Initialized
DEBUG - 2018-10-23 17:12:40 --> UTF-8 Support Enabled
INFO - 2018-10-23 17:12:40 --> Utf8 Class Initialized
INFO - 2018-10-23 17:12:40 --> URI Class Initialized
DEBUG - 2018-10-23 17:12:40 --> No URI present. Default controller set.
INFO - 2018-10-23 17:12:40 --> Router Class Initialized
INFO - 2018-10-23 17:12:40 --> Output Class Initialized
INFO - 2018-10-23 17:12:40 --> Security Class Initialized
DEBUG - 2018-10-23 17:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 17:12:40 --> CSRF cookie sent
INFO - 2018-10-23 17:12:40 --> Input Class Initialized
INFO - 2018-10-23 17:12:40 --> Language Class Initialized
INFO - 2018-10-23 17:12:40 --> Loader Class Initialized
INFO - 2018-10-23 17:12:40 --> Helper loaded: url_helper
INFO - 2018-10-23 17:12:40 --> Helper loaded: form_helper
INFO - 2018-10-23 17:12:40 --> Helper loaded: language_helper
DEBUG - 2018-10-23 17:12:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 17:12:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 17:12:40 --> User Agent Class Initialized
INFO - 2018-10-23 17:12:40 --> Controller Class Initialized
INFO - 2018-10-23 17:12:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 17:12:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 17:12:40 --> Helper loaded: custom_helper
INFO - 2018-10-23 17:12:40 --> Pixel_Model class loaded
INFO - 2018-10-23 17:12:40 --> Database Driver Class Initialized
INFO - 2018-10-23 17:12:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 17:12:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 17:12:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 17:12:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-23 17:12:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 17:12:40 --> Final output sent to browser
DEBUG - 2018-10-23 17:12:40 --> Total execution time: 0.6074
INFO - 2018-10-23 17:12:46 --> Config Class Initialized
INFO - 2018-10-23 17:12:46 --> Hooks Class Initialized
DEBUG - 2018-10-23 17:12:46 --> UTF-8 Support Enabled
INFO - 2018-10-23 17:12:46 --> Utf8 Class Initialized
INFO - 2018-10-23 17:12:46 --> URI Class Initialized
DEBUG - 2018-10-23 17:12:46 --> No URI present. Default controller set.
INFO - 2018-10-23 17:12:46 --> Router Class Initialized
INFO - 2018-10-23 17:12:46 --> Output Class Initialized
INFO - 2018-10-23 17:12:47 --> Security Class Initialized
DEBUG - 2018-10-23 17:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 17:12:47 --> CSRF cookie sent
INFO - 2018-10-23 17:12:47 --> Input Class Initialized
INFO - 2018-10-23 17:12:47 --> Language Class Initialized
INFO - 2018-10-23 17:12:47 --> Loader Class Initialized
INFO - 2018-10-23 17:12:47 --> Helper loaded: url_helper
INFO - 2018-10-23 17:12:47 --> Helper loaded: form_helper
INFO - 2018-10-23 17:12:47 --> Helper loaded: language_helper
DEBUG - 2018-10-23 17:12:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 17:12:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 17:12:47 --> User Agent Class Initialized
INFO - 2018-10-23 17:12:47 --> Controller Class Initialized
INFO - 2018-10-23 17:12:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 17:12:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 17:12:47 --> Helper loaded: custom_helper
INFO - 2018-10-23 17:12:47 --> Pixel_Model class loaded
INFO - 2018-10-23 17:12:47 --> Database Driver Class Initialized
INFO - 2018-10-23 17:12:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 17:12:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 17:12:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 17:12:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-23 17:12:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 17:12:47 --> Final output sent to browser
DEBUG - 2018-10-23 17:12:47 --> Total execution time: 0.6216
INFO - 2018-10-23 17:12:51 --> Config Class Initialized
INFO - 2018-10-23 17:12:51 --> Hooks Class Initialized
DEBUG - 2018-10-23 17:12:51 --> UTF-8 Support Enabled
INFO - 2018-10-23 17:12:51 --> Utf8 Class Initialized
INFO - 2018-10-23 17:12:51 --> URI Class Initialized
INFO - 2018-10-23 17:12:51 --> Router Class Initialized
INFO - 2018-10-23 17:12:51 --> Output Class Initialized
INFO - 2018-10-23 17:12:51 --> Security Class Initialized
DEBUG - 2018-10-23 17:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 17:12:51 --> CSRF cookie sent
INFO - 2018-10-23 17:12:51 --> CSRF token verified
INFO - 2018-10-23 17:12:51 --> Input Class Initialized
INFO - 2018-10-23 17:12:51 --> Language Class Initialized
INFO - 2018-10-23 17:12:51 --> Loader Class Initialized
INFO - 2018-10-23 17:12:51 --> Helper loaded: url_helper
INFO - 2018-10-23 17:12:51 --> Helper loaded: form_helper
INFO - 2018-10-23 17:12:51 --> Helper loaded: language_helper
DEBUG - 2018-10-23 17:12:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 17:12:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 17:12:51 --> User Agent Class Initialized
INFO - 2018-10-23 17:12:51 --> Controller Class Initialized
INFO - 2018-10-23 17:12:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 17:12:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 17:12:51 --> Helper loaded: custom_helper
INFO - 2018-10-23 17:12:51 --> Pixel_Model class loaded
INFO - 2018-10-23 17:12:51 --> Database Driver Class Initialized
INFO - 2018-10-23 17:12:51 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 17:12:51 --> Database Driver Class Initialized
INFO - 2018-10-23 17:12:51 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 17:12:51 --> Config Class Initialized
INFO - 2018-10-23 17:12:51 --> Hooks Class Initialized
DEBUG - 2018-10-23 17:12:51 --> UTF-8 Support Enabled
INFO - 2018-10-23 17:12:51 --> Utf8 Class Initialized
INFO - 2018-10-23 17:12:51 --> URI Class Initialized
DEBUG - 2018-10-23 17:12:51 --> No URI present. Default controller set.
INFO - 2018-10-23 17:12:51 --> Router Class Initialized
INFO - 2018-10-23 17:12:51 --> Output Class Initialized
INFO - 2018-10-23 17:12:51 --> Security Class Initialized
DEBUG - 2018-10-23 17:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 17:12:51 --> CSRF cookie sent
INFO - 2018-10-23 17:12:51 --> Input Class Initialized
INFO - 2018-10-23 17:12:51 --> Language Class Initialized
INFO - 2018-10-23 17:12:51 --> Loader Class Initialized
INFO - 2018-10-23 17:12:51 --> Helper loaded: url_helper
INFO - 2018-10-23 17:12:51 --> Helper loaded: form_helper
INFO - 2018-10-23 17:12:51 --> Helper loaded: language_helper
DEBUG - 2018-10-23 17:12:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 17:12:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 17:12:52 --> User Agent Class Initialized
INFO - 2018-10-23 17:12:52 --> Controller Class Initialized
INFO - 2018-10-23 17:12:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 17:12:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 17:12:52 --> Helper loaded: custom_helper
INFO - 2018-10-23 17:12:52 --> Pixel_Model class loaded
INFO - 2018-10-23 17:12:52 --> Database Driver Class Initialized
INFO - 2018-10-23 17:12:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 17:12:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 17:12:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 17:12:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-23 17:12:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 17:12:52 --> Final output sent to browser
DEBUG - 2018-10-23 17:12:52 --> Total execution time: 0.6330
INFO - 2018-10-23 17:14:59 --> Config Class Initialized
INFO - 2018-10-23 17:14:59 --> Hooks Class Initialized
DEBUG - 2018-10-23 17:14:59 --> UTF-8 Support Enabled
INFO - 2018-10-23 17:14:59 --> Utf8 Class Initialized
INFO - 2018-10-23 17:14:59 --> URI Class Initialized
DEBUG - 2018-10-23 17:14:59 --> No URI present. Default controller set.
INFO - 2018-10-23 17:14:59 --> Router Class Initialized
INFO - 2018-10-23 17:14:59 --> Output Class Initialized
INFO - 2018-10-23 17:14:59 --> Security Class Initialized
DEBUG - 2018-10-23 17:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 17:14:59 --> CSRF cookie sent
INFO - 2018-10-23 17:14:59 --> Input Class Initialized
INFO - 2018-10-23 17:14:59 --> Language Class Initialized
INFO - 2018-10-23 17:14:59 --> Loader Class Initialized
INFO - 2018-10-23 17:14:59 --> Helper loaded: url_helper
INFO - 2018-10-23 17:14:59 --> Helper loaded: form_helper
INFO - 2018-10-23 17:14:59 --> Helper loaded: language_helper
DEBUG - 2018-10-23 17:14:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 17:14:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 17:14:59 --> User Agent Class Initialized
INFO - 2018-10-23 17:14:59 --> Controller Class Initialized
INFO - 2018-10-23 17:14:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 17:14:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 17:14:59 --> Helper loaded: custom_helper
INFO - 2018-10-23 17:14:59 --> Pixel_Model class loaded
INFO - 2018-10-23 17:14:59 --> Database Driver Class Initialized
INFO - 2018-10-23 17:14:59 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 17:14:59 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 17:14:59 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 17:14:59 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-23 17:14:59 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 17:14:59 --> Final output sent to browser
DEBUG - 2018-10-23 17:14:59 --> Total execution time: 0.6054
INFO - 2018-10-23 17:15:03 --> Config Class Initialized
INFO - 2018-10-23 17:15:03 --> Hooks Class Initialized
DEBUG - 2018-10-23 17:15:03 --> UTF-8 Support Enabled
INFO - 2018-10-23 17:15:03 --> Utf8 Class Initialized
INFO - 2018-10-23 17:15:03 --> URI Class Initialized
INFO - 2018-10-23 17:15:03 --> Router Class Initialized
INFO - 2018-10-23 17:15:03 --> Output Class Initialized
INFO - 2018-10-23 17:15:03 --> Security Class Initialized
DEBUG - 2018-10-23 17:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 17:15:03 --> CSRF cookie sent
INFO - 2018-10-23 17:15:03 --> CSRF token verified
INFO - 2018-10-23 17:15:03 --> Input Class Initialized
INFO - 2018-10-23 17:15:03 --> Language Class Initialized
INFO - 2018-10-23 17:15:03 --> Loader Class Initialized
INFO - 2018-10-23 17:15:03 --> Helper loaded: url_helper
INFO - 2018-10-23 17:15:03 --> Helper loaded: form_helper
INFO - 2018-10-23 17:15:03 --> Helper loaded: language_helper
DEBUG - 2018-10-23 17:15:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 17:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 17:15:03 --> User Agent Class Initialized
INFO - 2018-10-23 17:15:03 --> Controller Class Initialized
INFO - 2018-10-23 17:15:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 17:15:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 17:15:03 --> Helper loaded: custom_helper
INFO - 2018-10-23 17:15:03 --> Pixel_Model class loaded
INFO - 2018-10-23 17:15:03 --> Database Driver Class Initialized
INFO - 2018-10-23 17:15:03 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 17:15:03 --> Database Driver Class Initialized
INFO - 2018-10-23 17:15:03 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 17:15:04 --> Config Class Initialized
INFO - 2018-10-23 17:15:04 --> Hooks Class Initialized
DEBUG - 2018-10-23 17:15:04 --> UTF-8 Support Enabled
INFO - 2018-10-23 17:15:04 --> Utf8 Class Initialized
INFO - 2018-10-23 17:15:04 --> URI Class Initialized
INFO - 2018-10-23 17:15:04 --> Router Class Initialized
INFO - 2018-10-23 17:15:04 --> Output Class Initialized
INFO - 2018-10-23 17:15:04 --> Security Class Initialized
DEBUG - 2018-10-23 17:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 17:15:04 --> CSRF cookie sent
INFO - 2018-10-23 17:15:04 --> Input Class Initialized
INFO - 2018-10-23 17:15:04 --> Language Class Initialized
INFO - 2018-10-23 17:15:04 --> Loader Class Initialized
INFO - 2018-10-23 17:15:04 --> Helper loaded: url_helper
INFO - 2018-10-23 17:15:04 --> Helper loaded: form_helper
INFO - 2018-10-23 17:15:04 --> Helper loaded: language_helper
DEBUG - 2018-10-23 17:15:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 17:15:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 17:15:04 --> User Agent Class Initialized
INFO - 2018-10-23 17:15:04 --> Controller Class Initialized
INFO - 2018-10-23 17:15:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 17:15:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 17:15:04 --> Helper loaded: custom_helper
INFO - 2018-10-23 17:15:04 --> Pixel_Model class loaded
INFO - 2018-10-23 17:15:04 --> Database Driver Class Initialized
INFO - 2018-10-23 17:15:04 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 17:15:04 --> Database Driver Class Initialized
INFO - 2018-10-23 17:15:04 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 17:15:04 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 17:15:04 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 17:15:04 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 17:15:04 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 17:15:04 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 17:15:04 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 17:15:04 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-23 17:15:04 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 17:15:04 --> Final output sent to browser
DEBUG - 2018-10-23 17:15:04 --> Total execution time: 0.7345
INFO - 2018-10-23 17:15:08 --> Config Class Initialized
INFO - 2018-10-23 17:15:08 --> Hooks Class Initialized
DEBUG - 2018-10-23 17:15:08 --> UTF-8 Support Enabled
INFO - 2018-10-23 17:15:08 --> Utf8 Class Initialized
INFO - 2018-10-23 17:15:08 --> URI Class Initialized
INFO - 2018-10-23 17:15:08 --> Router Class Initialized
INFO - 2018-10-23 17:15:08 --> Output Class Initialized
INFO - 2018-10-23 17:15:08 --> Security Class Initialized
DEBUG - 2018-10-23 17:15:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 17:15:08 --> CSRF cookie sent
INFO - 2018-10-23 17:15:08 --> Input Class Initialized
INFO - 2018-10-23 17:15:08 --> Language Class Initialized
INFO - 2018-10-23 17:15:08 --> Loader Class Initialized
INFO - 2018-10-23 17:15:08 --> Helper loaded: url_helper
INFO - 2018-10-23 17:15:08 --> Helper loaded: form_helper
INFO - 2018-10-23 17:15:08 --> Helper loaded: language_helper
DEBUG - 2018-10-23 17:15:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 17:15:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 17:15:08 --> User Agent Class Initialized
INFO - 2018-10-23 17:15:08 --> Controller Class Initialized
INFO - 2018-10-23 17:15:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 17:15:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 17:15:08 --> Helper loaded: custom_helper
INFO - 2018-10-23 17:15:08 --> Pixel_Model class loaded
INFO - 2018-10-23 17:15:08 --> Database Driver Class Initialized
INFO - 2018-10-23 17:15:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 17:15:08 --> Database Driver Class Initialized
INFO - 2018-10-23 17:15:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 17:15:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 17:15:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 17:15:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 17:15:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 17:15:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 17:15:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 17:15:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-23 17:15:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 17:15:08 --> Final output sent to browser
DEBUG - 2018-10-23 17:15:08 --> Total execution time: 0.7572
INFO - 2018-10-23 17:17:33 --> Config Class Initialized
INFO - 2018-10-23 17:17:33 --> Hooks Class Initialized
DEBUG - 2018-10-23 17:17:33 --> UTF-8 Support Enabled
INFO - 2018-10-23 17:17:33 --> Utf8 Class Initialized
INFO - 2018-10-23 17:17:33 --> URI Class Initialized
INFO - 2018-10-23 17:17:33 --> Router Class Initialized
INFO - 2018-10-23 17:17:33 --> Output Class Initialized
INFO - 2018-10-23 17:17:33 --> Security Class Initialized
DEBUG - 2018-10-23 17:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 17:17:33 --> CSRF cookie sent
INFO - 2018-10-23 17:17:33 --> Input Class Initialized
INFO - 2018-10-23 17:17:33 --> Language Class Initialized
INFO - 2018-10-23 17:17:33 --> Loader Class Initialized
INFO - 2018-10-23 17:17:33 --> Helper loaded: url_helper
INFO - 2018-10-23 17:17:33 --> Helper loaded: form_helper
INFO - 2018-10-23 17:17:33 --> Helper loaded: language_helper
DEBUG - 2018-10-23 17:17:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 17:17:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 17:17:33 --> User Agent Class Initialized
INFO - 2018-10-23 17:17:33 --> Controller Class Initialized
INFO - 2018-10-23 17:17:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 17:17:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 17:17:33 --> Helper loaded: custom_helper
INFO - 2018-10-23 17:17:33 --> Pixel_Model class loaded
INFO - 2018-10-23 17:17:33 --> Database Driver Class Initialized
INFO - 2018-10-23 17:17:33 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 17:17:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 17:17:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 17:17:33 --> Config Class Initialized
INFO - 2018-10-23 17:17:33 --> Hooks Class Initialized
INFO - 2018-10-23 17:17:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 17:17:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
DEBUG - 2018-10-23 17:17:33 --> UTF-8 Support Enabled
INFO - 2018-10-23 17:17:33 --> Utf8 Class Initialized
INFO - 2018-10-23 17:17:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 17:17:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 17:17:34 --> URI Class Initialized
INFO - 2018-10-23 17:17:34 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
DEBUG - 2018-10-23 17:17:34 --> No URI present. Default controller set.
INFO - 2018-10-23 17:17:34 --> Router Class Initialized
INFO - 2018-10-23 17:17:34 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 17:17:34 --> Final output sent to browser
INFO - 2018-10-23 17:17:34 --> Output Class Initialized
DEBUG - 2018-10-23 17:17:34 --> Total execution time: 0.6588
INFO - 2018-10-23 17:17:34 --> Security Class Initialized
DEBUG - 2018-10-23 17:17:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 17:17:34 --> CSRF cookie sent
INFO - 2018-10-23 17:17:34 --> Input Class Initialized
INFO - 2018-10-23 17:17:34 --> Language Class Initialized
INFO - 2018-10-23 17:17:34 --> Loader Class Initialized
INFO - 2018-10-23 17:17:34 --> Helper loaded: url_helper
INFO - 2018-10-23 17:17:34 --> Helper loaded: form_helper
INFO - 2018-10-23 17:17:34 --> Helper loaded: language_helper
DEBUG - 2018-10-23 17:17:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 17:17:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 17:17:34 --> User Agent Class Initialized
INFO - 2018-10-23 17:17:34 --> Controller Class Initialized
INFO - 2018-10-23 17:17:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 17:17:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 17:17:34 --> Helper loaded: custom_helper
INFO - 2018-10-23 17:17:34 --> Pixel_Model class loaded
INFO - 2018-10-23 17:17:34 --> Database Driver Class Initialized
INFO - 2018-10-23 17:17:34 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 17:17:34 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 17:17:34 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 17:17:34 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-23 17:17:34 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 17:17:34 --> Final output sent to browser
DEBUG - 2018-10-23 17:17:34 --> Total execution time: 0.5566
INFO - 2018-10-23 17:17:38 --> Config Class Initialized
INFO - 2018-10-23 17:17:38 --> Hooks Class Initialized
DEBUG - 2018-10-23 17:17:38 --> UTF-8 Support Enabled
INFO - 2018-10-23 17:17:38 --> Utf8 Class Initialized
INFO - 2018-10-23 17:17:38 --> URI Class Initialized
INFO - 2018-10-23 17:17:38 --> Router Class Initialized
INFO - 2018-10-23 17:17:38 --> Output Class Initialized
INFO - 2018-10-23 17:17:38 --> Security Class Initialized
DEBUG - 2018-10-23 17:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 17:17:38 --> CSRF cookie sent
INFO - 2018-10-23 17:17:38 --> CSRF token verified
INFO - 2018-10-23 17:17:38 --> Input Class Initialized
INFO - 2018-10-23 17:17:38 --> Language Class Initialized
INFO - 2018-10-23 17:17:38 --> Loader Class Initialized
INFO - 2018-10-23 17:17:38 --> Helper loaded: url_helper
INFO - 2018-10-23 17:17:38 --> Helper loaded: form_helper
INFO - 2018-10-23 17:17:38 --> Helper loaded: language_helper
DEBUG - 2018-10-23 17:17:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 17:17:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 17:17:38 --> User Agent Class Initialized
INFO - 2018-10-23 17:17:38 --> Controller Class Initialized
INFO - 2018-10-23 17:17:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 17:17:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 17:17:38 --> Helper loaded: custom_helper
INFO - 2018-10-23 17:17:38 --> Pixel_Model class loaded
INFO - 2018-10-23 17:17:38 --> Database Driver Class Initialized
INFO - 2018-10-23 17:17:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 17:17:38 --> Database Driver Class Initialized
INFO - 2018-10-23 17:17:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 17:17:38 --> Config Class Initialized
INFO - 2018-10-23 17:17:38 --> Hooks Class Initialized
DEBUG - 2018-10-23 17:17:38 --> UTF-8 Support Enabled
INFO - 2018-10-23 17:17:38 --> Utf8 Class Initialized
INFO - 2018-10-23 17:17:38 --> URI Class Initialized
INFO - 2018-10-23 17:17:38 --> Router Class Initialized
INFO - 2018-10-23 17:17:39 --> Output Class Initialized
INFO - 2018-10-23 17:17:39 --> Security Class Initialized
DEBUG - 2018-10-23 17:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 17:17:39 --> CSRF cookie sent
INFO - 2018-10-23 17:17:39 --> Input Class Initialized
INFO - 2018-10-23 17:17:39 --> Language Class Initialized
INFO - 2018-10-23 17:17:39 --> Loader Class Initialized
INFO - 2018-10-23 17:17:39 --> Helper loaded: url_helper
INFO - 2018-10-23 17:17:39 --> Helper loaded: form_helper
INFO - 2018-10-23 17:17:39 --> Helper loaded: language_helper
DEBUG - 2018-10-23 17:17:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 17:17:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 17:17:39 --> User Agent Class Initialized
INFO - 2018-10-23 17:17:39 --> Controller Class Initialized
INFO - 2018-10-23 17:17:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 17:17:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 17:17:39 --> Helper loaded: custom_helper
INFO - 2018-10-23 17:17:39 --> Pixel_Model class loaded
INFO - 2018-10-23 17:17:39 --> Database Driver Class Initialized
INFO - 2018-10-23 17:17:39 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 17:17:39 --> Database Driver Class Initialized
INFO - 2018-10-23 17:17:39 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 17:17:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 17:17:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 17:17:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-23 17:17:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-23 17:17:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-23 17:17:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-23 17:17:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-23 17:17:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 17:17:39 --> Final output sent to browser
DEBUG - 2018-10-23 17:17:39 --> Total execution time: 0.7288
INFO - 2018-10-23 17:17:46 --> Config Class Initialized
INFO - 2018-10-23 17:17:46 --> Hooks Class Initialized
DEBUG - 2018-10-23 17:17:46 --> UTF-8 Support Enabled
INFO - 2018-10-23 17:17:46 --> Utf8 Class Initialized
INFO - 2018-10-23 17:17:46 --> URI Class Initialized
DEBUG - 2018-10-23 17:17:46 --> No URI present. Default controller set.
INFO - 2018-10-23 17:17:46 --> Router Class Initialized
INFO - 2018-10-23 17:17:46 --> Output Class Initialized
INFO - 2018-10-23 17:17:46 --> Security Class Initialized
DEBUG - 2018-10-23 17:17:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 17:17:46 --> CSRF cookie sent
INFO - 2018-10-23 17:17:46 --> Input Class Initialized
INFO - 2018-10-23 17:17:46 --> Language Class Initialized
INFO - 2018-10-23 17:17:46 --> Loader Class Initialized
INFO - 2018-10-23 17:17:46 --> Helper loaded: url_helper
INFO - 2018-10-23 17:17:47 --> Helper loaded: form_helper
INFO - 2018-10-23 17:17:47 --> Helper loaded: language_helper
DEBUG - 2018-10-23 17:17:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 17:17:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 17:17:47 --> User Agent Class Initialized
INFO - 2018-10-23 17:17:47 --> Controller Class Initialized
INFO - 2018-10-23 17:17:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 17:17:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 17:17:47 --> Helper loaded: custom_helper
INFO - 2018-10-23 17:17:47 --> Pixel_Model class loaded
INFO - 2018-10-23 17:17:47 --> Database Driver Class Initialized
INFO - 2018-10-23 17:17:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 17:17:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 17:17:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 17:17:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-23 17:17:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 17:17:47 --> Final output sent to browser
DEBUG - 2018-10-23 17:17:47 --> Total execution time: 0.6010
INFO - 2018-10-23 17:17:49 --> Config Class Initialized
INFO - 2018-10-23 17:17:49 --> Hooks Class Initialized
DEBUG - 2018-10-23 17:17:49 --> UTF-8 Support Enabled
INFO - 2018-10-23 17:17:49 --> Utf8 Class Initialized
INFO - 2018-10-23 17:17:49 --> URI Class Initialized
DEBUG - 2018-10-23 17:17:49 --> No URI present. Default controller set.
INFO - 2018-10-23 17:17:49 --> Router Class Initialized
INFO - 2018-10-23 17:17:49 --> Output Class Initialized
INFO - 2018-10-23 17:17:49 --> Security Class Initialized
DEBUG - 2018-10-23 17:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 17:17:49 --> CSRF cookie sent
INFO - 2018-10-23 17:17:49 --> Input Class Initialized
INFO - 2018-10-23 17:17:49 --> Language Class Initialized
INFO - 2018-10-23 17:17:49 --> Loader Class Initialized
INFO - 2018-10-23 17:17:49 --> Helper loaded: url_helper
INFO - 2018-10-23 17:17:49 --> Helper loaded: form_helper
INFO - 2018-10-23 17:17:49 --> Helper loaded: language_helper
DEBUG - 2018-10-23 17:17:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 17:17:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 17:17:49 --> User Agent Class Initialized
INFO - 2018-10-23 17:17:49 --> Controller Class Initialized
INFO - 2018-10-23 17:17:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 17:17:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 17:17:50 --> Helper loaded: custom_helper
INFO - 2018-10-23 17:17:50 --> Pixel_Model class loaded
INFO - 2018-10-23 17:17:50 --> Database Driver Class Initialized
INFO - 2018-10-23 17:17:50 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 17:17:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 17:17:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 17:17:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-23 17:17:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 17:17:50 --> Final output sent to browser
DEBUG - 2018-10-23 17:17:50 --> Total execution time: 0.6526
INFO - 2018-10-23 17:17:53 --> Config Class Initialized
INFO - 2018-10-23 17:17:53 --> Hooks Class Initialized
DEBUG - 2018-10-23 17:17:53 --> UTF-8 Support Enabled
INFO - 2018-10-23 17:17:53 --> Utf8 Class Initialized
INFO - 2018-10-23 17:17:53 --> URI Class Initialized
INFO - 2018-10-23 17:17:53 --> Router Class Initialized
INFO - 2018-10-23 17:17:53 --> Output Class Initialized
INFO - 2018-10-23 17:17:53 --> Security Class Initialized
DEBUG - 2018-10-23 17:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 17:17:53 --> CSRF cookie sent
INFO - 2018-10-23 17:17:54 --> CSRF token verified
INFO - 2018-10-23 17:17:54 --> Input Class Initialized
INFO - 2018-10-23 17:17:54 --> Language Class Initialized
INFO - 2018-10-23 17:17:54 --> Loader Class Initialized
INFO - 2018-10-23 17:17:54 --> Helper loaded: url_helper
INFO - 2018-10-23 17:17:54 --> Helper loaded: form_helper
INFO - 2018-10-23 17:17:54 --> Helper loaded: language_helper
DEBUG - 2018-10-23 17:17:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 17:17:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 17:17:54 --> User Agent Class Initialized
INFO - 2018-10-23 17:17:54 --> Controller Class Initialized
INFO - 2018-10-23 17:17:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 17:17:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 17:17:54 --> Helper loaded: custom_helper
INFO - 2018-10-23 17:17:54 --> Pixel_Model class loaded
INFO - 2018-10-23 17:17:54 --> Database Driver Class Initialized
INFO - 2018-10-23 17:17:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 17:17:54 --> Database Driver Class Initialized
INFO - 2018-10-23 17:17:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 17:18:24 --> Config Class Initialized
INFO - 2018-10-23 17:18:24 --> Hooks Class Initialized
DEBUG - 2018-10-23 17:18:24 --> UTF-8 Support Enabled
INFO - 2018-10-23 17:18:24 --> Utf8 Class Initialized
INFO - 2018-10-23 17:18:24 --> URI Class Initialized
DEBUG - 2018-10-23 17:18:24 --> No URI present. Default controller set.
INFO - 2018-10-23 17:18:24 --> Router Class Initialized
INFO - 2018-10-23 17:18:24 --> Output Class Initialized
INFO - 2018-10-23 17:18:24 --> Security Class Initialized
DEBUG - 2018-10-23 17:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-23 17:18:24 --> CSRF cookie sent
INFO - 2018-10-23 17:18:24 --> Input Class Initialized
INFO - 2018-10-23 17:18:24 --> Language Class Initialized
INFO - 2018-10-23 17:18:24 --> Loader Class Initialized
INFO - 2018-10-23 17:18:24 --> Helper loaded: url_helper
INFO - 2018-10-23 17:18:24 --> Helper loaded: form_helper
INFO - 2018-10-23 17:18:24 --> Helper loaded: language_helper
DEBUG - 2018-10-23 17:18:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-23 17:18:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-23 17:18:24 --> User Agent Class Initialized
INFO - 2018-10-23 17:18:24 --> Controller Class Initialized
INFO - 2018-10-23 17:18:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-23 17:18:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-23 17:18:24 --> Helper loaded: custom_helper
INFO - 2018-10-23 17:18:24 --> Pixel_Model class loaded
INFO - 2018-10-23 17:18:24 --> Database Driver Class Initialized
INFO - 2018-10-23 17:18:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-23 17:18:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-23 17:18:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-23 17:18:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-23 17:18:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-23 17:18:24 --> Final output sent to browser
DEBUG - 2018-10-23 17:18:24 --> Total execution time: 0.5979

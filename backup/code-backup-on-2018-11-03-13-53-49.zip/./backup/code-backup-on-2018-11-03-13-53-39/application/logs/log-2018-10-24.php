<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-10-24 17:46:37 --> Config Class Initialized
INFO - 2018-10-24 17:46:37 --> Hooks Class Initialized
DEBUG - 2018-10-24 17:46:37 --> UTF-8 Support Enabled
INFO - 2018-10-24 17:46:37 --> Utf8 Class Initialized
INFO - 2018-10-24 17:46:37 --> URI Class Initialized
DEBUG - 2018-10-24 17:46:37 --> No URI present. Default controller set.
INFO - 2018-10-24 17:46:37 --> Router Class Initialized
INFO - 2018-10-24 17:46:37 --> Output Class Initialized
INFO - 2018-10-24 17:46:37 --> Security Class Initialized
DEBUG - 2018-10-24 17:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-24 17:46:37 --> CSRF cookie sent
INFO - 2018-10-24 17:46:37 --> Input Class Initialized
INFO - 2018-10-24 17:46:37 --> Language Class Initialized
INFO - 2018-10-24 17:46:37 --> Loader Class Initialized
INFO - 2018-10-24 17:46:37 --> Helper loaded: url_helper
INFO - 2018-10-24 17:46:37 --> Helper loaded: form_helper
INFO - 2018-10-24 17:46:37 --> Helper loaded: language_helper
DEBUG - 2018-10-24 17:46:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-24 17:46:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-24 17:46:38 --> User Agent Class Initialized
INFO - 2018-10-24 17:46:38 --> Controller Class Initialized
INFO - 2018-10-24 17:46:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-24 17:46:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-24 17:46:38 --> Helper loaded: custom_helper
INFO - 2018-10-24 17:46:38 --> Pixel_Model class loaded
INFO - 2018-10-24 17:46:38 --> Database Driver Class Initialized
INFO - 2018-10-24 17:46:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:46:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-24 17:46:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-24 17:46:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-24 17:46:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-24 17:46:38 --> Final output sent to browser
DEBUG - 2018-10-24 17:46:38 --> Total execution time: 1.1536
INFO - 2018-10-24 17:47:49 --> Config Class Initialized
INFO - 2018-10-24 17:47:49 --> Hooks Class Initialized
DEBUG - 2018-10-24 17:47:49 --> UTF-8 Support Enabled
INFO - 2018-10-24 17:47:49 --> Utf8 Class Initialized
INFO - 2018-10-24 17:47:49 --> URI Class Initialized
INFO - 2018-10-24 17:47:49 --> Router Class Initialized
INFO - 2018-10-24 17:47:49 --> Output Class Initialized
INFO - 2018-10-24 17:47:49 --> Security Class Initialized
DEBUG - 2018-10-24 17:47:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-24 17:47:49 --> CSRF cookie sent
INFO - 2018-10-24 17:47:49 --> Input Class Initialized
INFO - 2018-10-24 17:47:49 --> Language Class Initialized
INFO - 2018-10-24 17:47:49 --> Loader Class Initialized
INFO - 2018-10-24 17:47:49 --> Helper loaded: url_helper
INFO - 2018-10-24 17:47:49 --> Helper loaded: form_helper
INFO - 2018-10-24 17:47:49 --> Helper loaded: language_helper
DEBUG - 2018-10-24 17:47:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-24 17:47:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-24 17:47:49 --> User Agent Class Initialized
INFO - 2018-10-24 17:47:49 --> Controller Class Initialized
INFO - 2018-10-24 17:47:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-24 17:47:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-24 17:47:49 --> Helper loaded: custom_helper
INFO - 2018-10-24 17:47:49 --> Pixel_Model class loaded
INFO - 2018-10-24 17:47:49 --> Database Driver Class Initialized
INFO - 2018-10-24 17:47:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:48:37 --> Config Class Initialized
INFO - 2018-10-24 17:48:37 --> Hooks Class Initialized
DEBUG - 2018-10-24 17:48:37 --> UTF-8 Support Enabled
INFO - 2018-10-24 17:48:37 --> Utf8 Class Initialized
INFO - 2018-10-24 17:48:37 --> URI Class Initialized
INFO - 2018-10-24 17:48:37 --> Router Class Initialized
INFO - 2018-10-24 17:48:37 --> Output Class Initialized
INFO - 2018-10-24 17:48:37 --> Security Class Initialized
DEBUG - 2018-10-24 17:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-24 17:48:37 --> CSRF cookie sent
INFO - 2018-10-24 17:48:37 --> Input Class Initialized
INFO - 2018-10-24 17:48:37 --> Language Class Initialized
INFO - 2018-10-24 17:48:37 --> Loader Class Initialized
INFO - 2018-10-24 17:48:37 --> Helper loaded: url_helper
INFO - 2018-10-24 17:48:37 --> Helper loaded: form_helper
INFO - 2018-10-24 17:48:37 --> Helper loaded: language_helper
DEBUG - 2018-10-24 17:48:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-24 17:48:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-24 17:48:37 --> User Agent Class Initialized
INFO - 2018-10-24 17:48:37 --> Controller Class Initialized
INFO - 2018-10-24 17:48:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-24 17:48:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-24 17:48:37 --> Helper loaded: custom_helper
INFO - 2018-10-24 17:48:37 --> Pixel_Model class loaded
INFO - 2018-10-24 17:48:37 --> Database Driver Class Initialized
INFO - 2018-10-24 17:48:37 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:48:37 --> Config Class Initialized
INFO - 2018-10-24 17:48:37 --> Hooks Class Initialized
DEBUG - 2018-10-24 17:48:37 --> UTF-8 Support Enabled
INFO - 2018-10-24 17:48:37 --> Utf8 Class Initialized
INFO - 2018-10-24 17:48:37 --> URI Class Initialized
INFO - 2018-10-24 17:48:37 --> Router Class Initialized
INFO - 2018-10-24 17:48:37 --> Output Class Initialized
INFO - 2018-10-24 17:48:37 --> Security Class Initialized
DEBUG - 2018-10-24 17:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-24 17:48:37 --> CSRF cookie sent
INFO - 2018-10-24 17:48:37 --> Input Class Initialized
INFO - 2018-10-24 17:48:37 --> Language Class Initialized
INFO - 2018-10-24 17:48:37 --> Loader Class Initialized
INFO - 2018-10-24 17:48:37 --> Helper loaded: url_helper
INFO - 2018-10-24 17:48:37 --> Helper loaded: form_helper
INFO - 2018-10-24 17:48:37 --> Helper loaded: language_helper
DEBUG - 2018-10-24 17:48:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-24 17:48:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-24 17:48:37 --> User Agent Class Initialized
INFO - 2018-10-24 17:48:37 --> Controller Class Initialized
INFO - 2018-10-24 17:48:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-24 17:48:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-24 17:48:37 --> Helper loaded: custom_helper
INFO - 2018-10-24 17:48:37 --> Pixel_Model class loaded
INFO - 2018-10-24 17:48:37 --> Database Driver Class Initialized
INFO - 2018-10-24 17:48:37 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:48:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-24 17:48:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-24 17:48:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-24 17:48:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-24 17:48:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-24 17:48:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-24 17:48:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-24 17:48:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-24 17:48:37 --> Final output sent to browser
DEBUG - 2018-10-24 17:48:37 --> Total execution time: 0.3843
INFO - 2018-10-24 17:48:40 --> Config Class Initialized
INFO - 2018-10-24 17:48:40 --> Hooks Class Initialized
DEBUG - 2018-10-24 17:48:40 --> UTF-8 Support Enabled
INFO - 2018-10-24 17:48:40 --> Utf8 Class Initialized
INFO - 2018-10-24 17:48:40 --> URI Class Initialized
INFO - 2018-10-24 17:48:40 --> Router Class Initialized
INFO - 2018-10-24 17:48:40 --> Output Class Initialized
INFO - 2018-10-24 17:48:40 --> Security Class Initialized
DEBUG - 2018-10-24 17:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-24 17:48:40 --> CSRF cookie sent
INFO - 2018-10-24 17:48:40 --> CSRF token verified
INFO - 2018-10-24 17:48:40 --> Input Class Initialized
INFO - 2018-10-24 17:48:40 --> Language Class Initialized
INFO - 2018-10-24 17:48:40 --> Loader Class Initialized
INFO - 2018-10-24 17:48:40 --> Helper loaded: url_helper
INFO - 2018-10-24 17:48:40 --> Helper loaded: form_helper
INFO - 2018-10-24 17:48:40 --> Helper loaded: language_helper
DEBUG - 2018-10-24 17:48:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-24 17:48:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-24 17:48:40 --> User Agent Class Initialized
INFO - 2018-10-24 17:48:40 --> Controller Class Initialized
INFO - 2018-10-24 17:48:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-24 17:48:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-24 17:48:40 --> Helper loaded: custom_helper
INFO - 2018-10-24 17:48:40 --> Pixel_Model class loaded
INFO - 2018-10-24 17:48:40 --> Database Driver Class Initialized
INFO - 2018-10-24 17:48:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:48:40 --> Database Driver Class Initialized
INFO - 2018-10-24 17:48:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:48:40 --> Config Class Initialized
INFO - 2018-10-24 17:48:40 --> Hooks Class Initialized
DEBUG - 2018-10-24 17:48:40 --> UTF-8 Support Enabled
INFO - 2018-10-24 17:48:40 --> Utf8 Class Initialized
INFO - 2018-10-24 17:48:40 --> URI Class Initialized
INFO - 2018-10-24 17:48:40 --> Router Class Initialized
INFO - 2018-10-24 17:48:40 --> Output Class Initialized
INFO - 2018-10-24 17:48:40 --> Security Class Initialized
DEBUG - 2018-10-24 17:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-24 17:48:40 --> CSRF cookie sent
INFO - 2018-10-24 17:48:40 --> Input Class Initialized
INFO - 2018-10-24 17:48:40 --> Language Class Initialized
INFO - 2018-10-24 17:48:40 --> Loader Class Initialized
INFO - 2018-10-24 17:48:40 --> Helper loaded: url_helper
INFO - 2018-10-24 17:48:40 --> Helper loaded: form_helper
INFO - 2018-10-24 17:48:40 --> Helper loaded: language_helper
DEBUG - 2018-10-24 17:48:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-24 17:48:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-24 17:48:40 --> User Agent Class Initialized
INFO - 2018-10-24 17:48:40 --> Controller Class Initialized
INFO - 2018-10-24 17:48:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-24 17:48:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-24 17:48:40 --> Helper loaded: custom_helper
INFO - 2018-10-24 17:48:40 --> Pixel_Model class loaded
INFO - 2018-10-24 17:48:40 --> Database Driver Class Initialized
INFO - 2018-10-24 17:48:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:48:40 --> Database Driver Class Initialized
INFO - 2018-10-24 17:48:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:48:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-24 17:48:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-24 17:48:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-24 17:48:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-24 17:48:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-24 17:48:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-24 17:48:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-24 17:48:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-24 17:48:41 --> Final output sent to browser
DEBUG - 2018-10-24 17:48:41 --> Total execution time: 0.4039
INFO - 2018-10-24 17:48:46 --> Config Class Initialized
INFO - 2018-10-24 17:48:46 --> Hooks Class Initialized
DEBUG - 2018-10-24 17:48:46 --> UTF-8 Support Enabled
INFO - 2018-10-24 17:48:46 --> Utf8 Class Initialized
INFO - 2018-10-24 17:48:46 --> URI Class Initialized
INFO - 2018-10-24 17:48:46 --> Router Class Initialized
INFO - 2018-10-24 17:48:46 --> Output Class Initialized
INFO - 2018-10-24 17:48:46 --> Security Class Initialized
DEBUG - 2018-10-24 17:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-24 17:48:46 --> CSRF cookie sent
INFO - 2018-10-24 17:48:46 --> CSRF token verified
INFO - 2018-10-24 17:48:46 --> Input Class Initialized
INFO - 2018-10-24 17:48:46 --> Language Class Initialized
INFO - 2018-10-24 17:48:46 --> Loader Class Initialized
INFO - 2018-10-24 17:48:46 --> Helper loaded: url_helper
INFO - 2018-10-24 17:48:46 --> Helper loaded: form_helper
INFO - 2018-10-24 17:48:46 --> Helper loaded: language_helper
DEBUG - 2018-10-24 17:48:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-24 17:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-24 17:48:46 --> User Agent Class Initialized
INFO - 2018-10-24 17:48:47 --> Controller Class Initialized
INFO - 2018-10-24 17:48:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-24 17:48:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-24 17:48:47 --> Helper loaded: custom_helper
INFO - 2018-10-24 17:48:47 --> Pixel_Model class loaded
INFO - 2018-10-24 17:48:47 --> Database Driver Class Initialized
INFO - 2018-10-24 17:48:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:48:47 --> Form Validation Class Initialized
INFO - 2018-10-24 17:48:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-24 17:48:47 --> Database Driver Class Initialized
INFO - 2018-10-24 17:48:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:48:47 --> Config Class Initialized
INFO - 2018-10-24 17:48:47 --> Hooks Class Initialized
DEBUG - 2018-10-24 17:48:47 --> UTF-8 Support Enabled
INFO - 2018-10-24 17:48:47 --> Utf8 Class Initialized
INFO - 2018-10-24 17:48:47 --> URI Class Initialized
INFO - 2018-10-24 17:48:47 --> Router Class Initialized
INFO - 2018-10-24 17:48:47 --> Output Class Initialized
INFO - 2018-10-24 17:48:47 --> Security Class Initialized
DEBUG - 2018-10-24 17:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-24 17:48:47 --> CSRF cookie sent
INFO - 2018-10-24 17:48:47 --> Input Class Initialized
INFO - 2018-10-24 17:48:47 --> Language Class Initialized
INFO - 2018-10-24 17:48:47 --> Loader Class Initialized
INFO - 2018-10-24 17:48:47 --> Helper loaded: url_helper
INFO - 2018-10-24 17:48:47 --> Helper loaded: form_helper
INFO - 2018-10-24 17:48:47 --> Helper loaded: language_helper
DEBUG - 2018-10-24 17:48:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-24 17:48:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-24 17:48:47 --> User Agent Class Initialized
INFO - 2018-10-24 17:48:47 --> Controller Class Initialized
INFO - 2018-10-24 17:48:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-24 17:48:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-24 17:48:47 --> Helper loaded: custom_helper
INFO - 2018-10-24 17:48:47 --> Pixel_Model class loaded
INFO - 2018-10-24 17:48:47 --> Database Driver Class Initialized
INFO - 2018-10-24 17:48:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:48:47 --> Database Driver Class Initialized
INFO - 2018-10-24 17:48:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:48:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-24 17:48:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-24 17:48:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-24 17:48:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-24 17:48:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-24 17:48:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-24 17:48:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/your_job.php
INFO - 2018-10-24 17:48:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-24 17:48:47 --> Final output sent to browser
DEBUG - 2018-10-24 17:48:47 --> Total execution time: 0.3537
INFO - 2018-10-24 17:48:48 --> Config Class Initialized
INFO - 2018-10-24 17:48:48 --> Hooks Class Initialized
DEBUG - 2018-10-24 17:48:48 --> UTF-8 Support Enabled
INFO - 2018-10-24 17:48:48 --> Utf8 Class Initialized
INFO - 2018-10-24 17:48:48 --> URI Class Initialized
INFO - 2018-10-24 17:48:48 --> Router Class Initialized
INFO - 2018-10-24 17:48:48 --> Output Class Initialized
INFO - 2018-10-24 17:48:48 --> Security Class Initialized
DEBUG - 2018-10-24 17:48:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-24 17:48:48 --> CSRF cookie sent
INFO - 2018-10-24 17:48:48 --> CSRF token verified
INFO - 2018-10-24 17:48:48 --> Input Class Initialized
INFO - 2018-10-24 17:48:48 --> Language Class Initialized
INFO - 2018-10-24 17:48:48 --> Loader Class Initialized
INFO - 2018-10-24 17:48:48 --> Helper loaded: url_helper
INFO - 2018-10-24 17:48:48 --> Helper loaded: form_helper
INFO - 2018-10-24 17:48:48 --> Helper loaded: language_helper
DEBUG - 2018-10-24 17:48:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-24 17:48:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-24 17:48:48 --> User Agent Class Initialized
INFO - 2018-10-24 17:48:48 --> Controller Class Initialized
INFO - 2018-10-24 17:48:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-24 17:48:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-24 17:48:48 --> Helper loaded: custom_helper
INFO - 2018-10-24 17:48:48 --> Pixel_Model class loaded
INFO - 2018-10-24 17:48:48 --> Database Driver Class Initialized
INFO - 2018-10-24 17:48:48 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:48:48 --> Form Validation Class Initialized
INFO - 2018-10-24 17:48:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-24 17:48:48 --> Database Driver Class Initialized
INFO - 2018-10-24 17:48:48 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:48:48 --> Config Class Initialized
INFO - 2018-10-24 17:48:49 --> Hooks Class Initialized
DEBUG - 2018-10-24 17:48:49 --> UTF-8 Support Enabled
INFO - 2018-10-24 17:48:49 --> Utf8 Class Initialized
INFO - 2018-10-24 17:48:49 --> URI Class Initialized
INFO - 2018-10-24 17:48:49 --> Router Class Initialized
INFO - 2018-10-24 17:48:49 --> Output Class Initialized
INFO - 2018-10-24 17:48:49 --> Security Class Initialized
DEBUG - 2018-10-24 17:48:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-24 17:48:49 --> CSRF cookie sent
INFO - 2018-10-24 17:48:49 --> Input Class Initialized
INFO - 2018-10-24 17:48:49 --> Language Class Initialized
INFO - 2018-10-24 17:48:49 --> Loader Class Initialized
INFO - 2018-10-24 17:48:49 --> Helper loaded: url_helper
INFO - 2018-10-24 17:48:49 --> Helper loaded: form_helper
INFO - 2018-10-24 17:48:49 --> Helper loaded: language_helper
DEBUG - 2018-10-24 17:48:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-24 17:48:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-24 17:48:49 --> User Agent Class Initialized
INFO - 2018-10-24 17:48:49 --> Controller Class Initialized
INFO - 2018-10-24 17:48:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-24 17:48:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-24 17:48:49 --> Helper loaded: custom_helper
INFO - 2018-10-24 17:48:49 --> Pixel_Model class loaded
INFO - 2018-10-24 17:48:49 --> Database Driver Class Initialized
INFO - 2018-10-24 17:48:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:48:49 --> Database Driver Class Initialized
INFO - 2018-10-24 17:48:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:48:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-24 17:48:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-24 17:48:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner.php
INFO - 2018-10-24 17:48:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-24 17:48:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-24 17:48:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-24 17:48:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-24 17:48:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/relation_ship_status.php
INFO - 2018-10-24 17:48:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-24 17:48:49 --> Final output sent to browser
DEBUG - 2018-10-24 17:48:49 --> Total execution time: 0.3837
INFO - 2018-10-24 17:48:51 --> Config Class Initialized
INFO - 2018-10-24 17:48:51 --> Hooks Class Initialized
DEBUG - 2018-10-24 17:48:51 --> UTF-8 Support Enabled
INFO - 2018-10-24 17:48:51 --> Utf8 Class Initialized
INFO - 2018-10-24 17:48:51 --> URI Class Initialized
INFO - 2018-10-24 17:48:51 --> Router Class Initialized
INFO - 2018-10-24 17:48:51 --> Output Class Initialized
INFO - 2018-10-24 17:48:51 --> Security Class Initialized
DEBUG - 2018-10-24 17:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-24 17:48:51 --> CSRF cookie sent
INFO - 2018-10-24 17:48:51 --> CSRF token verified
INFO - 2018-10-24 17:48:51 --> Input Class Initialized
INFO - 2018-10-24 17:48:51 --> Language Class Initialized
INFO - 2018-10-24 17:48:51 --> Loader Class Initialized
INFO - 2018-10-24 17:48:51 --> Helper loaded: url_helper
INFO - 2018-10-24 17:48:52 --> Helper loaded: form_helper
INFO - 2018-10-24 17:48:52 --> Helper loaded: language_helper
DEBUG - 2018-10-24 17:48:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-24 17:48:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-24 17:48:52 --> User Agent Class Initialized
INFO - 2018-10-24 17:48:52 --> Controller Class Initialized
INFO - 2018-10-24 17:48:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-24 17:48:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-24 17:48:52 --> Helper loaded: custom_helper
INFO - 2018-10-24 17:48:52 --> Pixel_Model class loaded
INFO - 2018-10-24 17:48:52 --> Database Driver Class Initialized
INFO - 2018-10-24 17:48:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:48:52 --> Form Validation Class Initialized
INFO - 2018-10-24 17:48:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-24 17:48:52 --> Database Driver Class Initialized
INFO - 2018-10-24 17:48:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:48:52 --> Config Class Initialized
INFO - 2018-10-24 17:48:52 --> Hooks Class Initialized
DEBUG - 2018-10-24 17:48:52 --> UTF-8 Support Enabled
INFO - 2018-10-24 17:48:52 --> Utf8 Class Initialized
INFO - 2018-10-24 17:48:52 --> URI Class Initialized
INFO - 2018-10-24 17:48:52 --> Router Class Initialized
INFO - 2018-10-24 17:48:52 --> Output Class Initialized
INFO - 2018-10-24 17:48:52 --> Security Class Initialized
DEBUG - 2018-10-24 17:48:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-24 17:48:52 --> CSRF cookie sent
INFO - 2018-10-24 17:48:52 --> Input Class Initialized
INFO - 2018-10-24 17:48:52 --> Language Class Initialized
INFO - 2018-10-24 17:48:52 --> Loader Class Initialized
INFO - 2018-10-24 17:48:52 --> Helper loaded: url_helper
INFO - 2018-10-24 17:48:52 --> Helper loaded: form_helper
INFO - 2018-10-24 17:48:52 --> Helper loaded: language_helper
DEBUG - 2018-10-24 17:48:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-24 17:48:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-24 17:48:52 --> User Agent Class Initialized
INFO - 2018-10-24 17:48:52 --> Controller Class Initialized
INFO - 2018-10-24 17:48:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-24 17:48:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-24 17:48:52 --> Helper loaded: custom_helper
INFO - 2018-10-24 17:48:52 --> Pixel_Model class loaded
INFO - 2018-10-24 17:48:52 --> Database Driver Class Initialized
INFO - 2018-10-24 17:48:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:48:52 --> Database Driver Class Initialized
INFO - 2018-10-24 17:48:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:48:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-24 17:48:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-24 17:48:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-24 17:48:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-24 17:48:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-24 17:48:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-24 17:48:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/income.php
INFO - 2018-10-24 17:48:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-24 17:48:52 --> Final output sent to browser
DEBUG - 2018-10-24 17:48:52 --> Total execution time: 0.4119
INFO - 2018-10-24 17:49:44 --> Config Class Initialized
INFO - 2018-10-24 17:49:44 --> Hooks Class Initialized
DEBUG - 2018-10-24 17:49:44 --> UTF-8 Support Enabled
INFO - 2018-10-24 17:49:44 --> Utf8 Class Initialized
INFO - 2018-10-24 17:49:44 --> URI Class Initialized
INFO - 2018-10-24 17:49:44 --> Router Class Initialized
INFO - 2018-10-24 17:49:44 --> Output Class Initialized
INFO - 2018-10-24 17:49:44 --> Security Class Initialized
DEBUG - 2018-10-24 17:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-24 17:49:44 --> CSRF cookie sent
INFO - 2018-10-24 17:49:44 --> Input Class Initialized
INFO - 2018-10-24 17:49:44 --> Language Class Initialized
INFO - 2018-10-24 17:49:45 --> Loader Class Initialized
INFO - 2018-10-24 17:49:45 --> Helper loaded: url_helper
INFO - 2018-10-24 17:49:45 --> Helper loaded: form_helper
INFO - 2018-10-24 17:49:45 --> Helper loaded: language_helper
DEBUG - 2018-10-24 17:49:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-24 17:49:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-24 17:49:45 --> User Agent Class Initialized
INFO - 2018-10-24 17:49:45 --> Controller Class Initialized
INFO - 2018-10-24 17:49:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-24 17:49:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-24 17:49:45 --> Helper loaded: custom_helper
INFO - 2018-10-24 17:49:45 --> Pixel_Model class loaded
INFO - 2018-10-24 17:49:45 --> Database Driver Class Initialized
INFO - 2018-10-24 17:49:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:49:45 --> Database Driver Class Initialized
INFO - 2018-10-24 17:49:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:49:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-24 17:49:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-24 17:49:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-24 17:49:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-24 17:49:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-24 17:49:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-24 17:49:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/income.php
INFO - 2018-10-24 17:49:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-24 17:49:45 --> Final output sent to browser
DEBUG - 2018-10-24 17:49:45 --> Total execution time: 0.3499
INFO - 2018-10-24 17:50:00 --> Config Class Initialized
INFO - 2018-10-24 17:50:00 --> Hooks Class Initialized
DEBUG - 2018-10-24 17:50:00 --> UTF-8 Support Enabled
INFO - 2018-10-24 17:50:00 --> Utf8 Class Initialized
INFO - 2018-10-24 17:50:00 --> URI Class Initialized
INFO - 2018-10-24 17:50:00 --> Router Class Initialized
INFO - 2018-10-24 17:50:00 --> Output Class Initialized
INFO - 2018-10-24 17:50:00 --> Security Class Initialized
DEBUG - 2018-10-24 17:50:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-24 17:50:00 --> CSRF cookie sent
INFO - 2018-10-24 17:50:00 --> Input Class Initialized
INFO - 2018-10-24 17:50:00 --> Language Class Initialized
INFO - 2018-10-24 17:50:00 --> Loader Class Initialized
INFO - 2018-10-24 17:50:00 --> Helper loaded: url_helper
INFO - 2018-10-24 17:50:00 --> Helper loaded: form_helper
INFO - 2018-10-24 17:50:00 --> Helper loaded: language_helper
DEBUG - 2018-10-24 17:50:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-24 17:50:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-24 17:50:00 --> User Agent Class Initialized
INFO - 2018-10-24 17:50:00 --> Controller Class Initialized
INFO - 2018-10-24 17:50:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-24 17:50:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-24 17:50:00 --> Helper loaded: custom_helper
INFO - 2018-10-24 17:50:00 --> Pixel_Model class loaded
INFO - 2018-10-24 17:50:00 --> Database Driver Class Initialized
INFO - 2018-10-24 17:50:00 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:50:01 --> Database Driver Class Initialized
INFO - 2018-10-24 17:50:01 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:50:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-24 17:50:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-24 17:50:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-24 17:50:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-24 17:50:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-24 17:50:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-24 17:50:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/coh_home_title.php
INFO - 2018-10-24 17:50:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-24 17:50:01 --> Final output sent to browser
DEBUG - 2018-10-24 17:50:01 --> Total execution time: 0.3871
INFO - 2018-10-24 17:50:21 --> Config Class Initialized
INFO - 2018-10-24 17:50:21 --> Hooks Class Initialized
DEBUG - 2018-10-24 17:50:21 --> UTF-8 Support Enabled
INFO - 2018-10-24 17:50:21 --> Utf8 Class Initialized
INFO - 2018-10-24 17:50:21 --> URI Class Initialized
INFO - 2018-10-24 17:50:21 --> Router Class Initialized
INFO - 2018-10-24 17:50:22 --> Output Class Initialized
INFO - 2018-10-24 17:50:22 --> Security Class Initialized
DEBUG - 2018-10-24 17:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-24 17:50:22 --> CSRF cookie sent
INFO - 2018-10-24 17:50:22 --> Input Class Initialized
INFO - 2018-10-24 17:50:22 --> Language Class Initialized
INFO - 2018-10-24 17:50:22 --> Loader Class Initialized
INFO - 2018-10-24 17:50:22 --> Helper loaded: url_helper
INFO - 2018-10-24 17:50:22 --> Helper loaded: form_helper
INFO - 2018-10-24 17:50:22 --> Helper loaded: language_helper
DEBUG - 2018-10-24 17:50:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-24 17:50:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-24 17:50:22 --> User Agent Class Initialized
INFO - 2018-10-24 17:50:22 --> Controller Class Initialized
INFO - 2018-10-24 17:50:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-24 17:50:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-24 17:50:22 --> Helper loaded: custom_helper
INFO - 2018-10-24 17:50:22 --> Pixel_Model class loaded
INFO - 2018-10-24 17:50:22 --> Database Driver Class Initialized
INFO - 2018-10-24 17:50:22 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:50:22 --> Database Driver Class Initialized
INFO - 2018-10-24 17:50:22 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:50:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-24 17:50:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-24 17:50:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-24 17:50:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-24 17:50:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-24 17:50:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-24 17:50:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/coh_home_title.php
INFO - 2018-10-24 17:50:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-24 17:50:22 --> Final output sent to browser
DEBUG - 2018-10-24 17:50:22 --> Total execution time: 0.3333
INFO - 2018-10-24 17:51:04 --> Config Class Initialized
INFO - 2018-10-24 17:51:04 --> Hooks Class Initialized
DEBUG - 2018-10-24 17:51:04 --> UTF-8 Support Enabled
INFO - 2018-10-24 17:51:04 --> Utf8 Class Initialized
INFO - 2018-10-24 17:51:04 --> URI Class Initialized
INFO - 2018-10-24 17:51:04 --> Router Class Initialized
INFO - 2018-10-24 17:51:04 --> Output Class Initialized
INFO - 2018-10-24 17:51:04 --> Security Class Initialized
DEBUG - 2018-10-24 17:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-24 17:51:04 --> CSRF cookie sent
INFO - 2018-10-24 17:51:04 --> Input Class Initialized
INFO - 2018-10-24 17:51:04 --> Language Class Initialized
INFO - 2018-10-24 17:51:04 --> Loader Class Initialized
INFO - 2018-10-24 17:51:04 --> Helper loaded: url_helper
INFO - 2018-10-24 17:51:04 --> Helper loaded: form_helper
INFO - 2018-10-24 17:51:04 --> Helper loaded: language_helper
DEBUG - 2018-10-24 17:51:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-24 17:51:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-24 17:51:04 --> User Agent Class Initialized
INFO - 2018-10-24 17:51:04 --> Controller Class Initialized
INFO - 2018-10-24 17:51:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-24 17:51:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-24 17:51:04 --> Helper loaded: custom_helper
INFO - 2018-10-24 17:51:04 --> Pixel_Model class loaded
INFO - 2018-10-24 17:51:04 --> Database Driver Class Initialized
INFO - 2018-10-24 17:51:04 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:51:04 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-24 17:51:04 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-24 17:51:04 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-24 17:51:04 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-24 17:51:04 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-24 17:51:04 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-24 17:51:04 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-24 17:51:04 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-24 17:51:04 --> Final output sent to browser
DEBUG - 2018-10-24 17:51:04 --> Total execution time: 0.3314
INFO - 2018-10-24 17:51:06 --> Config Class Initialized
INFO - 2018-10-24 17:51:06 --> Hooks Class Initialized
DEBUG - 2018-10-24 17:51:06 --> UTF-8 Support Enabled
INFO - 2018-10-24 17:51:06 --> Utf8 Class Initialized
INFO - 2018-10-24 17:51:06 --> URI Class Initialized
INFO - 2018-10-24 17:51:06 --> Router Class Initialized
INFO - 2018-10-24 17:51:06 --> Output Class Initialized
INFO - 2018-10-24 17:51:06 --> Security Class Initialized
DEBUG - 2018-10-24 17:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-24 17:51:06 --> CSRF cookie sent
INFO - 2018-10-24 17:51:06 --> CSRF token verified
INFO - 2018-10-24 17:51:06 --> Input Class Initialized
INFO - 2018-10-24 17:51:06 --> Language Class Initialized
INFO - 2018-10-24 17:51:06 --> Loader Class Initialized
INFO - 2018-10-24 17:51:06 --> Helper loaded: url_helper
INFO - 2018-10-24 17:51:06 --> Helper loaded: form_helper
INFO - 2018-10-24 17:51:06 --> Helper loaded: language_helper
DEBUG - 2018-10-24 17:51:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-24 17:51:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-24 17:51:06 --> User Agent Class Initialized
INFO - 2018-10-24 17:51:06 --> Controller Class Initialized
INFO - 2018-10-24 17:51:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-24 17:51:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-24 17:51:06 --> Helper loaded: custom_helper
INFO - 2018-10-24 17:51:06 --> Pixel_Model class loaded
INFO - 2018-10-24 17:51:06 --> Database Driver Class Initialized
INFO - 2018-10-24 17:51:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:51:06 --> Database Driver Class Initialized
INFO - 2018-10-24 17:51:07 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:51:07 --> Config Class Initialized
INFO - 2018-10-24 17:51:07 --> Hooks Class Initialized
DEBUG - 2018-10-24 17:51:07 --> UTF-8 Support Enabled
INFO - 2018-10-24 17:51:07 --> Utf8 Class Initialized
INFO - 2018-10-24 17:51:07 --> URI Class Initialized
INFO - 2018-10-24 17:51:07 --> Router Class Initialized
INFO - 2018-10-24 17:51:07 --> Output Class Initialized
INFO - 2018-10-24 17:51:07 --> Security Class Initialized
DEBUG - 2018-10-24 17:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-24 17:51:07 --> CSRF cookie sent
INFO - 2018-10-24 17:51:07 --> Input Class Initialized
INFO - 2018-10-24 17:51:07 --> Language Class Initialized
INFO - 2018-10-24 17:51:07 --> Loader Class Initialized
INFO - 2018-10-24 17:51:07 --> Helper loaded: url_helper
INFO - 2018-10-24 17:51:07 --> Helper loaded: form_helper
INFO - 2018-10-24 17:51:07 --> Helper loaded: language_helper
DEBUG - 2018-10-24 17:51:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-24 17:51:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-24 17:51:07 --> User Agent Class Initialized
INFO - 2018-10-24 17:51:07 --> Controller Class Initialized
INFO - 2018-10-24 17:51:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-24 17:51:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-24 17:51:07 --> Helper loaded: custom_helper
INFO - 2018-10-24 17:51:07 --> Pixel_Model class loaded
INFO - 2018-10-24 17:51:07 --> Database Driver Class Initialized
INFO - 2018-10-24 17:51:07 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:51:07 --> Database Driver Class Initialized
INFO - 2018-10-24 17:51:07 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:51:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-24 17:51:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-24 17:51:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-24 17:51:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-24 17:51:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-24 17:51:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-24 17:51:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/income.php
INFO - 2018-10-24 17:51:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-24 17:51:07 --> Final output sent to browser
DEBUG - 2018-10-24 17:51:07 --> Total execution time: 0.3613
INFO - 2018-10-24 17:51:14 --> Config Class Initialized
INFO - 2018-10-24 17:51:14 --> Hooks Class Initialized
DEBUG - 2018-10-24 17:51:14 --> UTF-8 Support Enabled
INFO - 2018-10-24 17:51:14 --> Utf8 Class Initialized
INFO - 2018-10-24 17:51:14 --> URI Class Initialized
INFO - 2018-10-24 17:51:14 --> Router Class Initialized
INFO - 2018-10-24 17:51:14 --> Output Class Initialized
INFO - 2018-10-24 17:51:14 --> Security Class Initialized
DEBUG - 2018-10-24 17:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-24 17:51:14 --> CSRF cookie sent
INFO - 2018-10-24 17:51:14 --> Input Class Initialized
INFO - 2018-10-24 17:51:14 --> Language Class Initialized
INFO - 2018-10-24 17:51:14 --> Loader Class Initialized
INFO - 2018-10-24 17:51:14 --> Helper loaded: url_helper
INFO - 2018-10-24 17:51:14 --> Helper loaded: form_helper
INFO - 2018-10-24 17:51:14 --> Helper loaded: language_helper
DEBUG - 2018-10-24 17:51:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-24 17:51:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-24 17:51:14 --> User Agent Class Initialized
INFO - 2018-10-24 17:51:14 --> Controller Class Initialized
INFO - 2018-10-24 17:51:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-24 17:51:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-24 17:51:14 --> Helper loaded: custom_helper
INFO - 2018-10-24 17:51:14 --> Pixel_Model class loaded
INFO - 2018-10-24 17:51:14 --> Database Driver Class Initialized
INFO - 2018-10-24 17:51:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:51:14 --> Database Driver Class Initialized
INFO - 2018-10-24 17:51:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:51:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-24 17:51:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-24 17:51:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-24 17:51:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-24 17:51:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-24 17:51:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-24 17:51:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/income.php
INFO - 2018-10-24 17:51:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-24 17:51:14 --> Final output sent to browser
DEBUG - 2018-10-24 17:51:14 --> Total execution time: 0.4011
INFO - 2018-10-24 17:51:21 --> Config Class Initialized
INFO - 2018-10-24 17:51:21 --> Hooks Class Initialized
DEBUG - 2018-10-24 17:51:21 --> UTF-8 Support Enabled
INFO - 2018-10-24 17:51:21 --> Utf8 Class Initialized
INFO - 2018-10-24 17:51:21 --> URI Class Initialized
INFO - 2018-10-24 17:51:21 --> Router Class Initialized
INFO - 2018-10-24 17:51:21 --> Output Class Initialized
INFO - 2018-10-24 17:51:21 --> Security Class Initialized
DEBUG - 2018-10-24 17:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-24 17:51:21 --> CSRF cookie sent
INFO - 2018-10-24 17:51:21 --> CSRF token verified
INFO - 2018-10-24 17:51:21 --> Input Class Initialized
INFO - 2018-10-24 17:51:21 --> Language Class Initialized
INFO - 2018-10-24 17:51:21 --> Loader Class Initialized
INFO - 2018-10-24 17:51:21 --> Helper loaded: url_helper
INFO - 2018-10-24 17:51:21 --> Helper loaded: form_helper
INFO - 2018-10-24 17:51:21 --> Helper loaded: language_helper
DEBUG - 2018-10-24 17:51:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-24 17:51:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-24 17:51:21 --> User Agent Class Initialized
INFO - 2018-10-24 17:51:21 --> Controller Class Initialized
INFO - 2018-10-24 17:51:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-24 17:51:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-24 17:51:21 --> Helper loaded: custom_helper
INFO - 2018-10-24 17:51:21 --> Pixel_Model class loaded
INFO - 2018-10-24 17:51:21 --> Database Driver Class Initialized
INFO - 2018-10-24 17:51:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:51:21 --> Form Validation Class Initialized
INFO - 2018-10-24 17:51:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-24 17:51:21 --> Database Driver Class Initialized
INFO - 2018-10-24 17:51:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:51:21 --> Config Class Initialized
INFO - 2018-10-24 17:51:21 --> Hooks Class Initialized
DEBUG - 2018-10-24 17:51:21 --> UTF-8 Support Enabled
INFO - 2018-10-24 17:51:21 --> Utf8 Class Initialized
INFO - 2018-10-24 17:51:21 --> URI Class Initialized
INFO - 2018-10-24 17:51:21 --> Router Class Initialized
INFO - 2018-10-24 17:51:21 --> Output Class Initialized
INFO - 2018-10-24 17:51:21 --> Security Class Initialized
DEBUG - 2018-10-24 17:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-24 17:51:21 --> CSRF cookie sent
INFO - 2018-10-24 17:51:21 --> Input Class Initialized
INFO - 2018-10-24 17:51:21 --> Language Class Initialized
INFO - 2018-10-24 17:51:21 --> Loader Class Initialized
INFO - 2018-10-24 17:51:21 --> Helper loaded: url_helper
INFO - 2018-10-24 17:51:21 --> Helper loaded: form_helper
INFO - 2018-10-24 17:51:21 --> Helper loaded: language_helper
DEBUG - 2018-10-24 17:51:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-24 17:51:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-24 17:51:21 --> User Agent Class Initialized
INFO - 2018-10-24 17:51:21 --> Controller Class Initialized
INFO - 2018-10-24 17:51:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-24 17:51:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-24 17:51:21 --> Helper loaded: custom_helper
INFO - 2018-10-24 17:51:21 --> Pixel_Model class loaded
INFO - 2018-10-24 17:51:21 --> Database Driver Class Initialized
INFO - 2018-10-24 17:51:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:51:21 --> Database Driver Class Initialized
INFO - 2018-10-24 17:51:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:51:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-24 17:51:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-24 17:51:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-24 17:51:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-24 17:51:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-24 17:51:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-24 17:51:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/marriage.php
INFO - 2018-10-24 17:51:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-24 17:51:22 --> Final output sent to browser
DEBUG - 2018-10-24 17:51:22 --> Total execution time: 0.3845
INFO - 2018-10-24 17:51:23 --> Config Class Initialized
INFO - 2018-10-24 17:51:23 --> Hooks Class Initialized
DEBUG - 2018-10-24 17:51:23 --> UTF-8 Support Enabled
INFO - 2018-10-24 17:51:23 --> Utf8 Class Initialized
INFO - 2018-10-24 17:51:23 --> URI Class Initialized
INFO - 2018-10-24 17:51:23 --> Router Class Initialized
INFO - 2018-10-24 17:51:23 --> Output Class Initialized
INFO - 2018-10-24 17:51:23 --> Security Class Initialized
DEBUG - 2018-10-24 17:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-24 17:51:23 --> CSRF cookie sent
INFO - 2018-10-24 17:51:23 --> CSRF token verified
INFO - 2018-10-24 17:51:23 --> Input Class Initialized
INFO - 2018-10-24 17:51:23 --> Language Class Initialized
INFO - 2018-10-24 17:51:23 --> Loader Class Initialized
INFO - 2018-10-24 17:51:23 --> Helper loaded: url_helper
INFO - 2018-10-24 17:51:23 --> Helper loaded: form_helper
INFO - 2018-10-24 17:51:23 --> Helper loaded: language_helper
DEBUG - 2018-10-24 17:51:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-24 17:51:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-24 17:51:23 --> User Agent Class Initialized
INFO - 2018-10-24 17:51:23 --> Controller Class Initialized
INFO - 2018-10-24 17:51:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-24 17:51:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-24 17:51:23 --> Helper loaded: custom_helper
INFO - 2018-10-24 17:51:23 --> Pixel_Model class loaded
INFO - 2018-10-24 17:51:23 --> Database Driver Class Initialized
INFO - 2018-10-24 17:51:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:51:23 --> Form Validation Class Initialized
INFO - 2018-10-24 17:51:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-24 17:51:23 --> Database Driver Class Initialized
INFO - 2018-10-24 17:51:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:51:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-24 17:51:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-24 17:51:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-24 17:51:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-24 17:51:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-24 17:51:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_errors.php
INFO - 2018-10-24 17:51:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-24 17:51:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/marriage.php
INFO - 2018-10-24 17:51:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-24 17:51:23 --> Final output sent to browser
DEBUG - 2018-10-24 17:51:23 --> Total execution time: 0.4336
INFO - 2018-10-24 17:51:29 --> Config Class Initialized
INFO - 2018-10-24 17:51:29 --> Hooks Class Initialized
DEBUG - 2018-10-24 17:51:29 --> UTF-8 Support Enabled
INFO - 2018-10-24 17:51:29 --> Utf8 Class Initialized
INFO - 2018-10-24 17:51:29 --> URI Class Initialized
INFO - 2018-10-24 17:51:29 --> Router Class Initialized
INFO - 2018-10-24 17:51:29 --> Output Class Initialized
INFO - 2018-10-24 17:51:29 --> Security Class Initialized
DEBUG - 2018-10-24 17:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-24 17:51:29 --> CSRF cookie sent
INFO - 2018-10-24 17:51:29 --> Input Class Initialized
INFO - 2018-10-24 17:51:29 --> Language Class Initialized
INFO - 2018-10-24 17:51:29 --> Loader Class Initialized
INFO - 2018-10-24 17:51:29 --> Helper loaded: url_helper
INFO - 2018-10-24 17:51:30 --> Helper loaded: form_helper
INFO - 2018-10-24 17:51:30 --> Helper loaded: language_helper
DEBUG - 2018-10-24 17:51:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-24 17:51:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-24 17:51:30 --> User Agent Class Initialized
INFO - 2018-10-24 17:51:30 --> Controller Class Initialized
INFO - 2018-10-24 17:51:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-24 17:51:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-24 17:51:30 --> Helper loaded: custom_helper
INFO - 2018-10-24 17:51:30 --> Pixel_Model class loaded
INFO - 2018-10-24 17:51:30 --> Database Driver Class Initialized
INFO - 2018-10-24 17:51:30 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:51:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-24 17:51:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-24 17:51:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-24 17:51:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-24 17:51:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-24 17:51:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-24 17:51:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-24 17:51:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-24 17:51:30 --> Final output sent to browser
DEBUG - 2018-10-24 17:51:30 --> Total execution time: 0.3520
INFO - 2018-10-24 17:51:33 --> Config Class Initialized
INFO - 2018-10-24 17:51:33 --> Hooks Class Initialized
DEBUG - 2018-10-24 17:51:33 --> UTF-8 Support Enabled
INFO - 2018-10-24 17:51:33 --> Utf8 Class Initialized
INFO - 2018-10-24 17:51:33 --> URI Class Initialized
INFO - 2018-10-24 17:51:33 --> Router Class Initialized
INFO - 2018-10-24 17:51:33 --> Output Class Initialized
INFO - 2018-10-24 17:51:33 --> Security Class Initialized
DEBUG - 2018-10-24 17:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-24 17:51:33 --> CSRF cookie sent
INFO - 2018-10-24 17:51:33 --> CSRF token verified
INFO - 2018-10-24 17:51:33 --> Input Class Initialized
INFO - 2018-10-24 17:51:33 --> Language Class Initialized
INFO - 2018-10-24 17:51:33 --> Loader Class Initialized
INFO - 2018-10-24 17:51:33 --> Helper loaded: url_helper
INFO - 2018-10-24 17:51:33 --> Helper loaded: form_helper
INFO - 2018-10-24 17:51:33 --> Helper loaded: language_helper
DEBUG - 2018-10-24 17:51:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-24 17:51:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-24 17:51:33 --> User Agent Class Initialized
INFO - 2018-10-24 17:51:33 --> Controller Class Initialized
INFO - 2018-10-24 17:51:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-24 17:51:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-24 17:51:33 --> Helper loaded: custom_helper
INFO - 2018-10-24 17:51:33 --> Pixel_Model class loaded
INFO - 2018-10-24 17:51:33 --> Database Driver Class Initialized
INFO - 2018-10-24 17:51:33 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:51:33 --> Database Driver Class Initialized
INFO - 2018-10-24 17:51:33 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:51:33 --> Config Class Initialized
INFO - 2018-10-24 17:51:33 --> Hooks Class Initialized
DEBUG - 2018-10-24 17:51:33 --> UTF-8 Support Enabled
INFO - 2018-10-24 17:51:33 --> Utf8 Class Initialized
INFO - 2018-10-24 17:51:33 --> URI Class Initialized
INFO - 2018-10-24 17:51:33 --> Router Class Initialized
INFO - 2018-10-24 17:51:33 --> Output Class Initialized
INFO - 2018-10-24 17:51:33 --> Security Class Initialized
DEBUG - 2018-10-24 17:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-24 17:51:33 --> CSRF cookie sent
INFO - 2018-10-24 17:51:33 --> Input Class Initialized
INFO - 2018-10-24 17:51:33 --> Language Class Initialized
INFO - 2018-10-24 17:51:33 --> Loader Class Initialized
INFO - 2018-10-24 17:51:33 --> Helper loaded: url_helper
INFO - 2018-10-24 17:51:33 --> Helper loaded: form_helper
INFO - 2018-10-24 17:51:33 --> Helper loaded: language_helper
DEBUG - 2018-10-24 17:51:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-24 17:51:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-24 17:51:33 --> User Agent Class Initialized
INFO - 2018-10-24 17:51:33 --> Controller Class Initialized
INFO - 2018-10-24 17:51:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-24 17:51:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-24 17:51:33 --> Helper loaded: custom_helper
INFO - 2018-10-24 17:51:33 --> Pixel_Model class loaded
INFO - 2018-10-24 17:51:33 --> Database Driver Class Initialized
INFO - 2018-10-24 17:51:33 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:51:33 --> Database Driver Class Initialized
INFO - 2018-10-24 17:51:33 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:51:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-24 17:51:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-24 17:51:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-24 17:51:34 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-24 17:51:34 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-24 17:51:34 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-24 17:51:34 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/marriage.php
INFO - 2018-10-24 17:51:34 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-24 17:51:34 --> Final output sent to browser
DEBUG - 2018-10-24 17:51:34 --> Total execution time: 0.3861
INFO - 2018-10-24 17:51:35 --> Config Class Initialized
INFO - 2018-10-24 17:51:35 --> Hooks Class Initialized
DEBUG - 2018-10-24 17:51:35 --> UTF-8 Support Enabled
INFO - 2018-10-24 17:51:35 --> Utf8 Class Initialized
INFO - 2018-10-24 17:51:35 --> URI Class Initialized
INFO - 2018-10-24 17:51:35 --> Router Class Initialized
INFO - 2018-10-24 17:51:35 --> Output Class Initialized
INFO - 2018-10-24 17:51:35 --> Security Class Initialized
DEBUG - 2018-10-24 17:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-24 17:51:35 --> CSRF cookie sent
INFO - 2018-10-24 17:51:35 --> CSRF token verified
INFO - 2018-10-24 17:51:35 --> Input Class Initialized
INFO - 2018-10-24 17:51:35 --> Language Class Initialized
INFO - 2018-10-24 17:51:35 --> Loader Class Initialized
INFO - 2018-10-24 17:51:35 --> Helper loaded: url_helper
INFO - 2018-10-24 17:51:35 --> Helper loaded: form_helper
INFO - 2018-10-24 17:51:35 --> Helper loaded: language_helper
DEBUG - 2018-10-24 17:51:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-24 17:51:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-24 17:51:35 --> User Agent Class Initialized
INFO - 2018-10-24 17:51:35 --> Controller Class Initialized
INFO - 2018-10-24 17:51:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-24 17:51:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-24 17:51:35 --> Helper loaded: custom_helper
INFO - 2018-10-24 17:51:35 --> Pixel_Model class loaded
INFO - 2018-10-24 17:51:35 --> Database Driver Class Initialized
INFO - 2018-10-24 17:51:35 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:51:35 --> Form Validation Class Initialized
INFO - 2018-10-24 17:51:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-24 17:51:35 --> Database Driver Class Initialized
INFO - 2018-10-24 17:51:35 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:51:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-24 17:51:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-24 17:51:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-24 17:51:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-24 17:51:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-24 17:51:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_errors.php
INFO - 2018-10-24 17:51:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-24 17:51:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/marriage.php
INFO - 2018-10-24 17:51:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-24 17:51:35 --> Final output sent to browser
DEBUG - 2018-10-24 17:51:35 --> Total execution time: 0.4614
INFO - 2018-10-24 17:51:38 --> Config Class Initialized
INFO - 2018-10-24 17:51:38 --> Hooks Class Initialized
DEBUG - 2018-10-24 17:51:38 --> UTF-8 Support Enabled
INFO - 2018-10-24 17:51:38 --> Utf8 Class Initialized
INFO - 2018-10-24 17:51:38 --> URI Class Initialized
INFO - 2018-10-24 17:51:38 --> Router Class Initialized
INFO - 2018-10-24 17:51:38 --> Output Class Initialized
INFO - 2018-10-24 17:51:38 --> Security Class Initialized
DEBUG - 2018-10-24 17:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-24 17:51:38 --> CSRF cookie sent
INFO - 2018-10-24 17:51:38 --> CSRF token verified
INFO - 2018-10-24 17:51:38 --> Input Class Initialized
INFO - 2018-10-24 17:51:38 --> Language Class Initialized
INFO - 2018-10-24 17:51:38 --> Loader Class Initialized
INFO - 2018-10-24 17:51:38 --> Helper loaded: url_helper
INFO - 2018-10-24 17:51:38 --> Helper loaded: form_helper
INFO - 2018-10-24 17:51:38 --> Helper loaded: language_helper
DEBUG - 2018-10-24 17:51:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-24 17:51:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-24 17:51:38 --> User Agent Class Initialized
INFO - 2018-10-24 17:51:38 --> Controller Class Initialized
INFO - 2018-10-24 17:51:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-24 17:51:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-24 17:51:38 --> Helper loaded: custom_helper
INFO - 2018-10-24 17:51:38 --> Pixel_Model class loaded
INFO - 2018-10-24 17:51:38 --> Database Driver Class Initialized
INFO - 2018-10-24 17:51:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:51:38 --> Form Validation Class Initialized
INFO - 2018-10-24 17:51:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-24 17:51:38 --> Database Driver Class Initialized
INFO - 2018-10-24 17:51:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:51:39 --> Config Class Initialized
INFO - 2018-10-24 17:51:39 --> Hooks Class Initialized
DEBUG - 2018-10-24 17:51:39 --> UTF-8 Support Enabled
INFO - 2018-10-24 17:51:39 --> Utf8 Class Initialized
INFO - 2018-10-24 17:51:39 --> URI Class Initialized
INFO - 2018-10-24 17:51:39 --> Router Class Initialized
INFO - 2018-10-24 17:51:39 --> Output Class Initialized
INFO - 2018-10-24 17:51:39 --> Security Class Initialized
DEBUG - 2018-10-24 17:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-24 17:51:39 --> CSRF cookie sent
INFO - 2018-10-24 17:51:39 --> Input Class Initialized
INFO - 2018-10-24 17:51:39 --> Language Class Initialized
INFO - 2018-10-24 17:51:39 --> Loader Class Initialized
INFO - 2018-10-24 17:51:39 --> Helper loaded: url_helper
INFO - 2018-10-24 17:51:39 --> Helper loaded: form_helper
INFO - 2018-10-24 17:51:39 --> Helper loaded: language_helper
DEBUG - 2018-10-24 17:51:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-24 17:51:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-24 17:51:39 --> User Agent Class Initialized
INFO - 2018-10-24 17:51:39 --> Controller Class Initialized
INFO - 2018-10-24 17:51:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-24 17:51:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-24 17:51:39 --> Helper loaded: custom_helper
INFO - 2018-10-24 17:51:39 --> Pixel_Model class loaded
INFO - 2018-10-24 17:51:39 --> Database Driver Class Initialized
INFO - 2018-10-24 17:51:39 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:51:39 --> Database Driver Class Initialized
INFO - 2018-10-24 17:51:39 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:51:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-24 17:51:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-24 17:51:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-24 17:51:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-24 17:51:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-24 17:51:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-24 17:51:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/kids.php
INFO - 2018-10-24 17:51:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-24 17:51:39 --> Final output sent to browser
DEBUG - 2018-10-24 17:51:39 --> Total execution time: 0.4411
INFO - 2018-10-24 17:51:40 --> Config Class Initialized
INFO - 2018-10-24 17:51:40 --> Hooks Class Initialized
DEBUG - 2018-10-24 17:51:40 --> UTF-8 Support Enabled
INFO - 2018-10-24 17:51:40 --> Utf8 Class Initialized
INFO - 2018-10-24 17:51:40 --> URI Class Initialized
INFO - 2018-10-24 17:51:40 --> Router Class Initialized
INFO - 2018-10-24 17:51:40 --> Output Class Initialized
INFO - 2018-10-24 17:51:40 --> Security Class Initialized
DEBUG - 2018-10-24 17:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-24 17:51:40 --> CSRF cookie sent
INFO - 2018-10-24 17:51:40 --> CSRF token verified
INFO - 2018-10-24 17:51:40 --> Input Class Initialized
INFO - 2018-10-24 17:51:40 --> Language Class Initialized
INFO - 2018-10-24 17:51:40 --> Loader Class Initialized
INFO - 2018-10-24 17:51:40 --> Helper loaded: url_helper
INFO - 2018-10-24 17:51:40 --> Helper loaded: form_helper
INFO - 2018-10-24 17:51:40 --> Helper loaded: language_helper
DEBUG - 2018-10-24 17:51:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-24 17:51:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-24 17:51:40 --> User Agent Class Initialized
INFO - 2018-10-24 17:51:40 --> Controller Class Initialized
INFO - 2018-10-24 17:51:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-24 17:51:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-24 17:51:40 --> Helper loaded: custom_helper
INFO - 2018-10-24 17:51:40 --> Pixel_Model class loaded
INFO - 2018-10-24 17:51:40 --> Database Driver Class Initialized
INFO - 2018-10-24 17:51:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:51:40 --> Form Validation Class Initialized
INFO - 2018-10-24 17:51:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-24 17:51:40 --> Database Driver Class Initialized
INFO - 2018-10-24 17:51:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:51:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-24 17:51:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-24 17:51:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-24 17:51:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-24 17:51:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-24 17:51:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_errors.php
INFO - 2018-10-24 17:51:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-24 17:51:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/kids.php
INFO - 2018-10-24 17:51:40 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-24 17:51:40 --> Final output sent to browser
DEBUG - 2018-10-24 17:51:40 --> Total execution time: 0.4336
INFO - 2018-10-24 17:51:43 --> Config Class Initialized
INFO - 2018-10-24 17:51:43 --> Hooks Class Initialized
DEBUG - 2018-10-24 17:51:43 --> UTF-8 Support Enabled
INFO - 2018-10-24 17:51:43 --> Utf8 Class Initialized
INFO - 2018-10-24 17:51:43 --> URI Class Initialized
INFO - 2018-10-24 17:51:43 --> Router Class Initialized
INFO - 2018-10-24 17:51:43 --> Output Class Initialized
INFO - 2018-10-24 17:51:43 --> Security Class Initialized
DEBUG - 2018-10-24 17:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-24 17:51:43 --> CSRF cookie sent
INFO - 2018-10-24 17:51:43 --> CSRF token verified
INFO - 2018-10-24 17:51:43 --> Input Class Initialized
INFO - 2018-10-24 17:51:43 --> Language Class Initialized
INFO - 2018-10-24 17:51:43 --> Loader Class Initialized
INFO - 2018-10-24 17:51:43 --> Helper loaded: url_helper
INFO - 2018-10-24 17:51:43 --> Helper loaded: form_helper
INFO - 2018-10-24 17:51:43 --> Helper loaded: language_helper
DEBUG - 2018-10-24 17:51:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-24 17:51:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-24 17:51:43 --> User Agent Class Initialized
INFO - 2018-10-24 17:51:43 --> Controller Class Initialized
INFO - 2018-10-24 17:51:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-24 17:51:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-24 17:51:43 --> Helper loaded: custom_helper
INFO - 2018-10-24 17:51:43 --> Pixel_Model class loaded
INFO - 2018-10-24 17:51:43 --> Database Driver Class Initialized
INFO - 2018-10-24 17:51:43 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:51:43 --> Form Validation Class Initialized
INFO - 2018-10-24 17:51:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-24 17:51:43 --> Database Driver Class Initialized
INFO - 2018-10-24 17:51:43 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:51:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-24 17:51:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-24 17:51:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-24 17:51:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-24 17:51:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-24 17:51:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_errors.php
INFO - 2018-10-24 17:51:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-24 17:51:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/kids.php
INFO - 2018-10-24 17:51:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-24 17:51:44 --> Final output sent to browser
DEBUG - 2018-10-24 17:51:44 --> Total execution time: 0.4490
INFO - 2018-10-24 17:51:47 --> Config Class Initialized
INFO - 2018-10-24 17:51:47 --> Hooks Class Initialized
DEBUG - 2018-10-24 17:51:47 --> UTF-8 Support Enabled
INFO - 2018-10-24 17:51:47 --> Utf8 Class Initialized
INFO - 2018-10-24 17:51:47 --> URI Class Initialized
INFO - 2018-10-24 17:51:47 --> Router Class Initialized
INFO - 2018-10-24 17:51:47 --> Output Class Initialized
INFO - 2018-10-24 17:51:47 --> Security Class Initialized
DEBUG - 2018-10-24 17:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-24 17:51:47 --> CSRF cookie sent
INFO - 2018-10-24 17:51:47 --> CSRF token verified
INFO - 2018-10-24 17:51:47 --> Input Class Initialized
INFO - 2018-10-24 17:51:47 --> Language Class Initialized
INFO - 2018-10-24 17:51:47 --> Loader Class Initialized
INFO - 2018-10-24 17:51:47 --> Helper loaded: url_helper
INFO - 2018-10-24 17:51:47 --> Helper loaded: form_helper
INFO - 2018-10-24 17:51:47 --> Helper loaded: language_helper
DEBUG - 2018-10-24 17:51:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-24 17:51:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-24 17:51:47 --> User Agent Class Initialized
INFO - 2018-10-24 17:51:47 --> Controller Class Initialized
INFO - 2018-10-24 17:51:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-24 17:51:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-24 17:51:47 --> Helper loaded: custom_helper
INFO - 2018-10-24 17:51:47 --> Pixel_Model class loaded
INFO - 2018-10-24 17:51:47 --> Database Driver Class Initialized
INFO - 2018-10-24 17:51:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:51:47 --> Form Validation Class Initialized
INFO - 2018-10-24 17:51:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-24 17:51:47 --> Database Driver Class Initialized
INFO - 2018-10-24 17:51:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:51:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-24 17:51:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-24 17:51:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-24 17:51:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-24 17:51:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-24 17:51:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_errors.php
INFO - 2018-10-24 17:51:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-24 17:51:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/kids.php
INFO - 2018-10-24 17:51:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-24 17:51:47 --> Final output sent to browser
DEBUG - 2018-10-24 17:51:47 --> Total execution time: 0.4253
INFO - 2018-10-24 17:51:49 --> Config Class Initialized
INFO - 2018-10-24 17:51:49 --> Hooks Class Initialized
DEBUG - 2018-10-24 17:51:49 --> UTF-8 Support Enabled
INFO - 2018-10-24 17:51:49 --> Utf8 Class Initialized
INFO - 2018-10-24 17:51:49 --> URI Class Initialized
INFO - 2018-10-24 17:51:49 --> Router Class Initialized
INFO - 2018-10-24 17:51:50 --> Output Class Initialized
INFO - 2018-10-24 17:51:50 --> Security Class Initialized
DEBUG - 2018-10-24 17:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-24 17:51:50 --> CSRF cookie sent
INFO - 2018-10-24 17:51:50 --> CSRF token verified
INFO - 2018-10-24 17:51:50 --> Input Class Initialized
INFO - 2018-10-24 17:51:50 --> Language Class Initialized
INFO - 2018-10-24 17:51:50 --> Loader Class Initialized
INFO - 2018-10-24 17:51:50 --> Helper loaded: url_helper
INFO - 2018-10-24 17:51:50 --> Helper loaded: form_helper
INFO - 2018-10-24 17:51:50 --> Helper loaded: language_helper
DEBUG - 2018-10-24 17:51:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-24 17:51:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-24 17:51:50 --> User Agent Class Initialized
INFO - 2018-10-24 17:51:50 --> Controller Class Initialized
INFO - 2018-10-24 17:51:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-24 17:51:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-24 17:51:50 --> Helper loaded: custom_helper
INFO - 2018-10-24 17:51:50 --> Pixel_Model class loaded
INFO - 2018-10-24 17:51:50 --> Database Driver Class Initialized
INFO - 2018-10-24 17:51:50 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:51:50 --> Form Validation Class Initialized
INFO - 2018-10-24 17:51:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-24 17:51:50 --> Database Driver Class Initialized
INFO - 2018-10-24 17:51:50 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:51:50 --> Config Class Initialized
INFO - 2018-10-24 17:51:50 --> Hooks Class Initialized
DEBUG - 2018-10-24 17:51:50 --> UTF-8 Support Enabled
INFO - 2018-10-24 17:51:50 --> Utf8 Class Initialized
INFO - 2018-10-24 17:51:50 --> URI Class Initialized
INFO - 2018-10-24 17:51:50 --> Router Class Initialized
INFO - 2018-10-24 17:51:50 --> Output Class Initialized
INFO - 2018-10-24 17:51:50 --> Security Class Initialized
DEBUG - 2018-10-24 17:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-24 17:51:50 --> CSRF cookie sent
INFO - 2018-10-24 17:51:50 --> Input Class Initialized
INFO - 2018-10-24 17:51:50 --> Language Class Initialized
INFO - 2018-10-24 17:51:50 --> Loader Class Initialized
INFO - 2018-10-24 17:51:50 --> Helper loaded: url_helper
INFO - 2018-10-24 17:51:50 --> Helper loaded: form_helper
INFO - 2018-10-24 17:51:50 --> Helper loaded: language_helper
DEBUG - 2018-10-24 17:51:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-24 17:51:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-24 17:51:50 --> User Agent Class Initialized
INFO - 2018-10-24 17:51:50 --> Controller Class Initialized
INFO - 2018-10-24 17:51:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-24 17:51:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-24 17:51:50 --> Helper loaded: custom_helper
INFO - 2018-10-24 17:51:50 --> Pixel_Model class loaded
INFO - 2018-10-24 17:51:50 --> Database Driver Class Initialized
INFO - 2018-10-24 17:51:50 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:51:50 --> Database Driver Class Initialized
INFO - 2018-10-24 17:51:50 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:51:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-24 17:51:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-24 17:51:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-24 17:51:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-24 17:51:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-24 17:51:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-24 17:51:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/pension.php
INFO - 2018-10-24 17:51:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-24 17:51:50 --> Final output sent to browser
DEBUG - 2018-10-24 17:51:50 --> Total execution time: 0.4605
INFO - 2018-10-24 17:51:55 --> Config Class Initialized
INFO - 2018-10-24 17:51:55 --> Hooks Class Initialized
DEBUG - 2018-10-24 17:51:55 --> UTF-8 Support Enabled
INFO - 2018-10-24 17:51:55 --> Utf8 Class Initialized
INFO - 2018-10-24 17:51:55 --> URI Class Initialized
INFO - 2018-10-24 17:51:55 --> Router Class Initialized
INFO - 2018-10-24 17:51:55 --> Output Class Initialized
INFO - 2018-10-24 17:51:55 --> Security Class Initialized
DEBUG - 2018-10-24 17:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-24 17:51:55 --> CSRF cookie sent
INFO - 2018-10-24 17:51:55 --> CSRF token verified
INFO - 2018-10-24 17:51:55 --> Input Class Initialized
INFO - 2018-10-24 17:51:55 --> Language Class Initialized
INFO - 2018-10-24 17:51:55 --> Loader Class Initialized
INFO - 2018-10-24 17:51:55 --> Helper loaded: url_helper
INFO - 2018-10-24 17:51:55 --> Helper loaded: form_helper
INFO - 2018-10-24 17:51:55 --> Helper loaded: language_helper
DEBUG - 2018-10-24 17:51:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-24 17:51:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-24 17:51:55 --> User Agent Class Initialized
INFO - 2018-10-24 17:51:55 --> Controller Class Initialized
INFO - 2018-10-24 17:51:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-24 17:51:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-24 17:51:55 --> Helper loaded: custom_helper
INFO - 2018-10-24 17:51:55 --> Pixel_Model class loaded
INFO - 2018-10-24 17:51:55 --> Database Driver Class Initialized
INFO - 2018-10-24 17:51:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:51:55 --> Form Validation Class Initialized
INFO - 2018-10-24 17:51:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-24 17:51:55 --> Database Driver Class Initialized
INFO - 2018-10-24 17:51:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:51:55 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-24 17:51:55 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-24 17:51:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-24 17:51:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-24 17:51:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-24 17:51:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_errors.php
INFO - 2018-10-24 17:51:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-24 17:51:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/pension.php
INFO - 2018-10-24 17:51:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-24 17:51:56 --> Final output sent to browser
DEBUG - 2018-10-24 17:51:56 --> Total execution time: 0.4501
INFO - 2018-10-24 17:51:58 --> Config Class Initialized
INFO - 2018-10-24 17:51:58 --> Hooks Class Initialized
DEBUG - 2018-10-24 17:51:58 --> UTF-8 Support Enabled
INFO - 2018-10-24 17:51:58 --> Utf8 Class Initialized
INFO - 2018-10-24 17:51:58 --> URI Class Initialized
INFO - 2018-10-24 17:51:58 --> Router Class Initialized
INFO - 2018-10-24 17:51:58 --> Output Class Initialized
INFO - 2018-10-24 17:51:58 --> Security Class Initialized
DEBUG - 2018-10-24 17:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-24 17:51:58 --> CSRF cookie sent
INFO - 2018-10-24 17:51:58 --> CSRF token verified
INFO - 2018-10-24 17:51:58 --> Input Class Initialized
INFO - 2018-10-24 17:51:58 --> Language Class Initialized
INFO - 2018-10-24 17:51:58 --> Loader Class Initialized
INFO - 2018-10-24 17:51:58 --> Helper loaded: url_helper
INFO - 2018-10-24 17:51:58 --> Helper loaded: form_helper
INFO - 2018-10-24 17:51:58 --> Helper loaded: language_helper
DEBUG - 2018-10-24 17:51:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-24 17:51:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-24 17:51:58 --> User Agent Class Initialized
INFO - 2018-10-24 17:51:58 --> Controller Class Initialized
INFO - 2018-10-24 17:51:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-24 17:51:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-24 17:51:58 --> Helper loaded: custom_helper
INFO - 2018-10-24 17:51:58 --> Pixel_Model class loaded
INFO - 2018-10-24 17:51:58 --> Database Driver Class Initialized
INFO - 2018-10-24 17:51:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:51:58 --> Form Validation Class Initialized
INFO - 2018-10-24 17:51:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-24 17:51:58 --> Database Driver Class Initialized
INFO - 2018-10-24 17:51:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:51:58 --> Config Class Initialized
INFO - 2018-10-24 17:51:58 --> Hooks Class Initialized
DEBUG - 2018-10-24 17:51:58 --> UTF-8 Support Enabled
INFO - 2018-10-24 17:51:58 --> Utf8 Class Initialized
INFO - 2018-10-24 17:51:58 --> URI Class Initialized
INFO - 2018-10-24 17:51:58 --> Router Class Initialized
INFO - 2018-10-24 17:51:58 --> Output Class Initialized
INFO - 2018-10-24 17:51:58 --> Security Class Initialized
DEBUG - 2018-10-24 17:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-24 17:51:58 --> CSRF cookie sent
INFO - 2018-10-24 17:51:58 --> Input Class Initialized
INFO - 2018-10-24 17:51:58 --> Language Class Initialized
INFO - 2018-10-24 17:51:58 --> Loader Class Initialized
INFO - 2018-10-24 17:51:58 --> Helper loaded: url_helper
INFO - 2018-10-24 17:51:58 --> Helper loaded: form_helper
INFO - 2018-10-24 17:51:58 --> Helper loaded: language_helper
DEBUG - 2018-10-24 17:51:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-24 17:51:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-24 17:51:58 --> User Agent Class Initialized
INFO - 2018-10-24 17:51:58 --> Controller Class Initialized
INFO - 2018-10-24 17:51:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-24 17:51:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-24 17:51:58 --> Helper loaded: custom_helper
INFO - 2018-10-24 17:51:58 --> Pixel_Model class loaded
INFO - 2018-10-24 17:51:58 --> Database Driver Class Initialized
INFO - 2018-10-24 17:51:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:51:58 --> Database Driver Class Initialized
INFO - 2018-10-24 17:51:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:51:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-24 17:51:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-24 17:51:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-24 17:51:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-24 17:51:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-24 17:51:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-24 17:51:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/inheritance.php
INFO - 2018-10-24 17:51:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-24 17:51:58 --> Final output sent to browser
DEBUG - 2018-10-24 17:51:58 --> Total execution time: 0.4370
INFO - 2018-10-24 17:52:01 --> Config Class Initialized
INFO - 2018-10-24 17:52:01 --> Hooks Class Initialized
DEBUG - 2018-10-24 17:52:01 --> UTF-8 Support Enabled
INFO - 2018-10-24 17:52:01 --> Utf8 Class Initialized
INFO - 2018-10-24 17:52:01 --> URI Class Initialized
INFO - 2018-10-24 17:52:01 --> Router Class Initialized
INFO - 2018-10-24 17:52:01 --> Output Class Initialized
INFO - 2018-10-24 17:52:01 --> Security Class Initialized
DEBUG - 2018-10-24 17:52:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-24 17:52:01 --> CSRF cookie sent
INFO - 2018-10-24 17:52:01 --> CSRF token verified
INFO - 2018-10-24 17:52:01 --> Input Class Initialized
INFO - 2018-10-24 17:52:01 --> Language Class Initialized
INFO - 2018-10-24 17:52:01 --> Loader Class Initialized
INFO - 2018-10-24 17:52:01 --> Helper loaded: url_helper
INFO - 2018-10-24 17:52:01 --> Helper loaded: form_helper
INFO - 2018-10-24 17:52:01 --> Helper loaded: language_helper
DEBUG - 2018-10-24 17:52:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-24 17:52:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-24 17:52:01 --> User Agent Class Initialized
INFO - 2018-10-24 17:52:01 --> Controller Class Initialized
INFO - 2018-10-24 17:52:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-24 17:52:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-24 17:52:01 --> Helper loaded: custom_helper
INFO - 2018-10-24 17:52:01 --> Pixel_Model class loaded
INFO - 2018-10-24 17:52:01 --> Database Driver Class Initialized
INFO - 2018-10-24 17:52:01 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:52:01 --> Form Validation Class Initialized
INFO - 2018-10-24 17:52:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-24 17:52:01 --> Database Driver Class Initialized
INFO - 2018-10-24 17:52:01 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:52:01 --> Config Class Initialized
INFO - 2018-10-24 17:52:01 --> Hooks Class Initialized
DEBUG - 2018-10-24 17:52:01 --> UTF-8 Support Enabled
INFO - 2018-10-24 17:52:01 --> Utf8 Class Initialized
INFO - 2018-10-24 17:52:01 --> URI Class Initialized
INFO - 2018-10-24 17:52:01 --> Router Class Initialized
INFO - 2018-10-24 17:52:01 --> Output Class Initialized
INFO - 2018-10-24 17:52:01 --> Security Class Initialized
DEBUG - 2018-10-24 17:52:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-24 17:52:01 --> CSRF cookie sent
INFO - 2018-10-24 17:52:01 --> Input Class Initialized
INFO - 2018-10-24 17:52:01 --> Language Class Initialized
INFO - 2018-10-24 17:52:01 --> Loader Class Initialized
INFO - 2018-10-24 17:52:01 --> Helper loaded: url_helper
INFO - 2018-10-24 17:52:01 --> Helper loaded: form_helper
INFO - 2018-10-24 17:52:01 --> Helper loaded: language_helper
DEBUG - 2018-10-24 17:52:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-24 17:52:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-24 17:52:01 --> User Agent Class Initialized
INFO - 2018-10-24 17:52:01 --> Controller Class Initialized
INFO - 2018-10-24 17:52:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-24 17:52:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-24 17:52:01 --> Helper loaded: custom_helper
INFO - 2018-10-24 17:52:02 --> Pixel_Model class loaded
INFO - 2018-10-24 17:52:02 --> Database Driver Class Initialized
INFO - 2018-10-24 17:52:02 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:52:02 --> Database Driver Class Initialized
INFO - 2018-10-24 17:52:02 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:52:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-24 17:52:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-24 17:52:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-24 17:52:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-24 17:52:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-24 17:52:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-24 17:52:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/inheritance_maintained.php
INFO - 2018-10-24 17:52:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-24 17:52:02 --> Final output sent to browser
DEBUG - 2018-10-24 17:52:02 --> Total execution time: 0.4081
INFO - 2018-10-24 17:52:03 --> Config Class Initialized
INFO - 2018-10-24 17:52:03 --> Hooks Class Initialized
DEBUG - 2018-10-24 17:52:03 --> UTF-8 Support Enabled
INFO - 2018-10-24 17:52:03 --> Utf8 Class Initialized
INFO - 2018-10-24 17:52:03 --> URI Class Initialized
DEBUG - 2018-10-24 17:52:03 --> No URI present. Default controller set.
INFO - 2018-10-24 17:52:03 --> Router Class Initialized
INFO - 2018-10-24 17:52:03 --> Output Class Initialized
INFO - 2018-10-24 17:52:03 --> Security Class Initialized
DEBUG - 2018-10-24 17:52:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-24 17:52:03 --> CSRF cookie sent
INFO - 2018-10-24 17:52:03 --> Input Class Initialized
INFO - 2018-10-24 17:52:03 --> Language Class Initialized
INFO - 2018-10-24 17:52:03 --> Loader Class Initialized
INFO - 2018-10-24 17:52:03 --> Helper loaded: url_helper
INFO - 2018-10-24 17:52:03 --> Helper loaded: form_helper
INFO - 2018-10-24 17:52:03 --> Helper loaded: language_helper
DEBUG - 2018-10-24 17:52:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-24 17:52:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-24 17:52:04 --> User Agent Class Initialized
INFO - 2018-10-24 17:52:04 --> Controller Class Initialized
INFO - 2018-10-24 17:52:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-24 17:52:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-24 17:52:04 --> Helper loaded: custom_helper
INFO - 2018-10-24 17:52:04 --> Pixel_Model class loaded
INFO - 2018-10-24 17:52:04 --> Database Driver Class Initialized
INFO - 2018-10-24 17:52:04 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:52:04 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-24 17:52:04 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-24 17:52:04 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-24 17:52:04 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-24 17:52:04 --> Final output sent to browser
DEBUG - 2018-10-24 17:52:04 --> Total execution time: 0.3536
INFO - 2018-10-24 17:52:05 --> Config Class Initialized
INFO - 2018-10-24 17:52:05 --> Hooks Class Initialized
DEBUG - 2018-10-24 17:52:05 --> UTF-8 Support Enabled
INFO - 2018-10-24 17:52:05 --> Utf8 Class Initialized
INFO - 2018-10-24 17:52:05 --> URI Class Initialized
DEBUG - 2018-10-24 17:52:05 --> No URI present. Default controller set.
INFO - 2018-10-24 17:52:05 --> Router Class Initialized
INFO - 2018-10-24 17:52:05 --> Output Class Initialized
INFO - 2018-10-24 17:52:05 --> Security Class Initialized
DEBUG - 2018-10-24 17:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-24 17:52:05 --> CSRF cookie sent
INFO - 2018-10-24 17:52:05 --> Input Class Initialized
INFO - 2018-10-24 17:52:05 --> Language Class Initialized
INFO - 2018-10-24 17:52:05 --> Loader Class Initialized
INFO - 2018-10-24 17:52:05 --> Helper loaded: url_helper
INFO - 2018-10-24 17:52:05 --> Helper loaded: form_helper
INFO - 2018-10-24 17:52:05 --> Helper loaded: language_helper
DEBUG - 2018-10-24 17:52:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-24 17:52:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-24 17:52:05 --> User Agent Class Initialized
INFO - 2018-10-24 17:52:05 --> Controller Class Initialized
INFO - 2018-10-24 17:52:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-24 17:52:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-24 17:52:05 --> Helper loaded: custom_helper
INFO - 2018-10-24 17:52:05 --> Pixel_Model class loaded
INFO - 2018-10-24 17:52:05 --> Database Driver Class Initialized
INFO - 2018-10-24 17:52:05 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:52:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-24 17:52:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-24 17:52:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-24 17:52:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-24 17:52:05 --> Final output sent to browser
DEBUG - 2018-10-24 17:52:05 --> Total execution time: 0.4319
INFO - 2018-10-24 17:52:06 --> Config Class Initialized
INFO - 2018-10-24 17:52:06 --> Hooks Class Initialized
DEBUG - 2018-10-24 17:52:06 --> UTF-8 Support Enabled
INFO - 2018-10-24 17:52:06 --> Utf8 Class Initialized
INFO - 2018-10-24 17:52:06 --> URI Class Initialized
INFO - 2018-10-24 17:52:06 --> Router Class Initialized
INFO - 2018-10-24 17:52:06 --> Output Class Initialized
INFO - 2018-10-24 17:52:06 --> Security Class Initialized
DEBUG - 2018-10-24 17:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-24 17:52:06 --> CSRF cookie sent
INFO - 2018-10-24 17:52:06 --> Input Class Initialized
INFO - 2018-10-24 17:52:06 --> Language Class Initialized
INFO - 2018-10-24 17:52:06 --> Loader Class Initialized
INFO - 2018-10-24 17:52:06 --> Helper loaded: url_helper
INFO - 2018-10-24 17:52:06 --> Helper loaded: form_helper
INFO - 2018-10-24 17:52:06 --> Helper loaded: language_helper
DEBUG - 2018-10-24 17:52:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-24 17:52:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-24 17:52:06 --> User Agent Class Initialized
INFO - 2018-10-24 17:52:06 --> Controller Class Initialized
INFO - 2018-10-24 17:52:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-24 17:52:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-24 17:52:07 --> Helper loaded: custom_helper
INFO - 2018-10-24 17:52:07 --> Pixel_Model class loaded
INFO - 2018-10-24 17:52:07 --> Database Driver Class Initialized
INFO - 2018-10-24 17:52:07 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:52:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-24 17:52:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-24 17:52:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-24 17:52:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-24 17:52:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-24 17:52:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-24 17:52:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-24 17:52:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-24 17:52:07 --> Final output sent to browser
DEBUG - 2018-10-24 17:52:07 --> Total execution time: 0.4747
INFO - 2018-10-24 17:52:09 --> Config Class Initialized
INFO - 2018-10-24 17:52:09 --> Hooks Class Initialized
DEBUG - 2018-10-24 17:52:09 --> UTF-8 Support Enabled
INFO - 2018-10-24 17:52:09 --> Utf8 Class Initialized
INFO - 2018-10-24 17:52:09 --> URI Class Initialized
INFO - 2018-10-24 17:52:09 --> Router Class Initialized
INFO - 2018-10-24 17:52:09 --> Output Class Initialized
INFO - 2018-10-24 17:52:09 --> Security Class Initialized
DEBUG - 2018-10-24 17:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-24 17:52:09 --> CSRF cookie sent
INFO - 2018-10-24 17:52:09 --> CSRF token verified
INFO - 2018-10-24 17:52:09 --> Input Class Initialized
INFO - 2018-10-24 17:52:09 --> Language Class Initialized
INFO - 2018-10-24 17:52:09 --> Loader Class Initialized
INFO - 2018-10-24 17:52:09 --> Helper loaded: url_helper
INFO - 2018-10-24 17:52:09 --> Helper loaded: form_helper
INFO - 2018-10-24 17:52:09 --> Helper loaded: language_helper
DEBUG - 2018-10-24 17:52:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-24 17:52:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-24 17:52:09 --> User Agent Class Initialized
INFO - 2018-10-24 17:52:09 --> Controller Class Initialized
INFO - 2018-10-24 17:52:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-24 17:52:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-24 17:52:09 --> Helper loaded: custom_helper
INFO - 2018-10-24 17:52:09 --> Pixel_Model class loaded
INFO - 2018-10-24 17:52:09 --> Database Driver Class Initialized
INFO - 2018-10-24 17:52:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:52:09 --> Database Driver Class Initialized
INFO - 2018-10-24 17:52:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:52:09 --> Config Class Initialized
INFO - 2018-10-24 17:52:09 --> Hooks Class Initialized
DEBUG - 2018-10-24 17:52:09 --> UTF-8 Support Enabled
INFO - 2018-10-24 17:52:09 --> Utf8 Class Initialized
INFO - 2018-10-24 17:52:09 --> URI Class Initialized
INFO - 2018-10-24 17:52:09 --> Router Class Initialized
INFO - 2018-10-24 17:52:09 --> Output Class Initialized
INFO - 2018-10-24 17:52:09 --> Security Class Initialized
DEBUG - 2018-10-24 17:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-24 17:52:09 --> CSRF cookie sent
INFO - 2018-10-24 17:52:09 --> Input Class Initialized
INFO - 2018-10-24 17:52:09 --> Language Class Initialized
INFO - 2018-10-24 17:52:09 --> Loader Class Initialized
INFO - 2018-10-24 17:52:09 --> Helper loaded: url_helper
INFO - 2018-10-24 17:52:09 --> Helper loaded: form_helper
INFO - 2018-10-24 17:52:09 --> Helper loaded: language_helper
DEBUG - 2018-10-24 17:52:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-24 17:52:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-24 17:52:09 --> User Agent Class Initialized
INFO - 2018-10-24 17:52:09 --> Controller Class Initialized
INFO - 2018-10-24 17:52:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-24 17:52:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-24 17:52:10 --> Helper loaded: custom_helper
INFO - 2018-10-24 17:52:10 --> Pixel_Model class loaded
INFO - 2018-10-24 17:52:10 --> Database Driver Class Initialized
INFO - 2018-10-24 17:52:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:52:10 --> Database Driver Class Initialized
INFO - 2018-10-24 17:52:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:52:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-24 17:52:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-24 17:52:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-24 17:52:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-24 17:52:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-24 17:52:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-24 17:52:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/inheritance_maintained.php
INFO - 2018-10-24 17:52:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-24 17:52:10 --> Final output sent to browser
DEBUG - 2018-10-24 17:52:10 --> Total execution time: 0.3731
INFO - 2018-10-24 17:52:17 --> Config Class Initialized
INFO - 2018-10-24 17:52:17 --> Hooks Class Initialized
DEBUG - 2018-10-24 17:52:17 --> UTF-8 Support Enabled
INFO - 2018-10-24 17:52:17 --> Utf8 Class Initialized
INFO - 2018-10-24 17:52:17 --> URI Class Initialized
INFO - 2018-10-24 17:52:17 --> Router Class Initialized
INFO - 2018-10-24 17:52:17 --> Output Class Initialized
INFO - 2018-10-24 17:52:17 --> Security Class Initialized
DEBUG - 2018-10-24 17:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-24 17:52:17 --> CSRF cookie sent
INFO - 2018-10-24 17:52:17 --> Input Class Initialized
INFO - 2018-10-24 17:52:17 --> Language Class Initialized
INFO - 2018-10-24 17:52:17 --> Loader Class Initialized
INFO - 2018-10-24 17:52:17 --> Helper loaded: url_helper
INFO - 2018-10-24 17:52:17 --> Helper loaded: form_helper
INFO - 2018-10-24 17:52:17 --> Helper loaded: language_helper
DEBUG - 2018-10-24 17:52:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-24 17:52:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-24 17:52:17 --> User Agent Class Initialized
INFO - 2018-10-24 17:52:17 --> Controller Class Initialized
INFO - 2018-10-24 17:52:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-24 17:52:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-24 17:52:17 --> Helper loaded: custom_helper
INFO - 2018-10-24 17:52:17 --> Pixel_Model class loaded
INFO - 2018-10-24 17:52:17 --> Database Driver Class Initialized
INFO - 2018-10-24 17:52:17 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:52:17 --> Database Driver Class Initialized
INFO - 2018-10-24 17:52:17 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:52:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-24 17:52:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-24 17:52:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-24 17:52:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-24 17:52:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-24 17:52:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-24 17:52:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-24 17:52:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-24 17:52:17 --> Final output sent to browser
DEBUG - 2018-10-24 17:52:17 --> Total execution time: 0.3887
INFO - 2018-10-24 17:52:36 --> Config Class Initialized
INFO - 2018-10-24 17:52:36 --> Hooks Class Initialized
DEBUG - 2018-10-24 17:52:36 --> UTF-8 Support Enabled
INFO - 2018-10-24 17:52:36 --> Utf8 Class Initialized
INFO - 2018-10-24 17:52:36 --> URI Class Initialized
INFO - 2018-10-24 17:52:36 --> Router Class Initialized
INFO - 2018-10-24 17:52:36 --> Output Class Initialized
INFO - 2018-10-24 17:52:36 --> Security Class Initialized
DEBUG - 2018-10-24 17:52:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-24 17:52:36 --> CSRF cookie sent
INFO - 2018-10-24 17:52:36 --> Input Class Initialized
INFO - 2018-10-24 17:52:36 --> Language Class Initialized
INFO - 2018-10-24 17:52:36 --> Loader Class Initialized
INFO - 2018-10-24 17:52:36 --> Helper loaded: url_helper
INFO - 2018-10-24 17:52:36 --> Helper loaded: form_helper
INFO - 2018-10-24 17:52:36 --> Helper loaded: language_helper
DEBUG - 2018-10-24 17:52:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-24 17:52:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-24 17:52:36 --> User Agent Class Initialized
INFO - 2018-10-24 17:52:36 --> Controller Class Initialized
INFO - 2018-10-24 17:52:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-24 17:52:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-24 17:52:36 --> Helper loaded: custom_helper
INFO - 2018-10-24 17:52:36 --> Pixel_Model class loaded
INFO - 2018-10-24 17:52:36 --> Database Driver Class Initialized
INFO - 2018-10-24 17:52:36 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:52:36 --> Database Driver Class Initialized
INFO - 2018-10-24 17:52:36 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:52:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-24 17:52:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-24 17:52:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-24 17:52:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-24 17:52:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/risk_report.php
INFO - 2018-10-24 17:52:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-24 17:52:36 --> Final output sent to browser
DEBUG - 2018-10-24 17:52:36 --> Total execution time: 0.4328
INFO - 2018-10-24 17:54:08 --> Config Class Initialized
INFO - 2018-10-24 17:54:08 --> Hooks Class Initialized
DEBUG - 2018-10-24 17:54:08 --> UTF-8 Support Enabled
INFO - 2018-10-24 17:54:08 --> Utf8 Class Initialized
INFO - 2018-10-24 17:54:08 --> URI Class Initialized
INFO - 2018-10-24 17:54:08 --> Router Class Initialized
INFO - 2018-10-24 17:54:08 --> Output Class Initialized
INFO - 2018-10-24 17:54:08 --> Security Class Initialized
DEBUG - 2018-10-24 17:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-24 17:54:08 --> CSRF cookie sent
INFO - 2018-10-24 17:54:08 --> Input Class Initialized
INFO - 2018-10-24 17:54:08 --> Language Class Initialized
INFO - 2018-10-24 17:54:08 --> Loader Class Initialized
INFO - 2018-10-24 17:54:08 --> Helper loaded: url_helper
INFO - 2018-10-24 17:54:08 --> Helper loaded: form_helper
INFO - 2018-10-24 17:54:08 --> Helper loaded: language_helper
DEBUG - 2018-10-24 17:54:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-24 17:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-24 17:54:08 --> User Agent Class Initialized
INFO - 2018-10-24 17:54:08 --> Controller Class Initialized
INFO - 2018-10-24 17:54:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-24 17:54:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-24 17:54:08 --> Helper loaded: custom_helper
INFO - 2018-10-24 17:54:08 --> Pixel_Model class loaded
INFO - 2018-10-24 17:54:08 --> Database Driver Class Initialized
INFO - 2018-10-24 17:54:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:54:08 --> Database Driver Class Initialized
INFO - 2018-10-24 17:54:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:54:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-24 17:54:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-24 17:54:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-24 17:54:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-24 17:54:09 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/risk_report.php
INFO - 2018-10-24 17:54:09 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-24 17:54:09 --> Final output sent to browser
DEBUG - 2018-10-24 17:54:09 --> Total execution time: 0.9984
INFO - 2018-10-24 17:59:47 --> Config Class Initialized
INFO - 2018-10-24 17:59:47 --> Hooks Class Initialized
DEBUG - 2018-10-24 17:59:47 --> UTF-8 Support Enabled
INFO - 2018-10-24 17:59:47 --> Utf8 Class Initialized
INFO - 2018-10-24 17:59:48 --> URI Class Initialized
INFO - 2018-10-24 17:59:48 --> Router Class Initialized
INFO - 2018-10-24 17:59:48 --> Output Class Initialized
INFO - 2018-10-24 17:59:48 --> Security Class Initialized
DEBUG - 2018-10-24 17:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-24 17:59:48 --> CSRF cookie sent
INFO - 2018-10-24 17:59:48 --> Input Class Initialized
INFO - 2018-10-24 17:59:48 --> Language Class Initialized
INFO - 2018-10-24 17:59:48 --> Loader Class Initialized
INFO - 2018-10-24 17:59:48 --> Helper loaded: url_helper
INFO - 2018-10-24 17:59:48 --> Helper loaded: form_helper
INFO - 2018-10-24 17:59:48 --> Helper loaded: language_helper
DEBUG - 2018-10-24 17:59:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-24 17:59:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-24 17:59:48 --> User Agent Class Initialized
INFO - 2018-10-24 17:59:48 --> Controller Class Initialized
INFO - 2018-10-24 17:59:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-24 17:59:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-24 17:59:48 --> Helper loaded: custom_helper
INFO - 2018-10-24 17:59:48 --> Pixel_Model class loaded
INFO - 2018-10-24 17:59:48 --> Database Driver Class Initialized
INFO - 2018-10-24 17:59:48 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:59:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-24 17:59:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-24 17:59:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-24 17:59:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-24 17:59:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-24 17:59:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-24 17:59:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-24 17:59:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-24 17:59:48 --> Final output sent to browser
DEBUG - 2018-10-24 17:59:48 --> Total execution time: 0.3763
INFO - 2018-10-24 17:59:49 --> Config Class Initialized
INFO - 2018-10-24 17:59:49 --> Hooks Class Initialized
DEBUG - 2018-10-24 17:59:49 --> UTF-8 Support Enabled
INFO - 2018-10-24 17:59:49 --> Utf8 Class Initialized
INFO - 2018-10-24 17:59:49 --> URI Class Initialized
INFO - 2018-10-24 17:59:49 --> Router Class Initialized
INFO - 2018-10-24 17:59:49 --> Output Class Initialized
INFO - 2018-10-24 17:59:49 --> Security Class Initialized
DEBUG - 2018-10-24 17:59:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-24 17:59:49 --> CSRF cookie sent
INFO - 2018-10-24 17:59:49 --> CSRF token verified
INFO - 2018-10-24 17:59:49 --> Input Class Initialized
INFO - 2018-10-24 17:59:49 --> Language Class Initialized
INFO - 2018-10-24 17:59:49 --> Loader Class Initialized
INFO - 2018-10-24 17:59:49 --> Helper loaded: url_helper
INFO - 2018-10-24 17:59:49 --> Helper loaded: form_helper
INFO - 2018-10-24 17:59:49 --> Helper loaded: language_helper
DEBUG - 2018-10-24 17:59:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-24 17:59:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-24 17:59:49 --> User Agent Class Initialized
INFO - 2018-10-24 17:59:49 --> Controller Class Initialized
INFO - 2018-10-24 17:59:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-24 17:59:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-24 17:59:49 --> Helper loaded: custom_helper
INFO - 2018-10-24 17:59:49 --> Pixel_Model class loaded
INFO - 2018-10-24 17:59:49 --> Database Driver Class Initialized
INFO - 2018-10-24 17:59:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:59:50 --> Database Driver Class Initialized
INFO - 2018-10-24 17:59:50 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:59:50 --> Config Class Initialized
INFO - 2018-10-24 17:59:50 --> Hooks Class Initialized
DEBUG - 2018-10-24 17:59:50 --> UTF-8 Support Enabled
INFO - 2018-10-24 17:59:50 --> Utf8 Class Initialized
INFO - 2018-10-24 17:59:50 --> URI Class Initialized
INFO - 2018-10-24 17:59:50 --> Router Class Initialized
INFO - 2018-10-24 17:59:50 --> Output Class Initialized
INFO - 2018-10-24 17:59:50 --> Security Class Initialized
DEBUG - 2018-10-24 17:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-24 17:59:50 --> CSRF cookie sent
INFO - 2018-10-24 17:59:50 --> Input Class Initialized
INFO - 2018-10-24 17:59:50 --> Language Class Initialized
INFO - 2018-10-24 17:59:50 --> Loader Class Initialized
INFO - 2018-10-24 17:59:50 --> Helper loaded: url_helper
INFO - 2018-10-24 17:59:50 --> Helper loaded: form_helper
INFO - 2018-10-24 17:59:50 --> Helper loaded: language_helper
DEBUG - 2018-10-24 17:59:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-24 17:59:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-24 17:59:50 --> User Agent Class Initialized
INFO - 2018-10-24 17:59:50 --> Controller Class Initialized
INFO - 2018-10-24 17:59:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-24 17:59:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-24 17:59:50 --> Helper loaded: custom_helper
INFO - 2018-10-24 17:59:50 --> Pixel_Model class loaded
INFO - 2018-10-24 17:59:50 --> Database Driver Class Initialized
INFO - 2018-10-24 17:59:50 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:59:50 --> Database Driver Class Initialized
INFO - 2018-10-24 17:59:50 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:59:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-24 17:59:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-24 17:59:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-24 17:59:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-24 17:59:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-24 17:59:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-24 17:59:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-24 17:59:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-24 17:59:50 --> Final output sent to browser
DEBUG - 2018-10-24 17:59:50 --> Total execution time: 0.3913
INFO - 2018-10-24 17:59:56 --> Config Class Initialized
INFO - 2018-10-24 17:59:56 --> Hooks Class Initialized
DEBUG - 2018-10-24 17:59:56 --> UTF-8 Support Enabled
INFO - 2018-10-24 17:59:56 --> Utf8 Class Initialized
INFO - 2018-10-24 17:59:56 --> URI Class Initialized
INFO - 2018-10-24 17:59:56 --> Router Class Initialized
INFO - 2018-10-24 17:59:56 --> Output Class Initialized
INFO - 2018-10-24 17:59:56 --> Security Class Initialized
DEBUG - 2018-10-24 17:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-24 17:59:56 --> CSRF cookie sent
INFO - 2018-10-24 17:59:56 --> CSRF token verified
INFO - 2018-10-24 17:59:56 --> Input Class Initialized
INFO - 2018-10-24 17:59:56 --> Language Class Initialized
INFO - 2018-10-24 17:59:56 --> Loader Class Initialized
INFO - 2018-10-24 17:59:56 --> Helper loaded: url_helper
INFO - 2018-10-24 17:59:56 --> Helper loaded: form_helper
INFO - 2018-10-24 17:59:56 --> Helper loaded: language_helper
DEBUG - 2018-10-24 17:59:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-24 17:59:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-24 17:59:56 --> User Agent Class Initialized
INFO - 2018-10-24 17:59:56 --> Controller Class Initialized
INFO - 2018-10-24 17:59:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-24 17:59:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-24 17:59:56 --> Helper loaded: custom_helper
INFO - 2018-10-24 17:59:56 --> Pixel_Model class loaded
INFO - 2018-10-24 17:59:56 --> Database Driver Class Initialized
INFO - 2018-10-24 17:59:56 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:59:56 --> Form Validation Class Initialized
INFO - 2018-10-24 17:59:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-24 17:59:56 --> Database Driver Class Initialized
INFO - 2018-10-24 17:59:56 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:59:56 --> Config Class Initialized
INFO - 2018-10-24 17:59:56 --> Hooks Class Initialized
DEBUG - 2018-10-24 17:59:56 --> UTF-8 Support Enabled
INFO - 2018-10-24 17:59:56 --> Utf8 Class Initialized
INFO - 2018-10-24 17:59:56 --> URI Class Initialized
INFO - 2018-10-24 17:59:56 --> Router Class Initialized
INFO - 2018-10-24 17:59:56 --> Output Class Initialized
INFO - 2018-10-24 17:59:56 --> Security Class Initialized
DEBUG - 2018-10-24 17:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-24 17:59:56 --> CSRF cookie sent
INFO - 2018-10-24 17:59:56 --> Input Class Initialized
INFO - 2018-10-24 17:59:56 --> Language Class Initialized
INFO - 2018-10-24 17:59:56 --> Loader Class Initialized
INFO - 2018-10-24 17:59:57 --> Helper loaded: url_helper
INFO - 2018-10-24 17:59:57 --> Helper loaded: form_helper
INFO - 2018-10-24 17:59:57 --> Helper loaded: language_helper
DEBUG - 2018-10-24 17:59:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-24 17:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-24 17:59:57 --> User Agent Class Initialized
INFO - 2018-10-24 17:59:57 --> Controller Class Initialized
INFO - 2018-10-24 17:59:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-24 17:59:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-24 17:59:57 --> Helper loaded: custom_helper
INFO - 2018-10-24 17:59:57 --> Pixel_Model class loaded
INFO - 2018-10-24 17:59:57 --> Database Driver Class Initialized
INFO - 2018-10-24 17:59:57 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:59:57 --> Database Driver Class Initialized
INFO - 2018-10-24 17:59:57 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:59:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-24 17:59:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-24 17:59:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-24 17:59:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-24 17:59:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-24 17:59:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-24 17:59:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/your_job.php
INFO - 2018-10-24 17:59:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-24 17:59:57 --> Final output sent to browser
DEBUG - 2018-10-24 17:59:57 --> Total execution time: 0.4122
INFO - 2018-10-24 17:59:58 --> Config Class Initialized
INFO - 2018-10-24 17:59:58 --> Hooks Class Initialized
DEBUG - 2018-10-24 17:59:58 --> UTF-8 Support Enabled
INFO - 2018-10-24 17:59:58 --> Utf8 Class Initialized
INFO - 2018-10-24 17:59:58 --> URI Class Initialized
INFO - 2018-10-24 17:59:58 --> Router Class Initialized
INFO - 2018-10-24 17:59:58 --> Output Class Initialized
INFO - 2018-10-24 17:59:58 --> Security Class Initialized
DEBUG - 2018-10-24 17:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-24 17:59:58 --> CSRF cookie sent
INFO - 2018-10-24 17:59:58 --> CSRF token verified
INFO - 2018-10-24 17:59:58 --> Input Class Initialized
INFO - 2018-10-24 17:59:58 --> Language Class Initialized
INFO - 2018-10-24 17:59:58 --> Loader Class Initialized
INFO - 2018-10-24 17:59:58 --> Helper loaded: url_helper
INFO - 2018-10-24 17:59:58 --> Helper loaded: form_helper
INFO - 2018-10-24 17:59:58 --> Helper loaded: language_helper
DEBUG - 2018-10-24 17:59:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-24 17:59:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-24 17:59:58 --> User Agent Class Initialized
INFO - 2018-10-24 17:59:58 --> Controller Class Initialized
INFO - 2018-10-24 17:59:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-24 17:59:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-24 17:59:58 --> Helper loaded: custom_helper
INFO - 2018-10-24 17:59:58 --> Pixel_Model class loaded
INFO - 2018-10-24 17:59:58 --> Database Driver Class Initialized
INFO - 2018-10-24 17:59:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:59:58 --> Form Validation Class Initialized
INFO - 2018-10-24 17:59:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-24 17:59:58 --> Database Driver Class Initialized
INFO - 2018-10-24 17:59:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:59:58 --> Config Class Initialized
INFO - 2018-10-24 17:59:58 --> Hooks Class Initialized
DEBUG - 2018-10-24 17:59:58 --> UTF-8 Support Enabled
INFO - 2018-10-24 17:59:58 --> Utf8 Class Initialized
INFO - 2018-10-24 17:59:58 --> URI Class Initialized
INFO - 2018-10-24 17:59:58 --> Router Class Initialized
INFO - 2018-10-24 17:59:58 --> Output Class Initialized
INFO - 2018-10-24 17:59:58 --> Security Class Initialized
DEBUG - 2018-10-24 17:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-24 17:59:58 --> CSRF cookie sent
INFO - 2018-10-24 17:59:58 --> Input Class Initialized
INFO - 2018-10-24 17:59:58 --> Language Class Initialized
INFO - 2018-10-24 17:59:58 --> Loader Class Initialized
INFO - 2018-10-24 17:59:58 --> Helper loaded: url_helper
INFO - 2018-10-24 17:59:58 --> Helper loaded: form_helper
INFO - 2018-10-24 17:59:58 --> Helper loaded: language_helper
DEBUG - 2018-10-24 17:59:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-24 17:59:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-24 17:59:58 --> User Agent Class Initialized
INFO - 2018-10-24 17:59:58 --> Controller Class Initialized
INFO - 2018-10-24 17:59:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-24 17:59:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-24 17:59:58 --> Helper loaded: custom_helper
INFO - 2018-10-24 17:59:58 --> Pixel_Model class loaded
INFO - 2018-10-24 17:59:58 --> Database Driver Class Initialized
INFO - 2018-10-24 17:59:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:59:58 --> Database Driver Class Initialized
INFO - 2018-10-24 17:59:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 17:59:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-24 17:59:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-24 17:59:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner.php
INFO - 2018-10-24 17:59:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-24 17:59:59 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-24 17:59:59 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-24 17:59:59 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-24 17:59:59 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/relation_ship_status.php
INFO - 2018-10-24 17:59:59 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-24 17:59:59 --> Final output sent to browser
DEBUG - 2018-10-24 17:59:59 --> Total execution time: 0.3868
INFO - 2018-10-24 18:00:00 --> Config Class Initialized
INFO - 2018-10-24 18:00:00 --> Hooks Class Initialized
DEBUG - 2018-10-24 18:00:00 --> UTF-8 Support Enabled
INFO - 2018-10-24 18:00:00 --> Utf8 Class Initialized
INFO - 2018-10-24 18:00:00 --> URI Class Initialized
INFO - 2018-10-24 18:00:00 --> Router Class Initialized
INFO - 2018-10-24 18:00:00 --> Output Class Initialized
INFO - 2018-10-24 18:00:00 --> Security Class Initialized
DEBUG - 2018-10-24 18:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-24 18:00:00 --> CSRF cookie sent
INFO - 2018-10-24 18:00:00 --> CSRF token verified
INFO - 2018-10-24 18:00:00 --> Input Class Initialized
INFO - 2018-10-24 18:00:00 --> Language Class Initialized
INFO - 2018-10-24 18:00:00 --> Loader Class Initialized
INFO - 2018-10-24 18:00:00 --> Helper loaded: url_helper
INFO - 2018-10-24 18:00:00 --> Helper loaded: form_helper
INFO - 2018-10-24 18:00:00 --> Helper loaded: language_helper
DEBUG - 2018-10-24 18:00:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-24 18:00:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-24 18:00:00 --> User Agent Class Initialized
INFO - 2018-10-24 18:00:00 --> Controller Class Initialized
INFO - 2018-10-24 18:00:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-24 18:00:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-24 18:00:00 --> Helper loaded: custom_helper
INFO - 2018-10-24 18:00:00 --> Pixel_Model class loaded
INFO - 2018-10-24 18:00:00 --> Database Driver Class Initialized
INFO - 2018-10-24 18:00:00 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 18:00:00 --> Form Validation Class Initialized
INFO - 2018-10-24 18:00:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-24 18:00:00 --> Database Driver Class Initialized
INFO - 2018-10-24 18:00:00 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 18:00:00 --> Config Class Initialized
INFO - 2018-10-24 18:00:00 --> Hooks Class Initialized
DEBUG - 2018-10-24 18:00:00 --> UTF-8 Support Enabled
INFO - 2018-10-24 18:00:00 --> Utf8 Class Initialized
INFO - 2018-10-24 18:00:00 --> URI Class Initialized
INFO - 2018-10-24 18:00:00 --> Router Class Initialized
INFO - 2018-10-24 18:00:00 --> Output Class Initialized
INFO - 2018-10-24 18:00:00 --> Security Class Initialized
DEBUG - 2018-10-24 18:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-24 18:00:00 --> CSRF cookie sent
INFO - 2018-10-24 18:00:00 --> Input Class Initialized
INFO - 2018-10-24 18:00:00 --> Language Class Initialized
INFO - 2018-10-24 18:00:00 --> Loader Class Initialized
INFO - 2018-10-24 18:00:00 --> Helper loaded: url_helper
INFO - 2018-10-24 18:00:00 --> Helper loaded: form_helper
INFO - 2018-10-24 18:00:00 --> Helper loaded: language_helper
DEBUG - 2018-10-24 18:00:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-24 18:00:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-24 18:00:00 --> User Agent Class Initialized
INFO - 2018-10-24 18:00:00 --> Controller Class Initialized
INFO - 2018-10-24 18:00:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-24 18:00:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-24 18:00:00 --> Helper loaded: custom_helper
INFO - 2018-10-24 18:00:00 --> Pixel_Model class loaded
INFO - 2018-10-24 18:00:00 --> Database Driver Class Initialized
INFO - 2018-10-24 18:00:00 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 18:00:00 --> Database Driver Class Initialized
INFO - 2018-10-24 18:00:00 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 18:00:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-24 18:00:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-24 18:00:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-24 18:00:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-24 18:00:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-24 18:00:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-24 18:00:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/income.php
INFO - 2018-10-24 18:00:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-24 18:00:01 --> Final output sent to browser
DEBUG - 2018-10-24 18:00:01 --> Total execution time: 0.4112
INFO - 2018-10-24 18:00:05 --> Config Class Initialized
INFO - 2018-10-24 18:00:05 --> Hooks Class Initialized
DEBUG - 2018-10-24 18:00:05 --> UTF-8 Support Enabled
INFO - 2018-10-24 18:00:05 --> Utf8 Class Initialized
INFO - 2018-10-24 18:00:05 --> URI Class Initialized
INFO - 2018-10-24 18:00:05 --> Router Class Initialized
INFO - 2018-10-24 18:00:05 --> Output Class Initialized
INFO - 2018-10-24 18:00:05 --> Security Class Initialized
DEBUG - 2018-10-24 18:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-24 18:00:05 --> CSRF cookie sent
INFO - 2018-10-24 18:00:05 --> Input Class Initialized
INFO - 2018-10-24 18:00:05 --> Language Class Initialized
INFO - 2018-10-24 18:00:05 --> Loader Class Initialized
INFO - 2018-10-24 18:00:05 --> Helper loaded: url_helper
INFO - 2018-10-24 18:00:05 --> Helper loaded: form_helper
INFO - 2018-10-24 18:00:05 --> Helper loaded: language_helper
DEBUG - 2018-10-24 18:00:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-24 18:00:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-24 18:00:05 --> User Agent Class Initialized
INFO - 2018-10-24 18:00:05 --> Controller Class Initialized
INFO - 2018-10-24 18:00:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-24 18:00:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-24 18:00:05 --> Helper loaded: custom_helper
INFO - 2018-10-24 18:00:05 --> Pixel_Model class loaded
INFO - 2018-10-24 18:00:05 --> Database Driver Class Initialized
INFO - 2018-10-24 18:00:05 --> Model "QuestionsModel" initialized
INFO - 2018-10-24 18:00:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-24 18:00:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-24 18:00:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-24 18:00:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-24 18:00:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-24 18:00:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-24 18:00:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-24 18:00:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-24 18:00:05 --> Final output sent to browser
DEBUG - 2018-10-24 18:00:05 --> Total execution time: 0.3597
INFO - 2018-10-24 18:02:47 --> Config Class Initialized
INFO - 2018-10-24 18:02:47 --> Hooks Class Initialized
DEBUG - 2018-10-24 18:02:47 --> UTF-8 Support Enabled
INFO - 2018-10-24 18:02:47 --> Utf8 Class Initialized
INFO - 2018-10-24 18:02:47 --> URI Class Initialized
INFO - 2018-10-24 18:02:47 --> Router Class Initialized
INFO - 2018-10-24 18:02:47 --> Output Class Initialized
INFO - 2018-10-24 18:02:47 --> Security Class Initialized
DEBUG - 2018-10-24 18:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-24 18:02:47 --> CSRF cookie sent
INFO - 2018-10-24 18:02:47 --> Input Class Initialized
INFO - 2018-10-24 18:02:47 --> Language Class Initialized
INFO - 2018-10-24 18:02:47 --> Loader Class Initialized
INFO - 2018-10-24 18:02:47 --> Helper loaded: url_helper
INFO - 2018-10-24 18:02:47 --> Helper loaded: form_helper
INFO - 2018-10-24 18:02:47 --> Helper loaded: language_helper
DEBUG - 2018-10-24 18:02:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-24 18:02:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-24 18:02:47 --> User Agent Class Initialized
INFO - 2018-10-24 18:02:47 --> Controller Class Initialized
INFO - 2018-10-24 18:02:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-24 18:02:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-24 18:02:47 --> Helper loaded: custom_helper
DEBUG - 2018-10-24 18:02:47 --> Config file loaded: E:\xampp7\htdocs\famiquity\application\config/recaptcha.php
INFO - 2018-10-24 18:02:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-24 18:02:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-24 18:02:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-24 18:02:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
ERROR - 2018-10-24 18:02:48 --> Could not find the language line "req_email"
INFO - 2018-10-24 18:02:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\myaccount/signin.php
INFO - 2018-10-24 18:02:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-24 18:02:48 --> Final output sent to browser
DEBUG - 2018-10-24 18:02:48 --> Total execution time: 0.3537
INFO - 2018-10-24 18:02:50 --> Config Class Initialized
INFO - 2018-10-24 18:02:50 --> Hooks Class Initialized
DEBUG - 2018-10-24 18:02:50 --> UTF-8 Support Enabled
INFO - 2018-10-24 18:02:50 --> Utf8 Class Initialized
INFO - 2018-10-24 18:02:50 --> URI Class Initialized
INFO - 2018-10-24 18:02:50 --> Router Class Initialized
INFO - 2018-10-24 18:02:50 --> Output Class Initialized
INFO - 2018-10-24 18:02:50 --> Security Class Initialized
DEBUG - 2018-10-24 18:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-24 18:02:50 --> CSRF cookie sent
INFO - 2018-10-24 18:02:50 --> Input Class Initialized
INFO - 2018-10-24 18:02:50 --> Language Class Initialized
INFO - 2018-10-24 18:02:50 --> Loader Class Initialized
INFO - 2018-10-24 18:02:50 --> Helper loaded: url_helper
INFO - 2018-10-24 18:02:50 --> Helper loaded: form_helper
INFO - 2018-10-24 18:02:50 --> Helper loaded: language_helper
DEBUG - 2018-10-24 18:02:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-24 18:02:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-24 18:02:50 --> User Agent Class Initialized
INFO - 2018-10-24 18:02:50 --> Controller Class Initialized
INFO - 2018-10-24 18:02:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-24 18:02:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-24 18:02:50 --> Helper loaded: custom_helper
INFO - 2018-10-24 18:02:50 --> Pixel_Model class loaded
INFO - 2018-10-24 18:02:50 --> Database Driver Class Initialized
INFO - 2018-10-24 18:02:50 --> Model "RegistrationModel" initialized
DEBUG - 2018-10-24 18:02:50 --> Config file loaded: E:\xampp7\htdocs\famiquity\application\config/recaptcha.php
INFO - 2018-10-24 18:02:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-24 18:02:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-24 18:02:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-24 18:02:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
ERROR - 2018-10-24 18:02:50 --> Could not find the language line "req_email"
INFO - 2018-10-24 18:02:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\register/signup.php
INFO - 2018-10-24 18:02:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-24 18:02:50 --> Final output sent to browser
DEBUG - 2018-10-24 18:02:50 --> Total execution time: 0.3964
INFO - 2018-10-24 18:18:33 --> Config Class Initialized
INFO - 2018-10-24 18:18:33 --> Hooks Class Initialized
DEBUG - 2018-10-24 18:18:34 --> UTF-8 Support Enabled
INFO - 2018-10-24 18:18:34 --> Utf8 Class Initialized
INFO - 2018-10-24 18:18:34 --> URI Class Initialized
INFO - 2018-10-24 18:18:34 --> Router Class Initialized
INFO - 2018-10-24 18:18:34 --> Output Class Initialized
INFO - 2018-10-24 18:18:34 --> Security Class Initialized
DEBUG - 2018-10-24 18:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-24 18:18:34 --> CSRF cookie sent
INFO - 2018-10-24 18:18:34 --> Input Class Initialized
INFO - 2018-10-24 18:18:34 --> Language Class Initialized
INFO - 2018-10-24 18:18:34 --> Loader Class Initialized
INFO - 2018-10-24 18:18:34 --> Helper loaded: url_helper
INFO - 2018-10-24 18:18:34 --> Helper loaded: form_helper
INFO - 2018-10-24 18:18:34 --> Helper loaded: language_helper
DEBUG - 2018-10-24 18:18:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-24 18:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-24 18:18:34 --> User Agent Class Initialized
INFO - 2018-10-24 18:18:34 --> Controller Class Initialized
INFO - 2018-10-24 18:18:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-24 18:18:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-24 18:18:34 --> Helper loaded: custom_helper
INFO - 2018-10-24 18:18:34 --> Pixel_Model class loaded
INFO - 2018-10-24 18:18:34 --> Database Driver Class Initialized
INFO - 2018-10-24 18:18:34 --> Model "RegistrationModel" initialized
DEBUG - 2018-10-24 18:18:34 --> Config file loaded: E:\xampp7\htdocs\famiquity\application\config/recaptcha.php
INFO - 2018-10-24 18:18:34 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-24 18:18:34 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-24 18:18:34 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-24 18:18:34 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
ERROR - 2018-10-24 18:18:34 --> Could not find the language line "req_email"
INFO - 2018-10-24 18:18:34 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\register/signup.php
INFO - 2018-10-24 18:18:34 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-24 18:18:34 --> Final output sent to browser
DEBUG - 2018-10-24 18:18:34 --> Total execution time: 0.4476
INFO - 2018-10-24 18:18:42 --> Config Class Initialized
INFO - 2018-10-24 18:18:42 --> Hooks Class Initialized
DEBUG - 2018-10-24 18:18:42 --> UTF-8 Support Enabled
INFO - 2018-10-24 18:18:42 --> Utf8 Class Initialized
INFO - 2018-10-24 18:18:42 --> URI Class Initialized
INFO - 2018-10-24 18:18:42 --> Router Class Initialized
INFO - 2018-10-24 18:18:42 --> Output Class Initialized
INFO - 2018-10-24 18:18:42 --> Security Class Initialized
DEBUG - 2018-10-24 18:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-24 18:18:42 --> CSRF cookie sent
INFO - 2018-10-24 18:18:42 --> Input Class Initialized
INFO - 2018-10-24 18:18:42 --> Language Class Initialized
INFO - 2018-10-24 18:18:42 --> Loader Class Initialized
INFO - 2018-10-24 18:18:42 --> Helper loaded: url_helper
INFO - 2018-10-24 18:18:43 --> Helper loaded: form_helper
INFO - 2018-10-24 18:18:43 --> Helper loaded: language_helper
DEBUG - 2018-10-24 18:18:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-24 18:18:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-24 18:18:43 --> User Agent Class Initialized
INFO - 2018-10-24 18:18:43 --> Controller Class Initialized
INFO - 2018-10-24 18:18:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-24 18:18:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-24 18:18:43 --> Helper loaded: custom_helper
INFO - 2018-10-24 18:18:43 --> Pixel_Model class loaded
INFO - 2018-10-24 18:18:43 --> Database Driver Class Initialized
INFO - 2018-10-24 18:18:43 --> Model "RegistrationModel" initialized
DEBUG - 2018-10-24 18:18:43 --> Config file loaded: E:\xampp7\htdocs\famiquity\application\config/recaptcha.php
INFO - 2018-10-24 18:18:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-24 18:18:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-24 18:18:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-24 18:18:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-24 18:18:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\register/temp.php
INFO - 2018-10-24 18:18:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-24 18:18:43 --> Final output sent to browser
DEBUG - 2018-10-24 18:18:43 --> Total execution time: 0.3899
INFO - 2018-10-24 18:19:31 --> Config Class Initialized
INFO - 2018-10-24 18:19:31 --> Hooks Class Initialized
DEBUG - 2018-10-24 18:19:31 --> UTF-8 Support Enabled
INFO - 2018-10-24 18:19:31 --> Utf8 Class Initialized
INFO - 2018-10-24 18:19:31 --> URI Class Initialized
INFO - 2018-10-24 18:19:31 --> Router Class Initialized
INFO - 2018-10-24 18:19:31 --> Output Class Initialized
INFO - 2018-10-24 18:19:31 --> Security Class Initialized
DEBUG - 2018-10-24 18:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-24 18:19:32 --> CSRF cookie sent
INFO - 2018-10-24 18:19:32 --> Input Class Initialized
INFO - 2018-10-24 18:19:32 --> Language Class Initialized
INFO - 2018-10-24 18:19:32 --> Loader Class Initialized
INFO - 2018-10-24 18:19:32 --> Helper loaded: url_helper
INFO - 2018-10-24 18:19:32 --> Helper loaded: form_helper
INFO - 2018-10-24 18:19:32 --> Helper loaded: language_helper
DEBUG - 2018-10-24 18:19:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-24 18:19:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-24 18:19:32 --> User Agent Class Initialized
INFO - 2018-10-24 18:19:32 --> Controller Class Initialized
INFO - 2018-10-24 18:19:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-24 18:19:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-24 18:19:32 --> Helper loaded: custom_helper
INFO - 2018-10-24 18:19:32 --> Pixel_Model class loaded
INFO - 2018-10-24 18:19:32 --> Database Driver Class Initialized
INFO - 2018-10-24 18:19:32 --> Model "RegistrationModel" initialized
DEBUG - 2018-10-24 18:19:32 --> Config file loaded: E:\xampp7\htdocs\famiquity\application\config/recaptcha.php
INFO - 2018-10-24 18:19:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-24 18:19:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-24 18:19:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-24 18:19:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
ERROR - 2018-10-24 18:19:32 --> Could not find the language line "req_email"
INFO - 2018-10-24 18:19:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\register/signup_fa.php
INFO - 2018-10-24 18:19:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-24 18:19:32 --> Final output sent to browser
DEBUG - 2018-10-24 18:19:32 --> Total execution time: 0.4144
INFO - 2018-10-24 18:23:00 --> Config Class Initialized
INFO - 2018-10-24 18:23:00 --> Hooks Class Initialized
DEBUG - 2018-10-24 18:23:00 --> UTF-8 Support Enabled
INFO - 2018-10-24 18:23:00 --> Utf8 Class Initialized
INFO - 2018-10-24 18:23:01 --> URI Class Initialized
INFO - 2018-10-24 18:23:01 --> Router Class Initialized
INFO - 2018-10-24 18:23:01 --> Output Class Initialized
INFO - 2018-10-24 18:23:01 --> Security Class Initialized
DEBUG - 2018-10-24 18:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-24 18:23:01 --> CSRF cookie sent
INFO - 2018-10-24 18:23:01 --> Input Class Initialized
INFO - 2018-10-24 18:23:01 --> Language Class Initialized
INFO - 2018-10-24 18:23:01 --> Loader Class Initialized
INFO - 2018-10-24 18:23:01 --> Helper loaded: url_helper
INFO - 2018-10-24 18:23:01 --> Helper loaded: form_helper
INFO - 2018-10-24 18:23:01 --> Helper loaded: language_helper
DEBUG - 2018-10-24 18:23:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-24 18:23:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-24 18:23:01 --> User Agent Class Initialized
INFO - 2018-10-24 18:23:01 --> Controller Class Initialized
INFO - 2018-10-24 18:23:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-24 18:23:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-24 18:23:01 --> Helper loaded: custom_helper
INFO - 2018-10-24 18:23:01 --> Pixel_Model class loaded
INFO - 2018-10-24 18:23:01 --> Database Driver Class Initialized
INFO - 2018-10-24 18:23:01 --> Model "RegistrationModel" initialized
DEBUG - 2018-10-24 18:23:01 --> Config file loaded: E:\xampp7\htdocs\famiquity\application\config/recaptcha.php
INFO - 2018-10-24 18:23:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-24 18:23:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-24 18:23:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-24 18:23:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
ERROR - 2018-10-24 18:23:01 --> Could not find the language line "req_email"
INFO - 2018-10-24 18:23:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\register/signup_fa.php
INFO - 2018-10-24 18:23:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-24 18:23:01 --> Final output sent to browser
DEBUG - 2018-10-24 18:23:01 --> Total execution time: 0.3768
INFO - 2018-10-24 18:23:57 --> Config Class Initialized
INFO - 2018-10-24 18:23:57 --> Hooks Class Initialized
DEBUG - 2018-10-24 18:23:57 --> UTF-8 Support Enabled
INFO - 2018-10-24 18:23:57 --> Utf8 Class Initialized
INFO - 2018-10-24 18:23:57 --> URI Class Initialized
INFO - 2018-10-24 18:23:57 --> Router Class Initialized
INFO - 2018-10-24 18:23:57 --> Output Class Initialized
INFO - 2018-10-24 18:23:57 --> Security Class Initialized
DEBUG - 2018-10-24 18:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-24 18:23:57 --> CSRF cookie sent
INFO - 2018-10-24 18:23:57 --> CSRF token verified
INFO - 2018-10-24 18:23:57 --> Input Class Initialized
INFO - 2018-10-24 18:23:57 --> Language Class Initialized
INFO - 2018-10-24 18:23:57 --> Loader Class Initialized
INFO - 2018-10-24 18:23:57 --> Helper loaded: url_helper
INFO - 2018-10-24 18:23:57 --> Helper loaded: form_helper
INFO - 2018-10-24 18:23:57 --> Helper loaded: language_helper
DEBUG - 2018-10-24 18:23:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-24 18:23:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-24 18:23:57 --> User Agent Class Initialized
INFO - 2018-10-24 18:23:57 --> Controller Class Initialized
INFO - 2018-10-24 18:23:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-24 18:23:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-24 18:23:57 --> Helper loaded: custom_helper
DEBUG - 2018-10-24 18:23:57 --> Config file loaded: E:\xampp7\htdocs\famiquity\application\config/recaptcha.php
INFO - 2018-10-24 18:23:57 --> Form Validation Class Initialized
INFO - 2018-10-24 18:23:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-24 18:23:57 --> Pixel_Model class loaded
INFO - 2018-10-24 18:23:57 --> Database Driver Class Initialized
INFO - 2018-10-24 18:23:57 --> Model "RegistrationModel" initialized
ERROR - 2018-10-24 18:23:57 --> Severity: error --> Exception: Call to undefined function mcrypt_create_iv() E:\xampp7\htdocs\famiquity\application\libraries\Smart.php 307
INFO - 2018-10-24 18:24:26 --> Config Class Initialized
INFO - 2018-10-24 18:24:26 --> Hooks Class Initialized
DEBUG - 2018-10-24 18:24:26 --> UTF-8 Support Enabled
INFO - 2018-10-24 18:24:26 --> Utf8 Class Initialized
INFO - 2018-10-24 18:24:26 --> URI Class Initialized
INFO - 2018-10-24 18:24:26 --> Router Class Initialized
INFO - 2018-10-24 18:24:26 --> Output Class Initialized
INFO - 2018-10-24 18:24:26 --> Security Class Initialized
DEBUG - 2018-10-24 18:24:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-24 18:24:26 --> CSRF cookie sent
INFO - 2018-10-24 18:24:26 --> Input Class Initialized
INFO - 2018-10-24 18:24:26 --> Language Class Initialized
INFO - 2018-10-24 18:24:26 --> Loader Class Initialized
INFO - 2018-10-24 18:24:26 --> Helper loaded: url_helper
INFO - 2018-10-24 18:24:26 --> Helper loaded: form_helper
INFO - 2018-10-24 18:24:26 --> Helper loaded: language_helper
DEBUG - 2018-10-24 18:24:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-24 18:24:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-24 18:24:26 --> User Agent Class Initialized
INFO - 2018-10-24 18:24:26 --> Controller Class Initialized
INFO - 2018-10-24 18:24:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-24 18:24:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-24 18:24:26 --> Helper loaded: custom_helper
DEBUG - 2018-10-24 18:24:26 --> Config file loaded: E:\xampp7\htdocs\famiquity\application\config/recaptcha.php
INFO - 2018-10-24 18:24:27 --> Form Validation Class Initialized
INFO - 2018-10-24 18:24:27 --> Pixel_Model class loaded
INFO - 2018-10-24 18:24:27 --> Database Driver Class Initialized
INFO - 2018-10-24 18:24:27 --> Model "RegistrationModel" initialized
DEBUG - 2018-10-24 18:24:27 --> Recaptcha class already loaded. Second attempt ignored.
INFO - 2018-10-24 18:24:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-24 18:24:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-24 18:24:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-24 18:24:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-24 18:24:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\register/temp.php
INFO - 2018-10-24 18:24:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-24 18:24:27 --> Final output sent to browser
DEBUG - 2018-10-24 18:24:27 --> Total execution time: 0.3933
INFO - 2018-10-24 18:24:34 --> Config Class Initialized
INFO - 2018-10-24 18:24:34 --> Hooks Class Initialized
DEBUG - 2018-10-24 18:24:34 --> UTF-8 Support Enabled
INFO - 2018-10-24 18:24:34 --> Utf8 Class Initialized
INFO - 2018-10-24 18:24:34 --> URI Class Initialized
INFO - 2018-10-24 18:24:34 --> Router Class Initialized
INFO - 2018-10-24 18:24:34 --> Output Class Initialized
INFO - 2018-10-24 18:24:34 --> Security Class Initialized
DEBUG - 2018-10-24 18:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-24 18:24:34 --> CSRF cookie sent
INFO - 2018-10-24 18:24:34 --> Input Class Initialized
INFO - 2018-10-24 18:24:34 --> Language Class Initialized
ERROR - 2018-10-24 18:24:34 --> 404 Page Not Found: Sign-up-fa/index
INFO - 2018-10-24 18:24:36 --> Config Class Initialized
INFO - 2018-10-24 18:24:36 --> Hooks Class Initialized
DEBUG - 2018-10-24 18:24:36 --> UTF-8 Support Enabled
INFO - 2018-10-24 18:24:36 --> Utf8 Class Initialized
INFO - 2018-10-24 18:24:36 --> URI Class Initialized
INFO - 2018-10-24 18:24:36 --> Router Class Initialized
INFO - 2018-10-24 18:24:36 --> Output Class Initialized
INFO - 2018-10-24 18:24:36 --> Security Class Initialized
DEBUG - 2018-10-24 18:24:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-24 18:24:36 --> CSRF cookie sent
INFO - 2018-10-24 18:24:36 --> Input Class Initialized
INFO - 2018-10-24 18:24:36 --> Language Class Initialized
INFO - 2018-10-24 18:24:36 --> Loader Class Initialized
INFO - 2018-10-24 18:24:36 --> Helper loaded: url_helper
INFO - 2018-10-24 18:24:36 --> Helper loaded: form_helper
INFO - 2018-10-24 18:24:36 --> Helper loaded: language_helper
DEBUG - 2018-10-24 18:24:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-24 18:24:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-24 18:24:36 --> User Agent Class Initialized
INFO - 2018-10-24 18:24:36 --> Controller Class Initialized
INFO - 2018-10-24 18:24:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-24 18:24:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-24 18:24:36 --> Helper loaded: custom_helper
DEBUG - 2018-10-24 18:24:36 --> Config file loaded: E:\xampp7\htdocs\famiquity\application\config/recaptcha.php
INFO - 2018-10-24 18:24:36 --> Form Validation Class Initialized
INFO - 2018-10-24 18:24:36 --> Pixel_Model class loaded
INFO - 2018-10-24 18:24:36 --> Database Driver Class Initialized
INFO - 2018-10-24 18:24:36 --> Model "RegistrationModel" initialized
DEBUG - 2018-10-24 18:24:36 --> Recaptcha class already loaded. Second attempt ignored.
INFO - 2018-10-24 18:24:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-24 18:24:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-24 18:24:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-24 18:24:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-24 18:24:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\register/temp.php
INFO - 2018-10-24 18:24:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-24 18:24:36 --> Final output sent to browser
DEBUG - 2018-10-24 18:24:36 --> Total execution time: 0.4082
INFO - 2018-10-24 18:24:36 --> Config Class Initialized
INFO - 2018-10-24 18:24:37 --> Hooks Class Initialized
DEBUG - 2018-10-24 18:24:37 --> UTF-8 Support Enabled
INFO - 2018-10-24 18:24:37 --> Utf8 Class Initialized
INFO - 2018-10-24 18:24:37 --> URI Class Initialized
INFO - 2018-10-24 18:24:37 --> Router Class Initialized
INFO - 2018-10-24 18:24:37 --> Output Class Initialized
INFO - 2018-10-24 18:24:37 --> Security Class Initialized
DEBUG - 2018-10-24 18:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-24 18:24:37 --> CSRF cookie sent
INFO - 2018-10-24 18:24:37 --> Input Class Initialized
INFO - 2018-10-24 18:24:37 --> Language Class Initialized
INFO - 2018-10-24 18:24:37 --> Loader Class Initialized
INFO - 2018-10-24 18:24:37 --> Helper loaded: url_helper
INFO - 2018-10-24 18:24:37 --> Helper loaded: form_helper
INFO - 2018-10-24 18:24:37 --> Helper loaded: language_helper
DEBUG - 2018-10-24 18:24:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-24 18:24:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-24 18:24:37 --> User Agent Class Initialized
INFO - 2018-10-24 18:24:37 --> Controller Class Initialized
INFO - 2018-10-24 18:24:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-24 18:24:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-24 18:24:37 --> Helper loaded: custom_helper
INFO - 2018-10-24 18:24:37 --> Pixel_Model class loaded
INFO - 2018-10-24 18:24:37 --> Database Driver Class Initialized
INFO - 2018-10-24 18:24:37 --> Model "RegistrationModel" initialized
DEBUG - 2018-10-24 18:24:37 --> Config file loaded: E:\xampp7\htdocs\famiquity\application\config/recaptcha.php
INFO - 2018-10-24 18:24:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-24 18:24:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-24 18:24:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-24 18:24:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
ERROR - 2018-10-24 18:24:37 --> Could not find the language line "req_email"
INFO - 2018-10-24 18:24:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\register/signup_fa.php
INFO - 2018-10-24 18:24:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-24 18:24:37 --> Final output sent to browser
DEBUG - 2018-10-24 18:24:37 --> Total execution time: 0.4397
INFO - 2018-10-24 18:24:51 --> Config Class Initialized
INFO - 2018-10-24 18:24:51 --> Hooks Class Initialized
DEBUG - 2018-10-24 18:24:51 --> UTF-8 Support Enabled
INFO - 2018-10-24 18:24:51 --> Utf8 Class Initialized
INFO - 2018-10-24 18:24:51 --> URI Class Initialized
INFO - 2018-10-24 18:24:51 --> Router Class Initialized
INFO - 2018-10-24 18:24:51 --> Output Class Initialized
INFO - 2018-10-24 18:24:51 --> Security Class Initialized
DEBUG - 2018-10-24 18:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-24 18:24:51 --> CSRF cookie sent
INFO - 2018-10-24 18:24:51 --> CSRF token verified
INFO - 2018-10-24 18:24:51 --> Input Class Initialized
INFO - 2018-10-24 18:24:51 --> Language Class Initialized
INFO - 2018-10-24 18:24:51 --> Loader Class Initialized
INFO - 2018-10-24 18:24:51 --> Helper loaded: url_helper
INFO - 2018-10-24 18:24:51 --> Helper loaded: form_helper
INFO - 2018-10-24 18:24:51 --> Helper loaded: language_helper
DEBUG - 2018-10-24 18:24:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-24 18:24:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-24 18:24:51 --> User Agent Class Initialized
INFO - 2018-10-24 18:24:51 --> Controller Class Initialized
INFO - 2018-10-24 18:24:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-24 18:24:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-24 18:24:51 --> Helper loaded: custom_helper
DEBUG - 2018-10-24 18:24:51 --> Config file loaded: E:\xampp7\htdocs\famiquity\application\config/recaptcha.php
INFO - 2018-10-24 18:24:51 --> Form Validation Class Initialized
INFO - 2018-10-24 18:24:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-24 18:24:51 --> Pixel_Model class loaded
INFO - 2018-10-24 18:24:51 --> Database Driver Class Initialized
INFO - 2018-10-24 18:24:51 --> Model "RegistrationModel" initialized
ERROR - 2018-10-24 18:24:51 --> Severity: error --> Exception: Call to undefined function mcrypt_create_iv() E:\xampp7\htdocs\famiquity\application\libraries\Smart.php 307
INFO - 2018-10-24 18:25:00 --> Config Class Initialized
INFO - 2018-10-24 18:25:00 --> Hooks Class Initialized
DEBUG - 2018-10-24 18:25:00 --> UTF-8 Support Enabled
INFO - 2018-10-24 18:25:00 --> Utf8 Class Initialized
INFO - 2018-10-24 18:25:00 --> URI Class Initialized
INFO - 2018-10-24 18:25:00 --> Router Class Initialized
INFO - 2018-10-24 18:25:00 --> Output Class Initialized
INFO - 2018-10-24 18:25:00 --> Security Class Initialized
DEBUG - 2018-10-24 18:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-24 18:25:00 --> CSRF cookie sent
INFO - 2018-10-24 18:25:00 --> Input Class Initialized
INFO - 2018-10-24 18:25:00 --> Language Class Initialized
INFO - 2018-10-24 18:25:00 --> Loader Class Initialized
INFO - 2018-10-24 18:25:00 --> Helper loaded: url_helper
INFO - 2018-10-24 18:25:00 --> Helper loaded: form_helper
INFO - 2018-10-24 18:25:00 --> Helper loaded: language_helper
DEBUG - 2018-10-24 18:25:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-24 18:25:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-24 18:25:01 --> User Agent Class Initialized
INFO - 2018-10-24 18:25:01 --> Controller Class Initialized
INFO - 2018-10-24 18:25:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-24 18:25:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-24 18:25:01 --> Helper loaded: custom_helper
INFO - 2018-10-24 18:25:01 --> Pixel_Model class loaded
INFO - 2018-10-24 18:25:01 --> Database Driver Class Initialized
INFO - 2018-10-24 18:25:01 --> Model "RegistrationModel" initialized
DEBUG - 2018-10-24 18:25:01 --> Config file loaded: E:\xampp7\htdocs\famiquity\application\config/recaptcha.php
INFO - 2018-10-24 18:25:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-24 18:25:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-24 18:25:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-24 18:25:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
ERROR - 2018-10-24 18:25:01 --> Could not find the language line "req_email"
INFO - 2018-10-24 18:25:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\register/signup_fa.php
INFO - 2018-10-24 18:25:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-24 18:25:01 --> Final output sent to browser
DEBUG - 2018-10-24 18:25:01 --> Total execution time: 0.4042
INFO - 2018-10-24 18:27:01 --> Config Class Initialized
INFO - 2018-10-24 18:27:01 --> Hooks Class Initialized
DEBUG - 2018-10-24 18:27:01 --> UTF-8 Support Enabled
INFO - 2018-10-24 18:27:01 --> Utf8 Class Initialized
INFO - 2018-10-24 18:27:01 --> URI Class Initialized
INFO - 2018-10-24 18:27:01 --> Router Class Initialized
INFO - 2018-10-24 18:27:01 --> Output Class Initialized
INFO - 2018-10-24 18:27:01 --> Security Class Initialized
DEBUG - 2018-10-24 18:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-24 18:27:01 --> CSRF cookie sent
INFO - 2018-10-24 18:27:01 --> Input Class Initialized
INFO - 2018-10-24 18:27:01 --> Language Class Initialized
INFO - 2018-10-24 18:27:01 --> Loader Class Initialized
INFO - 2018-10-24 18:27:01 --> Helper loaded: url_helper
INFO - 2018-10-24 18:27:01 --> Helper loaded: form_helper
INFO - 2018-10-24 18:27:01 --> Helper loaded: language_helper
DEBUG - 2018-10-24 18:27:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-24 18:27:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-24 18:27:01 --> User Agent Class Initialized
INFO - 2018-10-24 18:27:01 --> Controller Class Initialized
INFO - 2018-10-24 18:27:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-24 18:27:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-24 18:27:01 --> Helper loaded: custom_helper
INFO - 2018-10-24 18:27:01 --> Pixel_Model class loaded
INFO - 2018-10-24 18:27:01 --> Database Driver Class Initialized
INFO - 2018-10-24 18:27:01 --> Model "RegistrationModel" initialized
DEBUG - 2018-10-24 18:27:01 --> Config file loaded: E:\xampp7\htdocs\famiquity\application\config/recaptcha.php
INFO - 2018-10-24 18:27:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-24 18:27:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-24 18:27:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-24 18:27:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
ERROR - 2018-10-24 18:27:01 --> Could not find the language line "req_email"
INFO - 2018-10-24 18:27:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\register/signup.php
INFO - 2018-10-24 18:27:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-24 18:27:01 --> Final output sent to browser
DEBUG - 2018-10-24 18:27:01 --> Total execution time: 0.3824

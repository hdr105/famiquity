<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-10-25 10:30:08 --> Config Class Initialized
INFO - 2018-10-25 10:30:08 --> Hooks Class Initialized
DEBUG - 2018-10-25 10:30:08 --> UTF-8 Support Enabled
INFO - 2018-10-25 10:30:08 --> Utf8 Class Initialized
INFO - 2018-10-25 10:30:08 --> URI Class Initialized
DEBUG - 2018-10-25 10:30:08 --> No URI present. Default controller set.
INFO - 2018-10-25 10:30:08 --> Router Class Initialized
INFO - 2018-10-25 10:30:08 --> Output Class Initialized
INFO - 2018-10-25 10:30:08 --> Security Class Initialized
DEBUG - 2018-10-25 10:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 10:30:08 --> CSRF cookie sent
INFO - 2018-10-25 10:30:08 --> Input Class Initialized
INFO - 2018-10-25 10:30:08 --> Language Class Initialized
INFO - 2018-10-25 10:30:08 --> Loader Class Initialized
INFO - 2018-10-25 10:30:08 --> Helper loaded: url_helper
INFO - 2018-10-25 10:30:08 --> Helper loaded: form_helper
INFO - 2018-10-25 10:30:08 --> Helper loaded: language_helper
DEBUG - 2018-10-25 10:30:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 10:30:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 10:30:08 --> User Agent Class Initialized
INFO - 2018-10-25 10:30:08 --> Controller Class Initialized
INFO - 2018-10-25 10:30:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 10:30:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 10:30:08 --> Helper loaded: custom_helper
INFO - 2018-10-25 10:30:09 --> Pixel_Model class loaded
INFO - 2018-10-25 10:30:09 --> Database Driver Class Initialized
ERROR - 2018-10-25 10:30:11 --> Unable to connect to the database
INFO - 2018-10-25 10:30:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 10:30:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-25 10:30:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-25 10:30:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-25 10:30:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-25 10:30:12 --> Final output sent to browser
DEBUG - 2018-10-25 10:30:12 --> Total execution time: 4.5554
INFO - 2018-10-25 10:30:36 --> Config Class Initialized
INFO - 2018-10-25 10:30:36 --> Hooks Class Initialized
DEBUG - 2018-10-25 10:30:36 --> UTF-8 Support Enabled
INFO - 2018-10-25 10:30:36 --> Utf8 Class Initialized
INFO - 2018-10-25 10:30:36 --> URI Class Initialized
INFO - 2018-10-25 10:30:36 --> Router Class Initialized
INFO - 2018-10-25 10:30:36 --> Output Class Initialized
INFO - 2018-10-25 10:30:36 --> Security Class Initialized
DEBUG - 2018-10-25 10:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 10:30:36 --> CSRF cookie sent
INFO - 2018-10-25 10:30:36 --> Input Class Initialized
INFO - 2018-10-25 10:30:36 --> Language Class Initialized
INFO - 2018-10-25 10:30:36 --> Loader Class Initialized
INFO - 2018-10-25 10:30:36 --> Helper loaded: url_helper
INFO - 2018-10-25 10:30:36 --> Helper loaded: form_helper
INFO - 2018-10-25 10:30:36 --> Helper loaded: language_helper
DEBUG - 2018-10-25 10:30:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 10:30:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 10:30:36 --> User Agent Class Initialized
INFO - 2018-10-25 10:30:37 --> Controller Class Initialized
INFO - 2018-10-25 10:30:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 10:30:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 10:30:37 --> Helper loaded: custom_helper
INFO - 2018-10-25 10:30:37 --> Pixel_Model class loaded
INFO - 2018-10-25 10:30:37 --> Database Driver Class Initialized
INFO - 2018-10-25 10:30:37 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 13:58:27 --> Config Class Initialized
INFO - 2018-10-25 13:58:27 --> Hooks Class Initialized
DEBUG - 2018-10-25 13:58:27 --> UTF-8 Support Enabled
INFO - 2018-10-25 13:58:27 --> Utf8 Class Initialized
INFO - 2018-10-25 13:58:27 --> URI Class Initialized
DEBUG - 2018-10-25 13:58:27 --> No URI present. Default controller set.
INFO - 2018-10-25 13:58:27 --> Router Class Initialized
INFO - 2018-10-25 13:58:27 --> Output Class Initialized
INFO - 2018-10-25 13:58:27 --> Security Class Initialized
DEBUG - 2018-10-25 13:58:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 13:58:27 --> CSRF cookie sent
INFO - 2018-10-25 13:58:27 --> Input Class Initialized
INFO - 2018-10-25 13:58:27 --> Language Class Initialized
INFO - 2018-10-25 13:58:27 --> Loader Class Initialized
INFO - 2018-10-25 13:58:27 --> Helper loaded: url_helper
INFO - 2018-10-25 13:58:27 --> Helper loaded: form_helper
INFO - 2018-10-25 13:58:27 --> Helper loaded: language_helper
DEBUG - 2018-10-25 13:58:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 13:58:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 13:58:27 --> User Agent Class Initialized
INFO - 2018-10-25 13:58:27 --> Controller Class Initialized
INFO - 2018-10-25 13:58:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 13:58:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 13:58:28 --> Helper loaded: custom_helper
INFO - 2018-10-25 13:58:28 --> Pixel_Model class loaded
INFO - 2018-10-25 13:58:28 --> Database Driver Class Initialized
INFO - 2018-10-25 13:58:28 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 13:58:28 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-25 13:58:28 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-25 13:58:28 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-25 13:58:28 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-25 13:58:28 --> Final output sent to browser
DEBUG - 2018-10-25 13:58:28 --> Total execution time: 0.9800
INFO - 2018-10-25 14:00:01 --> Config Class Initialized
INFO - 2018-10-25 14:00:01 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:00:01 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:00:01 --> Utf8 Class Initialized
INFO - 2018-10-25 14:00:01 --> URI Class Initialized
INFO - 2018-10-25 14:00:01 --> Router Class Initialized
INFO - 2018-10-25 14:00:01 --> Output Class Initialized
INFO - 2018-10-25 14:00:01 --> Security Class Initialized
DEBUG - 2018-10-25 14:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:00:01 --> CSRF cookie sent
INFO - 2018-10-25 14:00:01 --> Input Class Initialized
INFO - 2018-10-25 14:00:01 --> Language Class Initialized
INFO - 2018-10-25 14:00:01 --> Loader Class Initialized
INFO - 2018-10-25 14:00:01 --> Helper loaded: url_helper
INFO - 2018-10-25 14:00:01 --> Helper loaded: form_helper
INFO - 2018-10-25 14:00:01 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:00:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:00:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:00:01 --> User Agent Class Initialized
INFO - 2018-10-25 14:00:01 --> Controller Class Initialized
INFO - 2018-10-25 14:00:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:00:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:00:01 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:00:01 --> Pixel_Model class loaded
INFO - 2018-10-25 14:00:01 --> Database Driver Class Initialized
INFO - 2018-10-25 14:00:01 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:00:01 --> Config Class Initialized
INFO - 2018-10-25 14:00:01 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:00:01 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:00:01 --> Utf8 Class Initialized
INFO - 2018-10-25 14:00:01 --> URI Class Initialized
INFO - 2018-10-25 14:00:01 --> Router Class Initialized
INFO - 2018-10-25 14:00:01 --> Output Class Initialized
INFO - 2018-10-25 14:00:01 --> Security Class Initialized
DEBUG - 2018-10-25 14:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:00:01 --> CSRF cookie sent
INFO - 2018-10-25 14:00:01 --> Input Class Initialized
INFO - 2018-10-25 14:00:01 --> Language Class Initialized
INFO - 2018-10-25 14:00:01 --> Loader Class Initialized
INFO - 2018-10-25 14:00:01 --> Helper loaded: url_helper
INFO - 2018-10-25 14:00:01 --> Helper loaded: form_helper
INFO - 2018-10-25 14:00:01 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:00:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:00:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:00:01 --> User Agent Class Initialized
INFO - 2018-10-25 14:00:01 --> Controller Class Initialized
INFO - 2018-10-25 14:00:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:00:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:00:01 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:00:01 --> Pixel_Model class loaded
INFO - 2018-10-25 14:00:01 --> Database Driver Class Initialized
INFO - 2018-10-25 14:00:01 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:00:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-25 14:00:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-25 14:00:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-25 14:00:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-25 14:00:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-25 14:00:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-25 14:00:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-25 14:00:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-25 14:00:01 --> Final output sent to browser
DEBUG - 2018-10-25 14:00:01 --> Total execution time: 0.3144
INFO - 2018-10-25 14:00:05 --> Config Class Initialized
INFO - 2018-10-25 14:00:05 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:00:05 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:00:05 --> Utf8 Class Initialized
INFO - 2018-10-25 14:00:05 --> URI Class Initialized
INFO - 2018-10-25 14:00:05 --> Router Class Initialized
INFO - 2018-10-25 14:00:05 --> Output Class Initialized
INFO - 2018-10-25 14:00:05 --> Security Class Initialized
DEBUG - 2018-10-25 14:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:00:05 --> CSRF cookie sent
INFO - 2018-10-25 14:00:05 --> CSRF token verified
INFO - 2018-10-25 14:00:05 --> Input Class Initialized
INFO - 2018-10-25 14:00:05 --> Language Class Initialized
INFO - 2018-10-25 14:00:05 --> Loader Class Initialized
INFO - 2018-10-25 14:00:05 --> Helper loaded: url_helper
INFO - 2018-10-25 14:00:05 --> Helper loaded: form_helper
INFO - 2018-10-25 14:00:05 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:00:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:00:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:00:05 --> User Agent Class Initialized
INFO - 2018-10-25 14:00:05 --> Controller Class Initialized
INFO - 2018-10-25 14:00:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:00:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:00:05 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:00:05 --> Pixel_Model class loaded
INFO - 2018-10-25 14:00:05 --> Database Driver Class Initialized
INFO - 2018-10-25 14:00:05 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:00:05 --> Database Driver Class Initialized
INFO - 2018-10-25 14:00:05 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:00:05 --> Config Class Initialized
INFO - 2018-10-25 14:00:05 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:00:05 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:00:05 --> Utf8 Class Initialized
INFO - 2018-10-25 14:00:05 --> URI Class Initialized
INFO - 2018-10-25 14:00:05 --> Router Class Initialized
INFO - 2018-10-25 14:00:05 --> Output Class Initialized
INFO - 2018-10-25 14:00:05 --> Security Class Initialized
DEBUG - 2018-10-25 14:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:00:05 --> CSRF cookie sent
INFO - 2018-10-25 14:00:05 --> Input Class Initialized
INFO - 2018-10-25 14:00:05 --> Language Class Initialized
INFO - 2018-10-25 14:00:05 --> Loader Class Initialized
INFO - 2018-10-25 14:00:05 --> Helper loaded: url_helper
INFO - 2018-10-25 14:00:05 --> Helper loaded: form_helper
INFO - 2018-10-25 14:00:05 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:00:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:00:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:00:05 --> User Agent Class Initialized
INFO - 2018-10-25 14:00:05 --> Controller Class Initialized
INFO - 2018-10-25 14:00:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:00:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:00:05 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:00:05 --> Pixel_Model class loaded
INFO - 2018-10-25 14:00:05 --> Database Driver Class Initialized
INFO - 2018-10-25 14:00:05 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:00:05 --> Database Driver Class Initialized
INFO - 2018-10-25 14:00:05 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:00:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-25 14:00:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-25 14:00:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-25 14:00:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-25 14:00:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-25 14:00:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-25 14:00:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-25 14:00:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-25 14:00:05 --> Final output sent to browser
DEBUG - 2018-10-25 14:00:05 --> Total execution time: 0.3120
INFO - 2018-10-25 14:00:08 --> Config Class Initialized
INFO - 2018-10-25 14:00:08 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:00:08 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:00:08 --> Utf8 Class Initialized
INFO - 2018-10-25 14:00:08 --> URI Class Initialized
INFO - 2018-10-25 14:00:08 --> Router Class Initialized
INFO - 2018-10-25 14:00:08 --> Output Class Initialized
INFO - 2018-10-25 14:00:08 --> Security Class Initialized
DEBUG - 2018-10-25 14:00:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:00:08 --> CSRF cookie sent
INFO - 2018-10-25 14:00:08 --> CSRF token verified
INFO - 2018-10-25 14:00:08 --> Input Class Initialized
INFO - 2018-10-25 14:00:08 --> Language Class Initialized
INFO - 2018-10-25 14:00:08 --> Loader Class Initialized
INFO - 2018-10-25 14:00:08 --> Helper loaded: url_helper
INFO - 2018-10-25 14:00:08 --> Helper loaded: form_helper
INFO - 2018-10-25 14:00:08 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:00:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:00:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:00:08 --> User Agent Class Initialized
INFO - 2018-10-25 14:00:08 --> Controller Class Initialized
INFO - 2018-10-25 14:00:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:00:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:00:08 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:00:08 --> Pixel_Model class loaded
INFO - 2018-10-25 14:00:08 --> Database Driver Class Initialized
INFO - 2018-10-25 14:00:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:00:08 --> Form Validation Class Initialized
INFO - 2018-10-25 14:00:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-25 14:00:08 --> Database Driver Class Initialized
INFO - 2018-10-25 14:00:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:00:09 --> Config Class Initialized
INFO - 2018-10-25 14:00:09 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:00:09 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:00:09 --> Utf8 Class Initialized
INFO - 2018-10-25 14:00:09 --> URI Class Initialized
INFO - 2018-10-25 14:00:09 --> Router Class Initialized
INFO - 2018-10-25 14:00:09 --> Output Class Initialized
INFO - 2018-10-25 14:00:09 --> Security Class Initialized
DEBUG - 2018-10-25 14:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:00:09 --> CSRF cookie sent
INFO - 2018-10-25 14:00:09 --> Input Class Initialized
INFO - 2018-10-25 14:00:09 --> Language Class Initialized
INFO - 2018-10-25 14:00:09 --> Loader Class Initialized
INFO - 2018-10-25 14:00:09 --> Helper loaded: url_helper
INFO - 2018-10-25 14:00:09 --> Helper loaded: form_helper
INFO - 2018-10-25 14:00:09 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:00:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:00:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:00:09 --> User Agent Class Initialized
INFO - 2018-10-25 14:00:09 --> Controller Class Initialized
INFO - 2018-10-25 14:00:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:00:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:00:09 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:00:09 --> Pixel_Model class loaded
INFO - 2018-10-25 14:00:09 --> Database Driver Class Initialized
INFO - 2018-10-25 14:00:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:00:09 --> Database Driver Class Initialized
INFO - 2018-10-25 14:00:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:00:09 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-25 14:00:09 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-25 14:00:09 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-25 14:00:09 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-25 14:00:09 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-25 14:00:09 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-25 14:00:09 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/your_job.php
INFO - 2018-10-25 14:00:09 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-25 14:00:09 --> Final output sent to browser
DEBUG - 2018-10-25 14:00:09 --> Total execution time: 0.2902
INFO - 2018-10-25 14:00:09 --> Config Class Initialized
INFO - 2018-10-25 14:00:09 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:00:09 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:00:10 --> Utf8 Class Initialized
INFO - 2018-10-25 14:00:10 --> URI Class Initialized
INFO - 2018-10-25 14:00:10 --> Router Class Initialized
INFO - 2018-10-25 14:00:10 --> Output Class Initialized
INFO - 2018-10-25 14:00:10 --> Security Class Initialized
DEBUG - 2018-10-25 14:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:00:10 --> CSRF cookie sent
INFO - 2018-10-25 14:00:10 --> CSRF token verified
INFO - 2018-10-25 14:00:10 --> Input Class Initialized
INFO - 2018-10-25 14:00:10 --> Language Class Initialized
INFO - 2018-10-25 14:00:10 --> Loader Class Initialized
INFO - 2018-10-25 14:00:10 --> Helper loaded: url_helper
INFO - 2018-10-25 14:00:10 --> Helper loaded: form_helper
INFO - 2018-10-25 14:00:10 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:00:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:00:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:00:10 --> User Agent Class Initialized
INFO - 2018-10-25 14:00:10 --> Controller Class Initialized
INFO - 2018-10-25 14:00:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:00:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:00:10 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:00:10 --> Pixel_Model class loaded
INFO - 2018-10-25 14:00:10 --> Database Driver Class Initialized
INFO - 2018-10-25 14:00:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:00:10 --> Form Validation Class Initialized
INFO - 2018-10-25 14:00:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-25 14:00:10 --> Database Driver Class Initialized
INFO - 2018-10-25 14:00:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:00:10 --> Config Class Initialized
INFO - 2018-10-25 14:00:10 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:00:10 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:00:10 --> Utf8 Class Initialized
INFO - 2018-10-25 14:00:10 --> URI Class Initialized
INFO - 2018-10-25 14:00:10 --> Router Class Initialized
INFO - 2018-10-25 14:00:10 --> Output Class Initialized
INFO - 2018-10-25 14:00:10 --> Security Class Initialized
DEBUG - 2018-10-25 14:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:00:10 --> CSRF cookie sent
INFO - 2018-10-25 14:00:10 --> Input Class Initialized
INFO - 2018-10-25 14:00:10 --> Language Class Initialized
INFO - 2018-10-25 14:00:10 --> Loader Class Initialized
INFO - 2018-10-25 14:00:10 --> Helper loaded: url_helper
INFO - 2018-10-25 14:00:10 --> Helper loaded: form_helper
INFO - 2018-10-25 14:00:10 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:00:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:00:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:00:10 --> User Agent Class Initialized
INFO - 2018-10-25 14:00:10 --> Controller Class Initialized
INFO - 2018-10-25 14:00:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:00:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:00:10 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:00:10 --> Pixel_Model class loaded
INFO - 2018-10-25 14:00:10 --> Database Driver Class Initialized
INFO - 2018-10-25 14:00:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:00:10 --> Database Driver Class Initialized
INFO - 2018-10-25 14:00:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:00:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-25 14:00:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-25 14:00:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner.php
INFO - 2018-10-25 14:00:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-25 14:00:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-25 14:00:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-25 14:00:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-25 14:00:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/relation_ship_status.php
INFO - 2018-10-25 14:00:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-25 14:00:10 --> Final output sent to browser
DEBUG - 2018-10-25 14:00:10 --> Total execution time: 0.2934
INFO - 2018-10-25 14:00:11 --> Config Class Initialized
INFO - 2018-10-25 14:00:11 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:00:11 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:00:11 --> Utf8 Class Initialized
INFO - 2018-10-25 14:00:11 --> URI Class Initialized
INFO - 2018-10-25 14:00:11 --> Router Class Initialized
INFO - 2018-10-25 14:00:11 --> Output Class Initialized
INFO - 2018-10-25 14:00:11 --> Security Class Initialized
DEBUG - 2018-10-25 14:00:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:00:11 --> CSRF cookie sent
INFO - 2018-10-25 14:00:11 --> CSRF token verified
INFO - 2018-10-25 14:00:11 --> Input Class Initialized
INFO - 2018-10-25 14:00:11 --> Language Class Initialized
INFO - 2018-10-25 14:00:11 --> Loader Class Initialized
INFO - 2018-10-25 14:00:11 --> Helper loaded: url_helper
INFO - 2018-10-25 14:00:11 --> Helper loaded: form_helper
INFO - 2018-10-25 14:00:11 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:00:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:00:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:00:11 --> User Agent Class Initialized
INFO - 2018-10-25 14:00:11 --> Controller Class Initialized
INFO - 2018-10-25 14:00:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:00:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:00:11 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:00:11 --> Pixel_Model class loaded
INFO - 2018-10-25 14:00:11 --> Database Driver Class Initialized
INFO - 2018-10-25 14:00:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:00:11 --> Form Validation Class Initialized
INFO - 2018-10-25 14:00:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-25 14:00:11 --> Database Driver Class Initialized
INFO - 2018-10-25 14:00:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:00:11 --> Config Class Initialized
INFO - 2018-10-25 14:00:11 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:00:11 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:00:11 --> Utf8 Class Initialized
INFO - 2018-10-25 14:00:11 --> URI Class Initialized
INFO - 2018-10-25 14:00:11 --> Router Class Initialized
INFO - 2018-10-25 14:00:11 --> Output Class Initialized
INFO - 2018-10-25 14:00:11 --> Security Class Initialized
DEBUG - 2018-10-25 14:00:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:00:11 --> CSRF cookie sent
INFO - 2018-10-25 14:00:11 --> Input Class Initialized
INFO - 2018-10-25 14:00:11 --> Language Class Initialized
INFO - 2018-10-25 14:00:11 --> Loader Class Initialized
INFO - 2018-10-25 14:00:11 --> Helper loaded: url_helper
INFO - 2018-10-25 14:00:11 --> Helper loaded: form_helper
INFO - 2018-10-25 14:00:11 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:00:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:00:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:00:11 --> User Agent Class Initialized
INFO - 2018-10-25 14:00:11 --> Controller Class Initialized
INFO - 2018-10-25 14:00:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:00:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:00:11 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:00:11 --> Pixel_Model class loaded
INFO - 2018-10-25 14:00:11 --> Database Driver Class Initialized
INFO - 2018-10-25 14:00:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:00:11 --> Database Driver Class Initialized
INFO - 2018-10-25 14:00:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:00:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-25 14:00:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-25 14:00:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-25 14:00:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-25 14:00:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-25 14:00:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-25 14:00:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/income.php
INFO - 2018-10-25 14:00:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-25 14:00:11 --> Final output sent to browser
DEBUG - 2018-10-25 14:00:11 --> Total execution time: 0.3451
INFO - 2018-10-25 14:00:14 --> Config Class Initialized
INFO - 2018-10-25 14:00:14 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:00:14 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:00:14 --> Utf8 Class Initialized
INFO - 2018-10-25 14:00:14 --> URI Class Initialized
INFO - 2018-10-25 14:00:14 --> Router Class Initialized
INFO - 2018-10-25 14:00:14 --> Output Class Initialized
INFO - 2018-10-25 14:00:14 --> Security Class Initialized
DEBUG - 2018-10-25 14:00:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:00:14 --> CSRF cookie sent
INFO - 2018-10-25 14:00:14 --> CSRF token verified
INFO - 2018-10-25 14:00:14 --> Input Class Initialized
INFO - 2018-10-25 14:00:14 --> Language Class Initialized
INFO - 2018-10-25 14:00:14 --> Loader Class Initialized
INFO - 2018-10-25 14:00:14 --> Helper loaded: url_helper
INFO - 2018-10-25 14:00:14 --> Helper loaded: form_helper
INFO - 2018-10-25 14:00:14 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:00:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:00:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:00:14 --> User Agent Class Initialized
INFO - 2018-10-25 14:00:14 --> Controller Class Initialized
INFO - 2018-10-25 14:00:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:00:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:00:15 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:00:15 --> Pixel_Model class loaded
INFO - 2018-10-25 14:00:15 --> Database Driver Class Initialized
INFO - 2018-10-25 14:00:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:00:15 --> Form Validation Class Initialized
INFO - 2018-10-25 14:00:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-25 14:00:15 --> Database Driver Class Initialized
INFO - 2018-10-25 14:00:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:00:15 --> Config Class Initialized
INFO - 2018-10-25 14:00:15 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:00:15 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:00:15 --> Utf8 Class Initialized
INFO - 2018-10-25 14:00:15 --> URI Class Initialized
INFO - 2018-10-25 14:00:15 --> Router Class Initialized
INFO - 2018-10-25 14:00:15 --> Output Class Initialized
INFO - 2018-10-25 14:00:15 --> Security Class Initialized
DEBUG - 2018-10-25 14:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:00:15 --> CSRF cookie sent
INFO - 2018-10-25 14:00:15 --> Input Class Initialized
INFO - 2018-10-25 14:00:15 --> Language Class Initialized
INFO - 2018-10-25 14:00:15 --> Loader Class Initialized
INFO - 2018-10-25 14:00:15 --> Helper loaded: url_helper
INFO - 2018-10-25 14:00:15 --> Helper loaded: form_helper
INFO - 2018-10-25 14:00:15 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:00:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:00:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:00:15 --> User Agent Class Initialized
INFO - 2018-10-25 14:00:15 --> Controller Class Initialized
INFO - 2018-10-25 14:00:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:00:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:00:15 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:00:15 --> Pixel_Model class loaded
INFO - 2018-10-25 14:00:15 --> Database Driver Class Initialized
INFO - 2018-10-25 14:00:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:00:15 --> Database Driver Class Initialized
INFO - 2018-10-25 14:00:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:00:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-25 14:00:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-25 14:00:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-25 14:00:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-25 14:00:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-25 14:00:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-25 14:00:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/marriage.php
INFO - 2018-10-25 14:00:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-25 14:00:15 --> Final output sent to browser
DEBUG - 2018-10-25 14:00:15 --> Total execution time: 0.3065
INFO - 2018-10-25 14:00:18 --> Config Class Initialized
INFO - 2018-10-25 14:00:18 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:00:18 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:00:18 --> Utf8 Class Initialized
INFO - 2018-10-25 14:00:18 --> URI Class Initialized
INFO - 2018-10-25 14:00:18 --> Router Class Initialized
INFO - 2018-10-25 14:00:18 --> Output Class Initialized
INFO - 2018-10-25 14:00:18 --> Security Class Initialized
DEBUG - 2018-10-25 14:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:00:18 --> CSRF cookie sent
INFO - 2018-10-25 14:00:18 --> CSRF token verified
INFO - 2018-10-25 14:00:18 --> Input Class Initialized
INFO - 2018-10-25 14:00:18 --> Language Class Initialized
INFO - 2018-10-25 14:00:18 --> Loader Class Initialized
INFO - 2018-10-25 14:00:18 --> Helper loaded: url_helper
INFO - 2018-10-25 14:00:18 --> Helper loaded: form_helper
INFO - 2018-10-25 14:00:18 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:00:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:00:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:00:18 --> User Agent Class Initialized
INFO - 2018-10-25 14:00:18 --> Controller Class Initialized
INFO - 2018-10-25 14:00:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:00:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:00:18 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:00:18 --> Pixel_Model class loaded
INFO - 2018-10-25 14:00:18 --> Database Driver Class Initialized
INFO - 2018-10-25 14:00:18 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:00:18 --> Form Validation Class Initialized
INFO - 2018-10-25 14:00:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-25 14:00:18 --> Database Driver Class Initialized
INFO - 2018-10-25 14:00:18 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:00:18 --> Config Class Initialized
INFO - 2018-10-25 14:00:18 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:00:18 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:00:18 --> Utf8 Class Initialized
INFO - 2018-10-25 14:00:18 --> URI Class Initialized
INFO - 2018-10-25 14:00:18 --> Router Class Initialized
INFO - 2018-10-25 14:00:18 --> Output Class Initialized
INFO - 2018-10-25 14:00:18 --> Security Class Initialized
DEBUG - 2018-10-25 14:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:00:18 --> CSRF cookie sent
INFO - 2018-10-25 14:00:18 --> Input Class Initialized
INFO - 2018-10-25 14:00:18 --> Language Class Initialized
INFO - 2018-10-25 14:00:18 --> Loader Class Initialized
INFO - 2018-10-25 14:00:18 --> Helper loaded: url_helper
INFO - 2018-10-25 14:00:18 --> Helper loaded: form_helper
INFO - 2018-10-25 14:00:18 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:00:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:00:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:00:18 --> User Agent Class Initialized
INFO - 2018-10-25 14:00:18 --> Controller Class Initialized
INFO - 2018-10-25 14:00:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:00:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:00:18 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:00:18 --> Pixel_Model class loaded
INFO - 2018-10-25 14:00:18 --> Database Driver Class Initialized
INFO - 2018-10-25 14:00:18 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:00:18 --> Database Driver Class Initialized
INFO - 2018-10-25 14:00:18 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:00:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-25 14:00:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-25 14:00:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-25 14:00:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-25 14:00:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-25 14:00:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-25 14:00:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/kids.php
INFO - 2018-10-25 14:00:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-25 14:00:18 --> Final output sent to browser
DEBUG - 2018-10-25 14:00:18 --> Total execution time: 0.3296
INFO - 2018-10-25 14:00:21 --> Config Class Initialized
INFO - 2018-10-25 14:00:21 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:00:21 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:00:21 --> Utf8 Class Initialized
INFO - 2018-10-25 14:00:21 --> URI Class Initialized
INFO - 2018-10-25 14:00:21 --> Router Class Initialized
INFO - 2018-10-25 14:00:21 --> Output Class Initialized
INFO - 2018-10-25 14:00:21 --> Security Class Initialized
DEBUG - 2018-10-25 14:00:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:00:21 --> CSRF cookie sent
INFO - 2018-10-25 14:00:21 --> CSRF token verified
INFO - 2018-10-25 14:00:21 --> Input Class Initialized
INFO - 2018-10-25 14:00:21 --> Language Class Initialized
INFO - 2018-10-25 14:00:21 --> Loader Class Initialized
INFO - 2018-10-25 14:00:21 --> Helper loaded: url_helper
INFO - 2018-10-25 14:00:21 --> Helper loaded: form_helper
INFO - 2018-10-25 14:00:21 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:00:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:00:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:00:21 --> User Agent Class Initialized
INFO - 2018-10-25 14:00:21 --> Controller Class Initialized
INFO - 2018-10-25 14:00:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:00:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:00:21 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:00:21 --> Pixel_Model class loaded
INFO - 2018-10-25 14:00:21 --> Database Driver Class Initialized
INFO - 2018-10-25 14:00:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:00:21 --> Form Validation Class Initialized
INFO - 2018-10-25 14:00:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-25 14:00:21 --> Database Driver Class Initialized
INFO - 2018-10-25 14:00:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:00:21 --> Config Class Initialized
INFO - 2018-10-25 14:00:21 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:00:21 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:00:21 --> Utf8 Class Initialized
INFO - 2018-10-25 14:00:21 --> URI Class Initialized
INFO - 2018-10-25 14:00:21 --> Router Class Initialized
INFO - 2018-10-25 14:00:21 --> Output Class Initialized
INFO - 2018-10-25 14:00:21 --> Security Class Initialized
DEBUG - 2018-10-25 14:00:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:00:22 --> CSRF cookie sent
INFO - 2018-10-25 14:00:22 --> Input Class Initialized
INFO - 2018-10-25 14:00:22 --> Language Class Initialized
INFO - 2018-10-25 14:00:22 --> Loader Class Initialized
INFO - 2018-10-25 14:00:22 --> Helper loaded: url_helper
INFO - 2018-10-25 14:00:22 --> Helper loaded: form_helper
INFO - 2018-10-25 14:00:22 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:00:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:00:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:00:22 --> User Agent Class Initialized
INFO - 2018-10-25 14:00:22 --> Controller Class Initialized
INFO - 2018-10-25 14:00:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:00:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:00:22 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:00:22 --> Pixel_Model class loaded
INFO - 2018-10-25 14:00:22 --> Database Driver Class Initialized
INFO - 2018-10-25 14:00:22 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:00:22 --> Database Driver Class Initialized
INFO - 2018-10-25 14:00:22 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:00:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-25 14:00:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-25 14:00:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-25 14:00:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-25 14:00:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-25 14:00:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-25 14:00:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/pension.php
INFO - 2018-10-25 14:00:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-25 14:00:22 --> Final output sent to browser
DEBUG - 2018-10-25 14:00:22 --> Total execution time: 0.3377
INFO - 2018-10-25 14:00:25 --> Config Class Initialized
INFO - 2018-10-25 14:00:25 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:00:25 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:00:25 --> Utf8 Class Initialized
INFO - 2018-10-25 14:00:25 --> URI Class Initialized
INFO - 2018-10-25 14:00:25 --> Router Class Initialized
INFO - 2018-10-25 14:00:25 --> Output Class Initialized
INFO - 2018-10-25 14:00:25 --> Security Class Initialized
DEBUG - 2018-10-25 14:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:00:25 --> CSRF cookie sent
INFO - 2018-10-25 14:00:25 --> CSRF token verified
INFO - 2018-10-25 14:00:25 --> Input Class Initialized
INFO - 2018-10-25 14:00:25 --> Language Class Initialized
INFO - 2018-10-25 14:00:25 --> Loader Class Initialized
INFO - 2018-10-25 14:00:25 --> Helper loaded: url_helper
INFO - 2018-10-25 14:00:25 --> Helper loaded: form_helper
INFO - 2018-10-25 14:00:25 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:00:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:00:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:00:25 --> User Agent Class Initialized
INFO - 2018-10-25 14:00:25 --> Controller Class Initialized
INFO - 2018-10-25 14:00:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:00:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:00:25 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:00:25 --> Pixel_Model class loaded
INFO - 2018-10-25 14:00:25 --> Database Driver Class Initialized
INFO - 2018-10-25 14:00:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:00:25 --> Form Validation Class Initialized
INFO - 2018-10-25 14:00:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-25 14:00:25 --> Database Driver Class Initialized
INFO - 2018-10-25 14:00:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:00:25 --> Config Class Initialized
INFO - 2018-10-25 14:00:25 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:00:25 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:00:25 --> Utf8 Class Initialized
INFO - 2018-10-25 14:00:25 --> URI Class Initialized
INFO - 2018-10-25 14:00:25 --> Router Class Initialized
INFO - 2018-10-25 14:00:25 --> Output Class Initialized
INFO - 2018-10-25 14:00:25 --> Security Class Initialized
DEBUG - 2018-10-25 14:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:00:25 --> CSRF cookie sent
INFO - 2018-10-25 14:00:25 --> Input Class Initialized
INFO - 2018-10-25 14:00:25 --> Language Class Initialized
INFO - 2018-10-25 14:00:25 --> Loader Class Initialized
INFO - 2018-10-25 14:00:25 --> Helper loaded: url_helper
INFO - 2018-10-25 14:00:25 --> Helper loaded: form_helper
INFO - 2018-10-25 14:00:25 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:00:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:00:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:00:25 --> User Agent Class Initialized
INFO - 2018-10-25 14:00:25 --> Controller Class Initialized
INFO - 2018-10-25 14:00:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:00:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:00:25 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:00:25 --> Pixel_Model class loaded
INFO - 2018-10-25 14:00:26 --> Database Driver Class Initialized
INFO - 2018-10-25 14:00:26 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:00:26 --> Database Driver Class Initialized
INFO - 2018-10-25 14:00:26 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:00:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-25 14:00:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-25 14:00:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-25 14:00:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-25 14:00:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-25 14:00:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-25 14:00:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/inheritance.php
INFO - 2018-10-25 14:00:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-25 14:00:26 --> Final output sent to browser
DEBUG - 2018-10-25 14:00:26 --> Total execution time: 0.3338
INFO - 2018-10-25 14:00:29 --> Config Class Initialized
INFO - 2018-10-25 14:00:29 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:00:29 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:00:29 --> Utf8 Class Initialized
INFO - 2018-10-25 14:00:29 --> URI Class Initialized
INFO - 2018-10-25 14:00:29 --> Router Class Initialized
INFO - 2018-10-25 14:00:29 --> Output Class Initialized
INFO - 2018-10-25 14:00:29 --> Security Class Initialized
DEBUG - 2018-10-25 14:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:00:29 --> CSRF cookie sent
INFO - 2018-10-25 14:00:29 --> CSRF token verified
INFO - 2018-10-25 14:00:29 --> Input Class Initialized
INFO - 2018-10-25 14:00:29 --> Language Class Initialized
INFO - 2018-10-25 14:00:29 --> Loader Class Initialized
INFO - 2018-10-25 14:00:29 --> Helper loaded: url_helper
INFO - 2018-10-25 14:00:29 --> Helper loaded: form_helper
INFO - 2018-10-25 14:00:29 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:00:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:00:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:00:29 --> User Agent Class Initialized
INFO - 2018-10-25 14:00:29 --> Controller Class Initialized
INFO - 2018-10-25 14:00:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:00:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:00:29 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:00:29 --> Pixel_Model class loaded
INFO - 2018-10-25 14:00:29 --> Database Driver Class Initialized
INFO - 2018-10-25 14:00:29 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:00:29 --> Form Validation Class Initialized
INFO - 2018-10-25 14:00:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-25 14:00:29 --> Database Driver Class Initialized
INFO - 2018-10-25 14:00:29 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:00:29 --> Config Class Initialized
INFO - 2018-10-25 14:00:29 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:00:29 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:00:29 --> Utf8 Class Initialized
INFO - 2018-10-25 14:00:29 --> URI Class Initialized
INFO - 2018-10-25 14:00:29 --> Router Class Initialized
INFO - 2018-10-25 14:00:29 --> Output Class Initialized
INFO - 2018-10-25 14:00:29 --> Security Class Initialized
DEBUG - 2018-10-25 14:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:00:29 --> CSRF cookie sent
INFO - 2018-10-25 14:00:29 --> Input Class Initialized
INFO - 2018-10-25 14:00:29 --> Language Class Initialized
INFO - 2018-10-25 14:00:29 --> Loader Class Initialized
INFO - 2018-10-25 14:00:29 --> Helper loaded: url_helper
INFO - 2018-10-25 14:00:29 --> Helper loaded: form_helper
INFO - 2018-10-25 14:00:29 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:00:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:00:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:00:29 --> User Agent Class Initialized
INFO - 2018-10-25 14:00:29 --> Controller Class Initialized
INFO - 2018-10-25 14:00:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:00:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:00:29 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:00:29 --> Pixel_Model class loaded
INFO - 2018-10-25 14:00:29 --> Database Driver Class Initialized
INFO - 2018-10-25 14:00:29 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:00:29 --> Database Driver Class Initialized
INFO - 2018-10-25 14:00:29 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:00:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-25 14:00:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-25 14:00:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-25 14:00:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-25 14:00:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-25 14:00:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-25 14:00:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/inheritance_maintained.php
INFO - 2018-10-25 14:00:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-25 14:00:29 --> Final output sent to browser
DEBUG - 2018-10-25 14:00:29 --> Total execution time: 0.3249
INFO - 2018-10-25 14:00:30 --> Config Class Initialized
INFO - 2018-10-25 14:00:30 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:00:30 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:00:30 --> Utf8 Class Initialized
INFO - 2018-10-25 14:00:30 --> URI Class Initialized
INFO - 2018-10-25 14:00:30 --> Router Class Initialized
INFO - 2018-10-25 14:00:30 --> Output Class Initialized
INFO - 2018-10-25 14:00:30 --> Security Class Initialized
DEBUG - 2018-10-25 14:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:00:30 --> CSRF cookie sent
INFO - 2018-10-25 14:00:30 --> CSRF token verified
INFO - 2018-10-25 14:00:30 --> Input Class Initialized
INFO - 2018-10-25 14:00:30 --> Language Class Initialized
INFO - 2018-10-25 14:00:30 --> Loader Class Initialized
INFO - 2018-10-25 14:00:30 --> Helper loaded: url_helper
INFO - 2018-10-25 14:00:30 --> Helper loaded: form_helper
INFO - 2018-10-25 14:00:30 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:00:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:00:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:00:30 --> User Agent Class Initialized
INFO - 2018-10-25 14:00:30 --> Controller Class Initialized
INFO - 2018-10-25 14:00:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:00:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:00:31 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:00:31 --> Pixel_Model class loaded
INFO - 2018-10-25 14:00:31 --> Database Driver Class Initialized
INFO - 2018-10-25 14:00:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:00:31 --> Form Validation Class Initialized
INFO - 2018-10-25 14:00:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-25 14:00:31 --> Database Driver Class Initialized
INFO - 2018-10-25 14:00:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:00:31 --> Config Class Initialized
INFO - 2018-10-25 14:00:31 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:00:31 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:00:31 --> Utf8 Class Initialized
INFO - 2018-10-25 14:00:31 --> URI Class Initialized
INFO - 2018-10-25 14:00:31 --> Router Class Initialized
INFO - 2018-10-25 14:00:31 --> Output Class Initialized
INFO - 2018-10-25 14:00:31 --> Security Class Initialized
DEBUG - 2018-10-25 14:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:00:31 --> CSRF cookie sent
INFO - 2018-10-25 14:00:31 --> Input Class Initialized
INFO - 2018-10-25 14:00:31 --> Language Class Initialized
INFO - 2018-10-25 14:00:31 --> Loader Class Initialized
INFO - 2018-10-25 14:00:31 --> Helper loaded: url_helper
INFO - 2018-10-25 14:00:31 --> Helper loaded: form_helper
INFO - 2018-10-25 14:00:31 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:00:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:00:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:00:31 --> User Agent Class Initialized
INFO - 2018-10-25 14:00:31 --> Controller Class Initialized
INFO - 2018-10-25 14:00:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:00:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:00:31 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:00:31 --> Pixel_Model class loaded
INFO - 2018-10-25 14:00:31 --> Database Driver Class Initialized
INFO - 2018-10-25 14:00:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:00:31 --> Database Driver Class Initialized
INFO - 2018-10-25 14:00:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:00:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-25 14:00:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-25 14:00:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-25 14:00:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-25 14:00:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-25 14:00:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-25 14:00:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/home_owner.php
INFO - 2018-10-25 14:00:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-25 14:00:31 --> Final output sent to browser
DEBUG - 2018-10-25 14:00:31 --> Total execution time: 0.3538
INFO - 2018-10-25 14:00:32 --> Config Class Initialized
INFO - 2018-10-25 14:00:32 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:00:32 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:00:32 --> Utf8 Class Initialized
INFO - 2018-10-25 14:00:32 --> URI Class Initialized
INFO - 2018-10-25 14:00:32 --> Router Class Initialized
INFO - 2018-10-25 14:00:32 --> Output Class Initialized
INFO - 2018-10-25 14:00:32 --> Security Class Initialized
DEBUG - 2018-10-25 14:00:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:00:32 --> CSRF cookie sent
INFO - 2018-10-25 14:00:32 --> CSRF token verified
INFO - 2018-10-25 14:00:32 --> Input Class Initialized
INFO - 2018-10-25 14:00:32 --> Language Class Initialized
INFO - 2018-10-25 14:00:32 --> Loader Class Initialized
INFO - 2018-10-25 14:00:32 --> Helper loaded: url_helper
INFO - 2018-10-25 14:00:32 --> Helper loaded: form_helper
INFO - 2018-10-25 14:00:32 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:00:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:00:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:00:32 --> User Agent Class Initialized
INFO - 2018-10-25 14:00:32 --> Controller Class Initialized
INFO - 2018-10-25 14:00:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:00:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:00:32 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:00:32 --> Pixel_Model class loaded
INFO - 2018-10-25 14:00:32 --> Database Driver Class Initialized
INFO - 2018-10-25 14:00:32 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:00:32 --> Form Validation Class Initialized
INFO - 2018-10-25 14:00:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-25 14:00:33 --> Database Driver Class Initialized
INFO - 2018-10-25 14:00:33 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:00:33 --> Config Class Initialized
INFO - 2018-10-25 14:00:33 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:00:33 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:00:33 --> Utf8 Class Initialized
INFO - 2018-10-25 14:00:33 --> URI Class Initialized
INFO - 2018-10-25 14:00:33 --> Router Class Initialized
INFO - 2018-10-25 14:00:33 --> Output Class Initialized
INFO - 2018-10-25 14:00:33 --> Security Class Initialized
DEBUG - 2018-10-25 14:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:00:33 --> CSRF cookie sent
INFO - 2018-10-25 14:00:33 --> Input Class Initialized
INFO - 2018-10-25 14:00:33 --> Language Class Initialized
INFO - 2018-10-25 14:00:33 --> Loader Class Initialized
INFO - 2018-10-25 14:00:33 --> Helper loaded: url_helper
INFO - 2018-10-25 14:00:33 --> Helper loaded: form_helper
INFO - 2018-10-25 14:00:33 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:00:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:00:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:00:33 --> User Agent Class Initialized
INFO - 2018-10-25 14:00:33 --> Controller Class Initialized
INFO - 2018-10-25 14:00:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:00:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:00:33 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:00:33 --> Pixel_Model class loaded
INFO - 2018-10-25 14:00:33 --> Database Driver Class Initialized
INFO - 2018-10-25 14:00:33 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:00:33 --> Database Driver Class Initialized
INFO - 2018-10-25 14:00:33 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:00:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-25 14:00:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-25 14:00:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-25 14:00:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-25 14:00:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-25 14:00:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-25 14:00:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/home_value.php
INFO - 2018-10-25 14:00:33 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-25 14:00:33 --> Final output sent to browser
DEBUG - 2018-10-25 14:00:33 --> Total execution time: 0.3441
INFO - 2018-10-25 14:00:36 --> Config Class Initialized
INFO - 2018-10-25 14:00:36 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:00:36 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:00:36 --> Utf8 Class Initialized
INFO - 2018-10-25 14:00:36 --> URI Class Initialized
INFO - 2018-10-25 14:00:36 --> Router Class Initialized
INFO - 2018-10-25 14:00:36 --> Output Class Initialized
INFO - 2018-10-25 14:00:37 --> Security Class Initialized
DEBUG - 2018-10-25 14:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:00:37 --> CSRF cookie sent
INFO - 2018-10-25 14:00:37 --> CSRF token verified
INFO - 2018-10-25 14:00:37 --> Input Class Initialized
INFO - 2018-10-25 14:00:37 --> Language Class Initialized
INFO - 2018-10-25 14:00:37 --> Loader Class Initialized
INFO - 2018-10-25 14:00:37 --> Helper loaded: url_helper
INFO - 2018-10-25 14:00:37 --> Helper loaded: form_helper
INFO - 2018-10-25 14:00:37 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:00:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:00:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:00:37 --> User Agent Class Initialized
INFO - 2018-10-25 14:00:37 --> Controller Class Initialized
INFO - 2018-10-25 14:00:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:00:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:00:37 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:00:37 --> Pixel_Model class loaded
INFO - 2018-10-25 14:00:37 --> Database Driver Class Initialized
INFO - 2018-10-25 14:00:37 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:00:37 --> Form Validation Class Initialized
INFO - 2018-10-25 14:00:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-25 14:00:37 --> Database Driver Class Initialized
INFO - 2018-10-25 14:00:37 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:00:37 --> Config Class Initialized
INFO - 2018-10-25 14:00:37 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:00:37 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:00:37 --> Utf8 Class Initialized
INFO - 2018-10-25 14:00:37 --> URI Class Initialized
INFO - 2018-10-25 14:00:37 --> Router Class Initialized
INFO - 2018-10-25 14:00:37 --> Output Class Initialized
INFO - 2018-10-25 14:00:37 --> Security Class Initialized
DEBUG - 2018-10-25 14:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:00:37 --> CSRF cookie sent
INFO - 2018-10-25 14:00:37 --> Input Class Initialized
INFO - 2018-10-25 14:00:37 --> Language Class Initialized
INFO - 2018-10-25 14:00:37 --> Loader Class Initialized
INFO - 2018-10-25 14:00:37 --> Helper loaded: url_helper
INFO - 2018-10-25 14:00:37 --> Helper loaded: form_helper
INFO - 2018-10-25 14:00:37 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:00:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:00:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:00:37 --> User Agent Class Initialized
INFO - 2018-10-25 14:00:37 --> Controller Class Initialized
INFO - 2018-10-25 14:00:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:00:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:00:37 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:00:37 --> Pixel_Model class loaded
INFO - 2018-10-25 14:00:37 --> Database Driver Class Initialized
INFO - 2018-10-25 14:00:37 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:00:37 --> Database Driver Class Initialized
INFO - 2018-10-25 14:00:37 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:00:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-25 14:00:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-25 14:00:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-25 14:00:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-25 14:00:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-25 14:00:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-25 14:00:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/merriage_home_title.php
INFO - 2018-10-25 14:00:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-25 14:00:37 --> Final output sent to browser
DEBUG - 2018-10-25 14:00:37 --> Total execution time: 0.3459
INFO - 2018-10-25 14:00:39 --> Config Class Initialized
INFO - 2018-10-25 14:00:39 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:00:39 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:00:39 --> Utf8 Class Initialized
INFO - 2018-10-25 14:00:39 --> URI Class Initialized
INFO - 2018-10-25 14:00:39 --> Router Class Initialized
INFO - 2018-10-25 14:00:39 --> Output Class Initialized
INFO - 2018-10-25 14:00:39 --> Security Class Initialized
DEBUG - 2018-10-25 14:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:00:39 --> CSRF cookie sent
INFO - 2018-10-25 14:00:39 --> CSRF token verified
INFO - 2018-10-25 14:00:39 --> Input Class Initialized
INFO - 2018-10-25 14:00:39 --> Language Class Initialized
INFO - 2018-10-25 14:00:39 --> Loader Class Initialized
INFO - 2018-10-25 14:00:39 --> Helper loaded: url_helper
INFO - 2018-10-25 14:00:39 --> Helper loaded: form_helper
INFO - 2018-10-25 14:00:39 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:00:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:00:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:00:39 --> User Agent Class Initialized
INFO - 2018-10-25 14:00:39 --> Controller Class Initialized
INFO - 2018-10-25 14:00:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:00:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:00:39 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:00:39 --> Pixel_Model class loaded
INFO - 2018-10-25 14:00:39 --> Database Driver Class Initialized
INFO - 2018-10-25 14:00:39 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:00:39 --> Form Validation Class Initialized
INFO - 2018-10-25 14:00:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-25 14:00:39 --> Database Driver Class Initialized
INFO - 2018-10-25 14:00:39 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:00:39 --> Config Class Initialized
INFO - 2018-10-25 14:00:39 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:00:39 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:00:39 --> Utf8 Class Initialized
INFO - 2018-10-25 14:00:39 --> URI Class Initialized
INFO - 2018-10-25 14:00:39 --> Router Class Initialized
INFO - 2018-10-25 14:00:39 --> Output Class Initialized
INFO - 2018-10-25 14:00:39 --> Security Class Initialized
DEBUG - 2018-10-25 14:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:00:39 --> CSRF cookie sent
INFO - 2018-10-25 14:00:39 --> Input Class Initialized
INFO - 2018-10-25 14:00:39 --> Language Class Initialized
INFO - 2018-10-25 14:00:39 --> Loader Class Initialized
INFO - 2018-10-25 14:00:39 --> Helper loaded: url_helper
INFO - 2018-10-25 14:00:39 --> Helper loaded: form_helper
INFO - 2018-10-25 14:00:39 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:00:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:00:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:00:39 --> User Agent Class Initialized
INFO - 2018-10-25 14:00:39 --> Controller Class Initialized
INFO - 2018-10-25 14:00:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:00:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:00:39 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:00:39 --> Pixel_Model class loaded
INFO - 2018-10-25 14:00:39 --> Database Driver Class Initialized
INFO - 2018-10-25 14:00:39 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:00:39 --> Database Driver Class Initialized
INFO - 2018-10-25 14:00:39 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:00:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-25 14:00:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-25 14:00:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-25 14:00:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-25 14:00:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-25 14:00:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-25 14:00:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/financial.php
INFO - 2018-10-25 14:00:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-25 14:00:39 --> Final output sent to browser
DEBUG - 2018-10-25 14:00:39 --> Total execution time: 0.3647
INFO - 2018-10-25 14:00:41 --> Config Class Initialized
INFO - 2018-10-25 14:00:41 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:00:41 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:00:41 --> Utf8 Class Initialized
INFO - 2018-10-25 14:00:41 --> URI Class Initialized
INFO - 2018-10-25 14:00:41 --> Router Class Initialized
INFO - 2018-10-25 14:00:41 --> Output Class Initialized
INFO - 2018-10-25 14:00:41 --> Security Class Initialized
DEBUG - 2018-10-25 14:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:00:41 --> CSRF cookie sent
INFO - 2018-10-25 14:00:41 --> CSRF token verified
INFO - 2018-10-25 14:00:41 --> Input Class Initialized
INFO - 2018-10-25 14:00:41 --> Language Class Initialized
INFO - 2018-10-25 14:00:41 --> Loader Class Initialized
INFO - 2018-10-25 14:00:41 --> Helper loaded: url_helper
INFO - 2018-10-25 14:00:41 --> Helper loaded: form_helper
INFO - 2018-10-25 14:00:41 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:00:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:00:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:00:41 --> User Agent Class Initialized
INFO - 2018-10-25 14:00:41 --> Controller Class Initialized
INFO - 2018-10-25 14:00:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:00:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:00:41 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:00:41 --> Pixel_Model class loaded
INFO - 2018-10-25 14:00:41 --> Database Driver Class Initialized
INFO - 2018-10-25 14:00:41 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:00:41 --> Form Validation Class Initialized
INFO - 2018-10-25 14:00:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-25 14:00:41 --> Database Driver Class Initialized
INFO - 2018-10-25 14:00:41 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:00:41 --> Config Class Initialized
INFO - 2018-10-25 14:00:41 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:00:41 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:00:41 --> Utf8 Class Initialized
INFO - 2018-10-25 14:00:41 --> URI Class Initialized
INFO - 2018-10-25 14:00:41 --> Router Class Initialized
INFO - 2018-10-25 14:00:41 --> Output Class Initialized
INFO - 2018-10-25 14:00:41 --> Security Class Initialized
DEBUG - 2018-10-25 14:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:00:41 --> CSRF cookie sent
INFO - 2018-10-25 14:00:41 --> Input Class Initialized
INFO - 2018-10-25 14:00:41 --> Language Class Initialized
INFO - 2018-10-25 14:00:41 --> Loader Class Initialized
INFO - 2018-10-25 14:00:41 --> Helper loaded: url_helper
INFO - 2018-10-25 14:00:41 --> Helper loaded: form_helper
INFO - 2018-10-25 14:00:41 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:00:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:00:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:00:41 --> User Agent Class Initialized
INFO - 2018-10-25 14:00:41 --> Controller Class Initialized
INFO - 2018-10-25 14:00:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:00:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:00:41 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:00:41 --> Pixel_Model class loaded
INFO - 2018-10-25 14:00:41 --> Database Driver Class Initialized
INFO - 2018-10-25 14:00:41 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:00:41 --> Database Driver Class Initialized
INFO - 2018-10-25 14:00:41 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:00:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-25 14:00:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-25 14:00:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-25 14:00:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-25 14:00:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/risk_report.php
INFO - 2018-10-25 14:00:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-25 14:00:41 --> Final output sent to browser
DEBUG - 2018-10-25 14:00:41 --> Total execution time: 0.3244
INFO - 2018-10-25 14:00:43 --> Config Class Initialized
INFO - 2018-10-25 14:00:43 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:00:43 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:00:43 --> Utf8 Class Initialized
INFO - 2018-10-25 14:00:43 --> URI Class Initialized
INFO - 2018-10-25 14:00:43 --> Router Class Initialized
INFO - 2018-10-25 14:00:43 --> Output Class Initialized
INFO - 2018-10-25 14:00:43 --> Security Class Initialized
DEBUG - 2018-10-25 14:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:00:43 --> CSRF cookie sent
INFO - 2018-10-25 14:00:43 --> Input Class Initialized
INFO - 2018-10-25 14:00:43 --> Language Class Initialized
INFO - 2018-10-25 14:00:43 --> Loader Class Initialized
INFO - 2018-10-25 14:00:43 --> Helper loaded: url_helper
INFO - 2018-10-25 14:00:43 --> Helper loaded: form_helper
INFO - 2018-10-25 14:00:43 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:00:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:00:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:00:43 --> User Agent Class Initialized
INFO - 2018-10-25 14:00:43 --> Controller Class Initialized
INFO - 2018-10-25 14:00:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:00:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:00:43 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:00:43 --> Pixel_Model class loaded
INFO - 2018-10-25 14:00:43 --> Database Driver Class Initialized
INFO - 2018-10-25 14:00:43 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:00:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-25 14:00:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-25 14:00:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-25 14:00:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-25 14:00:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-25 14:00:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-25 14:00:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-25 14:00:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-25 14:00:43 --> Final output sent to browser
DEBUG - 2018-10-25 14:00:43 --> Total execution time: 0.3609
INFO - 2018-10-25 14:00:45 --> Config Class Initialized
INFO - 2018-10-25 14:00:45 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:00:45 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:00:45 --> Utf8 Class Initialized
INFO - 2018-10-25 14:00:45 --> URI Class Initialized
INFO - 2018-10-25 14:00:45 --> Router Class Initialized
INFO - 2018-10-25 14:00:45 --> Output Class Initialized
INFO - 2018-10-25 14:00:45 --> Security Class Initialized
DEBUG - 2018-10-25 14:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:00:45 --> CSRF cookie sent
INFO - 2018-10-25 14:00:45 --> CSRF token verified
INFO - 2018-10-25 14:00:45 --> Input Class Initialized
INFO - 2018-10-25 14:00:45 --> Language Class Initialized
INFO - 2018-10-25 14:00:45 --> Loader Class Initialized
INFO - 2018-10-25 14:00:46 --> Helper loaded: url_helper
INFO - 2018-10-25 14:00:46 --> Helper loaded: form_helper
INFO - 2018-10-25 14:00:46 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:00:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:00:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:00:46 --> User Agent Class Initialized
INFO - 2018-10-25 14:00:46 --> Controller Class Initialized
INFO - 2018-10-25 14:00:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:00:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:00:46 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:00:46 --> Pixel_Model class loaded
INFO - 2018-10-25 14:00:46 --> Database Driver Class Initialized
INFO - 2018-10-25 14:00:46 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:00:46 --> Database Driver Class Initialized
INFO - 2018-10-25 14:00:46 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:00:46 --> Config Class Initialized
INFO - 2018-10-25 14:00:46 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:00:46 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:00:46 --> Utf8 Class Initialized
INFO - 2018-10-25 14:00:46 --> URI Class Initialized
INFO - 2018-10-25 14:00:46 --> Router Class Initialized
INFO - 2018-10-25 14:00:46 --> Output Class Initialized
INFO - 2018-10-25 14:00:46 --> Security Class Initialized
DEBUG - 2018-10-25 14:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:00:46 --> CSRF cookie sent
INFO - 2018-10-25 14:00:46 --> Input Class Initialized
INFO - 2018-10-25 14:00:46 --> Language Class Initialized
INFO - 2018-10-25 14:00:46 --> Loader Class Initialized
INFO - 2018-10-25 14:00:46 --> Helper loaded: url_helper
INFO - 2018-10-25 14:00:46 --> Helper loaded: form_helper
INFO - 2018-10-25 14:00:46 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:00:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:00:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:00:46 --> User Agent Class Initialized
INFO - 2018-10-25 14:00:46 --> Controller Class Initialized
INFO - 2018-10-25 14:00:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:00:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:00:46 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:00:46 --> Pixel_Model class loaded
INFO - 2018-10-25 14:00:46 --> Database Driver Class Initialized
INFO - 2018-10-25 14:00:46 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:00:46 --> Config Class Initialized
INFO - 2018-10-25 14:00:46 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:00:46 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:00:46 --> Utf8 Class Initialized
INFO - 2018-10-25 14:00:46 --> URI Class Initialized
INFO - 2018-10-25 14:00:46 --> Router Class Initialized
INFO - 2018-10-25 14:00:46 --> Output Class Initialized
INFO - 2018-10-25 14:00:46 --> Security Class Initialized
DEBUG - 2018-10-25 14:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:00:46 --> CSRF cookie sent
INFO - 2018-10-25 14:00:46 --> Input Class Initialized
INFO - 2018-10-25 14:00:46 --> Language Class Initialized
INFO - 2018-10-25 14:00:46 --> Loader Class Initialized
INFO - 2018-10-25 14:00:46 --> Helper loaded: url_helper
INFO - 2018-10-25 14:00:46 --> Helper loaded: form_helper
INFO - 2018-10-25 14:00:46 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:00:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:00:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:00:46 --> User Agent Class Initialized
INFO - 2018-10-25 14:00:46 --> Controller Class Initialized
INFO - 2018-10-25 14:00:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:00:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:00:46 --> Helper loaded: custom_helper
DEBUG - 2018-10-25 14:00:46 --> Config file loaded: E:\xampp7\htdocs\famiquity\application\config/recaptcha.php
INFO - 2018-10-25 14:00:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-25 14:00:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-25 14:00:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-25 14:00:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
ERROR - 2018-10-25 14:00:46 --> Could not find the language line "req_email"
INFO - 2018-10-25 14:00:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\myaccount/signin.php
INFO - 2018-10-25 14:00:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-25 14:00:46 --> Final output sent to browser
DEBUG - 2018-10-25 14:00:46 --> Total execution time: 0.2822
INFO - 2018-10-25 14:00:48 --> Config Class Initialized
INFO - 2018-10-25 14:00:48 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:00:48 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:00:48 --> Utf8 Class Initialized
INFO - 2018-10-25 14:00:48 --> URI Class Initialized
INFO - 2018-10-25 14:00:48 --> Router Class Initialized
INFO - 2018-10-25 14:00:48 --> Output Class Initialized
INFO - 2018-10-25 14:00:48 --> Security Class Initialized
DEBUG - 2018-10-25 14:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:00:48 --> CSRF cookie sent
INFO - 2018-10-25 14:00:48 --> Input Class Initialized
INFO - 2018-10-25 14:00:48 --> Language Class Initialized
INFO - 2018-10-25 14:00:48 --> Loader Class Initialized
INFO - 2018-10-25 14:00:48 --> Helper loaded: url_helper
INFO - 2018-10-25 14:00:48 --> Helper loaded: form_helper
INFO - 2018-10-25 14:00:48 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:00:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:00:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:00:48 --> User Agent Class Initialized
INFO - 2018-10-25 14:00:48 --> Controller Class Initialized
INFO - 2018-10-25 14:00:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:00:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:00:48 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:00:48 --> Pixel_Model class loaded
INFO - 2018-10-25 14:00:48 --> Database Driver Class Initialized
INFO - 2018-10-25 14:00:48 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:00:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-25 14:00:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-25 14:00:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-25 14:00:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-25 14:00:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-25 14:00:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-25 14:00:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-25 14:00:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-25 14:00:48 --> Final output sent to browser
DEBUG - 2018-10-25 14:00:48 --> Total execution time: 0.3569
INFO - 2018-10-25 14:04:14 --> Config Class Initialized
INFO - 2018-10-25 14:04:14 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:04:14 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:04:14 --> Utf8 Class Initialized
INFO - 2018-10-25 14:04:14 --> URI Class Initialized
INFO - 2018-10-25 14:04:14 --> Router Class Initialized
INFO - 2018-10-25 14:04:14 --> Output Class Initialized
INFO - 2018-10-25 14:04:14 --> Security Class Initialized
DEBUG - 2018-10-25 14:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:04:14 --> CSRF cookie sent
INFO - 2018-10-25 14:04:14 --> Input Class Initialized
INFO - 2018-10-25 14:04:14 --> Language Class Initialized
INFO - 2018-10-25 14:04:15 --> Loader Class Initialized
INFO - 2018-10-25 14:04:15 --> Helper loaded: url_helper
INFO - 2018-10-25 14:04:15 --> Helper loaded: form_helper
INFO - 2018-10-25 14:04:15 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:04:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:04:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:04:15 --> User Agent Class Initialized
INFO - 2018-10-25 14:04:15 --> Controller Class Initialized
INFO - 2018-10-25 14:04:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:04:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:04:15 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:04:15 --> Pixel_Model class loaded
INFO - 2018-10-25 14:04:15 --> Database Driver Class Initialized
INFO - 2018-10-25 14:04:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:04:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-25 14:04:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-25 14:04:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-25 14:04:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-25 14:04:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-25 14:04:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-25 14:04:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-25 14:04:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-25 14:04:15 --> Final output sent to browser
DEBUG - 2018-10-25 14:04:15 --> Total execution time: 0.3608
INFO - 2018-10-25 14:04:18 --> Config Class Initialized
INFO - 2018-10-25 14:04:18 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:04:18 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:04:18 --> Utf8 Class Initialized
INFO - 2018-10-25 14:04:18 --> URI Class Initialized
INFO - 2018-10-25 14:04:18 --> Router Class Initialized
INFO - 2018-10-25 14:04:18 --> Output Class Initialized
INFO - 2018-10-25 14:04:18 --> Security Class Initialized
DEBUG - 2018-10-25 14:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:04:18 --> CSRF cookie sent
INFO - 2018-10-25 14:04:18 --> CSRF token verified
INFO - 2018-10-25 14:04:18 --> Input Class Initialized
INFO - 2018-10-25 14:04:18 --> Language Class Initialized
INFO - 2018-10-25 14:04:18 --> Loader Class Initialized
INFO - 2018-10-25 14:04:18 --> Helper loaded: url_helper
INFO - 2018-10-25 14:04:18 --> Helper loaded: form_helper
INFO - 2018-10-25 14:04:18 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:04:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:04:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:04:18 --> User Agent Class Initialized
INFO - 2018-10-25 14:04:18 --> Controller Class Initialized
INFO - 2018-10-25 14:04:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:04:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:04:18 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:04:18 --> Pixel_Model class loaded
INFO - 2018-10-25 14:04:18 --> Database Driver Class Initialized
INFO - 2018-10-25 14:04:18 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:05:09 --> Config Class Initialized
INFO - 2018-10-25 14:05:09 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:05:09 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:05:09 --> Utf8 Class Initialized
INFO - 2018-10-25 14:05:09 --> URI Class Initialized
INFO - 2018-10-25 14:05:09 --> Router Class Initialized
INFO - 2018-10-25 14:05:09 --> Output Class Initialized
INFO - 2018-10-25 14:05:09 --> Security Class Initialized
DEBUG - 2018-10-25 14:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:05:09 --> CSRF cookie sent
INFO - 2018-10-25 14:05:09 --> Input Class Initialized
INFO - 2018-10-25 14:05:09 --> Language Class Initialized
INFO - 2018-10-25 14:05:09 --> Loader Class Initialized
INFO - 2018-10-25 14:05:09 --> Helper loaded: url_helper
INFO - 2018-10-25 14:05:09 --> Helper loaded: form_helper
INFO - 2018-10-25 14:05:09 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:05:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:05:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:05:09 --> User Agent Class Initialized
INFO - 2018-10-25 14:05:09 --> Controller Class Initialized
INFO - 2018-10-25 14:05:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:05:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:05:09 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:05:09 --> Pixel_Model class loaded
INFO - 2018-10-25 14:05:09 --> Database Driver Class Initialized
INFO - 2018-10-25 14:05:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:05:09 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-25 14:05:09 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-25 14:05:09 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-25 14:05:09 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-25 14:05:09 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-25 14:05:09 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-25 14:05:09 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-25 14:05:09 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-25 14:05:09 --> Final output sent to browser
DEBUG - 2018-10-25 14:05:09 --> Total execution time: 0.3522
INFO - 2018-10-25 14:05:10 --> Config Class Initialized
INFO - 2018-10-25 14:05:10 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:05:10 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:05:10 --> Utf8 Class Initialized
INFO - 2018-10-25 14:05:10 --> URI Class Initialized
INFO - 2018-10-25 14:05:10 --> Router Class Initialized
INFO - 2018-10-25 14:05:10 --> Output Class Initialized
INFO - 2018-10-25 14:05:10 --> Security Class Initialized
DEBUG - 2018-10-25 14:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:05:10 --> CSRF cookie sent
INFO - 2018-10-25 14:05:10 --> Input Class Initialized
INFO - 2018-10-25 14:05:10 --> Language Class Initialized
INFO - 2018-10-25 14:05:10 --> Loader Class Initialized
INFO - 2018-10-25 14:05:10 --> Helper loaded: url_helper
INFO - 2018-10-25 14:05:10 --> Helper loaded: form_helper
INFO - 2018-10-25 14:05:10 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:05:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:05:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:05:10 --> User Agent Class Initialized
INFO - 2018-10-25 14:05:10 --> Controller Class Initialized
INFO - 2018-10-25 14:05:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:05:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:05:10 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:05:10 --> Pixel_Model class loaded
INFO - 2018-10-25 14:05:10 --> Database Driver Class Initialized
INFO - 2018-10-25 14:05:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:05:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-25 14:05:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-25 14:05:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-25 14:05:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-25 14:05:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-25 14:05:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-25 14:05:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-25 14:05:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-25 14:05:10 --> Final output sent to browser
DEBUG - 2018-10-25 14:05:10 --> Total execution time: 0.3823
INFO - 2018-10-25 14:05:13 --> Config Class Initialized
INFO - 2018-10-25 14:05:13 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:05:13 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:05:13 --> Utf8 Class Initialized
INFO - 2018-10-25 14:05:13 --> URI Class Initialized
INFO - 2018-10-25 14:05:13 --> Router Class Initialized
INFO - 2018-10-25 14:05:13 --> Output Class Initialized
INFO - 2018-10-25 14:05:13 --> Security Class Initialized
DEBUG - 2018-10-25 14:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:05:14 --> CSRF cookie sent
INFO - 2018-10-25 14:05:14 --> CSRF token verified
INFO - 2018-10-25 14:05:14 --> Input Class Initialized
INFO - 2018-10-25 14:05:14 --> Language Class Initialized
INFO - 2018-10-25 14:05:14 --> Loader Class Initialized
INFO - 2018-10-25 14:05:14 --> Helper loaded: url_helper
INFO - 2018-10-25 14:05:14 --> Helper loaded: form_helper
INFO - 2018-10-25 14:05:14 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:05:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:05:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:05:14 --> User Agent Class Initialized
INFO - 2018-10-25 14:05:14 --> Controller Class Initialized
INFO - 2018-10-25 14:05:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:05:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:05:14 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:05:14 --> Pixel_Model class loaded
INFO - 2018-10-25 14:05:14 --> Database Driver Class Initialized
INFO - 2018-10-25 14:05:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:05:14 --> Database Driver Class Initialized
INFO - 2018-10-25 14:05:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:05:49 --> Config Class Initialized
INFO - 2018-10-25 14:05:49 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:05:49 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:05:49 --> Utf8 Class Initialized
INFO - 2018-10-25 14:05:49 --> URI Class Initialized
INFO - 2018-10-25 14:05:49 --> Router Class Initialized
INFO - 2018-10-25 14:05:49 --> Output Class Initialized
INFO - 2018-10-25 14:05:49 --> Security Class Initialized
DEBUG - 2018-10-25 14:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:05:49 --> CSRF cookie sent
INFO - 2018-10-25 14:05:49 --> Input Class Initialized
INFO - 2018-10-25 14:05:49 --> Language Class Initialized
INFO - 2018-10-25 14:05:49 --> Loader Class Initialized
INFO - 2018-10-25 14:05:49 --> Helper loaded: url_helper
INFO - 2018-10-25 14:05:49 --> Helper loaded: form_helper
INFO - 2018-10-25 14:05:49 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:05:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:05:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:05:49 --> User Agent Class Initialized
INFO - 2018-10-25 14:05:49 --> Controller Class Initialized
INFO - 2018-10-25 14:05:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:05:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:05:49 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:05:49 --> Pixel_Model class loaded
INFO - 2018-10-25 14:05:49 --> Database Driver Class Initialized
INFO - 2018-10-25 14:05:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:05:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-25 14:05:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-25 14:05:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-25 14:05:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-25 14:05:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-25 14:05:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-25 14:05:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-25 14:05:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-25 14:05:49 --> Final output sent to browser
DEBUG - 2018-10-25 14:05:49 --> Total execution time: 0.3769
INFO - 2018-10-25 14:05:51 --> Config Class Initialized
INFO - 2018-10-25 14:05:51 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:05:51 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:05:51 --> Utf8 Class Initialized
INFO - 2018-10-25 14:05:51 --> URI Class Initialized
INFO - 2018-10-25 14:05:51 --> Router Class Initialized
INFO - 2018-10-25 14:05:51 --> Output Class Initialized
INFO - 2018-10-25 14:05:51 --> Security Class Initialized
DEBUG - 2018-10-25 14:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:05:51 --> CSRF cookie sent
INFO - 2018-10-25 14:05:51 --> Input Class Initialized
INFO - 2018-10-25 14:05:51 --> Language Class Initialized
INFO - 2018-10-25 14:05:51 --> Loader Class Initialized
INFO - 2018-10-25 14:05:51 --> Helper loaded: url_helper
INFO - 2018-10-25 14:05:51 --> Helper loaded: form_helper
INFO - 2018-10-25 14:05:51 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:05:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:05:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:05:51 --> User Agent Class Initialized
INFO - 2018-10-25 14:05:51 --> Controller Class Initialized
INFO - 2018-10-25 14:05:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:05:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:05:51 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:05:51 --> Pixel_Model class loaded
INFO - 2018-10-25 14:05:51 --> Database Driver Class Initialized
INFO - 2018-10-25 14:05:51 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:05:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-25 14:05:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-25 14:05:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-25 14:05:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-25 14:05:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-25 14:05:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-25 14:05:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-25 14:05:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-25 14:05:51 --> Final output sent to browser
DEBUG - 2018-10-25 14:05:51 --> Total execution time: 0.3874
INFO - 2018-10-25 14:05:53 --> Config Class Initialized
INFO - 2018-10-25 14:05:53 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:05:53 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:05:53 --> Utf8 Class Initialized
INFO - 2018-10-25 14:05:53 --> URI Class Initialized
INFO - 2018-10-25 14:05:53 --> Router Class Initialized
INFO - 2018-10-25 14:05:53 --> Output Class Initialized
INFO - 2018-10-25 14:05:53 --> Security Class Initialized
DEBUG - 2018-10-25 14:05:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:05:53 --> CSRF cookie sent
INFO - 2018-10-25 14:05:53 --> CSRF token verified
INFO - 2018-10-25 14:05:53 --> Input Class Initialized
INFO - 2018-10-25 14:05:53 --> Language Class Initialized
INFO - 2018-10-25 14:05:53 --> Loader Class Initialized
INFO - 2018-10-25 14:05:53 --> Helper loaded: url_helper
INFO - 2018-10-25 14:05:53 --> Helper loaded: form_helper
INFO - 2018-10-25 14:05:53 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:05:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:05:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:05:53 --> User Agent Class Initialized
INFO - 2018-10-25 14:05:53 --> Controller Class Initialized
INFO - 2018-10-25 14:05:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:05:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:05:53 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:05:53 --> Pixel_Model class loaded
INFO - 2018-10-25 14:05:53 --> Database Driver Class Initialized
INFO - 2018-10-25 14:05:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:05:53 --> Database Driver Class Initialized
INFO - 2018-10-25 14:05:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:05:54 --> Config Class Initialized
INFO - 2018-10-25 14:05:54 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:05:54 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:05:54 --> Utf8 Class Initialized
INFO - 2018-10-25 14:05:54 --> URI Class Initialized
INFO - 2018-10-25 14:05:54 --> Router Class Initialized
INFO - 2018-10-25 14:05:54 --> Output Class Initialized
INFO - 2018-10-25 14:05:54 --> Security Class Initialized
DEBUG - 2018-10-25 14:05:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:05:54 --> CSRF cookie sent
INFO - 2018-10-25 14:05:54 --> Input Class Initialized
INFO - 2018-10-25 14:05:54 --> Language Class Initialized
INFO - 2018-10-25 14:05:54 --> Loader Class Initialized
INFO - 2018-10-25 14:05:54 --> Helper loaded: url_helper
INFO - 2018-10-25 14:05:54 --> Helper loaded: form_helper
INFO - 2018-10-25 14:05:54 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:05:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:05:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:05:54 --> User Agent Class Initialized
INFO - 2018-10-25 14:05:54 --> Controller Class Initialized
INFO - 2018-10-25 14:05:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:05:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:05:54 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:05:54 --> Pixel_Model class loaded
INFO - 2018-10-25 14:05:54 --> Database Driver Class Initialized
INFO - 2018-10-25 14:05:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:05:54 --> Config Class Initialized
INFO - 2018-10-25 14:05:54 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:05:54 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:05:54 --> Utf8 Class Initialized
INFO - 2018-10-25 14:05:54 --> URI Class Initialized
INFO - 2018-10-25 14:05:54 --> Router Class Initialized
INFO - 2018-10-25 14:05:54 --> Output Class Initialized
INFO - 2018-10-25 14:05:54 --> Security Class Initialized
DEBUG - 2018-10-25 14:05:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:05:54 --> CSRF cookie sent
INFO - 2018-10-25 14:05:54 --> Input Class Initialized
INFO - 2018-10-25 14:05:54 --> Language Class Initialized
INFO - 2018-10-25 14:05:54 --> Loader Class Initialized
INFO - 2018-10-25 14:05:54 --> Helper loaded: url_helper
INFO - 2018-10-25 14:05:54 --> Helper loaded: form_helper
INFO - 2018-10-25 14:05:54 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:05:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:05:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:05:54 --> User Agent Class Initialized
INFO - 2018-10-25 14:05:54 --> Controller Class Initialized
INFO - 2018-10-25 14:05:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:05:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:05:54 --> Helper loaded: custom_helper
DEBUG - 2018-10-25 14:05:54 --> Config file loaded: E:\xampp7\htdocs\famiquity\application\config/recaptcha.php
INFO - 2018-10-25 14:05:54 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-25 14:05:54 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-25 14:05:54 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-25 14:05:54 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
ERROR - 2018-10-25 14:05:54 --> Could not find the language line "req_email"
INFO - 2018-10-25 14:05:54 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\myaccount/signin.php
INFO - 2018-10-25 14:05:54 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-25 14:05:54 --> Final output sent to browser
DEBUG - 2018-10-25 14:05:54 --> Total execution time: 0.2963
INFO - 2018-10-25 14:06:10 --> Config Class Initialized
INFO - 2018-10-25 14:06:10 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:06:10 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:06:10 --> Utf8 Class Initialized
INFO - 2018-10-25 14:06:10 --> URI Class Initialized
INFO - 2018-10-25 14:06:10 --> Router Class Initialized
INFO - 2018-10-25 14:06:10 --> Output Class Initialized
INFO - 2018-10-25 14:06:10 --> Security Class Initialized
DEBUG - 2018-10-25 14:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:06:10 --> CSRF cookie sent
INFO - 2018-10-25 14:06:10 --> Input Class Initialized
INFO - 2018-10-25 14:06:10 --> Language Class Initialized
INFO - 2018-10-25 14:06:11 --> Loader Class Initialized
INFO - 2018-10-25 14:06:11 --> Helper loaded: url_helper
INFO - 2018-10-25 14:06:11 --> Helper loaded: form_helper
INFO - 2018-10-25 14:06:11 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:06:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:06:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:06:11 --> User Agent Class Initialized
INFO - 2018-10-25 14:06:11 --> Controller Class Initialized
INFO - 2018-10-25 14:06:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:06:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:06:11 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:06:11 --> Pixel_Model class loaded
INFO - 2018-10-25 14:06:11 --> Database Driver Class Initialized
INFO - 2018-10-25 14:06:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:06:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-25 14:06:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-25 14:06:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-25 14:06:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-25 14:06:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-25 14:06:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-25 14:06:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-25 14:06:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-25 14:06:11 --> Final output sent to browser
DEBUG - 2018-10-25 14:06:11 --> Total execution time: 0.3612
INFO - 2018-10-25 14:06:35 --> Config Class Initialized
INFO - 2018-10-25 14:06:35 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:06:35 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:06:35 --> Utf8 Class Initialized
INFO - 2018-10-25 14:06:35 --> URI Class Initialized
INFO - 2018-10-25 14:06:35 --> Router Class Initialized
INFO - 2018-10-25 14:06:35 --> Output Class Initialized
INFO - 2018-10-25 14:06:35 --> Security Class Initialized
DEBUG - 2018-10-25 14:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:06:35 --> CSRF cookie sent
INFO - 2018-10-25 14:06:35 --> Input Class Initialized
INFO - 2018-10-25 14:06:35 --> Language Class Initialized
INFO - 2018-10-25 14:06:35 --> Loader Class Initialized
INFO - 2018-10-25 14:06:35 --> Helper loaded: url_helper
INFO - 2018-10-25 14:06:35 --> Helper loaded: form_helper
INFO - 2018-10-25 14:06:35 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:06:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:06:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:06:35 --> User Agent Class Initialized
INFO - 2018-10-25 14:06:35 --> Controller Class Initialized
INFO - 2018-10-25 14:06:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:06:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:06:35 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:06:35 --> Pixel_Model class loaded
INFO - 2018-10-25 14:06:35 --> Database Driver Class Initialized
INFO - 2018-10-25 14:06:35 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:06:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-25 14:06:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-25 14:06:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-25 14:06:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-25 14:06:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-25 14:06:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-25 14:06:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-25 14:06:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-25 14:06:36 --> Final output sent to browser
DEBUG - 2018-10-25 14:06:36 --> Total execution time: 0.3555
INFO - 2018-10-25 14:06:38 --> Config Class Initialized
INFO - 2018-10-25 14:06:38 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:06:38 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:06:38 --> Utf8 Class Initialized
INFO - 2018-10-25 14:06:38 --> URI Class Initialized
INFO - 2018-10-25 14:06:38 --> Router Class Initialized
INFO - 2018-10-25 14:06:38 --> Output Class Initialized
INFO - 2018-10-25 14:06:38 --> Security Class Initialized
DEBUG - 2018-10-25 14:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:06:38 --> CSRF cookie sent
INFO - 2018-10-25 14:06:38 --> CSRF token verified
INFO - 2018-10-25 14:06:38 --> Input Class Initialized
INFO - 2018-10-25 14:06:38 --> Language Class Initialized
INFO - 2018-10-25 14:06:38 --> Loader Class Initialized
INFO - 2018-10-25 14:06:38 --> Helper loaded: url_helper
INFO - 2018-10-25 14:06:38 --> Helper loaded: form_helper
INFO - 2018-10-25 14:06:38 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:06:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:06:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:06:38 --> User Agent Class Initialized
INFO - 2018-10-25 14:06:38 --> Controller Class Initialized
INFO - 2018-10-25 14:06:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:06:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:06:38 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:06:38 --> Pixel_Model class loaded
INFO - 2018-10-25 14:06:38 --> Database Driver Class Initialized
INFO - 2018-10-25 14:06:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:06:38 --> Database Driver Class Initialized
INFO - 2018-10-25 14:06:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:06:49 --> Config Class Initialized
INFO - 2018-10-25 14:06:49 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:06:49 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:06:49 --> Utf8 Class Initialized
INFO - 2018-10-25 14:06:49 --> URI Class Initialized
INFO - 2018-10-25 14:06:49 --> Router Class Initialized
INFO - 2018-10-25 14:06:49 --> Output Class Initialized
INFO - 2018-10-25 14:06:49 --> Security Class Initialized
DEBUG - 2018-10-25 14:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:06:49 --> CSRF cookie sent
INFO - 2018-10-25 14:06:49 --> Input Class Initialized
INFO - 2018-10-25 14:06:49 --> Language Class Initialized
INFO - 2018-10-25 14:06:49 --> Loader Class Initialized
INFO - 2018-10-25 14:06:49 --> Helper loaded: url_helper
INFO - 2018-10-25 14:06:49 --> Helper loaded: form_helper
INFO - 2018-10-25 14:06:49 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:06:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:06:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:06:49 --> User Agent Class Initialized
INFO - 2018-10-25 14:06:49 --> Controller Class Initialized
INFO - 2018-10-25 14:06:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:06:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:06:49 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:06:49 --> Pixel_Model class loaded
INFO - 2018-10-25 14:06:49 --> Database Driver Class Initialized
INFO - 2018-10-25 14:06:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:06:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-25 14:06:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-25 14:06:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-25 14:06:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-25 14:06:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-25 14:06:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-25 14:06:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-25 14:06:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-25 14:06:49 --> Final output sent to browser
DEBUG - 2018-10-25 14:06:49 --> Total execution time: 0.3541
INFO - 2018-10-25 14:06:51 --> Config Class Initialized
INFO - 2018-10-25 14:06:51 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:06:51 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:06:51 --> Utf8 Class Initialized
INFO - 2018-10-25 14:06:51 --> URI Class Initialized
INFO - 2018-10-25 14:06:51 --> Router Class Initialized
INFO - 2018-10-25 14:06:51 --> Output Class Initialized
INFO - 2018-10-25 14:06:51 --> Security Class Initialized
DEBUG - 2018-10-25 14:06:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:06:51 --> CSRF cookie sent
INFO - 2018-10-25 14:06:51 --> Input Class Initialized
INFO - 2018-10-25 14:06:51 --> Language Class Initialized
INFO - 2018-10-25 14:06:51 --> Loader Class Initialized
INFO - 2018-10-25 14:06:51 --> Helper loaded: url_helper
INFO - 2018-10-25 14:06:51 --> Helper loaded: form_helper
INFO - 2018-10-25 14:06:51 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:06:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:06:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:06:51 --> User Agent Class Initialized
INFO - 2018-10-25 14:06:51 --> Controller Class Initialized
INFO - 2018-10-25 14:06:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:06:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:06:51 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:06:51 --> Pixel_Model class loaded
INFO - 2018-10-25 14:06:51 --> Database Driver Class Initialized
INFO - 2018-10-25 14:06:51 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:06:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-25 14:06:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-25 14:06:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-25 14:06:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-25 14:06:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-25 14:06:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-25 14:06:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-25 14:06:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-25 14:06:51 --> Final output sent to browser
DEBUG - 2018-10-25 14:06:51 --> Total execution time: 0.3585
INFO - 2018-10-25 14:06:54 --> Config Class Initialized
INFO - 2018-10-25 14:06:54 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:06:54 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:06:54 --> Utf8 Class Initialized
INFO - 2018-10-25 14:06:54 --> URI Class Initialized
INFO - 2018-10-25 14:06:54 --> Router Class Initialized
INFO - 2018-10-25 14:06:54 --> Output Class Initialized
INFO - 2018-10-25 14:06:54 --> Security Class Initialized
DEBUG - 2018-10-25 14:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:06:54 --> CSRF cookie sent
INFO - 2018-10-25 14:06:54 --> CSRF token verified
INFO - 2018-10-25 14:06:54 --> Input Class Initialized
INFO - 2018-10-25 14:06:54 --> Language Class Initialized
INFO - 2018-10-25 14:06:54 --> Loader Class Initialized
INFO - 2018-10-25 14:06:54 --> Helper loaded: url_helper
INFO - 2018-10-25 14:06:54 --> Helper loaded: form_helper
INFO - 2018-10-25 14:06:54 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:06:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:06:54 --> User Agent Class Initialized
INFO - 2018-10-25 14:06:54 --> Controller Class Initialized
INFO - 2018-10-25 14:06:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:06:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:06:54 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:06:54 --> Pixel_Model class loaded
INFO - 2018-10-25 14:06:54 --> Database Driver Class Initialized
INFO - 2018-10-25 14:06:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:06:55 --> Database Driver Class Initialized
INFO - 2018-10-25 14:06:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:06:57 --> Config Class Initialized
INFO - 2018-10-25 14:06:57 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:06:57 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:06:57 --> Utf8 Class Initialized
INFO - 2018-10-25 14:06:57 --> URI Class Initialized
INFO - 2018-10-25 14:06:57 --> Router Class Initialized
INFO - 2018-10-25 14:06:57 --> Output Class Initialized
INFO - 2018-10-25 14:06:57 --> Security Class Initialized
DEBUG - 2018-10-25 14:06:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:06:57 --> CSRF cookie sent
INFO - 2018-10-25 14:06:57 --> Input Class Initialized
INFO - 2018-10-25 14:06:57 --> Language Class Initialized
INFO - 2018-10-25 14:06:57 --> Loader Class Initialized
INFO - 2018-10-25 14:06:57 --> Helper loaded: url_helper
INFO - 2018-10-25 14:06:57 --> Helper loaded: form_helper
INFO - 2018-10-25 14:06:57 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:06:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:06:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:06:57 --> User Agent Class Initialized
INFO - 2018-10-25 14:06:57 --> Controller Class Initialized
INFO - 2018-10-25 14:06:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:06:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:06:57 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:06:57 --> Pixel_Model class loaded
INFO - 2018-10-25 14:06:57 --> Database Driver Class Initialized
INFO - 2018-10-25 14:06:57 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:06:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-25 14:06:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-25 14:06:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-25 14:06:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-25 14:06:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-25 14:06:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-25 14:06:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-25 14:06:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-25 14:06:57 --> Final output sent to browser
DEBUG - 2018-10-25 14:06:57 --> Total execution time: 0.3699
INFO - 2018-10-25 14:07:02 --> Config Class Initialized
INFO - 2018-10-25 14:07:02 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:07:02 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:07:02 --> Utf8 Class Initialized
INFO - 2018-10-25 14:07:02 --> URI Class Initialized
INFO - 2018-10-25 14:07:02 --> Router Class Initialized
INFO - 2018-10-25 14:07:02 --> Output Class Initialized
INFO - 2018-10-25 14:07:02 --> Security Class Initialized
DEBUG - 2018-10-25 14:07:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:07:02 --> CSRF cookie sent
INFO - 2018-10-25 14:07:02 --> CSRF token verified
INFO - 2018-10-25 14:07:02 --> Input Class Initialized
INFO - 2018-10-25 14:07:02 --> Language Class Initialized
INFO - 2018-10-25 14:07:02 --> Loader Class Initialized
INFO - 2018-10-25 14:07:02 --> Helper loaded: url_helper
INFO - 2018-10-25 14:07:02 --> Helper loaded: form_helper
INFO - 2018-10-25 14:07:02 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:07:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:07:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:07:02 --> User Agent Class Initialized
INFO - 2018-10-25 14:07:02 --> Controller Class Initialized
INFO - 2018-10-25 14:07:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:07:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:07:02 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:07:02 --> Pixel_Model class loaded
INFO - 2018-10-25 14:07:02 --> Database Driver Class Initialized
INFO - 2018-10-25 14:07:02 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:07:02 --> Database Driver Class Initialized
INFO - 2018-10-25 14:07:02 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:08:23 --> Config Class Initialized
INFO - 2018-10-25 14:08:23 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:08:23 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:08:23 --> Utf8 Class Initialized
INFO - 2018-10-25 14:08:23 --> URI Class Initialized
INFO - 2018-10-25 14:08:23 --> Router Class Initialized
INFO - 2018-10-25 14:08:23 --> Output Class Initialized
INFO - 2018-10-25 14:08:23 --> Security Class Initialized
DEBUG - 2018-10-25 14:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:08:23 --> CSRF cookie sent
INFO - 2018-10-25 14:08:23 --> Input Class Initialized
INFO - 2018-10-25 14:08:23 --> Language Class Initialized
INFO - 2018-10-25 14:08:23 --> Loader Class Initialized
INFO - 2018-10-25 14:08:23 --> Helper loaded: url_helper
INFO - 2018-10-25 14:08:23 --> Helper loaded: form_helper
INFO - 2018-10-25 14:08:23 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:08:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:08:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:08:23 --> User Agent Class Initialized
INFO - 2018-10-25 14:08:23 --> Controller Class Initialized
INFO - 2018-10-25 14:08:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:08:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:08:23 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:08:23 --> Pixel_Model class loaded
INFO - 2018-10-25 14:08:23 --> Database Driver Class Initialized
INFO - 2018-10-25 14:08:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:08:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-25 14:08:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-25 14:08:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-25 14:08:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-25 14:08:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-25 14:08:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-25 14:08:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-25 14:08:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-25 14:08:23 --> Final output sent to browser
DEBUG - 2018-10-25 14:08:23 --> Total execution time: 0.3914
INFO - 2018-10-25 14:08:25 --> Config Class Initialized
INFO - 2018-10-25 14:08:25 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:08:25 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:08:25 --> Utf8 Class Initialized
INFO - 2018-10-25 14:08:25 --> URI Class Initialized
INFO - 2018-10-25 14:08:25 --> Router Class Initialized
INFO - 2018-10-25 14:08:25 --> Output Class Initialized
INFO - 2018-10-25 14:08:25 --> Security Class Initialized
DEBUG - 2018-10-25 14:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:08:25 --> CSRF cookie sent
INFO - 2018-10-25 14:08:25 --> Input Class Initialized
INFO - 2018-10-25 14:08:25 --> Language Class Initialized
INFO - 2018-10-25 14:08:25 --> Loader Class Initialized
INFO - 2018-10-25 14:08:25 --> Helper loaded: url_helper
INFO - 2018-10-25 14:08:25 --> Helper loaded: form_helper
INFO - 2018-10-25 14:08:25 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:08:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:08:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:08:25 --> User Agent Class Initialized
INFO - 2018-10-25 14:08:25 --> Controller Class Initialized
INFO - 2018-10-25 14:08:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:08:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:08:25 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:08:25 --> Pixel_Model class loaded
INFO - 2018-10-25 14:08:25 --> Database Driver Class Initialized
INFO - 2018-10-25 14:08:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:08:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-25 14:08:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-25 14:08:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-25 14:08:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-25 14:08:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-25 14:08:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-25 14:08:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-25 14:08:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-25 14:08:25 --> Final output sent to browser
DEBUG - 2018-10-25 14:08:25 --> Total execution time: 0.3790
INFO - 2018-10-25 14:08:27 --> Config Class Initialized
INFO - 2018-10-25 14:08:27 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:08:27 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:08:27 --> Utf8 Class Initialized
INFO - 2018-10-25 14:08:27 --> URI Class Initialized
INFO - 2018-10-25 14:08:27 --> Router Class Initialized
INFO - 2018-10-25 14:08:28 --> Output Class Initialized
INFO - 2018-10-25 14:08:28 --> Security Class Initialized
DEBUG - 2018-10-25 14:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:08:28 --> CSRF cookie sent
INFO - 2018-10-25 14:08:28 --> CSRF token verified
INFO - 2018-10-25 14:08:28 --> Input Class Initialized
INFO - 2018-10-25 14:08:28 --> Language Class Initialized
INFO - 2018-10-25 14:08:28 --> Loader Class Initialized
INFO - 2018-10-25 14:08:28 --> Helper loaded: url_helper
INFO - 2018-10-25 14:08:28 --> Helper loaded: form_helper
INFO - 2018-10-25 14:08:28 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:08:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:08:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:08:28 --> User Agent Class Initialized
INFO - 2018-10-25 14:08:28 --> Controller Class Initialized
INFO - 2018-10-25 14:08:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:08:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:08:28 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:08:28 --> Pixel_Model class loaded
INFO - 2018-10-25 14:08:28 --> Database Driver Class Initialized
INFO - 2018-10-25 14:08:28 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:08:28 --> Database Driver Class Initialized
INFO - 2018-10-25 14:08:28 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:09:22 --> Config Class Initialized
INFO - 2018-10-25 14:09:22 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:09:22 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:09:22 --> Utf8 Class Initialized
INFO - 2018-10-25 14:09:22 --> URI Class Initialized
INFO - 2018-10-25 14:09:22 --> Router Class Initialized
INFO - 2018-10-25 14:09:22 --> Output Class Initialized
INFO - 2018-10-25 14:09:22 --> Security Class Initialized
DEBUG - 2018-10-25 14:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:09:22 --> CSRF cookie sent
INFO - 2018-10-25 14:09:22 --> Input Class Initialized
INFO - 2018-10-25 14:09:22 --> Language Class Initialized
INFO - 2018-10-25 14:09:22 --> Loader Class Initialized
INFO - 2018-10-25 14:09:22 --> Helper loaded: url_helper
INFO - 2018-10-25 14:09:22 --> Helper loaded: form_helper
INFO - 2018-10-25 14:09:22 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:09:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:09:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:09:22 --> User Agent Class Initialized
INFO - 2018-10-25 14:09:22 --> Controller Class Initialized
INFO - 2018-10-25 14:09:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:09:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:09:22 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:09:22 --> Pixel_Model class loaded
INFO - 2018-10-25 14:09:22 --> Database Driver Class Initialized
INFO - 2018-10-25 14:09:22 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:09:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-25 14:09:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-25 14:09:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-25 14:09:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-25 14:09:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-25 14:09:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-25 14:09:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-25 14:09:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-25 14:09:22 --> Final output sent to browser
DEBUG - 2018-10-25 14:09:22 --> Total execution time: 0.3769
INFO - 2018-10-25 14:09:58 --> Config Class Initialized
INFO - 2018-10-25 14:09:58 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:09:58 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:09:58 --> Utf8 Class Initialized
INFO - 2018-10-25 14:09:58 --> URI Class Initialized
INFO - 2018-10-25 14:09:58 --> Router Class Initialized
INFO - 2018-10-25 14:09:58 --> Output Class Initialized
INFO - 2018-10-25 14:09:59 --> Security Class Initialized
DEBUG - 2018-10-25 14:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:09:59 --> CSRF cookie sent
INFO - 2018-10-25 14:09:59 --> CSRF token verified
INFO - 2018-10-25 14:09:59 --> Input Class Initialized
INFO - 2018-10-25 14:09:59 --> Language Class Initialized
INFO - 2018-10-25 14:09:59 --> Loader Class Initialized
INFO - 2018-10-25 14:09:59 --> Helper loaded: url_helper
INFO - 2018-10-25 14:09:59 --> Helper loaded: form_helper
INFO - 2018-10-25 14:09:59 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:09:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:09:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:09:59 --> User Agent Class Initialized
INFO - 2018-10-25 14:09:59 --> Controller Class Initialized
INFO - 2018-10-25 14:09:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:09:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:09:59 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:09:59 --> Pixel_Model class loaded
INFO - 2018-10-25 14:09:59 --> Database Driver Class Initialized
INFO - 2018-10-25 14:09:59 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:09:59 --> Database Driver Class Initialized
INFO - 2018-10-25 14:09:59 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:13:04 --> Config Class Initialized
INFO - 2018-10-25 14:13:04 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:13:04 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:13:04 --> Utf8 Class Initialized
INFO - 2018-10-25 14:13:04 --> URI Class Initialized
INFO - 2018-10-25 14:13:04 --> Router Class Initialized
INFO - 2018-10-25 14:13:04 --> Output Class Initialized
INFO - 2018-10-25 14:13:04 --> Security Class Initialized
DEBUG - 2018-10-25 14:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:13:04 --> CSRF cookie sent
INFO - 2018-10-25 14:13:04 --> Input Class Initialized
INFO - 2018-10-25 14:13:04 --> Language Class Initialized
INFO - 2018-10-25 14:13:04 --> Loader Class Initialized
INFO - 2018-10-25 14:13:04 --> Helper loaded: url_helper
INFO - 2018-10-25 14:13:04 --> Helper loaded: form_helper
INFO - 2018-10-25 14:13:04 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:13:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:13:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:13:04 --> User Agent Class Initialized
INFO - 2018-10-25 14:13:04 --> Controller Class Initialized
INFO - 2018-10-25 14:13:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:13:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:13:04 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:13:04 --> Pixel_Model class loaded
INFO - 2018-10-25 14:13:04 --> Database Driver Class Initialized
INFO - 2018-10-25 14:13:05 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:13:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-25 14:13:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-25 14:13:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-25 14:13:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-25 14:13:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-25 14:13:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-25 14:13:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-25 14:13:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-25 14:13:05 --> Final output sent to browser
DEBUG - 2018-10-25 14:13:05 --> Total execution time: 0.4413
INFO - 2018-10-25 14:13:06 --> Config Class Initialized
INFO - 2018-10-25 14:13:06 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:13:06 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:13:06 --> Utf8 Class Initialized
INFO - 2018-10-25 14:13:06 --> URI Class Initialized
INFO - 2018-10-25 14:13:06 --> Router Class Initialized
INFO - 2018-10-25 14:13:06 --> Output Class Initialized
INFO - 2018-10-25 14:13:06 --> Security Class Initialized
DEBUG - 2018-10-25 14:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:13:06 --> CSRF cookie sent
INFO - 2018-10-25 14:13:06 --> CSRF token verified
INFO - 2018-10-25 14:13:06 --> Input Class Initialized
INFO - 2018-10-25 14:13:06 --> Language Class Initialized
INFO - 2018-10-25 14:13:06 --> Loader Class Initialized
INFO - 2018-10-25 14:13:06 --> Helper loaded: url_helper
INFO - 2018-10-25 14:13:06 --> Helper loaded: form_helper
INFO - 2018-10-25 14:13:06 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:13:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:13:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:13:06 --> User Agent Class Initialized
INFO - 2018-10-25 14:13:06 --> Controller Class Initialized
INFO - 2018-10-25 14:13:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:13:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:13:06 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:13:06 --> Pixel_Model class loaded
INFO - 2018-10-25 14:13:06 --> Database Driver Class Initialized
INFO - 2018-10-25 14:13:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:13:06 --> Database Driver Class Initialized
INFO - 2018-10-25 14:13:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:13:16 --> Config Class Initialized
INFO - 2018-10-25 14:13:16 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:13:16 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:13:16 --> Utf8 Class Initialized
INFO - 2018-10-25 14:13:16 --> URI Class Initialized
INFO - 2018-10-25 14:13:16 --> Router Class Initialized
INFO - 2018-10-25 14:13:16 --> Output Class Initialized
INFO - 2018-10-25 14:13:16 --> Security Class Initialized
DEBUG - 2018-10-25 14:13:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:13:16 --> CSRF cookie sent
INFO - 2018-10-25 14:13:16 --> Input Class Initialized
INFO - 2018-10-25 14:13:16 --> Language Class Initialized
INFO - 2018-10-25 14:13:16 --> Loader Class Initialized
INFO - 2018-10-25 14:13:16 --> Helper loaded: url_helper
INFO - 2018-10-25 14:13:16 --> Helper loaded: form_helper
INFO - 2018-10-25 14:13:16 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:13:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:13:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:13:16 --> User Agent Class Initialized
INFO - 2018-10-25 14:13:16 --> Controller Class Initialized
INFO - 2018-10-25 14:13:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:13:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:13:16 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:13:16 --> Pixel_Model class loaded
INFO - 2018-10-25 14:13:16 --> Database Driver Class Initialized
INFO - 2018-10-25 14:13:16 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:13:16 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-25 14:13:16 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-25 14:13:16 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-25 14:13:16 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-25 14:13:16 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-25 14:13:16 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-25 14:13:16 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-25 14:13:16 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-25 14:13:16 --> Final output sent to browser
DEBUG - 2018-10-25 14:13:16 --> Total execution time: 0.4002
INFO - 2018-10-25 14:13:20 --> Config Class Initialized
INFO - 2018-10-25 14:13:20 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:13:20 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:13:20 --> Utf8 Class Initialized
INFO - 2018-10-25 14:13:20 --> URI Class Initialized
INFO - 2018-10-25 14:13:20 --> Router Class Initialized
INFO - 2018-10-25 14:13:20 --> Output Class Initialized
INFO - 2018-10-25 14:13:20 --> Security Class Initialized
DEBUG - 2018-10-25 14:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:13:20 --> CSRF cookie sent
INFO - 2018-10-25 14:13:20 --> CSRF token verified
INFO - 2018-10-25 14:13:20 --> Input Class Initialized
INFO - 2018-10-25 14:13:20 --> Language Class Initialized
INFO - 2018-10-25 14:13:20 --> Loader Class Initialized
INFO - 2018-10-25 14:13:20 --> Helper loaded: url_helper
INFO - 2018-10-25 14:13:20 --> Helper loaded: form_helper
INFO - 2018-10-25 14:13:20 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:13:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:13:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:13:20 --> User Agent Class Initialized
INFO - 2018-10-25 14:13:20 --> Controller Class Initialized
INFO - 2018-10-25 14:13:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:13:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:13:20 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:13:20 --> Pixel_Model class loaded
INFO - 2018-10-25 14:13:20 --> Database Driver Class Initialized
INFO - 2018-10-25 14:13:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:13:20 --> Database Driver Class Initialized
INFO - 2018-10-25 14:13:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:13:42 --> Config Class Initialized
INFO - 2018-10-25 14:13:42 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:13:42 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:13:42 --> Utf8 Class Initialized
INFO - 2018-10-25 14:13:42 --> URI Class Initialized
INFO - 2018-10-25 14:13:42 --> Router Class Initialized
INFO - 2018-10-25 14:13:42 --> Output Class Initialized
INFO - 2018-10-25 14:13:42 --> Security Class Initialized
DEBUG - 2018-10-25 14:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:13:42 --> CSRF cookie sent
INFO - 2018-10-25 14:13:42 --> Input Class Initialized
INFO - 2018-10-25 14:13:42 --> Language Class Initialized
INFO - 2018-10-25 14:13:42 --> Loader Class Initialized
INFO - 2018-10-25 14:13:42 --> Helper loaded: url_helper
INFO - 2018-10-25 14:13:42 --> Helper loaded: form_helper
INFO - 2018-10-25 14:13:42 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:13:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:13:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:13:42 --> User Agent Class Initialized
INFO - 2018-10-25 14:13:42 --> Controller Class Initialized
INFO - 2018-10-25 14:13:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:13:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:13:42 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:13:42 --> Pixel_Model class loaded
INFO - 2018-10-25 14:13:42 --> Database Driver Class Initialized
INFO - 2018-10-25 14:13:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:13:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-25 14:13:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-25 14:13:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-25 14:13:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-25 14:13:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-25 14:13:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-25 14:13:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-25 14:13:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-25 14:13:42 --> Final output sent to browser
DEBUG - 2018-10-25 14:13:42 --> Total execution time: 0.4066
INFO - 2018-10-25 14:13:43 --> Config Class Initialized
INFO - 2018-10-25 14:13:43 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:13:43 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:13:43 --> Utf8 Class Initialized
INFO - 2018-10-25 14:13:43 --> URI Class Initialized
INFO - 2018-10-25 14:13:43 --> Router Class Initialized
INFO - 2018-10-25 14:13:43 --> Output Class Initialized
INFO - 2018-10-25 14:13:43 --> Security Class Initialized
DEBUG - 2018-10-25 14:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:13:43 --> CSRF cookie sent
INFO - 2018-10-25 14:13:43 --> Input Class Initialized
INFO - 2018-10-25 14:13:43 --> Language Class Initialized
INFO - 2018-10-25 14:13:43 --> Loader Class Initialized
INFO - 2018-10-25 14:13:43 --> Helper loaded: url_helper
INFO - 2018-10-25 14:13:43 --> Helper loaded: form_helper
INFO - 2018-10-25 14:13:43 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:13:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:13:43 --> User Agent Class Initialized
INFO - 2018-10-25 14:13:43 --> Controller Class Initialized
INFO - 2018-10-25 14:13:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:13:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:13:43 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:13:43 --> Pixel_Model class loaded
INFO - 2018-10-25 14:13:43 --> Database Driver Class Initialized
INFO - 2018-10-25 14:13:43 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:13:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-25 14:13:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-25 14:13:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-25 14:13:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-25 14:13:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-25 14:13:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-25 14:13:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-25 14:13:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-25 14:13:43 --> Final output sent to browser
DEBUG - 2018-10-25 14:13:43 --> Total execution time: 0.4121
INFO - 2018-10-25 14:13:45 --> Config Class Initialized
INFO - 2018-10-25 14:13:45 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:13:45 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:13:45 --> Utf8 Class Initialized
INFO - 2018-10-25 14:13:45 --> URI Class Initialized
INFO - 2018-10-25 14:13:45 --> Router Class Initialized
INFO - 2018-10-25 14:13:45 --> Output Class Initialized
INFO - 2018-10-25 14:13:45 --> Security Class Initialized
DEBUG - 2018-10-25 14:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:13:45 --> CSRF cookie sent
INFO - 2018-10-25 14:13:45 --> CSRF token verified
INFO - 2018-10-25 14:13:45 --> Input Class Initialized
INFO - 2018-10-25 14:13:45 --> Language Class Initialized
INFO - 2018-10-25 14:13:45 --> Loader Class Initialized
INFO - 2018-10-25 14:13:45 --> Helper loaded: url_helper
INFO - 2018-10-25 14:13:45 --> Helper loaded: form_helper
INFO - 2018-10-25 14:13:45 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:13:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:13:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:13:45 --> User Agent Class Initialized
INFO - 2018-10-25 14:13:45 --> Controller Class Initialized
INFO - 2018-10-25 14:13:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:13:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:13:45 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:13:45 --> Pixel_Model class loaded
INFO - 2018-10-25 14:13:45 --> Database Driver Class Initialized
INFO - 2018-10-25 14:13:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:13:45 --> Database Driver Class Initialized
INFO - 2018-10-25 14:13:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:13:45 --> Config Class Initialized
INFO - 2018-10-25 14:13:45 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:13:45 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:13:45 --> Utf8 Class Initialized
INFO - 2018-10-25 14:13:45 --> URI Class Initialized
INFO - 2018-10-25 14:13:45 --> Router Class Initialized
INFO - 2018-10-25 14:13:45 --> Output Class Initialized
INFO - 2018-10-25 14:13:45 --> Security Class Initialized
DEBUG - 2018-10-25 14:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:13:45 --> CSRF cookie sent
INFO - 2018-10-25 14:13:45 --> Input Class Initialized
INFO - 2018-10-25 14:13:45 --> Language Class Initialized
INFO - 2018-10-25 14:13:45 --> Loader Class Initialized
INFO - 2018-10-25 14:13:45 --> Helper loaded: url_helper
INFO - 2018-10-25 14:13:45 --> Helper loaded: form_helper
INFO - 2018-10-25 14:13:45 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:13:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:13:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:13:45 --> User Agent Class Initialized
INFO - 2018-10-25 14:13:45 --> Controller Class Initialized
INFO - 2018-10-25 14:13:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:13:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:13:45 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:13:45 --> Pixel_Model class loaded
INFO - 2018-10-25 14:13:45 --> Database Driver Class Initialized
INFO - 2018-10-25 14:13:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:13:45 --> Database Driver Class Initialized
INFO - 2018-10-25 14:13:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:13:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-25 14:13:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-25 14:13:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-25 14:13:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-25 14:13:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-25 14:13:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-25 14:13:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-25 14:13:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-25 14:13:46 --> Final output sent to browser
DEBUG - 2018-10-25 14:13:46 --> Total execution time: 0.4122
INFO - 2018-10-25 14:13:48 --> Config Class Initialized
INFO - 2018-10-25 14:13:48 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:13:48 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:13:48 --> Utf8 Class Initialized
INFO - 2018-10-25 14:13:48 --> URI Class Initialized
INFO - 2018-10-25 14:13:48 --> Router Class Initialized
INFO - 2018-10-25 14:13:48 --> Output Class Initialized
INFO - 2018-10-25 14:13:48 --> Security Class Initialized
DEBUG - 2018-10-25 14:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:13:48 --> CSRF cookie sent
INFO - 2018-10-25 14:13:48 --> CSRF token verified
INFO - 2018-10-25 14:13:48 --> Input Class Initialized
INFO - 2018-10-25 14:13:48 --> Language Class Initialized
INFO - 2018-10-25 14:13:48 --> Loader Class Initialized
INFO - 2018-10-25 14:13:48 --> Helper loaded: url_helper
INFO - 2018-10-25 14:13:48 --> Helper loaded: form_helper
INFO - 2018-10-25 14:13:48 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:13:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:13:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:13:48 --> User Agent Class Initialized
INFO - 2018-10-25 14:13:48 --> Controller Class Initialized
INFO - 2018-10-25 14:13:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:13:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:13:48 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:13:48 --> Pixel_Model class loaded
INFO - 2018-10-25 14:13:48 --> Database Driver Class Initialized
INFO - 2018-10-25 14:13:48 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:13:48 --> Form Validation Class Initialized
INFO - 2018-10-25 14:13:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-25 14:13:48 --> Database Driver Class Initialized
INFO - 2018-10-25 14:13:48 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:13:49 --> Config Class Initialized
INFO - 2018-10-25 14:13:49 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:13:49 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:13:49 --> Utf8 Class Initialized
INFO - 2018-10-25 14:13:49 --> URI Class Initialized
INFO - 2018-10-25 14:13:49 --> Router Class Initialized
INFO - 2018-10-25 14:13:49 --> Output Class Initialized
INFO - 2018-10-25 14:13:49 --> Security Class Initialized
DEBUG - 2018-10-25 14:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:13:49 --> CSRF cookie sent
INFO - 2018-10-25 14:13:49 --> Input Class Initialized
INFO - 2018-10-25 14:13:49 --> Language Class Initialized
INFO - 2018-10-25 14:13:49 --> Loader Class Initialized
INFO - 2018-10-25 14:13:49 --> Helper loaded: url_helper
INFO - 2018-10-25 14:13:49 --> Helper loaded: form_helper
INFO - 2018-10-25 14:13:49 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:13:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:13:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:13:49 --> User Agent Class Initialized
INFO - 2018-10-25 14:13:49 --> Controller Class Initialized
INFO - 2018-10-25 14:13:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:13:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:13:49 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:13:49 --> Pixel_Model class loaded
INFO - 2018-10-25 14:13:49 --> Database Driver Class Initialized
INFO - 2018-10-25 14:13:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:13:49 --> Database Driver Class Initialized
INFO - 2018-10-25 14:13:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:13:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-25 14:13:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-25 14:13:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-25 14:13:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-25 14:13:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-25 14:13:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-25 14:13:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/your_job.php
INFO - 2018-10-25 14:13:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-25 14:13:49 --> Final output sent to browser
DEBUG - 2018-10-25 14:13:49 --> Total execution time: 0.4310
INFO - 2018-10-25 14:13:50 --> Config Class Initialized
INFO - 2018-10-25 14:13:50 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:13:50 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:13:50 --> Utf8 Class Initialized
INFO - 2018-10-25 14:13:50 --> URI Class Initialized
INFO - 2018-10-25 14:13:50 --> Router Class Initialized
INFO - 2018-10-25 14:13:50 --> Output Class Initialized
INFO - 2018-10-25 14:13:50 --> Security Class Initialized
DEBUG - 2018-10-25 14:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:13:50 --> CSRF cookie sent
INFO - 2018-10-25 14:13:50 --> CSRF token verified
INFO - 2018-10-25 14:13:50 --> Input Class Initialized
INFO - 2018-10-25 14:13:50 --> Language Class Initialized
INFO - 2018-10-25 14:13:50 --> Loader Class Initialized
INFO - 2018-10-25 14:13:50 --> Helper loaded: url_helper
INFO - 2018-10-25 14:13:50 --> Helper loaded: form_helper
INFO - 2018-10-25 14:13:50 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:13:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:13:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:13:50 --> User Agent Class Initialized
INFO - 2018-10-25 14:13:50 --> Controller Class Initialized
INFO - 2018-10-25 14:13:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:13:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:13:50 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:13:50 --> Pixel_Model class loaded
INFO - 2018-10-25 14:13:50 --> Database Driver Class Initialized
INFO - 2018-10-25 14:13:50 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:13:50 --> Form Validation Class Initialized
INFO - 2018-10-25 14:13:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-25 14:13:50 --> Database Driver Class Initialized
INFO - 2018-10-25 14:13:50 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:13:50 --> Config Class Initialized
INFO - 2018-10-25 14:13:50 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:13:50 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:13:50 --> Utf8 Class Initialized
INFO - 2018-10-25 14:13:50 --> URI Class Initialized
INFO - 2018-10-25 14:13:50 --> Router Class Initialized
INFO - 2018-10-25 14:13:50 --> Output Class Initialized
INFO - 2018-10-25 14:13:50 --> Security Class Initialized
DEBUG - 2018-10-25 14:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:13:50 --> CSRF cookie sent
INFO - 2018-10-25 14:13:50 --> Input Class Initialized
INFO - 2018-10-25 14:13:50 --> Language Class Initialized
INFO - 2018-10-25 14:13:50 --> Loader Class Initialized
INFO - 2018-10-25 14:13:50 --> Helper loaded: url_helper
INFO - 2018-10-25 14:13:50 --> Helper loaded: form_helper
INFO - 2018-10-25 14:13:50 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:13:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:13:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:13:50 --> User Agent Class Initialized
INFO - 2018-10-25 14:13:50 --> Controller Class Initialized
INFO - 2018-10-25 14:13:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:13:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:13:50 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:13:50 --> Pixel_Model class loaded
INFO - 2018-10-25 14:13:50 --> Database Driver Class Initialized
INFO - 2018-10-25 14:13:50 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:13:50 --> Database Driver Class Initialized
INFO - 2018-10-25 14:13:50 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:13:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-25 14:13:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-25 14:13:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner.php
INFO - 2018-10-25 14:13:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-25 14:13:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-25 14:13:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-25 14:13:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-25 14:13:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/relation_ship_status.php
INFO - 2018-10-25 14:13:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-25 14:13:50 --> Final output sent to browser
DEBUG - 2018-10-25 14:13:50 --> Total execution time: 0.4065
INFO - 2018-10-25 14:13:51 --> Config Class Initialized
INFO - 2018-10-25 14:13:51 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:13:51 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:13:51 --> Utf8 Class Initialized
INFO - 2018-10-25 14:13:51 --> URI Class Initialized
INFO - 2018-10-25 14:13:51 --> Router Class Initialized
INFO - 2018-10-25 14:13:51 --> Output Class Initialized
INFO - 2018-10-25 14:13:51 --> Security Class Initialized
DEBUG - 2018-10-25 14:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:13:51 --> CSRF cookie sent
INFO - 2018-10-25 14:13:51 --> CSRF token verified
INFO - 2018-10-25 14:13:51 --> Input Class Initialized
INFO - 2018-10-25 14:13:51 --> Language Class Initialized
INFO - 2018-10-25 14:13:51 --> Loader Class Initialized
INFO - 2018-10-25 14:13:51 --> Helper loaded: url_helper
INFO - 2018-10-25 14:13:51 --> Helper loaded: form_helper
INFO - 2018-10-25 14:13:51 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:13:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:13:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:13:51 --> User Agent Class Initialized
INFO - 2018-10-25 14:13:51 --> Controller Class Initialized
INFO - 2018-10-25 14:13:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:13:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:13:51 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:13:51 --> Pixel_Model class loaded
INFO - 2018-10-25 14:13:51 --> Database Driver Class Initialized
INFO - 2018-10-25 14:13:51 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:13:51 --> Form Validation Class Initialized
INFO - 2018-10-25 14:13:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-25 14:13:51 --> Database Driver Class Initialized
INFO - 2018-10-25 14:13:51 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:13:51 --> Config Class Initialized
INFO - 2018-10-25 14:13:51 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:13:51 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:13:51 --> Utf8 Class Initialized
INFO - 2018-10-25 14:13:51 --> URI Class Initialized
INFO - 2018-10-25 14:13:51 --> Router Class Initialized
INFO - 2018-10-25 14:13:51 --> Output Class Initialized
INFO - 2018-10-25 14:13:51 --> Security Class Initialized
DEBUG - 2018-10-25 14:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:13:51 --> CSRF cookie sent
INFO - 2018-10-25 14:13:51 --> Input Class Initialized
INFO - 2018-10-25 14:13:51 --> Language Class Initialized
INFO - 2018-10-25 14:13:51 --> Loader Class Initialized
INFO - 2018-10-25 14:13:51 --> Helper loaded: url_helper
INFO - 2018-10-25 14:13:51 --> Helper loaded: form_helper
INFO - 2018-10-25 14:13:51 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:13:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:13:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:13:51 --> User Agent Class Initialized
INFO - 2018-10-25 14:13:51 --> Controller Class Initialized
INFO - 2018-10-25 14:13:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:13:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:13:51 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:13:51 --> Pixel_Model class loaded
INFO - 2018-10-25 14:13:51 --> Database Driver Class Initialized
INFO - 2018-10-25 14:13:51 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:13:51 --> Database Driver Class Initialized
INFO - 2018-10-25 14:13:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:13:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-25 14:13:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-25 14:13:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-25 14:13:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-25 14:13:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-25 14:13:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-25 14:13:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/income.php
INFO - 2018-10-25 14:13:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-25 14:13:52 --> Final output sent to browser
DEBUG - 2018-10-25 14:13:52 --> Total execution time: 0.3962
INFO - 2018-10-25 14:13:54 --> Config Class Initialized
INFO - 2018-10-25 14:13:54 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:13:54 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:13:54 --> Utf8 Class Initialized
INFO - 2018-10-25 14:13:54 --> URI Class Initialized
INFO - 2018-10-25 14:13:54 --> Router Class Initialized
INFO - 2018-10-25 14:13:54 --> Output Class Initialized
INFO - 2018-10-25 14:13:54 --> Security Class Initialized
DEBUG - 2018-10-25 14:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:13:54 --> CSRF cookie sent
INFO - 2018-10-25 14:13:54 --> CSRF token verified
INFO - 2018-10-25 14:13:54 --> Input Class Initialized
INFO - 2018-10-25 14:13:54 --> Language Class Initialized
INFO - 2018-10-25 14:13:54 --> Loader Class Initialized
INFO - 2018-10-25 14:13:54 --> Helper loaded: url_helper
INFO - 2018-10-25 14:13:54 --> Helper loaded: form_helper
INFO - 2018-10-25 14:13:54 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:13:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:13:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:13:54 --> User Agent Class Initialized
INFO - 2018-10-25 14:13:54 --> Controller Class Initialized
INFO - 2018-10-25 14:13:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:13:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:13:54 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:13:54 --> Pixel_Model class loaded
INFO - 2018-10-25 14:13:54 --> Database Driver Class Initialized
INFO - 2018-10-25 14:13:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:13:54 --> Form Validation Class Initialized
INFO - 2018-10-25 14:13:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-25 14:13:54 --> Database Driver Class Initialized
INFO - 2018-10-25 14:13:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:13:54 --> Config Class Initialized
INFO - 2018-10-25 14:13:54 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:13:54 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:13:54 --> Utf8 Class Initialized
INFO - 2018-10-25 14:13:54 --> URI Class Initialized
INFO - 2018-10-25 14:13:54 --> Router Class Initialized
INFO - 2018-10-25 14:13:54 --> Output Class Initialized
INFO - 2018-10-25 14:13:54 --> Security Class Initialized
DEBUG - 2018-10-25 14:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:13:54 --> CSRF cookie sent
INFO - 2018-10-25 14:13:54 --> Input Class Initialized
INFO - 2018-10-25 14:13:54 --> Language Class Initialized
INFO - 2018-10-25 14:13:54 --> Loader Class Initialized
INFO - 2018-10-25 14:13:54 --> Helper loaded: url_helper
INFO - 2018-10-25 14:13:54 --> Helper loaded: form_helper
INFO - 2018-10-25 14:13:54 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:13:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:13:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:13:55 --> User Agent Class Initialized
INFO - 2018-10-25 14:13:55 --> Controller Class Initialized
INFO - 2018-10-25 14:13:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:13:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:13:55 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:13:55 --> Pixel_Model class loaded
INFO - 2018-10-25 14:13:55 --> Database Driver Class Initialized
INFO - 2018-10-25 14:13:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:13:55 --> Database Driver Class Initialized
INFO - 2018-10-25 14:13:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:13:55 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-25 14:13:55 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-25 14:13:55 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-25 14:13:55 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-25 14:13:55 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-25 14:13:55 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-25 14:13:55 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/marriage.php
INFO - 2018-10-25 14:13:55 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-25 14:13:55 --> Final output sent to browser
DEBUG - 2018-10-25 14:13:55 --> Total execution time: 0.4261
INFO - 2018-10-25 14:13:57 --> Config Class Initialized
INFO - 2018-10-25 14:13:57 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:13:57 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:13:57 --> Utf8 Class Initialized
INFO - 2018-10-25 14:13:57 --> URI Class Initialized
INFO - 2018-10-25 14:13:57 --> Router Class Initialized
INFO - 2018-10-25 14:13:57 --> Output Class Initialized
INFO - 2018-10-25 14:13:57 --> Security Class Initialized
DEBUG - 2018-10-25 14:13:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:13:57 --> CSRF cookie sent
INFO - 2018-10-25 14:13:57 --> CSRF token verified
INFO - 2018-10-25 14:13:57 --> Input Class Initialized
INFO - 2018-10-25 14:13:57 --> Language Class Initialized
INFO - 2018-10-25 14:13:57 --> Loader Class Initialized
INFO - 2018-10-25 14:13:57 --> Helper loaded: url_helper
INFO - 2018-10-25 14:13:57 --> Helper loaded: form_helper
INFO - 2018-10-25 14:13:57 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:13:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:13:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:13:57 --> User Agent Class Initialized
INFO - 2018-10-25 14:13:57 --> Controller Class Initialized
INFO - 2018-10-25 14:13:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:13:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:13:57 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:13:57 --> Pixel_Model class loaded
INFO - 2018-10-25 14:13:57 --> Database Driver Class Initialized
INFO - 2018-10-25 14:13:57 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:13:57 --> Form Validation Class Initialized
INFO - 2018-10-25 14:13:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-25 14:13:57 --> Database Driver Class Initialized
INFO - 2018-10-25 14:13:57 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:13:57 --> Config Class Initialized
INFO - 2018-10-25 14:13:57 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:13:57 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:13:58 --> Utf8 Class Initialized
INFO - 2018-10-25 14:13:58 --> URI Class Initialized
INFO - 2018-10-25 14:13:58 --> Router Class Initialized
INFO - 2018-10-25 14:13:58 --> Output Class Initialized
INFO - 2018-10-25 14:13:58 --> Security Class Initialized
DEBUG - 2018-10-25 14:13:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:13:58 --> CSRF cookie sent
INFO - 2018-10-25 14:13:58 --> Input Class Initialized
INFO - 2018-10-25 14:13:58 --> Language Class Initialized
INFO - 2018-10-25 14:13:58 --> Loader Class Initialized
INFO - 2018-10-25 14:13:58 --> Helper loaded: url_helper
INFO - 2018-10-25 14:13:58 --> Helper loaded: form_helper
INFO - 2018-10-25 14:13:58 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:13:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:13:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:13:58 --> User Agent Class Initialized
INFO - 2018-10-25 14:13:58 --> Controller Class Initialized
INFO - 2018-10-25 14:13:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:13:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:13:58 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:13:58 --> Pixel_Model class loaded
INFO - 2018-10-25 14:13:58 --> Database Driver Class Initialized
INFO - 2018-10-25 14:13:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:13:58 --> Database Driver Class Initialized
INFO - 2018-10-25 14:13:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:13:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-25 14:13:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-25 14:13:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-25 14:13:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-25 14:13:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-25 14:13:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-25 14:13:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/kids.php
INFO - 2018-10-25 14:13:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-25 14:13:58 --> Final output sent to browser
DEBUG - 2018-10-25 14:13:58 --> Total execution time: 0.4191
INFO - 2018-10-25 14:14:01 --> Config Class Initialized
INFO - 2018-10-25 14:14:01 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:14:01 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:14:01 --> Utf8 Class Initialized
INFO - 2018-10-25 14:14:01 --> URI Class Initialized
INFO - 2018-10-25 14:14:01 --> Router Class Initialized
INFO - 2018-10-25 14:14:01 --> Output Class Initialized
INFO - 2018-10-25 14:14:01 --> Security Class Initialized
DEBUG - 2018-10-25 14:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:14:01 --> CSRF cookie sent
INFO - 2018-10-25 14:14:01 --> CSRF token verified
INFO - 2018-10-25 14:14:01 --> Input Class Initialized
INFO - 2018-10-25 14:14:01 --> Language Class Initialized
INFO - 2018-10-25 14:14:01 --> Loader Class Initialized
INFO - 2018-10-25 14:14:01 --> Helper loaded: url_helper
INFO - 2018-10-25 14:14:01 --> Helper loaded: form_helper
INFO - 2018-10-25 14:14:01 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:14:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:14:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:14:01 --> User Agent Class Initialized
INFO - 2018-10-25 14:14:01 --> Controller Class Initialized
INFO - 2018-10-25 14:14:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:14:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:14:01 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:14:01 --> Pixel_Model class loaded
INFO - 2018-10-25 14:14:01 --> Database Driver Class Initialized
INFO - 2018-10-25 14:14:01 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:14:01 --> Form Validation Class Initialized
INFO - 2018-10-25 14:14:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-25 14:14:01 --> Database Driver Class Initialized
INFO - 2018-10-25 14:14:01 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:14:01 --> Config Class Initialized
INFO - 2018-10-25 14:14:01 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:14:01 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:14:01 --> Utf8 Class Initialized
INFO - 2018-10-25 14:14:01 --> URI Class Initialized
INFO - 2018-10-25 14:14:01 --> Router Class Initialized
INFO - 2018-10-25 14:14:01 --> Output Class Initialized
INFO - 2018-10-25 14:14:01 --> Security Class Initialized
DEBUG - 2018-10-25 14:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:14:01 --> CSRF cookie sent
INFO - 2018-10-25 14:14:01 --> Input Class Initialized
INFO - 2018-10-25 14:14:01 --> Language Class Initialized
INFO - 2018-10-25 14:14:01 --> Loader Class Initialized
INFO - 2018-10-25 14:14:01 --> Helper loaded: url_helper
INFO - 2018-10-25 14:14:01 --> Helper loaded: form_helper
INFO - 2018-10-25 14:14:02 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:14:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:14:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:14:02 --> User Agent Class Initialized
INFO - 2018-10-25 14:14:02 --> Controller Class Initialized
INFO - 2018-10-25 14:14:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:14:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:14:02 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:14:02 --> Pixel_Model class loaded
INFO - 2018-10-25 14:14:02 --> Database Driver Class Initialized
INFO - 2018-10-25 14:14:02 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:14:02 --> Database Driver Class Initialized
INFO - 2018-10-25 14:14:02 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:14:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-25 14:14:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-25 14:14:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-25 14:14:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-25 14:14:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-25 14:14:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-25 14:14:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/pension.php
INFO - 2018-10-25 14:14:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-25 14:14:02 --> Final output sent to browser
DEBUG - 2018-10-25 14:14:02 --> Total execution time: 0.4345
INFO - 2018-10-25 14:14:04 --> Config Class Initialized
INFO - 2018-10-25 14:14:04 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:14:04 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:14:04 --> Utf8 Class Initialized
INFO - 2018-10-25 14:14:04 --> URI Class Initialized
INFO - 2018-10-25 14:14:04 --> Router Class Initialized
INFO - 2018-10-25 14:14:04 --> Output Class Initialized
INFO - 2018-10-25 14:14:04 --> Security Class Initialized
DEBUG - 2018-10-25 14:14:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:14:04 --> CSRF cookie sent
INFO - 2018-10-25 14:14:04 --> CSRF token verified
INFO - 2018-10-25 14:14:04 --> Input Class Initialized
INFO - 2018-10-25 14:14:04 --> Language Class Initialized
INFO - 2018-10-25 14:14:04 --> Loader Class Initialized
INFO - 2018-10-25 14:14:04 --> Helper loaded: url_helper
INFO - 2018-10-25 14:14:04 --> Helper loaded: form_helper
INFO - 2018-10-25 14:14:04 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:14:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:14:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:14:04 --> User Agent Class Initialized
INFO - 2018-10-25 14:14:04 --> Controller Class Initialized
INFO - 2018-10-25 14:14:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:14:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:14:04 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:14:04 --> Pixel_Model class loaded
INFO - 2018-10-25 14:14:04 --> Database Driver Class Initialized
INFO - 2018-10-25 14:14:04 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:14:04 --> Form Validation Class Initialized
INFO - 2018-10-25 14:14:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-25 14:14:04 --> Database Driver Class Initialized
INFO - 2018-10-25 14:14:04 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:14:04 --> Config Class Initialized
INFO - 2018-10-25 14:14:04 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:14:04 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:14:04 --> Utf8 Class Initialized
INFO - 2018-10-25 14:14:04 --> URI Class Initialized
INFO - 2018-10-25 14:14:04 --> Router Class Initialized
INFO - 2018-10-25 14:14:04 --> Output Class Initialized
INFO - 2018-10-25 14:14:05 --> Security Class Initialized
DEBUG - 2018-10-25 14:14:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:14:05 --> CSRF cookie sent
INFO - 2018-10-25 14:14:05 --> Input Class Initialized
INFO - 2018-10-25 14:14:05 --> Language Class Initialized
INFO - 2018-10-25 14:14:05 --> Loader Class Initialized
INFO - 2018-10-25 14:14:05 --> Helper loaded: url_helper
INFO - 2018-10-25 14:14:05 --> Helper loaded: form_helper
INFO - 2018-10-25 14:14:05 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:14:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:14:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:14:05 --> User Agent Class Initialized
INFO - 2018-10-25 14:14:05 --> Controller Class Initialized
INFO - 2018-10-25 14:14:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:14:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:14:05 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:14:05 --> Pixel_Model class loaded
INFO - 2018-10-25 14:14:05 --> Database Driver Class Initialized
INFO - 2018-10-25 14:14:05 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:14:05 --> Database Driver Class Initialized
INFO - 2018-10-25 14:14:05 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:14:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-25 14:14:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-25 14:14:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-25 14:14:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-25 14:14:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-25 14:14:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-25 14:14:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/inheritance.php
INFO - 2018-10-25 14:14:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-25 14:14:05 --> Final output sent to browser
DEBUG - 2018-10-25 14:14:05 --> Total execution time: 0.4259
INFO - 2018-10-25 14:14:07 --> Config Class Initialized
INFO - 2018-10-25 14:14:07 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:14:07 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:14:07 --> Utf8 Class Initialized
INFO - 2018-10-25 14:14:07 --> URI Class Initialized
INFO - 2018-10-25 14:14:07 --> Router Class Initialized
INFO - 2018-10-25 14:14:07 --> Output Class Initialized
INFO - 2018-10-25 14:14:07 --> Security Class Initialized
DEBUG - 2018-10-25 14:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:14:07 --> CSRF cookie sent
INFO - 2018-10-25 14:14:07 --> CSRF token verified
INFO - 2018-10-25 14:14:07 --> Input Class Initialized
INFO - 2018-10-25 14:14:07 --> Language Class Initialized
INFO - 2018-10-25 14:14:07 --> Loader Class Initialized
INFO - 2018-10-25 14:14:07 --> Helper loaded: url_helper
INFO - 2018-10-25 14:14:07 --> Helper loaded: form_helper
INFO - 2018-10-25 14:14:07 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:14:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:14:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:14:07 --> User Agent Class Initialized
INFO - 2018-10-25 14:14:07 --> Controller Class Initialized
INFO - 2018-10-25 14:14:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:14:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:14:07 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:14:07 --> Pixel_Model class loaded
INFO - 2018-10-25 14:14:07 --> Database Driver Class Initialized
INFO - 2018-10-25 14:14:07 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:14:07 --> Form Validation Class Initialized
INFO - 2018-10-25 14:14:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-25 14:14:07 --> Database Driver Class Initialized
INFO - 2018-10-25 14:14:07 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:14:07 --> Config Class Initialized
INFO - 2018-10-25 14:14:07 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:14:07 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:14:07 --> Utf8 Class Initialized
INFO - 2018-10-25 14:14:07 --> URI Class Initialized
INFO - 2018-10-25 14:14:07 --> Router Class Initialized
INFO - 2018-10-25 14:14:07 --> Output Class Initialized
INFO - 2018-10-25 14:14:07 --> Security Class Initialized
DEBUG - 2018-10-25 14:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:14:07 --> CSRF cookie sent
INFO - 2018-10-25 14:14:07 --> Input Class Initialized
INFO - 2018-10-25 14:14:07 --> Language Class Initialized
INFO - 2018-10-25 14:14:07 --> Loader Class Initialized
INFO - 2018-10-25 14:14:07 --> Helper loaded: url_helper
INFO - 2018-10-25 14:14:07 --> Helper loaded: form_helper
INFO - 2018-10-25 14:14:07 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:14:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:14:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:14:07 --> User Agent Class Initialized
INFO - 2018-10-25 14:14:07 --> Controller Class Initialized
INFO - 2018-10-25 14:14:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:14:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:14:07 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:14:07 --> Pixel_Model class loaded
INFO - 2018-10-25 14:14:07 --> Database Driver Class Initialized
INFO - 2018-10-25 14:14:07 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:14:07 --> Database Driver Class Initialized
INFO - 2018-10-25 14:14:07 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:14:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-25 14:14:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-25 14:14:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-25 14:14:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-25 14:14:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-25 14:14:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-25 14:14:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/inheritance_maintained.php
INFO - 2018-10-25 14:14:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-25 14:14:07 --> Final output sent to browser
DEBUG - 2018-10-25 14:14:08 --> Total execution time: 0.4272
INFO - 2018-10-25 14:14:09 --> Config Class Initialized
INFO - 2018-10-25 14:14:09 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:14:09 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:14:09 --> Utf8 Class Initialized
INFO - 2018-10-25 14:14:09 --> URI Class Initialized
INFO - 2018-10-25 14:14:09 --> Router Class Initialized
INFO - 2018-10-25 14:14:09 --> Output Class Initialized
INFO - 2018-10-25 14:14:09 --> Security Class Initialized
DEBUG - 2018-10-25 14:14:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:14:09 --> CSRF cookie sent
INFO - 2018-10-25 14:14:09 --> CSRF token verified
INFO - 2018-10-25 14:14:09 --> Input Class Initialized
INFO - 2018-10-25 14:14:09 --> Language Class Initialized
INFO - 2018-10-25 14:14:09 --> Loader Class Initialized
INFO - 2018-10-25 14:14:09 --> Helper loaded: url_helper
INFO - 2018-10-25 14:14:09 --> Helper loaded: form_helper
INFO - 2018-10-25 14:14:09 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:14:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:14:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:14:09 --> User Agent Class Initialized
INFO - 2018-10-25 14:14:09 --> Controller Class Initialized
INFO - 2018-10-25 14:14:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:14:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:14:09 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:14:09 --> Pixel_Model class loaded
INFO - 2018-10-25 14:14:09 --> Database Driver Class Initialized
INFO - 2018-10-25 14:14:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:14:09 --> Form Validation Class Initialized
INFO - 2018-10-25 14:14:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-25 14:14:09 --> Database Driver Class Initialized
INFO - 2018-10-25 14:14:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:14:09 --> Config Class Initialized
INFO - 2018-10-25 14:14:09 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:14:09 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:14:09 --> Utf8 Class Initialized
INFO - 2018-10-25 14:14:09 --> URI Class Initialized
INFO - 2018-10-25 14:14:09 --> Router Class Initialized
INFO - 2018-10-25 14:14:09 --> Output Class Initialized
INFO - 2018-10-25 14:14:09 --> Security Class Initialized
DEBUG - 2018-10-25 14:14:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:14:09 --> CSRF cookie sent
INFO - 2018-10-25 14:14:09 --> Input Class Initialized
INFO - 2018-10-25 14:14:09 --> Language Class Initialized
INFO - 2018-10-25 14:14:09 --> Loader Class Initialized
INFO - 2018-10-25 14:14:09 --> Helper loaded: url_helper
INFO - 2018-10-25 14:14:09 --> Helper loaded: form_helper
INFO - 2018-10-25 14:14:09 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:14:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:14:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:14:10 --> User Agent Class Initialized
INFO - 2018-10-25 14:14:10 --> Controller Class Initialized
INFO - 2018-10-25 14:14:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:14:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:14:10 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:14:10 --> Pixel_Model class loaded
INFO - 2018-10-25 14:14:10 --> Database Driver Class Initialized
INFO - 2018-10-25 14:14:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:14:10 --> Database Driver Class Initialized
INFO - 2018-10-25 14:14:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:14:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-25 14:14:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-25 14:14:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-25 14:14:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-25 14:14:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-25 14:14:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-25 14:14:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/home_owner.php
INFO - 2018-10-25 14:14:10 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-25 14:14:10 --> Final output sent to browser
DEBUG - 2018-10-25 14:14:10 --> Total execution time: 0.4350
INFO - 2018-10-25 14:14:11 --> Config Class Initialized
INFO - 2018-10-25 14:14:11 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:14:11 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:14:11 --> Utf8 Class Initialized
INFO - 2018-10-25 14:14:11 --> URI Class Initialized
INFO - 2018-10-25 14:14:11 --> Router Class Initialized
INFO - 2018-10-25 14:14:11 --> Output Class Initialized
INFO - 2018-10-25 14:14:11 --> Security Class Initialized
DEBUG - 2018-10-25 14:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:14:11 --> CSRF cookie sent
INFO - 2018-10-25 14:14:11 --> CSRF token verified
INFO - 2018-10-25 14:14:11 --> Input Class Initialized
INFO - 2018-10-25 14:14:11 --> Language Class Initialized
INFO - 2018-10-25 14:14:11 --> Loader Class Initialized
INFO - 2018-10-25 14:14:11 --> Helper loaded: url_helper
INFO - 2018-10-25 14:14:11 --> Helper loaded: form_helper
INFO - 2018-10-25 14:14:11 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:14:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:14:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:14:11 --> User Agent Class Initialized
INFO - 2018-10-25 14:14:11 --> Controller Class Initialized
INFO - 2018-10-25 14:14:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:14:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:14:11 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:14:11 --> Pixel_Model class loaded
INFO - 2018-10-25 14:14:11 --> Database Driver Class Initialized
INFO - 2018-10-25 14:14:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:14:11 --> Form Validation Class Initialized
INFO - 2018-10-25 14:14:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-25 14:14:11 --> Database Driver Class Initialized
INFO - 2018-10-25 14:14:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:14:11 --> Config Class Initialized
INFO - 2018-10-25 14:14:11 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:14:11 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:14:11 --> Utf8 Class Initialized
INFO - 2018-10-25 14:14:11 --> URI Class Initialized
INFO - 2018-10-25 14:14:11 --> Router Class Initialized
INFO - 2018-10-25 14:14:11 --> Output Class Initialized
INFO - 2018-10-25 14:14:11 --> Security Class Initialized
DEBUG - 2018-10-25 14:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:14:11 --> CSRF cookie sent
INFO - 2018-10-25 14:14:11 --> Input Class Initialized
INFO - 2018-10-25 14:14:11 --> Language Class Initialized
INFO - 2018-10-25 14:14:11 --> Loader Class Initialized
INFO - 2018-10-25 14:14:11 --> Helper loaded: url_helper
INFO - 2018-10-25 14:14:11 --> Helper loaded: form_helper
INFO - 2018-10-25 14:14:11 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:14:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:14:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:14:11 --> User Agent Class Initialized
INFO - 2018-10-25 14:14:11 --> Controller Class Initialized
INFO - 2018-10-25 14:14:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:14:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:14:11 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:14:11 --> Pixel_Model class loaded
INFO - 2018-10-25 14:14:12 --> Database Driver Class Initialized
INFO - 2018-10-25 14:14:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:14:12 --> Database Driver Class Initialized
INFO - 2018-10-25 14:14:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:14:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-25 14:14:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-25 14:14:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-25 14:14:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-25 14:14:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-25 14:14:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-25 14:14:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/home_value.php
INFO - 2018-10-25 14:14:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-25 14:14:12 --> Final output sent to browser
DEBUG - 2018-10-25 14:14:12 --> Total execution time: 0.4620
INFO - 2018-10-25 14:14:14 --> Config Class Initialized
INFO - 2018-10-25 14:14:14 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:14:14 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:14:14 --> Utf8 Class Initialized
INFO - 2018-10-25 14:14:15 --> URI Class Initialized
INFO - 2018-10-25 14:14:15 --> Router Class Initialized
INFO - 2018-10-25 14:14:15 --> Output Class Initialized
INFO - 2018-10-25 14:14:15 --> Security Class Initialized
DEBUG - 2018-10-25 14:14:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:14:15 --> CSRF cookie sent
INFO - 2018-10-25 14:14:15 --> CSRF token verified
INFO - 2018-10-25 14:14:15 --> Input Class Initialized
INFO - 2018-10-25 14:14:15 --> Language Class Initialized
INFO - 2018-10-25 14:14:15 --> Loader Class Initialized
INFO - 2018-10-25 14:14:15 --> Helper loaded: url_helper
INFO - 2018-10-25 14:14:15 --> Helper loaded: form_helper
INFO - 2018-10-25 14:14:15 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:14:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:14:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:14:15 --> User Agent Class Initialized
INFO - 2018-10-25 14:14:15 --> Controller Class Initialized
INFO - 2018-10-25 14:14:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:14:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:14:15 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:14:15 --> Pixel_Model class loaded
INFO - 2018-10-25 14:14:15 --> Database Driver Class Initialized
INFO - 2018-10-25 14:14:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:14:15 --> Form Validation Class Initialized
INFO - 2018-10-25 14:14:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-25 14:14:15 --> Database Driver Class Initialized
INFO - 2018-10-25 14:14:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:14:15 --> Config Class Initialized
INFO - 2018-10-25 14:14:15 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:14:15 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:14:15 --> Utf8 Class Initialized
INFO - 2018-10-25 14:14:15 --> URI Class Initialized
INFO - 2018-10-25 14:14:15 --> Router Class Initialized
INFO - 2018-10-25 14:14:15 --> Output Class Initialized
INFO - 2018-10-25 14:14:15 --> Security Class Initialized
DEBUG - 2018-10-25 14:14:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:14:15 --> CSRF cookie sent
INFO - 2018-10-25 14:14:15 --> Input Class Initialized
INFO - 2018-10-25 14:14:15 --> Language Class Initialized
INFO - 2018-10-25 14:14:15 --> Loader Class Initialized
INFO - 2018-10-25 14:14:15 --> Helper loaded: url_helper
INFO - 2018-10-25 14:14:15 --> Helper loaded: form_helper
INFO - 2018-10-25 14:14:15 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:14:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:14:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:14:15 --> User Agent Class Initialized
INFO - 2018-10-25 14:14:15 --> Controller Class Initialized
INFO - 2018-10-25 14:14:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:14:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:14:15 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:14:15 --> Pixel_Model class loaded
INFO - 2018-10-25 14:14:15 --> Database Driver Class Initialized
INFO - 2018-10-25 14:14:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:14:15 --> Database Driver Class Initialized
INFO - 2018-10-25 14:14:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:14:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-25 14:14:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-25 14:14:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-25 14:14:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-25 14:14:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-25 14:14:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-25 14:14:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/merriage_home_title.php
INFO - 2018-10-25 14:14:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-25 14:14:15 --> Final output sent to browser
DEBUG - 2018-10-25 14:14:15 --> Total execution time: 0.4347
INFO - 2018-10-25 14:14:17 --> Config Class Initialized
INFO - 2018-10-25 14:14:17 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:14:17 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:14:17 --> Utf8 Class Initialized
INFO - 2018-10-25 14:14:17 --> URI Class Initialized
INFO - 2018-10-25 14:14:17 --> Router Class Initialized
INFO - 2018-10-25 14:14:17 --> Output Class Initialized
INFO - 2018-10-25 14:14:17 --> Security Class Initialized
DEBUG - 2018-10-25 14:14:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:14:17 --> CSRF cookie sent
INFO - 2018-10-25 14:14:17 --> CSRF token verified
INFO - 2018-10-25 14:14:17 --> Input Class Initialized
INFO - 2018-10-25 14:14:17 --> Language Class Initialized
INFO - 2018-10-25 14:14:17 --> Loader Class Initialized
INFO - 2018-10-25 14:14:17 --> Helper loaded: url_helper
INFO - 2018-10-25 14:14:17 --> Helper loaded: form_helper
INFO - 2018-10-25 14:14:17 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:14:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:14:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:14:17 --> User Agent Class Initialized
INFO - 2018-10-25 14:14:17 --> Controller Class Initialized
INFO - 2018-10-25 14:14:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:14:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:14:17 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:14:17 --> Pixel_Model class loaded
INFO - 2018-10-25 14:14:17 --> Database Driver Class Initialized
INFO - 2018-10-25 14:14:17 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:14:17 --> Form Validation Class Initialized
INFO - 2018-10-25 14:14:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-25 14:14:17 --> Database Driver Class Initialized
INFO - 2018-10-25 14:14:17 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:14:17 --> Config Class Initialized
INFO - 2018-10-25 14:14:17 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:14:17 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:14:17 --> Utf8 Class Initialized
INFO - 2018-10-25 14:14:17 --> URI Class Initialized
INFO - 2018-10-25 14:14:17 --> Router Class Initialized
INFO - 2018-10-25 14:14:17 --> Output Class Initialized
INFO - 2018-10-25 14:14:17 --> Security Class Initialized
DEBUG - 2018-10-25 14:14:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:14:17 --> CSRF cookie sent
INFO - 2018-10-25 14:14:17 --> Input Class Initialized
INFO - 2018-10-25 14:14:17 --> Language Class Initialized
INFO - 2018-10-25 14:14:17 --> Loader Class Initialized
INFO - 2018-10-25 14:14:17 --> Helper loaded: url_helper
INFO - 2018-10-25 14:14:17 --> Helper loaded: form_helper
INFO - 2018-10-25 14:14:17 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:14:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:14:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:14:17 --> User Agent Class Initialized
INFO - 2018-10-25 14:14:17 --> Controller Class Initialized
INFO - 2018-10-25 14:14:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:14:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:14:17 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:14:17 --> Pixel_Model class loaded
INFO - 2018-10-25 14:14:17 --> Database Driver Class Initialized
INFO - 2018-10-25 14:14:17 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:14:17 --> Database Driver Class Initialized
INFO - 2018-10-25 14:14:17 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:14:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-25 14:14:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-25 14:14:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-25 14:14:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-25 14:14:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-25 14:14:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-25 14:14:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/financial.php
INFO - 2018-10-25 14:14:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-25 14:14:17 --> Final output sent to browser
DEBUG - 2018-10-25 14:14:18 --> Total execution time: 0.4354
INFO - 2018-10-25 14:14:19 --> Config Class Initialized
INFO - 2018-10-25 14:14:19 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:14:19 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:14:19 --> Utf8 Class Initialized
INFO - 2018-10-25 14:14:19 --> URI Class Initialized
INFO - 2018-10-25 14:14:19 --> Router Class Initialized
INFO - 2018-10-25 14:14:19 --> Output Class Initialized
INFO - 2018-10-25 14:14:19 --> Security Class Initialized
DEBUG - 2018-10-25 14:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:14:19 --> CSRF cookie sent
INFO - 2018-10-25 14:14:19 --> CSRF token verified
INFO - 2018-10-25 14:14:19 --> Input Class Initialized
INFO - 2018-10-25 14:14:19 --> Language Class Initialized
INFO - 2018-10-25 14:14:19 --> Loader Class Initialized
INFO - 2018-10-25 14:14:19 --> Helper loaded: url_helper
INFO - 2018-10-25 14:14:19 --> Helper loaded: form_helper
INFO - 2018-10-25 14:14:19 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:14:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:14:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:14:19 --> User Agent Class Initialized
INFO - 2018-10-25 14:14:19 --> Controller Class Initialized
INFO - 2018-10-25 14:14:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:14:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:14:19 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:14:19 --> Pixel_Model class loaded
INFO - 2018-10-25 14:14:19 --> Database Driver Class Initialized
INFO - 2018-10-25 14:14:19 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:14:19 --> Form Validation Class Initialized
INFO - 2018-10-25 14:14:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-25 14:14:19 --> Database Driver Class Initialized
INFO - 2018-10-25 14:14:19 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:14:19 --> Config Class Initialized
INFO - 2018-10-25 14:14:19 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:14:19 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:14:19 --> Utf8 Class Initialized
INFO - 2018-10-25 14:14:19 --> URI Class Initialized
INFO - 2018-10-25 14:14:19 --> Router Class Initialized
INFO - 2018-10-25 14:14:19 --> Output Class Initialized
INFO - 2018-10-25 14:14:19 --> Security Class Initialized
DEBUG - 2018-10-25 14:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:14:19 --> CSRF cookie sent
INFO - 2018-10-25 14:14:19 --> Input Class Initialized
INFO - 2018-10-25 14:14:19 --> Language Class Initialized
INFO - 2018-10-25 14:14:19 --> Loader Class Initialized
INFO - 2018-10-25 14:14:19 --> Helper loaded: url_helper
INFO - 2018-10-25 14:14:19 --> Helper loaded: form_helper
INFO - 2018-10-25 14:14:19 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:14:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:14:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:14:19 --> User Agent Class Initialized
INFO - 2018-10-25 14:14:19 --> Controller Class Initialized
INFO - 2018-10-25 14:14:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:14:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:14:20 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:14:20 --> Pixel_Model class loaded
INFO - 2018-10-25 14:14:20 --> Database Driver Class Initialized
INFO - 2018-10-25 14:14:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:14:20 --> Database Driver Class Initialized
INFO - 2018-10-25 14:14:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:14:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-25 14:14:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-25 14:14:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-25 14:14:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-25 14:14:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/risk_report.php
INFO - 2018-10-25 14:14:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-25 14:14:20 --> Final output sent to browser
DEBUG - 2018-10-25 14:14:20 --> Total execution time: 0.4278
INFO - 2018-10-25 14:14:21 --> Config Class Initialized
INFO - 2018-10-25 14:14:21 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:14:21 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:14:21 --> Utf8 Class Initialized
INFO - 2018-10-25 14:14:21 --> URI Class Initialized
INFO - 2018-10-25 14:14:21 --> Router Class Initialized
INFO - 2018-10-25 14:14:21 --> Output Class Initialized
INFO - 2018-10-25 14:14:21 --> Security Class Initialized
DEBUG - 2018-10-25 14:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:14:22 --> CSRF cookie sent
INFO - 2018-10-25 14:14:22 --> Input Class Initialized
INFO - 2018-10-25 14:14:22 --> Language Class Initialized
INFO - 2018-10-25 14:14:22 --> Loader Class Initialized
INFO - 2018-10-25 14:14:22 --> Helper loaded: url_helper
INFO - 2018-10-25 14:14:22 --> Helper loaded: form_helper
INFO - 2018-10-25 14:14:22 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:14:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:14:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:14:22 --> User Agent Class Initialized
INFO - 2018-10-25 14:14:22 --> Controller Class Initialized
INFO - 2018-10-25 14:14:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:14:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:14:22 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:14:22 --> Pixel_Model class loaded
INFO - 2018-10-25 14:14:22 --> Database Driver Class Initialized
INFO - 2018-10-25 14:14:22 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:14:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-25 14:14:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-25 14:14:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-25 14:14:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-25 14:14:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-25 14:14:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-25 14:14:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-25 14:14:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-25 14:14:22 --> Final output sent to browser
DEBUG - 2018-10-25 14:14:22 --> Total execution time: 0.4193
INFO - 2018-10-25 14:14:24 --> Config Class Initialized
INFO - 2018-10-25 14:14:24 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:14:24 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:14:24 --> Utf8 Class Initialized
INFO - 2018-10-25 14:14:24 --> URI Class Initialized
INFO - 2018-10-25 14:14:24 --> Router Class Initialized
INFO - 2018-10-25 14:14:24 --> Output Class Initialized
INFO - 2018-10-25 14:14:24 --> Security Class Initialized
DEBUG - 2018-10-25 14:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:14:24 --> CSRF cookie sent
INFO - 2018-10-25 14:14:24 --> CSRF token verified
INFO - 2018-10-25 14:14:24 --> Input Class Initialized
INFO - 2018-10-25 14:14:24 --> Language Class Initialized
INFO - 2018-10-25 14:14:24 --> Loader Class Initialized
INFO - 2018-10-25 14:14:24 --> Helper loaded: url_helper
INFO - 2018-10-25 14:14:24 --> Helper loaded: form_helper
INFO - 2018-10-25 14:14:24 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:14:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:14:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:14:24 --> User Agent Class Initialized
INFO - 2018-10-25 14:14:24 --> Controller Class Initialized
INFO - 2018-10-25 14:14:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:14:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:14:24 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:14:24 --> Pixel_Model class loaded
INFO - 2018-10-25 14:14:24 --> Database Driver Class Initialized
INFO - 2018-10-25 14:14:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:14:24 --> Database Driver Class Initialized
INFO - 2018-10-25 14:14:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:14:24 --> Config Class Initialized
INFO - 2018-10-25 14:14:24 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:14:24 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:14:24 --> Utf8 Class Initialized
INFO - 2018-10-25 14:14:24 --> URI Class Initialized
INFO - 2018-10-25 14:14:24 --> Router Class Initialized
INFO - 2018-10-25 14:14:24 --> Output Class Initialized
INFO - 2018-10-25 14:14:24 --> Security Class Initialized
DEBUG - 2018-10-25 14:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:14:24 --> CSRF cookie sent
INFO - 2018-10-25 14:14:24 --> Input Class Initialized
INFO - 2018-10-25 14:14:24 --> Language Class Initialized
INFO - 2018-10-25 14:14:24 --> Loader Class Initialized
INFO - 2018-10-25 14:14:24 --> Helper loaded: url_helper
INFO - 2018-10-25 14:14:24 --> Helper loaded: form_helper
INFO - 2018-10-25 14:14:24 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:14:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:14:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:14:24 --> User Agent Class Initialized
INFO - 2018-10-25 14:14:24 --> Controller Class Initialized
INFO - 2018-10-25 14:14:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:14:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:14:24 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:14:24 --> Pixel_Model class loaded
INFO - 2018-10-25 14:14:24 --> Database Driver Class Initialized
INFO - 2018-10-25 14:14:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:14:24 --> Config Class Initialized
INFO - 2018-10-25 14:14:24 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:14:24 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:14:24 --> Utf8 Class Initialized
INFO - 2018-10-25 14:14:24 --> URI Class Initialized
INFO - 2018-10-25 14:14:24 --> Router Class Initialized
INFO - 2018-10-25 14:14:24 --> Output Class Initialized
INFO - 2018-10-25 14:14:24 --> Security Class Initialized
DEBUG - 2018-10-25 14:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:14:24 --> CSRF cookie sent
INFO - 2018-10-25 14:14:24 --> Input Class Initialized
INFO - 2018-10-25 14:14:24 --> Language Class Initialized
INFO - 2018-10-25 14:14:24 --> Loader Class Initialized
INFO - 2018-10-25 14:14:24 --> Helper loaded: url_helper
INFO - 2018-10-25 14:14:24 --> Helper loaded: form_helper
INFO - 2018-10-25 14:14:24 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:14:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:14:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:14:24 --> User Agent Class Initialized
INFO - 2018-10-25 14:14:24 --> Controller Class Initialized
INFO - 2018-10-25 14:14:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:14:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:14:25 --> Helper loaded: custom_helper
DEBUG - 2018-10-25 14:14:25 --> Config file loaded: E:\xampp7\htdocs\famiquity\application\config/recaptcha.php
INFO - 2018-10-25 14:14:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-25 14:14:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-25 14:14:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-25 14:14:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
ERROR - 2018-10-25 14:14:25 --> Could not find the language line "req_email"
INFO - 2018-10-25 14:14:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\myaccount/signin.php
INFO - 2018-10-25 14:14:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-25 14:14:25 --> Final output sent to browser
DEBUG - 2018-10-25 14:14:25 --> Total execution time: 0.3508
INFO - 2018-10-25 14:14:58 --> Config Class Initialized
INFO - 2018-10-25 14:14:58 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:14:58 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:14:58 --> Utf8 Class Initialized
INFO - 2018-10-25 14:14:58 --> URI Class Initialized
INFO - 2018-10-25 14:14:58 --> Router Class Initialized
INFO - 2018-10-25 14:14:58 --> Output Class Initialized
INFO - 2018-10-25 14:14:58 --> Security Class Initialized
DEBUG - 2018-10-25 14:14:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:14:58 --> CSRF cookie sent
INFO - 2018-10-25 14:14:58 --> Input Class Initialized
INFO - 2018-10-25 14:14:58 --> Language Class Initialized
INFO - 2018-10-25 14:14:58 --> Loader Class Initialized
INFO - 2018-10-25 14:14:58 --> Helper loaded: url_helper
INFO - 2018-10-25 14:14:58 --> Helper loaded: form_helper
INFO - 2018-10-25 14:14:58 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:14:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:14:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:14:58 --> User Agent Class Initialized
INFO - 2018-10-25 14:14:58 --> Controller Class Initialized
INFO - 2018-10-25 14:14:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:14:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:14:58 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:14:58 --> Pixel_Model class loaded
INFO - 2018-10-25 14:14:58 --> Database Driver Class Initialized
INFO - 2018-10-25 14:14:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:14:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-25 14:14:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-25 14:14:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-25 14:14:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-25 14:14:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-25 14:14:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-25 14:14:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-25 14:14:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-25 14:14:58 --> Final output sent to browser
DEBUG - 2018-10-25 14:14:58 --> Total execution time: 0.4394
INFO - 2018-10-25 14:14:59 --> Config Class Initialized
INFO - 2018-10-25 14:14:59 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:14:59 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:14:59 --> Utf8 Class Initialized
INFO - 2018-10-25 14:14:59 --> URI Class Initialized
INFO - 2018-10-25 14:14:59 --> Router Class Initialized
INFO - 2018-10-25 14:14:59 --> Output Class Initialized
INFO - 2018-10-25 14:14:59 --> Security Class Initialized
DEBUG - 2018-10-25 14:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:14:59 --> CSRF cookie sent
INFO - 2018-10-25 14:14:59 --> Input Class Initialized
INFO - 2018-10-25 14:14:59 --> Language Class Initialized
INFO - 2018-10-25 14:14:59 --> Loader Class Initialized
INFO - 2018-10-25 14:14:59 --> Helper loaded: url_helper
INFO - 2018-10-25 14:14:59 --> Helper loaded: form_helper
INFO - 2018-10-25 14:14:59 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:14:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:14:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:14:59 --> User Agent Class Initialized
INFO - 2018-10-25 14:14:59 --> Controller Class Initialized
INFO - 2018-10-25 14:14:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:14:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:14:59 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:14:59 --> Pixel_Model class loaded
INFO - 2018-10-25 14:14:59 --> Database Driver Class Initialized
INFO - 2018-10-25 14:14:59 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:14:59 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-25 14:14:59 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-25 14:14:59 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-25 14:14:59 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-25 14:14:59 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-25 14:14:59 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-25 14:14:59 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-25 14:14:59 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-25 14:14:59 --> Final output sent to browser
DEBUG - 2018-10-25 14:14:59 --> Total execution time: 0.4373
INFO - 2018-10-25 14:17:44 --> Config Class Initialized
INFO - 2018-10-25 14:17:44 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:17:44 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:17:44 --> Utf8 Class Initialized
INFO - 2018-10-25 14:17:44 --> URI Class Initialized
INFO - 2018-10-25 14:17:44 --> Router Class Initialized
INFO - 2018-10-25 14:17:44 --> Output Class Initialized
INFO - 2018-10-25 14:17:44 --> Security Class Initialized
DEBUG - 2018-10-25 14:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:17:44 --> CSRF cookie sent
INFO - 2018-10-25 14:17:44 --> CSRF token verified
INFO - 2018-10-25 14:17:44 --> Input Class Initialized
INFO - 2018-10-25 14:17:44 --> Language Class Initialized
INFO - 2018-10-25 14:17:44 --> Loader Class Initialized
INFO - 2018-10-25 14:17:44 --> Helper loaded: url_helper
INFO - 2018-10-25 14:17:44 --> Helper loaded: form_helper
INFO - 2018-10-25 14:17:44 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:17:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:17:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:17:44 --> User Agent Class Initialized
INFO - 2018-10-25 14:17:44 --> Controller Class Initialized
INFO - 2018-10-25 14:17:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:17:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:17:44 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:17:44 --> Pixel_Model class loaded
INFO - 2018-10-25 14:17:44 --> Database Driver Class Initialized
INFO - 2018-10-25 14:17:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:17:44 --> Database Driver Class Initialized
INFO - 2018-10-25 14:17:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:17:44 --> Config Class Initialized
INFO - 2018-10-25 14:17:44 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:17:45 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:17:45 --> Utf8 Class Initialized
INFO - 2018-10-25 14:17:45 --> URI Class Initialized
INFO - 2018-10-25 14:17:45 --> Router Class Initialized
INFO - 2018-10-25 14:17:45 --> Output Class Initialized
INFO - 2018-10-25 14:17:45 --> Security Class Initialized
DEBUG - 2018-10-25 14:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:17:45 --> CSRF cookie sent
INFO - 2018-10-25 14:17:45 --> Input Class Initialized
INFO - 2018-10-25 14:17:45 --> Language Class Initialized
INFO - 2018-10-25 14:17:45 --> Loader Class Initialized
INFO - 2018-10-25 14:17:45 --> Helper loaded: url_helper
INFO - 2018-10-25 14:17:45 --> Helper loaded: form_helper
INFO - 2018-10-25 14:17:45 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:17:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:17:45 --> User Agent Class Initialized
INFO - 2018-10-25 14:17:45 --> Controller Class Initialized
INFO - 2018-10-25 14:17:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:17:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:17:45 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:17:45 --> Pixel_Model class loaded
INFO - 2018-10-25 14:17:45 --> Database Driver Class Initialized
INFO - 2018-10-25 14:17:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:17:45 --> Database Driver Class Initialized
INFO - 2018-10-25 14:17:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:17:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-25 14:17:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-25 14:17:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-25 14:17:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-25 14:17:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-25 14:17:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-25 14:17:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-25 14:17:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-25 14:17:45 --> Final output sent to browser
DEBUG - 2018-10-25 14:17:45 --> Total execution time: 0.4493
INFO - 2018-10-25 14:17:48 --> Config Class Initialized
INFO - 2018-10-25 14:17:48 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:17:48 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:17:48 --> Utf8 Class Initialized
INFO - 2018-10-25 14:17:48 --> URI Class Initialized
INFO - 2018-10-25 14:17:48 --> Router Class Initialized
INFO - 2018-10-25 14:17:48 --> Output Class Initialized
INFO - 2018-10-25 14:17:48 --> Security Class Initialized
DEBUG - 2018-10-25 14:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:17:48 --> CSRF cookie sent
INFO - 2018-10-25 14:17:48 --> CSRF token verified
INFO - 2018-10-25 14:17:48 --> Input Class Initialized
INFO - 2018-10-25 14:17:48 --> Language Class Initialized
INFO - 2018-10-25 14:17:48 --> Loader Class Initialized
INFO - 2018-10-25 14:17:48 --> Helper loaded: url_helper
INFO - 2018-10-25 14:17:48 --> Helper loaded: form_helper
INFO - 2018-10-25 14:17:48 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:17:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:17:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:17:48 --> User Agent Class Initialized
INFO - 2018-10-25 14:17:48 --> Controller Class Initialized
INFO - 2018-10-25 14:17:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:17:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:17:48 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:17:48 --> Pixel_Model class loaded
INFO - 2018-10-25 14:17:48 --> Database Driver Class Initialized
INFO - 2018-10-25 14:17:48 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:17:48 --> Form Validation Class Initialized
INFO - 2018-10-25 14:17:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-25 14:17:48 --> Database Driver Class Initialized
INFO - 2018-10-25 14:17:48 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:17:48 --> Config Class Initialized
INFO - 2018-10-25 14:17:48 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:17:48 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:17:48 --> Utf8 Class Initialized
INFO - 2018-10-25 14:17:48 --> URI Class Initialized
INFO - 2018-10-25 14:17:48 --> Router Class Initialized
INFO - 2018-10-25 14:17:48 --> Output Class Initialized
INFO - 2018-10-25 14:17:48 --> Security Class Initialized
DEBUG - 2018-10-25 14:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:17:48 --> CSRF cookie sent
INFO - 2018-10-25 14:17:48 --> Input Class Initialized
INFO - 2018-10-25 14:17:48 --> Language Class Initialized
INFO - 2018-10-25 14:17:48 --> Loader Class Initialized
INFO - 2018-10-25 14:17:48 --> Helper loaded: url_helper
INFO - 2018-10-25 14:17:48 --> Helper loaded: form_helper
INFO - 2018-10-25 14:17:48 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:17:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:17:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:17:48 --> User Agent Class Initialized
INFO - 2018-10-25 14:17:48 --> Controller Class Initialized
INFO - 2018-10-25 14:17:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:17:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:17:49 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:17:49 --> Pixel_Model class loaded
INFO - 2018-10-25 14:17:49 --> Database Driver Class Initialized
INFO - 2018-10-25 14:17:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:17:49 --> Database Driver Class Initialized
INFO - 2018-10-25 14:17:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:17:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-25 14:17:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-25 14:17:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-25 14:17:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-25 14:17:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-25 14:17:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-25 14:17:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/your_job.php
INFO - 2018-10-25 14:17:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-25 14:17:49 --> Final output sent to browser
DEBUG - 2018-10-25 14:17:49 --> Total execution time: 0.4771
INFO - 2018-10-25 14:17:49 --> Config Class Initialized
INFO - 2018-10-25 14:17:50 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:17:50 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:17:50 --> Utf8 Class Initialized
INFO - 2018-10-25 14:17:50 --> URI Class Initialized
INFO - 2018-10-25 14:17:50 --> Router Class Initialized
INFO - 2018-10-25 14:17:50 --> Output Class Initialized
INFO - 2018-10-25 14:17:50 --> Security Class Initialized
DEBUG - 2018-10-25 14:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:17:50 --> CSRF cookie sent
INFO - 2018-10-25 14:17:50 --> CSRF token verified
INFO - 2018-10-25 14:17:50 --> Input Class Initialized
INFO - 2018-10-25 14:17:50 --> Language Class Initialized
INFO - 2018-10-25 14:17:50 --> Loader Class Initialized
INFO - 2018-10-25 14:17:50 --> Helper loaded: url_helper
INFO - 2018-10-25 14:17:50 --> Helper loaded: form_helper
INFO - 2018-10-25 14:17:50 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:17:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:17:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:17:50 --> User Agent Class Initialized
INFO - 2018-10-25 14:17:50 --> Controller Class Initialized
INFO - 2018-10-25 14:17:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:17:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:17:50 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:17:50 --> Pixel_Model class loaded
INFO - 2018-10-25 14:17:50 --> Database Driver Class Initialized
INFO - 2018-10-25 14:17:50 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:17:50 --> Form Validation Class Initialized
INFO - 2018-10-25 14:17:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-25 14:17:50 --> Database Driver Class Initialized
INFO - 2018-10-25 14:17:50 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:17:50 --> Config Class Initialized
INFO - 2018-10-25 14:17:50 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:17:50 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:17:50 --> Utf8 Class Initialized
INFO - 2018-10-25 14:17:50 --> URI Class Initialized
INFO - 2018-10-25 14:17:50 --> Router Class Initialized
INFO - 2018-10-25 14:17:50 --> Output Class Initialized
INFO - 2018-10-25 14:17:50 --> Security Class Initialized
DEBUG - 2018-10-25 14:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:17:50 --> CSRF cookie sent
INFO - 2018-10-25 14:17:50 --> Input Class Initialized
INFO - 2018-10-25 14:17:50 --> Language Class Initialized
INFO - 2018-10-25 14:17:50 --> Loader Class Initialized
INFO - 2018-10-25 14:17:50 --> Helper loaded: url_helper
INFO - 2018-10-25 14:17:50 --> Helper loaded: form_helper
INFO - 2018-10-25 14:17:50 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:17:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:17:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:17:50 --> User Agent Class Initialized
INFO - 2018-10-25 14:17:50 --> Controller Class Initialized
INFO - 2018-10-25 14:17:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:17:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:17:50 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:17:50 --> Pixel_Model class loaded
INFO - 2018-10-25 14:17:50 --> Database Driver Class Initialized
INFO - 2018-10-25 14:17:50 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:17:50 --> Database Driver Class Initialized
INFO - 2018-10-25 14:17:50 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:17:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-25 14:17:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-25 14:17:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner.php
INFO - 2018-10-25 14:17:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-25 14:17:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-25 14:17:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-25 14:17:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-25 14:17:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/relation_ship_status.php
INFO - 2018-10-25 14:17:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-25 14:17:50 --> Final output sent to browser
DEBUG - 2018-10-25 14:17:50 --> Total execution time: 0.4960
INFO - 2018-10-25 14:17:51 --> Config Class Initialized
INFO - 2018-10-25 14:17:51 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:17:51 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:17:51 --> Utf8 Class Initialized
INFO - 2018-10-25 14:17:51 --> URI Class Initialized
INFO - 2018-10-25 14:17:51 --> Router Class Initialized
INFO - 2018-10-25 14:17:51 --> Output Class Initialized
INFO - 2018-10-25 14:17:51 --> Security Class Initialized
DEBUG - 2018-10-25 14:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:17:51 --> CSRF cookie sent
INFO - 2018-10-25 14:17:51 --> CSRF token verified
INFO - 2018-10-25 14:17:51 --> Input Class Initialized
INFO - 2018-10-25 14:17:51 --> Language Class Initialized
INFO - 2018-10-25 14:17:51 --> Loader Class Initialized
INFO - 2018-10-25 14:17:51 --> Helper loaded: url_helper
INFO - 2018-10-25 14:17:51 --> Helper loaded: form_helper
INFO - 2018-10-25 14:17:51 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:17:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:17:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:17:51 --> User Agent Class Initialized
INFO - 2018-10-25 14:17:51 --> Controller Class Initialized
INFO - 2018-10-25 14:17:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:17:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:17:51 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:17:51 --> Pixel_Model class loaded
INFO - 2018-10-25 14:17:51 --> Database Driver Class Initialized
INFO - 2018-10-25 14:17:51 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:17:51 --> Form Validation Class Initialized
INFO - 2018-10-25 14:17:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-25 14:17:51 --> Database Driver Class Initialized
INFO - 2018-10-25 14:17:51 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:17:51 --> Config Class Initialized
INFO - 2018-10-25 14:17:51 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:17:51 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:17:51 --> Utf8 Class Initialized
INFO - 2018-10-25 14:17:52 --> URI Class Initialized
INFO - 2018-10-25 14:17:52 --> Router Class Initialized
INFO - 2018-10-25 14:17:52 --> Output Class Initialized
INFO - 2018-10-25 14:17:52 --> Security Class Initialized
DEBUG - 2018-10-25 14:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:17:52 --> CSRF cookie sent
INFO - 2018-10-25 14:17:52 --> Input Class Initialized
INFO - 2018-10-25 14:17:52 --> Language Class Initialized
INFO - 2018-10-25 14:17:52 --> Loader Class Initialized
INFO - 2018-10-25 14:17:52 --> Helper loaded: url_helper
INFO - 2018-10-25 14:17:52 --> Helper loaded: form_helper
INFO - 2018-10-25 14:17:52 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:17:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:17:52 --> User Agent Class Initialized
INFO - 2018-10-25 14:17:52 --> Controller Class Initialized
INFO - 2018-10-25 14:17:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:17:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:17:52 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:17:52 --> Pixel_Model class loaded
INFO - 2018-10-25 14:17:52 --> Database Driver Class Initialized
INFO - 2018-10-25 14:17:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:17:52 --> Database Driver Class Initialized
INFO - 2018-10-25 14:17:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:17:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-25 14:17:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-25 14:17:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-25 14:17:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-25 14:17:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-25 14:17:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-25 14:17:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/income.php
INFO - 2018-10-25 14:17:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-25 14:17:52 --> Final output sent to browser
DEBUG - 2018-10-25 14:17:52 --> Total execution time: 0.4892
INFO - 2018-10-25 14:17:53 --> Config Class Initialized
INFO - 2018-10-25 14:17:53 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:17:53 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:17:53 --> Utf8 Class Initialized
INFO - 2018-10-25 14:17:53 --> URI Class Initialized
INFO - 2018-10-25 14:17:53 --> Router Class Initialized
INFO - 2018-10-25 14:17:53 --> Output Class Initialized
INFO - 2018-10-25 14:17:53 --> Security Class Initialized
DEBUG - 2018-10-25 14:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:17:53 --> CSRF cookie sent
INFO - 2018-10-25 14:17:53 --> CSRF token verified
INFO - 2018-10-25 14:17:53 --> Input Class Initialized
INFO - 2018-10-25 14:17:53 --> Language Class Initialized
INFO - 2018-10-25 14:17:53 --> Loader Class Initialized
INFO - 2018-10-25 14:17:53 --> Helper loaded: url_helper
INFO - 2018-10-25 14:17:53 --> Helper loaded: form_helper
INFO - 2018-10-25 14:17:53 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:17:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:17:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:17:53 --> User Agent Class Initialized
INFO - 2018-10-25 14:17:53 --> Controller Class Initialized
INFO - 2018-10-25 14:17:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:17:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:17:53 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:17:53 --> Pixel_Model class loaded
INFO - 2018-10-25 14:17:53 --> Database Driver Class Initialized
INFO - 2018-10-25 14:17:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:17:53 --> Form Validation Class Initialized
INFO - 2018-10-25 14:17:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-25 14:17:53 --> Database Driver Class Initialized
INFO - 2018-10-25 14:17:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:17:54 --> Config Class Initialized
INFO - 2018-10-25 14:17:54 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:17:54 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:17:54 --> Utf8 Class Initialized
INFO - 2018-10-25 14:17:54 --> URI Class Initialized
INFO - 2018-10-25 14:17:54 --> Router Class Initialized
INFO - 2018-10-25 14:17:54 --> Output Class Initialized
INFO - 2018-10-25 14:17:54 --> Security Class Initialized
DEBUG - 2018-10-25 14:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:17:54 --> CSRF cookie sent
INFO - 2018-10-25 14:17:54 --> Input Class Initialized
INFO - 2018-10-25 14:17:54 --> Language Class Initialized
INFO - 2018-10-25 14:17:54 --> Loader Class Initialized
INFO - 2018-10-25 14:17:54 --> Helper loaded: url_helper
INFO - 2018-10-25 14:17:54 --> Helper loaded: form_helper
INFO - 2018-10-25 14:17:54 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:17:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:17:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:17:54 --> User Agent Class Initialized
INFO - 2018-10-25 14:17:54 --> Controller Class Initialized
INFO - 2018-10-25 14:17:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:17:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:17:54 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:17:54 --> Pixel_Model class loaded
INFO - 2018-10-25 14:17:54 --> Database Driver Class Initialized
INFO - 2018-10-25 14:17:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:17:54 --> Database Driver Class Initialized
INFO - 2018-10-25 14:17:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:17:54 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-25 14:17:54 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-25 14:17:54 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-25 14:17:54 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-25 14:17:54 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-25 14:17:54 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-25 14:17:54 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/marriage.php
INFO - 2018-10-25 14:17:54 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-25 14:17:54 --> Final output sent to browser
DEBUG - 2018-10-25 14:17:54 --> Total execution time: 0.4522
INFO - 2018-10-25 14:17:55 --> Config Class Initialized
INFO - 2018-10-25 14:17:55 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:17:55 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:17:55 --> Utf8 Class Initialized
INFO - 2018-10-25 14:17:55 --> URI Class Initialized
INFO - 2018-10-25 14:17:55 --> Router Class Initialized
INFO - 2018-10-25 14:17:55 --> Output Class Initialized
INFO - 2018-10-25 14:17:55 --> Security Class Initialized
DEBUG - 2018-10-25 14:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:17:55 --> CSRF cookie sent
INFO - 2018-10-25 14:17:55 --> CSRF token verified
INFO - 2018-10-25 14:17:55 --> Input Class Initialized
INFO - 2018-10-25 14:17:56 --> Language Class Initialized
INFO - 2018-10-25 14:17:56 --> Loader Class Initialized
INFO - 2018-10-25 14:17:56 --> Helper loaded: url_helper
INFO - 2018-10-25 14:17:56 --> Helper loaded: form_helper
INFO - 2018-10-25 14:17:56 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:17:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:17:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:17:56 --> User Agent Class Initialized
INFO - 2018-10-25 14:17:56 --> Controller Class Initialized
INFO - 2018-10-25 14:17:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:17:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:17:56 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:17:56 --> Pixel_Model class loaded
INFO - 2018-10-25 14:17:56 --> Database Driver Class Initialized
INFO - 2018-10-25 14:17:56 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:17:56 --> Form Validation Class Initialized
INFO - 2018-10-25 14:17:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-25 14:17:56 --> Database Driver Class Initialized
INFO - 2018-10-25 14:17:56 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:17:56 --> Config Class Initialized
INFO - 2018-10-25 14:17:56 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:17:56 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:17:56 --> Utf8 Class Initialized
INFO - 2018-10-25 14:17:56 --> URI Class Initialized
INFO - 2018-10-25 14:17:56 --> Router Class Initialized
INFO - 2018-10-25 14:17:56 --> Output Class Initialized
INFO - 2018-10-25 14:17:56 --> Security Class Initialized
DEBUG - 2018-10-25 14:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:17:56 --> CSRF cookie sent
INFO - 2018-10-25 14:17:56 --> Input Class Initialized
INFO - 2018-10-25 14:17:56 --> Language Class Initialized
INFO - 2018-10-25 14:17:56 --> Loader Class Initialized
INFO - 2018-10-25 14:17:56 --> Helper loaded: url_helper
INFO - 2018-10-25 14:17:56 --> Helper loaded: form_helper
INFO - 2018-10-25 14:17:56 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:17:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:17:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:17:56 --> User Agent Class Initialized
INFO - 2018-10-25 14:17:56 --> Controller Class Initialized
INFO - 2018-10-25 14:17:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:17:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:17:56 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:17:56 --> Pixel_Model class loaded
INFO - 2018-10-25 14:17:56 --> Database Driver Class Initialized
INFO - 2018-10-25 14:17:56 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:17:56 --> Database Driver Class Initialized
INFO - 2018-10-25 14:17:56 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:17:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-25 14:17:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-25 14:17:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-25 14:17:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-25 14:17:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-25 14:17:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-25 14:17:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/kids.php
INFO - 2018-10-25 14:17:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-25 14:17:56 --> Final output sent to browser
DEBUG - 2018-10-25 14:17:56 --> Total execution time: 0.4696
INFO - 2018-10-25 14:17:57 --> Config Class Initialized
INFO - 2018-10-25 14:17:57 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:17:57 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:17:57 --> Utf8 Class Initialized
INFO - 2018-10-25 14:17:57 --> URI Class Initialized
INFO - 2018-10-25 14:17:57 --> Router Class Initialized
INFO - 2018-10-25 14:17:57 --> Output Class Initialized
INFO - 2018-10-25 14:17:57 --> Security Class Initialized
DEBUG - 2018-10-25 14:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:17:57 --> CSRF cookie sent
INFO - 2018-10-25 14:17:57 --> CSRF token verified
INFO - 2018-10-25 14:17:57 --> Input Class Initialized
INFO - 2018-10-25 14:17:57 --> Language Class Initialized
INFO - 2018-10-25 14:17:57 --> Loader Class Initialized
INFO - 2018-10-25 14:17:57 --> Helper loaded: url_helper
INFO - 2018-10-25 14:17:57 --> Helper loaded: form_helper
INFO - 2018-10-25 14:17:57 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:17:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:17:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:17:57 --> User Agent Class Initialized
INFO - 2018-10-25 14:17:57 --> Controller Class Initialized
INFO - 2018-10-25 14:17:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:17:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:17:57 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:17:57 --> Pixel_Model class loaded
INFO - 2018-10-25 14:17:57 --> Database Driver Class Initialized
INFO - 2018-10-25 14:17:57 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:17:57 --> Form Validation Class Initialized
INFO - 2018-10-25 14:17:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-25 14:17:57 --> Database Driver Class Initialized
INFO - 2018-10-25 14:17:57 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:17:57 --> Config Class Initialized
INFO - 2018-10-25 14:17:57 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:17:57 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:17:57 --> Utf8 Class Initialized
INFO - 2018-10-25 14:17:57 --> URI Class Initialized
INFO - 2018-10-25 14:17:57 --> Router Class Initialized
INFO - 2018-10-25 14:17:58 --> Output Class Initialized
INFO - 2018-10-25 14:17:58 --> Security Class Initialized
DEBUG - 2018-10-25 14:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:17:58 --> CSRF cookie sent
INFO - 2018-10-25 14:17:58 --> Input Class Initialized
INFO - 2018-10-25 14:17:58 --> Language Class Initialized
INFO - 2018-10-25 14:17:58 --> Loader Class Initialized
INFO - 2018-10-25 14:17:58 --> Helper loaded: url_helper
INFO - 2018-10-25 14:17:58 --> Helper loaded: form_helper
INFO - 2018-10-25 14:17:58 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:17:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:17:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:17:58 --> User Agent Class Initialized
INFO - 2018-10-25 14:17:58 --> Controller Class Initialized
INFO - 2018-10-25 14:17:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:17:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:17:58 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:17:58 --> Pixel_Model class loaded
INFO - 2018-10-25 14:17:58 --> Database Driver Class Initialized
INFO - 2018-10-25 14:17:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:17:58 --> Database Driver Class Initialized
INFO - 2018-10-25 14:17:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:17:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-25 14:17:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-25 14:17:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-25 14:17:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-25 14:17:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-25 14:17:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-25 14:17:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/pension.php
INFO - 2018-10-25 14:17:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-25 14:17:58 --> Final output sent to browser
DEBUG - 2018-10-25 14:17:58 --> Total execution time: 0.4674
INFO - 2018-10-25 14:17:59 --> Config Class Initialized
INFO - 2018-10-25 14:17:59 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:17:59 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:17:59 --> Utf8 Class Initialized
INFO - 2018-10-25 14:17:59 --> URI Class Initialized
INFO - 2018-10-25 14:17:59 --> Router Class Initialized
INFO - 2018-10-25 14:17:59 --> Output Class Initialized
INFO - 2018-10-25 14:17:59 --> Security Class Initialized
DEBUG - 2018-10-25 14:17:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:17:59 --> CSRF cookie sent
INFO - 2018-10-25 14:17:59 --> CSRF token verified
INFO - 2018-10-25 14:17:59 --> Input Class Initialized
INFO - 2018-10-25 14:17:59 --> Language Class Initialized
INFO - 2018-10-25 14:17:59 --> Loader Class Initialized
INFO - 2018-10-25 14:17:59 --> Helper loaded: url_helper
INFO - 2018-10-25 14:17:59 --> Helper loaded: form_helper
INFO - 2018-10-25 14:17:59 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:17:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:17:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:17:59 --> User Agent Class Initialized
INFO - 2018-10-25 14:17:59 --> Controller Class Initialized
INFO - 2018-10-25 14:17:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:17:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:17:59 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:17:59 --> Pixel_Model class loaded
INFO - 2018-10-25 14:17:59 --> Database Driver Class Initialized
INFO - 2018-10-25 14:17:59 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:17:59 --> Form Validation Class Initialized
INFO - 2018-10-25 14:17:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-25 14:17:59 --> Database Driver Class Initialized
INFO - 2018-10-25 14:17:59 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:17:59 --> Config Class Initialized
INFO - 2018-10-25 14:17:59 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:17:59 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:17:59 --> Utf8 Class Initialized
INFO - 2018-10-25 14:18:00 --> URI Class Initialized
INFO - 2018-10-25 14:18:00 --> Router Class Initialized
INFO - 2018-10-25 14:18:00 --> Output Class Initialized
INFO - 2018-10-25 14:18:00 --> Security Class Initialized
DEBUG - 2018-10-25 14:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:18:00 --> CSRF cookie sent
INFO - 2018-10-25 14:18:00 --> Input Class Initialized
INFO - 2018-10-25 14:18:00 --> Language Class Initialized
INFO - 2018-10-25 14:18:00 --> Loader Class Initialized
INFO - 2018-10-25 14:18:00 --> Helper loaded: url_helper
INFO - 2018-10-25 14:18:00 --> Helper loaded: form_helper
INFO - 2018-10-25 14:18:00 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:18:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:18:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:18:00 --> User Agent Class Initialized
INFO - 2018-10-25 14:18:00 --> Controller Class Initialized
INFO - 2018-10-25 14:18:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:18:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:18:00 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:18:00 --> Pixel_Model class loaded
INFO - 2018-10-25 14:18:00 --> Database Driver Class Initialized
INFO - 2018-10-25 14:18:00 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:18:00 --> Database Driver Class Initialized
INFO - 2018-10-25 14:18:00 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:18:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-25 14:18:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-25 14:18:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-25 14:18:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-25 14:18:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-25 14:18:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-25 14:18:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/inheritance.php
INFO - 2018-10-25 14:18:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-25 14:18:00 --> Final output sent to browser
DEBUG - 2018-10-25 14:18:00 --> Total execution time: 0.4906
INFO - 2018-10-25 14:18:01 --> Config Class Initialized
INFO - 2018-10-25 14:18:01 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:18:01 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:18:01 --> Utf8 Class Initialized
INFO - 2018-10-25 14:18:01 --> URI Class Initialized
INFO - 2018-10-25 14:18:01 --> Router Class Initialized
INFO - 2018-10-25 14:18:01 --> Output Class Initialized
INFO - 2018-10-25 14:18:01 --> Security Class Initialized
DEBUG - 2018-10-25 14:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:18:01 --> CSRF cookie sent
INFO - 2018-10-25 14:18:01 --> CSRF token verified
INFO - 2018-10-25 14:18:01 --> Input Class Initialized
INFO - 2018-10-25 14:18:01 --> Language Class Initialized
INFO - 2018-10-25 14:18:01 --> Loader Class Initialized
INFO - 2018-10-25 14:18:01 --> Helper loaded: url_helper
INFO - 2018-10-25 14:18:01 --> Helper loaded: form_helper
INFO - 2018-10-25 14:18:01 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:18:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:18:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:18:01 --> User Agent Class Initialized
INFO - 2018-10-25 14:18:01 --> Controller Class Initialized
INFO - 2018-10-25 14:18:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:18:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:18:01 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:18:01 --> Pixel_Model class loaded
INFO - 2018-10-25 14:18:01 --> Database Driver Class Initialized
INFO - 2018-10-25 14:18:01 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:18:01 --> Form Validation Class Initialized
INFO - 2018-10-25 14:18:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-25 14:18:01 --> Database Driver Class Initialized
INFO - 2018-10-25 14:18:01 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:18:01 --> Config Class Initialized
INFO - 2018-10-25 14:18:01 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:18:01 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:18:01 --> Utf8 Class Initialized
INFO - 2018-10-25 14:18:01 --> URI Class Initialized
INFO - 2018-10-25 14:18:01 --> Router Class Initialized
INFO - 2018-10-25 14:18:01 --> Output Class Initialized
INFO - 2018-10-25 14:18:01 --> Security Class Initialized
DEBUG - 2018-10-25 14:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:18:01 --> CSRF cookie sent
INFO - 2018-10-25 14:18:01 --> Input Class Initialized
INFO - 2018-10-25 14:18:01 --> Language Class Initialized
INFO - 2018-10-25 14:18:01 --> Loader Class Initialized
INFO - 2018-10-25 14:18:01 --> Helper loaded: url_helper
INFO - 2018-10-25 14:18:01 --> Helper loaded: form_helper
INFO - 2018-10-25 14:18:01 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:18:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:18:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:18:02 --> User Agent Class Initialized
INFO - 2018-10-25 14:18:02 --> Controller Class Initialized
INFO - 2018-10-25 14:18:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:18:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:18:02 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:18:02 --> Pixel_Model class loaded
INFO - 2018-10-25 14:18:02 --> Database Driver Class Initialized
INFO - 2018-10-25 14:18:02 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:18:02 --> Database Driver Class Initialized
INFO - 2018-10-25 14:18:02 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:18:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-25 14:18:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-25 14:18:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-25 14:18:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-25 14:18:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-25 14:18:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-25 14:18:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/inheritance_maintained.php
INFO - 2018-10-25 14:18:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-25 14:18:02 --> Final output sent to browser
DEBUG - 2018-10-25 14:18:02 --> Total execution time: 0.4762
INFO - 2018-10-25 14:18:02 --> Config Class Initialized
INFO - 2018-10-25 14:18:02 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:18:03 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:18:03 --> Utf8 Class Initialized
INFO - 2018-10-25 14:18:03 --> URI Class Initialized
INFO - 2018-10-25 14:18:03 --> Router Class Initialized
INFO - 2018-10-25 14:18:03 --> Output Class Initialized
INFO - 2018-10-25 14:18:03 --> Security Class Initialized
DEBUG - 2018-10-25 14:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:18:03 --> CSRF cookie sent
INFO - 2018-10-25 14:18:03 --> CSRF token verified
INFO - 2018-10-25 14:18:03 --> Input Class Initialized
INFO - 2018-10-25 14:18:03 --> Language Class Initialized
INFO - 2018-10-25 14:18:03 --> Loader Class Initialized
INFO - 2018-10-25 14:18:03 --> Helper loaded: url_helper
INFO - 2018-10-25 14:18:03 --> Helper loaded: form_helper
INFO - 2018-10-25 14:18:03 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:18:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:18:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:18:03 --> User Agent Class Initialized
INFO - 2018-10-25 14:18:03 --> Controller Class Initialized
INFO - 2018-10-25 14:18:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:18:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:18:03 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:18:03 --> Pixel_Model class loaded
INFO - 2018-10-25 14:18:03 --> Database Driver Class Initialized
INFO - 2018-10-25 14:18:03 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:18:03 --> Form Validation Class Initialized
INFO - 2018-10-25 14:18:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-25 14:18:03 --> Database Driver Class Initialized
INFO - 2018-10-25 14:18:03 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:18:03 --> Config Class Initialized
INFO - 2018-10-25 14:18:03 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:18:03 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:18:03 --> Utf8 Class Initialized
INFO - 2018-10-25 14:18:03 --> URI Class Initialized
INFO - 2018-10-25 14:18:03 --> Router Class Initialized
INFO - 2018-10-25 14:18:03 --> Output Class Initialized
INFO - 2018-10-25 14:18:03 --> Security Class Initialized
DEBUG - 2018-10-25 14:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:18:03 --> CSRF cookie sent
INFO - 2018-10-25 14:18:03 --> Input Class Initialized
INFO - 2018-10-25 14:18:03 --> Language Class Initialized
INFO - 2018-10-25 14:18:03 --> Loader Class Initialized
INFO - 2018-10-25 14:18:03 --> Helper loaded: url_helper
INFO - 2018-10-25 14:18:03 --> Helper loaded: form_helper
INFO - 2018-10-25 14:18:03 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:18:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:18:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:18:03 --> User Agent Class Initialized
INFO - 2018-10-25 14:18:03 --> Controller Class Initialized
INFO - 2018-10-25 14:18:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:18:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:18:03 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:18:03 --> Pixel_Model class loaded
INFO - 2018-10-25 14:18:03 --> Database Driver Class Initialized
INFO - 2018-10-25 14:18:03 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:18:03 --> Database Driver Class Initialized
INFO - 2018-10-25 14:18:03 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:18:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-25 14:18:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-25 14:18:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-25 14:18:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-25 14:18:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-25 14:18:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-25 14:18:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/home_owner.php
INFO - 2018-10-25 14:18:03 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-25 14:18:03 --> Final output sent to browser
DEBUG - 2018-10-25 14:18:04 --> Total execution time: 0.5038
INFO - 2018-10-25 14:18:04 --> Config Class Initialized
INFO - 2018-10-25 14:18:04 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:18:04 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:18:04 --> Utf8 Class Initialized
INFO - 2018-10-25 14:18:04 --> URI Class Initialized
INFO - 2018-10-25 14:18:04 --> Router Class Initialized
INFO - 2018-10-25 14:18:04 --> Output Class Initialized
INFO - 2018-10-25 14:18:04 --> Security Class Initialized
DEBUG - 2018-10-25 14:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:18:04 --> CSRF cookie sent
INFO - 2018-10-25 14:18:04 --> CSRF token verified
INFO - 2018-10-25 14:18:04 --> Input Class Initialized
INFO - 2018-10-25 14:18:04 --> Language Class Initialized
INFO - 2018-10-25 14:18:04 --> Loader Class Initialized
INFO - 2018-10-25 14:18:04 --> Helper loaded: url_helper
INFO - 2018-10-25 14:18:05 --> Helper loaded: form_helper
INFO - 2018-10-25 14:18:05 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:18:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:18:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:18:05 --> User Agent Class Initialized
INFO - 2018-10-25 14:18:05 --> Controller Class Initialized
INFO - 2018-10-25 14:18:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:18:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:18:05 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:18:05 --> Pixel_Model class loaded
INFO - 2018-10-25 14:18:05 --> Database Driver Class Initialized
INFO - 2018-10-25 14:18:05 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:18:05 --> Form Validation Class Initialized
INFO - 2018-10-25 14:18:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-25 14:18:05 --> Database Driver Class Initialized
INFO - 2018-10-25 14:18:05 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:18:05 --> Config Class Initialized
INFO - 2018-10-25 14:18:05 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:18:05 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:18:05 --> Utf8 Class Initialized
INFO - 2018-10-25 14:18:05 --> URI Class Initialized
INFO - 2018-10-25 14:18:05 --> Router Class Initialized
INFO - 2018-10-25 14:18:05 --> Output Class Initialized
INFO - 2018-10-25 14:18:05 --> Security Class Initialized
DEBUG - 2018-10-25 14:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:18:05 --> CSRF cookie sent
INFO - 2018-10-25 14:18:05 --> Input Class Initialized
INFO - 2018-10-25 14:18:05 --> Language Class Initialized
INFO - 2018-10-25 14:18:05 --> Loader Class Initialized
INFO - 2018-10-25 14:18:05 --> Helper loaded: url_helper
INFO - 2018-10-25 14:18:05 --> Helper loaded: form_helper
INFO - 2018-10-25 14:18:05 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:18:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:18:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:18:05 --> User Agent Class Initialized
INFO - 2018-10-25 14:18:05 --> Controller Class Initialized
INFO - 2018-10-25 14:18:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:18:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:18:05 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:18:05 --> Pixel_Model class loaded
INFO - 2018-10-25 14:18:05 --> Database Driver Class Initialized
INFO - 2018-10-25 14:18:05 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:18:05 --> Database Driver Class Initialized
INFO - 2018-10-25 14:18:05 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:18:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-25 14:18:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-25 14:18:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-25 14:18:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-25 14:18:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-25 14:18:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-25 14:18:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/home_value.php
INFO - 2018-10-25 14:18:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-25 14:18:05 --> Final output sent to browser
DEBUG - 2018-10-25 14:18:05 --> Total execution time: 0.4785
INFO - 2018-10-25 14:18:07 --> Config Class Initialized
INFO - 2018-10-25 14:18:07 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:18:07 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:18:07 --> Utf8 Class Initialized
INFO - 2018-10-25 14:18:07 --> URI Class Initialized
INFO - 2018-10-25 14:18:07 --> Router Class Initialized
INFO - 2018-10-25 14:18:07 --> Output Class Initialized
INFO - 2018-10-25 14:18:07 --> Security Class Initialized
DEBUG - 2018-10-25 14:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:18:07 --> CSRF cookie sent
INFO - 2018-10-25 14:18:07 --> CSRF token verified
INFO - 2018-10-25 14:18:07 --> Input Class Initialized
INFO - 2018-10-25 14:18:07 --> Language Class Initialized
INFO - 2018-10-25 14:18:07 --> Loader Class Initialized
INFO - 2018-10-25 14:18:07 --> Helper loaded: url_helper
INFO - 2018-10-25 14:18:07 --> Helper loaded: form_helper
INFO - 2018-10-25 14:18:07 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:18:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:18:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:18:07 --> User Agent Class Initialized
INFO - 2018-10-25 14:18:07 --> Controller Class Initialized
INFO - 2018-10-25 14:18:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:18:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:18:07 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:18:07 --> Pixel_Model class loaded
INFO - 2018-10-25 14:18:07 --> Database Driver Class Initialized
INFO - 2018-10-25 14:18:07 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:18:07 --> Form Validation Class Initialized
INFO - 2018-10-25 14:18:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-25 14:18:07 --> Database Driver Class Initialized
INFO - 2018-10-25 14:18:07 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:18:07 --> Config Class Initialized
INFO - 2018-10-25 14:18:07 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:18:07 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:18:07 --> Utf8 Class Initialized
INFO - 2018-10-25 14:18:07 --> URI Class Initialized
INFO - 2018-10-25 14:18:07 --> Router Class Initialized
INFO - 2018-10-25 14:18:07 --> Output Class Initialized
INFO - 2018-10-25 14:18:07 --> Security Class Initialized
DEBUG - 2018-10-25 14:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:18:07 --> CSRF cookie sent
INFO - 2018-10-25 14:18:07 --> Input Class Initialized
INFO - 2018-10-25 14:18:07 --> Language Class Initialized
INFO - 2018-10-25 14:18:07 --> Loader Class Initialized
INFO - 2018-10-25 14:18:07 --> Helper loaded: url_helper
INFO - 2018-10-25 14:18:07 --> Helper loaded: form_helper
INFO - 2018-10-25 14:18:07 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:18:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:18:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:18:07 --> User Agent Class Initialized
INFO - 2018-10-25 14:18:07 --> Controller Class Initialized
INFO - 2018-10-25 14:18:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:18:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:18:07 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:18:07 --> Pixel_Model class loaded
INFO - 2018-10-25 14:18:07 --> Database Driver Class Initialized
INFO - 2018-10-25 14:18:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:18:08 --> Database Driver Class Initialized
INFO - 2018-10-25 14:18:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:18:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-25 14:18:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-25 14:18:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-25 14:18:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-25 14:18:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-25 14:18:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-25 14:18:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/merriage_home_title.php
INFO - 2018-10-25 14:18:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-25 14:18:08 --> Final output sent to browser
DEBUG - 2018-10-25 14:18:08 --> Total execution time: 0.4883
INFO - 2018-10-25 14:18:08 --> Config Class Initialized
INFO - 2018-10-25 14:18:08 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:18:08 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:18:08 --> Utf8 Class Initialized
INFO - 2018-10-25 14:18:08 --> URI Class Initialized
INFO - 2018-10-25 14:18:08 --> Router Class Initialized
INFO - 2018-10-25 14:18:08 --> Output Class Initialized
INFO - 2018-10-25 14:18:08 --> Security Class Initialized
DEBUG - 2018-10-25 14:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:18:08 --> CSRF cookie sent
INFO - 2018-10-25 14:18:08 --> CSRF token verified
INFO - 2018-10-25 14:18:08 --> Input Class Initialized
INFO - 2018-10-25 14:18:08 --> Language Class Initialized
INFO - 2018-10-25 14:18:08 --> Loader Class Initialized
INFO - 2018-10-25 14:18:09 --> Helper loaded: url_helper
INFO - 2018-10-25 14:18:09 --> Helper loaded: form_helper
INFO - 2018-10-25 14:18:09 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:18:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:18:09 --> User Agent Class Initialized
INFO - 2018-10-25 14:18:09 --> Controller Class Initialized
INFO - 2018-10-25 14:18:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:18:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:18:09 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:18:09 --> Pixel_Model class loaded
INFO - 2018-10-25 14:18:09 --> Database Driver Class Initialized
INFO - 2018-10-25 14:18:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:18:09 --> Form Validation Class Initialized
INFO - 2018-10-25 14:18:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-25 14:18:09 --> Database Driver Class Initialized
INFO - 2018-10-25 14:18:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:18:09 --> Config Class Initialized
INFO - 2018-10-25 14:18:09 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:18:09 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:18:09 --> Utf8 Class Initialized
INFO - 2018-10-25 14:18:09 --> URI Class Initialized
INFO - 2018-10-25 14:18:09 --> Router Class Initialized
INFO - 2018-10-25 14:18:09 --> Output Class Initialized
INFO - 2018-10-25 14:18:09 --> Security Class Initialized
DEBUG - 2018-10-25 14:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:18:09 --> CSRF cookie sent
INFO - 2018-10-25 14:18:09 --> Input Class Initialized
INFO - 2018-10-25 14:18:09 --> Language Class Initialized
INFO - 2018-10-25 14:18:09 --> Loader Class Initialized
INFO - 2018-10-25 14:18:09 --> Helper loaded: url_helper
INFO - 2018-10-25 14:18:09 --> Helper loaded: form_helper
INFO - 2018-10-25 14:18:09 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:18:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:18:09 --> User Agent Class Initialized
INFO - 2018-10-25 14:18:09 --> Controller Class Initialized
INFO - 2018-10-25 14:18:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:18:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:18:09 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:18:09 --> Pixel_Model class loaded
INFO - 2018-10-25 14:18:09 --> Database Driver Class Initialized
INFO - 2018-10-25 14:18:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:18:09 --> Database Driver Class Initialized
INFO - 2018-10-25 14:18:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:18:09 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-25 14:18:09 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-25 14:18:09 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-25 14:18:09 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-25 14:18:09 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-25 14:18:09 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-25 14:18:09 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/financial.php
INFO - 2018-10-25 14:18:09 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-25 14:18:09 --> Final output sent to browser
DEBUG - 2018-10-25 14:18:09 --> Total execution time: 0.4920
INFO - 2018-10-25 14:18:10 --> Config Class Initialized
INFO - 2018-10-25 14:18:10 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:18:10 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:18:10 --> Utf8 Class Initialized
INFO - 2018-10-25 14:18:10 --> URI Class Initialized
INFO - 2018-10-25 14:18:10 --> Router Class Initialized
INFO - 2018-10-25 14:18:10 --> Output Class Initialized
INFO - 2018-10-25 14:18:10 --> Security Class Initialized
DEBUG - 2018-10-25 14:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:18:10 --> CSRF cookie sent
INFO - 2018-10-25 14:18:10 --> CSRF token verified
INFO - 2018-10-25 14:18:10 --> Input Class Initialized
INFO - 2018-10-25 14:18:10 --> Language Class Initialized
INFO - 2018-10-25 14:18:10 --> Loader Class Initialized
INFO - 2018-10-25 14:18:10 --> Helper loaded: url_helper
INFO - 2018-10-25 14:18:10 --> Helper loaded: form_helper
INFO - 2018-10-25 14:18:10 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:18:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:18:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:18:10 --> User Agent Class Initialized
INFO - 2018-10-25 14:18:10 --> Controller Class Initialized
INFO - 2018-10-25 14:18:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:18:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:18:10 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:18:10 --> Pixel_Model class loaded
INFO - 2018-10-25 14:18:10 --> Database Driver Class Initialized
INFO - 2018-10-25 14:18:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:18:10 --> Form Validation Class Initialized
INFO - 2018-10-25 14:18:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-25 14:18:10 --> Database Driver Class Initialized
INFO - 2018-10-25 14:18:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:18:11 --> Config Class Initialized
INFO - 2018-10-25 14:18:11 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:18:11 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:18:11 --> Utf8 Class Initialized
INFO - 2018-10-25 14:18:11 --> URI Class Initialized
INFO - 2018-10-25 14:18:11 --> Router Class Initialized
INFO - 2018-10-25 14:18:11 --> Output Class Initialized
INFO - 2018-10-25 14:18:11 --> Security Class Initialized
DEBUG - 2018-10-25 14:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:18:11 --> CSRF cookie sent
INFO - 2018-10-25 14:18:11 --> Input Class Initialized
INFO - 2018-10-25 14:18:11 --> Language Class Initialized
INFO - 2018-10-25 14:18:11 --> Loader Class Initialized
INFO - 2018-10-25 14:18:11 --> Helper loaded: url_helper
INFO - 2018-10-25 14:18:11 --> Helper loaded: form_helper
INFO - 2018-10-25 14:18:11 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:18:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:18:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:18:11 --> User Agent Class Initialized
INFO - 2018-10-25 14:18:11 --> Controller Class Initialized
INFO - 2018-10-25 14:18:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:18:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:18:11 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:18:11 --> Pixel_Model class loaded
INFO - 2018-10-25 14:18:11 --> Database Driver Class Initialized
INFO - 2018-10-25 14:18:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:18:11 --> Database Driver Class Initialized
INFO - 2018-10-25 14:18:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:18:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-25 14:18:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-25 14:18:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-25 14:18:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-25 14:18:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/risk_report.php
INFO - 2018-10-25 14:18:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-25 14:18:11 --> Final output sent to browser
DEBUG - 2018-10-25 14:18:11 --> Total execution time: 0.4586
INFO - 2018-10-25 14:18:16 --> Config Class Initialized
INFO - 2018-10-25 14:18:16 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:18:16 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:18:16 --> Utf8 Class Initialized
INFO - 2018-10-25 14:18:16 --> URI Class Initialized
INFO - 2018-10-25 14:18:16 --> Router Class Initialized
INFO - 2018-10-25 14:18:16 --> Output Class Initialized
INFO - 2018-10-25 14:18:16 --> Security Class Initialized
DEBUG - 2018-10-25 14:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:18:16 --> CSRF cookie sent
INFO - 2018-10-25 14:18:16 --> Input Class Initialized
INFO - 2018-10-25 14:18:16 --> Language Class Initialized
INFO - 2018-10-25 14:18:16 --> Loader Class Initialized
INFO - 2018-10-25 14:18:16 --> Helper loaded: url_helper
INFO - 2018-10-25 14:18:16 --> Helper loaded: form_helper
INFO - 2018-10-25 14:18:16 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:18:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:18:16 --> User Agent Class Initialized
INFO - 2018-10-25 14:18:16 --> Controller Class Initialized
INFO - 2018-10-25 14:18:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:18:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:18:16 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:18:16 --> Pixel_Model class loaded
INFO - 2018-10-25 14:18:16 --> Database Driver Class Initialized
INFO - 2018-10-25 14:18:16 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:18:16 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-25 14:18:16 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-25 14:18:16 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-25 14:18:16 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-25 14:18:16 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-25 14:18:16 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-25 14:18:16 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-25 14:18:16 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-25 14:18:16 --> Final output sent to browser
DEBUG - 2018-10-25 14:18:16 --> Total execution time: 0.4646
INFO - 2018-10-25 14:18:19 --> Config Class Initialized
INFO - 2018-10-25 14:18:19 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:18:19 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:18:19 --> Utf8 Class Initialized
INFO - 2018-10-25 14:18:19 --> URI Class Initialized
INFO - 2018-10-25 14:18:19 --> Router Class Initialized
INFO - 2018-10-25 14:18:19 --> Output Class Initialized
INFO - 2018-10-25 14:18:19 --> Security Class Initialized
DEBUG - 2018-10-25 14:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:18:19 --> CSRF cookie sent
INFO - 2018-10-25 14:18:19 --> CSRF token verified
INFO - 2018-10-25 14:18:19 --> Input Class Initialized
INFO - 2018-10-25 14:18:19 --> Language Class Initialized
INFO - 2018-10-25 14:18:19 --> Loader Class Initialized
INFO - 2018-10-25 14:18:19 --> Helper loaded: url_helper
INFO - 2018-10-25 14:18:19 --> Helper loaded: form_helper
INFO - 2018-10-25 14:18:19 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:18:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:18:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:18:19 --> User Agent Class Initialized
INFO - 2018-10-25 14:18:19 --> Controller Class Initialized
INFO - 2018-10-25 14:18:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:18:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:18:19 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:18:19 --> Pixel_Model class loaded
INFO - 2018-10-25 14:18:19 --> Database Driver Class Initialized
INFO - 2018-10-25 14:18:19 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:18:19 --> Database Driver Class Initialized
INFO - 2018-10-25 14:18:19 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:18:19 --> Config Class Initialized
INFO - 2018-10-25 14:18:19 --> Hooks Class Initialized
DEBUG - 2018-10-25 14:18:19 --> UTF-8 Support Enabled
INFO - 2018-10-25 14:18:19 --> Utf8 Class Initialized
INFO - 2018-10-25 14:18:19 --> URI Class Initialized
INFO - 2018-10-25 14:18:19 --> Router Class Initialized
INFO - 2018-10-25 14:18:19 --> Output Class Initialized
INFO - 2018-10-25 14:18:19 --> Security Class Initialized
DEBUG - 2018-10-25 14:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 14:18:19 --> CSRF cookie sent
INFO - 2018-10-25 14:18:19 --> Input Class Initialized
INFO - 2018-10-25 14:18:19 --> Language Class Initialized
INFO - 2018-10-25 14:18:19 --> Loader Class Initialized
INFO - 2018-10-25 14:18:19 --> Helper loaded: url_helper
INFO - 2018-10-25 14:18:19 --> Helper loaded: form_helper
INFO - 2018-10-25 14:18:19 --> Helper loaded: language_helper
DEBUG - 2018-10-25 14:18:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 14:18:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 14:18:19 --> User Agent Class Initialized
INFO - 2018-10-25 14:18:19 --> Controller Class Initialized
INFO - 2018-10-25 14:18:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 14:18:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 14:18:19 --> Helper loaded: custom_helper
INFO - 2018-10-25 14:18:19 --> Pixel_Model class loaded
INFO - 2018-10-25 14:18:19 --> Database Driver Class Initialized
INFO - 2018-10-25 14:18:19 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:18:19 --> Database Driver Class Initialized
INFO - 2018-10-25 14:18:19 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 14:18:19 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-25 14:18:19 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-25 14:18:19 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-25 14:18:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-25 14:18:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-25 14:18:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-25 14:18:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-25 14:18:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-25 14:18:20 --> Final output sent to browser
DEBUG - 2018-10-25 14:18:20 --> Total execution time: 0.4989
INFO - 2018-10-25 15:45:11 --> Config Class Initialized
INFO - 2018-10-25 15:45:11 --> Hooks Class Initialized
DEBUG - 2018-10-25 15:45:11 --> UTF-8 Support Enabled
INFO - 2018-10-25 15:45:11 --> Utf8 Class Initialized
INFO - 2018-10-25 15:45:11 --> URI Class Initialized
DEBUG - 2018-10-25 15:45:11 --> No URI present. Default controller set.
INFO - 2018-10-25 15:45:11 --> Router Class Initialized
INFO - 2018-10-25 15:45:11 --> Output Class Initialized
INFO - 2018-10-25 15:45:11 --> Security Class Initialized
DEBUG - 2018-10-25 15:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 15:45:11 --> CSRF cookie sent
INFO - 2018-10-25 15:45:11 --> Input Class Initialized
INFO - 2018-10-25 15:45:11 --> Language Class Initialized
INFO - 2018-10-25 15:45:11 --> Loader Class Initialized
INFO - 2018-10-25 15:45:11 --> Helper loaded: url_helper
INFO - 2018-10-25 15:45:11 --> Helper loaded: form_helper
INFO - 2018-10-25 15:45:11 --> Helper loaded: language_helper
DEBUG - 2018-10-25 15:45:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 15:45:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 15:45:11 --> User Agent Class Initialized
INFO - 2018-10-25 15:45:12 --> Controller Class Initialized
INFO - 2018-10-25 15:45:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 15:45:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 15:45:12 --> Helper loaded: custom_helper
INFO - 2018-10-25 15:45:12 --> Pixel_Model class loaded
INFO - 2018-10-25 15:45:12 --> Database Driver Class Initialized
INFO - 2018-10-25 15:45:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 15:45:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-25 15:45:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-25 15:45:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-25 15:45:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-25 15:45:12 --> Final output sent to browser
DEBUG - 2018-10-25 15:45:12 --> Total execution time: 0.4516
INFO - 2018-10-25 15:45:55 --> Config Class Initialized
INFO - 2018-10-25 15:45:55 --> Hooks Class Initialized
DEBUG - 2018-10-25 15:45:55 --> UTF-8 Support Enabled
INFO - 2018-10-25 15:45:55 --> Utf8 Class Initialized
INFO - 2018-10-25 15:45:55 --> URI Class Initialized
DEBUG - 2018-10-25 15:45:55 --> No URI present. Default controller set.
INFO - 2018-10-25 15:45:55 --> Router Class Initialized
INFO - 2018-10-25 15:45:55 --> Output Class Initialized
INFO - 2018-10-25 15:45:55 --> Security Class Initialized
DEBUG - 2018-10-25 15:45:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 15:45:55 --> CSRF cookie sent
INFO - 2018-10-25 15:45:55 --> Input Class Initialized
INFO - 2018-10-25 15:45:55 --> Language Class Initialized
INFO - 2018-10-25 15:45:55 --> Loader Class Initialized
INFO - 2018-10-25 15:45:55 --> Helper loaded: url_helper
INFO - 2018-10-25 15:45:55 --> Helper loaded: form_helper
INFO - 2018-10-25 15:45:55 --> Helper loaded: language_helper
DEBUG - 2018-10-25 15:45:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 15:45:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 15:45:55 --> User Agent Class Initialized
INFO - 2018-10-25 15:45:55 --> Controller Class Initialized
INFO - 2018-10-25 15:45:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 15:45:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 15:45:55 --> Helper loaded: custom_helper
INFO - 2018-10-25 15:45:55 --> Pixel_Model class loaded
INFO - 2018-10-25 15:45:55 --> Database Driver Class Initialized
INFO - 2018-10-25 15:45:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 15:45:55 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-25 15:45:55 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-25 15:48:02 --> Config Class Initialized
INFO - 2018-10-25 15:48:02 --> Hooks Class Initialized
DEBUG - 2018-10-25 15:48:02 --> UTF-8 Support Enabled
INFO - 2018-10-25 15:48:02 --> Utf8 Class Initialized
INFO - 2018-10-25 15:48:02 --> URI Class Initialized
DEBUG - 2018-10-25 15:48:02 --> No URI present. Default controller set.
INFO - 2018-10-25 15:48:02 --> Router Class Initialized
INFO - 2018-10-25 15:48:02 --> Output Class Initialized
INFO - 2018-10-25 15:48:02 --> Security Class Initialized
DEBUG - 2018-10-25 15:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 15:48:02 --> CSRF cookie sent
INFO - 2018-10-25 15:48:02 --> Input Class Initialized
INFO - 2018-10-25 15:48:02 --> Language Class Initialized
INFO - 2018-10-25 15:48:02 --> Loader Class Initialized
INFO - 2018-10-25 15:48:02 --> Helper loaded: url_helper
INFO - 2018-10-25 15:48:02 --> Helper loaded: form_helper
INFO - 2018-10-25 15:48:02 --> Helper loaded: language_helper
DEBUG - 2018-10-25 15:48:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 15:48:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 15:48:02 --> User Agent Class Initialized
INFO - 2018-10-25 15:48:02 --> Controller Class Initialized
INFO - 2018-10-25 15:48:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 15:48:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 15:48:02 --> Helper loaded: custom_helper
INFO - 2018-10-25 15:48:02 --> Pixel_Model class loaded
INFO - 2018-10-25 15:48:02 --> Database Driver Class Initialized
INFO - 2018-10-25 15:48:02 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 15:48:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-25 15:48:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-25 15:51:17 --> Config Class Initialized
INFO - 2018-10-25 15:51:17 --> Hooks Class Initialized
DEBUG - 2018-10-25 15:51:17 --> UTF-8 Support Enabled
INFO - 2018-10-25 15:51:17 --> Utf8 Class Initialized
INFO - 2018-10-25 15:51:17 --> URI Class Initialized
DEBUG - 2018-10-25 15:51:17 --> No URI present. Default controller set.
INFO - 2018-10-25 15:51:17 --> Router Class Initialized
INFO - 2018-10-25 15:51:17 --> Output Class Initialized
INFO - 2018-10-25 15:51:17 --> Security Class Initialized
DEBUG - 2018-10-25 15:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 15:51:17 --> CSRF cookie sent
INFO - 2018-10-25 15:51:17 --> Input Class Initialized
INFO - 2018-10-25 15:51:17 --> Language Class Initialized
INFO - 2018-10-25 15:51:17 --> Loader Class Initialized
INFO - 2018-10-25 15:51:17 --> Helper loaded: url_helper
INFO - 2018-10-25 15:51:17 --> Helper loaded: form_helper
INFO - 2018-10-25 15:51:17 --> Helper loaded: language_helper
DEBUG - 2018-10-25 15:51:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 15:51:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 15:51:17 --> User Agent Class Initialized
INFO - 2018-10-25 15:51:17 --> Controller Class Initialized
INFO - 2018-10-25 15:51:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-25 15:51:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-25 15:51:17 --> Helper loaded: custom_helper
INFO - 2018-10-25 15:51:17 --> Pixel_Model class loaded
INFO - 2018-10-25 15:51:17 --> Database Driver Class Initialized
INFO - 2018-10-25 15:51:17 --> Model "QuestionsModel" initialized
INFO - 2018-10-25 15:51:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-25 15:51:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-25 15:51:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-25 15:51:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-25 15:51:17 --> Final output sent to browser
DEBUG - 2018-10-25 15:51:17 --> Total execution time: 0.4138

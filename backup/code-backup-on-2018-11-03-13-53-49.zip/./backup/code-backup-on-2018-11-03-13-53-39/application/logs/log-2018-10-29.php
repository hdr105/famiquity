<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-10-29 17:24:43 --> Config Class Initialized
INFO - 2018-10-29 17:24:43 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:24:43 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:24:43 --> Utf8 Class Initialized
INFO - 2018-10-29 17:24:43 --> URI Class Initialized
DEBUG - 2018-10-29 17:24:43 --> No URI present. Default controller set.
INFO - 2018-10-29 17:24:43 --> Router Class Initialized
INFO - 2018-10-29 17:24:44 --> Output Class Initialized
INFO - 2018-10-29 17:24:44 --> Security Class Initialized
DEBUG - 2018-10-29 17:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:24:44 --> CSRF cookie sent
INFO - 2018-10-29 17:24:44 --> Input Class Initialized
INFO - 2018-10-29 17:24:44 --> Language Class Initialized
INFO - 2018-10-29 17:24:44 --> Loader Class Initialized
INFO - 2018-10-29 17:24:44 --> Helper loaded: url_helper
INFO - 2018-10-29 17:24:44 --> Helper loaded: form_helper
INFO - 2018-10-29 17:24:44 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:24:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:24:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:24:44 --> User Agent Class Initialized
INFO - 2018-10-29 17:24:44 --> Controller Class Initialized
INFO - 2018-10-29 17:24:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:24:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:24:44 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:24:44 --> Pixel_Model class loaded
INFO - 2018-10-29 17:24:44 --> Database Driver Class Initialized
INFO - 2018-10-29 17:24:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:24:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 17:24:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 17:24:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-29 17:24:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 17:24:45 --> Final output sent to browser
DEBUG - 2018-10-29 17:24:45 --> Total execution time: 1.6240
INFO - 2018-10-29 17:25:18 --> Config Class Initialized
INFO - 2018-10-29 17:25:18 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:25:18 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:25:18 --> Utf8 Class Initialized
INFO - 2018-10-29 17:25:18 --> URI Class Initialized
DEBUG - 2018-10-29 17:25:18 --> No URI present. Default controller set.
INFO - 2018-10-29 17:25:18 --> Router Class Initialized
INFO - 2018-10-29 17:25:18 --> Output Class Initialized
INFO - 2018-10-29 17:25:18 --> Security Class Initialized
DEBUG - 2018-10-29 17:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:25:18 --> CSRF cookie sent
INFO - 2018-10-29 17:25:18 --> Input Class Initialized
INFO - 2018-10-29 17:25:18 --> Language Class Initialized
INFO - 2018-10-29 17:25:18 --> Loader Class Initialized
INFO - 2018-10-29 17:25:18 --> Helper loaded: url_helper
INFO - 2018-10-29 17:25:18 --> Helper loaded: form_helper
INFO - 2018-10-29 17:25:18 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:25:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:25:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:25:18 --> User Agent Class Initialized
INFO - 2018-10-29 17:25:18 --> Controller Class Initialized
INFO - 2018-10-29 17:25:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:25:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:25:18 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:25:18 --> Pixel_Model class loaded
INFO - 2018-10-29 17:25:18 --> Database Driver Class Initialized
INFO - 2018-10-29 17:25:18 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:25:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 17:25:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 17:25:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-29 17:25:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 17:25:18 --> Final output sent to browser
DEBUG - 2018-10-29 17:25:18 --> Total execution time: 0.3217
INFO - 2018-10-29 17:25:39 --> Config Class Initialized
INFO - 2018-10-29 17:25:39 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:25:39 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:25:39 --> Utf8 Class Initialized
INFO - 2018-10-29 17:25:39 --> URI Class Initialized
DEBUG - 2018-10-29 17:25:39 --> No URI present. Default controller set.
INFO - 2018-10-29 17:25:39 --> Router Class Initialized
INFO - 2018-10-29 17:25:39 --> Output Class Initialized
INFO - 2018-10-29 17:25:39 --> Security Class Initialized
DEBUG - 2018-10-29 17:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:25:39 --> CSRF cookie sent
INFO - 2018-10-29 17:25:39 --> Input Class Initialized
INFO - 2018-10-29 17:25:39 --> Language Class Initialized
INFO - 2018-10-29 17:25:39 --> Loader Class Initialized
INFO - 2018-10-29 17:25:39 --> Helper loaded: url_helper
INFO - 2018-10-29 17:25:39 --> Helper loaded: form_helper
INFO - 2018-10-29 17:25:39 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:25:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:25:39 --> User Agent Class Initialized
INFO - 2018-10-29 17:25:39 --> Controller Class Initialized
INFO - 2018-10-29 17:25:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:25:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:25:39 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:25:39 --> Pixel_Model class loaded
INFO - 2018-10-29 17:25:39 --> Database Driver Class Initialized
INFO - 2018-10-29 17:25:39 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:25:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 17:25:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 17:25:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-29 17:25:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 17:25:39 --> Final output sent to browser
DEBUG - 2018-10-29 17:25:39 --> Total execution time: 0.2654
INFO - 2018-10-29 17:25:41 --> Config Class Initialized
INFO - 2018-10-29 17:25:41 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:25:41 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:25:41 --> Utf8 Class Initialized
INFO - 2018-10-29 17:25:41 --> URI Class Initialized
DEBUG - 2018-10-29 17:25:41 --> No URI present. Default controller set.
INFO - 2018-10-29 17:25:41 --> Router Class Initialized
INFO - 2018-10-29 17:25:41 --> Output Class Initialized
INFO - 2018-10-29 17:25:41 --> Security Class Initialized
DEBUG - 2018-10-29 17:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:25:41 --> CSRF cookie sent
INFO - 2018-10-29 17:25:41 --> Input Class Initialized
INFO - 2018-10-29 17:25:41 --> Language Class Initialized
INFO - 2018-10-29 17:25:41 --> Loader Class Initialized
INFO - 2018-10-29 17:25:41 --> Helper loaded: url_helper
INFO - 2018-10-29 17:25:41 --> Helper loaded: form_helper
INFO - 2018-10-29 17:25:41 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:25:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:25:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:25:41 --> User Agent Class Initialized
INFO - 2018-10-29 17:25:41 --> Controller Class Initialized
INFO - 2018-10-29 17:25:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:25:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:25:41 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:25:41 --> Pixel_Model class loaded
INFO - 2018-10-29 17:25:41 --> Database Driver Class Initialized
INFO - 2018-10-29 17:25:41 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:25:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 17:25:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 17:25:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-29 17:25:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 17:25:41 --> Final output sent to browser
DEBUG - 2018-10-29 17:25:41 --> Total execution time: 0.2729
INFO - 2018-10-29 17:26:04 --> Config Class Initialized
INFO - 2018-10-29 17:26:04 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:26:04 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:26:04 --> Utf8 Class Initialized
INFO - 2018-10-29 17:26:04 --> URI Class Initialized
INFO - 2018-10-29 17:26:04 --> Router Class Initialized
INFO - 2018-10-29 17:26:04 --> Output Class Initialized
INFO - 2018-10-29 17:26:04 --> Security Class Initialized
DEBUG - 2018-10-29 17:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:26:04 --> CSRF cookie sent
INFO - 2018-10-29 17:26:04 --> Input Class Initialized
INFO - 2018-10-29 17:26:04 --> Language Class Initialized
INFO - 2018-10-29 17:26:04 --> Loader Class Initialized
INFO - 2018-10-29 17:26:04 --> Helper loaded: url_helper
INFO - 2018-10-29 17:26:04 --> Helper loaded: form_helper
INFO - 2018-10-29 17:26:04 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:26:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:26:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:26:04 --> User Agent Class Initialized
INFO - 2018-10-29 17:26:04 --> Controller Class Initialized
INFO - 2018-10-29 17:26:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:26:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:26:04 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:26:04 --> Pixel_Model class loaded
INFO - 2018-10-29 17:26:04 --> Database Driver Class Initialized
INFO - 2018-10-29 17:26:04 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:26:04 --> Config Class Initialized
INFO - 2018-10-29 17:26:04 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:26:04 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:26:04 --> Utf8 Class Initialized
INFO - 2018-10-29 17:26:04 --> URI Class Initialized
INFO - 2018-10-29 17:26:04 --> Router Class Initialized
INFO - 2018-10-29 17:26:04 --> Output Class Initialized
INFO - 2018-10-29 17:26:04 --> Security Class Initialized
DEBUG - 2018-10-29 17:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:26:04 --> CSRF cookie sent
INFO - 2018-10-29 17:26:04 --> Input Class Initialized
INFO - 2018-10-29 17:26:04 --> Language Class Initialized
INFO - 2018-10-29 17:26:04 --> Loader Class Initialized
INFO - 2018-10-29 17:26:04 --> Helper loaded: url_helper
INFO - 2018-10-29 17:26:04 --> Helper loaded: form_helper
INFO - 2018-10-29 17:26:04 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:26:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:26:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:26:04 --> User Agent Class Initialized
INFO - 2018-10-29 17:26:04 --> Controller Class Initialized
INFO - 2018-10-29 17:26:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:26:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:26:05 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:26:05 --> Pixel_Model class loaded
INFO - 2018-10-29 17:26:05 --> Database Driver Class Initialized
INFO - 2018-10-29 17:26:05 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:26:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 17:26:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 17:26:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 17:26:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 17:26:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-29 17:26:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-29 17:26:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-29 17:26:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 17:26:05 --> Final output sent to browser
DEBUG - 2018-10-29 17:26:05 --> Total execution time: 0.4439
INFO - 2018-10-29 17:26:07 --> Config Class Initialized
INFO - 2018-10-29 17:26:07 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:26:07 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:26:07 --> Utf8 Class Initialized
INFO - 2018-10-29 17:26:07 --> URI Class Initialized
INFO - 2018-10-29 17:26:07 --> Router Class Initialized
INFO - 2018-10-29 17:26:07 --> Output Class Initialized
INFO - 2018-10-29 17:26:07 --> Security Class Initialized
DEBUG - 2018-10-29 17:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:26:07 --> CSRF cookie sent
INFO - 2018-10-29 17:26:07 --> CSRF token verified
INFO - 2018-10-29 17:26:07 --> Input Class Initialized
INFO - 2018-10-29 17:26:07 --> Language Class Initialized
INFO - 2018-10-29 17:26:07 --> Loader Class Initialized
INFO - 2018-10-29 17:26:07 --> Helper loaded: url_helper
INFO - 2018-10-29 17:26:07 --> Helper loaded: form_helper
INFO - 2018-10-29 17:26:07 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:26:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:26:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:26:07 --> User Agent Class Initialized
INFO - 2018-10-29 17:26:07 --> Controller Class Initialized
INFO - 2018-10-29 17:26:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:26:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:26:07 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:26:07 --> Pixel_Model class loaded
INFO - 2018-10-29 17:26:07 --> Database Driver Class Initialized
INFO - 2018-10-29 17:26:07 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:26:07 --> Database Driver Class Initialized
INFO - 2018-10-29 17:26:07 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:26:07 --> Config Class Initialized
INFO - 2018-10-29 17:26:07 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:26:07 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:26:07 --> Utf8 Class Initialized
INFO - 2018-10-29 17:26:07 --> URI Class Initialized
INFO - 2018-10-29 17:26:07 --> Router Class Initialized
INFO - 2018-10-29 17:26:07 --> Output Class Initialized
INFO - 2018-10-29 17:26:07 --> Security Class Initialized
DEBUG - 2018-10-29 17:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:26:07 --> CSRF cookie sent
INFO - 2018-10-29 17:26:07 --> Input Class Initialized
INFO - 2018-10-29 17:26:07 --> Language Class Initialized
INFO - 2018-10-29 17:26:07 --> Loader Class Initialized
INFO - 2018-10-29 17:26:07 --> Helper loaded: url_helper
INFO - 2018-10-29 17:26:07 --> Helper loaded: form_helper
INFO - 2018-10-29 17:26:07 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:26:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:26:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:26:07 --> User Agent Class Initialized
INFO - 2018-10-29 17:26:07 --> Controller Class Initialized
INFO - 2018-10-29 17:26:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:26:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:26:08 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:26:08 --> Pixel_Model class loaded
INFO - 2018-10-29 17:26:08 --> Database Driver Class Initialized
INFO - 2018-10-29 17:26:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:26:08 --> Database Driver Class Initialized
INFO - 2018-10-29 17:26:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:26:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 17:26:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 17:26:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 17:26:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 17:26:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-29 17:26:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-29 17:26:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-29 17:26:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 17:26:08 --> Final output sent to browser
DEBUG - 2018-10-29 17:26:08 --> Total execution time: 0.3463
INFO - 2018-10-29 17:26:11 --> Config Class Initialized
INFO - 2018-10-29 17:26:11 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:26:11 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:26:11 --> Utf8 Class Initialized
INFO - 2018-10-29 17:26:11 --> URI Class Initialized
INFO - 2018-10-29 17:26:11 --> Router Class Initialized
INFO - 2018-10-29 17:26:11 --> Output Class Initialized
INFO - 2018-10-29 17:26:11 --> Security Class Initialized
DEBUG - 2018-10-29 17:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:26:11 --> CSRF cookie sent
INFO - 2018-10-29 17:26:11 --> CSRF token verified
INFO - 2018-10-29 17:26:11 --> Input Class Initialized
INFO - 2018-10-29 17:26:11 --> Language Class Initialized
INFO - 2018-10-29 17:26:11 --> Loader Class Initialized
INFO - 2018-10-29 17:26:11 --> Helper loaded: url_helper
INFO - 2018-10-29 17:26:11 --> Helper loaded: form_helper
INFO - 2018-10-29 17:26:11 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:26:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:26:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:26:11 --> User Agent Class Initialized
INFO - 2018-10-29 17:26:11 --> Controller Class Initialized
INFO - 2018-10-29 17:26:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:26:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:26:11 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:26:11 --> Pixel_Model class loaded
INFO - 2018-10-29 17:26:11 --> Database Driver Class Initialized
INFO - 2018-10-29 17:26:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:26:11 --> Form Validation Class Initialized
INFO - 2018-10-29 17:26:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-29 17:26:11 --> Database Driver Class Initialized
INFO - 2018-10-29 17:26:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:26:11 --> Config Class Initialized
INFO - 2018-10-29 17:26:11 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:26:11 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:26:11 --> Utf8 Class Initialized
INFO - 2018-10-29 17:26:11 --> URI Class Initialized
INFO - 2018-10-29 17:26:11 --> Router Class Initialized
INFO - 2018-10-29 17:26:11 --> Output Class Initialized
INFO - 2018-10-29 17:26:11 --> Security Class Initialized
DEBUG - 2018-10-29 17:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:26:11 --> CSRF cookie sent
INFO - 2018-10-29 17:26:11 --> Input Class Initialized
INFO - 2018-10-29 17:26:11 --> Language Class Initialized
INFO - 2018-10-29 17:26:11 --> Loader Class Initialized
INFO - 2018-10-29 17:26:11 --> Helper loaded: url_helper
INFO - 2018-10-29 17:26:11 --> Helper loaded: form_helper
INFO - 2018-10-29 17:26:11 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:26:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:26:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:26:11 --> User Agent Class Initialized
INFO - 2018-10-29 17:26:11 --> Controller Class Initialized
INFO - 2018-10-29 17:26:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:26:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:26:11 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:26:11 --> Pixel_Model class loaded
INFO - 2018-10-29 17:26:11 --> Database Driver Class Initialized
INFO - 2018-10-29 17:26:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:26:11 --> Database Driver Class Initialized
INFO - 2018-10-29 17:26:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:26:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 17:26:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 17:26:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 17:26:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 17:26:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-29 17:26:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-29 17:26:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/your_job.php
INFO - 2018-10-29 17:26:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 17:26:11 --> Final output sent to browser
DEBUG - 2018-10-29 17:26:11 --> Total execution time: 0.3294
INFO - 2018-10-29 17:26:12 --> Config Class Initialized
INFO - 2018-10-29 17:26:12 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:26:12 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:26:12 --> Utf8 Class Initialized
INFO - 2018-10-29 17:26:12 --> URI Class Initialized
INFO - 2018-10-29 17:26:12 --> Router Class Initialized
INFO - 2018-10-29 17:26:12 --> Output Class Initialized
INFO - 2018-10-29 17:26:12 --> Security Class Initialized
DEBUG - 2018-10-29 17:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:26:12 --> CSRF cookie sent
INFO - 2018-10-29 17:26:12 --> CSRF token verified
INFO - 2018-10-29 17:26:12 --> Input Class Initialized
INFO - 2018-10-29 17:26:12 --> Language Class Initialized
INFO - 2018-10-29 17:26:12 --> Loader Class Initialized
INFO - 2018-10-29 17:26:12 --> Helper loaded: url_helper
INFO - 2018-10-29 17:26:12 --> Helper loaded: form_helper
INFO - 2018-10-29 17:26:12 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:26:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:26:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:26:12 --> User Agent Class Initialized
INFO - 2018-10-29 17:26:12 --> Controller Class Initialized
INFO - 2018-10-29 17:26:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:26:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:26:12 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:26:12 --> Pixel_Model class loaded
INFO - 2018-10-29 17:26:12 --> Database Driver Class Initialized
INFO - 2018-10-29 17:26:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:26:12 --> Form Validation Class Initialized
INFO - 2018-10-29 17:26:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-29 17:26:12 --> Database Driver Class Initialized
INFO - 2018-10-29 17:26:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:26:12 --> Config Class Initialized
INFO - 2018-10-29 17:26:12 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:26:12 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:26:13 --> Utf8 Class Initialized
INFO - 2018-10-29 17:26:13 --> URI Class Initialized
INFO - 2018-10-29 17:26:13 --> Router Class Initialized
INFO - 2018-10-29 17:26:13 --> Output Class Initialized
INFO - 2018-10-29 17:26:13 --> Security Class Initialized
DEBUG - 2018-10-29 17:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:26:13 --> CSRF cookie sent
INFO - 2018-10-29 17:26:13 --> Input Class Initialized
INFO - 2018-10-29 17:26:13 --> Language Class Initialized
INFO - 2018-10-29 17:26:13 --> Loader Class Initialized
INFO - 2018-10-29 17:26:13 --> Helper loaded: url_helper
INFO - 2018-10-29 17:26:13 --> Helper loaded: form_helper
INFO - 2018-10-29 17:26:13 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:26:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:26:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:26:13 --> User Agent Class Initialized
INFO - 2018-10-29 17:26:13 --> Controller Class Initialized
INFO - 2018-10-29 17:26:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:26:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:26:13 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:26:13 --> Pixel_Model class loaded
INFO - 2018-10-29 17:26:13 --> Database Driver Class Initialized
INFO - 2018-10-29 17:26:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:26:13 --> Database Driver Class Initialized
INFO - 2018-10-29 17:26:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:26:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 17:26:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 17:26:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner.php
INFO - 2018-10-29 17:26:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 17:26:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 17:26:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-29 17:26:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-29 17:26:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/relation_ship_status.php
INFO - 2018-10-29 17:26:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 17:26:13 --> Final output sent to browser
DEBUG - 2018-10-29 17:26:13 --> Total execution time: 0.3943
INFO - 2018-10-29 17:26:14 --> Config Class Initialized
INFO - 2018-10-29 17:26:14 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:26:14 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:26:14 --> Utf8 Class Initialized
INFO - 2018-10-29 17:26:14 --> URI Class Initialized
INFO - 2018-10-29 17:26:14 --> Router Class Initialized
INFO - 2018-10-29 17:26:14 --> Output Class Initialized
INFO - 2018-10-29 17:26:14 --> Security Class Initialized
DEBUG - 2018-10-29 17:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:26:14 --> CSRF cookie sent
INFO - 2018-10-29 17:26:14 --> CSRF token verified
INFO - 2018-10-29 17:26:14 --> Input Class Initialized
INFO - 2018-10-29 17:26:14 --> Language Class Initialized
INFO - 2018-10-29 17:26:14 --> Loader Class Initialized
INFO - 2018-10-29 17:26:14 --> Helper loaded: url_helper
INFO - 2018-10-29 17:26:14 --> Helper loaded: form_helper
INFO - 2018-10-29 17:26:14 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:26:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:26:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:26:14 --> User Agent Class Initialized
INFO - 2018-10-29 17:26:14 --> Controller Class Initialized
INFO - 2018-10-29 17:26:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:26:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:26:14 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:26:14 --> Pixel_Model class loaded
INFO - 2018-10-29 17:26:14 --> Database Driver Class Initialized
INFO - 2018-10-29 17:26:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:26:14 --> Form Validation Class Initialized
INFO - 2018-10-29 17:26:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-29 17:26:14 --> Database Driver Class Initialized
INFO - 2018-10-29 17:26:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:26:14 --> Config Class Initialized
INFO - 2018-10-29 17:26:14 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:26:14 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:26:14 --> Utf8 Class Initialized
INFO - 2018-10-29 17:26:14 --> URI Class Initialized
INFO - 2018-10-29 17:26:14 --> Router Class Initialized
INFO - 2018-10-29 17:26:14 --> Output Class Initialized
INFO - 2018-10-29 17:26:14 --> Security Class Initialized
DEBUG - 2018-10-29 17:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:26:14 --> CSRF cookie sent
INFO - 2018-10-29 17:26:14 --> Input Class Initialized
INFO - 2018-10-29 17:26:14 --> Language Class Initialized
INFO - 2018-10-29 17:26:14 --> Loader Class Initialized
INFO - 2018-10-29 17:26:14 --> Helper loaded: url_helper
INFO - 2018-10-29 17:26:14 --> Helper loaded: form_helper
INFO - 2018-10-29 17:26:14 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:26:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:26:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:26:14 --> User Agent Class Initialized
INFO - 2018-10-29 17:26:14 --> Controller Class Initialized
INFO - 2018-10-29 17:26:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:26:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:26:14 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:26:14 --> Pixel_Model class loaded
INFO - 2018-10-29 17:26:14 --> Database Driver Class Initialized
INFO - 2018-10-29 17:26:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:26:14 --> Database Driver Class Initialized
INFO - 2018-10-29 17:26:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:26:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 17:26:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 17:26:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 17:26:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 17:26:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-29 17:26:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-29 17:26:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/income.php
INFO - 2018-10-29 17:26:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 17:26:14 --> Final output sent to browser
DEBUG - 2018-10-29 17:26:15 --> Total execution time: 0.4028
INFO - 2018-10-29 17:26:17 --> Config Class Initialized
INFO - 2018-10-29 17:26:17 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:26:17 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:26:17 --> Utf8 Class Initialized
INFO - 2018-10-29 17:26:17 --> URI Class Initialized
INFO - 2018-10-29 17:26:17 --> Router Class Initialized
INFO - 2018-10-29 17:26:17 --> Output Class Initialized
INFO - 2018-10-29 17:26:17 --> Security Class Initialized
DEBUG - 2018-10-29 17:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:26:17 --> CSRF cookie sent
INFO - 2018-10-29 17:26:17 --> CSRF token verified
INFO - 2018-10-29 17:26:17 --> Input Class Initialized
INFO - 2018-10-29 17:26:17 --> Language Class Initialized
INFO - 2018-10-29 17:26:17 --> Loader Class Initialized
INFO - 2018-10-29 17:26:17 --> Helper loaded: url_helper
INFO - 2018-10-29 17:26:17 --> Helper loaded: form_helper
INFO - 2018-10-29 17:26:17 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:26:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:26:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:26:17 --> User Agent Class Initialized
INFO - 2018-10-29 17:26:18 --> Controller Class Initialized
INFO - 2018-10-29 17:26:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:26:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:26:18 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:26:18 --> Pixel_Model class loaded
INFO - 2018-10-29 17:26:18 --> Database Driver Class Initialized
INFO - 2018-10-29 17:26:18 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:26:18 --> Form Validation Class Initialized
INFO - 2018-10-29 17:26:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-29 17:26:18 --> Database Driver Class Initialized
INFO - 2018-10-29 17:26:18 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:26:18 --> Config Class Initialized
INFO - 2018-10-29 17:26:18 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:26:18 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:26:18 --> Utf8 Class Initialized
INFO - 2018-10-29 17:26:18 --> URI Class Initialized
INFO - 2018-10-29 17:26:18 --> Router Class Initialized
INFO - 2018-10-29 17:26:18 --> Output Class Initialized
INFO - 2018-10-29 17:26:18 --> Security Class Initialized
DEBUG - 2018-10-29 17:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:26:18 --> CSRF cookie sent
INFO - 2018-10-29 17:26:18 --> Input Class Initialized
INFO - 2018-10-29 17:26:18 --> Language Class Initialized
INFO - 2018-10-29 17:26:18 --> Loader Class Initialized
INFO - 2018-10-29 17:26:18 --> Helper loaded: url_helper
INFO - 2018-10-29 17:26:18 --> Helper loaded: form_helper
INFO - 2018-10-29 17:26:18 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:26:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:26:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:26:18 --> User Agent Class Initialized
INFO - 2018-10-29 17:26:18 --> Controller Class Initialized
INFO - 2018-10-29 17:26:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:26:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:26:18 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:26:18 --> Pixel_Model class loaded
INFO - 2018-10-29 17:26:18 --> Database Driver Class Initialized
INFO - 2018-10-29 17:26:18 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:26:18 --> Database Driver Class Initialized
INFO - 2018-10-29 17:26:18 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:26:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 17:26:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 17:26:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 17:26:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 17:26:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-29 17:26:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-29 17:26:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/marriage.php
INFO - 2018-10-29 17:26:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 17:26:18 --> Final output sent to browser
DEBUG - 2018-10-29 17:26:18 --> Total execution time: 0.3498
INFO - 2018-10-29 17:26:21 --> Config Class Initialized
INFO - 2018-10-29 17:26:21 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:26:21 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:26:21 --> Utf8 Class Initialized
INFO - 2018-10-29 17:26:21 --> URI Class Initialized
INFO - 2018-10-29 17:26:21 --> Router Class Initialized
INFO - 2018-10-29 17:26:21 --> Output Class Initialized
INFO - 2018-10-29 17:26:21 --> Security Class Initialized
DEBUG - 2018-10-29 17:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:26:21 --> CSRF cookie sent
INFO - 2018-10-29 17:26:22 --> CSRF token verified
INFO - 2018-10-29 17:26:22 --> Input Class Initialized
INFO - 2018-10-29 17:26:22 --> Language Class Initialized
INFO - 2018-10-29 17:26:22 --> Loader Class Initialized
INFO - 2018-10-29 17:26:22 --> Helper loaded: url_helper
INFO - 2018-10-29 17:26:22 --> Helper loaded: form_helper
INFO - 2018-10-29 17:26:22 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:26:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:26:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:26:22 --> User Agent Class Initialized
INFO - 2018-10-29 17:26:22 --> Controller Class Initialized
INFO - 2018-10-29 17:26:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:26:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:26:22 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:26:22 --> Pixel_Model class loaded
INFO - 2018-10-29 17:26:22 --> Database Driver Class Initialized
INFO - 2018-10-29 17:26:22 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:26:22 --> Form Validation Class Initialized
INFO - 2018-10-29 17:26:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-29 17:26:22 --> Database Driver Class Initialized
INFO - 2018-10-29 17:26:22 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:26:22 --> Config Class Initialized
INFO - 2018-10-29 17:26:22 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:26:22 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:26:22 --> Utf8 Class Initialized
INFO - 2018-10-29 17:26:22 --> URI Class Initialized
INFO - 2018-10-29 17:26:22 --> Router Class Initialized
INFO - 2018-10-29 17:26:22 --> Output Class Initialized
INFO - 2018-10-29 17:26:22 --> Security Class Initialized
DEBUG - 2018-10-29 17:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:26:22 --> CSRF cookie sent
INFO - 2018-10-29 17:26:22 --> Input Class Initialized
INFO - 2018-10-29 17:26:22 --> Language Class Initialized
INFO - 2018-10-29 17:26:22 --> Loader Class Initialized
INFO - 2018-10-29 17:26:22 --> Helper loaded: url_helper
INFO - 2018-10-29 17:26:22 --> Helper loaded: form_helper
INFO - 2018-10-29 17:26:22 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:26:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:26:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:26:22 --> User Agent Class Initialized
INFO - 2018-10-29 17:26:22 --> Controller Class Initialized
INFO - 2018-10-29 17:26:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:26:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:26:22 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:26:22 --> Pixel_Model class loaded
INFO - 2018-10-29 17:26:22 --> Database Driver Class Initialized
INFO - 2018-10-29 17:26:22 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:26:22 --> Database Driver Class Initialized
INFO - 2018-10-29 17:26:22 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:26:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 17:26:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 17:26:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 17:26:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 17:26:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-29 17:26:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-29 17:26:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/kids.php
INFO - 2018-10-29 17:26:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 17:26:22 --> Final output sent to browser
DEBUG - 2018-10-29 17:26:22 --> Total execution time: 0.3703
INFO - 2018-10-29 17:26:23 --> Config Class Initialized
INFO - 2018-10-29 17:26:23 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:26:23 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:26:23 --> Utf8 Class Initialized
INFO - 2018-10-29 17:26:23 --> URI Class Initialized
INFO - 2018-10-29 17:26:23 --> Router Class Initialized
INFO - 2018-10-29 17:26:23 --> Output Class Initialized
INFO - 2018-10-29 17:26:23 --> Security Class Initialized
DEBUG - 2018-10-29 17:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:26:24 --> CSRF cookie sent
INFO - 2018-10-29 17:26:24 --> CSRF token verified
INFO - 2018-10-29 17:26:24 --> Input Class Initialized
INFO - 2018-10-29 17:26:24 --> Language Class Initialized
INFO - 2018-10-29 17:26:24 --> Loader Class Initialized
INFO - 2018-10-29 17:26:24 --> Helper loaded: url_helper
INFO - 2018-10-29 17:26:24 --> Helper loaded: form_helper
INFO - 2018-10-29 17:26:24 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:26:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:26:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:26:24 --> User Agent Class Initialized
INFO - 2018-10-29 17:26:24 --> Controller Class Initialized
INFO - 2018-10-29 17:26:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:26:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:26:24 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:26:24 --> Pixel_Model class loaded
INFO - 2018-10-29 17:26:24 --> Database Driver Class Initialized
INFO - 2018-10-29 17:26:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:26:24 --> Form Validation Class Initialized
INFO - 2018-10-29 17:26:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-29 17:26:24 --> Database Driver Class Initialized
INFO - 2018-10-29 17:26:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:26:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 17:26:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 17:26:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 17:26:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 17:26:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-29 17:26:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_errors.php
INFO - 2018-10-29 17:26:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-29 17:26:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/kids.php
INFO - 2018-10-29 17:26:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 17:26:24 --> Final output sent to browser
DEBUG - 2018-10-29 17:26:24 --> Total execution time: 0.3857
INFO - 2018-10-29 17:26:27 --> Config Class Initialized
INFO - 2018-10-29 17:26:27 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:26:27 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:26:27 --> Utf8 Class Initialized
INFO - 2018-10-29 17:26:27 --> URI Class Initialized
INFO - 2018-10-29 17:26:27 --> Router Class Initialized
INFO - 2018-10-29 17:26:27 --> Output Class Initialized
INFO - 2018-10-29 17:26:27 --> Security Class Initialized
DEBUG - 2018-10-29 17:26:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:26:27 --> CSRF cookie sent
INFO - 2018-10-29 17:26:27 --> CSRF token verified
INFO - 2018-10-29 17:26:27 --> Input Class Initialized
INFO - 2018-10-29 17:26:27 --> Language Class Initialized
INFO - 2018-10-29 17:26:27 --> Loader Class Initialized
INFO - 2018-10-29 17:26:27 --> Helper loaded: url_helper
INFO - 2018-10-29 17:26:27 --> Helper loaded: form_helper
INFO - 2018-10-29 17:26:28 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:26:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:26:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:26:28 --> User Agent Class Initialized
INFO - 2018-10-29 17:26:28 --> Controller Class Initialized
INFO - 2018-10-29 17:26:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:26:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:26:28 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:26:28 --> Pixel_Model class loaded
INFO - 2018-10-29 17:26:28 --> Database Driver Class Initialized
INFO - 2018-10-29 17:26:28 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:26:28 --> Form Validation Class Initialized
INFO - 2018-10-29 17:26:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-29 17:26:28 --> Database Driver Class Initialized
INFO - 2018-10-29 17:26:28 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:26:28 --> Config Class Initialized
INFO - 2018-10-29 17:26:28 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:26:28 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:26:28 --> Utf8 Class Initialized
INFO - 2018-10-29 17:26:28 --> URI Class Initialized
INFO - 2018-10-29 17:26:28 --> Router Class Initialized
INFO - 2018-10-29 17:26:28 --> Output Class Initialized
INFO - 2018-10-29 17:26:28 --> Security Class Initialized
DEBUG - 2018-10-29 17:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:26:28 --> CSRF cookie sent
INFO - 2018-10-29 17:26:28 --> Input Class Initialized
INFO - 2018-10-29 17:26:28 --> Language Class Initialized
INFO - 2018-10-29 17:26:28 --> Loader Class Initialized
INFO - 2018-10-29 17:26:28 --> Helper loaded: url_helper
INFO - 2018-10-29 17:26:28 --> Helper loaded: form_helper
INFO - 2018-10-29 17:26:28 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:26:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:26:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:26:28 --> User Agent Class Initialized
INFO - 2018-10-29 17:26:28 --> Controller Class Initialized
INFO - 2018-10-29 17:26:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:26:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:26:28 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:26:28 --> Pixel_Model class loaded
INFO - 2018-10-29 17:26:28 --> Database Driver Class Initialized
INFO - 2018-10-29 17:26:28 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:26:28 --> Database Driver Class Initialized
INFO - 2018-10-29 17:26:28 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:26:28 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 17:26:28 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 17:26:28 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 17:26:28 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 17:26:28 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-29 17:26:28 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-29 17:26:28 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/pension.php
INFO - 2018-10-29 17:26:28 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 17:26:28 --> Final output sent to browser
DEBUG - 2018-10-29 17:26:28 --> Total execution time: 0.4277
INFO - 2018-10-29 17:26:31 --> Config Class Initialized
INFO - 2018-10-29 17:26:31 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:26:31 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:26:31 --> Utf8 Class Initialized
INFO - 2018-10-29 17:26:31 --> URI Class Initialized
INFO - 2018-10-29 17:26:31 --> Router Class Initialized
INFO - 2018-10-29 17:26:31 --> Output Class Initialized
INFO - 2018-10-29 17:26:31 --> Security Class Initialized
DEBUG - 2018-10-29 17:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:26:31 --> CSRF cookie sent
INFO - 2018-10-29 17:26:31 --> CSRF token verified
INFO - 2018-10-29 17:26:31 --> Input Class Initialized
INFO - 2018-10-29 17:26:31 --> Language Class Initialized
INFO - 2018-10-29 17:26:31 --> Loader Class Initialized
INFO - 2018-10-29 17:26:31 --> Helper loaded: url_helper
INFO - 2018-10-29 17:26:31 --> Helper loaded: form_helper
INFO - 2018-10-29 17:26:31 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:26:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:26:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:26:31 --> User Agent Class Initialized
INFO - 2018-10-29 17:26:31 --> Controller Class Initialized
INFO - 2018-10-29 17:26:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:26:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:26:31 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:26:31 --> Pixel_Model class loaded
INFO - 2018-10-29 17:26:31 --> Database Driver Class Initialized
INFO - 2018-10-29 17:26:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:26:31 --> Form Validation Class Initialized
INFO - 2018-10-29 17:26:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-29 17:26:31 --> Database Driver Class Initialized
INFO - 2018-10-29 17:26:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:26:31 --> Config Class Initialized
INFO - 2018-10-29 17:26:31 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:26:31 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:26:31 --> Utf8 Class Initialized
INFO - 2018-10-29 17:26:31 --> URI Class Initialized
INFO - 2018-10-29 17:26:31 --> Router Class Initialized
INFO - 2018-10-29 17:26:31 --> Output Class Initialized
INFO - 2018-10-29 17:26:31 --> Security Class Initialized
DEBUG - 2018-10-29 17:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:26:31 --> CSRF cookie sent
INFO - 2018-10-29 17:26:31 --> Input Class Initialized
INFO - 2018-10-29 17:26:31 --> Language Class Initialized
INFO - 2018-10-29 17:26:31 --> Loader Class Initialized
INFO - 2018-10-29 17:26:31 --> Helper loaded: url_helper
INFO - 2018-10-29 17:26:31 --> Helper loaded: form_helper
INFO - 2018-10-29 17:26:31 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:26:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:26:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:26:31 --> User Agent Class Initialized
INFO - 2018-10-29 17:26:31 --> Controller Class Initialized
INFO - 2018-10-29 17:26:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:26:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:26:31 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:26:31 --> Pixel_Model class loaded
INFO - 2018-10-29 17:26:31 --> Database Driver Class Initialized
INFO - 2018-10-29 17:26:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:26:31 --> Database Driver Class Initialized
INFO - 2018-10-29 17:26:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:26:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 17:26:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 17:26:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 17:26:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 17:26:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-29 17:26:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-29 17:26:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/inheritance.php
INFO - 2018-10-29 17:26:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 17:26:31 --> Final output sent to browser
DEBUG - 2018-10-29 17:26:31 --> Total execution time: 0.3750
INFO - 2018-10-29 17:26:33 --> Config Class Initialized
INFO - 2018-10-29 17:26:33 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:26:33 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:26:33 --> Utf8 Class Initialized
INFO - 2018-10-29 17:26:33 --> URI Class Initialized
INFO - 2018-10-29 17:26:33 --> Router Class Initialized
INFO - 2018-10-29 17:26:33 --> Output Class Initialized
INFO - 2018-10-29 17:26:33 --> Security Class Initialized
DEBUG - 2018-10-29 17:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:26:33 --> CSRF cookie sent
INFO - 2018-10-29 17:26:33 --> CSRF token verified
INFO - 2018-10-29 17:26:33 --> Input Class Initialized
INFO - 2018-10-29 17:26:33 --> Language Class Initialized
INFO - 2018-10-29 17:26:33 --> Loader Class Initialized
INFO - 2018-10-29 17:26:33 --> Helper loaded: url_helper
INFO - 2018-10-29 17:26:33 --> Helper loaded: form_helper
INFO - 2018-10-29 17:26:33 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:26:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:26:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:26:33 --> User Agent Class Initialized
INFO - 2018-10-29 17:26:33 --> Controller Class Initialized
INFO - 2018-10-29 17:26:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:26:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:26:33 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:26:33 --> Pixel_Model class loaded
INFO - 2018-10-29 17:26:33 --> Database Driver Class Initialized
INFO - 2018-10-29 17:26:33 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:26:33 --> Form Validation Class Initialized
INFO - 2018-10-29 17:26:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-29 17:26:33 --> Database Driver Class Initialized
INFO - 2018-10-29 17:26:33 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:26:33 --> Config Class Initialized
INFO - 2018-10-29 17:26:33 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:26:33 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:26:33 --> Utf8 Class Initialized
INFO - 2018-10-29 17:26:33 --> URI Class Initialized
INFO - 2018-10-29 17:26:33 --> Router Class Initialized
INFO - 2018-10-29 17:26:33 --> Output Class Initialized
INFO - 2018-10-29 17:26:33 --> Security Class Initialized
DEBUG - 2018-10-29 17:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:26:33 --> CSRF cookie sent
INFO - 2018-10-29 17:26:33 --> Input Class Initialized
INFO - 2018-10-29 17:26:33 --> Language Class Initialized
INFO - 2018-10-29 17:26:34 --> Loader Class Initialized
INFO - 2018-10-29 17:26:34 --> Helper loaded: url_helper
INFO - 2018-10-29 17:26:34 --> Helper loaded: form_helper
INFO - 2018-10-29 17:26:34 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:26:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:26:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:26:34 --> User Agent Class Initialized
INFO - 2018-10-29 17:26:34 --> Controller Class Initialized
INFO - 2018-10-29 17:26:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:26:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:26:34 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:26:34 --> Pixel_Model class loaded
INFO - 2018-10-29 17:26:34 --> Database Driver Class Initialized
INFO - 2018-10-29 17:26:34 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:26:34 --> Database Driver Class Initialized
INFO - 2018-10-29 17:26:34 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:26:34 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 17:26:34 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 17:26:34 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 17:26:34 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 17:26:34 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-29 17:26:34 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-29 17:26:34 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/inheritance_maintained.php
INFO - 2018-10-29 17:26:34 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 17:26:34 --> Final output sent to browser
DEBUG - 2018-10-29 17:26:34 --> Total execution time: 0.3855
INFO - 2018-10-29 17:26:35 --> Config Class Initialized
INFO - 2018-10-29 17:26:35 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:26:35 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:26:35 --> Utf8 Class Initialized
INFO - 2018-10-29 17:26:35 --> URI Class Initialized
INFO - 2018-10-29 17:26:35 --> Router Class Initialized
INFO - 2018-10-29 17:26:35 --> Output Class Initialized
INFO - 2018-10-29 17:26:35 --> Security Class Initialized
DEBUG - 2018-10-29 17:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:26:35 --> CSRF cookie sent
INFO - 2018-10-29 17:26:35 --> CSRF token verified
INFO - 2018-10-29 17:26:35 --> Input Class Initialized
INFO - 2018-10-29 17:26:35 --> Language Class Initialized
INFO - 2018-10-29 17:26:36 --> Loader Class Initialized
INFO - 2018-10-29 17:26:36 --> Helper loaded: url_helper
INFO - 2018-10-29 17:26:36 --> Helper loaded: form_helper
INFO - 2018-10-29 17:26:36 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:26:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:26:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:26:36 --> User Agent Class Initialized
INFO - 2018-10-29 17:26:36 --> Controller Class Initialized
INFO - 2018-10-29 17:26:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:26:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:26:36 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:26:36 --> Pixel_Model class loaded
INFO - 2018-10-29 17:26:36 --> Database Driver Class Initialized
INFO - 2018-10-29 17:26:36 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:26:36 --> Form Validation Class Initialized
INFO - 2018-10-29 17:26:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-29 17:26:36 --> Database Driver Class Initialized
INFO - 2018-10-29 17:26:36 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:26:36 --> Config Class Initialized
INFO - 2018-10-29 17:26:36 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:26:36 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:26:36 --> Utf8 Class Initialized
INFO - 2018-10-29 17:26:36 --> URI Class Initialized
INFO - 2018-10-29 17:26:36 --> Router Class Initialized
INFO - 2018-10-29 17:26:36 --> Output Class Initialized
INFO - 2018-10-29 17:26:36 --> Security Class Initialized
DEBUG - 2018-10-29 17:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:26:36 --> CSRF cookie sent
INFO - 2018-10-29 17:26:36 --> Input Class Initialized
INFO - 2018-10-29 17:26:36 --> Language Class Initialized
INFO - 2018-10-29 17:26:36 --> Loader Class Initialized
INFO - 2018-10-29 17:26:36 --> Helper loaded: url_helper
INFO - 2018-10-29 17:26:36 --> Helper loaded: form_helper
INFO - 2018-10-29 17:26:36 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:26:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:26:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:26:36 --> User Agent Class Initialized
INFO - 2018-10-29 17:26:36 --> Controller Class Initialized
INFO - 2018-10-29 17:26:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:26:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:26:36 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:26:36 --> Pixel_Model class loaded
INFO - 2018-10-29 17:26:36 --> Database Driver Class Initialized
INFO - 2018-10-29 17:26:36 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:26:36 --> Database Driver Class Initialized
INFO - 2018-10-29 17:26:36 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:26:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 17:26:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 17:26:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 17:26:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 17:26:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-29 17:26:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-29 17:26:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/home_owner.php
INFO - 2018-10-29 17:26:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 17:26:36 --> Final output sent to browser
DEBUG - 2018-10-29 17:26:36 --> Total execution time: 0.3842
INFO - 2018-10-29 17:26:38 --> Config Class Initialized
INFO - 2018-10-29 17:26:38 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:26:38 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:26:38 --> Utf8 Class Initialized
INFO - 2018-10-29 17:26:38 --> URI Class Initialized
INFO - 2018-10-29 17:26:38 --> Router Class Initialized
INFO - 2018-10-29 17:26:38 --> Output Class Initialized
INFO - 2018-10-29 17:26:38 --> Security Class Initialized
DEBUG - 2018-10-29 17:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:26:38 --> CSRF cookie sent
INFO - 2018-10-29 17:26:38 --> CSRF token verified
INFO - 2018-10-29 17:26:38 --> Input Class Initialized
INFO - 2018-10-29 17:26:38 --> Language Class Initialized
INFO - 2018-10-29 17:26:38 --> Loader Class Initialized
INFO - 2018-10-29 17:26:38 --> Helper loaded: url_helper
INFO - 2018-10-29 17:26:38 --> Helper loaded: form_helper
INFO - 2018-10-29 17:26:38 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:26:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:26:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:26:38 --> User Agent Class Initialized
INFO - 2018-10-29 17:26:38 --> Controller Class Initialized
INFO - 2018-10-29 17:26:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:26:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:26:38 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:26:38 --> Pixel_Model class loaded
INFO - 2018-10-29 17:26:38 --> Database Driver Class Initialized
INFO - 2018-10-29 17:26:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:26:38 --> Form Validation Class Initialized
INFO - 2018-10-29 17:26:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-29 17:26:38 --> Database Driver Class Initialized
INFO - 2018-10-29 17:26:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:26:38 --> Config Class Initialized
INFO - 2018-10-29 17:26:38 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:26:38 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:26:38 --> Utf8 Class Initialized
INFO - 2018-10-29 17:26:38 --> URI Class Initialized
INFO - 2018-10-29 17:26:38 --> Router Class Initialized
INFO - 2018-10-29 17:26:38 --> Output Class Initialized
INFO - 2018-10-29 17:26:38 --> Security Class Initialized
DEBUG - 2018-10-29 17:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:26:38 --> CSRF cookie sent
INFO - 2018-10-29 17:26:38 --> Input Class Initialized
INFO - 2018-10-29 17:26:38 --> Language Class Initialized
INFO - 2018-10-29 17:26:38 --> Loader Class Initialized
INFO - 2018-10-29 17:26:38 --> Helper loaded: url_helper
INFO - 2018-10-29 17:26:38 --> Helper loaded: form_helper
INFO - 2018-10-29 17:26:38 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:26:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:26:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:26:38 --> User Agent Class Initialized
INFO - 2018-10-29 17:26:38 --> Controller Class Initialized
INFO - 2018-10-29 17:26:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:26:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:26:38 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:26:38 --> Pixel_Model class loaded
INFO - 2018-10-29 17:26:38 --> Database Driver Class Initialized
INFO - 2018-10-29 17:26:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:26:38 --> Database Driver Class Initialized
INFO - 2018-10-29 17:26:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:26:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 17:26:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 17:26:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 17:26:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 17:26:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-29 17:26:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-29 17:26:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/home_value.php
INFO - 2018-10-29 17:26:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 17:26:38 --> Final output sent to browser
DEBUG - 2018-10-29 17:26:38 --> Total execution time: 0.4141
INFO - 2018-10-29 17:26:42 --> Config Class Initialized
INFO - 2018-10-29 17:26:42 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:26:42 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:26:42 --> Utf8 Class Initialized
INFO - 2018-10-29 17:26:42 --> URI Class Initialized
INFO - 2018-10-29 17:26:42 --> Router Class Initialized
INFO - 2018-10-29 17:26:42 --> Output Class Initialized
INFO - 2018-10-29 17:26:42 --> Security Class Initialized
DEBUG - 2018-10-29 17:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:26:42 --> CSRF cookie sent
INFO - 2018-10-29 17:26:42 --> CSRF token verified
INFO - 2018-10-29 17:26:42 --> Input Class Initialized
INFO - 2018-10-29 17:26:42 --> Language Class Initialized
INFO - 2018-10-29 17:26:42 --> Loader Class Initialized
INFO - 2018-10-29 17:26:42 --> Helper loaded: url_helper
INFO - 2018-10-29 17:26:42 --> Helper loaded: form_helper
INFO - 2018-10-29 17:26:42 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:26:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:26:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:26:42 --> User Agent Class Initialized
INFO - 2018-10-29 17:26:42 --> Controller Class Initialized
INFO - 2018-10-29 17:26:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:26:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:26:42 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:26:42 --> Pixel_Model class loaded
INFO - 2018-10-29 17:26:42 --> Database Driver Class Initialized
INFO - 2018-10-29 17:26:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:26:42 --> Form Validation Class Initialized
INFO - 2018-10-29 17:26:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-29 17:26:42 --> Database Driver Class Initialized
INFO - 2018-10-29 17:26:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:26:42 --> Config Class Initialized
INFO - 2018-10-29 17:26:42 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:26:42 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:26:42 --> Utf8 Class Initialized
INFO - 2018-10-29 17:26:42 --> URI Class Initialized
INFO - 2018-10-29 17:26:42 --> Router Class Initialized
INFO - 2018-10-29 17:26:42 --> Output Class Initialized
INFO - 2018-10-29 17:26:42 --> Security Class Initialized
DEBUG - 2018-10-29 17:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:26:42 --> CSRF cookie sent
INFO - 2018-10-29 17:26:42 --> Input Class Initialized
INFO - 2018-10-29 17:26:42 --> Language Class Initialized
INFO - 2018-10-29 17:26:42 --> Loader Class Initialized
INFO - 2018-10-29 17:26:42 --> Helper loaded: url_helper
INFO - 2018-10-29 17:26:42 --> Helper loaded: form_helper
INFO - 2018-10-29 17:26:42 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:26:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:26:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:26:42 --> User Agent Class Initialized
INFO - 2018-10-29 17:26:42 --> Controller Class Initialized
INFO - 2018-10-29 17:26:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:26:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:26:42 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:26:42 --> Pixel_Model class loaded
INFO - 2018-10-29 17:26:42 --> Database Driver Class Initialized
INFO - 2018-10-29 17:26:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:26:42 --> Database Driver Class Initialized
INFO - 2018-10-29 17:26:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:26:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 17:26:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 17:26:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 17:26:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 17:26:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-29 17:26:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-29 17:26:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/merriage_home_title.php
INFO - 2018-10-29 17:26:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 17:26:42 --> Final output sent to browser
DEBUG - 2018-10-29 17:26:42 --> Total execution time: 0.4130
INFO - 2018-10-29 17:26:44 --> Config Class Initialized
INFO - 2018-10-29 17:26:44 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:26:44 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:26:44 --> Utf8 Class Initialized
INFO - 2018-10-29 17:26:44 --> URI Class Initialized
INFO - 2018-10-29 17:26:44 --> Router Class Initialized
INFO - 2018-10-29 17:26:44 --> Output Class Initialized
INFO - 2018-10-29 17:26:44 --> Security Class Initialized
DEBUG - 2018-10-29 17:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:26:44 --> CSRF cookie sent
INFO - 2018-10-29 17:26:44 --> CSRF token verified
INFO - 2018-10-29 17:26:44 --> Input Class Initialized
INFO - 2018-10-29 17:26:44 --> Language Class Initialized
INFO - 2018-10-29 17:26:44 --> Loader Class Initialized
INFO - 2018-10-29 17:26:44 --> Helper loaded: url_helper
INFO - 2018-10-29 17:26:44 --> Helper loaded: form_helper
INFO - 2018-10-29 17:26:44 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:26:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:26:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:26:44 --> User Agent Class Initialized
INFO - 2018-10-29 17:26:44 --> Controller Class Initialized
INFO - 2018-10-29 17:26:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:26:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:26:44 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:26:44 --> Pixel_Model class loaded
INFO - 2018-10-29 17:26:44 --> Database Driver Class Initialized
INFO - 2018-10-29 17:26:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:26:44 --> Form Validation Class Initialized
INFO - 2018-10-29 17:26:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-29 17:26:44 --> Database Driver Class Initialized
INFO - 2018-10-29 17:26:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:26:44 --> Config Class Initialized
INFO - 2018-10-29 17:26:44 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:26:44 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:26:44 --> Utf8 Class Initialized
INFO - 2018-10-29 17:26:44 --> URI Class Initialized
INFO - 2018-10-29 17:26:44 --> Router Class Initialized
INFO - 2018-10-29 17:26:44 --> Output Class Initialized
INFO - 2018-10-29 17:26:44 --> Security Class Initialized
DEBUG - 2018-10-29 17:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:26:44 --> CSRF cookie sent
INFO - 2018-10-29 17:26:44 --> Input Class Initialized
INFO - 2018-10-29 17:26:44 --> Language Class Initialized
INFO - 2018-10-29 17:26:44 --> Loader Class Initialized
INFO - 2018-10-29 17:26:44 --> Helper loaded: url_helper
INFO - 2018-10-29 17:26:44 --> Helper loaded: form_helper
INFO - 2018-10-29 17:26:44 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:26:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:26:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:26:44 --> User Agent Class Initialized
INFO - 2018-10-29 17:26:44 --> Controller Class Initialized
INFO - 2018-10-29 17:26:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:26:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:26:44 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:26:44 --> Pixel_Model class loaded
INFO - 2018-10-29 17:26:44 --> Database Driver Class Initialized
INFO - 2018-10-29 17:26:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:26:44 --> Database Driver Class Initialized
INFO - 2018-10-29 17:26:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:26:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 17:26:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 17:26:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 17:26:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 17:26:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-29 17:26:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-29 17:26:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/financial.php
INFO - 2018-10-29 17:26:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 17:26:45 --> Final output sent to browser
DEBUG - 2018-10-29 17:26:45 --> Total execution time: 0.3941
INFO - 2018-10-29 17:26:46 --> Config Class Initialized
INFO - 2018-10-29 17:26:46 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:26:46 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:26:46 --> Utf8 Class Initialized
INFO - 2018-10-29 17:26:46 --> URI Class Initialized
INFO - 2018-10-29 17:26:46 --> Router Class Initialized
INFO - 2018-10-29 17:26:46 --> Output Class Initialized
INFO - 2018-10-29 17:26:46 --> Security Class Initialized
DEBUG - 2018-10-29 17:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:26:46 --> CSRF cookie sent
INFO - 2018-10-29 17:26:46 --> CSRF token verified
INFO - 2018-10-29 17:26:46 --> Input Class Initialized
INFO - 2018-10-29 17:26:46 --> Language Class Initialized
INFO - 2018-10-29 17:26:46 --> Loader Class Initialized
INFO - 2018-10-29 17:26:46 --> Helper loaded: url_helper
INFO - 2018-10-29 17:26:46 --> Helper loaded: form_helper
INFO - 2018-10-29 17:26:46 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:26:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:26:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:26:46 --> User Agent Class Initialized
INFO - 2018-10-29 17:26:46 --> Controller Class Initialized
INFO - 2018-10-29 17:26:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:26:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:26:46 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:26:46 --> Pixel_Model class loaded
INFO - 2018-10-29 17:26:46 --> Database Driver Class Initialized
INFO - 2018-10-29 17:26:46 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:26:46 --> Form Validation Class Initialized
INFO - 2018-10-29 17:26:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-29 17:26:46 --> Database Driver Class Initialized
INFO - 2018-10-29 17:26:46 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:26:46 --> Config Class Initialized
INFO - 2018-10-29 17:26:46 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:26:46 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:26:46 --> Utf8 Class Initialized
INFO - 2018-10-29 17:26:46 --> URI Class Initialized
INFO - 2018-10-29 17:26:46 --> Router Class Initialized
INFO - 2018-10-29 17:26:46 --> Output Class Initialized
INFO - 2018-10-29 17:26:46 --> Security Class Initialized
DEBUG - 2018-10-29 17:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:26:46 --> CSRF cookie sent
INFO - 2018-10-29 17:26:46 --> Input Class Initialized
INFO - 2018-10-29 17:26:46 --> Language Class Initialized
INFO - 2018-10-29 17:26:46 --> Loader Class Initialized
INFO - 2018-10-29 17:26:46 --> Helper loaded: url_helper
INFO - 2018-10-29 17:26:46 --> Helper loaded: form_helper
INFO - 2018-10-29 17:26:46 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:26:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:26:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:26:46 --> User Agent Class Initialized
INFO - 2018-10-29 17:26:46 --> Controller Class Initialized
INFO - 2018-10-29 17:26:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:26:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:26:46 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:26:46 --> Pixel_Model class loaded
INFO - 2018-10-29 17:26:46 --> Database Driver Class Initialized
INFO - 2018-10-29 17:26:46 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:26:46 --> Database Driver Class Initialized
INFO - 2018-10-29 17:26:46 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:26:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 17:26:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 17:26:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 17:26:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 17:26:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/risk_report.php
INFO - 2018-10-29 17:26:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 17:26:47 --> Final output sent to browser
DEBUG - 2018-10-29 17:26:47 --> Total execution time: 0.3984
INFO - 2018-10-29 17:26:52 --> Config Class Initialized
INFO - 2018-10-29 17:26:52 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:26:52 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:26:52 --> Utf8 Class Initialized
INFO - 2018-10-29 17:26:52 --> URI Class Initialized
INFO - 2018-10-29 17:26:52 --> Router Class Initialized
INFO - 2018-10-29 17:26:52 --> Output Class Initialized
INFO - 2018-10-29 17:26:52 --> Security Class Initialized
DEBUG - 2018-10-29 17:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:26:52 --> CSRF cookie sent
INFO - 2018-10-29 17:26:52 --> Input Class Initialized
INFO - 2018-10-29 17:26:52 --> Language Class Initialized
INFO - 2018-10-29 17:26:52 --> Loader Class Initialized
INFO - 2018-10-29 17:26:52 --> Helper loaded: url_helper
INFO - 2018-10-29 17:26:52 --> Helper loaded: form_helper
INFO - 2018-10-29 17:26:52 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:26:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:26:52 --> User Agent Class Initialized
INFO - 2018-10-29 17:26:52 --> Controller Class Initialized
INFO - 2018-10-29 17:26:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:26:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:26:52 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:26:52 --> Pixel_Model class loaded
INFO - 2018-10-29 17:26:52 --> Database Driver Class Initialized
INFO - 2018-10-29 17:26:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:26:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 17:26:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 17:26:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 17:26:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 17:26:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/contact_us.php
INFO - 2018-10-29 17:26:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 17:26:52 --> Final output sent to browser
DEBUG - 2018-10-29 17:26:52 --> Total execution time: 0.3620
INFO - 2018-10-29 17:26:58 --> Config Class Initialized
INFO - 2018-10-29 17:26:58 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:26:58 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:26:58 --> Utf8 Class Initialized
INFO - 2018-10-29 17:26:58 --> URI Class Initialized
INFO - 2018-10-29 17:26:58 --> Router Class Initialized
INFO - 2018-10-29 17:26:58 --> Output Class Initialized
INFO - 2018-10-29 17:26:58 --> Security Class Initialized
DEBUG - 2018-10-29 17:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:26:58 --> CSRF cookie sent
INFO - 2018-10-29 17:26:58 --> Input Class Initialized
INFO - 2018-10-29 17:26:58 --> Language Class Initialized
INFO - 2018-10-29 17:26:58 --> Loader Class Initialized
INFO - 2018-10-29 17:26:58 --> Helper loaded: url_helper
INFO - 2018-10-29 17:26:58 --> Helper loaded: form_helper
INFO - 2018-10-29 17:26:58 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:26:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:26:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:26:58 --> User Agent Class Initialized
INFO - 2018-10-29 17:26:58 --> Controller Class Initialized
INFO - 2018-10-29 17:26:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:26:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:26:58 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:26:58 --> Pixel_Model class loaded
INFO - 2018-10-29 17:26:58 --> Database Driver Class Initialized
INFO - 2018-10-29 17:26:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:26:58 --> Database Driver Class Initialized
INFO - 2018-10-29 17:26:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:26:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 17:26:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 17:26:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 17:26:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 17:26:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/risk_report.php
INFO - 2018-10-29 17:26:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 17:26:58 --> Final output sent to browser
DEBUG - 2018-10-29 17:26:58 --> Total execution time: 0.4004
INFO - 2018-10-29 17:28:12 --> Config Class Initialized
INFO - 2018-10-29 17:28:12 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:28:12 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:28:12 --> Utf8 Class Initialized
INFO - 2018-10-29 17:28:12 --> URI Class Initialized
DEBUG - 2018-10-29 17:28:12 --> No URI present. Default controller set.
INFO - 2018-10-29 17:28:12 --> Router Class Initialized
INFO - 2018-10-29 17:28:12 --> Output Class Initialized
INFO - 2018-10-29 17:28:12 --> Security Class Initialized
DEBUG - 2018-10-29 17:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:28:12 --> CSRF cookie sent
INFO - 2018-10-29 17:28:12 --> Input Class Initialized
INFO - 2018-10-29 17:28:12 --> Language Class Initialized
INFO - 2018-10-29 17:28:12 --> Loader Class Initialized
INFO - 2018-10-29 17:28:12 --> Helper loaded: url_helper
INFO - 2018-10-29 17:28:12 --> Helper loaded: form_helper
INFO - 2018-10-29 17:28:12 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:28:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:28:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:28:12 --> User Agent Class Initialized
INFO - 2018-10-29 17:28:12 --> Controller Class Initialized
INFO - 2018-10-29 17:28:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:28:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:28:12 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:28:12 --> Pixel_Model class loaded
INFO - 2018-10-29 17:28:12 --> Database Driver Class Initialized
INFO - 2018-10-29 17:28:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:28:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 17:28:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 17:28:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-29 17:28:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 17:28:12 --> Final output sent to browser
DEBUG - 2018-10-29 17:28:12 --> Total execution time: 0.3314
INFO - 2018-10-29 17:28:18 --> Config Class Initialized
INFO - 2018-10-29 17:28:18 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:28:18 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:28:18 --> Utf8 Class Initialized
INFO - 2018-10-29 17:28:18 --> URI Class Initialized
INFO - 2018-10-29 17:28:18 --> Router Class Initialized
INFO - 2018-10-29 17:28:18 --> Output Class Initialized
INFO - 2018-10-29 17:28:18 --> Security Class Initialized
DEBUG - 2018-10-29 17:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:28:18 --> CSRF cookie sent
INFO - 2018-10-29 17:28:18 --> Input Class Initialized
INFO - 2018-10-29 17:28:18 --> Language Class Initialized
INFO - 2018-10-29 17:28:18 --> Loader Class Initialized
INFO - 2018-10-29 17:28:18 --> Helper loaded: url_helper
INFO - 2018-10-29 17:28:18 --> Helper loaded: form_helper
INFO - 2018-10-29 17:28:18 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:28:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:28:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:28:18 --> User Agent Class Initialized
INFO - 2018-10-29 17:28:18 --> Controller Class Initialized
INFO - 2018-10-29 17:28:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:28:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:28:18 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:28:18 --> Pixel_Model class loaded
INFO - 2018-10-29 17:28:18 --> Database Driver Class Initialized
INFO - 2018-10-29 17:28:18 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:28:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 17:28:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 17:28:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 17:28:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 17:28:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-29 17:28:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-29 17:28:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-29 17:28:18 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 17:28:18 --> Final output sent to browser
DEBUG - 2018-10-29 17:28:18 --> Total execution time: 0.3686
INFO - 2018-10-29 17:28:20 --> Config Class Initialized
INFO - 2018-10-29 17:28:20 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:28:20 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:28:20 --> Utf8 Class Initialized
INFO - 2018-10-29 17:28:20 --> URI Class Initialized
INFO - 2018-10-29 17:28:20 --> Router Class Initialized
INFO - 2018-10-29 17:28:20 --> Output Class Initialized
INFO - 2018-10-29 17:28:20 --> Security Class Initialized
DEBUG - 2018-10-29 17:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:28:20 --> CSRF cookie sent
INFO - 2018-10-29 17:28:20 --> CSRF token verified
INFO - 2018-10-29 17:28:20 --> Input Class Initialized
INFO - 2018-10-29 17:28:20 --> Language Class Initialized
INFO - 2018-10-29 17:28:20 --> Loader Class Initialized
INFO - 2018-10-29 17:28:20 --> Helper loaded: url_helper
INFO - 2018-10-29 17:28:20 --> Helper loaded: form_helper
INFO - 2018-10-29 17:28:20 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:28:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:28:21 --> User Agent Class Initialized
INFO - 2018-10-29 17:28:21 --> Controller Class Initialized
INFO - 2018-10-29 17:28:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:28:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:28:21 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:28:21 --> Pixel_Model class loaded
INFO - 2018-10-29 17:28:21 --> Database Driver Class Initialized
INFO - 2018-10-29 17:28:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:28:21 --> Database Driver Class Initialized
INFO - 2018-10-29 17:28:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:28:21 --> Config Class Initialized
INFO - 2018-10-29 17:28:21 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:28:21 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:28:21 --> Utf8 Class Initialized
INFO - 2018-10-29 17:28:21 --> URI Class Initialized
INFO - 2018-10-29 17:28:21 --> Router Class Initialized
INFO - 2018-10-29 17:28:21 --> Output Class Initialized
INFO - 2018-10-29 17:28:21 --> Security Class Initialized
DEBUG - 2018-10-29 17:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:28:21 --> CSRF cookie sent
INFO - 2018-10-29 17:28:21 --> Input Class Initialized
INFO - 2018-10-29 17:28:21 --> Language Class Initialized
INFO - 2018-10-29 17:28:21 --> Loader Class Initialized
INFO - 2018-10-29 17:28:21 --> Helper loaded: url_helper
INFO - 2018-10-29 17:28:21 --> Helper loaded: form_helper
INFO - 2018-10-29 17:28:21 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:28:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:28:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:28:21 --> User Agent Class Initialized
INFO - 2018-10-29 17:28:21 --> Controller Class Initialized
INFO - 2018-10-29 17:28:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:28:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:28:21 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:28:21 --> Pixel_Model class loaded
INFO - 2018-10-29 17:28:21 --> Database Driver Class Initialized
INFO - 2018-10-29 17:28:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:28:21 --> Database Driver Class Initialized
INFO - 2018-10-29 17:28:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:28:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 17:28:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 17:28:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 17:28:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 17:28:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-29 17:28:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-29 17:28:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-29 17:28:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 17:28:21 --> Final output sent to browser
DEBUG - 2018-10-29 17:28:21 --> Total execution time: 0.3687
INFO - 2018-10-29 17:28:24 --> Config Class Initialized
INFO - 2018-10-29 17:28:24 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:28:24 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:28:24 --> Utf8 Class Initialized
INFO - 2018-10-29 17:28:24 --> URI Class Initialized
INFO - 2018-10-29 17:28:24 --> Router Class Initialized
INFO - 2018-10-29 17:28:24 --> Output Class Initialized
INFO - 2018-10-29 17:28:24 --> Security Class Initialized
DEBUG - 2018-10-29 17:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:28:24 --> CSRF cookie sent
INFO - 2018-10-29 17:28:24 --> CSRF token verified
INFO - 2018-10-29 17:28:24 --> Input Class Initialized
INFO - 2018-10-29 17:28:24 --> Language Class Initialized
INFO - 2018-10-29 17:28:24 --> Loader Class Initialized
INFO - 2018-10-29 17:28:24 --> Helper loaded: url_helper
INFO - 2018-10-29 17:28:24 --> Helper loaded: form_helper
INFO - 2018-10-29 17:28:24 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:28:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:28:24 --> User Agent Class Initialized
INFO - 2018-10-29 17:28:24 --> Controller Class Initialized
INFO - 2018-10-29 17:28:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:28:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:28:24 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:28:24 --> Pixel_Model class loaded
INFO - 2018-10-29 17:28:24 --> Database Driver Class Initialized
INFO - 2018-10-29 17:28:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:28:24 --> Form Validation Class Initialized
INFO - 2018-10-29 17:28:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-29 17:28:24 --> Database Driver Class Initialized
INFO - 2018-10-29 17:28:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:28:24 --> Config Class Initialized
INFO - 2018-10-29 17:28:24 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:28:24 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:28:24 --> Utf8 Class Initialized
INFO - 2018-10-29 17:28:24 --> URI Class Initialized
INFO - 2018-10-29 17:28:24 --> Router Class Initialized
INFO - 2018-10-29 17:28:24 --> Output Class Initialized
INFO - 2018-10-29 17:28:24 --> Security Class Initialized
DEBUG - 2018-10-29 17:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:28:24 --> CSRF cookie sent
INFO - 2018-10-29 17:28:24 --> Input Class Initialized
INFO - 2018-10-29 17:28:24 --> Language Class Initialized
INFO - 2018-10-29 17:28:24 --> Loader Class Initialized
INFO - 2018-10-29 17:28:24 --> Helper loaded: url_helper
INFO - 2018-10-29 17:28:24 --> Helper loaded: form_helper
INFO - 2018-10-29 17:28:25 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:28:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:28:25 --> User Agent Class Initialized
INFO - 2018-10-29 17:28:25 --> Controller Class Initialized
INFO - 2018-10-29 17:28:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:28:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:28:25 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:28:25 --> Pixel_Model class loaded
INFO - 2018-10-29 17:28:25 --> Database Driver Class Initialized
INFO - 2018-10-29 17:28:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:28:25 --> Database Driver Class Initialized
INFO - 2018-10-29 17:28:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:28:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 17:28:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 17:28:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 17:28:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 17:28:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-29 17:28:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-29 17:28:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/your_job.php
INFO - 2018-10-29 17:28:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 17:28:25 --> Final output sent to browser
DEBUG - 2018-10-29 17:28:25 --> Total execution time: 0.3842
INFO - 2018-10-29 17:28:25 --> Config Class Initialized
INFO - 2018-10-29 17:28:25 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:28:25 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:28:25 --> Utf8 Class Initialized
INFO - 2018-10-29 17:28:25 --> URI Class Initialized
INFO - 2018-10-29 17:28:25 --> Router Class Initialized
INFO - 2018-10-29 17:28:25 --> Output Class Initialized
INFO - 2018-10-29 17:28:25 --> Security Class Initialized
DEBUG - 2018-10-29 17:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:28:25 --> CSRF cookie sent
INFO - 2018-10-29 17:28:25 --> CSRF token verified
INFO - 2018-10-29 17:28:25 --> Input Class Initialized
INFO - 2018-10-29 17:28:25 --> Language Class Initialized
INFO - 2018-10-29 17:28:25 --> Loader Class Initialized
INFO - 2018-10-29 17:28:25 --> Helper loaded: url_helper
INFO - 2018-10-29 17:28:25 --> Helper loaded: form_helper
INFO - 2018-10-29 17:28:25 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:28:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:28:26 --> User Agent Class Initialized
INFO - 2018-10-29 17:28:26 --> Controller Class Initialized
INFO - 2018-10-29 17:28:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:28:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:28:26 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:28:26 --> Pixel_Model class loaded
INFO - 2018-10-29 17:28:26 --> Database Driver Class Initialized
INFO - 2018-10-29 17:28:26 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:28:26 --> Form Validation Class Initialized
INFO - 2018-10-29 17:28:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-29 17:28:26 --> Database Driver Class Initialized
INFO - 2018-10-29 17:28:26 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:28:26 --> Config Class Initialized
INFO - 2018-10-29 17:28:26 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:28:26 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:28:26 --> Utf8 Class Initialized
INFO - 2018-10-29 17:28:26 --> URI Class Initialized
INFO - 2018-10-29 17:28:26 --> Router Class Initialized
INFO - 2018-10-29 17:28:26 --> Output Class Initialized
INFO - 2018-10-29 17:28:26 --> Security Class Initialized
DEBUG - 2018-10-29 17:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:28:26 --> CSRF cookie sent
INFO - 2018-10-29 17:28:26 --> Input Class Initialized
INFO - 2018-10-29 17:28:26 --> Language Class Initialized
INFO - 2018-10-29 17:28:26 --> Loader Class Initialized
INFO - 2018-10-29 17:28:26 --> Helper loaded: url_helper
INFO - 2018-10-29 17:28:26 --> Helper loaded: form_helper
INFO - 2018-10-29 17:28:26 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:28:26 --> User Agent Class Initialized
INFO - 2018-10-29 17:28:26 --> Controller Class Initialized
INFO - 2018-10-29 17:28:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:28:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:28:26 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:28:26 --> Pixel_Model class loaded
INFO - 2018-10-29 17:28:26 --> Database Driver Class Initialized
INFO - 2018-10-29 17:28:26 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:28:26 --> Database Driver Class Initialized
INFO - 2018-10-29 17:28:26 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:28:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 17:28:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 17:28:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner.php
INFO - 2018-10-29 17:28:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 17:28:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 17:28:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-29 17:28:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-29 17:28:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/relation_ship_status.php
INFO - 2018-10-29 17:28:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 17:28:26 --> Final output sent to browser
DEBUG - 2018-10-29 17:28:26 --> Total execution time: 0.3828
INFO - 2018-10-29 17:28:27 --> Config Class Initialized
INFO - 2018-10-29 17:28:27 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:28:27 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:28:27 --> Utf8 Class Initialized
INFO - 2018-10-29 17:28:27 --> URI Class Initialized
INFO - 2018-10-29 17:28:27 --> Router Class Initialized
INFO - 2018-10-29 17:28:27 --> Output Class Initialized
INFO - 2018-10-29 17:28:27 --> Security Class Initialized
DEBUG - 2018-10-29 17:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:28:27 --> CSRF cookie sent
INFO - 2018-10-29 17:28:27 --> CSRF token verified
INFO - 2018-10-29 17:28:27 --> Input Class Initialized
INFO - 2018-10-29 17:28:27 --> Language Class Initialized
INFO - 2018-10-29 17:28:27 --> Loader Class Initialized
INFO - 2018-10-29 17:28:27 --> Helper loaded: url_helper
INFO - 2018-10-29 17:28:27 --> Helper loaded: form_helper
INFO - 2018-10-29 17:28:27 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:28:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:28:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:28:27 --> User Agent Class Initialized
INFO - 2018-10-29 17:28:27 --> Controller Class Initialized
INFO - 2018-10-29 17:28:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:28:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:28:27 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:28:27 --> Pixel_Model class loaded
INFO - 2018-10-29 17:28:27 --> Database Driver Class Initialized
INFO - 2018-10-29 17:28:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:28:27 --> Form Validation Class Initialized
INFO - 2018-10-29 17:28:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-29 17:28:27 --> Database Driver Class Initialized
INFO - 2018-10-29 17:28:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:28:27 --> Config Class Initialized
INFO - 2018-10-29 17:28:27 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:28:27 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:28:27 --> Utf8 Class Initialized
INFO - 2018-10-29 17:28:27 --> URI Class Initialized
INFO - 2018-10-29 17:28:27 --> Router Class Initialized
INFO - 2018-10-29 17:28:27 --> Output Class Initialized
INFO - 2018-10-29 17:28:27 --> Security Class Initialized
DEBUG - 2018-10-29 17:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:28:27 --> CSRF cookie sent
INFO - 2018-10-29 17:28:27 --> Input Class Initialized
INFO - 2018-10-29 17:28:27 --> Language Class Initialized
INFO - 2018-10-29 17:28:27 --> Loader Class Initialized
INFO - 2018-10-29 17:28:27 --> Helper loaded: url_helper
INFO - 2018-10-29 17:28:27 --> Helper loaded: form_helper
INFO - 2018-10-29 17:28:27 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:28:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:28:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:28:27 --> User Agent Class Initialized
INFO - 2018-10-29 17:28:27 --> Controller Class Initialized
INFO - 2018-10-29 17:28:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:28:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:28:27 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:28:27 --> Pixel_Model class loaded
INFO - 2018-10-29 17:28:27 --> Database Driver Class Initialized
INFO - 2018-10-29 17:28:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:28:27 --> Database Driver Class Initialized
INFO - 2018-10-29 17:28:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:28:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 17:28:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 17:28:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 17:28:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 17:28:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-29 17:28:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-29 17:28:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/income.php
INFO - 2018-10-29 17:28:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 17:28:27 --> Final output sent to browser
DEBUG - 2018-10-29 17:28:27 --> Total execution time: 0.3759
INFO - 2018-10-29 17:28:30 --> Config Class Initialized
INFO - 2018-10-29 17:28:30 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:28:30 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:28:30 --> Utf8 Class Initialized
INFO - 2018-10-29 17:28:30 --> URI Class Initialized
INFO - 2018-10-29 17:28:30 --> Router Class Initialized
INFO - 2018-10-29 17:28:30 --> Output Class Initialized
INFO - 2018-10-29 17:28:30 --> Security Class Initialized
DEBUG - 2018-10-29 17:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:28:30 --> CSRF cookie sent
INFO - 2018-10-29 17:28:30 --> CSRF token verified
INFO - 2018-10-29 17:28:30 --> Input Class Initialized
INFO - 2018-10-29 17:28:30 --> Language Class Initialized
INFO - 2018-10-29 17:28:30 --> Loader Class Initialized
INFO - 2018-10-29 17:28:30 --> Helper loaded: url_helper
INFO - 2018-10-29 17:28:30 --> Helper loaded: form_helper
INFO - 2018-10-29 17:28:30 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:28:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:28:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:28:30 --> User Agent Class Initialized
INFO - 2018-10-29 17:28:30 --> Controller Class Initialized
INFO - 2018-10-29 17:28:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:28:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:28:30 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:28:30 --> Pixel_Model class loaded
INFO - 2018-10-29 17:28:30 --> Database Driver Class Initialized
INFO - 2018-10-29 17:28:30 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:28:30 --> Form Validation Class Initialized
INFO - 2018-10-29 17:28:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-29 17:28:30 --> Database Driver Class Initialized
INFO - 2018-10-29 17:28:30 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:28:30 --> Config Class Initialized
INFO - 2018-10-29 17:28:30 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:28:30 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:28:30 --> Utf8 Class Initialized
INFO - 2018-10-29 17:28:30 --> URI Class Initialized
INFO - 2018-10-29 17:28:30 --> Router Class Initialized
INFO - 2018-10-29 17:28:30 --> Output Class Initialized
INFO - 2018-10-29 17:28:30 --> Security Class Initialized
DEBUG - 2018-10-29 17:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:28:30 --> CSRF cookie sent
INFO - 2018-10-29 17:28:30 --> Input Class Initialized
INFO - 2018-10-29 17:28:30 --> Language Class Initialized
INFO - 2018-10-29 17:28:30 --> Loader Class Initialized
INFO - 2018-10-29 17:28:30 --> Helper loaded: url_helper
INFO - 2018-10-29 17:28:30 --> Helper loaded: form_helper
INFO - 2018-10-29 17:28:30 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:28:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:28:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:28:30 --> User Agent Class Initialized
INFO - 2018-10-29 17:28:30 --> Controller Class Initialized
INFO - 2018-10-29 17:28:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:28:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:28:30 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:28:30 --> Pixel_Model class loaded
INFO - 2018-10-29 17:28:30 --> Database Driver Class Initialized
INFO - 2018-10-29 17:28:30 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:28:30 --> Database Driver Class Initialized
INFO - 2018-10-29 17:28:30 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:28:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 17:28:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 17:28:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 17:28:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 17:28:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-29 17:28:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-29 17:28:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/marriage.php
INFO - 2018-10-29 17:28:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 17:28:31 --> Final output sent to browser
DEBUG - 2018-10-29 17:28:31 --> Total execution time: 0.3702
INFO - 2018-10-29 17:28:33 --> Config Class Initialized
INFO - 2018-10-29 17:28:33 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:28:33 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:28:33 --> Utf8 Class Initialized
INFO - 2018-10-29 17:28:33 --> URI Class Initialized
INFO - 2018-10-29 17:28:33 --> Router Class Initialized
INFO - 2018-10-29 17:28:33 --> Output Class Initialized
INFO - 2018-10-29 17:28:33 --> Security Class Initialized
DEBUG - 2018-10-29 17:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:28:33 --> CSRF cookie sent
INFO - 2018-10-29 17:28:33 --> CSRF token verified
INFO - 2018-10-29 17:28:33 --> Input Class Initialized
INFO - 2018-10-29 17:28:33 --> Language Class Initialized
INFO - 2018-10-29 17:28:33 --> Loader Class Initialized
INFO - 2018-10-29 17:28:33 --> Helper loaded: url_helper
INFO - 2018-10-29 17:28:33 --> Helper loaded: form_helper
INFO - 2018-10-29 17:28:33 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:28:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:28:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:28:33 --> User Agent Class Initialized
INFO - 2018-10-29 17:28:33 --> Controller Class Initialized
INFO - 2018-10-29 17:28:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:28:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:28:33 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:28:33 --> Pixel_Model class loaded
INFO - 2018-10-29 17:28:33 --> Database Driver Class Initialized
INFO - 2018-10-29 17:28:33 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:28:34 --> Form Validation Class Initialized
INFO - 2018-10-29 17:28:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-29 17:28:34 --> Database Driver Class Initialized
INFO - 2018-10-29 17:28:34 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:28:34 --> Config Class Initialized
INFO - 2018-10-29 17:28:34 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:28:34 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:28:34 --> Utf8 Class Initialized
INFO - 2018-10-29 17:28:34 --> URI Class Initialized
INFO - 2018-10-29 17:28:34 --> Router Class Initialized
INFO - 2018-10-29 17:28:34 --> Output Class Initialized
INFO - 2018-10-29 17:28:34 --> Security Class Initialized
DEBUG - 2018-10-29 17:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:28:34 --> CSRF cookie sent
INFO - 2018-10-29 17:28:34 --> Input Class Initialized
INFO - 2018-10-29 17:28:34 --> Language Class Initialized
INFO - 2018-10-29 17:28:34 --> Loader Class Initialized
INFO - 2018-10-29 17:28:34 --> Helper loaded: url_helper
INFO - 2018-10-29 17:28:34 --> Helper loaded: form_helper
INFO - 2018-10-29 17:28:34 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:28:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:28:34 --> User Agent Class Initialized
INFO - 2018-10-29 17:28:34 --> Controller Class Initialized
INFO - 2018-10-29 17:28:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:28:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:28:34 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:28:34 --> Pixel_Model class loaded
INFO - 2018-10-29 17:28:34 --> Database Driver Class Initialized
INFO - 2018-10-29 17:28:34 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:28:34 --> Database Driver Class Initialized
INFO - 2018-10-29 17:28:34 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:28:34 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 17:28:34 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 17:28:34 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 17:28:34 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 17:28:34 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-29 17:28:34 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-29 17:28:34 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/kids.php
INFO - 2018-10-29 17:28:34 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 17:28:34 --> Final output sent to browser
DEBUG - 2018-10-29 17:28:34 --> Total execution time: 0.3943
INFO - 2018-10-29 17:28:35 --> Config Class Initialized
INFO - 2018-10-29 17:28:35 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:28:35 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:28:35 --> Utf8 Class Initialized
INFO - 2018-10-29 17:28:35 --> URI Class Initialized
INFO - 2018-10-29 17:28:35 --> Router Class Initialized
INFO - 2018-10-29 17:28:35 --> Output Class Initialized
INFO - 2018-10-29 17:28:35 --> Security Class Initialized
DEBUG - 2018-10-29 17:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:28:35 --> CSRF cookie sent
INFO - 2018-10-29 17:28:35 --> CSRF token verified
INFO - 2018-10-29 17:28:35 --> Input Class Initialized
INFO - 2018-10-29 17:28:35 --> Language Class Initialized
INFO - 2018-10-29 17:28:35 --> Loader Class Initialized
INFO - 2018-10-29 17:28:35 --> Helper loaded: url_helper
INFO - 2018-10-29 17:28:35 --> Helper loaded: form_helper
INFO - 2018-10-29 17:28:35 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:28:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:28:35 --> User Agent Class Initialized
INFO - 2018-10-29 17:28:35 --> Controller Class Initialized
INFO - 2018-10-29 17:28:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:28:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:28:35 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:28:35 --> Pixel_Model class loaded
INFO - 2018-10-29 17:28:35 --> Database Driver Class Initialized
INFO - 2018-10-29 17:28:35 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:28:35 --> Form Validation Class Initialized
INFO - 2018-10-29 17:28:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-29 17:28:35 --> Database Driver Class Initialized
INFO - 2018-10-29 17:28:35 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:28:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 17:28:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 17:28:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 17:28:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 17:28:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-29 17:28:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_errors.php
INFO - 2018-10-29 17:28:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-29 17:28:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/kids.php
INFO - 2018-10-29 17:28:35 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 17:28:35 --> Final output sent to browser
DEBUG - 2018-10-29 17:28:35 --> Total execution time: 0.4608
INFO - 2018-10-29 17:28:37 --> Config Class Initialized
INFO - 2018-10-29 17:28:37 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:28:37 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:28:37 --> Utf8 Class Initialized
INFO - 2018-10-29 17:28:37 --> URI Class Initialized
INFO - 2018-10-29 17:28:37 --> Router Class Initialized
INFO - 2018-10-29 17:28:37 --> Output Class Initialized
INFO - 2018-10-29 17:28:37 --> Security Class Initialized
DEBUG - 2018-10-29 17:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:28:37 --> CSRF cookie sent
INFO - 2018-10-29 17:28:37 --> CSRF token verified
INFO - 2018-10-29 17:28:37 --> Input Class Initialized
INFO - 2018-10-29 17:28:37 --> Language Class Initialized
INFO - 2018-10-29 17:28:37 --> Loader Class Initialized
INFO - 2018-10-29 17:28:37 --> Helper loaded: url_helper
INFO - 2018-10-29 17:28:37 --> Helper loaded: form_helper
INFO - 2018-10-29 17:28:37 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:28:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:28:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:28:38 --> User Agent Class Initialized
INFO - 2018-10-29 17:28:38 --> Controller Class Initialized
INFO - 2018-10-29 17:28:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:28:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:28:38 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:28:38 --> Pixel_Model class loaded
INFO - 2018-10-29 17:28:38 --> Database Driver Class Initialized
INFO - 2018-10-29 17:28:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:28:38 --> Form Validation Class Initialized
INFO - 2018-10-29 17:28:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-29 17:28:38 --> Database Driver Class Initialized
INFO - 2018-10-29 17:28:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:28:38 --> Config Class Initialized
INFO - 2018-10-29 17:28:38 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:28:38 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:28:38 --> Utf8 Class Initialized
INFO - 2018-10-29 17:28:38 --> URI Class Initialized
INFO - 2018-10-29 17:28:38 --> Router Class Initialized
INFO - 2018-10-29 17:28:38 --> Output Class Initialized
INFO - 2018-10-29 17:28:38 --> Security Class Initialized
DEBUG - 2018-10-29 17:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:28:38 --> CSRF cookie sent
INFO - 2018-10-29 17:28:38 --> Input Class Initialized
INFO - 2018-10-29 17:28:38 --> Language Class Initialized
INFO - 2018-10-29 17:28:38 --> Loader Class Initialized
INFO - 2018-10-29 17:28:38 --> Helper loaded: url_helper
INFO - 2018-10-29 17:28:38 --> Helper loaded: form_helper
INFO - 2018-10-29 17:28:38 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:28:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:28:38 --> User Agent Class Initialized
INFO - 2018-10-29 17:28:38 --> Controller Class Initialized
INFO - 2018-10-29 17:28:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:28:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:28:38 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:28:38 --> Pixel_Model class loaded
INFO - 2018-10-29 17:28:38 --> Database Driver Class Initialized
INFO - 2018-10-29 17:28:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:28:38 --> Database Driver Class Initialized
INFO - 2018-10-29 17:28:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:28:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 17:28:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 17:28:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 17:28:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 17:28:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-29 17:28:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-29 17:28:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/pension.php
INFO - 2018-10-29 17:28:38 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 17:28:38 --> Final output sent to browser
DEBUG - 2018-10-29 17:28:38 --> Total execution time: 0.3853
INFO - 2018-10-29 17:28:40 --> Config Class Initialized
INFO - 2018-10-29 17:28:40 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:28:40 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:28:40 --> Utf8 Class Initialized
INFO - 2018-10-29 17:28:40 --> URI Class Initialized
INFO - 2018-10-29 17:28:40 --> Router Class Initialized
INFO - 2018-10-29 17:28:40 --> Output Class Initialized
INFO - 2018-10-29 17:28:40 --> Security Class Initialized
DEBUG - 2018-10-29 17:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:28:40 --> CSRF cookie sent
INFO - 2018-10-29 17:28:40 --> CSRF token verified
INFO - 2018-10-29 17:28:40 --> Input Class Initialized
INFO - 2018-10-29 17:28:40 --> Language Class Initialized
INFO - 2018-10-29 17:28:40 --> Loader Class Initialized
INFO - 2018-10-29 17:28:41 --> Helper loaded: url_helper
INFO - 2018-10-29 17:28:41 --> Helper loaded: form_helper
INFO - 2018-10-29 17:28:41 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:28:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:28:41 --> User Agent Class Initialized
INFO - 2018-10-29 17:28:41 --> Controller Class Initialized
INFO - 2018-10-29 17:28:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:28:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:28:41 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:28:41 --> Pixel_Model class loaded
INFO - 2018-10-29 17:28:41 --> Database Driver Class Initialized
INFO - 2018-10-29 17:28:41 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:28:41 --> Form Validation Class Initialized
INFO - 2018-10-29 17:28:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-29 17:28:41 --> Database Driver Class Initialized
INFO - 2018-10-29 17:28:41 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:28:41 --> Config Class Initialized
INFO - 2018-10-29 17:28:41 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:28:41 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:28:41 --> Utf8 Class Initialized
INFO - 2018-10-29 17:28:41 --> URI Class Initialized
INFO - 2018-10-29 17:28:41 --> Router Class Initialized
INFO - 2018-10-29 17:28:41 --> Output Class Initialized
INFO - 2018-10-29 17:28:41 --> Security Class Initialized
DEBUG - 2018-10-29 17:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:28:41 --> CSRF cookie sent
INFO - 2018-10-29 17:28:41 --> Input Class Initialized
INFO - 2018-10-29 17:28:41 --> Language Class Initialized
INFO - 2018-10-29 17:28:41 --> Loader Class Initialized
INFO - 2018-10-29 17:28:41 --> Helper loaded: url_helper
INFO - 2018-10-29 17:28:41 --> Helper loaded: form_helper
INFO - 2018-10-29 17:28:41 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:28:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:28:41 --> User Agent Class Initialized
INFO - 2018-10-29 17:28:41 --> Controller Class Initialized
INFO - 2018-10-29 17:28:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:28:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:28:41 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:28:41 --> Pixel_Model class loaded
INFO - 2018-10-29 17:28:41 --> Database Driver Class Initialized
INFO - 2018-10-29 17:28:41 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:28:41 --> Database Driver Class Initialized
INFO - 2018-10-29 17:28:41 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:28:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 17:28:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 17:28:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 17:28:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 17:28:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-29 17:28:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-29 17:28:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/inheritance.php
INFO - 2018-10-29 17:28:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 17:28:41 --> Final output sent to browser
DEBUG - 2018-10-29 17:28:41 --> Total execution time: 0.3985
INFO - 2018-10-29 17:28:43 --> Config Class Initialized
INFO - 2018-10-29 17:28:43 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:28:43 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:28:43 --> Utf8 Class Initialized
INFO - 2018-10-29 17:28:43 --> URI Class Initialized
INFO - 2018-10-29 17:28:43 --> Router Class Initialized
INFO - 2018-10-29 17:28:43 --> Output Class Initialized
INFO - 2018-10-29 17:28:43 --> Security Class Initialized
DEBUG - 2018-10-29 17:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:28:43 --> CSRF cookie sent
INFO - 2018-10-29 17:28:43 --> CSRF token verified
INFO - 2018-10-29 17:28:43 --> Input Class Initialized
INFO - 2018-10-29 17:28:43 --> Language Class Initialized
INFO - 2018-10-29 17:28:43 --> Loader Class Initialized
INFO - 2018-10-29 17:28:43 --> Helper loaded: url_helper
INFO - 2018-10-29 17:28:43 --> Helper loaded: form_helper
INFO - 2018-10-29 17:28:43 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:28:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:28:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:28:43 --> User Agent Class Initialized
INFO - 2018-10-29 17:28:43 --> Controller Class Initialized
INFO - 2018-10-29 17:28:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:28:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:28:43 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:28:43 --> Pixel_Model class loaded
INFO - 2018-10-29 17:28:43 --> Database Driver Class Initialized
INFO - 2018-10-29 17:28:43 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:28:43 --> Form Validation Class Initialized
INFO - 2018-10-29 17:28:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-29 17:28:43 --> Database Driver Class Initialized
INFO - 2018-10-29 17:28:43 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:28:43 --> Config Class Initialized
INFO - 2018-10-29 17:28:43 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:28:43 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:28:43 --> Utf8 Class Initialized
INFO - 2018-10-29 17:28:43 --> URI Class Initialized
INFO - 2018-10-29 17:28:44 --> Router Class Initialized
INFO - 2018-10-29 17:28:44 --> Output Class Initialized
INFO - 2018-10-29 17:28:44 --> Security Class Initialized
DEBUG - 2018-10-29 17:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:28:44 --> CSRF cookie sent
INFO - 2018-10-29 17:28:44 --> Input Class Initialized
INFO - 2018-10-29 17:28:44 --> Language Class Initialized
INFO - 2018-10-29 17:28:44 --> Loader Class Initialized
INFO - 2018-10-29 17:28:44 --> Helper loaded: url_helper
INFO - 2018-10-29 17:28:44 --> Helper loaded: form_helper
INFO - 2018-10-29 17:28:44 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:28:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:28:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:28:44 --> User Agent Class Initialized
INFO - 2018-10-29 17:28:44 --> Controller Class Initialized
INFO - 2018-10-29 17:28:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:28:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:28:44 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:28:44 --> Pixel_Model class loaded
INFO - 2018-10-29 17:28:44 --> Database Driver Class Initialized
INFO - 2018-10-29 17:28:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:28:44 --> Database Driver Class Initialized
INFO - 2018-10-29 17:28:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:28:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 17:28:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 17:28:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 17:28:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 17:28:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-29 17:28:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-29 17:28:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/inheritance_maintained.php
INFO - 2018-10-29 17:28:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 17:28:44 --> Final output sent to browser
DEBUG - 2018-10-29 17:28:44 --> Total execution time: 0.3869
INFO - 2018-10-29 17:28:45 --> Config Class Initialized
INFO - 2018-10-29 17:28:45 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:28:45 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:28:45 --> Utf8 Class Initialized
INFO - 2018-10-29 17:28:45 --> URI Class Initialized
INFO - 2018-10-29 17:28:45 --> Router Class Initialized
INFO - 2018-10-29 17:28:45 --> Output Class Initialized
INFO - 2018-10-29 17:28:45 --> Security Class Initialized
DEBUG - 2018-10-29 17:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:28:45 --> CSRF cookie sent
INFO - 2018-10-29 17:28:45 --> CSRF token verified
INFO - 2018-10-29 17:28:45 --> Input Class Initialized
INFO - 2018-10-29 17:28:45 --> Language Class Initialized
INFO - 2018-10-29 17:28:45 --> Loader Class Initialized
INFO - 2018-10-29 17:28:45 --> Helper loaded: url_helper
INFO - 2018-10-29 17:28:45 --> Helper loaded: form_helper
INFO - 2018-10-29 17:28:45 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:28:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:28:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:28:45 --> User Agent Class Initialized
INFO - 2018-10-29 17:28:45 --> Controller Class Initialized
INFO - 2018-10-29 17:28:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:28:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:28:45 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:28:45 --> Pixel_Model class loaded
INFO - 2018-10-29 17:28:45 --> Database Driver Class Initialized
INFO - 2018-10-29 17:28:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:28:45 --> Form Validation Class Initialized
INFO - 2018-10-29 17:28:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-29 17:28:45 --> Database Driver Class Initialized
INFO - 2018-10-29 17:28:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:28:45 --> Config Class Initialized
INFO - 2018-10-29 17:28:45 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:28:45 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:28:45 --> Utf8 Class Initialized
INFO - 2018-10-29 17:28:45 --> URI Class Initialized
INFO - 2018-10-29 17:28:45 --> Router Class Initialized
INFO - 2018-10-29 17:28:45 --> Output Class Initialized
INFO - 2018-10-29 17:28:45 --> Security Class Initialized
DEBUG - 2018-10-29 17:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:28:45 --> CSRF cookie sent
INFO - 2018-10-29 17:28:45 --> Input Class Initialized
INFO - 2018-10-29 17:28:45 --> Language Class Initialized
INFO - 2018-10-29 17:28:45 --> Loader Class Initialized
INFO - 2018-10-29 17:28:45 --> Helper loaded: url_helper
INFO - 2018-10-29 17:28:45 --> Helper loaded: form_helper
INFO - 2018-10-29 17:28:45 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:28:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:28:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:28:45 --> User Agent Class Initialized
INFO - 2018-10-29 17:28:45 --> Controller Class Initialized
INFO - 2018-10-29 17:28:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:28:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:28:45 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:28:45 --> Pixel_Model class loaded
INFO - 2018-10-29 17:28:45 --> Database Driver Class Initialized
INFO - 2018-10-29 17:28:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:28:45 --> Database Driver Class Initialized
INFO - 2018-10-29 17:28:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:28:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 17:28:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 17:28:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 17:28:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 17:28:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-29 17:28:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-29 17:28:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/home_owner.php
INFO - 2018-10-29 17:28:46 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 17:28:46 --> Final output sent to browser
DEBUG - 2018-10-29 17:28:46 --> Total execution time: 0.4031
INFO - 2018-10-29 17:28:47 --> Config Class Initialized
INFO - 2018-10-29 17:28:47 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:28:47 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:28:47 --> Utf8 Class Initialized
INFO - 2018-10-29 17:28:47 --> URI Class Initialized
INFO - 2018-10-29 17:28:47 --> Router Class Initialized
INFO - 2018-10-29 17:28:47 --> Output Class Initialized
INFO - 2018-10-29 17:28:47 --> Security Class Initialized
DEBUG - 2018-10-29 17:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:28:47 --> CSRF cookie sent
INFO - 2018-10-29 17:28:47 --> CSRF token verified
INFO - 2018-10-29 17:28:47 --> Input Class Initialized
INFO - 2018-10-29 17:28:47 --> Language Class Initialized
INFO - 2018-10-29 17:28:47 --> Loader Class Initialized
INFO - 2018-10-29 17:28:47 --> Helper loaded: url_helper
INFO - 2018-10-29 17:28:47 --> Helper loaded: form_helper
INFO - 2018-10-29 17:28:47 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:28:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:28:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:28:47 --> User Agent Class Initialized
INFO - 2018-10-29 17:28:47 --> Controller Class Initialized
INFO - 2018-10-29 17:28:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:28:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:28:47 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:28:47 --> Pixel_Model class loaded
INFO - 2018-10-29 17:28:47 --> Database Driver Class Initialized
INFO - 2018-10-29 17:28:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:28:47 --> Form Validation Class Initialized
INFO - 2018-10-29 17:28:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-29 17:28:47 --> Database Driver Class Initialized
INFO - 2018-10-29 17:28:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:28:47 --> Config Class Initialized
INFO - 2018-10-29 17:28:47 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:28:47 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:28:47 --> Utf8 Class Initialized
INFO - 2018-10-29 17:28:47 --> URI Class Initialized
INFO - 2018-10-29 17:28:47 --> Router Class Initialized
INFO - 2018-10-29 17:28:47 --> Output Class Initialized
INFO - 2018-10-29 17:28:47 --> Security Class Initialized
DEBUG - 2018-10-29 17:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:28:47 --> CSRF cookie sent
INFO - 2018-10-29 17:28:47 --> Input Class Initialized
INFO - 2018-10-29 17:28:47 --> Language Class Initialized
INFO - 2018-10-29 17:28:47 --> Loader Class Initialized
INFO - 2018-10-29 17:28:47 --> Helper loaded: url_helper
INFO - 2018-10-29 17:28:47 --> Helper loaded: form_helper
INFO - 2018-10-29 17:28:47 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:28:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:28:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:28:47 --> User Agent Class Initialized
INFO - 2018-10-29 17:28:47 --> Controller Class Initialized
INFO - 2018-10-29 17:28:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:28:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:28:47 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:28:47 --> Pixel_Model class loaded
INFO - 2018-10-29 17:28:47 --> Database Driver Class Initialized
INFO - 2018-10-29 17:28:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:28:47 --> Database Driver Class Initialized
INFO - 2018-10-29 17:28:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:28:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 17:28:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 17:28:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 17:28:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 17:28:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-29 17:28:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-29 17:28:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/home_value.php
INFO - 2018-10-29 17:28:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 17:28:47 --> Final output sent to browser
DEBUG - 2018-10-29 17:28:47 --> Total execution time: 0.3978
INFO - 2018-10-29 17:28:50 --> Config Class Initialized
INFO - 2018-10-29 17:28:50 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:28:50 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:28:50 --> Utf8 Class Initialized
INFO - 2018-10-29 17:28:50 --> URI Class Initialized
INFO - 2018-10-29 17:28:50 --> Router Class Initialized
INFO - 2018-10-29 17:28:50 --> Output Class Initialized
INFO - 2018-10-29 17:28:50 --> Security Class Initialized
DEBUG - 2018-10-29 17:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:28:50 --> CSRF cookie sent
INFO - 2018-10-29 17:28:50 --> CSRF token verified
INFO - 2018-10-29 17:28:50 --> Input Class Initialized
INFO - 2018-10-29 17:28:50 --> Language Class Initialized
INFO - 2018-10-29 17:28:50 --> Loader Class Initialized
INFO - 2018-10-29 17:28:50 --> Helper loaded: url_helper
INFO - 2018-10-29 17:28:50 --> Helper loaded: form_helper
INFO - 2018-10-29 17:28:50 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:28:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:28:50 --> User Agent Class Initialized
INFO - 2018-10-29 17:28:50 --> Controller Class Initialized
INFO - 2018-10-29 17:28:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:28:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:28:50 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:28:50 --> Pixel_Model class loaded
INFO - 2018-10-29 17:28:50 --> Database Driver Class Initialized
INFO - 2018-10-29 17:28:50 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:28:50 --> Form Validation Class Initialized
INFO - 2018-10-29 17:28:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-29 17:28:50 --> Database Driver Class Initialized
INFO - 2018-10-29 17:28:50 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:28:50 --> Config Class Initialized
INFO - 2018-10-29 17:28:50 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:28:50 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:28:50 --> Utf8 Class Initialized
INFO - 2018-10-29 17:28:50 --> URI Class Initialized
INFO - 2018-10-29 17:28:50 --> Router Class Initialized
INFO - 2018-10-29 17:28:50 --> Output Class Initialized
INFO - 2018-10-29 17:28:50 --> Security Class Initialized
DEBUG - 2018-10-29 17:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:28:50 --> CSRF cookie sent
INFO - 2018-10-29 17:28:50 --> Input Class Initialized
INFO - 2018-10-29 17:28:50 --> Language Class Initialized
INFO - 2018-10-29 17:28:50 --> Loader Class Initialized
INFO - 2018-10-29 17:28:50 --> Helper loaded: url_helper
INFO - 2018-10-29 17:28:50 --> Helper loaded: form_helper
INFO - 2018-10-29 17:28:50 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:28:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:28:50 --> User Agent Class Initialized
INFO - 2018-10-29 17:28:50 --> Controller Class Initialized
INFO - 2018-10-29 17:28:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:28:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:28:50 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:28:50 --> Pixel_Model class loaded
INFO - 2018-10-29 17:28:50 --> Database Driver Class Initialized
INFO - 2018-10-29 17:28:50 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:28:50 --> Database Driver Class Initialized
INFO - 2018-10-29 17:28:50 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:28:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 17:28:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 17:28:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 17:28:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 17:28:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-29 17:28:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-29 17:28:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/merriage_home_title.php
INFO - 2018-10-29 17:28:50 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 17:28:50 --> Final output sent to browser
DEBUG - 2018-10-29 17:28:50 --> Total execution time: 0.3966
INFO - 2018-10-29 17:28:51 --> Config Class Initialized
INFO - 2018-10-29 17:28:51 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:28:51 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:28:52 --> Utf8 Class Initialized
INFO - 2018-10-29 17:28:52 --> URI Class Initialized
INFO - 2018-10-29 17:28:52 --> Router Class Initialized
INFO - 2018-10-29 17:28:52 --> Output Class Initialized
INFO - 2018-10-29 17:28:52 --> Security Class Initialized
DEBUG - 2018-10-29 17:28:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:28:52 --> CSRF cookie sent
INFO - 2018-10-29 17:28:52 --> CSRF token verified
INFO - 2018-10-29 17:28:52 --> Input Class Initialized
INFO - 2018-10-29 17:28:52 --> Language Class Initialized
INFO - 2018-10-29 17:28:52 --> Loader Class Initialized
INFO - 2018-10-29 17:28:52 --> Helper loaded: url_helper
INFO - 2018-10-29 17:28:52 --> Helper loaded: form_helper
INFO - 2018-10-29 17:28:52 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:28:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:28:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:28:52 --> User Agent Class Initialized
INFO - 2018-10-29 17:28:52 --> Controller Class Initialized
INFO - 2018-10-29 17:28:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:28:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:28:52 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:28:52 --> Pixel_Model class loaded
INFO - 2018-10-29 17:28:52 --> Database Driver Class Initialized
INFO - 2018-10-29 17:28:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:28:52 --> Form Validation Class Initialized
INFO - 2018-10-29 17:28:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-29 17:28:52 --> Database Driver Class Initialized
INFO - 2018-10-29 17:28:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:28:52 --> Config Class Initialized
INFO - 2018-10-29 17:28:52 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:28:52 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:28:52 --> Utf8 Class Initialized
INFO - 2018-10-29 17:28:52 --> URI Class Initialized
INFO - 2018-10-29 17:28:52 --> Router Class Initialized
INFO - 2018-10-29 17:28:52 --> Output Class Initialized
INFO - 2018-10-29 17:28:52 --> Security Class Initialized
DEBUG - 2018-10-29 17:28:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:28:52 --> CSRF cookie sent
INFO - 2018-10-29 17:28:52 --> Input Class Initialized
INFO - 2018-10-29 17:28:52 --> Language Class Initialized
INFO - 2018-10-29 17:28:52 --> Loader Class Initialized
INFO - 2018-10-29 17:28:52 --> Helper loaded: url_helper
INFO - 2018-10-29 17:28:52 --> Helper loaded: form_helper
INFO - 2018-10-29 17:28:52 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:28:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:28:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:28:52 --> User Agent Class Initialized
INFO - 2018-10-29 17:28:52 --> Controller Class Initialized
INFO - 2018-10-29 17:28:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:28:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:28:52 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:28:52 --> Pixel_Model class loaded
INFO - 2018-10-29 17:28:52 --> Database Driver Class Initialized
INFO - 2018-10-29 17:28:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:28:52 --> Database Driver Class Initialized
INFO - 2018-10-29 17:28:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:28:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 17:28:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 17:28:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 17:28:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 17:28:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-29 17:28:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-29 17:28:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/financial.php
INFO - 2018-10-29 17:28:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 17:28:52 --> Final output sent to browser
DEBUG - 2018-10-29 17:28:52 --> Total execution time: 0.4374
INFO - 2018-10-29 17:28:53 --> Config Class Initialized
INFO - 2018-10-29 17:28:53 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:28:53 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:28:53 --> Utf8 Class Initialized
INFO - 2018-10-29 17:28:53 --> URI Class Initialized
INFO - 2018-10-29 17:28:53 --> Router Class Initialized
INFO - 2018-10-29 17:28:53 --> Output Class Initialized
INFO - 2018-10-29 17:28:53 --> Security Class Initialized
DEBUG - 2018-10-29 17:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:28:53 --> CSRF cookie sent
INFO - 2018-10-29 17:28:53 --> CSRF token verified
INFO - 2018-10-29 17:28:53 --> Input Class Initialized
INFO - 2018-10-29 17:28:53 --> Language Class Initialized
INFO - 2018-10-29 17:28:53 --> Loader Class Initialized
INFO - 2018-10-29 17:28:54 --> Helper loaded: url_helper
INFO - 2018-10-29 17:28:54 --> Helper loaded: form_helper
INFO - 2018-10-29 17:28:54 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:28:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:28:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:28:54 --> User Agent Class Initialized
INFO - 2018-10-29 17:28:54 --> Controller Class Initialized
INFO - 2018-10-29 17:28:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:28:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:28:54 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:28:54 --> Pixel_Model class loaded
INFO - 2018-10-29 17:28:54 --> Database Driver Class Initialized
INFO - 2018-10-29 17:28:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:28:54 --> Form Validation Class Initialized
INFO - 2018-10-29 17:28:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-29 17:28:54 --> Database Driver Class Initialized
INFO - 2018-10-29 17:28:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:28:54 --> Config Class Initialized
INFO - 2018-10-29 17:28:54 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:28:54 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:28:54 --> Utf8 Class Initialized
INFO - 2018-10-29 17:28:54 --> URI Class Initialized
INFO - 2018-10-29 17:28:54 --> Router Class Initialized
INFO - 2018-10-29 17:28:54 --> Output Class Initialized
INFO - 2018-10-29 17:28:54 --> Security Class Initialized
DEBUG - 2018-10-29 17:28:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:28:54 --> CSRF cookie sent
INFO - 2018-10-29 17:28:54 --> Input Class Initialized
INFO - 2018-10-29 17:28:54 --> Language Class Initialized
INFO - 2018-10-29 17:28:54 --> Loader Class Initialized
INFO - 2018-10-29 17:28:54 --> Helper loaded: url_helper
INFO - 2018-10-29 17:28:54 --> Helper loaded: form_helper
INFO - 2018-10-29 17:28:54 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:28:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:28:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:28:54 --> User Agent Class Initialized
INFO - 2018-10-29 17:28:54 --> Controller Class Initialized
INFO - 2018-10-29 17:28:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:28:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:28:54 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:28:54 --> Pixel_Model class loaded
INFO - 2018-10-29 17:28:54 --> Database Driver Class Initialized
INFO - 2018-10-29 17:28:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:28:54 --> Database Driver Class Initialized
INFO - 2018-10-29 17:28:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:28:54 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 17:28:54 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 17:28:54 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 17:28:54 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 17:28:54 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/risk_report.php
INFO - 2018-10-29 17:28:54 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 17:28:54 --> Final output sent to browser
DEBUG - 2018-10-29 17:28:54 --> Total execution time: 0.3868
INFO - 2018-10-29 17:28:57 --> Config Class Initialized
INFO - 2018-10-29 17:28:57 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:28:57 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:28:57 --> Utf8 Class Initialized
INFO - 2018-10-29 17:28:57 --> URI Class Initialized
INFO - 2018-10-29 17:28:57 --> Router Class Initialized
INFO - 2018-10-29 17:28:57 --> Output Class Initialized
INFO - 2018-10-29 17:28:57 --> Security Class Initialized
DEBUG - 2018-10-29 17:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:28:57 --> CSRF cookie sent
INFO - 2018-10-29 17:28:57 --> Input Class Initialized
INFO - 2018-10-29 17:28:57 --> Language Class Initialized
INFO - 2018-10-29 17:28:57 --> Loader Class Initialized
INFO - 2018-10-29 17:28:57 --> Helper loaded: url_helper
INFO - 2018-10-29 17:28:57 --> Helper loaded: form_helper
INFO - 2018-10-29 17:28:57 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:28:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:28:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:28:57 --> User Agent Class Initialized
INFO - 2018-10-29 17:28:57 --> Controller Class Initialized
INFO - 2018-10-29 17:28:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:28:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:28:57 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:28:57 --> Pixel_Model class loaded
INFO - 2018-10-29 17:28:57 --> Database Driver Class Initialized
INFO - 2018-10-29 17:28:57 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:28:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 17:28:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 17:28:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 17:28:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 17:28:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/contact_us.php
INFO - 2018-10-29 17:28:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 17:28:57 --> Final output sent to browser
DEBUG - 2018-10-29 17:28:57 --> Total execution time: 0.3775
INFO - 2018-10-29 17:29:01 --> Config Class Initialized
INFO - 2018-10-29 17:29:01 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:29:01 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:29:01 --> Utf8 Class Initialized
INFO - 2018-10-29 17:29:01 --> URI Class Initialized
INFO - 2018-10-29 17:29:01 --> Router Class Initialized
INFO - 2018-10-29 17:29:01 --> Output Class Initialized
INFO - 2018-10-29 17:29:01 --> Security Class Initialized
DEBUG - 2018-10-29 17:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:29:01 --> CSRF cookie sent
INFO - 2018-10-29 17:29:01 --> Input Class Initialized
INFO - 2018-10-29 17:29:01 --> Language Class Initialized
INFO - 2018-10-29 17:29:01 --> Loader Class Initialized
INFO - 2018-10-29 17:29:01 --> Helper loaded: url_helper
INFO - 2018-10-29 17:29:01 --> Helper loaded: form_helper
INFO - 2018-10-29 17:29:01 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:29:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:29:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:29:01 --> User Agent Class Initialized
INFO - 2018-10-29 17:29:01 --> Controller Class Initialized
INFO - 2018-10-29 17:29:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:29:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:29:01 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:29:01 --> Pixel_Model class loaded
INFO - 2018-10-29 17:29:01 --> Database Driver Class Initialized
INFO - 2018-10-29 17:29:01 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:29:01 --> Database Driver Class Initialized
INFO - 2018-10-29 17:29:01 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:29:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 17:29:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 17:29:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 17:29:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 17:29:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/risk_report.php
INFO - 2018-10-29 17:29:01 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 17:29:01 --> Final output sent to browser
DEBUG - 2018-10-29 17:29:01 --> Total execution time: 0.4030
INFO - 2018-10-29 17:29:16 --> Config Class Initialized
INFO - 2018-10-29 17:29:16 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:29:16 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:29:16 --> Utf8 Class Initialized
INFO - 2018-10-29 17:29:16 --> URI Class Initialized
INFO - 2018-10-29 17:29:16 --> Router Class Initialized
INFO - 2018-10-29 17:29:16 --> Output Class Initialized
INFO - 2018-10-29 17:29:16 --> Security Class Initialized
DEBUG - 2018-10-29 17:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:29:16 --> CSRF cookie sent
INFO - 2018-10-29 17:29:16 --> Input Class Initialized
INFO - 2018-10-29 17:29:16 --> Language Class Initialized
INFO - 2018-10-29 17:29:16 --> Loader Class Initialized
INFO - 2018-10-29 17:29:16 --> Helper loaded: url_helper
INFO - 2018-10-29 17:29:16 --> Helper loaded: form_helper
INFO - 2018-10-29 17:29:16 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:29:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:29:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:29:16 --> User Agent Class Initialized
INFO - 2018-10-29 17:29:16 --> Controller Class Initialized
INFO - 2018-10-29 17:29:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:29:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:29:16 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:29:16 --> Pixel_Model class loaded
INFO - 2018-10-29 17:29:16 --> Database Driver Class Initialized
INFO - 2018-10-29 17:29:16 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:29:16 --> Database Driver Class Initialized
INFO - 2018-10-29 17:29:16 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:29:16 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 17:29:16 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 17:29:16 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 17:29:16 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 17:29:16 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-29 17:29:16 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-29 17:29:16 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/financial.php
INFO - 2018-10-29 17:29:16 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 17:29:16 --> Final output sent to browser
DEBUG - 2018-10-29 17:29:16 --> Total execution time: 0.4344
INFO - 2018-10-29 17:29:19 --> Config Class Initialized
INFO - 2018-10-29 17:29:19 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:29:19 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:29:19 --> Utf8 Class Initialized
INFO - 2018-10-29 17:29:19 --> URI Class Initialized
INFO - 2018-10-29 17:29:19 --> Router Class Initialized
INFO - 2018-10-29 17:29:19 --> Output Class Initialized
INFO - 2018-10-29 17:29:19 --> Security Class Initialized
DEBUG - 2018-10-29 17:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:29:20 --> CSRF cookie sent
INFO - 2018-10-29 17:29:20 --> Input Class Initialized
INFO - 2018-10-29 17:29:20 --> Language Class Initialized
INFO - 2018-10-29 17:29:20 --> Loader Class Initialized
INFO - 2018-10-29 17:29:20 --> Helper loaded: url_helper
INFO - 2018-10-29 17:29:20 --> Helper loaded: form_helper
INFO - 2018-10-29 17:29:20 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:29:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:29:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:29:20 --> User Agent Class Initialized
INFO - 2018-10-29 17:29:20 --> Controller Class Initialized
INFO - 2018-10-29 17:29:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:29:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:29:20 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:29:20 --> Pixel_Model class loaded
INFO - 2018-10-29 17:29:20 --> Database Driver Class Initialized
INFO - 2018-10-29 17:29:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:29:20 --> Database Driver Class Initialized
INFO - 2018-10-29 17:29:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:29:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 17:29:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 17:29:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 17:29:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 17:29:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/risk_report.php
INFO - 2018-10-29 17:29:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 17:29:20 --> Final output sent to browser
DEBUG - 2018-10-29 17:29:20 --> Total execution time: 0.4042
INFO - 2018-10-29 17:29:23 --> Config Class Initialized
INFO - 2018-10-29 17:29:23 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:29:23 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:29:23 --> Utf8 Class Initialized
INFO - 2018-10-29 17:29:23 --> URI Class Initialized
INFO - 2018-10-29 17:29:23 --> Router Class Initialized
INFO - 2018-10-29 17:29:23 --> Output Class Initialized
INFO - 2018-10-29 17:29:23 --> Security Class Initialized
DEBUG - 2018-10-29 17:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:29:23 --> CSRF cookie sent
INFO - 2018-10-29 17:29:23 --> Input Class Initialized
INFO - 2018-10-29 17:29:23 --> Language Class Initialized
INFO - 2018-10-29 17:29:23 --> Loader Class Initialized
INFO - 2018-10-29 17:29:23 --> Helper loaded: url_helper
INFO - 2018-10-29 17:29:23 --> Helper loaded: form_helper
INFO - 2018-10-29 17:29:23 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:29:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:29:23 --> User Agent Class Initialized
INFO - 2018-10-29 17:29:23 --> Controller Class Initialized
INFO - 2018-10-29 17:29:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:29:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:29:23 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:29:23 --> Pixel_Model class loaded
INFO - 2018-10-29 17:29:23 --> Database Driver Class Initialized
INFO - 2018-10-29 17:29:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:29:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 17:29:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 17:29:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 17:29:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 17:29:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/contact_us.php
INFO - 2018-10-29 17:29:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 17:29:23 --> Final output sent to browser
DEBUG - 2018-10-29 17:29:23 --> Total execution time: 0.3838
INFO - 2018-10-29 17:29:27 --> Config Class Initialized
INFO - 2018-10-29 17:29:27 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:29:27 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:29:27 --> Utf8 Class Initialized
INFO - 2018-10-29 17:29:27 --> URI Class Initialized
INFO - 2018-10-29 17:29:27 --> Router Class Initialized
INFO - 2018-10-29 17:29:27 --> Output Class Initialized
INFO - 2018-10-29 17:29:27 --> Security Class Initialized
DEBUG - 2018-10-29 17:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:29:27 --> CSRF cookie sent
INFO - 2018-10-29 17:29:27 --> Input Class Initialized
INFO - 2018-10-29 17:29:27 --> Language Class Initialized
INFO - 2018-10-29 17:29:27 --> Loader Class Initialized
INFO - 2018-10-29 17:29:27 --> Helper loaded: url_helper
INFO - 2018-10-29 17:29:27 --> Helper loaded: form_helper
INFO - 2018-10-29 17:29:27 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:29:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:29:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:29:27 --> User Agent Class Initialized
INFO - 2018-10-29 17:29:27 --> Controller Class Initialized
INFO - 2018-10-29 17:29:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:29:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:29:28 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:29:28 --> Pixel_Model class loaded
INFO - 2018-10-29 17:29:28 --> Database Driver Class Initialized
INFO - 2018-10-29 17:29:28 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:29:28 --> Database Driver Class Initialized
INFO - 2018-10-29 17:29:28 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:29:28 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 17:29:28 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 17:29:28 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 17:29:28 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 17:29:28 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/risk_report.php
INFO - 2018-10-29 17:29:28 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 17:29:28 --> Final output sent to browser
DEBUG - 2018-10-29 17:29:28 --> Total execution time: 0.4021
INFO - 2018-10-29 17:30:44 --> Config Class Initialized
INFO - 2018-10-29 17:30:44 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:30:44 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:30:44 --> Utf8 Class Initialized
INFO - 2018-10-29 17:30:44 --> URI Class Initialized
INFO - 2018-10-29 17:30:44 --> Router Class Initialized
INFO - 2018-10-29 17:30:44 --> Output Class Initialized
INFO - 2018-10-29 17:30:44 --> Security Class Initialized
DEBUG - 2018-10-29 17:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:30:44 --> CSRF cookie sent
INFO - 2018-10-29 17:30:44 --> Input Class Initialized
INFO - 2018-10-29 17:30:44 --> Language Class Initialized
INFO - 2018-10-29 17:30:44 --> Loader Class Initialized
INFO - 2018-10-29 17:30:44 --> Helper loaded: url_helper
INFO - 2018-10-29 17:30:44 --> Helper loaded: form_helper
INFO - 2018-10-29 17:30:44 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:30:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:30:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:30:44 --> User Agent Class Initialized
INFO - 2018-10-29 17:30:44 --> Controller Class Initialized
INFO - 2018-10-29 17:30:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:30:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:30:44 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:30:44 --> Pixel_Model class loaded
INFO - 2018-10-29 17:30:44 --> Database Driver Class Initialized
INFO - 2018-10-29 17:30:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:30:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 17:30:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 17:30:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 17:30:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 17:30:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/contact_us.php
INFO - 2018-10-29 17:30:44 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 17:30:44 --> Final output sent to browser
DEBUG - 2018-10-29 17:30:44 --> Total execution time: 0.3851
INFO - 2018-10-29 17:30:53 --> Config Class Initialized
INFO - 2018-10-29 17:30:53 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:30:53 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:30:53 --> Utf8 Class Initialized
INFO - 2018-10-29 17:30:53 --> URI Class Initialized
INFO - 2018-10-29 17:30:53 --> Router Class Initialized
INFO - 2018-10-29 17:30:53 --> Output Class Initialized
INFO - 2018-10-29 17:30:53 --> Security Class Initialized
DEBUG - 2018-10-29 17:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:30:53 --> CSRF cookie sent
INFO - 2018-10-29 17:30:53 --> Input Class Initialized
INFO - 2018-10-29 17:30:53 --> Language Class Initialized
INFO - 2018-10-29 17:30:53 --> Loader Class Initialized
INFO - 2018-10-29 17:30:53 --> Helper loaded: url_helper
INFO - 2018-10-29 17:30:53 --> Helper loaded: form_helper
INFO - 2018-10-29 17:30:53 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:30:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:30:53 --> User Agent Class Initialized
INFO - 2018-10-29 17:30:53 --> Controller Class Initialized
INFO - 2018-10-29 17:30:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:30:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:30:53 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:30:53 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 17:30:53 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 17:30:53 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 17:30:53 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 17:30:53 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\register/terms.php
INFO - 2018-10-29 17:30:53 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 17:30:53 --> Final output sent to browser
DEBUG - 2018-10-29 17:30:53 --> Total execution time: 0.4048
INFO - 2018-10-29 17:32:45 --> Config Class Initialized
INFO - 2018-10-29 17:32:45 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:32:45 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:32:45 --> Utf8 Class Initialized
INFO - 2018-10-29 17:32:45 --> URI Class Initialized
INFO - 2018-10-29 17:32:45 --> Router Class Initialized
INFO - 2018-10-29 17:32:45 --> Output Class Initialized
INFO - 2018-10-29 17:32:45 --> Security Class Initialized
DEBUG - 2018-10-29 17:32:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:32:45 --> CSRF cookie sent
INFO - 2018-10-29 17:32:45 --> Input Class Initialized
INFO - 2018-10-29 17:32:45 --> Language Class Initialized
INFO - 2018-10-29 17:32:45 --> Loader Class Initialized
INFO - 2018-10-29 17:32:45 --> Helper loaded: url_helper
INFO - 2018-10-29 17:32:45 --> Helper loaded: form_helper
INFO - 2018-10-29 17:32:45 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:32:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:32:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:32:45 --> User Agent Class Initialized
INFO - 2018-10-29 17:32:45 --> Controller Class Initialized
INFO - 2018-10-29 17:32:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:32:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:32:45 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:32:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 17:32:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 17:32:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 17:32:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 17:32:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\register/terms.php
INFO - 2018-10-29 17:32:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 17:32:45 --> Final output sent to browser
DEBUG - 2018-10-29 17:32:45 --> Total execution time: 0.3713
INFO - 2018-10-29 17:37:24 --> Config Class Initialized
INFO - 2018-10-29 17:37:24 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:37:24 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:37:24 --> Utf8 Class Initialized
INFO - 2018-10-29 17:37:24 --> URI Class Initialized
INFO - 2018-10-29 17:37:24 --> Router Class Initialized
INFO - 2018-10-29 17:37:24 --> Output Class Initialized
INFO - 2018-10-29 17:37:24 --> Security Class Initialized
DEBUG - 2018-10-29 17:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:37:24 --> CSRF cookie sent
INFO - 2018-10-29 17:37:24 --> Input Class Initialized
INFO - 2018-10-29 17:37:24 --> Language Class Initialized
INFO - 2018-10-29 17:37:24 --> Loader Class Initialized
INFO - 2018-10-29 17:37:24 --> Helper loaded: url_helper
INFO - 2018-10-29 17:37:24 --> Helper loaded: form_helper
INFO - 2018-10-29 17:37:24 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:37:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:37:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:37:24 --> User Agent Class Initialized
INFO - 2018-10-29 17:37:24 --> Controller Class Initialized
INFO - 2018-10-29 17:37:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:37:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:37:24 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:37:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 17:37:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 17:37:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 17:37:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 17:37:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\register/terms.php
INFO - 2018-10-29 17:37:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 17:37:24 --> Final output sent to browser
DEBUG - 2018-10-29 17:37:24 --> Total execution time: 0.3236
INFO - 2018-10-29 17:37:47 --> Config Class Initialized
INFO - 2018-10-29 17:37:47 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:37:47 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:37:47 --> Utf8 Class Initialized
INFO - 2018-10-29 17:37:47 --> URI Class Initialized
INFO - 2018-10-29 17:37:47 --> Router Class Initialized
INFO - 2018-10-29 17:37:47 --> Output Class Initialized
INFO - 2018-10-29 17:37:47 --> Security Class Initialized
DEBUG - 2018-10-29 17:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:37:47 --> CSRF cookie sent
INFO - 2018-10-29 17:37:47 --> Input Class Initialized
INFO - 2018-10-29 17:37:47 --> Language Class Initialized
INFO - 2018-10-29 17:37:47 --> Loader Class Initialized
INFO - 2018-10-29 17:37:47 --> Helper loaded: url_helper
INFO - 2018-10-29 17:37:47 --> Helper loaded: form_helper
INFO - 2018-10-29 17:37:47 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:37:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:37:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:37:47 --> User Agent Class Initialized
INFO - 2018-10-29 17:37:47 --> Controller Class Initialized
INFO - 2018-10-29 17:37:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:37:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:37:47 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:37:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 17:37:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 17:37:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 17:37:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 17:37:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\register/terms.php
INFO - 2018-10-29 17:37:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 17:37:47 --> Final output sent to browser
DEBUG - 2018-10-29 17:37:47 --> Total execution time: 0.3406
INFO - 2018-10-29 17:39:08 --> Config Class Initialized
INFO - 2018-10-29 17:39:08 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:39:08 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:39:08 --> Utf8 Class Initialized
INFO - 2018-10-29 17:39:08 --> URI Class Initialized
INFO - 2018-10-29 17:39:08 --> Router Class Initialized
INFO - 2018-10-29 17:39:08 --> Output Class Initialized
INFO - 2018-10-29 17:39:08 --> Security Class Initialized
DEBUG - 2018-10-29 17:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:39:08 --> CSRF cookie sent
INFO - 2018-10-29 17:39:08 --> Input Class Initialized
INFO - 2018-10-29 17:39:08 --> Language Class Initialized
INFO - 2018-10-29 17:39:08 --> Loader Class Initialized
INFO - 2018-10-29 17:39:08 --> Helper loaded: url_helper
INFO - 2018-10-29 17:39:08 --> Helper loaded: form_helper
INFO - 2018-10-29 17:39:08 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:39:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:39:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:39:08 --> User Agent Class Initialized
INFO - 2018-10-29 17:39:08 --> Controller Class Initialized
INFO - 2018-10-29 17:39:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:39:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:39:08 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:39:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 17:39:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 17:39:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 17:39:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 17:39:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\register/terms.php
INFO - 2018-10-29 17:39:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 17:39:08 --> Final output sent to browser
DEBUG - 2018-10-29 17:39:08 --> Total execution time: 0.3189
INFO - 2018-10-29 17:43:08 --> Config Class Initialized
INFO - 2018-10-29 17:43:08 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:43:08 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:43:08 --> Utf8 Class Initialized
INFO - 2018-10-29 17:43:08 --> URI Class Initialized
INFO - 2018-10-29 17:43:08 --> Router Class Initialized
INFO - 2018-10-29 17:43:08 --> Output Class Initialized
INFO - 2018-10-29 17:43:08 --> Security Class Initialized
DEBUG - 2018-10-29 17:43:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:43:08 --> CSRF cookie sent
INFO - 2018-10-29 17:43:08 --> Input Class Initialized
INFO - 2018-10-29 17:43:08 --> Language Class Initialized
INFO - 2018-10-29 17:43:08 --> Loader Class Initialized
INFO - 2018-10-29 17:43:08 --> Helper loaded: url_helper
INFO - 2018-10-29 17:43:08 --> Helper loaded: form_helper
INFO - 2018-10-29 17:43:08 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:43:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:43:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:43:08 --> User Agent Class Initialized
INFO - 2018-10-29 17:43:08 --> Controller Class Initialized
INFO - 2018-10-29 17:43:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:43:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:43:08 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:43:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 17:43:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 17:43:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 17:43:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 17:43:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\register/terms.php
INFO - 2018-10-29 17:43:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 17:43:08 --> Final output sent to browser
DEBUG - 2018-10-29 17:43:08 --> Total execution time: 0.3350
INFO - 2018-10-29 17:50:26 --> Config Class Initialized
INFO - 2018-10-29 17:50:26 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:50:26 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:50:26 --> Utf8 Class Initialized
INFO - 2018-10-29 17:50:26 --> URI Class Initialized
INFO - 2018-10-29 17:50:26 --> Router Class Initialized
INFO - 2018-10-29 17:50:26 --> Output Class Initialized
INFO - 2018-10-29 17:50:26 --> Security Class Initialized
DEBUG - 2018-10-29 17:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:50:26 --> CSRF cookie sent
INFO - 2018-10-29 17:50:26 --> Input Class Initialized
INFO - 2018-10-29 17:50:26 --> Language Class Initialized
INFO - 2018-10-29 17:50:26 --> Loader Class Initialized
INFO - 2018-10-29 17:50:26 --> Helper loaded: url_helper
INFO - 2018-10-29 17:50:26 --> Helper loaded: form_helper
INFO - 2018-10-29 17:50:26 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:50:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:50:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:50:26 --> User Agent Class Initialized
INFO - 2018-10-29 17:50:26 --> Controller Class Initialized
INFO - 2018-10-29 17:50:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:50:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:50:26 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:50:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 17:50:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 17:50:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 17:50:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 17:50:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\register/terms.php
INFO - 2018-10-29 17:50:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 17:50:26 --> Final output sent to browser
DEBUG - 2018-10-29 17:50:26 --> Total execution time: 0.3320
INFO - 2018-10-29 17:50:29 --> Config Class Initialized
INFO - 2018-10-29 17:50:29 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:50:29 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:50:29 --> Utf8 Class Initialized
INFO - 2018-10-29 17:50:29 --> URI Class Initialized
DEBUG - 2018-10-29 17:50:29 --> No URI present. Default controller set.
INFO - 2018-10-29 17:50:29 --> Router Class Initialized
INFO - 2018-10-29 17:50:29 --> Output Class Initialized
INFO - 2018-10-29 17:50:29 --> Security Class Initialized
DEBUG - 2018-10-29 17:50:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:50:29 --> CSRF cookie sent
INFO - 2018-10-29 17:50:29 --> Input Class Initialized
INFO - 2018-10-29 17:50:29 --> Language Class Initialized
INFO - 2018-10-29 17:50:29 --> Loader Class Initialized
INFO - 2018-10-29 17:50:29 --> Helper loaded: url_helper
INFO - 2018-10-29 17:50:29 --> Helper loaded: form_helper
INFO - 2018-10-29 17:50:29 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:50:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:50:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:50:29 --> User Agent Class Initialized
INFO - 2018-10-29 17:50:29 --> Controller Class Initialized
INFO - 2018-10-29 17:50:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:50:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:50:29 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:50:29 --> Pixel_Model class loaded
INFO - 2018-10-29 17:50:29 --> Database Driver Class Initialized
INFO - 2018-10-29 17:50:29 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:50:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 17:50:29 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 17:50:48 --> Config Class Initialized
INFO - 2018-10-29 17:50:48 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:50:48 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:50:48 --> Utf8 Class Initialized
INFO - 2018-10-29 17:50:48 --> URI Class Initialized
DEBUG - 2018-10-29 17:50:48 --> No URI present. Default controller set.
INFO - 2018-10-29 17:50:48 --> Router Class Initialized
INFO - 2018-10-29 17:50:48 --> Output Class Initialized
INFO - 2018-10-29 17:50:48 --> Security Class Initialized
DEBUG - 2018-10-29 17:50:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:50:48 --> CSRF cookie sent
INFO - 2018-10-29 17:50:48 --> Input Class Initialized
INFO - 2018-10-29 17:50:48 --> Language Class Initialized
INFO - 2018-10-29 17:50:49 --> Loader Class Initialized
INFO - 2018-10-29 17:50:49 --> Helper loaded: url_helper
INFO - 2018-10-29 17:50:49 --> Helper loaded: form_helper
INFO - 2018-10-29 17:50:49 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:50:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:50:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:50:49 --> User Agent Class Initialized
INFO - 2018-10-29 17:50:49 --> Controller Class Initialized
INFO - 2018-10-29 17:50:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:50:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:50:49 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:50:49 --> Pixel_Model class loaded
INFO - 2018-10-29 17:50:49 --> Database Driver Class Initialized
INFO - 2018-10-29 17:50:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:50:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 17:50:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 17:50:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-29 17:50:49 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 17:50:49 --> Final output sent to browser
DEBUG - 2018-10-29 17:50:49 --> Total execution time: 0.3480
INFO - 2018-10-29 17:50:51 --> Config Class Initialized
INFO - 2018-10-29 17:50:51 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:50:51 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:50:51 --> Utf8 Class Initialized
INFO - 2018-10-29 17:50:51 --> URI Class Initialized
INFO - 2018-10-29 17:50:51 --> Router Class Initialized
INFO - 2018-10-29 17:50:51 --> Output Class Initialized
INFO - 2018-10-29 17:50:51 --> Security Class Initialized
DEBUG - 2018-10-29 17:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:50:51 --> CSRF cookie sent
INFO - 2018-10-29 17:50:51 --> Input Class Initialized
INFO - 2018-10-29 17:50:52 --> Language Class Initialized
INFO - 2018-10-29 17:50:52 --> Loader Class Initialized
INFO - 2018-10-29 17:50:52 --> Helper loaded: url_helper
INFO - 2018-10-29 17:50:52 --> Helper loaded: form_helper
INFO - 2018-10-29 17:50:52 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:50:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:50:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:50:52 --> User Agent Class Initialized
INFO - 2018-10-29 17:50:52 --> Controller Class Initialized
INFO - 2018-10-29 17:50:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:50:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:50:52 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:50:52 --> Pixel_Model class loaded
INFO - 2018-10-29 17:50:52 --> Database Driver Class Initialized
INFO - 2018-10-29 17:50:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:50:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 17:50:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 17:50:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 17:50:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 17:50:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-29 17:50:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-29 17:50:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-29 17:50:52 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 17:50:52 --> Final output sent to browser
DEBUG - 2018-10-29 17:50:52 --> Total execution time: 0.4461
INFO - 2018-10-29 17:51:34 --> Config Class Initialized
INFO - 2018-10-29 17:51:34 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:51:34 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:51:34 --> Utf8 Class Initialized
INFO - 2018-10-29 17:51:34 --> URI Class Initialized
INFO - 2018-10-29 17:51:34 --> Router Class Initialized
INFO - 2018-10-29 17:51:34 --> Output Class Initialized
INFO - 2018-10-29 17:51:34 --> Security Class Initialized
DEBUG - 2018-10-29 17:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:51:34 --> CSRF cookie sent
INFO - 2018-10-29 17:51:34 --> CSRF token verified
INFO - 2018-10-29 17:51:34 --> Input Class Initialized
INFO - 2018-10-29 17:51:34 --> Language Class Initialized
INFO - 2018-10-29 17:51:34 --> Loader Class Initialized
INFO - 2018-10-29 17:51:34 --> Helper loaded: url_helper
INFO - 2018-10-29 17:51:34 --> Helper loaded: form_helper
INFO - 2018-10-29 17:51:34 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:51:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:51:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:51:34 --> User Agent Class Initialized
INFO - 2018-10-29 17:51:34 --> Controller Class Initialized
INFO - 2018-10-29 17:51:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:51:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:51:34 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:51:34 --> Pixel_Model class loaded
INFO - 2018-10-29 17:51:34 --> Database Driver Class Initialized
INFO - 2018-10-29 17:51:34 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:51:34 --> Database Driver Class Initialized
INFO - 2018-10-29 17:51:34 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:51:34 --> Config Class Initialized
INFO - 2018-10-29 17:51:34 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:51:34 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:51:34 --> Utf8 Class Initialized
INFO - 2018-10-29 17:51:34 --> URI Class Initialized
INFO - 2018-10-29 17:51:34 --> Router Class Initialized
INFO - 2018-10-29 17:51:34 --> Output Class Initialized
INFO - 2018-10-29 17:51:34 --> Security Class Initialized
DEBUG - 2018-10-29 17:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:51:34 --> CSRF cookie sent
INFO - 2018-10-29 17:51:34 --> Input Class Initialized
INFO - 2018-10-29 17:51:34 --> Language Class Initialized
INFO - 2018-10-29 17:51:34 --> Loader Class Initialized
INFO - 2018-10-29 17:51:34 --> Helper loaded: url_helper
INFO - 2018-10-29 17:51:34 --> Helper loaded: form_helper
INFO - 2018-10-29 17:51:34 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:51:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:51:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:51:34 --> User Agent Class Initialized
INFO - 2018-10-29 17:51:34 --> Controller Class Initialized
INFO - 2018-10-29 17:51:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:51:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:51:34 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:51:34 --> Pixel_Model class loaded
INFO - 2018-10-29 17:51:34 --> Database Driver Class Initialized
INFO - 2018-10-29 17:51:34 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:51:34 --> Database Driver Class Initialized
INFO - 2018-10-29 17:51:34 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:51:34 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 17:51:34 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 17:51:34 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 17:51:34 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 17:51:34 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-29 17:51:34 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-29 17:51:34 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-29 17:51:34 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 17:51:34 --> Final output sent to browser
DEBUG - 2018-10-29 17:51:34 --> Total execution time: 0.4337
INFO - 2018-10-29 17:52:14 --> Config Class Initialized
INFO - 2018-10-29 17:52:14 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:52:14 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:52:14 --> Utf8 Class Initialized
INFO - 2018-10-29 17:52:14 --> URI Class Initialized
INFO - 2018-10-29 17:52:14 --> Router Class Initialized
INFO - 2018-10-29 17:52:14 --> Output Class Initialized
INFO - 2018-10-29 17:52:14 --> Security Class Initialized
DEBUG - 2018-10-29 17:52:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:52:14 --> CSRF cookie sent
INFO - 2018-10-29 17:52:14 --> Input Class Initialized
INFO - 2018-10-29 17:52:14 --> Language Class Initialized
INFO - 2018-10-29 17:52:14 --> Loader Class Initialized
INFO - 2018-10-29 17:52:14 --> Helper loaded: url_helper
INFO - 2018-10-29 17:52:14 --> Helper loaded: form_helper
INFO - 2018-10-29 17:52:14 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:52:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:52:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:52:14 --> User Agent Class Initialized
INFO - 2018-10-29 17:52:14 --> Controller Class Initialized
INFO - 2018-10-29 17:52:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:52:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:52:14 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:52:14 --> Pixel_Model class loaded
INFO - 2018-10-29 17:52:14 --> Database Driver Class Initialized
INFO - 2018-10-29 17:52:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:52:14 --> Database Driver Class Initialized
INFO - 2018-10-29 17:52:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:52:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 17:52:14 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 17:56:56 --> Config Class Initialized
INFO - 2018-10-29 17:56:56 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:56:56 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:56:56 --> Utf8 Class Initialized
INFO - 2018-10-29 17:56:56 --> URI Class Initialized
INFO - 2018-10-29 17:56:56 --> Router Class Initialized
INFO - 2018-10-29 17:56:56 --> Output Class Initialized
INFO - 2018-10-29 17:56:56 --> Security Class Initialized
DEBUG - 2018-10-29 17:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:56:56 --> CSRF cookie sent
INFO - 2018-10-29 17:56:56 --> Input Class Initialized
INFO - 2018-10-29 17:56:56 --> Language Class Initialized
INFO - 2018-10-29 17:56:56 --> Loader Class Initialized
INFO - 2018-10-29 17:56:56 --> Helper loaded: url_helper
INFO - 2018-10-29 17:56:56 --> Helper loaded: form_helper
INFO - 2018-10-29 17:56:56 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:56:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:56:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:56:56 --> User Agent Class Initialized
INFO - 2018-10-29 17:56:56 --> Controller Class Initialized
INFO - 2018-10-29 17:56:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:56:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:56:56 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:56:56 --> Pixel_Model class loaded
INFO - 2018-10-29 17:56:56 --> Database Driver Class Initialized
INFO - 2018-10-29 17:56:56 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:56:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 17:56:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 17:56:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 17:56:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 17:56:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-29 17:56:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-29 17:56:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-29 17:56:56 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 17:56:56 --> Final output sent to browser
DEBUG - 2018-10-29 17:56:56 --> Total execution time: 0.4064
INFO - 2018-10-29 17:56:58 --> Config Class Initialized
INFO - 2018-10-29 17:56:58 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:56:58 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:56:58 --> Utf8 Class Initialized
INFO - 2018-10-29 17:56:58 --> URI Class Initialized
DEBUG - 2018-10-29 17:56:58 --> No URI present. Default controller set.
INFO - 2018-10-29 17:56:58 --> Router Class Initialized
INFO - 2018-10-29 17:56:58 --> Output Class Initialized
INFO - 2018-10-29 17:56:58 --> Security Class Initialized
DEBUG - 2018-10-29 17:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:56:58 --> CSRF cookie sent
INFO - 2018-10-29 17:56:58 --> Input Class Initialized
INFO - 2018-10-29 17:56:58 --> Language Class Initialized
INFO - 2018-10-29 17:56:58 --> Loader Class Initialized
INFO - 2018-10-29 17:56:58 --> Helper loaded: url_helper
INFO - 2018-10-29 17:56:58 --> Helper loaded: form_helper
INFO - 2018-10-29 17:56:58 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:56:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:56:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:56:58 --> User Agent Class Initialized
INFO - 2018-10-29 17:56:58 --> Controller Class Initialized
INFO - 2018-10-29 17:56:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:56:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:56:58 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:56:58 --> Pixel_Model class loaded
INFO - 2018-10-29 17:56:58 --> Database Driver Class Initialized
INFO - 2018-10-29 17:56:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:56:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 17:56:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 17:56:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-29 17:56:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 17:56:58 --> Final output sent to browser
DEBUG - 2018-10-29 17:56:58 --> Total execution time: 0.3658
INFO - 2018-10-29 17:56:59 --> Config Class Initialized
INFO - 2018-10-29 17:56:59 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:56:59 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:56:59 --> Utf8 Class Initialized
INFO - 2018-10-29 17:56:59 --> URI Class Initialized
INFO - 2018-10-29 17:56:59 --> Router Class Initialized
INFO - 2018-10-29 17:57:00 --> Output Class Initialized
INFO - 2018-10-29 17:57:00 --> Security Class Initialized
DEBUG - 2018-10-29 17:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:57:00 --> CSRF cookie sent
INFO - 2018-10-29 17:57:00 --> Input Class Initialized
INFO - 2018-10-29 17:57:00 --> Language Class Initialized
INFO - 2018-10-29 17:57:00 --> Loader Class Initialized
INFO - 2018-10-29 17:57:00 --> Helper loaded: url_helper
INFO - 2018-10-29 17:57:00 --> Helper loaded: form_helper
INFO - 2018-10-29 17:57:00 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:57:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:57:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:57:00 --> User Agent Class Initialized
INFO - 2018-10-29 17:57:00 --> Controller Class Initialized
INFO - 2018-10-29 17:57:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:57:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:57:00 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:57:00 --> Pixel_Model class loaded
INFO - 2018-10-29 17:57:00 --> Database Driver Class Initialized
INFO - 2018-10-29 17:57:00 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:57:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 17:57:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 17:57:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 17:57:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 17:57:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-29 17:57:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-29 17:57:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-29 17:57:00 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 17:57:00 --> Final output sent to browser
DEBUG - 2018-10-29 17:57:00 --> Total execution time: 0.4840
INFO - 2018-10-29 17:57:02 --> Config Class Initialized
INFO - 2018-10-29 17:57:02 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:57:02 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:57:02 --> Utf8 Class Initialized
INFO - 2018-10-29 17:57:02 --> URI Class Initialized
DEBUG - 2018-10-29 17:57:02 --> No URI present. Default controller set.
INFO - 2018-10-29 17:57:02 --> Router Class Initialized
INFO - 2018-10-29 17:57:02 --> Output Class Initialized
INFO - 2018-10-29 17:57:02 --> Security Class Initialized
DEBUG - 2018-10-29 17:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:57:02 --> CSRF cookie sent
INFO - 2018-10-29 17:57:02 --> Input Class Initialized
INFO - 2018-10-29 17:57:02 --> Language Class Initialized
INFO - 2018-10-29 17:57:02 --> Loader Class Initialized
INFO - 2018-10-29 17:57:02 --> Helper loaded: url_helper
INFO - 2018-10-29 17:57:02 --> Helper loaded: form_helper
INFO - 2018-10-29 17:57:02 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:57:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:57:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:57:02 --> User Agent Class Initialized
INFO - 2018-10-29 17:57:02 --> Controller Class Initialized
INFO - 2018-10-29 17:57:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:57:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:57:02 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:57:02 --> Pixel_Model class loaded
INFO - 2018-10-29 17:57:02 --> Database Driver Class Initialized
INFO - 2018-10-29 17:57:02 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:57:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 17:57:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 17:57:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-29 17:57:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 17:57:02 --> Final output sent to browser
DEBUG - 2018-10-29 17:57:02 --> Total execution time: 0.3938
INFO - 2018-10-29 17:57:06 --> Config Class Initialized
INFO - 2018-10-29 17:57:06 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:57:06 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:57:06 --> Utf8 Class Initialized
INFO - 2018-10-29 17:57:06 --> URI Class Initialized
INFO - 2018-10-29 17:57:06 --> Router Class Initialized
INFO - 2018-10-29 17:57:06 --> Output Class Initialized
INFO - 2018-10-29 17:57:06 --> Security Class Initialized
DEBUG - 2018-10-29 17:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:57:06 --> CSRF cookie sent
INFO - 2018-10-29 17:57:06 --> CSRF token verified
INFO - 2018-10-29 17:57:06 --> Input Class Initialized
INFO - 2018-10-29 17:57:06 --> Language Class Initialized
INFO - 2018-10-29 17:57:06 --> Loader Class Initialized
INFO - 2018-10-29 17:57:06 --> Helper loaded: url_helper
INFO - 2018-10-29 17:57:06 --> Helper loaded: form_helper
INFO - 2018-10-29 17:57:06 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:57:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:57:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:57:06 --> User Agent Class Initialized
INFO - 2018-10-29 17:57:06 --> Controller Class Initialized
INFO - 2018-10-29 17:57:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:57:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:57:06 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:57:06 --> Pixel_Model class loaded
INFO - 2018-10-29 17:57:06 --> Database Driver Class Initialized
INFO - 2018-10-29 17:57:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:57:06 --> Database Driver Class Initialized
INFO - 2018-10-29 17:57:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:57:06 --> Config Class Initialized
INFO - 2018-10-29 17:57:06 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:57:06 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:57:06 --> Utf8 Class Initialized
INFO - 2018-10-29 17:57:06 --> URI Class Initialized
INFO - 2018-10-29 17:57:06 --> Router Class Initialized
INFO - 2018-10-29 17:57:06 --> Output Class Initialized
INFO - 2018-10-29 17:57:06 --> Security Class Initialized
DEBUG - 2018-10-29 17:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:57:06 --> CSRF cookie sent
INFO - 2018-10-29 17:57:06 --> Input Class Initialized
INFO - 2018-10-29 17:57:06 --> Language Class Initialized
INFO - 2018-10-29 17:57:06 --> Loader Class Initialized
INFO - 2018-10-29 17:57:06 --> Helper loaded: url_helper
INFO - 2018-10-29 17:57:06 --> Helper loaded: form_helper
INFO - 2018-10-29 17:57:06 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:57:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:57:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:57:06 --> User Agent Class Initialized
INFO - 2018-10-29 17:57:06 --> Controller Class Initialized
INFO - 2018-10-29 17:57:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:57:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:57:06 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:57:06 --> Pixel_Model class loaded
INFO - 2018-10-29 17:57:06 --> Database Driver Class Initialized
INFO - 2018-10-29 17:57:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:57:06 --> Database Driver Class Initialized
INFO - 2018-10-29 17:57:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:57:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 17:57:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 17:57:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 17:57:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 17:57:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-29 17:57:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-29 17:57:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-29 17:57:07 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 17:57:07 --> Final output sent to browser
DEBUG - 2018-10-29 17:57:07 --> Total execution time: 0.4602
INFO - 2018-10-29 17:57:12 --> Config Class Initialized
INFO - 2018-10-29 17:57:12 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:57:12 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:57:12 --> Utf8 Class Initialized
INFO - 2018-10-29 17:57:12 --> URI Class Initialized
DEBUG - 2018-10-29 17:57:12 --> No URI present. Default controller set.
INFO - 2018-10-29 17:57:12 --> Router Class Initialized
INFO - 2018-10-29 17:57:12 --> Output Class Initialized
INFO - 2018-10-29 17:57:12 --> Security Class Initialized
DEBUG - 2018-10-29 17:57:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:57:12 --> CSRF cookie sent
INFO - 2018-10-29 17:57:12 --> Input Class Initialized
INFO - 2018-10-29 17:57:12 --> Language Class Initialized
INFO - 2018-10-29 17:57:12 --> Loader Class Initialized
INFO - 2018-10-29 17:57:12 --> Helper loaded: url_helper
INFO - 2018-10-29 17:57:12 --> Helper loaded: form_helper
INFO - 2018-10-29 17:57:12 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:57:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:57:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:57:12 --> User Agent Class Initialized
INFO - 2018-10-29 17:57:12 --> Controller Class Initialized
INFO - 2018-10-29 17:57:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:57:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:57:12 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:57:12 --> Pixel_Model class loaded
INFO - 2018-10-29 17:57:12 --> Database Driver Class Initialized
INFO - 2018-10-29 17:57:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:57:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 17:57:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 17:57:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-29 17:57:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 17:57:13 --> Final output sent to browser
DEBUG - 2018-10-29 17:57:13 --> Total execution time: 0.3842
INFO - 2018-10-29 17:57:36 --> Config Class Initialized
INFO - 2018-10-29 17:57:36 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:57:36 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:57:36 --> Utf8 Class Initialized
INFO - 2018-10-29 17:57:36 --> URI Class Initialized
INFO - 2018-10-29 17:57:36 --> Router Class Initialized
INFO - 2018-10-29 17:57:36 --> Output Class Initialized
INFO - 2018-10-29 17:57:36 --> Security Class Initialized
DEBUG - 2018-10-29 17:57:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:57:36 --> CSRF cookie sent
INFO - 2018-10-29 17:57:36 --> Input Class Initialized
INFO - 2018-10-29 17:57:36 --> Language Class Initialized
INFO - 2018-10-29 17:57:36 --> Loader Class Initialized
INFO - 2018-10-29 17:57:36 --> Helper loaded: url_helper
INFO - 2018-10-29 17:57:36 --> Helper loaded: form_helper
INFO - 2018-10-29 17:57:36 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:57:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:57:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:57:36 --> User Agent Class Initialized
INFO - 2018-10-29 17:57:36 --> Controller Class Initialized
INFO - 2018-10-29 17:57:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:57:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:57:36 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:57:36 --> Pixel_Model class loaded
INFO - 2018-10-29 17:57:36 --> Database Driver Class Initialized
INFO - 2018-10-29 17:57:36 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:57:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 17:57:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 17:57:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 17:57:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 17:57:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-29 17:57:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-29 17:57:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-29 17:57:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 17:57:37 --> Final output sent to browser
DEBUG - 2018-10-29 17:57:37 --> Total execution time: 0.4661
INFO - 2018-10-29 17:59:08 --> Config Class Initialized
INFO - 2018-10-29 17:59:08 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:59:08 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:59:08 --> Utf8 Class Initialized
INFO - 2018-10-29 17:59:08 --> URI Class Initialized
DEBUG - 2018-10-29 17:59:08 --> No URI present. Default controller set.
INFO - 2018-10-29 17:59:08 --> Router Class Initialized
INFO - 2018-10-29 17:59:08 --> Output Class Initialized
INFO - 2018-10-29 17:59:08 --> Security Class Initialized
DEBUG - 2018-10-29 17:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:59:08 --> CSRF cookie sent
INFO - 2018-10-29 17:59:08 --> Input Class Initialized
INFO - 2018-10-29 17:59:08 --> Language Class Initialized
INFO - 2018-10-29 17:59:08 --> Loader Class Initialized
INFO - 2018-10-29 17:59:08 --> Helper loaded: url_helper
INFO - 2018-10-29 17:59:08 --> Helper loaded: form_helper
INFO - 2018-10-29 17:59:08 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:59:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:59:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:59:08 --> User Agent Class Initialized
INFO - 2018-10-29 17:59:08 --> Controller Class Initialized
INFO - 2018-10-29 17:59:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:59:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:59:08 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:59:08 --> Pixel_Model class loaded
INFO - 2018-10-29 17:59:08 --> Database Driver Class Initialized
INFO - 2018-10-29 17:59:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:59:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 17:59:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 17:59:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-29 17:59:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 17:59:08 --> Final output sent to browser
DEBUG - 2018-10-29 17:59:08 --> Total execution time: 0.3795
INFO - 2018-10-29 17:59:17 --> Config Class Initialized
INFO - 2018-10-29 17:59:17 --> Hooks Class Initialized
DEBUG - 2018-10-29 17:59:17 --> UTF-8 Support Enabled
INFO - 2018-10-29 17:59:17 --> Utf8 Class Initialized
INFO - 2018-10-29 17:59:17 --> URI Class Initialized
INFO - 2018-10-29 17:59:17 --> Router Class Initialized
INFO - 2018-10-29 17:59:17 --> Output Class Initialized
INFO - 2018-10-29 17:59:17 --> Security Class Initialized
DEBUG - 2018-10-29 17:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 17:59:17 --> CSRF cookie sent
INFO - 2018-10-29 17:59:17 --> Input Class Initialized
INFO - 2018-10-29 17:59:17 --> Language Class Initialized
INFO - 2018-10-29 17:59:17 --> Loader Class Initialized
INFO - 2018-10-29 17:59:17 --> Helper loaded: url_helper
INFO - 2018-10-29 17:59:17 --> Helper loaded: form_helper
INFO - 2018-10-29 17:59:17 --> Helper loaded: language_helper
DEBUG - 2018-10-29 17:59:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 17:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 17:59:17 --> User Agent Class Initialized
INFO - 2018-10-29 17:59:17 --> Controller Class Initialized
INFO - 2018-10-29 17:59:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 17:59:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 17:59:17 --> Helper loaded: custom_helper
INFO - 2018-10-29 17:59:17 --> Pixel_Model class loaded
INFO - 2018-10-29 17:59:17 --> Database Driver Class Initialized
INFO - 2018-10-29 17:59:17 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 17:59:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 17:59:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 17:59:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 17:59:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 17:59:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-29 17:59:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-29 17:59:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-29 17:59:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 17:59:17 --> Final output sent to browser
DEBUG - 2018-10-29 17:59:17 --> Total execution time: 0.4223
INFO - 2018-10-29 18:00:35 --> Config Class Initialized
INFO - 2018-10-29 18:00:35 --> Hooks Class Initialized
DEBUG - 2018-10-29 18:00:35 --> UTF-8 Support Enabled
INFO - 2018-10-29 18:00:35 --> Utf8 Class Initialized
INFO - 2018-10-29 18:00:35 --> URI Class Initialized
INFO - 2018-10-29 18:00:35 --> Router Class Initialized
INFO - 2018-10-29 18:00:35 --> Output Class Initialized
INFO - 2018-10-29 18:00:36 --> Security Class Initialized
DEBUG - 2018-10-29 18:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 18:00:36 --> CSRF cookie sent
INFO - 2018-10-29 18:00:36 --> Input Class Initialized
INFO - 2018-10-29 18:00:36 --> Language Class Initialized
INFO - 2018-10-29 18:00:36 --> Loader Class Initialized
INFO - 2018-10-29 18:00:36 --> Helper loaded: url_helper
INFO - 2018-10-29 18:00:36 --> Helper loaded: form_helper
INFO - 2018-10-29 18:00:36 --> Helper loaded: language_helper
DEBUG - 2018-10-29 18:00:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 18:00:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 18:00:36 --> User Agent Class Initialized
INFO - 2018-10-29 18:00:36 --> Controller Class Initialized
INFO - 2018-10-29 18:00:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 18:00:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 18:00:36 --> Helper loaded: custom_helper
INFO - 2018-10-29 18:00:36 --> Pixel_Model class loaded
INFO - 2018-10-29 18:00:36 --> Database Driver Class Initialized
INFO - 2018-10-29 18:00:36 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:00:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 18:00:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 18:00:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 18:00:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 18:00:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-29 18:00:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-29 18:00:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-29 18:00:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 18:00:36 --> Final output sent to browser
DEBUG - 2018-10-29 18:00:36 --> Total execution time: 0.4336
INFO - 2018-10-29 18:00:38 --> Config Class Initialized
INFO - 2018-10-29 18:00:38 --> Hooks Class Initialized
DEBUG - 2018-10-29 18:00:38 --> UTF-8 Support Enabled
INFO - 2018-10-29 18:00:38 --> Utf8 Class Initialized
INFO - 2018-10-29 18:00:38 --> URI Class Initialized
INFO - 2018-10-29 18:00:38 --> Router Class Initialized
INFO - 2018-10-29 18:00:38 --> Output Class Initialized
INFO - 2018-10-29 18:00:38 --> Security Class Initialized
DEBUG - 2018-10-29 18:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 18:00:39 --> CSRF cookie sent
INFO - 2018-10-29 18:00:39 --> Input Class Initialized
INFO - 2018-10-29 18:00:39 --> Language Class Initialized
INFO - 2018-10-29 18:00:39 --> Loader Class Initialized
INFO - 2018-10-29 18:00:39 --> Helper loaded: url_helper
INFO - 2018-10-29 18:00:39 --> Helper loaded: form_helper
INFO - 2018-10-29 18:00:39 --> Helper loaded: language_helper
DEBUG - 2018-10-29 18:00:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 18:00:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 18:00:39 --> User Agent Class Initialized
INFO - 2018-10-29 18:00:39 --> Controller Class Initialized
INFO - 2018-10-29 18:00:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 18:00:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 18:00:39 --> Helper loaded: custom_helper
INFO - 2018-10-29 18:00:39 --> Pixel_Model class loaded
INFO - 2018-10-29 18:00:39 --> Database Driver Class Initialized
INFO - 2018-10-29 18:00:39 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:00:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 18:00:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 18:00:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 18:00:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 18:00:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-29 18:00:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-29 18:00:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-29 18:00:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 18:00:39 --> Final output sent to browser
DEBUG - 2018-10-29 18:00:39 --> Total execution time: 0.4168
INFO - 2018-10-29 18:00:41 --> Config Class Initialized
INFO - 2018-10-29 18:00:41 --> Hooks Class Initialized
DEBUG - 2018-10-29 18:00:41 --> UTF-8 Support Enabled
INFO - 2018-10-29 18:00:41 --> Utf8 Class Initialized
INFO - 2018-10-29 18:00:41 --> URI Class Initialized
DEBUG - 2018-10-29 18:00:41 --> No URI present. Default controller set.
INFO - 2018-10-29 18:00:41 --> Router Class Initialized
INFO - 2018-10-29 18:00:41 --> Output Class Initialized
INFO - 2018-10-29 18:00:41 --> Security Class Initialized
DEBUG - 2018-10-29 18:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 18:00:41 --> CSRF cookie sent
INFO - 2018-10-29 18:00:41 --> Input Class Initialized
INFO - 2018-10-29 18:00:41 --> Language Class Initialized
INFO - 2018-10-29 18:00:41 --> Loader Class Initialized
INFO - 2018-10-29 18:00:41 --> Helper loaded: url_helper
INFO - 2018-10-29 18:00:41 --> Helper loaded: form_helper
INFO - 2018-10-29 18:00:41 --> Helper loaded: language_helper
DEBUG - 2018-10-29 18:00:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 18:00:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 18:00:41 --> User Agent Class Initialized
INFO - 2018-10-29 18:00:41 --> Controller Class Initialized
INFO - 2018-10-29 18:00:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 18:00:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 18:00:41 --> Helper loaded: custom_helper
INFO - 2018-10-29 18:00:41 --> Pixel_Model class loaded
INFO - 2018-10-29 18:00:41 --> Database Driver Class Initialized
INFO - 2018-10-29 18:00:41 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:00:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 18:00:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 18:00:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-29 18:00:41 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 18:00:41 --> Final output sent to browser
DEBUG - 2018-10-29 18:00:41 --> Total execution time: 0.3840
INFO - 2018-10-29 18:00:43 --> Config Class Initialized
INFO - 2018-10-29 18:00:43 --> Hooks Class Initialized
DEBUG - 2018-10-29 18:00:43 --> UTF-8 Support Enabled
INFO - 2018-10-29 18:00:43 --> Utf8 Class Initialized
INFO - 2018-10-29 18:00:43 --> URI Class Initialized
DEBUG - 2018-10-29 18:00:43 --> No URI present. Default controller set.
INFO - 2018-10-29 18:00:43 --> Router Class Initialized
INFO - 2018-10-29 18:00:43 --> Output Class Initialized
INFO - 2018-10-29 18:00:43 --> Security Class Initialized
DEBUG - 2018-10-29 18:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 18:00:43 --> CSRF cookie sent
INFO - 2018-10-29 18:00:43 --> Input Class Initialized
INFO - 2018-10-29 18:00:43 --> Language Class Initialized
INFO - 2018-10-29 18:00:43 --> Loader Class Initialized
INFO - 2018-10-29 18:00:43 --> Helper loaded: url_helper
INFO - 2018-10-29 18:00:43 --> Helper loaded: form_helper
INFO - 2018-10-29 18:00:43 --> Helper loaded: language_helper
DEBUG - 2018-10-29 18:00:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 18:00:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 18:00:43 --> User Agent Class Initialized
INFO - 2018-10-29 18:00:43 --> Controller Class Initialized
INFO - 2018-10-29 18:00:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 18:00:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 18:00:43 --> Helper loaded: custom_helper
INFO - 2018-10-29 18:00:43 --> Pixel_Model class loaded
INFO - 2018-10-29 18:00:43 --> Database Driver Class Initialized
INFO - 2018-10-29 18:00:43 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:00:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 18:00:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 18:00:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-29 18:00:43 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 18:00:43 --> Final output sent to browser
DEBUG - 2018-10-29 18:00:43 --> Total execution time: 0.4589
INFO - 2018-10-29 18:03:11 --> Config Class Initialized
INFO - 2018-10-29 18:03:11 --> Hooks Class Initialized
DEBUG - 2018-10-29 18:03:11 --> UTF-8 Support Enabled
INFO - 2018-10-29 18:03:11 --> Utf8 Class Initialized
INFO - 2018-10-29 18:03:11 --> URI Class Initialized
DEBUG - 2018-10-29 18:03:11 --> No URI present. Default controller set.
INFO - 2018-10-29 18:03:11 --> Router Class Initialized
INFO - 2018-10-29 18:03:11 --> Output Class Initialized
INFO - 2018-10-29 18:03:11 --> Security Class Initialized
DEBUG - 2018-10-29 18:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 18:03:11 --> CSRF cookie sent
INFO - 2018-10-29 18:03:11 --> Input Class Initialized
INFO - 2018-10-29 18:03:11 --> Language Class Initialized
INFO - 2018-10-29 18:03:11 --> Loader Class Initialized
INFO - 2018-10-29 18:03:11 --> Helper loaded: url_helper
INFO - 2018-10-29 18:03:11 --> Helper loaded: form_helper
INFO - 2018-10-29 18:03:11 --> Helper loaded: language_helper
DEBUG - 2018-10-29 18:03:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 18:03:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 18:03:11 --> User Agent Class Initialized
INFO - 2018-10-29 18:03:11 --> Controller Class Initialized
INFO - 2018-10-29 18:03:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 18:03:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 18:03:11 --> Helper loaded: custom_helper
INFO - 2018-10-29 18:03:11 --> Pixel_Model class loaded
INFO - 2018-10-29 18:03:11 --> Database Driver Class Initialized
INFO - 2018-10-29 18:03:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:03:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 18:03:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 18:03:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-29 18:03:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 18:03:11 --> Final output sent to browser
DEBUG - 2018-10-29 18:03:11 --> Total execution time: 0.3925
INFO - 2018-10-29 18:03:13 --> Config Class Initialized
INFO - 2018-10-29 18:03:13 --> Hooks Class Initialized
DEBUG - 2018-10-29 18:03:13 --> UTF-8 Support Enabled
INFO - 2018-10-29 18:03:13 --> Utf8 Class Initialized
INFO - 2018-10-29 18:03:13 --> URI Class Initialized
INFO - 2018-10-29 18:03:13 --> Router Class Initialized
INFO - 2018-10-29 18:03:13 --> Output Class Initialized
INFO - 2018-10-29 18:03:13 --> Security Class Initialized
DEBUG - 2018-10-29 18:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 18:03:13 --> CSRF cookie sent
INFO - 2018-10-29 18:03:13 --> Input Class Initialized
INFO - 2018-10-29 18:03:13 --> Language Class Initialized
INFO - 2018-10-29 18:03:13 --> Loader Class Initialized
INFO - 2018-10-29 18:03:13 --> Helper loaded: url_helper
INFO - 2018-10-29 18:03:13 --> Helper loaded: form_helper
INFO - 2018-10-29 18:03:13 --> Helper loaded: language_helper
DEBUG - 2018-10-29 18:03:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 18:03:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 18:03:13 --> User Agent Class Initialized
INFO - 2018-10-29 18:03:13 --> Controller Class Initialized
INFO - 2018-10-29 18:03:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 18:03:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 18:03:13 --> Helper loaded: custom_helper
INFO - 2018-10-29 18:03:13 --> Pixel_Model class loaded
INFO - 2018-10-29 18:03:13 --> Database Driver Class Initialized
INFO - 2018-10-29 18:03:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:03:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 18:03:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 18:03:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 18:03:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 18:03:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-29 18:03:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-29 18:03:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-29 18:03:13 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 18:03:13 --> Final output sent to browser
DEBUG - 2018-10-29 18:03:13 --> Total execution time: 0.5214
INFO - 2018-10-29 18:03:15 --> Config Class Initialized
INFO - 2018-10-29 18:03:15 --> Hooks Class Initialized
DEBUG - 2018-10-29 18:03:15 --> UTF-8 Support Enabled
INFO - 2018-10-29 18:03:15 --> Utf8 Class Initialized
INFO - 2018-10-29 18:03:15 --> URI Class Initialized
INFO - 2018-10-29 18:03:15 --> Router Class Initialized
INFO - 2018-10-29 18:03:15 --> Output Class Initialized
INFO - 2018-10-29 18:03:15 --> Security Class Initialized
DEBUG - 2018-10-29 18:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 18:03:15 --> CSRF cookie sent
INFO - 2018-10-29 18:03:15 --> CSRF token verified
INFO - 2018-10-29 18:03:15 --> Input Class Initialized
INFO - 2018-10-29 18:03:15 --> Language Class Initialized
INFO - 2018-10-29 18:03:15 --> Loader Class Initialized
INFO - 2018-10-29 18:03:15 --> Helper loaded: url_helper
INFO - 2018-10-29 18:03:15 --> Helper loaded: form_helper
INFO - 2018-10-29 18:03:15 --> Helper loaded: language_helper
DEBUG - 2018-10-29 18:03:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 18:03:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 18:03:16 --> User Agent Class Initialized
INFO - 2018-10-29 18:03:16 --> Controller Class Initialized
INFO - 2018-10-29 18:03:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 18:03:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 18:03:16 --> Helper loaded: custom_helper
INFO - 2018-10-29 18:03:16 --> Pixel_Model class loaded
INFO - 2018-10-29 18:03:16 --> Database Driver Class Initialized
INFO - 2018-10-29 18:03:16 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:03:16 --> Database Driver Class Initialized
INFO - 2018-10-29 18:03:16 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:03:16 --> Config Class Initialized
INFO - 2018-10-29 18:03:16 --> Hooks Class Initialized
DEBUG - 2018-10-29 18:03:16 --> UTF-8 Support Enabled
INFO - 2018-10-29 18:03:16 --> Utf8 Class Initialized
INFO - 2018-10-29 18:03:16 --> URI Class Initialized
INFO - 2018-10-29 18:03:16 --> Router Class Initialized
INFO - 2018-10-29 18:03:16 --> Output Class Initialized
INFO - 2018-10-29 18:03:16 --> Security Class Initialized
DEBUG - 2018-10-29 18:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 18:03:16 --> CSRF cookie sent
INFO - 2018-10-29 18:03:16 --> Input Class Initialized
INFO - 2018-10-29 18:03:16 --> Language Class Initialized
INFO - 2018-10-29 18:03:16 --> Loader Class Initialized
INFO - 2018-10-29 18:03:16 --> Helper loaded: url_helper
INFO - 2018-10-29 18:03:16 --> Helper loaded: form_helper
INFO - 2018-10-29 18:03:16 --> Helper loaded: language_helper
DEBUG - 2018-10-29 18:03:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 18:03:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 18:03:16 --> User Agent Class Initialized
INFO - 2018-10-29 18:03:16 --> Controller Class Initialized
INFO - 2018-10-29 18:03:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 18:03:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 18:03:16 --> Helper loaded: custom_helper
INFO - 2018-10-29 18:03:16 --> Pixel_Model class loaded
INFO - 2018-10-29 18:03:16 --> Database Driver Class Initialized
INFO - 2018-10-29 18:03:16 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:03:16 --> Database Driver Class Initialized
INFO - 2018-10-29 18:03:16 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:03:16 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 18:03:16 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 18:03:16 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 18:03:16 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 18:03:16 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-29 18:03:16 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-29 18:03:16 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-29 18:03:16 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 18:03:16 --> Final output sent to browser
DEBUG - 2018-10-29 18:03:16 --> Total execution time: 0.4481
INFO - 2018-10-29 18:03:19 --> Config Class Initialized
INFO - 2018-10-29 18:03:19 --> Hooks Class Initialized
DEBUG - 2018-10-29 18:03:19 --> UTF-8 Support Enabled
INFO - 2018-10-29 18:03:19 --> Utf8 Class Initialized
INFO - 2018-10-29 18:03:19 --> URI Class Initialized
INFO - 2018-10-29 18:03:19 --> Router Class Initialized
INFO - 2018-10-29 18:03:19 --> Output Class Initialized
INFO - 2018-10-29 18:03:19 --> Security Class Initialized
DEBUG - 2018-10-29 18:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 18:03:19 --> CSRF cookie sent
INFO - 2018-10-29 18:03:19 --> CSRF token verified
INFO - 2018-10-29 18:03:19 --> Input Class Initialized
INFO - 2018-10-29 18:03:19 --> Language Class Initialized
INFO - 2018-10-29 18:03:19 --> Loader Class Initialized
INFO - 2018-10-29 18:03:19 --> Helper loaded: url_helper
INFO - 2018-10-29 18:03:19 --> Helper loaded: form_helper
INFO - 2018-10-29 18:03:19 --> Helper loaded: language_helper
DEBUG - 2018-10-29 18:03:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 18:03:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 18:03:19 --> User Agent Class Initialized
INFO - 2018-10-29 18:03:19 --> Controller Class Initialized
INFO - 2018-10-29 18:03:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 18:03:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 18:03:19 --> Helper loaded: custom_helper
INFO - 2018-10-29 18:03:19 --> Pixel_Model class loaded
INFO - 2018-10-29 18:03:19 --> Database Driver Class Initialized
INFO - 2018-10-29 18:03:19 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:03:19 --> Form Validation Class Initialized
INFO - 2018-10-29 18:03:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-29 18:03:19 --> Database Driver Class Initialized
INFO - 2018-10-29 18:03:19 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:03:19 --> Config Class Initialized
INFO - 2018-10-29 18:03:19 --> Hooks Class Initialized
DEBUG - 2018-10-29 18:03:19 --> UTF-8 Support Enabled
INFO - 2018-10-29 18:03:19 --> Utf8 Class Initialized
INFO - 2018-10-29 18:03:19 --> URI Class Initialized
INFO - 2018-10-29 18:03:19 --> Router Class Initialized
INFO - 2018-10-29 18:03:19 --> Output Class Initialized
INFO - 2018-10-29 18:03:19 --> Security Class Initialized
DEBUG - 2018-10-29 18:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 18:03:19 --> CSRF cookie sent
INFO - 2018-10-29 18:03:19 --> Input Class Initialized
INFO - 2018-10-29 18:03:19 --> Language Class Initialized
INFO - 2018-10-29 18:03:19 --> Loader Class Initialized
INFO - 2018-10-29 18:03:19 --> Helper loaded: url_helper
INFO - 2018-10-29 18:03:19 --> Helper loaded: form_helper
INFO - 2018-10-29 18:03:19 --> Helper loaded: language_helper
DEBUG - 2018-10-29 18:03:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 18:03:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 18:03:19 --> User Agent Class Initialized
INFO - 2018-10-29 18:03:19 --> Controller Class Initialized
INFO - 2018-10-29 18:03:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 18:03:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 18:03:19 --> Helper loaded: custom_helper
INFO - 2018-10-29 18:03:19 --> Pixel_Model class loaded
INFO - 2018-10-29 18:03:19 --> Database Driver Class Initialized
INFO - 2018-10-29 18:03:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:03:20 --> Database Driver Class Initialized
INFO - 2018-10-29 18:03:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:03:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 18:03:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 18:03:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 18:03:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 18:03:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-29 18:03:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-29 18:03:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/your_job.php
INFO - 2018-10-29 18:03:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 18:03:20 --> Final output sent to browser
DEBUG - 2018-10-29 18:03:20 --> Total execution time: 0.4571
INFO - 2018-10-29 18:03:20 --> Config Class Initialized
INFO - 2018-10-29 18:03:20 --> Hooks Class Initialized
DEBUG - 2018-10-29 18:03:20 --> UTF-8 Support Enabled
INFO - 2018-10-29 18:03:20 --> Utf8 Class Initialized
INFO - 2018-10-29 18:03:20 --> URI Class Initialized
INFO - 2018-10-29 18:03:20 --> Router Class Initialized
INFO - 2018-10-29 18:03:20 --> Output Class Initialized
INFO - 2018-10-29 18:03:20 --> Security Class Initialized
DEBUG - 2018-10-29 18:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 18:03:21 --> CSRF cookie sent
INFO - 2018-10-29 18:03:21 --> CSRF token verified
INFO - 2018-10-29 18:03:21 --> Input Class Initialized
INFO - 2018-10-29 18:03:21 --> Language Class Initialized
INFO - 2018-10-29 18:03:21 --> Loader Class Initialized
INFO - 2018-10-29 18:03:21 --> Helper loaded: url_helper
INFO - 2018-10-29 18:03:21 --> Helper loaded: form_helper
INFO - 2018-10-29 18:03:21 --> Helper loaded: language_helper
DEBUG - 2018-10-29 18:03:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 18:03:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 18:03:21 --> User Agent Class Initialized
INFO - 2018-10-29 18:03:21 --> Controller Class Initialized
INFO - 2018-10-29 18:03:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 18:03:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 18:03:21 --> Helper loaded: custom_helper
INFO - 2018-10-29 18:03:21 --> Pixel_Model class loaded
INFO - 2018-10-29 18:03:21 --> Database Driver Class Initialized
INFO - 2018-10-29 18:03:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:03:21 --> Form Validation Class Initialized
INFO - 2018-10-29 18:03:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-29 18:03:21 --> Database Driver Class Initialized
INFO - 2018-10-29 18:03:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:03:21 --> Config Class Initialized
INFO - 2018-10-29 18:03:21 --> Hooks Class Initialized
DEBUG - 2018-10-29 18:03:21 --> UTF-8 Support Enabled
INFO - 2018-10-29 18:03:21 --> Utf8 Class Initialized
INFO - 2018-10-29 18:03:21 --> URI Class Initialized
INFO - 2018-10-29 18:03:21 --> Router Class Initialized
INFO - 2018-10-29 18:03:21 --> Output Class Initialized
INFO - 2018-10-29 18:03:21 --> Security Class Initialized
DEBUG - 2018-10-29 18:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 18:03:21 --> CSRF cookie sent
INFO - 2018-10-29 18:03:21 --> Input Class Initialized
INFO - 2018-10-29 18:03:21 --> Language Class Initialized
INFO - 2018-10-29 18:03:21 --> Loader Class Initialized
INFO - 2018-10-29 18:03:21 --> Helper loaded: url_helper
INFO - 2018-10-29 18:03:21 --> Helper loaded: form_helper
INFO - 2018-10-29 18:03:21 --> Helper loaded: language_helper
DEBUG - 2018-10-29 18:03:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 18:03:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 18:03:21 --> User Agent Class Initialized
INFO - 2018-10-29 18:03:21 --> Controller Class Initialized
INFO - 2018-10-29 18:03:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 18:03:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 18:03:21 --> Helper loaded: custom_helper
INFO - 2018-10-29 18:03:21 --> Pixel_Model class loaded
INFO - 2018-10-29 18:03:21 --> Database Driver Class Initialized
INFO - 2018-10-29 18:03:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:03:21 --> Database Driver Class Initialized
INFO - 2018-10-29 18:03:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:03:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 18:03:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 18:03:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner.php
INFO - 2018-10-29 18:03:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 18:03:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 18:03:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-29 18:03:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-29 18:03:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/relation_ship_status.php
INFO - 2018-10-29 18:03:21 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 18:03:21 --> Final output sent to browser
DEBUG - 2018-10-29 18:03:21 --> Total execution time: 0.4601
INFO - 2018-10-29 18:03:22 --> Config Class Initialized
INFO - 2018-10-29 18:03:22 --> Hooks Class Initialized
DEBUG - 2018-10-29 18:03:22 --> UTF-8 Support Enabled
INFO - 2018-10-29 18:03:22 --> Utf8 Class Initialized
INFO - 2018-10-29 18:03:22 --> URI Class Initialized
INFO - 2018-10-29 18:03:22 --> Router Class Initialized
INFO - 2018-10-29 18:03:22 --> Output Class Initialized
INFO - 2018-10-29 18:03:22 --> Security Class Initialized
DEBUG - 2018-10-29 18:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 18:03:22 --> CSRF cookie sent
INFO - 2018-10-29 18:03:22 --> CSRF token verified
INFO - 2018-10-29 18:03:22 --> Input Class Initialized
INFO - 2018-10-29 18:03:22 --> Language Class Initialized
INFO - 2018-10-29 18:03:22 --> Loader Class Initialized
INFO - 2018-10-29 18:03:22 --> Helper loaded: url_helper
INFO - 2018-10-29 18:03:22 --> Helper loaded: form_helper
INFO - 2018-10-29 18:03:22 --> Helper loaded: language_helper
DEBUG - 2018-10-29 18:03:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 18:03:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 18:03:22 --> User Agent Class Initialized
INFO - 2018-10-29 18:03:22 --> Controller Class Initialized
INFO - 2018-10-29 18:03:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 18:03:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 18:03:22 --> Helper loaded: custom_helper
INFO - 2018-10-29 18:03:22 --> Pixel_Model class loaded
INFO - 2018-10-29 18:03:22 --> Database Driver Class Initialized
INFO - 2018-10-29 18:03:22 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:03:22 --> Form Validation Class Initialized
INFO - 2018-10-29 18:03:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-29 18:03:22 --> Database Driver Class Initialized
INFO - 2018-10-29 18:03:22 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:03:22 --> Config Class Initialized
INFO - 2018-10-29 18:03:22 --> Hooks Class Initialized
DEBUG - 2018-10-29 18:03:22 --> UTF-8 Support Enabled
INFO - 2018-10-29 18:03:22 --> Utf8 Class Initialized
INFO - 2018-10-29 18:03:22 --> URI Class Initialized
INFO - 2018-10-29 18:03:22 --> Router Class Initialized
INFO - 2018-10-29 18:03:22 --> Output Class Initialized
INFO - 2018-10-29 18:03:22 --> Security Class Initialized
DEBUG - 2018-10-29 18:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 18:03:22 --> CSRF cookie sent
INFO - 2018-10-29 18:03:22 --> Input Class Initialized
INFO - 2018-10-29 18:03:22 --> Language Class Initialized
INFO - 2018-10-29 18:03:22 --> Loader Class Initialized
INFO - 2018-10-29 18:03:22 --> Helper loaded: url_helper
INFO - 2018-10-29 18:03:23 --> Helper loaded: form_helper
INFO - 2018-10-29 18:03:23 --> Helper loaded: language_helper
DEBUG - 2018-10-29 18:03:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 18:03:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 18:03:23 --> User Agent Class Initialized
INFO - 2018-10-29 18:03:23 --> Controller Class Initialized
INFO - 2018-10-29 18:03:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 18:03:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 18:03:23 --> Helper loaded: custom_helper
INFO - 2018-10-29 18:03:23 --> Pixel_Model class loaded
INFO - 2018-10-29 18:03:23 --> Database Driver Class Initialized
INFO - 2018-10-29 18:03:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:03:23 --> Database Driver Class Initialized
INFO - 2018-10-29 18:03:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:03:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 18:03:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 18:03:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 18:03:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 18:03:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-29 18:03:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-29 18:03:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/income.php
INFO - 2018-10-29 18:03:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 18:03:23 --> Final output sent to browser
DEBUG - 2018-10-29 18:03:23 --> Total execution time: 0.4800
INFO - 2018-10-29 18:03:24 --> Config Class Initialized
INFO - 2018-10-29 18:03:24 --> Hooks Class Initialized
DEBUG - 2018-10-29 18:03:24 --> UTF-8 Support Enabled
INFO - 2018-10-29 18:03:24 --> Utf8 Class Initialized
INFO - 2018-10-29 18:03:24 --> URI Class Initialized
INFO - 2018-10-29 18:03:24 --> Router Class Initialized
INFO - 2018-10-29 18:03:24 --> Output Class Initialized
INFO - 2018-10-29 18:03:24 --> Security Class Initialized
DEBUG - 2018-10-29 18:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 18:03:24 --> CSRF cookie sent
INFO - 2018-10-29 18:03:24 --> Input Class Initialized
INFO - 2018-10-29 18:03:24 --> Language Class Initialized
INFO - 2018-10-29 18:03:24 --> Loader Class Initialized
INFO - 2018-10-29 18:03:24 --> Helper loaded: url_helper
INFO - 2018-10-29 18:03:24 --> Helper loaded: form_helper
INFO - 2018-10-29 18:03:24 --> Helper loaded: language_helper
DEBUG - 2018-10-29 18:03:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 18:03:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 18:03:24 --> User Agent Class Initialized
INFO - 2018-10-29 18:03:24 --> Controller Class Initialized
INFO - 2018-10-29 18:03:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 18:03:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 18:03:24 --> Helper loaded: custom_helper
INFO - 2018-10-29 18:03:24 --> Pixel_Model class loaded
INFO - 2018-10-29 18:03:24 --> Database Driver Class Initialized
INFO - 2018-10-29 18:03:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:03:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 18:03:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 18:03:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 18:03:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 18:03:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-29 18:03:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-29 18:03:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-29 18:03:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 18:03:24 --> Final output sent to browser
DEBUG - 2018-10-29 18:03:24 --> Total execution time: 0.4329
INFO - 2018-10-29 18:03:26 --> Config Class Initialized
INFO - 2018-10-29 18:03:26 --> Hooks Class Initialized
DEBUG - 2018-10-29 18:03:26 --> UTF-8 Support Enabled
INFO - 2018-10-29 18:03:26 --> Utf8 Class Initialized
INFO - 2018-10-29 18:03:26 --> URI Class Initialized
INFO - 2018-10-29 18:03:26 --> Router Class Initialized
INFO - 2018-10-29 18:03:26 --> Output Class Initialized
INFO - 2018-10-29 18:03:26 --> Security Class Initialized
DEBUG - 2018-10-29 18:03:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 18:03:26 --> CSRF cookie sent
INFO - 2018-10-29 18:03:26 --> CSRF token verified
INFO - 2018-10-29 18:03:26 --> Input Class Initialized
INFO - 2018-10-29 18:03:26 --> Language Class Initialized
INFO - 2018-10-29 18:03:26 --> Loader Class Initialized
INFO - 2018-10-29 18:03:26 --> Helper loaded: url_helper
INFO - 2018-10-29 18:03:26 --> Helper loaded: form_helper
INFO - 2018-10-29 18:03:26 --> Helper loaded: language_helper
DEBUG - 2018-10-29 18:03:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 18:03:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 18:03:26 --> User Agent Class Initialized
INFO - 2018-10-29 18:03:26 --> Controller Class Initialized
INFO - 2018-10-29 18:03:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 18:03:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 18:03:26 --> Helper loaded: custom_helper
INFO - 2018-10-29 18:03:26 --> Pixel_Model class loaded
INFO - 2018-10-29 18:03:26 --> Database Driver Class Initialized
INFO - 2018-10-29 18:03:26 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:03:26 --> Database Driver Class Initialized
INFO - 2018-10-29 18:03:26 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:03:26 --> Config Class Initialized
INFO - 2018-10-29 18:03:26 --> Hooks Class Initialized
DEBUG - 2018-10-29 18:03:26 --> UTF-8 Support Enabled
INFO - 2018-10-29 18:03:26 --> Utf8 Class Initialized
INFO - 2018-10-29 18:03:26 --> URI Class Initialized
INFO - 2018-10-29 18:03:27 --> Router Class Initialized
INFO - 2018-10-29 18:03:27 --> Output Class Initialized
INFO - 2018-10-29 18:03:27 --> Security Class Initialized
DEBUG - 2018-10-29 18:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 18:03:27 --> CSRF cookie sent
INFO - 2018-10-29 18:03:27 --> Input Class Initialized
INFO - 2018-10-29 18:03:27 --> Language Class Initialized
INFO - 2018-10-29 18:03:27 --> Loader Class Initialized
INFO - 2018-10-29 18:03:27 --> Helper loaded: url_helper
INFO - 2018-10-29 18:03:27 --> Helper loaded: form_helper
INFO - 2018-10-29 18:03:27 --> Helper loaded: language_helper
DEBUG - 2018-10-29 18:03:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 18:03:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 18:03:27 --> User Agent Class Initialized
INFO - 2018-10-29 18:03:27 --> Controller Class Initialized
INFO - 2018-10-29 18:03:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 18:03:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 18:03:27 --> Helper loaded: custom_helper
INFO - 2018-10-29 18:03:27 --> Pixel_Model class loaded
INFO - 2018-10-29 18:03:27 --> Database Driver Class Initialized
INFO - 2018-10-29 18:03:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:03:27 --> Database Driver Class Initialized
INFO - 2018-10-29 18:03:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:03:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 18:03:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 18:03:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 18:03:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 18:03:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-29 18:03:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-29 18:03:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-29 18:03:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 18:03:27 --> Final output sent to browser
DEBUG - 2018-10-29 18:03:27 --> Total execution time: 0.4519
INFO - 2018-10-29 18:03:29 --> Config Class Initialized
INFO - 2018-10-29 18:03:29 --> Hooks Class Initialized
DEBUG - 2018-10-29 18:03:29 --> UTF-8 Support Enabled
INFO - 2018-10-29 18:03:30 --> Utf8 Class Initialized
INFO - 2018-10-29 18:03:30 --> URI Class Initialized
INFO - 2018-10-29 18:03:30 --> Router Class Initialized
INFO - 2018-10-29 18:03:30 --> Output Class Initialized
INFO - 2018-10-29 18:03:30 --> Security Class Initialized
DEBUG - 2018-10-29 18:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 18:03:30 --> CSRF cookie sent
INFO - 2018-10-29 18:03:30 --> CSRF token verified
INFO - 2018-10-29 18:03:30 --> Input Class Initialized
INFO - 2018-10-29 18:03:30 --> Language Class Initialized
INFO - 2018-10-29 18:03:30 --> Loader Class Initialized
INFO - 2018-10-29 18:03:30 --> Helper loaded: url_helper
INFO - 2018-10-29 18:03:30 --> Helper loaded: form_helper
INFO - 2018-10-29 18:03:30 --> Helper loaded: language_helper
DEBUG - 2018-10-29 18:03:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 18:03:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 18:03:30 --> User Agent Class Initialized
INFO - 2018-10-29 18:03:30 --> Controller Class Initialized
INFO - 2018-10-29 18:03:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 18:03:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 18:03:30 --> Helper loaded: custom_helper
INFO - 2018-10-29 18:03:30 --> Pixel_Model class loaded
INFO - 2018-10-29 18:03:30 --> Database Driver Class Initialized
INFO - 2018-10-29 18:03:30 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:03:30 --> Form Validation Class Initialized
INFO - 2018-10-29 18:03:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-29 18:03:30 --> Database Driver Class Initialized
INFO - 2018-10-29 18:03:30 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:03:30 --> Config Class Initialized
INFO - 2018-10-29 18:03:30 --> Hooks Class Initialized
DEBUG - 2018-10-29 18:03:30 --> UTF-8 Support Enabled
INFO - 2018-10-29 18:03:30 --> Utf8 Class Initialized
INFO - 2018-10-29 18:03:30 --> URI Class Initialized
INFO - 2018-10-29 18:03:30 --> Router Class Initialized
INFO - 2018-10-29 18:03:30 --> Output Class Initialized
INFO - 2018-10-29 18:03:30 --> Security Class Initialized
DEBUG - 2018-10-29 18:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 18:03:30 --> CSRF cookie sent
INFO - 2018-10-29 18:03:30 --> Input Class Initialized
INFO - 2018-10-29 18:03:30 --> Language Class Initialized
INFO - 2018-10-29 18:03:30 --> Loader Class Initialized
INFO - 2018-10-29 18:03:30 --> Helper loaded: url_helper
INFO - 2018-10-29 18:03:30 --> Helper loaded: form_helper
INFO - 2018-10-29 18:03:30 --> Helper loaded: language_helper
DEBUG - 2018-10-29 18:03:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 18:03:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 18:03:30 --> User Agent Class Initialized
INFO - 2018-10-29 18:03:30 --> Controller Class Initialized
INFO - 2018-10-29 18:03:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 18:03:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 18:03:30 --> Helper loaded: custom_helper
INFO - 2018-10-29 18:03:30 --> Pixel_Model class loaded
INFO - 2018-10-29 18:03:30 --> Database Driver Class Initialized
INFO - 2018-10-29 18:03:30 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:03:30 --> Database Driver Class Initialized
INFO - 2018-10-29 18:03:30 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:03:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 18:03:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 18:03:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 18:03:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 18:03:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-29 18:03:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-29 18:03:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/your_job.php
INFO - 2018-10-29 18:03:30 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 18:03:30 --> Final output sent to browser
DEBUG - 2018-10-29 18:03:30 --> Total execution time: 0.4610
INFO - 2018-10-29 18:03:31 --> Config Class Initialized
INFO - 2018-10-29 18:03:31 --> Hooks Class Initialized
DEBUG - 2018-10-29 18:03:31 --> UTF-8 Support Enabled
INFO - 2018-10-29 18:03:31 --> Utf8 Class Initialized
INFO - 2018-10-29 18:03:31 --> URI Class Initialized
INFO - 2018-10-29 18:03:31 --> Router Class Initialized
INFO - 2018-10-29 18:03:31 --> Output Class Initialized
INFO - 2018-10-29 18:03:31 --> Security Class Initialized
DEBUG - 2018-10-29 18:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 18:03:31 --> CSRF cookie sent
INFO - 2018-10-29 18:03:31 --> CSRF token verified
INFO - 2018-10-29 18:03:31 --> Input Class Initialized
INFO - 2018-10-29 18:03:31 --> Language Class Initialized
INFO - 2018-10-29 18:03:31 --> Loader Class Initialized
INFO - 2018-10-29 18:03:31 --> Helper loaded: url_helper
INFO - 2018-10-29 18:03:31 --> Helper loaded: form_helper
INFO - 2018-10-29 18:03:31 --> Helper loaded: language_helper
DEBUG - 2018-10-29 18:03:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 18:03:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 18:03:31 --> User Agent Class Initialized
INFO - 2018-10-29 18:03:31 --> Controller Class Initialized
INFO - 2018-10-29 18:03:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 18:03:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 18:03:32 --> Helper loaded: custom_helper
INFO - 2018-10-29 18:03:32 --> Pixel_Model class loaded
INFO - 2018-10-29 18:03:32 --> Database Driver Class Initialized
INFO - 2018-10-29 18:03:32 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:03:32 --> Form Validation Class Initialized
INFO - 2018-10-29 18:03:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-29 18:03:32 --> Database Driver Class Initialized
INFO - 2018-10-29 18:03:32 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:03:32 --> Config Class Initialized
INFO - 2018-10-29 18:03:32 --> Hooks Class Initialized
DEBUG - 2018-10-29 18:03:32 --> UTF-8 Support Enabled
INFO - 2018-10-29 18:03:32 --> Utf8 Class Initialized
INFO - 2018-10-29 18:03:32 --> URI Class Initialized
INFO - 2018-10-29 18:03:32 --> Router Class Initialized
INFO - 2018-10-29 18:03:32 --> Output Class Initialized
INFO - 2018-10-29 18:03:32 --> Security Class Initialized
DEBUG - 2018-10-29 18:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 18:03:32 --> CSRF cookie sent
INFO - 2018-10-29 18:03:32 --> Input Class Initialized
INFO - 2018-10-29 18:03:32 --> Language Class Initialized
INFO - 2018-10-29 18:03:32 --> Loader Class Initialized
INFO - 2018-10-29 18:03:32 --> Helper loaded: url_helper
INFO - 2018-10-29 18:03:32 --> Helper loaded: form_helper
INFO - 2018-10-29 18:03:32 --> Helper loaded: language_helper
DEBUG - 2018-10-29 18:03:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 18:03:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 18:03:32 --> User Agent Class Initialized
INFO - 2018-10-29 18:03:32 --> Controller Class Initialized
INFO - 2018-10-29 18:03:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 18:03:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 18:03:32 --> Helper loaded: custom_helper
INFO - 2018-10-29 18:03:32 --> Pixel_Model class loaded
INFO - 2018-10-29 18:03:32 --> Database Driver Class Initialized
INFO - 2018-10-29 18:03:32 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:03:32 --> Database Driver Class Initialized
INFO - 2018-10-29 18:03:32 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:03:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 18:03:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 18:03:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner.php
INFO - 2018-10-29 18:03:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 18:03:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 18:03:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-29 18:03:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-29 18:03:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/relation_ship_status.php
INFO - 2018-10-29 18:03:32 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 18:03:32 --> Final output sent to browser
DEBUG - 2018-10-29 18:03:32 --> Total execution time: 0.4767
INFO - 2018-10-29 18:03:36 --> Config Class Initialized
INFO - 2018-10-29 18:03:37 --> Hooks Class Initialized
DEBUG - 2018-10-29 18:03:37 --> UTF-8 Support Enabled
INFO - 2018-10-29 18:03:37 --> Utf8 Class Initialized
INFO - 2018-10-29 18:03:37 --> URI Class Initialized
INFO - 2018-10-29 18:03:37 --> Router Class Initialized
INFO - 2018-10-29 18:03:37 --> Output Class Initialized
INFO - 2018-10-29 18:03:37 --> Security Class Initialized
DEBUG - 2018-10-29 18:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 18:03:37 --> CSRF cookie sent
INFO - 2018-10-29 18:03:37 --> CSRF token verified
INFO - 2018-10-29 18:03:37 --> Input Class Initialized
INFO - 2018-10-29 18:03:37 --> Language Class Initialized
INFO - 2018-10-29 18:03:37 --> Loader Class Initialized
INFO - 2018-10-29 18:03:37 --> Helper loaded: url_helper
INFO - 2018-10-29 18:03:37 --> Helper loaded: form_helper
INFO - 2018-10-29 18:03:37 --> Helper loaded: language_helper
DEBUG - 2018-10-29 18:03:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 18:03:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 18:03:37 --> User Agent Class Initialized
INFO - 2018-10-29 18:03:37 --> Controller Class Initialized
INFO - 2018-10-29 18:03:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 18:03:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 18:03:37 --> Helper loaded: custom_helper
INFO - 2018-10-29 18:03:37 --> Pixel_Model class loaded
INFO - 2018-10-29 18:03:37 --> Database Driver Class Initialized
INFO - 2018-10-29 18:03:37 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:03:37 --> Form Validation Class Initialized
INFO - 2018-10-29 18:03:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-29 18:03:37 --> Database Driver Class Initialized
INFO - 2018-10-29 18:03:37 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:03:37 --> Config Class Initialized
INFO - 2018-10-29 18:03:37 --> Hooks Class Initialized
DEBUG - 2018-10-29 18:03:37 --> UTF-8 Support Enabled
INFO - 2018-10-29 18:03:37 --> Utf8 Class Initialized
INFO - 2018-10-29 18:03:37 --> URI Class Initialized
INFO - 2018-10-29 18:03:37 --> Router Class Initialized
INFO - 2018-10-29 18:03:37 --> Output Class Initialized
INFO - 2018-10-29 18:03:37 --> Security Class Initialized
DEBUG - 2018-10-29 18:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 18:03:37 --> CSRF cookie sent
INFO - 2018-10-29 18:03:37 --> Input Class Initialized
INFO - 2018-10-29 18:03:37 --> Language Class Initialized
INFO - 2018-10-29 18:03:37 --> Loader Class Initialized
INFO - 2018-10-29 18:03:37 --> Helper loaded: url_helper
INFO - 2018-10-29 18:03:37 --> Helper loaded: form_helper
INFO - 2018-10-29 18:03:37 --> Helper loaded: language_helper
DEBUG - 2018-10-29 18:03:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 18:03:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 18:03:37 --> User Agent Class Initialized
INFO - 2018-10-29 18:03:37 --> Controller Class Initialized
INFO - 2018-10-29 18:03:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 18:03:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 18:03:37 --> Helper loaded: custom_helper
INFO - 2018-10-29 18:03:37 --> Pixel_Model class loaded
INFO - 2018-10-29 18:03:37 --> Database Driver Class Initialized
INFO - 2018-10-29 18:03:37 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:03:37 --> Database Driver Class Initialized
INFO - 2018-10-29 18:03:37 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:03:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 18:03:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 18:03:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 18:03:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 18:03:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-29 18:03:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-29 18:03:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/income.php
INFO - 2018-10-29 18:03:37 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 18:03:37 --> Final output sent to browser
DEBUG - 2018-10-29 18:03:38 --> Total execution time: 0.5166
INFO - 2018-10-29 18:03:38 --> Config Class Initialized
INFO - 2018-10-29 18:03:38 --> Hooks Class Initialized
DEBUG - 2018-10-29 18:03:38 --> UTF-8 Support Enabled
INFO - 2018-10-29 18:03:38 --> Utf8 Class Initialized
INFO - 2018-10-29 18:03:38 --> URI Class Initialized
INFO - 2018-10-29 18:03:38 --> Router Class Initialized
INFO - 2018-10-29 18:03:38 --> Output Class Initialized
INFO - 2018-10-29 18:03:38 --> Security Class Initialized
DEBUG - 2018-10-29 18:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 18:03:38 --> CSRF cookie sent
INFO - 2018-10-29 18:03:38 --> Input Class Initialized
INFO - 2018-10-29 18:03:38 --> Language Class Initialized
INFO - 2018-10-29 18:03:38 --> Loader Class Initialized
INFO - 2018-10-29 18:03:38 --> Helper loaded: url_helper
INFO - 2018-10-29 18:03:38 --> Helper loaded: form_helper
INFO - 2018-10-29 18:03:38 --> Helper loaded: language_helper
DEBUG - 2018-10-29 18:03:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 18:03:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 18:03:38 --> User Agent Class Initialized
INFO - 2018-10-29 18:03:38 --> Controller Class Initialized
INFO - 2018-10-29 18:03:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 18:03:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 18:03:38 --> Helper loaded: custom_helper
INFO - 2018-10-29 18:03:38 --> Pixel_Model class loaded
INFO - 2018-10-29 18:03:39 --> Database Driver Class Initialized
INFO - 2018-10-29 18:03:39 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:03:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 18:03:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 18:03:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 18:03:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 18:03:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-29 18:03:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-29 18:03:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-29 18:03:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 18:03:39 --> Final output sent to browser
DEBUG - 2018-10-29 18:03:39 --> Total execution time: 0.4691
INFO - 2018-10-29 18:03:41 --> Config Class Initialized
INFO - 2018-10-29 18:03:41 --> Hooks Class Initialized
DEBUG - 2018-10-29 18:03:41 --> UTF-8 Support Enabled
INFO - 2018-10-29 18:03:41 --> Utf8 Class Initialized
INFO - 2018-10-29 18:03:41 --> URI Class Initialized
INFO - 2018-10-29 18:03:41 --> Router Class Initialized
INFO - 2018-10-29 18:03:41 --> Output Class Initialized
INFO - 2018-10-29 18:03:41 --> Security Class Initialized
DEBUG - 2018-10-29 18:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 18:03:41 --> CSRF cookie sent
INFO - 2018-10-29 18:03:41 --> CSRF token verified
INFO - 2018-10-29 18:03:41 --> Input Class Initialized
INFO - 2018-10-29 18:03:41 --> Language Class Initialized
INFO - 2018-10-29 18:03:41 --> Loader Class Initialized
INFO - 2018-10-29 18:03:41 --> Helper loaded: url_helper
INFO - 2018-10-29 18:03:41 --> Helper loaded: form_helper
INFO - 2018-10-29 18:03:41 --> Helper loaded: language_helper
DEBUG - 2018-10-29 18:03:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 18:03:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 18:03:41 --> User Agent Class Initialized
INFO - 2018-10-29 18:03:41 --> Controller Class Initialized
INFO - 2018-10-29 18:03:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 18:03:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 18:03:41 --> Helper loaded: custom_helper
INFO - 2018-10-29 18:03:41 --> Pixel_Model class loaded
INFO - 2018-10-29 18:03:41 --> Database Driver Class Initialized
INFO - 2018-10-29 18:03:41 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:03:41 --> Database Driver Class Initialized
INFO - 2018-10-29 18:03:41 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:03:41 --> Config Class Initialized
INFO - 2018-10-29 18:03:41 --> Hooks Class Initialized
DEBUG - 2018-10-29 18:03:41 --> UTF-8 Support Enabled
INFO - 2018-10-29 18:03:41 --> Utf8 Class Initialized
INFO - 2018-10-29 18:03:41 --> URI Class Initialized
INFO - 2018-10-29 18:03:41 --> Router Class Initialized
INFO - 2018-10-29 18:03:41 --> Output Class Initialized
INFO - 2018-10-29 18:03:41 --> Security Class Initialized
DEBUG - 2018-10-29 18:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 18:03:41 --> CSRF cookie sent
INFO - 2018-10-29 18:03:41 --> Input Class Initialized
INFO - 2018-10-29 18:03:41 --> Language Class Initialized
INFO - 2018-10-29 18:03:41 --> Loader Class Initialized
INFO - 2018-10-29 18:03:41 --> Helper loaded: url_helper
INFO - 2018-10-29 18:03:41 --> Helper loaded: form_helper
INFO - 2018-10-29 18:03:41 --> Helper loaded: language_helper
DEBUG - 2018-10-29 18:03:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 18:03:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 18:03:41 --> User Agent Class Initialized
INFO - 2018-10-29 18:03:41 --> Controller Class Initialized
INFO - 2018-10-29 18:03:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 18:03:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 18:03:42 --> Helper loaded: custom_helper
INFO - 2018-10-29 18:03:42 --> Pixel_Model class loaded
INFO - 2018-10-29 18:03:42 --> Database Driver Class Initialized
INFO - 2018-10-29 18:03:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:03:42 --> Database Driver Class Initialized
INFO - 2018-10-29 18:03:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:03:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 18:03:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 18:03:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 18:03:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 18:03:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-29 18:03:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-29 18:03:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-29 18:03:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 18:03:42 --> Final output sent to browser
DEBUG - 2018-10-29 18:03:42 --> Total execution time: 0.4921
INFO - 2018-10-29 18:03:44 --> Config Class Initialized
INFO - 2018-10-29 18:03:44 --> Hooks Class Initialized
DEBUG - 2018-10-29 18:03:44 --> UTF-8 Support Enabled
INFO - 2018-10-29 18:03:44 --> Utf8 Class Initialized
INFO - 2018-10-29 18:03:44 --> URI Class Initialized
INFO - 2018-10-29 18:03:44 --> Router Class Initialized
INFO - 2018-10-29 18:03:44 --> Output Class Initialized
INFO - 2018-10-29 18:03:44 --> Security Class Initialized
DEBUG - 2018-10-29 18:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 18:03:44 --> CSRF cookie sent
INFO - 2018-10-29 18:03:44 --> CSRF token verified
INFO - 2018-10-29 18:03:44 --> Input Class Initialized
INFO - 2018-10-29 18:03:44 --> Language Class Initialized
INFO - 2018-10-29 18:03:44 --> Loader Class Initialized
INFO - 2018-10-29 18:03:44 --> Helper loaded: url_helper
INFO - 2018-10-29 18:03:44 --> Helper loaded: form_helper
INFO - 2018-10-29 18:03:44 --> Helper loaded: language_helper
DEBUG - 2018-10-29 18:03:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 18:03:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 18:03:44 --> User Agent Class Initialized
INFO - 2018-10-29 18:03:44 --> Controller Class Initialized
INFO - 2018-10-29 18:03:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 18:03:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 18:03:44 --> Helper loaded: custom_helper
INFO - 2018-10-29 18:03:44 --> Pixel_Model class loaded
INFO - 2018-10-29 18:03:44 --> Database Driver Class Initialized
INFO - 2018-10-29 18:03:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:03:45 --> Form Validation Class Initialized
INFO - 2018-10-29 18:03:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-29 18:03:45 --> Database Driver Class Initialized
INFO - 2018-10-29 18:03:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:03:45 --> Config Class Initialized
INFO - 2018-10-29 18:03:45 --> Hooks Class Initialized
DEBUG - 2018-10-29 18:03:45 --> UTF-8 Support Enabled
INFO - 2018-10-29 18:03:45 --> Utf8 Class Initialized
INFO - 2018-10-29 18:03:45 --> URI Class Initialized
INFO - 2018-10-29 18:03:45 --> Router Class Initialized
INFO - 2018-10-29 18:03:45 --> Output Class Initialized
INFO - 2018-10-29 18:03:45 --> Security Class Initialized
DEBUG - 2018-10-29 18:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 18:03:45 --> CSRF cookie sent
INFO - 2018-10-29 18:03:45 --> Input Class Initialized
INFO - 2018-10-29 18:03:45 --> Language Class Initialized
INFO - 2018-10-29 18:03:45 --> Loader Class Initialized
INFO - 2018-10-29 18:03:45 --> Helper loaded: url_helper
INFO - 2018-10-29 18:03:45 --> Helper loaded: form_helper
INFO - 2018-10-29 18:03:45 --> Helper loaded: language_helper
DEBUG - 2018-10-29 18:03:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 18:03:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 18:03:45 --> User Agent Class Initialized
INFO - 2018-10-29 18:03:45 --> Controller Class Initialized
INFO - 2018-10-29 18:03:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 18:03:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 18:03:45 --> Helper loaded: custom_helper
INFO - 2018-10-29 18:03:45 --> Pixel_Model class loaded
INFO - 2018-10-29 18:03:45 --> Database Driver Class Initialized
INFO - 2018-10-29 18:03:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:03:45 --> Database Driver Class Initialized
INFO - 2018-10-29 18:03:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:03:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 18:03:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 18:03:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 18:03:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 18:03:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-29 18:03:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-29 18:03:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/your_job.php
INFO - 2018-10-29 18:03:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 18:03:45 --> Final output sent to browser
DEBUG - 2018-10-29 18:03:45 --> Total execution time: 0.4866
INFO - 2018-10-29 18:03:46 --> Config Class Initialized
INFO - 2018-10-29 18:03:46 --> Hooks Class Initialized
DEBUG - 2018-10-29 18:03:46 --> UTF-8 Support Enabled
INFO - 2018-10-29 18:03:46 --> Utf8 Class Initialized
INFO - 2018-10-29 18:03:46 --> URI Class Initialized
INFO - 2018-10-29 18:03:46 --> Router Class Initialized
INFO - 2018-10-29 18:03:46 --> Output Class Initialized
INFO - 2018-10-29 18:03:46 --> Security Class Initialized
DEBUG - 2018-10-29 18:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 18:03:46 --> CSRF cookie sent
INFO - 2018-10-29 18:03:46 --> CSRF token verified
INFO - 2018-10-29 18:03:46 --> Input Class Initialized
INFO - 2018-10-29 18:03:46 --> Language Class Initialized
INFO - 2018-10-29 18:03:46 --> Loader Class Initialized
INFO - 2018-10-29 18:03:46 --> Helper loaded: url_helper
INFO - 2018-10-29 18:03:46 --> Helper loaded: form_helper
INFO - 2018-10-29 18:03:46 --> Helper loaded: language_helper
DEBUG - 2018-10-29 18:03:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 18:03:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 18:03:46 --> User Agent Class Initialized
INFO - 2018-10-29 18:03:46 --> Controller Class Initialized
INFO - 2018-10-29 18:03:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 18:03:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 18:03:46 --> Helper loaded: custom_helper
INFO - 2018-10-29 18:03:46 --> Pixel_Model class loaded
INFO - 2018-10-29 18:03:46 --> Database Driver Class Initialized
INFO - 2018-10-29 18:03:46 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:03:46 --> Form Validation Class Initialized
INFO - 2018-10-29 18:03:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-29 18:03:46 --> Database Driver Class Initialized
INFO - 2018-10-29 18:03:46 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:03:46 --> Config Class Initialized
INFO - 2018-10-29 18:03:46 --> Hooks Class Initialized
DEBUG - 2018-10-29 18:03:46 --> UTF-8 Support Enabled
INFO - 2018-10-29 18:03:46 --> Utf8 Class Initialized
INFO - 2018-10-29 18:03:46 --> URI Class Initialized
INFO - 2018-10-29 18:03:46 --> Router Class Initialized
INFO - 2018-10-29 18:03:46 --> Output Class Initialized
INFO - 2018-10-29 18:03:46 --> Security Class Initialized
DEBUG - 2018-10-29 18:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 18:03:46 --> CSRF cookie sent
INFO - 2018-10-29 18:03:46 --> Input Class Initialized
INFO - 2018-10-29 18:03:46 --> Language Class Initialized
INFO - 2018-10-29 18:03:46 --> Loader Class Initialized
INFO - 2018-10-29 18:03:46 --> Helper loaded: url_helper
INFO - 2018-10-29 18:03:46 --> Helper loaded: form_helper
INFO - 2018-10-29 18:03:46 --> Helper loaded: language_helper
DEBUG - 2018-10-29 18:03:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 18:03:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 18:03:46 --> User Agent Class Initialized
INFO - 2018-10-29 18:03:47 --> Controller Class Initialized
INFO - 2018-10-29 18:03:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 18:03:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 18:03:47 --> Helper loaded: custom_helper
INFO - 2018-10-29 18:03:47 --> Pixel_Model class loaded
INFO - 2018-10-29 18:03:47 --> Database Driver Class Initialized
INFO - 2018-10-29 18:03:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:03:47 --> Database Driver Class Initialized
INFO - 2018-10-29 18:03:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:03:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 18:03:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 18:03:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner.php
INFO - 2018-10-29 18:03:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 18:03:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 18:03:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-29 18:03:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-29 18:03:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/relation_ship_status.php
INFO - 2018-10-29 18:03:47 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 18:03:47 --> Final output sent to browser
DEBUG - 2018-10-29 18:03:47 --> Total execution time: 0.4900
INFO - 2018-10-29 18:03:50 --> Config Class Initialized
INFO - 2018-10-29 18:03:50 --> Hooks Class Initialized
DEBUG - 2018-10-29 18:03:50 --> UTF-8 Support Enabled
INFO - 2018-10-29 18:03:50 --> Utf8 Class Initialized
INFO - 2018-10-29 18:03:50 --> URI Class Initialized
INFO - 2018-10-29 18:03:50 --> Router Class Initialized
INFO - 2018-10-29 18:03:50 --> Output Class Initialized
INFO - 2018-10-29 18:03:50 --> Security Class Initialized
DEBUG - 2018-10-29 18:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 18:03:50 --> CSRF cookie sent
INFO - 2018-10-29 18:03:50 --> CSRF token verified
INFO - 2018-10-29 18:03:50 --> Input Class Initialized
INFO - 2018-10-29 18:03:50 --> Language Class Initialized
INFO - 2018-10-29 18:03:50 --> Loader Class Initialized
INFO - 2018-10-29 18:03:50 --> Helper loaded: url_helper
INFO - 2018-10-29 18:03:50 --> Helper loaded: form_helper
INFO - 2018-10-29 18:03:50 --> Helper loaded: language_helper
DEBUG - 2018-10-29 18:03:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 18:03:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 18:03:50 --> User Agent Class Initialized
INFO - 2018-10-29 18:03:50 --> Controller Class Initialized
INFO - 2018-10-29 18:03:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 18:03:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 18:03:50 --> Helper loaded: custom_helper
INFO - 2018-10-29 18:03:50 --> Pixel_Model class loaded
INFO - 2018-10-29 18:03:50 --> Database Driver Class Initialized
INFO - 2018-10-29 18:03:50 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:03:50 --> Form Validation Class Initialized
INFO - 2018-10-29 18:03:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-29 18:03:50 --> Database Driver Class Initialized
INFO - 2018-10-29 18:03:50 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:03:50 --> Config Class Initialized
INFO - 2018-10-29 18:03:50 --> Hooks Class Initialized
DEBUG - 2018-10-29 18:03:50 --> UTF-8 Support Enabled
INFO - 2018-10-29 18:03:50 --> Utf8 Class Initialized
INFO - 2018-10-29 18:03:50 --> URI Class Initialized
INFO - 2018-10-29 18:03:51 --> Router Class Initialized
INFO - 2018-10-29 18:03:51 --> Output Class Initialized
INFO - 2018-10-29 18:03:51 --> Security Class Initialized
DEBUG - 2018-10-29 18:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 18:03:51 --> CSRF cookie sent
INFO - 2018-10-29 18:03:51 --> Input Class Initialized
INFO - 2018-10-29 18:03:51 --> Language Class Initialized
INFO - 2018-10-29 18:03:51 --> Loader Class Initialized
INFO - 2018-10-29 18:03:51 --> Helper loaded: url_helper
INFO - 2018-10-29 18:03:51 --> Helper loaded: form_helper
INFO - 2018-10-29 18:03:51 --> Helper loaded: language_helper
DEBUG - 2018-10-29 18:03:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 18:03:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 18:03:51 --> User Agent Class Initialized
INFO - 2018-10-29 18:03:51 --> Controller Class Initialized
INFO - 2018-10-29 18:03:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 18:03:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 18:03:51 --> Helper loaded: custom_helper
INFO - 2018-10-29 18:03:51 --> Pixel_Model class loaded
INFO - 2018-10-29 18:03:51 --> Database Driver Class Initialized
INFO - 2018-10-29 18:03:51 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:03:51 --> Database Driver Class Initialized
INFO - 2018-10-29 18:03:51 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:03:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 18:03:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 18:03:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 18:03:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 18:03:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-29 18:03:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-29 18:03:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/income.php
INFO - 2018-10-29 18:03:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 18:03:51 --> Final output sent to browser
DEBUG - 2018-10-29 18:03:51 --> Total execution time: 0.4937
INFO - 2018-10-29 18:03:53 --> Config Class Initialized
INFO - 2018-10-29 18:03:53 --> Hooks Class Initialized
DEBUG - 2018-10-29 18:03:53 --> UTF-8 Support Enabled
INFO - 2018-10-29 18:03:53 --> Utf8 Class Initialized
INFO - 2018-10-29 18:03:53 --> URI Class Initialized
INFO - 2018-10-29 18:03:53 --> Router Class Initialized
INFO - 2018-10-29 18:03:53 --> Output Class Initialized
INFO - 2018-10-29 18:03:53 --> Security Class Initialized
DEBUG - 2018-10-29 18:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 18:03:53 --> CSRF cookie sent
INFO - 2018-10-29 18:03:53 --> CSRF token verified
INFO - 2018-10-29 18:03:53 --> Input Class Initialized
INFO - 2018-10-29 18:03:53 --> Language Class Initialized
INFO - 2018-10-29 18:03:53 --> Loader Class Initialized
INFO - 2018-10-29 18:03:53 --> Helper loaded: url_helper
INFO - 2018-10-29 18:03:53 --> Helper loaded: form_helper
INFO - 2018-10-29 18:03:53 --> Helper loaded: language_helper
DEBUG - 2018-10-29 18:03:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 18:03:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 18:03:53 --> User Agent Class Initialized
INFO - 2018-10-29 18:03:53 --> Controller Class Initialized
INFO - 2018-10-29 18:03:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 18:03:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 18:03:53 --> Helper loaded: custom_helper
INFO - 2018-10-29 18:03:53 --> Pixel_Model class loaded
INFO - 2018-10-29 18:03:53 --> Database Driver Class Initialized
INFO - 2018-10-29 18:03:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:03:53 --> Form Validation Class Initialized
INFO - 2018-10-29 18:03:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-29 18:03:53 --> Database Driver Class Initialized
INFO - 2018-10-29 18:03:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:03:53 --> Config Class Initialized
INFO - 2018-10-29 18:03:53 --> Hooks Class Initialized
DEBUG - 2018-10-29 18:03:53 --> UTF-8 Support Enabled
INFO - 2018-10-29 18:03:53 --> Utf8 Class Initialized
INFO - 2018-10-29 18:03:53 --> URI Class Initialized
INFO - 2018-10-29 18:03:53 --> Router Class Initialized
INFO - 2018-10-29 18:03:53 --> Output Class Initialized
INFO - 2018-10-29 18:03:53 --> Security Class Initialized
DEBUG - 2018-10-29 18:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 18:03:53 --> CSRF cookie sent
INFO - 2018-10-29 18:03:53 --> Input Class Initialized
INFO - 2018-10-29 18:03:53 --> Language Class Initialized
INFO - 2018-10-29 18:03:53 --> Loader Class Initialized
INFO - 2018-10-29 18:03:53 --> Helper loaded: url_helper
INFO - 2018-10-29 18:03:53 --> Helper loaded: form_helper
INFO - 2018-10-29 18:03:53 --> Helper loaded: language_helper
DEBUG - 2018-10-29 18:03:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 18:03:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 18:03:53 --> User Agent Class Initialized
INFO - 2018-10-29 18:03:53 --> Controller Class Initialized
INFO - 2018-10-29 18:03:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 18:03:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 18:03:53 --> Helper loaded: custom_helper
INFO - 2018-10-29 18:03:53 --> Pixel_Model class loaded
INFO - 2018-10-29 18:03:53 --> Database Driver Class Initialized
INFO - 2018-10-29 18:03:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:03:53 --> Database Driver Class Initialized
INFO - 2018-10-29 18:03:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:03:53 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 18:03:53 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 18:03:53 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 18:03:53 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 18:03:53 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-29 18:03:53 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-29 18:03:53 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/cohabitation.php
INFO - 2018-10-29 18:03:54 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 18:03:54 --> Final output sent to browser
DEBUG - 2018-10-29 18:03:54 --> Total execution time: 0.5203
INFO - 2018-10-29 18:03:54 --> Config Class Initialized
INFO - 2018-10-29 18:03:54 --> Hooks Class Initialized
DEBUG - 2018-10-29 18:03:54 --> UTF-8 Support Enabled
INFO - 2018-10-29 18:03:54 --> Utf8 Class Initialized
INFO - 2018-10-29 18:03:54 --> URI Class Initialized
INFO - 2018-10-29 18:03:54 --> Router Class Initialized
INFO - 2018-10-29 18:03:54 --> Output Class Initialized
INFO - 2018-10-29 18:03:54 --> Security Class Initialized
DEBUG - 2018-10-29 18:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 18:03:54 --> CSRF cookie sent
INFO - 2018-10-29 18:03:54 --> Input Class Initialized
INFO - 2018-10-29 18:03:54 --> Language Class Initialized
INFO - 2018-10-29 18:03:54 --> Loader Class Initialized
INFO - 2018-10-29 18:03:54 --> Helper loaded: url_helper
INFO - 2018-10-29 18:03:54 --> Helper loaded: form_helper
INFO - 2018-10-29 18:03:54 --> Helper loaded: language_helper
DEBUG - 2018-10-29 18:03:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 18:03:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 18:03:54 --> User Agent Class Initialized
INFO - 2018-10-29 18:03:54 --> Controller Class Initialized
INFO - 2018-10-29 18:03:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 18:03:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 18:03:55 --> Helper loaded: custom_helper
INFO - 2018-10-29 18:03:55 --> Pixel_Model class loaded
INFO - 2018-10-29 18:03:55 --> Database Driver Class Initialized
INFO - 2018-10-29 18:03:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:03:55 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 18:03:55 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 18:03:55 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 18:03:55 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 18:03:55 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-29 18:03:55 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-29 18:03:55 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-29 18:03:55 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 18:03:55 --> Final output sent to browser
DEBUG - 2018-10-29 18:03:55 --> Total execution time: 0.4723
INFO - 2018-10-29 18:03:58 --> Config Class Initialized
INFO - 2018-10-29 18:03:58 --> Hooks Class Initialized
DEBUG - 2018-10-29 18:03:58 --> UTF-8 Support Enabled
INFO - 2018-10-29 18:03:58 --> Utf8 Class Initialized
INFO - 2018-10-29 18:03:58 --> URI Class Initialized
INFO - 2018-10-29 18:03:58 --> Router Class Initialized
INFO - 2018-10-29 18:03:58 --> Output Class Initialized
INFO - 2018-10-29 18:03:58 --> Security Class Initialized
DEBUG - 2018-10-29 18:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 18:03:58 --> CSRF cookie sent
INFO - 2018-10-29 18:03:58 --> CSRF token verified
INFO - 2018-10-29 18:03:58 --> Input Class Initialized
INFO - 2018-10-29 18:03:58 --> Language Class Initialized
INFO - 2018-10-29 18:03:58 --> Loader Class Initialized
INFO - 2018-10-29 18:03:58 --> Helper loaded: url_helper
INFO - 2018-10-29 18:03:58 --> Helper loaded: form_helper
INFO - 2018-10-29 18:03:58 --> Helper loaded: language_helper
DEBUG - 2018-10-29 18:03:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 18:03:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 18:03:58 --> User Agent Class Initialized
INFO - 2018-10-29 18:03:58 --> Controller Class Initialized
INFO - 2018-10-29 18:03:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 18:03:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 18:03:58 --> Helper loaded: custom_helper
INFO - 2018-10-29 18:03:58 --> Pixel_Model class loaded
INFO - 2018-10-29 18:03:58 --> Database Driver Class Initialized
INFO - 2018-10-29 18:03:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:03:58 --> Database Driver Class Initialized
INFO - 2018-10-29 18:03:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:03:58 --> Config Class Initialized
INFO - 2018-10-29 18:03:58 --> Hooks Class Initialized
DEBUG - 2018-10-29 18:03:58 --> UTF-8 Support Enabled
INFO - 2018-10-29 18:03:58 --> Utf8 Class Initialized
INFO - 2018-10-29 18:03:58 --> URI Class Initialized
INFO - 2018-10-29 18:03:58 --> Router Class Initialized
INFO - 2018-10-29 18:03:58 --> Output Class Initialized
INFO - 2018-10-29 18:03:58 --> Security Class Initialized
DEBUG - 2018-10-29 18:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 18:03:58 --> CSRF cookie sent
INFO - 2018-10-29 18:03:58 --> Input Class Initialized
INFO - 2018-10-29 18:03:58 --> Language Class Initialized
INFO - 2018-10-29 18:03:58 --> Loader Class Initialized
INFO - 2018-10-29 18:03:58 --> Helper loaded: url_helper
INFO - 2018-10-29 18:03:58 --> Helper loaded: form_helper
INFO - 2018-10-29 18:03:58 --> Helper loaded: language_helper
DEBUG - 2018-10-29 18:03:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 18:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 18:03:59 --> User Agent Class Initialized
INFO - 2018-10-29 18:03:59 --> Controller Class Initialized
INFO - 2018-10-29 18:03:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 18:03:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 18:03:59 --> Helper loaded: custom_helper
INFO - 2018-10-29 18:03:59 --> Pixel_Model class loaded
INFO - 2018-10-29 18:03:59 --> Database Driver Class Initialized
INFO - 2018-10-29 18:03:59 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:03:59 --> Database Driver Class Initialized
INFO - 2018-10-29 18:03:59 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:03:59 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 18:03:59 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 18:03:59 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 18:03:59 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 18:03:59 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-29 18:03:59 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-29 18:03:59 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-29 18:03:59 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 18:03:59 --> Final output sent to browser
DEBUG - 2018-10-29 18:03:59 --> Total execution time: 0.4861
INFO - 2018-10-29 18:04:01 --> Config Class Initialized
INFO - 2018-10-29 18:04:01 --> Hooks Class Initialized
DEBUG - 2018-10-29 18:04:01 --> UTF-8 Support Enabled
INFO - 2018-10-29 18:04:01 --> Utf8 Class Initialized
INFO - 2018-10-29 18:04:01 --> URI Class Initialized
INFO - 2018-10-29 18:04:01 --> Router Class Initialized
INFO - 2018-10-29 18:04:01 --> Output Class Initialized
INFO - 2018-10-29 18:04:01 --> Security Class Initialized
DEBUG - 2018-10-29 18:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 18:04:01 --> CSRF cookie sent
INFO - 2018-10-29 18:04:01 --> CSRF token verified
INFO - 2018-10-29 18:04:02 --> Input Class Initialized
INFO - 2018-10-29 18:04:02 --> Language Class Initialized
INFO - 2018-10-29 18:04:02 --> Loader Class Initialized
INFO - 2018-10-29 18:04:02 --> Helper loaded: url_helper
INFO - 2018-10-29 18:04:02 --> Helper loaded: form_helper
INFO - 2018-10-29 18:04:02 --> Helper loaded: language_helper
DEBUG - 2018-10-29 18:04:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 18:04:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 18:04:02 --> User Agent Class Initialized
INFO - 2018-10-29 18:04:02 --> Controller Class Initialized
INFO - 2018-10-29 18:04:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 18:04:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 18:04:02 --> Helper loaded: custom_helper
INFO - 2018-10-29 18:04:02 --> Pixel_Model class loaded
INFO - 2018-10-29 18:04:02 --> Database Driver Class Initialized
INFO - 2018-10-29 18:04:02 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:04:02 --> Form Validation Class Initialized
INFO - 2018-10-29 18:04:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-29 18:04:02 --> Database Driver Class Initialized
INFO - 2018-10-29 18:04:02 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:04:02 --> Config Class Initialized
INFO - 2018-10-29 18:04:02 --> Hooks Class Initialized
DEBUG - 2018-10-29 18:04:02 --> UTF-8 Support Enabled
INFO - 2018-10-29 18:04:02 --> Utf8 Class Initialized
INFO - 2018-10-29 18:04:02 --> URI Class Initialized
INFO - 2018-10-29 18:04:02 --> Router Class Initialized
INFO - 2018-10-29 18:04:02 --> Output Class Initialized
INFO - 2018-10-29 18:04:02 --> Security Class Initialized
DEBUG - 2018-10-29 18:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 18:04:02 --> CSRF cookie sent
INFO - 2018-10-29 18:04:02 --> Input Class Initialized
INFO - 2018-10-29 18:04:02 --> Language Class Initialized
INFO - 2018-10-29 18:04:02 --> Loader Class Initialized
INFO - 2018-10-29 18:04:02 --> Helper loaded: url_helper
INFO - 2018-10-29 18:04:02 --> Helper loaded: form_helper
INFO - 2018-10-29 18:04:02 --> Helper loaded: language_helper
DEBUG - 2018-10-29 18:04:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 18:04:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 18:04:02 --> User Agent Class Initialized
INFO - 2018-10-29 18:04:02 --> Controller Class Initialized
INFO - 2018-10-29 18:04:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 18:04:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 18:04:02 --> Helper loaded: custom_helper
INFO - 2018-10-29 18:04:02 --> Pixel_Model class loaded
INFO - 2018-10-29 18:04:02 --> Database Driver Class Initialized
INFO - 2018-10-29 18:04:02 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:04:02 --> Database Driver Class Initialized
INFO - 2018-10-29 18:04:02 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:04:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 18:04:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 18:04:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 18:04:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 18:04:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-29 18:04:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-29 18:04:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/your_job.php
INFO - 2018-10-29 18:04:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 18:04:02 --> Final output sent to browser
DEBUG - 2018-10-29 18:04:02 --> Total execution time: 0.4955
INFO - 2018-10-29 18:04:03 --> Config Class Initialized
INFO - 2018-10-29 18:04:03 --> Hooks Class Initialized
DEBUG - 2018-10-29 18:04:03 --> UTF-8 Support Enabled
INFO - 2018-10-29 18:04:03 --> Utf8 Class Initialized
INFO - 2018-10-29 18:04:03 --> URI Class Initialized
INFO - 2018-10-29 18:04:03 --> Router Class Initialized
INFO - 2018-10-29 18:04:03 --> Output Class Initialized
INFO - 2018-10-29 18:04:03 --> Security Class Initialized
DEBUG - 2018-10-29 18:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 18:04:03 --> CSRF cookie sent
INFO - 2018-10-29 18:04:03 --> CSRF token verified
INFO - 2018-10-29 18:04:03 --> Input Class Initialized
INFO - 2018-10-29 18:04:03 --> Language Class Initialized
INFO - 2018-10-29 18:04:03 --> Loader Class Initialized
INFO - 2018-10-29 18:04:03 --> Helper loaded: url_helper
INFO - 2018-10-29 18:04:03 --> Helper loaded: form_helper
INFO - 2018-10-29 18:04:03 --> Helper loaded: language_helper
DEBUG - 2018-10-29 18:04:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 18:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 18:04:03 --> User Agent Class Initialized
INFO - 2018-10-29 18:04:03 --> Controller Class Initialized
INFO - 2018-10-29 18:04:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 18:04:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 18:04:03 --> Helper loaded: custom_helper
INFO - 2018-10-29 18:04:03 --> Pixel_Model class loaded
INFO - 2018-10-29 18:04:03 --> Database Driver Class Initialized
INFO - 2018-10-29 18:04:03 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:04:03 --> Form Validation Class Initialized
INFO - 2018-10-29 18:04:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-29 18:04:03 --> Database Driver Class Initialized
INFO - 2018-10-29 18:04:03 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:04:03 --> Config Class Initialized
INFO - 2018-10-29 18:04:03 --> Hooks Class Initialized
DEBUG - 2018-10-29 18:04:04 --> UTF-8 Support Enabled
INFO - 2018-10-29 18:04:04 --> Utf8 Class Initialized
INFO - 2018-10-29 18:04:04 --> URI Class Initialized
INFO - 2018-10-29 18:04:04 --> Router Class Initialized
INFO - 2018-10-29 18:04:04 --> Output Class Initialized
INFO - 2018-10-29 18:04:04 --> Security Class Initialized
DEBUG - 2018-10-29 18:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 18:04:04 --> CSRF cookie sent
INFO - 2018-10-29 18:04:04 --> Input Class Initialized
INFO - 2018-10-29 18:04:04 --> Language Class Initialized
INFO - 2018-10-29 18:04:04 --> Loader Class Initialized
INFO - 2018-10-29 18:04:04 --> Helper loaded: url_helper
INFO - 2018-10-29 18:04:04 --> Helper loaded: form_helper
INFO - 2018-10-29 18:04:04 --> Helper loaded: language_helper
DEBUG - 2018-10-29 18:04:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 18:04:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 18:04:04 --> User Agent Class Initialized
INFO - 2018-10-29 18:04:04 --> Controller Class Initialized
INFO - 2018-10-29 18:04:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 18:04:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 18:04:04 --> Helper loaded: custom_helper
INFO - 2018-10-29 18:04:04 --> Pixel_Model class loaded
INFO - 2018-10-29 18:04:04 --> Database Driver Class Initialized
INFO - 2018-10-29 18:04:04 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:04:04 --> Database Driver Class Initialized
INFO - 2018-10-29 18:04:04 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:04:04 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 18:04:04 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 18:04:04 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner.php
INFO - 2018-10-29 18:04:04 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 18:04:04 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 18:04:04 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-29 18:04:04 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-29 18:04:04 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/relation_ship_status.php
INFO - 2018-10-29 18:04:04 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 18:04:04 --> Final output sent to browser
DEBUG - 2018-10-29 18:04:04 --> Total execution time: 0.4916
INFO - 2018-10-29 18:04:05 --> Config Class Initialized
INFO - 2018-10-29 18:04:05 --> Hooks Class Initialized
DEBUG - 2018-10-29 18:04:05 --> UTF-8 Support Enabled
INFO - 2018-10-29 18:04:05 --> Utf8 Class Initialized
INFO - 2018-10-29 18:04:05 --> URI Class Initialized
INFO - 2018-10-29 18:04:05 --> Router Class Initialized
INFO - 2018-10-29 18:04:05 --> Output Class Initialized
INFO - 2018-10-29 18:04:05 --> Security Class Initialized
DEBUG - 2018-10-29 18:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 18:04:05 --> CSRF cookie sent
INFO - 2018-10-29 18:04:05 --> CSRF token verified
INFO - 2018-10-29 18:04:05 --> Input Class Initialized
INFO - 2018-10-29 18:04:05 --> Language Class Initialized
INFO - 2018-10-29 18:04:05 --> Loader Class Initialized
INFO - 2018-10-29 18:04:05 --> Helper loaded: url_helper
INFO - 2018-10-29 18:04:05 --> Helper loaded: form_helper
INFO - 2018-10-29 18:04:05 --> Helper loaded: language_helper
DEBUG - 2018-10-29 18:04:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 18:04:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 18:04:05 --> User Agent Class Initialized
INFO - 2018-10-29 18:04:05 --> Controller Class Initialized
INFO - 2018-10-29 18:04:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 18:04:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 18:04:05 --> Helper loaded: custom_helper
INFO - 2018-10-29 18:04:05 --> Pixel_Model class loaded
INFO - 2018-10-29 18:04:05 --> Database Driver Class Initialized
INFO - 2018-10-29 18:04:05 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:04:05 --> Form Validation Class Initialized
INFO - 2018-10-29 18:04:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-29 18:04:05 --> Database Driver Class Initialized
INFO - 2018-10-29 18:04:05 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:04:05 --> Config Class Initialized
INFO - 2018-10-29 18:04:05 --> Hooks Class Initialized
DEBUG - 2018-10-29 18:04:05 --> UTF-8 Support Enabled
INFO - 2018-10-29 18:04:05 --> Utf8 Class Initialized
INFO - 2018-10-29 18:04:05 --> URI Class Initialized
INFO - 2018-10-29 18:04:05 --> Router Class Initialized
INFO - 2018-10-29 18:04:05 --> Output Class Initialized
INFO - 2018-10-29 18:04:05 --> Security Class Initialized
DEBUG - 2018-10-29 18:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 18:04:05 --> CSRF cookie sent
INFO - 2018-10-29 18:04:05 --> Input Class Initialized
INFO - 2018-10-29 18:04:05 --> Language Class Initialized
INFO - 2018-10-29 18:04:05 --> Loader Class Initialized
INFO - 2018-10-29 18:04:05 --> Helper loaded: url_helper
INFO - 2018-10-29 18:04:05 --> Helper loaded: form_helper
INFO - 2018-10-29 18:04:05 --> Helper loaded: language_helper
DEBUG - 2018-10-29 18:04:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 18:04:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 18:04:05 --> User Agent Class Initialized
INFO - 2018-10-29 18:04:05 --> Controller Class Initialized
INFO - 2018-10-29 18:04:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 18:04:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 18:04:05 --> Helper loaded: custom_helper
INFO - 2018-10-29 18:04:05 --> Pixel_Model class loaded
INFO - 2018-10-29 18:04:05 --> Database Driver Class Initialized
INFO - 2018-10-29 18:04:05 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:04:05 --> Database Driver Class Initialized
INFO - 2018-10-29 18:04:05 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:04:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 18:04:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 18:04:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 18:04:05 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 18:04:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-29 18:04:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-29 18:04:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/income.php
INFO - 2018-10-29 18:04:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 18:04:06 --> Final output sent to browser
DEBUG - 2018-10-29 18:04:06 --> Total execution time: 0.4896
INFO - 2018-10-29 18:04:15 --> Config Class Initialized
INFO - 2018-10-29 18:04:15 --> Hooks Class Initialized
DEBUG - 2018-10-29 18:04:15 --> UTF-8 Support Enabled
INFO - 2018-10-29 18:04:15 --> Utf8 Class Initialized
INFO - 2018-10-29 18:04:15 --> URI Class Initialized
INFO - 2018-10-29 18:04:15 --> Router Class Initialized
INFO - 2018-10-29 18:04:15 --> Output Class Initialized
INFO - 2018-10-29 18:04:15 --> Security Class Initialized
DEBUG - 2018-10-29 18:04:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 18:04:15 --> CSRF cookie sent
INFO - 2018-10-29 18:04:15 --> Input Class Initialized
INFO - 2018-10-29 18:04:15 --> Language Class Initialized
INFO - 2018-10-29 18:04:15 --> Loader Class Initialized
INFO - 2018-10-29 18:04:15 --> Helper loaded: url_helper
INFO - 2018-10-29 18:04:15 --> Helper loaded: form_helper
INFO - 2018-10-29 18:04:15 --> Helper loaded: language_helper
DEBUG - 2018-10-29 18:04:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 18:04:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 18:04:15 --> User Agent Class Initialized
INFO - 2018-10-29 18:04:15 --> Controller Class Initialized
INFO - 2018-10-29 18:04:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 18:04:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 18:04:15 --> Helper loaded: custom_helper
INFO - 2018-10-29 18:04:15 --> Pixel_Model class loaded
INFO - 2018-10-29 18:04:15 --> Database Driver Class Initialized
INFO - 2018-10-29 18:04:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:04:15 --> Database Driver Class Initialized
INFO - 2018-10-29 18:04:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:04:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 18:04:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 18:04:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 18:04:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 18:04:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-29 18:04:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-29 18:04:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/income.php
INFO - 2018-10-29 18:04:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 18:04:15 --> Final output sent to browser
DEBUG - 2018-10-29 18:04:15 --> Total execution time: 0.5169
INFO - 2018-10-29 18:04:16 --> Config Class Initialized
INFO - 2018-10-29 18:04:16 --> Hooks Class Initialized
DEBUG - 2018-10-29 18:04:16 --> UTF-8 Support Enabled
INFO - 2018-10-29 18:04:16 --> Utf8 Class Initialized
INFO - 2018-10-29 18:04:16 --> URI Class Initialized
INFO - 2018-10-29 18:04:16 --> Router Class Initialized
INFO - 2018-10-29 18:04:16 --> Output Class Initialized
INFO - 2018-10-29 18:04:16 --> Security Class Initialized
DEBUG - 2018-10-29 18:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 18:04:16 --> CSRF cookie sent
INFO - 2018-10-29 18:04:16 --> Input Class Initialized
INFO - 2018-10-29 18:04:16 --> Language Class Initialized
INFO - 2018-10-29 18:04:16 --> Loader Class Initialized
INFO - 2018-10-29 18:04:16 --> Helper loaded: url_helper
INFO - 2018-10-29 18:04:16 --> Helper loaded: form_helper
INFO - 2018-10-29 18:04:16 --> Helper loaded: language_helper
DEBUG - 2018-10-29 18:04:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 18:04:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 18:04:16 --> User Agent Class Initialized
INFO - 2018-10-29 18:04:16 --> Controller Class Initialized
INFO - 2018-10-29 18:04:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 18:04:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 18:04:16 --> Helper loaded: custom_helper
INFO - 2018-10-29 18:04:16 --> Pixel_Model class loaded
INFO - 2018-10-29 18:04:16 --> Database Driver Class Initialized
INFO - 2018-10-29 18:04:16 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:04:16 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 18:04:16 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 18:04:16 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 18:04:16 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 18:04:16 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-29 18:04:16 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-29 18:04:16 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-29 18:04:17 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 18:04:17 --> Final output sent to browser
DEBUG - 2018-10-29 18:04:17 --> Total execution time: 0.4876
INFO - 2018-10-29 18:04:19 --> Config Class Initialized
INFO - 2018-10-29 18:04:19 --> Hooks Class Initialized
DEBUG - 2018-10-29 18:04:19 --> UTF-8 Support Enabled
INFO - 2018-10-29 18:04:19 --> Utf8 Class Initialized
INFO - 2018-10-29 18:04:19 --> URI Class Initialized
INFO - 2018-10-29 18:04:19 --> Router Class Initialized
INFO - 2018-10-29 18:04:19 --> Output Class Initialized
INFO - 2018-10-29 18:04:19 --> Security Class Initialized
DEBUG - 2018-10-29 18:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 18:04:19 --> CSRF cookie sent
INFO - 2018-10-29 18:04:19 --> CSRF token verified
INFO - 2018-10-29 18:04:19 --> Input Class Initialized
INFO - 2018-10-29 18:04:19 --> Language Class Initialized
INFO - 2018-10-29 18:04:19 --> Loader Class Initialized
INFO - 2018-10-29 18:04:19 --> Helper loaded: url_helper
INFO - 2018-10-29 18:04:19 --> Helper loaded: form_helper
INFO - 2018-10-29 18:04:19 --> Helper loaded: language_helper
DEBUG - 2018-10-29 18:04:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 18:04:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 18:04:19 --> User Agent Class Initialized
INFO - 2018-10-29 18:04:19 --> Controller Class Initialized
INFO - 2018-10-29 18:04:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 18:04:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 18:04:19 --> Helper loaded: custom_helper
INFO - 2018-10-29 18:04:19 --> Pixel_Model class loaded
INFO - 2018-10-29 18:04:19 --> Database Driver Class Initialized
INFO - 2018-10-29 18:04:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:04:20 --> Database Driver Class Initialized
INFO - 2018-10-29 18:04:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:04:20 --> Config Class Initialized
INFO - 2018-10-29 18:04:20 --> Hooks Class Initialized
DEBUG - 2018-10-29 18:04:20 --> UTF-8 Support Enabled
INFO - 2018-10-29 18:04:20 --> Utf8 Class Initialized
INFO - 2018-10-29 18:04:20 --> URI Class Initialized
INFO - 2018-10-29 18:04:20 --> Router Class Initialized
INFO - 2018-10-29 18:04:20 --> Output Class Initialized
INFO - 2018-10-29 18:04:20 --> Security Class Initialized
DEBUG - 2018-10-29 18:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 18:04:20 --> CSRF cookie sent
INFO - 2018-10-29 18:04:20 --> Input Class Initialized
INFO - 2018-10-29 18:04:20 --> Language Class Initialized
INFO - 2018-10-29 18:04:20 --> Loader Class Initialized
INFO - 2018-10-29 18:04:20 --> Helper loaded: url_helper
INFO - 2018-10-29 18:04:20 --> Helper loaded: form_helper
INFO - 2018-10-29 18:04:20 --> Helper loaded: language_helper
DEBUG - 2018-10-29 18:04:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 18:04:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 18:04:20 --> User Agent Class Initialized
INFO - 2018-10-29 18:04:20 --> Controller Class Initialized
INFO - 2018-10-29 18:04:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 18:04:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 18:04:20 --> Helper loaded: custom_helper
INFO - 2018-10-29 18:04:20 --> Pixel_Model class loaded
INFO - 2018-10-29 18:04:20 --> Database Driver Class Initialized
INFO - 2018-10-29 18:04:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:04:20 --> Database Driver Class Initialized
INFO - 2018-10-29 18:04:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:04:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 18:04:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 18:04:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 18:04:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 18:04:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-29 18:04:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-29 18:04:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-29 18:04:20 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 18:04:20 --> Final output sent to browser
DEBUG - 2018-10-29 18:04:20 --> Total execution time: 0.5209
INFO - 2018-10-29 18:04:23 --> Config Class Initialized
INFO - 2018-10-29 18:04:23 --> Hooks Class Initialized
DEBUG - 2018-10-29 18:04:23 --> UTF-8 Support Enabled
INFO - 2018-10-29 18:04:23 --> Utf8 Class Initialized
INFO - 2018-10-29 18:04:23 --> URI Class Initialized
INFO - 2018-10-29 18:04:23 --> Router Class Initialized
INFO - 2018-10-29 18:04:23 --> Output Class Initialized
INFO - 2018-10-29 18:04:23 --> Security Class Initialized
DEBUG - 2018-10-29 18:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 18:04:23 --> CSRF cookie sent
INFO - 2018-10-29 18:04:23 --> CSRF token verified
INFO - 2018-10-29 18:04:23 --> Input Class Initialized
INFO - 2018-10-29 18:04:23 --> Language Class Initialized
INFO - 2018-10-29 18:04:23 --> Loader Class Initialized
INFO - 2018-10-29 18:04:23 --> Helper loaded: url_helper
INFO - 2018-10-29 18:04:23 --> Helper loaded: form_helper
INFO - 2018-10-29 18:04:23 --> Helper loaded: language_helper
DEBUG - 2018-10-29 18:04:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 18:04:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 18:04:23 --> User Agent Class Initialized
INFO - 2018-10-29 18:04:23 --> Controller Class Initialized
INFO - 2018-10-29 18:04:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 18:04:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 18:04:23 --> Helper loaded: custom_helper
INFO - 2018-10-29 18:04:23 --> Pixel_Model class loaded
INFO - 2018-10-29 18:04:23 --> Database Driver Class Initialized
INFO - 2018-10-29 18:04:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:04:23 --> Form Validation Class Initialized
INFO - 2018-10-29 18:04:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-29 18:04:23 --> Database Driver Class Initialized
INFO - 2018-10-29 18:04:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:04:23 --> Config Class Initialized
INFO - 2018-10-29 18:04:24 --> Hooks Class Initialized
DEBUG - 2018-10-29 18:04:24 --> UTF-8 Support Enabled
INFO - 2018-10-29 18:04:24 --> Utf8 Class Initialized
INFO - 2018-10-29 18:04:24 --> URI Class Initialized
INFO - 2018-10-29 18:04:24 --> Router Class Initialized
INFO - 2018-10-29 18:04:24 --> Output Class Initialized
INFO - 2018-10-29 18:04:24 --> Security Class Initialized
DEBUG - 2018-10-29 18:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 18:04:24 --> CSRF cookie sent
INFO - 2018-10-29 18:04:24 --> Input Class Initialized
INFO - 2018-10-29 18:04:24 --> Language Class Initialized
INFO - 2018-10-29 18:04:24 --> Loader Class Initialized
INFO - 2018-10-29 18:04:24 --> Helper loaded: url_helper
INFO - 2018-10-29 18:04:24 --> Helper loaded: form_helper
INFO - 2018-10-29 18:04:24 --> Helper loaded: language_helper
DEBUG - 2018-10-29 18:04:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 18:04:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 18:04:24 --> User Agent Class Initialized
INFO - 2018-10-29 18:04:24 --> Controller Class Initialized
INFO - 2018-10-29 18:04:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 18:04:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 18:04:24 --> Helper loaded: custom_helper
INFO - 2018-10-29 18:04:24 --> Pixel_Model class loaded
INFO - 2018-10-29 18:04:24 --> Database Driver Class Initialized
INFO - 2018-10-29 18:04:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:04:24 --> Database Driver Class Initialized
INFO - 2018-10-29 18:04:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:04:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 18:04:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 18:04:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 18:04:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 18:04:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-29 18:04:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-29 18:04:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/your_job.php
INFO - 2018-10-29 18:04:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 18:04:24 --> Final output sent to browser
DEBUG - 2018-10-29 18:04:24 --> Total execution time: 0.5059
INFO - 2018-10-29 18:04:25 --> Config Class Initialized
INFO - 2018-10-29 18:04:25 --> Hooks Class Initialized
DEBUG - 2018-10-29 18:04:25 --> UTF-8 Support Enabled
INFO - 2018-10-29 18:04:25 --> Utf8 Class Initialized
INFO - 2018-10-29 18:04:25 --> URI Class Initialized
INFO - 2018-10-29 18:04:25 --> Router Class Initialized
INFO - 2018-10-29 18:04:25 --> Output Class Initialized
INFO - 2018-10-29 18:04:25 --> Security Class Initialized
DEBUG - 2018-10-29 18:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 18:04:25 --> CSRF cookie sent
INFO - 2018-10-29 18:04:25 --> CSRF token verified
INFO - 2018-10-29 18:04:25 --> Input Class Initialized
INFO - 2018-10-29 18:04:25 --> Language Class Initialized
INFO - 2018-10-29 18:04:25 --> Loader Class Initialized
INFO - 2018-10-29 18:04:25 --> Helper loaded: url_helper
INFO - 2018-10-29 18:04:25 --> Helper loaded: form_helper
INFO - 2018-10-29 18:04:25 --> Helper loaded: language_helper
DEBUG - 2018-10-29 18:04:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 18:04:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 18:04:25 --> User Agent Class Initialized
INFO - 2018-10-29 18:04:25 --> Controller Class Initialized
INFO - 2018-10-29 18:04:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 18:04:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 18:04:25 --> Helper loaded: custom_helper
INFO - 2018-10-29 18:04:25 --> Pixel_Model class loaded
INFO - 2018-10-29 18:04:25 --> Database Driver Class Initialized
INFO - 2018-10-29 18:04:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:04:25 --> Form Validation Class Initialized
INFO - 2018-10-29 18:04:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-29 18:04:25 --> Database Driver Class Initialized
INFO - 2018-10-29 18:04:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:04:25 --> Config Class Initialized
INFO - 2018-10-29 18:04:25 --> Hooks Class Initialized
DEBUG - 2018-10-29 18:04:25 --> UTF-8 Support Enabled
INFO - 2018-10-29 18:04:25 --> Utf8 Class Initialized
INFO - 2018-10-29 18:04:25 --> URI Class Initialized
INFO - 2018-10-29 18:04:25 --> Router Class Initialized
INFO - 2018-10-29 18:04:25 --> Output Class Initialized
INFO - 2018-10-29 18:04:25 --> Security Class Initialized
DEBUG - 2018-10-29 18:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 18:04:25 --> CSRF cookie sent
INFO - 2018-10-29 18:04:25 --> Input Class Initialized
INFO - 2018-10-29 18:04:25 --> Language Class Initialized
INFO - 2018-10-29 18:04:25 --> Loader Class Initialized
INFO - 2018-10-29 18:04:25 --> Helper loaded: url_helper
INFO - 2018-10-29 18:04:25 --> Helper loaded: form_helper
INFO - 2018-10-29 18:04:25 --> Helper loaded: language_helper
DEBUG - 2018-10-29 18:04:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 18:04:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 18:04:25 --> User Agent Class Initialized
INFO - 2018-10-29 18:04:25 --> Controller Class Initialized
INFO - 2018-10-29 18:04:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 18:04:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 18:04:25 --> Helper loaded: custom_helper
INFO - 2018-10-29 18:04:25 --> Pixel_Model class loaded
INFO - 2018-10-29 18:04:25 --> Database Driver Class Initialized
INFO - 2018-10-29 18:04:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:04:25 --> Database Driver Class Initialized
INFO - 2018-10-29 18:04:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:04:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 18:04:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 18:04:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner.php
INFO - 2018-10-29 18:04:25 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 18:04:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 18:04:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-29 18:04:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-29 18:04:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/relation_ship_status.php
INFO - 2018-10-29 18:04:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 18:04:26 --> Final output sent to browser
DEBUG - 2018-10-29 18:04:26 --> Total execution time: 0.5192
INFO - 2018-10-29 18:04:26 --> Config Class Initialized
INFO - 2018-10-29 18:04:26 --> Hooks Class Initialized
DEBUG - 2018-10-29 18:04:26 --> UTF-8 Support Enabled
INFO - 2018-10-29 18:04:26 --> Utf8 Class Initialized
INFO - 2018-10-29 18:04:26 --> URI Class Initialized
INFO - 2018-10-29 18:04:26 --> Router Class Initialized
INFO - 2018-10-29 18:04:26 --> Output Class Initialized
INFO - 2018-10-29 18:04:26 --> Security Class Initialized
DEBUG - 2018-10-29 18:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 18:04:26 --> CSRF cookie sent
INFO - 2018-10-29 18:04:26 --> CSRF token verified
INFO - 2018-10-29 18:04:26 --> Input Class Initialized
INFO - 2018-10-29 18:04:26 --> Language Class Initialized
INFO - 2018-10-29 18:04:26 --> Loader Class Initialized
INFO - 2018-10-29 18:04:26 --> Helper loaded: url_helper
INFO - 2018-10-29 18:04:26 --> Helper loaded: form_helper
INFO - 2018-10-29 18:04:26 --> Helper loaded: language_helper
DEBUG - 2018-10-29 18:04:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 18:04:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 18:04:26 --> User Agent Class Initialized
INFO - 2018-10-29 18:04:26 --> Controller Class Initialized
INFO - 2018-10-29 18:04:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 18:04:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 18:04:26 --> Helper loaded: custom_helper
INFO - 2018-10-29 18:04:27 --> Pixel_Model class loaded
INFO - 2018-10-29 18:04:27 --> Database Driver Class Initialized
INFO - 2018-10-29 18:04:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:04:27 --> Form Validation Class Initialized
INFO - 2018-10-29 18:04:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-29 18:04:27 --> Database Driver Class Initialized
INFO - 2018-10-29 18:04:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:04:27 --> Config Class Initialized
INFO - 2018-10-29 18:04:27 --> Hooks Class Initialized
DEBUG - 2018-10-29 18:04:27 --> UTF-8 Support Enabled
INFO - 2018-10-29 18:04:27 --> Utf8 Class Initialized
INFO - 2018-10-29 18:04:27 --> URI Class Initialized
INFO - 2018-10-29 18:04:27 --> Router Class Initialized
INFO - 2018-10-29 18:04:27 --> Output Class Initialized
INFO - 2018-10-29 18:04:27 --> Security Class Initialized
DEBUG - 2018-10-29 18:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 18:04:27 --> CSRF cookie sent
INFO - 2018-10-29 18:04:27 --> Input Class Initialized
INFO - 2018-10-29 18:04:27 --> Language Class Initialized
INFO - 2018-10-29 18:04:27 --> Loader Class Initialized
INFO - 2018-10-29 18:04:27 --> Helper loaded: url_helper
INFO - 2018-10-29 18:04:27 --> Helper loaded: form_helper
INFO - 2018-10-29 18:04:27 --> Helper loaded: language_helper
DEBUG - 2018-10-29 18:04:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 18:04:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 18:04:27 --> User Agent Class Initialized
INFO - 2018-10-29 18:04:27 --> Controller Class Initialized
INFO - 2018-10-29 18:04:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 18:04:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 18:04:27 --> Helper loaded: custom_helper
INFO - 2018-10-29 18:04:27 --> Pixel_Model class loaded
INFO - 2018-10-29 18:04:27 --> Database Driver Class Initialized
INFO - 2018-10-29 18:04:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:04:27 --> Database Driver Class Initialized
INFO - 2018-10-29 18:04:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:04:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 18:04:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 18:04:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 18:04:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 18:04:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-29 18:04:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-29 18:04:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/income.php
INFO - 2018-10-29 18:04:27 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 18:04:27 --> Final output sent to browser
DEBUG - 2018-10-29 18:04:27 --> Total execution time: 0.5054
INFO - 2018-10-29 18:06:11 --> Config Class Initialized
INFO - 2018-10-29 18:06:11 --> Hooks Class Initialized
DEBUG - 2018-10-29 18:06:11 --> UTF-8 Support Enabled
INFO - 2018-10-29 18:06:11 --> Utf8 Class Initialized
INFO - 2018-10-29 18:06:11 --> URI Class Initialized
DEBUG - 2018-10-29 18:06:11 --> No URI present. Default controller set.
INFO - 2018-10-29 18:06:11 --> Router Class Initialized
INFO - 2018-10-29 18:06:11 --> Output Class Initialized
INFO - 2018-10-29 18:06:11 --> Security Class Initialized
DEBUG - 2018-10-29 18:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 18:06:11 --> CSRF cookie sent
INFO - 2018-10-29 18:06:11 --> Input Class Initialized
INFO - 2018-10-29 18:06:11 --> Language Class Initialized
INFO - 2018-10-29 18:06:12 --> Loader Class Initialized
INFO - 2018-10-29 18:06:12 --> Helper loaded: url_helper
INFO - 2018-10-29 18:06:12 --> Helper loaded: form_helper
INFO - 2018-10-29 18:06:12 --> Helper loaded: language_helper
DEBUG - 2018-10-29 18:06:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 18:06:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 18:06:12 --> User Agent Class Initialized
INFO - 2018-10-29 18:06:12 --> Controller Class Initialized
INFO - 2018-10-29 18:06:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 18:06:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 18:06:12 --> Helper loaded: custom_helper
INFO - 2018-10-29 18:06:12 --> Pixel_Model class loaded
INFO - 2018-10-29 18:06:12 --> Database Driver Class Initialized
INFO - 2018-10-29 18:06:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:06:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 18:06:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 18:06:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-29 18:06:12 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 18:06:12 --> Final output sent to browser
DEBUG - 2018-10-29 18:06:12 --> Total execution time: 0.4548
INFO - 2018-10-29 18:06:31 --> Config Class Initialized
INFO - 2018-10-29 18:06:31 --> Hooks Class Initialized
DEBUG - 2018-10-29 18:06:31 --> UTF-8 Support Enabled
INFO - 2018-10-29 18:06:31 --> Utf8 Class Initialized
INFO - 2018-10-29 18:06:31 --> URI Class Initialized
INFO - 2018-10-29 18:06:31 --> Router Class Initialized
INFO - 2018-10-29 18:06:31 --> Output Class Initialized
INFO - 2018-10-29 18:06:31 --> Security Class Initialized
DEBUG - 2018-10-29 18:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 18:06:31 --> CSRF cookie sent
INFO - 2018-10-29 18:06:31 --> Input Class Initialized
INFO - 2018-10-29 18:06:31 --> Language Class Initialized
INFO - 2018-10-29 18:06:31 --> Loader Class Initialized
INFO - 2018-10-29 18:06:31 --> Helper loaded: url_helper
INFO - 2018-10-29 18:06:31 --> Helper loaded: form_helper
INFO - 2018-10-29 18:06:31 --> Helper loaded: language_helper
DEBUG - 2018-10-29 18:06:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 18:06:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 18:06:31 --> User Agent Class Initialized
INFO - 2018-10-29 18:06:31 --> Controller Class Initialized
INFO - 2018-10-29 18:06:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 18:06:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 18:06:31 --> Helper loaded: custom_helper
INFO - 2018-10-29 18:06:31 --> Pixel_Model class loaded
INFO - 2018-10-29 18:06:31 --> Database Driver Class Initialized
INFO - 2018-10-29 18:06:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:06:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 18:06:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 18:06:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 18:06:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 18:06:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-29 18:06:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-29 18:06:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-29 18:06:31 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 18:06:31 --> Final output sent to browser
DEBUG - 2018-10-29 18:06:31 --> Total execution time: 0.4866
INFO - 2018-10-29 18:06:41 --> Config Class Initialized
INFO - 2018-10-29 18:06:41 --> Hooks Class Initialized
DEBUG - 2018-10-29 18:06:41 --> UTF-8 Support Enabled
INFO - 2018-10-29 18:06:41 --> Utf8 Class Initialized
INFO - 2018-10-29 18:06:41 --> URI Class Initialized
INFO - 2018-10-29 18:06:41 --> Router Class Initialized
INFO - 2018-10-29 18:06:41 --> Output Class Initialized
INFO - 2018-10-29 18:06:41 --> Security Class Initialized
DEBUG - 2018-10-29 18:06:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 18:06:41 --> CSRF cookie sent
INFO - 2018-10-29 18:06:41 --> CSRF token verified
INFO - 2018-10-29 18:06:41 --> Input Class Initialized
INFO - 2018-10-29 18:06:41 --> Language Class Initialized
INFO - 2018-10-29 18:06:41 --> Loader Class Initialized
INFO - 2018-10-29 18:06:41 --> Helper loaded: url_helper
INFO - 2018-10-29 18:06:41 --> Helper loaded: form_helper
INFO - 2018-10-29 18:06:41 --> Helper loaded: language_helper
DEBUG - 2018-10-29 18:06:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 18:06:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 18:06:41 --> User Agent Class Initialized
INFO - 2018-10-29 18:06:41 --> Controller Class Initialized
INFO - 2018-10-29 18:06:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 18:06:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 18:06:41 --> Helper loaded: custom_helper
INFO - 2018-10-29 18:06:41 --> Pixel_Model class loaded
INFO - 2018-10-29 18:06:41 --> Database Driver Class Initialized
INFO - 2018-10-29 18:06:41 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:06:41 --> Database Driver Class Initialized
INFO - 2018-10-29 18:06:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:06:42 --> Config Class Initialized
INFO - 2018-10-29 18:06:42 --> Hooks Class Initialized
DEBUG - 2018-10-29 18:06:42 --> UTF-8 Support Enabled
INFO - 2018-10-29 18:06:42 --> Utf8 Class Initialized
INFO - 2018-10-29 18:06:42 --> URI Class Initialized
INFO - 2018-10-29 18:06:42 --> Router Class Initialized
INFO - 2018-10-29 18:06:42 --> Output Class Initialized
INFO - 2018-10-29 18:06:42 --> Security Class Initialized
DEBUG - 2018-10-29 18:06:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 18:06:42 --> CSRF cookie sent
INFO - 2018-10-29 18:06:42 --> Input Class Initialized
INFO - 2018-10-29 18:06:42 --> Language Class Initialized
INFO - 2018-10-29 18:06:42 --> Loader Class Initialized
INFO - 2018-10-29 18:06:42 --> Helper loaded: url_helper
INFO - 2018-10-29 18:06:42 --> Helper loaded: form_helper
INFO - 2018-10-29 18:06:42 --> Helper loaded: language_helper
DEBUG - 2018-10-29 18:06:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 18:06:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 18:06:42 --> User Agent Class Initialized
INFO - 2018-10-29 18:06:42 --> Controller Class Initialized
INFO - 2018-10-29 18:06:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 18:06:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 18:06:42 --> Helper loaded: custom_helper
INFO - 2018-10-29 18:06:42 --> Pixel_Model class loaded
INFO - 2018-10-29 18:06:42 --> Database Driver Class Initialized
INFO - 2018-10-29 18:06:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:06:42 --> Database Driver Class Initialized
INFO - 2018-10-29 18:06:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:06:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 18:06:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 18:06:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 18:06:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 18:06:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-29 18:06:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-29 18:06:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-29 18:06:42 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 18:06:42 --> Final output sent to browser
DEBUG - 2018-10-29 18:06:42 --> Total execution time: 0.5186
INFO - 2018-10-29 18:06:57 --> Config Class Initialized
INFO - 2018-10-29 18:06:57 --> Hooks Class Initialized
DEBUG - 2018-10-29 18:06:57 --> UTF-8 Support Enabled
INFO - 2018-10-29 18:06:57 --> Utf8 Class Initialized
INFO - 2018-10-29 18:06:57 --> URI Class Initialized
INFO - 2018-10-29 18:06:57 --> Router Class Initialized
INFO - 2018-10-29 18:06:58 --> Output Class Initialized
INFO - 2018-10-29 18:06:58 --> Security Class Initialized
DEBUG - 2018-10-29 18:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 18:06:58 --> CSRF cookie sent
INFO - 2018-10-29 18:06:58 --> Input Class Initialized
INFO - 2018-10-29 18:06:58 --> Language Class Initialized
INFO - 2018-10-29 18:06:58 --> Loader Class Initialized
INFO - 2018-10-29 18:06:58 --> Helper loaded: url_helper
INFO - 2018-10-29 18:06:58 --> Helper loaded: form_helper
INFO - 2018-10-29 18:06:58 --> Helper loaded: language_helper
DEBUG - 2018-10-29 18:06:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 18:06:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 18:06:58 --> User Agent Class Initialized
INFO - 2018-10-29 18:06:58 --> Controller Class Initialized
INFO - 2018-10-29 18:06:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 18:06:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 18:06:58 --> Helper loaded: custom_helper
INFO - 2018-10-29 18:06:58 --> Pixel_Model class loaded
INFO - 2018-10-29 18:06:58 --> Database Driver Class Initialized
INFO - 2018-10-29 18:06:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:06:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 18:06:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 18:06:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 18:06:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 18:06:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-29 18:06:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-29 18:06:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-29 18:06:58 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 18:06:58 --> Final output sent to browser
DEBUG - 2018-10-29 18:06:58 --> Total execution time: 0.5079
INFO - 2018-10-29 18:09:38 --> Config Class Initialized
INFO - 2018-10-29 18:09:38 --> Hooks Class Initialized
DEBUG - 2018-10-29 18:09:38 --> UTF-8 Support Enabled
INFO - 2018-10-29 18:09:38 --> Utf8 Class Initialized
INFO - 2018-10-29 18:09:38 --> URI Class Initialized
DEBUG - 2018-10-29 18:09:38 --> No URI present. Default controller set.
INFO - 2018-10-29 18:09:38 --> Router Class Initialized
INFO - 2018-10-29 18:09:39 --> Output Class Initialized
INFO - 2018-10-29 18:09:39 --> Security Class Initialized
DEBUG - 2018-10-29 18:09:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 18:09:39 --> CSRF cookie sent
INFO - 2018-10-29 18:09:39 --> Input Class Initialized
INFO - 2018-10-29 18:09:39 --> Language Class Initialized
INFO - 2018-10-29 18:09:39 --> Loader Class Initialized
INFO - 2018-10-29 18:09:39 --> Helper loaded: url_helper
INFO - 2018-10-29 18:09:39 --> Helper loaded: form_helper
INFO - 2018-10-29 18:09:39 --> Helper loaded: language_helper
DEBUG - 2018-10-29 18:09:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 18:09:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 18:09:39 --> User Agent Class Initialized
INFO - 2018-10-29 18:09:39 --> Controller Class Initialized
INFO - 2018-10-29 18:09:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 18:09:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 18:09:39 --> Helper loaded: custom_helper
INFO - 2018-10-29 18:09:39 --> Pixel_Model class loaded
INFO - 2018-10-29 18:09:39 --> Database Driver Class Initialized
INFO - 2018-10-29 18:09:39 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:09:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 18:09:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 18:09:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-29 18:09:39 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 18:09:39 --> Final output sent to browser
DEBUG - 2018-10-29 18:09:39 --> Total execution time: 0.4547
INFO - 2018-10-29 18:09:57 --> Config Class Initialized
INFO - 2018-10-29 18:09:57 --> Hooks Class Initialized
DEBUG - 2018-10-29 18:09:57 --> UTF-8 Support Enabled
INFO - 2018-10-29 18:09:57 --> Utf8 Class Initialized
INFO - 2018-10-29 18:09:57 --> URI Class Initialized
INFO - 2018-10-29 18:09:57 --> Router Class Initialized
INFO - 2018-10-29 18:09:57 --> Output Class Initialized
INFO - 2018-10-29 18:09:57 --> Security Class Initialized
DEBUG - 2018-10-29 18:09:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 18:09:57 --> CSRF cookie sent
INFO - 2018-10-29 18:09:57 --> Input Class Initialized
INFO - 2018-10-29 18:09:57 --> Language Class Initialized
ERROR - 2018-10-29 18:09:57 --> 404 Page Not Found: Assets/css
INFO - 2018-10-29 18:10:48 --> Config Class Initialized
INFO - 2018-10-29 18:10:48 --> Hooks Class Initialized
DEBUG - 2018-10-29 18:10:48 --> UTF-8 Support Enabled
INFO - 2018-10-29 18:10:48 --> Utf8 Class Initialized
INFO - 2018-10-29 18:10:48 --> URI Class Initialized
INFO - 2018-10-29 18:10:48 --> Router Class Initialized
INFO - 2018-10-29 18:10:48 --> Output Class Initialized
INFO - 2018-10-29 18:10:48 --> Security Class Initialized
DEBUG - 2018-10-29 18:10:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 18:10:48 --> CSRF cookie sent
INFO - 2018-10-29 18:10:48 --> Input Class Initialized
INFO - 2018-10-29 18:10:48 --> Language Class Initialized
INFO - 2018-10-29 18:10:48 --> Loader Class Initialized
INFO - 2018-10-29 18:10:48 --> Helper loaded: url_helper
INFO - 2018-10-29 18:10:48 --> Helper loaded: form_helper
INFO - 2018-10-29 18:10:48 --> Helper loaded: language_helper
DEBUG - 2018-10-29 18:10:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 18:10:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 18:10:48 --> User Agent Class Initialized
INFO - 2018-10-29 18:10:48 --> Controller Class Initialized
INFO - 2018-10-29 18:10:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 18:10:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 18:10:48 --> Helper loaded: custom_helper
INFO - 2018-10-29 18:10:48 --> Pixel_Model class loaded
INFO - 2018-10-29 18:10:48 --> Database Driver Class Initialized
INFO - 2018-10-29 18:10:48 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:10:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 18:10:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 18:10:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 18:10:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 18:10:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-29 18:10:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-29 18:10:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-29 18:10:48 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 18:10:48 --> Final output sent to browser
DEBUG - 2018-10-29 18:10:48 --> Total execution time: 0.4792
INFO - 2018-10-29 18:10:50 --> Config Class Initialized
INFO - 2018-10-29 18:10:50 --> Hooks Class Initialized
DEBUG - 2018-10-29 18:10:50 --> UTF-8 Support Enabled
INFO - 2018-10-29 18:10:50 --> Utf8 Class Initialized
INFO - 2018-10-29 18:10:50 --> URI Class Initialized
INFO - 2018-10-29 18:10:50 --> Router Class Initialized
INFO - 2018-10-29 18:10:50 --> Output Class Initialized
INFO - 2018-10-29 18:10:50 --> Security Class Initialized
DEBUG - 2018-10-29 18:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 18:10:50 --> CSRF cookie sent
INFO - 2018-10-29 18:10:50 --> CSRF token verified
INFO - 2018-10-29 18:10:50 --> Input Class Initialized
INFO - 2018-10-29 18:10:50 --> Language Class Initialized
INFO - 2018-10-29 18:10:50 --> Loader Class Initialized
INFO - 2018-10-29 18:10:50 --> Helper loaded: url_helper
INFO - 2018-10-29 18:10:50 --> Helper loaded: form_helper
INFO - 2018-10-29 18:10:50 --> Helper loaded: language_helper
DEBUG - 2018-10-29 18:10:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 18:10:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 18:10:50 --> User Agent Class Initialized
INFO - 2018-10-29 18:10:50 --> Controller Class Initialized
INFO - 2018-10-29 18:10:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 18:10:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 18:10:50 --> Helper loaded: custom_helper
INFO - 2018-10-29 18:10:50 --> Pixel_Model class loaded
INFO - 2018-10-29 18:10:50 --> Database Driver Class Initialized
INFO - 2018-10-29 18:10:50 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:10:50 --> Database Driver Class Initialized
INFO - 2018-10-29 18:10:50 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:10:50 --> Config Class Initialized
INFO - 2018-10-29 18:10:50 --> Hooks Class Initialized
DEBUG - 2018-10-29 18:10:50 --> UTF-8 Support Enabled
INFO - 2018-10-29 18:10:50 --> Utf8 Class Initialized
INFO - 2018-10-29 18:10:50 --> URI Class Initialized
INFO - 2018-10-29 18:10:50 --> Router Class Initialized
INFO - 2018-10-29 18:10:50 --> Output Class Initialized
INFO - 2018-10-29 18:10:50 --> Security Class Initialized
DEBUG - 2018-10-29 18:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 18:10:50 --> CSRF cookie sent
INFO - 2018-10-29 18:10:50 --> Input Class Initialized
INFO - 2018-10-29 18:10:50 --> Language Class Initialized
INFO - 2018-10-29 18:10:50 --> Loader Class Initialized
INFO - 2018-10-29 18:10:50 --> Helper loaded: url_helper
INFO - 2018-10-29 18:10:50 --> Helper loaded: form_helper
INFO - 2018-10-29 18:10:50 --> Helper loaded: language_helper
DEBUG - 2018-10-29 18:10:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 18:10:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 18:10:50 --> User Agent Class Initialized
INFO - 2018-10-29 18:10:51 --> Controller Class Initialized
INFO - 2018-10-29 18:10:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 18:10:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 18:10:51 --> Helper loaded: custom_helper
INFO - 2018-10-29 18:10:51 --> Pixel_Model class loaded
INFO - 2018-10-29 18:10:51 --> Database Driver Class Initialized
INFO - 2018-10-29 18:10:51 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:10:51 --> Database Driver Class Initialized
INFO - 2018-10-29 18:10:51 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:10:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 18:10:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 18:10:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 18:10:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 18:10:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-29 18:10:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-29 18:10:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-29 18:10:51 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 18:10:51 --> Final output sent to browser
DEBUG - 2018-10-29 18:10:51 --> Total execution time: 0.5099
INFO - 2018-10-29 18:10:54 --> Config Class Initialized
INFO - 2018-10-29 18:10:54 --> Hooks Class Initialized
DEBUG - 2018-10-29 18:10:54 --> UTF-8 Support Enabled
INFO - 2018-10-29 18:10:54 --> Utf8 Class Initialized
INFO - 2018-10-29 18:10:54 --> URI Class Initialized
INFO - 2018-10-29 18:10:54 --> Router Class Initialized
INFO - 2018-10-29 18:10:54 --> Output Class Initialized
INFO - 2018-10-29 18:10:54 --> Security Class Initialized
DEBUG - 2018-10-29 18:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 18:10:54 --> CSRF cookie sent
INFO - 2018-10-29 18:10:54 --> CSRF token verified
INFO - 2018-10-29 18:10:54 --> Input Class Initialized
INFO - 2018-10-29 18:10:54 --> Language Class Initialized
INFO - 2018-10-29 18:10:54 --> Loader Class Initialized
INFO - 2018-10-29 18:10:54 --> Helper loaded: url_helper
INFO - 2018-10-29 18:10:54 --> Helper loaded: form_helper
INFO - 2018-10-29 18:10:54 --> Helper loaded: language_helper
DEBUG - 2018-10-29 18:10:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 18:10:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 18:10:54 --> User Agent Class Initialized
INFO - 2018-10-29 18:10:54 --> Controller Class Initialized
INFO - 2018-10-29 18:10:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 18:10:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 18:10:54 --> Helper loaded: custom_helper
INFO - 2018-10-29 18:10:54 --> Pixel_Model class loaded
INFO - 2018-10-29 18:10:55 --> Database Driver Class Initialized
INFO - 2018-10-29 18:10:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:10:55 --> Form Validation Class Initialized
INFO - 2018-10-29 18:10:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-29 18:10:55 --> Database Driver Class Initialized
INFO - 2018-10-29 18:10:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:10:55 --> Config Class Initialized
INFO - 2018-10-29 18:10:55 --> Hooks Class Initialized
DEBUG - 2018-10-29 18:10:55 --> UTF-8 Support Enabled
INFO - 2018-10-29 18:10:55 --> Utf8 Class Initialized
INFO - 2018-10-29 18:10:55 --> URI Class Initialized
INFO - 2018-10-29 18:10:55 --> Router Class Initialized
INFO - 2018-10-29 18:10:55 --> Output Class Initialized
INFO - 2018-10-29 18:10:55 --> Security Class Initialized
DEBUG - 2018-10-29 18:10:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 18:10:55 --> CSRF cookie sent
INFO - 2018-10-29 18:10:55 --> Input Class Initialized
INFO - 2018-10-29 18:10:55 --> Language Class Initialized
INFO - 2018-10-29 18:10:55 --> Loader Class Initialized
INFO - 2018-10-29 18:10:55 --> Helper loaded: url_helper
INFO - 2018-10-29 18:10:55 --> Helper loaded: form_helper
INFO - 2018-10-29 18:10:55 --> Helper loaded: language_helper
DEBUG - 2018-10-29 18:10:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 18:10:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 18:10:55 --> User Agent Class Initialized
INFO - 2018-10-29 18:10:55 --> Controller Class Initialized
INFO - 2018-10-29 18:10:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 18:10:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 18:10:55 --> Helper loaded: custom_helper
INFO - 2018-10-29 18:10:55 --> Pixel_Model class loaded
INFO - 2018-10-29 18:10:55 --> Database Driver Class Initialized
INFO - 2018-10-29 18:10:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:10:55 --> Database Driver Class Initialized
INFO - 2018-10-29 18:10:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:10:55 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 18:10:55 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 18:10:55 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 18:10:55 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 18:10:55 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-29 18:10:55 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-29 18:10:55 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/your_job.php
INFO - 2018-10-29 18:10:55 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 18:10:55 --> Final output sent to browser
DEBUG - 2018-10-29 18:10:55 --> Total execution time: 0.5324
INFO - 2018-10-29 18:10:58 --> Config Class Initialized
INFO - 2018-10-29 18:10:58 --> Hooks Class Initialized
DEBUG - 2018-10-29 18:10:58 --> UTF-8 Support Enabled
INFO - 2018-10-29 18:10:58 --> Utf8 Class Initialized
INFO - 2018-10-29 18:10:58 --> URI Class Initialized
INFO - 2018-10-29 18:10:58 --> Router Class Initialized
INFO - 2018-10-29 18:10:58 --> Output Class Initialized
INFO - 2018-10-29 18:10:58 --> Security Class Initialized
DEBUG - 2018-10-29 18:10:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 18:10:58 --> CSRF cookie sent
INFO - 2018-10-29 18:10:58 --> CSRF token verified
INFO - 2018-10-29 18:10:58 --> Input Class Initialized
INFO - 2018-10-29 18:10:58 --> Language Class Initialized
INFO - 2018-10-29 18:10:58 --> Loader Class Initialized
INFO - 2018-10-29 18:10:58 --> Helper loaded: url_helper
INFO - 2018-10-29 18:10:58 --> Helper loaded: form_helper
INFO - 2018-10-29 18:10:58 --> Helper loaded: language_helper
DEBUG - 2018-10-29 18:10:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 18:10:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 18:10:58 --> User Agent Class Initialized
INFO - 2018-10-29 18:10:58 --> Controller Class Initialized
INFO - 2018-10-29 18:10:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 18:10:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 18:10:58 --> Helper loaded: custom_helper
INFO - 2018-10-29 18:10:58 --> Pixel_Model class loaded
INFO - 2018-10-29 18:10:58 --> Database Driver Class Initialized
INFO - 2018-10-29 18:10:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:10:58 --> Form Validation Class Initialized
INFO - 2018-10-29 18:10:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-29 18:10:58 --> Database Driver Class Initialized
INFO - 2018-10-29 18:10:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:10:58 --> Config Class Initialized
INFO - 2018-10-29 18:10:58 --> Hooks Class Initialized
DEBUG - 2018-10-29 18:10:58 --> UTF-8 Support Enabled
INFO - 2018-10-29 18:10:58 --> Utf8 Class Initialized
INFO - 2018-10-29 18:10:58 --> URI Class Initialized
INFO - 2018-10-29 18:10:58 --> Router Class Initialized
INFO - 2018-10-29 18:10:58 --> Output Class Initialized
INFO - 2018-10-29 18:10:58 --> Security Class Initialized
DEBUG - 2018-10-29 18:10:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 18:10:58 --> CSRF cookie sent
INFO - 2018-10-29 18:10:58 --> Input Class Initialized
INFO - 2018-10-29 18:10:58 --> Language Class Initialized
INFO - 2018-10-29 18:10:58 --> Loader Class Initialized
INFO - 2018-10-29 18:10:58 --> Helper loaded: url_helper
INFO - 2018-10-29 18:10:58 --> Helper loaded: form_helper
INFO - 2018-10-29 18:10:58 --> Helper loaded: language_helper
DEBUG - 2018-10-29 18:10:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 18:10:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 18:10:58 --> User Agent Class Initialized
INFO - 2018-10-29 18:10:58 --> Controller Class Initialized
INFO - 2018-10-29 18:10:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 18:10:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 18:10:59 --> Helper loaded: custom_helper
INFO - 2018-10-29 18:10:59 --> Pixel_Model class loaded
INFO - 2018-10-29 18:10:59 --> Database Driver Class Initialized
INFO - 2018-10-29 18:10:59 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:10:59 --> Database Driver Class Initialized
INFO - 2018-10-29 18:10:59 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:10:59 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 18:10:59 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 18:10:59 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner.php
INFO - 2018-10-29 18:10:59 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 18:10:59 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 18:10:59 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-29 18:10:59 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-29 18:10:59 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/relation_ship_status.php
INFO - 2018-10-29 18:10:59 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 18:10:59 --> Final output sent to browser
DEBUG - 2018-10-29 18:10:59 --> Total execution time: 0.5390
INFO - 2018-10-29 18:11:01 --> Config Class Initialized
INFO - 2018-10-29 18:11:01 --> Hooks Class Initialized
DEBUG - 2018-10-29 18:11:01 --> UTF-8 Support Enabled
INFO - 2018-10-29 18:11:01 --> Utf8 Class Initialized
INFO - 2018-10-29 18:11:01 --> URI Class Initialized
INFO - 2018-10-29 18:11:01 --> Router Class Initialized
INFO - 2018-10-29 18:11:01 --> Output Class Initialized
INFO - 2018-10-29 18:11:01 --> Security Class Initialized
DEBUG - 2018-10-29 18:11:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 18:11:01 --> CSRF cookie sent
INFO - 2018-10-29 18:11:01 --> CSRF token verified
INFO - 2018-10-29 18:11:01 --> Input Class Initialized
INFO - 2018-10-29 18:11:01 --> Language Class Initialized
INFO - 2018-10-29 18:11:01 --> Loader Class Initialized
INFO - 2018-10-29 18:11:01 --> Helper loaded: url_helper
INFO - 2018-10-29 18:11:01 --> Helper loaded: form_helper
INFO - 2018-10-29 18:11:01 --> Helper loaded: language_helper
DEBUG - 2018-10-29 18:11:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 18:11:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 18:11:01 --> User Agent Class Initialized
INFO - 2018-10-29 18:11:01 --> Controller Class Initialized
INFO - 2018-10-29 18:11:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 18:11:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 18:11:01 --> Helper loaded: custom_helper
INFO - 2018-10-29 18:11:01 --> Pixel_Model class loaded
INFO - 2018-10-29 18:11:01 --> Database Driver Class Initialized
INFO - 2018-10-29 18:11:01 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:11:01 --> Form Validation Class Initialized
INFO - 2018-10-29 18:11:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-29 18:11:01 --> Database Driver Class Initialized
INFO - 2018-10-29 18:11:01 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:11:01 --> Config Class Initialized
INFO - 2018-10-29 18:11:01 --> Hooks Class Initialized
DEBUG - 2018-10-29 18:11:01 --> UTF-8 Support Enabled
INFO - 2018-10-29 18:11:01 --> Utf8 Class Initialized
INFO - 2018-10-29 18:11:01 --> URI Class Initialized
INFO - 2018-10-29 18:11:01 --> Router Class Initialized
INFO - 2018-10-29 18:11:02 --> Output Class Initialized
INFO - 2018-10-29 18:11:02 --> Security Class Initialized
DEBUG - 2018-10-29 18:11:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 18:11:02 --> CSRF cookie sent
INFO - 2018-10-29 18:11:02 --> Input Class Initialized
INFO - 2018-10-29 18:11:02 --> Language Class Initialized
INFO - 2018-10-29 18:11:02 --> Loader Class Initialized
INFO - 2018-10-29 18:11:02 --> Helper loaded: url_helper
INFO - 2018-10-29 18:11:02 --> Helper loaded: form_helper
INFO - 2018-10-29 18:11:02 --> Helper loaded: language_helper
DEBUG - 2018-10-29 18:11:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 18:11:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 18:11:02 --> User Agent Class Initialized
INFO - 2018-10-29 18:11:02 --> Controller Class Initialized
INFO - 2018-10-29 18:11:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 18:11:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 18:11:02 --> Helper loaded: custom_helper
INFO - 2018-10-29 18:11:02 --> Pixel_Model class loaded
INFO - 2018-10-29 18:11:02 --> Database Driver Class Initialized
INFO - 2018-10-29 18:11:02 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:11:02 --> Database Driver Class Initialized
INFO - 2018-10-29 18:11:02 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:11:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 18:11:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 18:11:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 18:11:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 18:11:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-29 18:11:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-29 18:11:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/income.php
INFO - 2018-10-29 18:11:02 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 18:11:02 --> Final output sent to browser
DEBUG - 2018-10-29 18:11:02 --> Total execution time: 0.5369
INFO - 2018-10-29 18:11:05 --> Config Class Initialized
INFO - 2018-10-29 18:11:05 --> Hooks Class Initialized
DEBUG - 2018-10-29 18:11:05 --> UTF-8 Support Enabled
INFO - 2018-10-29 18:11:05 --> Utf8 Class Initialized
INFO - 2018-10-29 18:11:05 --> URI Class Initialized
INFO - 2018-10-29 18:11:05 --> Router Class Initialized
INFO - 2018-10-29 18:11:05 --> Output Class Initialized
INFO - 2018-10-29 18:11:05 --> Security Class Initialized
DEBUG - 2018-10-29 18:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 18:11:05 --> CSRF cookie sent
INFO - 2018-10-29 18:11:05 --> CSRF token verified
INFO - 2018-10-29 18:11:05 --> Input Class Initialized
INFO - 2018-10-29 18:11:05 --> Language Class Initialized
INFO - 2018-10-29 18:11:05 --> Loader Class Initialized
INFO - 2018-10-29 18:11:05 --> Helper loaded: url_helper
INFO - 2018-10-29 18:11:05 --> Helper loaded: form_helper
INFO - 2018-10-29 18:11:05 --> Helper loaded: language_helper
DEBUG - 2018-10-29 18:11:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 18:11:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 18:11:05 --> User Agent Class Initialized
INFO - 2018-10-29 18:11:05 --> Controller Class Initialized
INFO - 2018-10-29 18:11:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 18:11:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 18:11:05 --> Helper loaded: custom_helper
INFO - 2018-10-29 18:11:05 --> Pixel_Model class loaded
INFO - 2018-10-29 18:11:05 --> Database Driver Class Initialized
INFO - 2018-10-29 18:11:05 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:11:05 --> Form Validation Class Initialized
INFO - 2018-10-29 18:11:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-29 18:11:06 --> Database Driver Class Initialized
INFO - 2018-10-29 18:11:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:11:06 --> Config Class Initialized
INFO - 2018-10-29 18:11:06 --> Hooks Class Initialized
DEBUG - 2018-10-29 18:11:06 --> UTF-8 Support Enabled
INFO - 2018-10-29 18:11:06 --> Utf8 Class Initialized
INFO - 2018-10-29 18:11:06 --> URI Class Initialized
INFO - 2018-10-29 18:11:06 --> Router Class Initialized
INFO - 2018-10-29 18:11:06 --> Output Class Initialized
INFO - 2018-10-29 18:11:06 --> Security Class Initialized
DEBUG - 2018-10-29 18:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 18:11:06 --> CSRF cookie sent
INFO - 2018-10-29 18:11:06 --> Input Class Initialized
INFO - 2018-10-29 18:11:06 --> Language Class Initialized
INFO - 2018-10-29 18:11:06 --> Loader Class Initialized
INFO - 2018-10-29 18:11:06 --> Helper loaded: url_helper
INFO - 2018-10-29 18:11:06 --> Helper loaded: form_helper
INFO - 2018-10-29 18:11:06 --> Helper loaded: language_helper
DEBUG - 2018-10-29 18:11:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 18:11:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 18:11:06 --> User Agent Class Initialized
INFO - 2018-10-29 18:11:06 --> Controller Class Initialized
INFO - 2018-10-29 18:11:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 18:11:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 18:11:06 --> Helper loaded: custom_helper
INFO - 2018-10-29 18:11:06 --> Pixel_Model class loaded
INFO - 2018-10-29 18:11:06 --> Database Driver Class Initialized
INFO - 2018-10-29 18:11:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:11:06 --> Database Driver Class Initialized
INFO - 2018-10-29 18:11:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:11:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 18:11:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 18:11:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 18:11:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 18:11:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-29 18:11:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-29 18:11:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/marriage.php
INFO - 2018-10-29 18:11:06 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 18:11:06 --> Final output sent to browser
DEBUG - 2018-10-29 18:11:06 --> Total execution time: 0.5231
INFO - 2018-10-29 18:11:07 --> Config Class Initialized
INFO - 2018-10-29 18:11:07 --> Hooks Class Initialized
DEBUG - 2018-10-29 18:11:07 --> UTF-8 Support Enabled
INFO - 2018-10-29 18:11:07 --> Utf8 Class Initialized
INFO - 2018-10-29 18:11:07 --> URI Class Initialized
INFO - 2018-10-29 18:11:08 --> Router Class Initialized
INFO - 2018-10-29 18:11:08 --> Output Class Initialized
INFO - 2018-10-29 18:11:08 --> Security Class Initialized
DEBUG - 2018-10-29 18:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 18:11:08 --> CSRF cookie sent
INFO - 2018-10-29 18:11:08 --> Input Class Initialized
INFO - 2018-10-29 18:11:08 --> Language Class Initialized
INFO - 2018-10-29 18:11:08 --> Loader Class Initialized
INFO - 2018-10-29 18:11:08 --> Helper loaded: url_helper
INFO - 2018-10-29 18:11:08 --> Helper loaded: form_helper
INFO - 2018-10-29 18:11:08 --> Helper loaded: language_helper
DEBUG - 2018-10-29 18:11:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 18:11:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 18:11:08 --> User Agent Class Initialized
INFO - 2018-10-29 18:11:08 --> Controller Class Initialized
INFO - 2018-10-29 18:11:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 18:11:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 18:11:08 --> Helper loaded: custom_helper
INFO - 2018-10-29 18:11:08 --> Pixel_Model class loaded
INFO - 2018-10-29 18:11:08 --> Database Driver Class Initialized
INFO - 2018-10-29 18:11:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:11:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 18:11:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 18:11:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 18:11:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 18:11:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-29 18:11:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-29 18:11:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/start_questions.php
INFO - 2018-10-29 18:11:08 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 18:11:08 --> Final output sent to browser
DEBUG - 2018-10-29 18:11:08 --> Total execution time: 0.5181
INFO - 2018-10-29 18:11:10 --> Config Class Initialized
INFO - 2018-10-29 18:11:10 --> Hooks Class Initialized
DEBUG - 2018-10-29 18:11:10 --> UTF-8 Support Enabled
INFO - 2018-10-29 18:11:10 --> Utf8 Class Initialized
INFO - 2018-10-29 18:11:10 --> URI Class Initialized
INFO - 2018-10-29 18:11:10 --> Router Class Initialized
INFO - 2018-10-29 18:11:10 --> Output Class Initialized
INFO - 2018-10-29 18:11:11 --> Security Class Initialized
DEBUG - 2018-10-29 18:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 18:11:11 --> CSRF cookie sent
INFO - 2018-10-29 18:11:11 --> CSRF token verified
INFO - 2018-10-29 18:11:11 --> Input Class Initialized
INFO - 2018-10-29 18:11:11 --> Language Class Initialized
INFO - 2018-10-29 18:11:11 --> Loader Class Initialized
INFO - 2018-10-29 18:11:11 --> Helper loaded: url_helper
INFO - 2018-10-29 18:11:11 --> Helper loaded: form_helper
INFO - 2018-10-29 18:11:11 --> Helper loaded: language_helper
DEBUG - 2018-10-29 18:11:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 18:11:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 18:11:11 --> User Agent Class Initialized
INFO - 2018-10-29 18:11:11 --> Controller Class Initialized
INFO - 2018-10-29 18:11:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 18:11:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 18:11:11 --> Helper loaded: custom_helper
INFO - 2018-10-29 18:11:11 --> Pixel_Model class loaded
INFO - 2018-10-29 18:11:11 --> Database Driver Class Initialized
INFO - 2018-10-29 18:11:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:11:11 --> Database Driver Class Initialized
INFO - 2018-10-29 18:11:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:11:11 --> Config Class Initialized
INFO - 2018-10-29 18:11:11 --> Hooks Class Initialized
DEBUG - 2018-10-29 18:11:11 --> UTF-8 Support Enabled
INFO - 2018-10-29 18:11:11 --> Utf8 Class Initialized
INFO - 2018-10-29 18:11:11 --> URI Class Initialized
INFO - 2018-10-29 18:11:11 --> Router Class Initialized
INFO - 2018-10-29 18:11:11 --> Output Class Initialized
INFO - 2018-10-29 18:11:11 --> Security Class Initialized
DEBUG - 2018-10-29 18:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 18:11:11 --> CSRF cookie sent
INFO - 2018-10-29 18:11:11 --> Input Class Initialized
INFO - 2018-10-29 18:11:11 --> Language Class Initialized
INFO - 2018-10-29 18:11:11 --> Loader Class Initialized
INFO - 2018-10-29 18:11:11 --> Helper loaded: url_helper
INFO - 2018-10-29 18:11:11 --> Helper loaded: form_helper
INFO - 2018-10-29 18:11:11 --> Helper loaded: language_helper
DEBUG - 2018-10-29 18:11:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 18:11:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 18:11:11 --> User Agent Class Initialized
INFO - 2018-10-29 18:11:11 --> Controller Class Initialized
INFO - 2018-10-29 18:11:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 18:11:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 18:11:11 --> Helper loaded: custom_helper
INFO - 2018-10-29 18:11:11 --> Pixel_Model class loaded
INFO - 2018-10-29 18:11:11 --> Database Driver Class Initialized
INFO - 2018-10-29 18:11:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:11:11 --> Database Driver Class Initialized
INFO - 2018-10-29 18:11:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:11:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 18:11:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 18:11:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 18:11:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 18:11:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-29 18:11:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-29 18:11:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/people_confide.php
INFO - 2018-10-29 18:11:11 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 18:11:11 --> Final output sent to browser
DEBUG - 2018-10-29 18:11:11 --> Total execution time: 0.5329
INFO - 2018-10-29 18:11:14 --> Config Class Initialized
INFO - 2018-10-29 18:11:14 --> Hooks Class Initialized
DEBUG - 2018-10-29 18:11:14 --> UTF-8 Support Enabled
INFO - 2018-10-29 18:11:14 --> Utf8 Class Initialized
INFO - 2018-10-29 18:11:14 --> URI Class Initialized
INFO - 2018-10-29 18:11:14 --> Router Class Initialized
INFO - 2018-10-29 18:11:14 --> Output Class Initialized
INFO - 2018-10-29 18:11:14 --> Security Class Initialized
DEBUG - 2018-10-29 18:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 18:11:14 --> CSRF cookie sent
INFO - 2018-10-29 18:11:14 --> CSRF token verified
INFO - 2018-10-29 18:11:14 --> Input Class Initialized
INFO - 2018-10-29 18:11:14 --> Language Class Initialized
INFO - 2018-10-29 18:11:14 --> Loader Class Initialized
INFO - 2018-10-29 18:11:14 --> Helper loaded: url_helper
INFO - 2018-10-29 18:11:14 --> Helper loaded: form_helper
INFO - 2018-10-29 18:11:14 --> Helper loaded: language_helper
DEBUG - 2018-10-29 18:11:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 18:11:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 18:11:14 --> User Agent Class Initialized
INFO - 2018-10-29 18:11:14 --> Controller Class Initialized
INFO - 2018-10-29 18:11:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 18:11:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 18:11:14 --> Helper loaded: custom_helper
INFO - 2018-10-29 18:11:14 --> Pixel_Model class loaded
INFO - 2018-10-29 18:11:14 --> Database Driver Class Initialized
INFO - 2018-10-29 18:11:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:11:14 --> Form Validation Class Initialized
INFO - 2018-10-29 18:11:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-29 18:11:14 --> Database Driver Class Initialized
INFO - 2018-10-29 18:11:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:11:14 --> Config Class Initialized
INFO - 2018-10-29 18:11:14 --> Hooks Class Initialized
DEBUG - 2018-10-29 18:11:14 --> UTF-8 Support Enabled
INFO - 2018-10-29 18:11:14 --> Utf8 Class Initialized
INFO - 2018-10-29 18:11:15 --> URI Class Initialized
INFO - 2018-10-29 18:11:15 --> Router Class Initialized
INFO - 2018-10-29 18:11:15 --> Output Class Initialized
INFO - 2018-10-29 18:11:15 --> Security Class Initialized
DEBUG - 2018-10-29 18:11:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 18:11:15 --> CSRF cookie sent
INFO - 2018-10-29 18:11:15 --> Input Class Initialized
INFO - 2018-10-29 18:11:15 --> Language Class Initialized
INFO - 2018-10-29 18:11:15 --> Loader Class Initialized
INFO - 2018-10-29 18:11:15 --> Helper loaded: url_helper
INFO - 2018-10-29 18:11:15 --> Helper loaded: form_helper
INFO - 2018-10-29 18:11:15 --> Helper loaded: language_helper
DEBUG - 2018-10-29 18:11:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 18:11:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 18:11:15 --> User Agent Class Initialized
INFO - 2018-10-29 18:11:15 --> Controller Class Initialized
INFO - 2018-10-29 18:11:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 18:11:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 18:11:15 --> Helper loaded: custom_helper
INFO - 2018-10-29 18:11:15 --> Pixel_Model class loaded
INFO - 2018-10-29 18:11:15 --> Database Driver Class Initialized
INFO - 2018-10-29 18:11:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:11:15 --> Database Driver Class Initialized
INFO - 2018-10-29 18:11:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:11:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 18:11:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 18:11:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 18:11:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 18:11:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-29 18:11:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-29 18:11:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/your_job.php
INFO - 2018-10-29 18:11:15 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 18:11:15 --> Final output sent to browser
DEBUG - 2018-10-29 18:11:15 --> Total execution time: 0.5463
INFO - 2018-10-29 18:11:17 --> Config Class Initialized
INFO - 2018-10-29 18:11:17 --> Hooks Class Initialized
DEBUG - 2018-10-29 18:11:18 --> UTF-8 Support Enabled
INFO - 2018-10-29 18:11:18 --> Utf8 Class Initialized
INFO - 2018-10-29 18:11:18 --> URI Class Initialized
INFO - 2018-10-29 18:11:18 --> Router Class Initialized
INFO - 2018-10-29 18:11:18 --> Output Class Initialized
INFO - 2018-10-29 18:11:18 --> Security Class Initialized
DEBUG - 2018-10-29 18:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 18:11:18 --> CSRF cookie sent
INFO - 2018-10-29 18:11:18 --> CSRF token verified
INFO - 2018-10-29 18:11:18 --> Input Class Initialized
INFO - 2018-10-29 18:11:18 --> Language Class Initialized
INFO - 2018-10-29 18:11:18 --> Loader Class Initialized
INFO - 2018-10-29 18:11:18 --> Helper loaded: url_helper
INFO - 2018-10-29 18:11:18 --> Helper loaded: form_helper
INFO - 2018-10-29 18:11:18 --> Helper loaded: language_helper
DEBUG - 2018-10-29 18:11:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 18:11:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 18:11:18 --> User Agent Class Initialized
INFO - 2018-10-29 18:11:18 --> Controller Class Initialized
INFO - 2018-10-29 18:11:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 18:11:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 18:11:18 --> Helper loaded: custom_helper
INFO - 2018-10-29 18:11:18 --> Pixel_Model class loaded
INFO - 2018-10-29 18:11:18 --> Database Driver Class Initialized
INFO - 2018-10-29 18:11:18 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:11:18 --> Form Validation Class Initialized
INFO - 2018-10-29 18:11:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-29 18:11:18 --> Database Driver Class Initialized
INFO - 2018-10-29 18:11:18 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:11:18 --> Config Class Initialized
INFO - 2018-10-29 18:11:18 --> Hooks Class Initialized
DEBUG - 2018-10-29 18:11:18 --> UTF-8 Support Enabled
INFO - 2018-10-29 18:11:18 --> Utf8 Class Initialized
INFO - 2018-10-29 18:11:18 --> URI Class Initialized
INFO - 2018-10-29 18:11:18 --> Router Class Initialized
INFO - 2018-10-29 18:11:18 --> Output Class Initialized
INFO - 2018-10-29 18:11:18 --> Security Class Initialized
DEBUG - 2018-10-29 18:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 18:11:18 --> CSRF cookie sent
INFO - 2018-10-29 18:11:18 --> Input Class Initialized
INFO - 2018-10-29 18:11:18 --> Language Class Initialized
INFO - 2018-10-29 18:11:18 --> Loader Class Initialized
INFO - 2018-10-29 18:11:18 --> Helper loaded: url_helper
INFO - 2018-10-29 18:11:18 --> Helper loaded: form_helper
INFO - 2018-10-29 18:11:18 --> Helper loaded: language_helper
DEBUG - 2018-10-29 18:11:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 18:11:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 18:11:18 --> User Agent Class Initialized
INFO - 2018-10-29 18:11:18 --> Controller Class Initialized
INFO - 2018-10-29 18:11:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 18:11:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 18:11:18 --> Helper loaded: custom_helper
INFO - 2018-10-29 18:11:18 --> Pixel_Model class loaded
INFO - 2018-10-29 18:11:18 --> Database Driver Class Initialized
INFO - 2018-10-29 18:11:18 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:11:19 --> Database Driver Class Initialized
INFO - 2018-10-29 18:11:19 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:11:19 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 18:11:19 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 18:11:19 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner.php
INFO - 2018-10-29 18:11:19 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 18:11:19 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 18:11:19 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-29 18:11:19 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-29 18:11:19 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/relation_ship_status.php
INFO - 2018-10-29 18:11:19 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 18:11:19 --> Final output sent to browser
DEBUG - 2018-10-29 18:11:19 --> Total execution time: 0.5647
INFO - 2018-10-29 18:11:23 --> Config Class Initialized
INFO - 2018-10-29 18:11:23 --> Hooks Class Initialized
DEBUG - 2018-10-29 18:11:23 --> UTF-8 Support Enabled
INFO - 2018-10-29 18:11:23 --> Utf8 Class Initialized
INFO - 2018-10-29 18:11:23 --> URI Class Initialized
INFO - 2018-10-29 18:11:23 --> Router Class Initialized
INFO - 2018-10-29 18:11:23 --> Output Class Initialized
INFO - 2018-10-29 18:11:23 --> Security Class Initialized
DEBUG - 2018-10-29 18:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 18:11:23 --> CSRF cookie sent
INFO - 2018-10-29 18:11:23 --> CSRF token verified
INFO - 2018-10-29 18:11:23 --> Input Class Initialized
INFO - 2018-10-29 18:11:23 --> Language Class Initialized
INFO - 2018-10-29 18:11:23 --> Loader Class Initialized
INFO - 2018-10-29 18:11:23 --> Helper loaded: url_helper
INFO - 2018-10-29 18:11:23 --> Helper loaded: form_helper
INFO - 2018-10-29 18:11:23 --> Helper loaded: language_helper
DEBUG - 2018-10-29 18:11:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 18:11:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 18:11:23 --> User Agent Class Initialized
INFO - 2018-10-29 18:11:23 --> Controller Class Initialized
INFO - 2018-10-29 18:11:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 18:11:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 18:11:23 --> Helper loaded: custom_helper
INFO - 2018-10-29 18:11:23 --> Pixel_Model class loaded
INFO - 2018-10-29 18:11:23 --> Database Driver Class Initialized
INFO - 2018-10-29 18:11:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:11:23 --> Form Validation Class Initialized
INFO - 2018-10-29 18:11:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-29 18:11:23 --> Database Driver Class Initialized
INFO - 2018-10-29 18:11:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:11:23 --> Config Class Initialized
INFO - 2018-10-29 18:11:23 --> Hooks Class Initialized
DEBUG - 2018-10-29 18:11:23 --> UTF-8 Support Enabled
INFO - 2018-10-29 18:11:23 --> Utf8 Class Initialized
INFO - 2018-10-29 18:11:23 --> URI Class Initialized
INFO - 2018-10-29 18:11:23 --> Router Class Initialized
INFO - 2018-10-29 18:11:23 --> Output Class Initialized
INFO - 2018-10-29 18:11:23 --> Security Class Initialized
DEBUG - 2018-10-29 18:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 18:11:23 --> CSRF cookie sent
INFO - 2018-10-29 18:11:23 --> Input Class Initialized
INFO - 2018-10-29 18:11:23 --> Language Class Initialized
INFO - 2018-10-29 18:11:23 --> Loader Class Initialized
INFO - 2018-10-29 18:11:23 --> Helper loaded: url_helper
INFO - 2018-10-29 18:11:23 --> Helper loaded: form_helper
INFO - 2018-10-29 18:11:23 --> Helper loaded: language_helper
DEBUG - 2018-10-29 18:11:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 18:11:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 18:11:24 --> User Agent Class Initialized
INFO - 2018-10-29 18:11:24 --> Controller Class Initialized
INFO - 2018-10-29 18:11:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 18:11:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 18:11:24 --> Helper loaded: custom_helper
INFO - 2018-10-29 18:11:24 --> Pixel_Model class loaded
INFO - 2018-10-29 18:11:24 --> Database Driver Class Initialized
INFO - 2018-10-29 18:11:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:11:24 --> Database Driver Class Initialized
INFO - 2018-10-29 18:11:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:11:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 18:11:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 18:11:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_banner_empty.php
INFO - 2018-10-29 18:11:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_page_header.php
INFO - 2018-10-29 18:11:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_bar.php
INFO - 2018-10-29 18:11:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_buttons.php
INFO - 2018-10-29 18:11:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\questions/income.php
INFO - 2018-10-29 18:11:24 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 18:11:24 --> Final output sent to browser
DEBUG - 2018-10-29 18:11:24 --> Total execution time: 0.5402
INFO - 2018-10-29 18:14:56 --> Config Class Initialized
INFO - 2018-10-29 18:14:56 --> Hooks Class Initialized
DEBUG - 2018-10-29 18:14:56 --> UTF-8 Support Enabled
INFO - 2018-10-29 18:14:56 --> Utf8 Class Initialized
INFO - 2018-10-29 18:14:56 --> URI Class Initialized
DEBUG - 2018-10-29 18:14:56 --> No URI present. Default controller set.
INFO - 2018-10-29 18:14:56 --> Router Class Initialized
INFO - 2018-10-29 18:14:56 --> Output Class Initialized
INFO - 2018-10-29 18:14:56 --> Security Class Initialized
DEBUG - 2018-10-29 18:14:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 18:14:56 --> CSRF cookie sent
INFO - 2018-10-29 18:14:56 --> Input Class Initialized
INFO - 2018-10-29 18:14:56 --> Language Class Initialized
INFO - 2018-10-29 18:14:56 --> Loader Class Initialized
INFO - 2018-10-29 18:14:56 --> Helper loaded: url_helper
INFO - 2018-10-29 18:14:56 --> Helper loaded: form_helper
INFO - 2018-10-29 18:14:56 --> Helper loaded: language_helper
DEBUG - 2018-10-29 18:14:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 18:14:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 18:14:56 --> User Agent Class Initialized
INFO - 2018-10-29 18:14:56 --> Controller Class Initialized
INFO - 2018-10-29 18:14:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-29 18:14:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-29 18:14:56 --> Helper loaded: custom_helper
INFO - 2018-10-29 18:14:56 --> Pixel_Model class loaded
INFO - 2018-10-29 18:14:56 --> Database Driver Class Initialized
INFO - 2018-10-29 18:14:56 --> Model "QuestionsModel" initialized
INFO - 2018-10-29 18:14:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-29 18:14:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-29 18:14:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-29 18:14:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-29 18:14:57 --> Final output sent to browser
DEBUG - 2018-10-29 18:14:57 --> Total execution time: 1.0357

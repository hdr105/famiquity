<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-10-31 17:20:23 --> Config Class Initialized
INFO - 2018-10-31 17:20:23 --> Hooks Class Initialized
DEBUG - 2018-10-31 17:20:23 --> UTF-8 Support Enabled
INFO - 2018-10-31 17:20:24 --> Utf8 Class Initialized
INFO - 2018-10-31 17:20:24 --> URI Class Initialized
INFO - 2018-10-31 17:20:24 --> Router Class Initialized
INFO - 2018-10-31 17:20:24 --> Output Class Initialized
INFO - 2018-10-31 17:20:24 --> Security Class Initialized
DEBUG - 2018-10-31 17:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-31 17:20:24 --> CSRF cookie sent
INFO - 2018-10-31 17:20:24 --> Input Class Initialized
INFO - 2018-10-31 17:20:24 --> Language Class Initialized
INFO - 2018-10-31 17:20:24 --> Loader Class Initialized
INFO - 2018-10-31 17:20:24 --> Helper loaded: url_helper
INFO - 2018-10-31 17:20:24 --> Helper loaded: form_helper
INFO - 2018-10-31 17:20:24 --> Helper loaded: language_helper
DEBUG - 2018-10-31 17:20:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-31 17:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-31 17:20:24 --> User Agent Class Initialized
INFO - 2018-10-31 17:20:24 --> Controller Class Initialized
INFO - 2018-10-31 17:20:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-31 17:20:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-31 17:20:24 --> Helper loaded: custom_helper
INFO - 2018-10-31 17:20:36 --> Config Class Initialized
INFO - 2018-10-31 17:20:37 --> Hooks Class Initialized
DEBUG - 2018-10-31 17:20:37 --> UTF-8 Support Enabled
INFO - 2018-10-31 17:20:37 --> Utf8 Class Initialized
INFO - 2018-10-31 17:20:37 --> URI Class Initialized
INFO - 2018-10-31 17:20:37 --> Router Class Initialized
INFO - 2018-10-31 17:20:37 --> Output Class Initialized
INFO - 2018-10-31 17:20:37 --> Security Class Initialized
DEBUG - 2018-10-31 17:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-31 17:20:37 --> CSRF cookie sent
INFO - 2018-10-31 17:20:37 --> Input Class Initialized
INFO - 2018-10-31 17:20:37 --> Language Class Initialized
INFO - 2018-10-31 17:20:37 --> Loader Class Initialized
INFO - 2018-10-31 17:20:37 --> Helper loaded: url_helper
INFO - 2018-10-31 17:20:37 --> Helper loaded: form_helper
INFO - 2018-10-31 17:20:37 --> Helper loaded: language_helper
DEBUG - 2018-10-31 17:20:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-31 17:20:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-31 17:20:37 --> User Agent Class Initialized
INFO - 2018-10-31 17:20:37 --> Controller Class Initialized
INFO - 2018-10-31 17:20:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-31 17:20:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-31 17:20:37 --> Helper loaded: custom_helper
ERROR - 2018-10-31 17:21:07 --> Severity: Error --> Maximum execution time of 30 seconds exceeded E:\xampp7\htdocs\famiquity\system\core\Common.php 597
INFO - 2018-10-31 17:22:41 --> Config Class Initialized
INFO - 2018-10-31 17:22:41 --> Hooks Class Initialized
DEBUG - 2018-10-31 17:22:41 --> UTF-8 Support Enabled
INFO - 2018-10-31 17:22:41 --> Utf8 Class Initialized
INFO - 2018-10-31 17:22:41 --> URI Class Initialized
INFO - 2018-10-31 17:22:41 --> Router Class Initialized
INFO - 2018-10-31 17:22:41 --> Output Class Initialized
INFO - 2018-10-31 17:22:41 --> Security Class Initialized
DEBUG - 2018-10-31 17:22:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-31 17:22:41 --> CSRF cookie sent
INFO - 2018-10-31 17:22:41 --> Input Class Initialized
INFO - 2018-10-31 17:22:41 --> Language Class Initialized
INFO - 2018-10-31 17:22:41 --> Loader Class Initialized
INFO - 2018-10-31 17:22:41 --> Helper loaded: url_helper
INFO - 2018-10-31 17:22:41 --> Helper loaded: form_helper
INFO - 2018-10-31 17:22:41 --> Helper loaded: language_helper
DEBUG - 2018-10-31 17:22:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-31 17:22:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-31 17:22:41 --> User Agent Class Initialized
INFO - 2018-10-31 17:22:41 --> Controller Class Initialized
INFO - 2018-10-31 17:22:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-31 17:22:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-31 17:22:41 --> Helper loaded: custom_helper
ERROR - 2018-10-31 17:23:11 --> Severity: Error --> Maximum execution time of 30 seconds exceeded E:\xampp7\htdocs\famiquity\system\core\Common.php 597
INFO - 2018-10-31 17:26:16 --> Config Class Initialized
INFO - 2018-10-31 17:26:16 --> Hooks Class Initialized
DEBUG - 2018-10-31 17:26:16 --> UTF-8 Support Enabled
INFO - 2018-10-31 17:26:16 --> Utf8 Class Initialized
INFO - 2018-10-31 17:26:16 --> URI Class Initialized
INFO - 2018-10-31 17:26:16 --> Router Class Initialized
INFO - 2018-10-31 17:26:16 --> Output Class Initialized
INFO - 2018-10-31 17:26:16 --> Security Class Initialized
DEBUG - 2018-10-31 17:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-31 17:26:16 --> CSRF cookie sent
INFO - 2018-10-31 17:26:16 --> Input Class Initialized
INFO - 2018-10-31 17:26:16 --> Language Class Initialized
INFO - 2018-10-31 17:26:16 --> Loader Class Initialized
INFO - 2018-10-31 17:26:16 --> Helper loaded: url_helper
INFO - 2018-10-31 17:26:16 --> Helper loaded: form_helper
INFO - 2018-10-31 17:26:16 --> Helper loaded: language_helper
DEBUG - 2018-10-31 17:26:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-31 17:26:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-31 17:26:16 --> User Agent Class Initialized
INFO - 2018-10-31 17:26:16 --> Controller Class Initialized
INFO - 2018-10-31 17:26:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-31 17:26:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-31 17:26:16 --> Helper loaded: custom_helper
ERROR - 2018-10-31 17:26:16 --> Severity: error --> Exception: RecursiveDirectoryIterator::__construct(http://localhost/famiquity/application): failed to open dir: not implemented E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 26
INFO - 2018-10-31 17:26:29 --> Config Class Initialized
INFO - 2018-10-31 17:26:29 --> Hooks Class Initialized
DEBUG - 2018-10-31 17:26:29 --> UTF-8 Support Enabled
INFO - 2018-10-31 17:26:29 --> Utf8 Class Initialized
INFO - 2018-10-31 17:26:29 --> URI Class Initialized
INFO - 2018-10-31 17:26:29 --> Router Class Initialized
INFO - 2018-10-31 17:26:29 --> Output Class Initialized
INFO - 2018-10-31 17:26:29 --> Security Class Initialized
DEBUG - 2018-10-31 17:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-31 17:26:29 --> CSRF cookie sent
INFO - 2018-10-31 17:26:29 --> Input Class Initialized
INFO - 2018-10-31 17:26:29 --> Language Class Initialized
INFO - 2018-10-31 17:26:29 --> Loader Class Initialized
INFO - 2018-10-31 17:26:29 --> Helper loaded: url_helper
INFO - 2018-10-31 17:26:29 --> Helper loaded: form_helper
INFO - 2018-10-31 17:26:29 --> Helper loaded: language_helper
DEBUG - 2018-10-31 17:26:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-31 17:26:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-31 17:26:29 --> User Agent Class Initialized
INFO - 2018-10-31 17:26:29 --> Controller Class Initialized
INFO - 2018-10-31 17:26:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-31 17:26:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-31 17:26:29 --> Helper loaded: custom_helper
ERROR - 2018-10-31 17:26:29 --> Severity: error --> Exception: RecursiveDirectoryIterator::__construct(http://localhost/famiquity/application): failed to open dir: not implemented E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 26
INFO - 2018-10-31 17:26:31 --> Config Class Initialized
INFO - 2018-10-31 17:26:31 --> Hooks Class Initialized
DEBUG - 2018-10-31 17:26:31 --> UTF-8 Support Enabled
INFO - 2018-10-31 17:26:31 --> Utf8 Class Initialized
INFO - 2018-10-31 17:26:31 --> URI Class Initialized
INFO - 2018-10-31 17:26:31 --> Router Class Initialized
INFO - 2018-10-31 17:26:31 --> Output Class Initialized
INFO - 2018-10-31 17:26:31 --> Security Class Initialized
DEBUG - 2018-10-31 17:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-31 17:26:31 --> CSRF cookie sent
INFO - 2018-10-31 17:26:31 --> Input Class Initialized
INFO - 2018-10-31 17:26:31 --> Language Class Initialized
INFO - 2018-10-31 17:26:31 --> Loader Class Initialized
INFO - 2018-10-31 17:26:31 --> Helper loaded: url_helper
INFO - 2018-10-31 17:26:31 --> Helper loaded: form_helper
INFO - 2018-10-31 17:26:31 --> Helper loaded: language_helper
DEBUG - 2018-10-31 17:26:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-31 17:26:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-31 17:26:31 --> User Agent Class Initialized
INFO - 2018-10-31 17:26:31 --> Controller Class Initialized
INFO - 2018-10-31 17:26:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-31 17:26:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-31 17:26:31 --> Helper loaded: custom_helper
ERROR - 2018-10-31 17:26:31 --> Severity: error --> Exception: RecursiveDirectoryIterator::__construct(http://localhost/famiquity/application): failed to open dir: not implemented E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 26
INFO - 2018-10-31 17:26:31 --> Config Class Initialized
INFO - 2018-10-31 17:26:31 --> Hooks Class Initialized
DEBUG - 2018-10-31 17:26:31 --> UTF-8 Support Enabled
INFO - 2018-10-31 17:26:31 --> Utf8 Class Initialized
INFO - 2018-10-31 17:26:31 --> URI Class Initialized
INFO - 2018-10-31 17:26:31 --> Router Class Initialized
INFO - 2018-10-31 17:26:31 --> Output Class Initialized
INFO - 2018-10-31 17:26:31 --> Security Class Initialized
DEBUG - 2018-10-31 17:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-31 17:26:31 --> CSRF cookie sent
INFO - 2018-10-31 17:26:31 --> Input Class Initialized
INFO - 2018-10-31 17:26:31 --> Language Class Initialized
INFO - 2018-10-31 17:26:31 --> Loader Class Initialized
INFO - 2018-10-31 17:26:32 --> Helper loaded: url_helper
INFO - 2018-10-31 17:26:32 --> Helper loaded: form_helper
INFO - 2018-10-31 17:26:32 --> Helper loaded: language_helper
DEBUG - 2018-10-31 17:26:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-31 17:26:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-31 17:26:32 --> User Agent Class Initialized
INFO - 2018-10-31 17:26:32 --> Controller Class Initialized
INFO - 2018-10-31 17:26:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-31 17:26:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-31 17:26:32 --> Helper loaded: custom_helper
ERROR - 2018-10-31 17:26:32 --> Severity: error --> Exception: RecursiveDirectoryIterator::__construct(http://localhost/famiquity/application): failed to open dir: not implemented E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 26
INFO - 2018-10-31 17:26:41 --> Config Class Initialized
INFO - 2018-10-31 17:26:41 --> Hooks Class Initialized
DEBUG - 2018-10-31 17:26:41 --> UTF-8 Support Enabled
INFO - 2018-10-31 17:26:41 --> Utf8 Class Initialized
INFO - 2018-10-31 17:26:41 --> URI Class Initialized
INFO - 2018-10-31 17:26:41 --> Router Class Initialized
INFO - 2018-10-31 17:26:41 --> Output Class Initialized
INFO - 2018-10-31 17:26:41 --> Security Class Initialized
DEBUG - 2018-10-31 17:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-31 17:26:41 --> CSRF cookie sent
INFO - 2018-10-31 17:26:41 --> Input Class Initialized
INFO - 2018-10-31 17:26:41 --> Language Class Initialized
INFO - 2018-10-31 17:26:41 --> Loader Class Initialized
INFO - 2018-10-31 17:26:41 --> Helper loaded: url_helper
INFO - 2018-10-31 17:26:41 --> Helper loaded: form_helper
INFO - 2018-10-31 17:26:41 --> Helper loaded: language_helper
DEBUG - 2018-10-31 17:26:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-31 17:26:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-31 17:26:41 --> User Agent Class Initialized
INFO - 2018-10-31 17:26:41 --> Controller Class Initialized
INFO - 2018-10-31 17:26:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-31 17:26:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-31 17:26:41 --> Helper loaded: custom_helper
ERROR - 2018-10-31 17:26:41 --> Severity: error --> Exception: RecursiveDirectoryIterator::__construct(http://localhost/famiquity/application): failed to open dir: not implemented E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 26
INFO - 2018-10-31 17:27:04 --> Config Class Initialized
INFO - 2018-10-31 17:27:04 --> Hooks Class Initialized
DEBUG - 2018-10-31 17:27:04 --> UTF-8 Support Enabled
INFO - 2018-10-31 17:27:04 --> Utf8 Class Initialized
INFO - 2018-10-31 17:27:04 --> URI Class Initialized
INFO - 2018-10-31 17:27:04 --> Router Class Initialized
INFO - 2018-10-31 17:27:04 --> Output Class Initialized
INFO - 2018-10-31 17:27:04 --> Security Class Initialized
DEBUG - 2018-10-31 17:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-31 17:27:04 --> CSRF cookie sent
INFO - 2018-10-31 17:27:04 --> Input Class Initialized
INFO - 2018-10-31 17:27:04 --> Language Class Initialized
ERROR - 2018-10-31 17:27:05 --> Severity: error --> Exception: syntax error, unexpected ')' E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 21
INFO - 2018-10-31 17:27:06 --> Config Class Initialized
INFO - 2018-10-31 17:27:06 --> Hooks Class Initialized
DEBUG - 2018-10-31 17:27:06 --> UTF-8 Support Enabled
INFO - 2018-10-31 17:27:06 --> Utf8 Class Initialized
INFO - 2018-10-31 17:27:06 --> URI Class Initialized
INFO - 2018-10-31 17:27:06 --> Router Class Initialized
INFO - 2018-10-31 17:27:06 --> Output Class Initialized
INFO - 2018-10-31 17:27:06 --> Security Class Initialized
DEBUG - 2018-10-31 17:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-31 17:27:06 --> CSRF cookie sent
INFO - 2018-10-31 17:27:06 --> Input Class Initialized
INFO - 2018-10-31 17:27:06 --> Language Class Initialized
ERROR - 2018-10-31 17:27:06 --> Severity: error --> Exception: syntax error, unexpected ')' E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 21
INFO - 2018-10-31 17:44:17 --> Config Class Initialized
INFO - 2018-10-31 17:44:17 --> Hooks Class Initialized
DEBUG - 2018-10-31 17:44:17 --> UTF-8 Support Enabled
INFO - 2018-10-31 17:44:17 --> Utf8 Class Initialized
INFO - 2018-10-31 17:44:17 --> URI Class Initialized
INFO - 2018-10-31 17:44:17 --> Router Class Initialized
INFO - 2018-10-31 17:44:17 --> Output Class Initialized
INFO - 2018-10-31 17:44:17 --> Security Class Initialized
DEBUG - 2018-10-31 17:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-31 17:44:17 --> CSRF cookie sent
INFO - 2018-10-31 17:44:17 --> Input Class Initialized
INFO - 2018-10-31 17:44:17 --> Language Class Initialized
ERROR - 2018-10-31 17:44:17 --> Severity: error --> Exception: syntax error, unexpected end of file E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 67
INFO - 2018-10-31 17:44:18 --> Config Class Initialized
INFO - 2018-10-31 17:44:18 --> Hooks Class Initialized
DEBUG - 2018-10-31 17:44:18 --> UTF-8 Support Enabled
INFO - 2018-10-31 17:44:18 --> Utf8 Class Initialized
INFO - 2018-10-31 17:44:18 --> URI Class Initialized
INFO - 2018-10-31 17:44:18 --> Router Class Initialized
INFO - 2018-10-31 17:44:18 --> Output Class Initialized
INFO - 2018-10-31 17:44:18 --> Security Class Initialized
DEBUG - 2018-10-31 17:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-31 17:44:18 --> CSRF cookie sent
INFO - 2018-10-31 17:44:18 --> Input Class Initialized
INFO - 2018-10-31 17:44:18 --> Language Class Initialized
ERROR - 2018-10-31 17:44:18 --> Severity: error --> Exception: syntax error, unexpected end of file E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 67
INFO - 2018-10-31 17:44:19 --> Config Class Initialized
INFO - 2018-10-31 17:44:19 --> Hooks Class Initialized
DEBUG - 2018-10-31 17:44:19 --> UTF-8 Support Enabled
INFO - 2018-10-31 17:44:19 --> Utf8 Class Initialized
INFO - 2018-10-31 17:44:19 --> URI Class Initialized
INFO - 2018-10-31 17:44:19 --> Router Class Initialized
INFO - 2018-10-31 17:44:19 --> Output Class Initialized
INFO - 2018-10-31 17:44:19 --> Security Class Initialized
DEBUG - 2018-10-31 17:44:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-31 17:44:19 --> CSRF cookie sent
INFO - 2018-10-31 17:44:19 --> Input Class Initialized
INFO - 2018-10-31 17:44:19 --> Language Class Initialized
ERROR - 2018-10-31 17:44:19 --> Severity: error --> Exception: syntax error, unexpected end of file E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 67
INFO - 2018-10-31 17:44:19 --> Config Class Initialized
INFO - 2018-10-31 17:44:19 --> Hooks Class Initialized
DEBUG - 2018-10-31 17:44:19 --> UTF-8 Support Enabled
INFO - 2018-10-31 17:44:19 --> Utf8 Class Initialized
INFO - 2018-10-31 17:44:19 --> URI Class Initialized
INFO - 2018-10-31 17:44:19 --> Router Class Initialized
INFO - 2018-10-31 17:44:19 --> Output Class Initialized
INFO - 2018-10-31 17:44:19 --> Security Class Initialized
DEBUG - 2018-10-31 17:44:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-31 17:44:19 --> CSRF cookie sent
INFO - 2018-10-31 17:44:19 --> Input Class Initialized
INFO - 2018-10-31 17:44:19 --> Language Class Initialized
ERROR - 2018-10-31 17:44:19 --> Severity: error --> Exception: syntax error, unexpected end of file E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 67
INFO - 2018-10-31 17:44:22 --> Config Class Initialized
INFO - 2018-10-31 17:44:22 --> Hooks Class Initialized
DEBUG - 2018-10-31 17:44:22 --> UTF-8 Support Enabled
INFO - 2018-10-31 17:44:22 --> Utf8 Class Initialized
INFO - 2018-10-31 17:44:22 --> URI Class Initialized
DEBUG - 2018-10-31 17:44:22 --> No URI present. Default controller set.
INFO - 2018-10-31 17:44:22 --> Router Class Initialized
INFO - 2018-10-31 17:44:22 --> Output Class Initialized
INFO - 2018-10-31 17:44:22 --> Security Class Initialized
DEBUG - 2018-10-31 17:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-31 17:44:22 --> CSRF cookie sent
INFO - 2018-10-31 17:44:22 --> Input Class Initialized
INFO - 2018-10-31 17:44:22 --> Language Class Initialized
INFO - 2018-10-31 17:44:22 --> Loader Class Initialized
INFO - 2018-10-31 17:44:22 --> Helper loaded: url_helper
INFO - 2018-10-31 17:44:22 --> Helper loaded: form_helper
INFO - 2018-10-31 17:44:22 --> Helper loaded: language_helper
DEBUG - 2018-10-31 17:44:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-31 17:44:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-31 17:44:22 --> User Agent Class Initialized
INFO - 2018-10-31 17:44:22 --> Controller Class Initialized
INFO - 2018-10-31 17:44:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-31 17:44:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-31 17:44:22 --> Helper loaded: custom_helper
INFO - 2018-10-31 17:44:22 --> Pixel_Model class loaded
INFO - 2018-10-31 17:44:22 --> Database Driver Class Initialized
INFO - 2018-10-31 17:44:22 --> Model "QuestionsModel" initialized
INFO - 2018-10-31 17:44:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-10-31 17:44:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-10-31 17:44:22 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-10-31 17:44:23 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-10-31 17:44:23 --> Final output sent to browser
DEBUG - 2018-10-31 17:44:23 --> Total execution time: 0.3303
INFO - 2018-10-31 17:44:28 --> Config Class Initialized
INFO - 2018-10-31 17:44:28 --> Hooks Class Initialized
DEBUG - 2018-10-31 17:44:28 --> UTF-8 Support Enabled
INFO - 2018-10-31 17:44:28 --> Utf8 Class Initialized
INFO - 2018-10-31 17:44:28 --> URI Class Initialized
INFO - 2018-10-31 17:44:28 --> Router Class Initialized
INFO - 2018-10-31 17:44:28 --> Output Class Initialized
INFO - 2018-10-31 17:44:28 --> Security Class Initialized
DEBUG - 2018-10-31 17:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-31 17:44:28 --> CSRF cookie sent
INFO - 2018-10-31 17:44:28 --> Input Class Initialized
INFO - 2018-10-31 17:44:28 --> Language Class Initialized
ERROR - 2018-10-31 17:44:28 --> Severity: error --> Exception: syntax error, unexpected end of file E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 67
INFO - 2018-10-31 17:44:37 --> Config Class Initialized
INFO - 2018-10-31 17:44:37 --> Hooks Class Initialized
DEBUG - 2018-10-31 17:44:37 --> UTF-8 Support Enabled
INFO - 2018-10-31 17:44:37 --> Utf8 Class Initialized
INFO - 2018-10-31 17:44:37 --> URI Class Initialized
INFO - 2018-10-31 17:44:37 --> Router Class Initialized
INFO - 2018-10-31 17:44:37 --> Output Class Initialized
INFO - 2018-10-31 17:44:37 --> Security Class Initialized
DEBUG - 2018-10-31 17:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-31 17:44:37 --> CSRF cookie sent
INFO - 2018-10-31 17:44:37 --> Input Class Initialized
INFO - 2018-10-31 17:44:37 --> Language Class Initialized
ERROR - 2018-10-31 17:44:37 --> Severity: error --> Exception: syntax error, unexpected end of file E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 67
INFO - 2018-10-31 17:51:39 --> Config Class Initialized
INFO - 2018-10-31 17:51:39 --> Hooks Class Initialized
DEBUG - 2018-10-31 17:51:39 --> UTF-8 Support Enabled
INFO - 2018-10-31 17:51:39 --> Utf8 Class Initialized
INFO - 2018-10-31 17:51:39 --> URI Class Initialized
INFO - 2018-10-31 17:51:39 --> Router Class Initialized
INFO - 2018-10-31 17:51:39 --> Output Class Initialized
INFO - 2018-10-31 17:51:39 --> Security Class Initialized
DEBUG - 2018-10-31 17:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-31 17:51:39 --> CSRF cookie sent
INFO - 2018-10-31 17:51:39 --> Input Class Initialized
INFO - 2018-10-31 17:51:39 --> Language Class Initialized
INFO - 2018-10-31 17:51:39 --> Loader Class Initialized
INFO - 2018-10-31 17:51:39 --> Helper loaded: url_helper
INFO - 2018-10-31 17:51:39 --> Helper loaded: form_helper
INFO - 2018-10-31 17:51:39 --> Helper loaded: language_helper
DEBUG - 2018-10-31 17:51:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-31 17:51:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-31 17:51:39 --> User Agent Class Initialized
INFO - 2018-10-31 17:51:39 --> Controller Class Initialized
INFO - 2018-10-31 17:51:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-31 17:51:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-31 17:51:39 --> Helper loaded: custom_helper
INFO - 2018-10-31 17:51:39 --> Final output sent to browser
DEBUG - 2018-10-31 17:51:39 --> Total execution time: 0.2157
INFO - 2018-10-31 17:53:15 --> Config Class Initialized
INFO - 2018-10-31 17:53:15 --> Hooks Class Initialized
DEBUG - 2018-10-31 17:53:15 --> UTF-8 Support Enabled
INFO - 2018-10-31 17:53:15 --> Utf8 Class Initialized
INFO - 2018-10-31 17:53:15 --> URI Class Initialized
INFO - 2018-10-31 17:53:15 --> Router Class Initialized
INFO - 2018-10-31 17:53:15 --> Output Class Initialized
INFO - 2018-10-31 17:53:15 --> Security Class Initialized
DEBUG - 2018-10-31 17:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-31 17:53:15 --> CSRF cookie sent
INFO - 2018-10-31 17:53:15 --> Input Class Initialized
INFO - 2018-10-31 17:53:15 --> Language Class Initialized
INFO - 2018-10-31 17:53:15 --> Loader Class Initialized
INFO - 2018-10-31 17:53:15 --> Helper loaded: url_helper
INFO - 2018-10-31 17:53:15 --> Helper loaded: form_helper
INFO - 2018-10-31 17:53:15 --> Helper loaded: language_helper
DEBUG - 2018-10-31 17:53:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-31 17:53:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-31 17:53:15 --> User Agent Class Initialized
INFO - 2018-10-31 17:53:15 --> Controller Class Initialized
INFO - 2018-10-31 17:53:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-31 17:53:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-31 17:53:15 --> Helper loaded: custom_helper
INFO - 2018-10-31 17:53:15 --> Final output sent to browser
DEBUG - 2018-10-31 17:53:15 --> Total execution time: 0.1972
INFO - 2018-10-31 17:55:25 --> Config Class Initialized
INFO - 2018-10-31 17:55:25 --> Hooks Class Initialized
DEBUG - 2018-10-31 17:55:25 --> UTF-8 Support Enabled
INFO - 2018-10-31 17:55:25 --> Utf8 Class Initialized
INFO - 2018-10-31 17:55:25 --> URI Class Initialized
INFO - 2018-10-31 17:55:25 --> Router Class Initialized
INFO - 2018-10-31 17:55:25 --> Output Class Initialized
INFO - 2018-10-31 17:55:25 --> Security Class Initialized
DEBUG - 2018-10-31 17:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-31 17:55:25 --> CSRF cookie sent
INFO - 2018-10-31 17:55:25 --> Input Class Initialized
INFO - 2018-10-31 17:55:25 --> Language Class Initialized
INFO - 2018-10-31 17:55:25 --> Loader Class Initialized
INFO - 2018-10-31 17:55:25 --> Helper loaded: url_helper
INFO - 2018-10-31 17:55:25 --> Helper loaded: form_helper
INFO - 2018-10-31 17:55:25 --> Helper loaded: language_helper
DEBUG - 2018-10-31 17:55:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-31 17:55:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-31 17:55:25 --> User Agent Class Initialized
INFO - 2018-10-31 17:55:25 --> Controller Class Initialized
INFO - 2018-10-31 17:55:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-31 17:55:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-31 17:55:25 --> Helper loaded: custom_helper
INFO - 2018-10-31 17:55:25 --> Database Driver Class Initialized
INFO - 2018-10-31 17:55:25 --> Database Utility Class Initialized
INFO - 2018-10-31 17:55:25 --> Zip Compression Class Initialized
INFO - 2018-10-31 17:55:25 --> Helper loaded: file_helper
INFO - 2018-10-31 17:55:25 --> Helper loaded: download_helper
INFO - 2018-10-31 17:55:47 --> Config Class Initialized
INFO - 2018-10-31 17:55:47 --> Hooks Class Initialized
DEBUG - 2018-10-31 17:55:47 --> UTF-8 Support Enabled
INFO - 2018-10-31 17:55:47 --> Utf8 Class Initialized
INFO - 2018-10-31 17:55:47 --> URI Class Initialized
INFO - 2018-10-31 17:55:47 --> Router Class Initialized
INFO - 2018-10-31 17:55:47 --> Output Class Initialized
INFO - 2018-10-31 17:55:47 --> Security Class Initialized
DEBUG - 2018-10-31 17:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-31 17:55:47 --> CSRF cookie sent
INFO - 2018-10-31 17:55:47 --> Input Class Initialized
INFO - 2018-10-31 17:55:47 --> Language Class Initialized
INFO - 2018-10-31 17:55:47 --> Loader Class Initialized
INFO - 2018-10-31 17:55:47 --> Helper loaded: url_helper
INFO - 2018-10-31 17:55:47 --> Helper loaded: form_helper
INFO - 2018-10-31 17:55:47 --> Helper loaded: language_helper
DEBUG - 2018-10-31 17:55:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-31 17:55:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-31 17:55:47 --> User Agent Class Initialized
INFO - 2018-10-31 17:55:47 --> Controller Class Initialized
INFO - 2018-10-31 17:55:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-31 17:55:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-31 17:55:47 --> Helper loaded: custom_helper
INFO - 2018-10-31 17:55:47 --> Database Driver Class Initialized
INFO - 2018-10-31 17:55:47 --> Database Utility Class Initialized
INFO - 2018-10-31 17:55:47 --> Zip Compression Class Initialized
INFO - 2018-10-31 17:55:47 --> Helper loaded: file_helper
INFO - 2018-10-31 17:55:47 --> Helper loaded: download_helper
INFO - 2018-10-31 17:57:46 --> Config Class Initialized
INFO - 2018-10-31 17:57:46 --> Hooks Class Initialized
DEBUG - 2018-10-31 17:57:46 --> UTF-8 Support Enabled
INFO - 2018-10-31 17:57:46 --> Utf8 Class Initialized
INFO - 2018-10-31 17:57:46 --> URI Class Initialized
INFO - 2018-10-31 17:57:46 --> Router Class Initialized
INFO - 2018-10-31 17:57:46 --> Output Class Initialized
INFO - 2018-10-31 17:57:46 --> Security Class Initialized
DEBUG - 2018-10-31 17:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-31 17:57:46 --> CSRF cookie sent
INFO - 2018-10-31 17:57:46 --> Input Class Initialized
INFO - 2018-10-31 17:57:46 --> Language Class Initialized
INFO - 2018-10-31 17:57:46 --> Loader Class Initialized
INFO - 2018-10-31 17:57:46 --> Helper loaded: url_helper
INFO - 2018-10-31 17:57:46 --> Helper loaded: form_helper
INFO - 2018-10-31 17:57:46 --> Helper loaded: language_helper
DEBUG - 2018-10-31 17:57:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-31 17:57:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-31 17:57:46 --> User Agent Class Initialized
INFO - 2018-10-31 17:57:46 --> Controller Class Initialized
INFO - 2018-10-31 17:57:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-31 17:57:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-31 17:57:46 --> Helper loaded: custom_helper
INFO - 2018-10-31 17:57:46 --> Database Driver Class Initialized
INFO - 2018-10-31 17:57:46 --> Database Utility Class Initialized
INFO - 2018-10-31 17:57:46 --> Zip Compression Class Initialized
INFO - 2018-10-31 17:57:46 --> Helper loaded: file_helper
INFO - 2018-10-31 17:57:46 --> Helper loaded: download_helper
INFO - 2018-10-31 18:00:09 --> Config Class Initialized
INFO - 2018-10-31 18:00:09 --> Hooks Class Initialized
DEBUG - 2018-10-31 18:00:09 --> UTF-8 Support Enabled
INFO - 2018-10-31 18:00:09 --> Utf8 Class Initialized
INFO - 2018-10-31 18:00:09 --> URI Class Initialized
INFO - 2018-10-31 18:00:09 --> Router Class Initialized
INFO - 2018-10-31 18:00:09 --> Output Class Initialized
INFO - 2018-10-31 18:00:09 --> Security Class Initialized
DEBUG - 2018-10-31 18:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-31 18:00:09 --> CSRF cookie sent
INFO - 2018-10-31 18:00:09 --> Input Class Initialized
INFO - 2018-10-31 18:00:09 --> Language Class Initialized
INFO - 2018-10-31 18:00:09 --> Loader Class Initialized
INFO - 2018-10-31 18:00:09 --> Helper loaded: url_helper
INFO - 2018-10-31 18:00:09 --> Helper loaded: form_helper
INFO - 2018-10-31 18:00:09 --> Helper loaded: language_helper
DEBUG - 2018-10-31 18:00:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-31 18:00:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-31 18:00:09 --> User Agent Class Initialized
INFO - 2018-10-31 18:00:09 --> Controller Class Initialized
INFO - 2018-10-31 18:00:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-31 18:00:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-31 18:00:09 --> Helper loaded: custom_helper
INFO - 2018-10-31 18:00:09 --> Database Driver Class Initialized
INFO - 2018-10-31 18:00:09 --> Database Utility Class Initialized
INFO - 2018-10-31 18:00:09 --> Database Utility Class Initialized
INFO - 2018-10-31 18:00:09 --> Helper loaded: file_helper
INFO - 2018-10-31 18:00:09 --> Final output sent to browser
DEBUG - 2018-10-31 18:00:09 --> Total execution time: 0.2993
INFO - 2018-10-31 18:01:50 --> Config Class Initialized
INFO - 2018-10-31 18:01:50 --> Hooks Class Initialized
DEBUG - 2018-10-31 18:01:50 --> UTF-8 Support Enabled
INFO - 2018-10-31 18:01:50 --> Utf8 Class Initialized
INFO - 2018-10-31 18:01:50 --> URI Class Initialized
INFO - 2018-10-31 18:01:50 --> Router Class Initialized
INFO - 2018-10-31 18:01:50 --> Output Class Initialized
INFO - 2018-10-31 18:01:50 --> Security Class Initialized
DEBUG - 2018-10-31 18:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-31 18:01:50 --> CSRF cookie sent
INFO - 2018-10-31 18:01:50 --> Input Class Initialized
INFO - 2018-10-31 18:01:50 --> Language Class Initialized
ERROR - 2018-10-31 18:01:50 --> Severity: error --> Exception: syntax error, unexpected ',' E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 38
INFO - 2018-10-31 18:02:04 --> Config Class Initialized
INFO - 2018-10-31 18:02:04 --> Hooks Class Initialized
DEBUG - 2018-10-31 18:02:04 --> UTF-8 Support Enabled
INFO - 2018-10-31 18:02:04 --> Utf8 Class Initialized
INFO - 2018-10-31 18:02:04 --> URI Class Initialized
INFO - 2018-10-31 18:02:04 --> Router Class Initialized
INFO - 2018-10-31 18:02:04 --> Output Class Initialized
INFO - 2018-10-31 18:02:04 --> Security Class Initialized
DEBUG - 2018-10-31 18:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-31 18:02:04 --> CSRF cookie sent
INFO - 2018-10-31 18:02:04 --> Input Class Initialized
INFO - 2018-10-31 18:02:04 --> Language Class Initialized
INFO - 2018-10-31 18:02:04 --> Loader Class Initialized
INFO - 2018-10-31 18:02:04 --> Helper loaded: url_helper
INFO - 2018-10-31 18:02:04 --> Helper loaded: form_helper
INFO - 2018-10-31 18:02:04 --> Helper loaded: language_helper
DEBUG - 2018-10-31 18:02:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-31 18:02:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-31 18:02:04 --> User Agent Class Initialized
INFO - 2018-10-31 18:02:04 --> Controller Class Initialized
INFO - 2018-10-31 18:02:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-31 18:02:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-31 18:02:04 --> Helper loaded: custom_helper
INFO - 2018-10-31 18:02:04 --> Database Driver Class Initialized
INFO - 2018-10-31 18:02:04 --> Database Utility Class Initialized
INFO - 2018-10-31 18:02:04 --> Database Utility Class Initialized
INFO - 2018-10-31 18:02:04 --> Zip Compression Class Initialized
INFO - 2018-10-31 18:02:04 --> Final output sent to browser
DEBUG - 2018-10-31 18:02:04 --> Total execution time: 0.3084
INFO - 2018-10-31 18:03:02 --> Config Class Initialized
INFO - 2018-10-31 18:03:02 --> Hooks Class Initialized
DEBUG - 2018-10-31 18:03:02 --> UTF-8 Support Enabled
INFO - 2018-10-31 18:03:02 --> Utf8 Class Initialized
INFO - 2018-10-31 18:03:02 --> URI Class Initialized
INFO - 2018-10-31 18:03:02 --> Router Class Initialized
INFO - 2018-10-31 18:03:02 --> Output Class Initialized
INFO - 2018-10-31 18:03:02 --> Security Class Initialized
DEBUG - 2018-10-31 18:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-31 18:03:02 --> CSRF cookie sent
INFO - 2018-10-31 18:03:02 --> Input Class Initialized
INFO - 2018-10-31 18:03:02 --> Language Class Initialized
INFO - 2018-10-31 18:03:02 --> Loader Class Initialized
INFO - 2018-10-31 18:03:02 --> Helper loaded: url_helper
INFO - 2018-10-31 18:03:02 --> Helper loaded: form_helper
INFO - 2018-10-31 18:03:02 --> Helper loaded: language_helper
DEBUG - 2018-10-31 18:03:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-31 18:03:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-31 18:03:02 --> User Agent Class Initialized
INFO - 2018-10-31 18:03:02 --> Controller Class Initialized
INFO - 2018-10-31 18:03:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-31 18:03:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-31 18:03:02 --> Helper loaded: custom_helper
INFO - 2018-10-31 18:03:02 --> Database Driver Class Initialized
INFO - 2018-10-31 18:03:02 --> Database Utility Class Initialized
INFO - 2018-10-31 18:03:02 --> Database Utility Class Initialized
INFO - 2018-10-31 18:03:02 --> Zip Compression Class Initialized
INFO - 2018-10-31 18:03:02 --> Helper loaded: file_helper
INFO - 2018-10-31 18:03:02 --> Final output sent to browser
DEBUG - 2018-10-31 18:03:02 --> Total execution time: 0.3213
INFO - 2018-10-31 18:07:23 --> Config Class Initialized
INFO - 2018-10-31 18:07:23 --> Hooks Class Initialized
DEBUG - 2018-10-31 18:07:23 --> UTF-8 Support Enabled
INFO - 2018-10-31 18:07:23 --> Utf8 Class Initialized
INFO - 2018-10-31 18:07:23 --> URI Class Initialized
INFO - 2018-10-31 18:07:23 --> Router Class Initialized
INFO - 2018-10-31 18:07:23 --> Output Class Initialized
INFO - 2018-10-31 18:07:23 --> Security Class Initialized
DEBUG - 2018-10-31 18:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-31 18:07:23 --> CSRF cookie sent
INFO - 2018-10-31 18:07:23 --> Input Class Initialized
INFO - 2018-10-31 18:07:23 --> Language Class Initialized
INFO - 2018-10-31 18:07:23 --> Loader Class Initialized
INFO - 2018-10-31 18:07:23 --> Helper loaded: url_helper
INFO - 2018-10-31 18:07:23 --> Helper loaded: form_helper
INFO - 2018-10-31 18:07:23 --> Helper loaded: language_helper
DEBUG - 2018-10-31 18:07:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-31 18:07:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-31 18:07:23 --> User Agent Class Initialized
INFO - 2018-10-31 18:07:23 --> Controller Class Initialized
INFO - 2018-10-31 18:07:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-31 18:07:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-31 18:07:23 --> Helper loaded: custom_helper
INFO - 2018-10-31 18:07:23 --> Database Driver Class Initialized
INFO - 2018-10-31 18:07:23 --> Database Utility Class Initialized
INFO - 2018-10-31 18:07:23 --> Database Utility Class Initialized
INFO - 2018-10-31 18:07:23 --> Zip Compression Class Initialized
INFO - 2018-10-31 18:07:23 --> Helper loaded: file_helper
INFO - 2018-10-31 18:07:23 --> Final output sent to browser
DEBUG - 2018-10-31 18:07:23 --> Total execution time: 0.3301
INFO - 2018-10-31 18:07:24 --> Config Class Initialized
INFO - 2018-10-31 18:07:24 --> Hooks Class Initialized
DEBUG - 2018-10-31 18:07:24 --> UTF-8 Support Enabled
INFO - 2018-10-31 18:07:24 --> Utf8 Class Initialized
INFO - 2018-10-31 18:07:24 --> URI Class Initialized
INFO - 2018-10-31 18:07:24 --> Router Class Initialized
INFO - 2018-10-31 18:07:24 --> Output Class Initialized
INFO - 2018-10-31 18:07:24 --> Security Class Initialized
DEBUG - 2018-10-31 18:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-31 18:07:24 --> CSRF cookie sent
INFO - 2018-10-31 18:07:24 --> Input Class Initialized
INFO - 2018-10-31 18:07:24 --> Language Class Initialized
INFO - 2018-10-31 18:07:24 --> Loader Class Initialized
INFO - 2018-10-31 18:07:24 --> Helper loaded: url_helper
INFO - 2018-10-31 18:07:24 --> Helper loaded: form_helper
INFO - 2018-10-31 18:07:24 --> Helper loaded: language_helper
DEBUG - 2018-10-31 18:07:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-31 18:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-31 18:07:24 --> User Agent Class Initialized
INFO - 2018-10-31 18:07:24 --> Controller Class Initialized
INFO - 2018-10-31 18:07:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-31 18:07:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-31 18:07:24 --> Helper loaded: custom_helper
INFO - 2018-10-31 18:07:24 --> Database Driver Class Initialized
INFO - 2018-10-31 18:07:24 --> Database Utility Class Initialized
INFO - 2018-10-31 18:07:25 --> Database Utility Class Initialized
INFO - 2018-10-31 18:07:25 --> Zip Compression Class Initialized
INFO - 2018-10-31 18:07:25 --> Helper loaded: file_helper
INFO - 2018-10-31 18:07:25 --> Final output sent to browser
DEBUG - 2018-10-31 18:07:25 --> Total execution time: 0.3126
INFO - 2018-10-31 18:08:26 --> Config Class Initialized
INFO - 2018-10-31 18:08:26 --> Hooks Class Initialized
DEBUG - 2018-10-31 18:08:26 --> UTF-8 Support Enabled
INFO - 2018-10-31 18:08:26 --> Utf8 Class Initialized
INFO - 2018-10-31 18:08:26 --> URI Class Initialized
INFO - 2018-10-31 18:08:26 --> Router Class Initialized
INFO - 2018-10-31 18:08:26 --> Output Class Initialized
INFO - 2018-10-31 18:08:26 --> Security Class Initialized
DEBUG - 2018-10-31 18:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-31 18:08:26 --> CSRF cookie sent
INFO - 2018-10-31 18:08:26 --> Input Class Initialized
INFO - 2018-10-31 18:08:26 --> Language Class Initialized
INFO - 2018-10-31 18:08:26 --> Loader Class Initialized
INFO - 2018-10-31 18:08:26 --> Helper loaded: url_helper
INFO - 2018-10-31 18:08:26 --> Helper loaded: form_helper
INFO - 2018-10-31 18:08:26 --> Helper loaded: language_helper
DEBUG - 2018-10-31 18:08:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-31 18:08:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-31 18:08:26 --> User Agent Class Initialized
INFO - 2018-10-31 18:08:26 --> Controller Class Initialized
INFO - 2018-10-31 18:08:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-31 18:08:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-31 18:08:26 --> Helper loaded: custom_helper
INFO - 2018-10-31 18:08:26 --> Database Driver Class Initialized
INFO - 2018-10-31 18:08:26 --> Database Utility Class Initialized
INFO - 2018-10-31 18:08:26 --> Database Utility Class Initialized
INFO - 2018-10-31 18:08:26 --> Zip Compression Class Initialized
INFO - 2018-10-31 18:08:27 --> Helper loaded: file_helper
INFO - 2018-10-31 18:08:27 --> Final output sent to browser
DEBUG - 2018-10-31 18:08:27 --> Total execution time: 0.3032
INFO - 2018-10-31 18:09:56 --> Config Class Initialized
INFO - 2018-10-31 18:09:56 --> Hooks Class Initialized
DEBUG - 2018-10-31 18:09:56 --> UTF-8 Support Enabled
INFO - 2018-10-31 18:09:56 --> Utf8 Class Initialized
INFO - 2018-10-31 18:09:56 --> URI Class Initialized
INFO - 2018-10-31 18:09:56 --> Router Class Initialized
INFO - 2018-10-31 18:09:56 --> Output Class Initialized
INFO - 2018-10-31 18:09:56 --> Security Class Initialized
DEBUG - 2018-10-31 18:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-31 18:09:56 --> CSRF cookie sent
INFO - 2018-10-31 18:09:56 --> Input Class Initialized
INFO - 2018-10-31 18:09:56 --> Language Class Initialized
INFO - 2018-10-31 18:09:56 --> Loader Class Initialized
INFO - 2018-10-31 18:09:56 --> Helper loaded: url_helper
INFO - 2018-10-31 18:09:56 --> Helper loaded: form_helper
INFO - 2018-10-31 18:09:56 --> Helper loaded: language_helper
DEBUG - 2018-10-31 18:09:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-31 18:09:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-31 18:09:56 --> User Agent Class Initialized
INFO - 2018-10-31 18:09:56 --> Controller Class Initialized
INFO - 2018-10-31 18:09:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-31 18:09:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-31 18:09:56 --> Helper loaded: custom_helper
INFO - 2018-10-31 18:09:56 --> Database Driver Class Initialized
INFO - 2018-10-31 18:09:56 --> Database Utility Class Initialized
INFO - 2018-10-31 18:09:56 --> Database Utility Class Initialized
INFO - 2018-10-31 18:09:56 --> Zip Compression Class Initialized
INFO - 2018-10-31 18:09:56 --> Helper loaded: file_helper
INFO - 2018-10-31 18:09:56 --> Final output sent to browser
DEBUG - 2018-10-31 18:09:56 --> Total execution time: 0.3235
INFO - 2018-10-31 18:11:34 --> Config Class Initialized
INFO - 2018-10-31 18:11:34 --> Hooks Class Initialized
DEBUG - 2018-10-31 18:11:34 --> UTF-8 Support Enabled
INFO - 2018-10-31 18:11:34 --> Utf8 Class Initialized
INFO - 2018-10-31 18:11:34 --> URI Class Initialized
INFO - 2018-10-31 18:11:34 --> Router Class Initialized
INFO - 2018-10-31 18:11:34 --> Output Class Initialized
INFO - 2018-10-31 18:11:34 --> Security Class Initialized
DEBUG - 2018-10-31 18:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-31 18:11:34 --> CSRF cookie sent
INFO - 2018-10-31 18:11:34 --> Input Class Initialized
INFO - 2018-10-31 18:11:34 --> Language Class Initialized
INFO - 2018-10-31 18:11:34 --> Loader Class Initialized
INFO - 2018-10-31 18:11:34 --> Helper loaded: url_helper
INFO - 2018-10-31 18:11:34 --> Helper loaded: form_helper
INFO - 2018-10-31 18:11:34 --> Helper loaded: language_helper
DEBUG - 2018-10-31 18:11:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-31 18:11:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-31 18:11:34 --> User Agent Class Initialized
INFO - 2018-10-31 18:11:34 --> Controller Class Initialized
INFO - 2018-10-31 18:11:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-31 18:11:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-31 18:11:34 --> Helper loaded: custom_helper
INFO - 2018-10-31 18:11:34 --> Database Driver Class Initialized
INFO - 2018-10-31 18:11:35 --> Database Utility Class Initialized
INFO - 2018-10-31 18:11:35 --> Database Utility Class Initialized
INFO - 2018-10-31 18:11:35 --> Zip Compression Class Initialized
INFO - 2018-10-31 18:11:35 --> Helper loaded: file_helper
INFO - 2018-10-31 18:11:35 --> Final output sent to browser
DEBUG - 2018-10-31 18:11:35 --> Total execution time: 0.4117
INFO - 2018-10-31 18:14:55 --> Config Class Initialized
INFO - 2018-10-31 18:14:55 --> Hooks Class Initialized
DEBUG - 2018-10-31 18:14:55 --> UTF-8 Support Enabled
INFO - 2018-10-31 18:14:55 --> Utf8 Class Initialized
INFO - 2018-10-31 18:14:55 --> URI Class Initialized
INFO - 2018-10-31 18:14:55 --> Router Class Initialized
INFO - 2018-10-31 18:14:55 --> Output Class Initialized
INFO - 2018-10-31 18:14:55 --> Security Class Initialized
DEBUG - 2018-10-31 18:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-31 18:14:55 --> CSRF cookie sent
INFO - 2018-10-31 18:14:55 --> Input Class Initialized
INFO - 2018-10-31 18:14:55 --> Language Class Initialized
ERROR - 2018-10-31 18:14:55 --> Severity: error --> Exception: syntax error, unexpected '}' E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 16
INFO - 2018-10-31 18:15:05 --> Config Class Initialized
INFO - 2018-10-31 18:15:05 --> Hooks Class Initialized
DEBUG - 2018-10-31 18:15:05 --> UTF-8 Support Enabled
INFO - 2018-10-31 18:15:05 --> Utf8 Class Initialized
INFO - 2018-10-31 18:15:05 --> URI Class Initialized
INFO - 2018-10-31 18:15:05 --> Router Class Initialized
INFO - 2018-10-31 18:15:05 --> Output Class Initialized
INFO - 2018-10-31 18:15:05 --> Security Class Initialized
DEBUG - 2018-10-31 18:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-31 18:15:05 --> CSRF cookie sent
INFO - 2018-10-31 18:15:05 --> Input Class Initialized
INFO - 2018-10-31 18:15:05 --> Language Class Initialized
ERROR - 2018-10-31 18:15:05 --> Severity: error --> Exception: syntax error, unexpected '}' E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 16
INFO - 2018-10-31 18:15:52 --> Config Class Initialized
INFO - 2018-10-31 18:15:52 --> Hooks Class Initialized
DEBUG - 2018-10-31 18:15:52 --> UTF-8 Support Enabled
INFO - 2018-10-31 18:15:52 --> Utf8 Class Initialized
INFO - 2018-10-31 18:15:52 --> URI Class Initialized
INFO - 2018-10-31 18:15:52 --> Router Class Initialized
INFO - 2018-10-31 18:15:52 --> Output Class Initialized
INFO - 2018-10-31 18:15:52 --> Security Class Initialized
DEBUG - 2018-10-31 18:15:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-31 18:15:52 --> CSRF cookie sent
INFO - 2018-10-31 18:15:52 --> Input Class Initialized
INFO - 2018-10-31 18:15:52 --> Language Class Initialized
INFO - 2018-10-31 18:15:52 --> Loader Class Initialized
INFO - 2018-10-31 18:15:52 --> Helper loaded: url_helper
INFO - 2018-10-31 18:15:52 --> Helper loaded: form_helper
INFO - 2018-10-31 18:15:52 --> Helper loaded: language_helper
DEBUG - 2018-10-31 18:15:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-31 18:15:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-31 18:15:52 --> User Agent Class Initialized
INFO - 2018-10-31 18:15:52 --> Controller Class Initialized
INFO - 2018-10-31 18:15:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-31 18:15:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-31 18:15:52 --> Helper loaded: custom_helper
INFO - 2018-10-31 18:15:52 --> Final output sent to browser
DEBUG - 2018-10-31 18:15:52 --> Total execution time: 0.2389
INFO - 2018-10-31 18:16:29 --> Config Class Initialized
INFO - 2018-10-31 18:16:29 --> Hooks Class Initialized
DEBUG - 2018-10-31 18:16:29 --> UTF-8 Support Enabled
INFO - 2018-10-31 18:16:29 --> Utf8 Class Initialized
INFO - 2018-10-31 18:16:29 --> URI Class Initialized
INFO - 2018-10-31 18:16:29 --> Router Class Initialized
INFO - 2018-10-31 18:16:29 --> Output Class Initialized
INFO - 2018-10-31 18:16:29 --> Security Class Initialized
DEBUG - 2018-10-31 18:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-31 18:16:29 --> CSRF cookie sent
INFO - 2018-10-31 18:16:29 --> Input Class Initialized
INFO - 2018-10-31 18:16:29 --> Language Class Initialized
INFO - 2018-10-31 18:16:29 --> Loader Class Initialized
INFO - 2018-10-31 18:16:29 --> Helper loaded: url_helper
INFO - 2018-10-31 18:16:29 --> Helper loaded: form_helper
INFO - 2018-10-31 18:16:29 --> Helper loaded: language_helper
DEBUG - 2018-10-31 18:16:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-31 18:16:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-31 18:16:29 --> User Agent Class Initialized
INFO - 2018-10-31 18:16:29 --> Controller Class Initialized
INFO - 2018-10-31 18:16:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-31 18:16:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-31 18:16:30 --> Helper loaded: custom_helper
INFO - 2018-10-31 18:16:30 --> Final output sent to browser
DEBUG - 2018-10-31 18:16:30 --> Total execution time: 0.2449
INFO - 2018-10-31 18:16:59 --> Config Class Initialized
INFO - 2018-10-31 18:16:59 --> Hooks Class Initialized
DEBUG - 2018-10-31 18:16:59 --> UTF-8 Support Enabled
INFO - 2018-10-31 18:16:59 --> Utf8 Class Initialized
INFO - 2018-10-31 18:16:59 --> URI Class Initialized
INFO - 2018-10-31 18:16:59 --> Router Class Initialized
INFO - 2018-10-31 18:16:59 --> Output Class Initialized
INFO - 2018-10-31 18:16:59 --> Security Class Initialized
DEBUG - 2018-10-31 18:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-31 18:16:59 --> CSRF cookie sent
INFO - 2018-10-31 18:16:59 --> Input Class Initialized
INFO - 2018-10-31 18:16:59 --> Language Class Initialized
INFO - 2018-10-31 18:16:59 --> Loader Class Initialized
INFO - 2018-10-31 18:16:59 --> Helper loaded: url_helper
INFO - 2018-10-31 18:16:59 --> Helper loaded: form_helper
INFO - 2018-10-31 18:16:59 --> Helper loaded: language_helper
DEBUG - 2018-10-31 18:16:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-31 18:16:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-31 18:16:59 --> User Agent Class Initialized
INFO - 2018-10-31 18:16:59 --> Controller Class Initialized
INFO - 2018-10-31 18:16:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-31 18:16:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-31 18:16:59 --> Helper loaded: custom_helper
INFO - 2018-10-31 18:16:59 --> Final output sent to browser
DEBUG - 2018-10-31 18:16:59 --> Total execution time: 0.2242
INFO - 2018-10-31 18:17:47 --> Config Class Initialized
INFO - 2018-10-31 18:17:47 --> Hooks Class Initialized
DEBUG - 2018-10-31 18:17:47 --> UTF-8 Support Enabled
INFO - 2018-10-31 18:17:47 --> Utf8 Class Initialized
INFO - 2018-10-31 18:17:47 --> URI Class Initialized
INFO - 2018-10-31 18:17:47 --> Router Class Initialized
INFO - 2018-10-31 18:17:47 --> Output Class Initialized
INFO - 2018-10-31 18:17:47 --> Security Class Initialized
DEBUG - 2018-10-31 18:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-31 18:17:47 --> CSRF cookie sent
INFO - 2018-10-31 18:17:47 --> Input Class Initialized
INFO - 2018-10-31 18:17:47 --> Language Class Initialized
INFO - 2018-10-31 18:17:47 --> Loader Class Initialized
INFO - 2018-10-31 18:17:47 --> Helper loaded: url_helper
INFO - 2018-10-31 18:17:47 --> Helper loaded: form_helper
INFO - 2018-10-31 18:17:47 --> Helper loaded: language_helper
DEBUG - 2018-10-31 18:17:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-31 18:17:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-31 18:17:47 --> User Agent Class Initialized
INFO - 2018-10-31 18:17:47 --> Controller Class Initialized
INFO - 2018-10-31 18:17:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-31 18:17:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-31 18:17:47 --> Helper loaded: custom_helper
INFO - 2018-10-31 18:17:47 --> Final output sent to browser
DEBUG - 2018-10-31 18:17:47 --> Total execution time: 0.2367
INFO - 2018-10-31 18:18:24 --> Config Class Initialized
INFO - 2018-10-31 18:18:24 --> Hooks Class Initialized
DEBUG - 2018-10-31 18:18:24 --> UTF-8 Support Enabled
INFO - 2018-10-31 18:18:24 --> Utf8 Class Initialized
INFO - 2018-10-31 18:18:24 --> URI Class Initialized
INFO - 2018-10-31 18:18:24 --> Router Class Initialized
INFO - 2018-10-31 18:18:24 --> Output Class Initialized
INFO - 2018-10-31 18:18:24 --> Security Class Initialized
DEBUG - 2018-10-31 18:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-31 18:18:24 --> CSRF cookie sent
INFO - 2018-10-31 18:18:24 --> Input Class Initialized
INFO - 2018-10-31 18:18:24 --> Language Class Initialized
ERROR - 2018-10-31 18:18:24 --> Severity: error --> Exception: syntax error, unexpected ')' E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 58
INFO - 2018-10-31 18:19:29 --> Config Class Initialized
INFO - 2018-10-31 18:19:29 --> Hooks Class Initialized
DEBUG - 2018-10-31 18:19:29 --> UTF-8 Support Enabled
INFO - 2018-10-31 18:19:29 --> Utf8 Class Initialized
INFO - 2018-10-31 18:19:29 --> URI Class Initialized
INFO - 2018-10-31 18:19:29 --> Router Class Initialized
INFO - 2018-10-31 18:19:29 --> Output Class Initialized
INFO - 2018-10-31 18:19:29 --> Security Class Initialized
DEBUG - 2018-10-31 18:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-31 18:19:29 --> CSRF cookie sent
INFO - 2018-10-31 18:19:29 --> Input Class Initialized
INFO - 2018-10-31 18:19:29 --> Language Class Initialized
ERROR - 2018-10-31 18:19:29 --> Severity: error --> Exception: syntax error, unexpected ')' E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 58
INFO - 2018-10-31 18:19:42 --> Config Class Initialized
INFO - 2018-10-31 18:19:42 --> Hooks Class Initialized
DEBUG - 2018-10-31 18:19:42 --> UTF-8 Support Enabled
INFO - 2018-10-31 18:19:42 --> Utf8 Class Initialized
INFO - 2018-10-31 18:19:42 --> URI Class Initialized
INFO - 2018-10-31 18:19:42 --> Router Class Initialized
INFO - 2018-10-31 18:19:42 --> Output Class Initialized
INFO - 2018-10-31 18:19:42 --> Security Class Initialized
DEBUG - 2018-10-31 18:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-31 18:19:42 --> CSRF cookie sent
INFO - 2018-10-31 18:19:42 --> Input Class Initialized
INFO - 2018-10-31 18:19:42 --> Language Class Initialized
ERROR - 2018-10-31 18:19:42 --> Severity: error --> Exception: syntax error, unexpected ')' E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 75
INFO - 2018-10-31 18:19:50 --> Config Class Initialized
INFO - 2018-10-31 18:19:50 --> Hooks Class Initialized
DEBUG - 2018-10-31 18:19:50 --> UTF-8 Support Enabled
INFO - 2018-10-31 18:19:50 --> Utf8 Class Initialized
INFO - 2018-10-31 18:19:50 --> URI Class Initialized
INFO - 2018-10-31 18:19:51 --> Router Class Initialized
INFO - 2018-10-31 18:19:51 --> Output Class Initialized
INFO - 2018-10-31 18:19:51 --> Security Class Initialized
DEBUG - 2018-10-31 18:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-31 18:19:51 --> CSRF cookie sent
INFO - 2018-10-31 18:19:51 --> Input Class Initialized
INFO - 2018-10-31 18:19:51 --> Language Class Initialized
INFO - 2018-10-31 18:19:51 --> Loader Class Initialized
INFO - 2018-10-31 18:19:51 --> Helper loaded: url_helper
INFO - 2018-10-31 18:19:51 --> Helper loaded: form_helper
INFO - 2018-10-31 18:19:51 --> Helper loaded: language_helper
DEBUG - 2018-10-31 18:19:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-31 18:19:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-31 18:19:51 --> User Agent Class Initialized
INFO - 2018-10-31 18:19:51 --> Controller Class Initialized
INFO - 2018-10-31 18:19:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-31 18:19:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-31 18:19:51 --> Helper loaded: custom_helper
INFO - 2018-10-31 18:19:51 --> Final output sent to browser
DEBUG - 2018-10-31 18:19:51 --> Total execution time: 0.2403
INFO - 2018-10-31 18:20:22 --> Config Class Initialized
INFO - 2018-10-31 18:20:22 --> Hooks Class Initialized
DEBUG - 2018-10-31 18:20:22 --> UTF-8 Support Enabled
INFO - 2018-10-31 18:20:22 --> Utf8 Class Initialized
INFO - 2018-10-31 18:20:22 --> URI Class Initialized
INFO - 2018-10-31 18:20:22 --> Router Class Initialized
INFO - 2018-10-31 18:20:22 --> Output Class Initialized
INFO - 2018-10-31 18:20:22 --> Security Class Initialized
DEBUG - 2018-10-31 18:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-31 18:20:22 --> CSRF cookie sent
INFO - 2018-10-31 18:20:22 --> Input Class Initialized
INFO - 2018-10-31 18:20:22 --> Language Class Initialized
INFO - 2018-10-31 18:20:22 --> Loader Class Initialized
INFO - 2018-10-31 18:20:22 --> Helper loaded: url_helper
INFO - 2018-10-31 18:20:22 --> Helper loaded: form_helper
INFO - 2018-10-31 18:20:22 --> Helper loaded: language_helper
DEBUG - 2018-10-31 18:20:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-31 18:20:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-31 18:20:22 --> User Agent Class Initialized
INFO - 2018-10-31 18:20:22 --> Controller Class Initialized
INFO - 2018-10-31 18:20:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-31 18:20:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-31 18:20:22 --> Helper loaded: custom_helper
ERROR - 2018-10-31 18:20:22 --> Severity: error --> Exception: Call to undefined function directory_map() E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 66
INFO - 2018-10-31 18:20:38 --> Config Class Initialized
INFO - 2018-10-31 18:20:38 --> Hooks Class Initialized
DEBUG - 2018-10-31 18:20:39 --> UTF-8 Support Enabled
INFO - 2018-10-31 18:20:39 --> Utf8 Class Initialized
INFO - 2018-10-31 18:20:39 --> URI Class Initialized
INFO - 2018-10-31 18:20:39 --> Router Class Initialized
INFO - 2018-10-31 18:20:39 --> Output Class Initialized
INFO - 2018-10-31 18:20:39 --> Security Class Initialized
DEBUG - 2018-10-31 18:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-31 18:20:39 --> CSRF cookie sent
INFO - 2018-10-31 18:20:39 --> Input Class Initialized
INFO - 2018-10-31 18:20:39 --> Language Class Initialized
INFO - 2018-10-31 18:20:39 --> Loader Class Initialized
INFO - 2018-10-31 18:20:39 --> Helper loaded: url_helper
INFO - 2018-10-31 18:20:39 --> Helper loaded: form_helper
INFO - 2018-10-31 18:20:39 --> Helper loaded: language_helper
DEBUG - 2018-10-31 18:20:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-31 18:20:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-31 18:20:39 --> User Agent Class Initialized
INFO - 2018-10-31 18:20:39 --> Controller Class Initialized
INFO - 2018-10-31 18:20:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-31 18:20:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-31 18:20:39 --> Helper loaded: custom_helper
INFO - 2018-10-31 18:20:39 --> Helper loaded: directory_helper
ERROR - 2018-10-31 18:20:39 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 69
INFO - 2018-10-31 18:20:39 --> Final output sent to browser
DEBUG - 2018-10-31 18:20:39 --> Total execution time: 0.2727
INFO - 2018-10-31 18:21:37 --> Config Class Initialized
INFO - 2018-10-31 18:21:37 --> Hooks Class Initialized
DEBUG - 2018-10-31 18:21:37 --> UTF-8 Support Enabled
INFO - 2018-10-31 18:21:37 --> Utf8 Class Initialized
INFO - 2018-10-31 18:21:37 --> URI Class Initialized
INFO - 2018-10-31 18:21:37 --> Router Class Initialized
INFO - 2018-10-31 18:21:37 --> Output Class Initialized
INFO - 2018-10-31 18:21:37 --> Security Class Initialized
DEBUG - 2018-10-31 18:21:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-31 18:21:37 --> CSRF cookie sent
INFO - 2018-10-31 18:21:37 --> Input Class Initialized
INFO - 2018-10-31 18:21:37 --> Language Class Initialized
INFO - 2018-10-31 18:21:37 --> Loader Class Initialized
INFO - 2018-10-31 18:21:37 --> Helper loaded: url_helper
INFO - 2018-10-31 18:21:37 --> Helper loaded: form_helper
INFO - 2018-10-31 18:21:37 --> Helper loaded: language_helper
DEBUG - 2018-10-31 18:21:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-31 18:21:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-31 18:21:37 --> User Agent Class Initialized
INFO - 2018-10-31 18:21:37 --> Controller Class Initialized
INFO - 2018-10-31 18:21:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-31 18:21:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-31 18:21:37 --> Helper loaded: custom_helper
INFO - 2018-10-31 18:21:37 --> Helper loaded: directory_helper
INFO - 2018-10-31 18:22:13 --> Config Class Initialized
INFO - 2018-10-31 18:22:13 --> Hooks Class Initialized
DEBUG - 2018-10-31 18:22:13 --> UTF-8 Support Enabled
INFO - 2018-10-31 18:22:13 --> Utf8 Class Initialized
INFO - 2018-10-31 18:22:13 --> URI Class Initialized
INFO - 2018-10-31 18:22:13 --> Router Class Initialized
INFO - 2018-10-31 18:22:13 --> Output Class Initialized
INFO - 2018-10-31 18:22:13 --> Security Class Initialized
DEBUG - 2018-10-31 18:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-31 18:22:13 --> CSRF cookie sent
INFO - 2018-10-31 18:22:13 --> Input Class Initialized
INFO - 2018-10-31 18:22:13 --> Language Class Initialized
INFO - 2018-10-31 18:22:13 --> Loader Class Initialized
INFO - 2018-10-31 18:22:13 --> Helper loaded: url_helper
INFO - 2018-10-31 18:22:13 --> Helper loaded: form_helper
INFO - 2018-10-31 18:22:13 --> Helper loaded: language_helper
DEBUG - 2018-10-31 18:22:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-31 18:22:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-31 18:22:13 --> User Agent Class Initialized
INFO - 2018-10-31 18:22:13 --> Controller Class Initialized
INFO - 2018-10-31 18:22:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-31 18:22:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-31 18:22:13 --> Helper loaded: custom_helper
INFO - 2018-10-31 18:22:43 --> Config Class Initialized
INFO - 2018-10-31 18:22:43 --> Hooks Class Initialized
DEBUG - 2018-10-31 18:22:43 --> UTF-8 Support Enabled
INFO - 2018-10-31 18:22:43 --> Utf8 Class Initialized
INFO - 2018-10-31 18:22:43 --> URI Class Initialized
INFO - 2018-10-31 18:22:43 --> Router Class Initialized
INFO - 2018-10-31 18:22:43 --> Output Class Initialized
INFO - 2018-10-31 18:22:43 --> Security Class Initialized
DEBUG - 2018-10-31 18:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-31 18:22:43 --> CSRF cookie sent
INFO - 2018-10-31 18:22:43 --> Input Class Initialized
INFO - 2018-10-31 18:22:43 --> Language Class Initialized
INFO - 2018-10-31 18:22:43 --> Loader Class Initialized
INFO - 2018-10-31 18:22:43 --> Helper loaded: url_helper
INFO - 2018-10-31 18:22:43 --> Helper loaded: form_helper
INFO - 2018-10-31 18:22:43 --> Helper loaded: language_helper
DEBUG - 2018-10-31 18:22:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-31 18:22:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-31 18:22:43 --> User Agent Class Initialized
INFO - 2018-10-31 18:22:43 --> Config Class Initialized
INFO - 2018-10-31 18:22:43 --> Hooks Class Initialized
INFO - 2018-10-31 18:22:43 --> Controller Class Initialized
INFO - 2018-10-31 18:22:43 --> Language file loaded: language/en/common_lang.php
DEBUG - 2018-10-31 18:22:43 --> UTF-8 Support Enabled
INFO - 2018-10-31 18:22:43 --> Utf8 Class Initialized
INFO - 2018-10-31 18:22:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-31 18:22:43 --> URI Class Initialized
INFO - 2018-10-31 18:22:43 --> Helper loaded: custom_helper
INFO - 2018-10-31 18:22:43 --> Helper loaded: directory_helper
INFO - 2018-10-31 18:22:43 --> Router Class Initialized
ERROR - 2018-10-31 18:22:43 --> Severity: Notice --> Undefined variable: srcdir E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 15
INFO - 2018-10-31 18:22:43 --> Output Class Initialized
ERROR - 2018-10-31 18:22:43 --> Severity: Notice --> Undefined variable: dstdir E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 16
INFO - 2018-10-31 18:22:43 --> Security Class Initialized
ERROR - 2018-10-31 18:22:43 --> Severity: Warning --> mkdir(): Invalid path E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 19
DEBUG - 2018-10-31 18:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-31 18:22:43 --> CSRF cookie sent
INFO - 2018-10-31 18:22:43 --> Input Class Initialized
INFO - 2018-10-31 18:22:43 --> Language Class Initialized
INFO - 2018-10-31 18:22:43 --> Loader Class Initialized
INFO - 2018-10-31 18:22:43 --> Helper loaded: url_helper
INFO - 2018-10-31 18:22:43 --> Helper loaded: form_helper
INFO - 2018-10-31 18:22:43 --> Helper loaded: language_helper
DEBUG - 2018-10-31 18:22:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-31 18:22:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-31 18:22:43 --> User Agent Class Initialized
INFO - 2018-10-31 18:22:43 --> Controller Class Initialized
INFO - 2018-10-31 18:22:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-31 18:22:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-31 18:22:43 --> Helper loaded: custom_helper
INFO - 2018-10-31 18:22:43 --> Helper loaded: directory_helper
ERROR - 2018-10-31 18:22:43 --> Severity: Notice --> Undefined variable: srcdir E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 15
ERROR - 2018-10-31 18:22:43 --> Severity: Notice --> Undefined variable: dstdir E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 16
ERROR - 2018-10-31 18:22:43 --> Severity: Warning --> mkdir(): Invalid path E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 19
INFO - 2018-10-31 18:23:00 --> Config Class Initialized
INFO - 2018-10-31 18:23:00 --> Hooks Class Initialized
DEBUG - 2018-10-31 18:23:00 --> UTF-8 Support Enabled
INFO - 2018-10-31 18:23:00 --> Utf8 Class Initialized
INFO - 2018-10-31 18:23:00 --> URI Class Initialized
INFO - 2018-10-31 18:23:00 --> Router Class Initialized
INFO - 2018-10-31 18:23:00 --> Output Class Initialized
INFO - 2018-10-31 18:23:00 --> Security Class Initialized
DEBUG - 2018-10-31 18:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-31 18:23:00 --> CSRF cookie sent
INFO - 2018-10-31 18:23:00 --> Input Class Initialized
INFO - 2018-10-31 18:23:00 --> Language Class Initialized
INFO - 2018-10-31 18:23:00 --> Loader Class Initialized
INFO - 2018-10-31 18:23:00 --> Helper loaded: url_helper
INFO - 2018-10-31 18:23:00 --> Helper loaded: form_helper
INFO - 2018-10-31 18:23:00 --> Helper loaded: language_helper
DEBUG - 2018-10-31 18:23:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-31 18:23:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-31 18:23:00 --> User Agent Class Initialized
INFO - 2018-10-31 18:23:00 --> Controller Class Initialized
INFO - 2018-10-31 18:23:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-31 18:23:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-31 18:23:00 --> Helper loaded: custom_helper
INFO - 2018-10-31 18:23:00 --> Helper loaded: directory_helper
INFO - 2018-10-31 18:23:20 --> Config Class Initialized
INFO - 2018-10-31 18:23:20 --> Hooks Class Initialized
DEBUG - 2018-10-31 18:23:20 --> UTF-8 Support Enabled
INFO - 2018-10-31 18:23:20 --> Utf8 Class Initialized
INFO - 2018-10-31 18:23:20 --> URI Class Initialized
INFO - 2018-10-31 18:23:20 --> Router Class Initialized
INFO - 2018-10-31 18:23:20 --> Output Class Initialized
INFO - 2018-10-31 18:23:20 --> Security Class Initialized
DEBUG - 2018-10-31 18:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-31 18:23:20 --> CSRF cookie sent
INFO - 2018-10-31 18:23:20 --> Input Class Initialized
INFO - 2018-10-31 18:23:20 --> Language Class Initialized
INFO - 2018-10-31 18:23:20 --> Loader Class Initialized
INFO - 2018-10-31 18:23:20 --> Helper loaded: url_helper
INFO - 2018-10-31 18:23:20 --> Helper loaded: form_helper
INFO - 2018-10-31 18:23:20 --> Helper loaded: language_helper
DEBUG - 2018-10-31 18:23:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-31 18:23:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-31 18:23:20 --> User Agent Class Initialized
INFO - 2018-10-31 18:23:20 --> Controller Class Initialized
INFO - 2018-10-31 18:23:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-31 18:23:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-31 18:23:21 --> Helper loaded: custom_helper
INFO - 2018-10-31 18:23:21 --> Helper loaded: directory_helper
INFO - 2018-10-31 18:24:17 --> Config Class Initialized
INFO - 2018-10-31 18:24:17 --> Hooks Class Initialized
DEBUG - 2018-10-31 18:24:17 --> UTF-8 Support Enabled
INFO - 2018-10-31 18:24:17 --> Utf8 Class Initialized
INFO - 2018-10-31 18:24:17 --> URI Class Initialized
INFO - 2018-10-31 18:24:17 --> Router Class Initialized
INFO - 2018-10-31 18:24:17 --> Output Class Initialized
INFO - 2018-10-31 18:24:17 --> Security Class Initialized
DEBUG - 2018-10-31 18:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-31 18:24:17 --> CSRF cookie sent
INFO - 2018-10-31 18:24:17 --> Input Class Initialized
INFO - 2018-10-31 18:24:17 --> Language Class Initialized
INFO - 2018-10-31 18:24:17 --> Loader Class Initialized
INFO - 2018-10-31 18:24:17 --> Helper loaded: url_helper
INFO - 2018-10-31 18:24:17 --> Helper loaded: form_helper
INFO - 2018-10-31 18:24:17 --> Helper loaded: language_helper
DEBUG - 2018-10-31 18:24:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-31 18:24:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-31 18:24:17 --> User Agent Class Initialized
INFO - 2018-10-31 18:24:17 --> Controller Class Initialized
INFO - 2018-10-31 18:24:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-31 18:24:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-31 18:24:17 --> Helper loaded: custom_helper
INFO - 2018-10-31 18:24:17 --> Helper loaded: directory_helper
INFO - 2018-10-31 18:25:07 --> Config Class Initialized
INFO - 2018-10-31 18:25:07 --> Hooks Class Initialized
DEBUG - 2018-10-31 18:25:07 --> UTF-8 Support Enabled
INFO - 2018-10-31 18:25:07 --> Utf8 Class Initialized
INFO - 2018-10-31 18:25:07 --> URI Class Initialized
INFO - 2018-10-31 18:25:07 --> Router Class Initialized
INFO - 2018-10-31 18:25:07 --> Output Class Initialized
INFO - 2018-10-31 18:25:07 --> Security Class Initialized
DEBUG - 2018-10-31 18:25:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-31 18:25:07 --> CSRF cookie sent
INFO - 2018-10-31 18:25:07 --> Input Class Initialized
INFO - 2018-10-31 18:25:07 --> Language Class Initialized
INFO - 2018-10-31 18:25:07 --> Loader Class Initialized
INFO - 2018-10-31 18:25:07 --> Helper loaded: url_helper
INFO - 2018-10-31 18:25:07 --> Helper loaded: form_helper
INFO - 2018-10-31 18:25:07 --> Helper loaded: language_helper
DEBUG - 2018-10-31 18:25:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-31 18:25:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-31 18:25:07 --> User Agent Class Initialized
INFO - 2018-10-31 18:25:07 --> Controller Class Initialized
INFO - 2018-10-31 18:25:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-31 18:25:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-31 18:25:07 --> Helper loaded: custom_helper
INFO - 2018-10-31 18:25:07 --> Helper loaded: directory_helper
INFO - 2018-10-31 18:25:21 --> Config Class Initialized
INFO - 2018-10-31 18:25:21 --> Hooks Class Initialized
DEBUG - 2018-10-31 18:25:21 --> UTF-8 Support Enabled
INFO - 2018-10-31 18:25:21 --> Utf8 Class Initialized
INFO - 2018-10-31 18:25:21 --> URI Class Initialized
INFO - 2018-10-31 18:25:21 --> Router Class Initialized
INFO - 2018-10-31 18:25:21 --> Output Class Initialized
INFO - 2018-10-31 18:25:21 --> Security Class Initialized
DEBUG - 2018-10-31 18:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-31 18:25:21 --> CSRF cookie sent
INFO - 2018-10-31 18:25:21 --> Input Class Initialized
INFO - 2018-10-31 18:25:21 --> Language Class Initialized
INFO - 2018-10-31 18:25:21 --> Loader Class Initialized
INFO - 2018-10-31 18:25:21 --> Helper loaded: url_helper
INFO - 2018-10-31 18:25:21 --> Helper loaded: form_helper
INFO - 2018-10-31 18:25:21 --> Helper loaded: language_helper
DEBUG - 2018-10-31 18:25:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-31 18:25:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-31 18:25:21 --> User Agent Class Initialized
INFO - 2018-10-31 18:25:21 --> Controller Class Initialized
INFO - 2018-10-31 18:25:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-31 18:25:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-31 18:25:21 --> Helper loaded: custom_helper
INFO - 2018-10-31 18:25:21 --> Helper loaded: directory_helper
INFO - 2018-10-31 18:26:11 --> Config Class Initialized
INFO - 2018-10-31 18:26:11 --> Hooks Class Initialized
DEBUG - 2018-10-31 18:26:11 --> UTF-8 Support Enabled
INFO - 2018-10-31 18:26:11 --> Utf8 Class Initialized
INFO - 2018-10-31 18:26:11 --> URI Class Initialized
INFO - 2018-10-31 18:26:11 --> Router Class Initialized
INFO - 2018-10-31 18:26:11 --> Output Class Initialized
INFO - 2018-10-31 18:26:11 --> Security Class Initialized
DEBUG - 2018-10-31 18:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-31 18:26:11 --> CSRF cookie sent
INFO - 2018-10-31 18:26:11 --> Input Class Initialized
INFO - 2018-10-31 18:26:11 --> Language Class Initialized
INFO - 2018-10-31 18:26:11 --> Loader Class Initialized
INFO - 2018-10-31 18:26:11 --> Helper loaded: url_helper
INFO - 2018-10-31 18:26:11 --> Helper loaded: form_helper
INFO - 2018-10-31 18:26:11 --> Helper loaded: language_helper
DEBUG - 2018-10-31 18:26:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-31 18:26:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-31 18:26:11 --> User Agent Class Initialized
INFO - 2018-10-31 18:26:11 --> Controller Class Initialized
INFO - 2018-10-31 18:26:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-31 18:26:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-31 18:26:11 --> Helper loaded: custom_helper
INFO - 2018-10-31 18:26:11 --> Helper loaded: directory_helper
INFO - 2018-10-31 18:26:51 --> Config Class Initialized
INFO - 2018-10-31 18:26:51 --> Hooks Class Initialized
DEBUG - 2018-10-31 18:26:51 --> UTF-8 Support Enabled
INFO - 2018-10-31 18:26:51 --> Utf8 Class Initialized
INFO - 2018-10-31 18:26:51 --> URI Class Initialized
INFO - 2018-10-31 18:26:51 --> Router Class Initialized
INFO - 2018-10-31 18:26:51 --> Output Class Initialized
INFO - 2018-10-31 18:26:51 --> Security Class Initialized
DEBUG - 2018-10-31 18:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-31 18:26:51 --> CSRF cookie sent
INFO - 2018-10-31 18:26:51 --> Input Class Initialized
INFO - 2018-10-31 18:26:51 --> Language Class Initialized
INFO - 2018-10-31 18:26:51 --> Loader Class Initialized
INFO - 2018-10-31 18:26:51 --> Helper loaded: url_helper
INFO - 2018-10-31 18:26:51 --> Helper loaded: form_helper
INFO - 2018-10-31 18:26:51 --> Helper loaded: language_helper
DEBUG - 2018-10-31 18:26:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-31 18:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-31 18:26:51 --> User Agent Class Initialized
INFO - 2018-10-31 18:26:51 --> Controller Class Initialized
INFO - 2018-10-31 18:26:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-31 18:26:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-31 18:26:51 --> Helper loaded: custom_helper
INFO - 2018-10-31 18:26:51 --> Helper loaded: directory_helper
INFO - 2018-10-31 18:27:37 --> Config Class Initialized
INFO - 2018-10-31 18:27:37 --> Hooks Class Initialized
DEBUG - 2018-10-31 18:27:37 --> UTF-8 Support Enabled
INFO - 2018-10-31 18:27:37 --> Utf8 Class Initialized
INFO - 2018-10-31 18:27:37 --> URI Class Initialized
INFO - 2018-10-31 18:27:37 --> Router Class Initialized
INFO - 2018-10-31 18:27:37 --> Output Class Initialized
INFO - 2018-10-31 18:27:37 --> Security Class Initialized
DEBUG - 2018-10-31 18:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-31 18:27:37 --> CSRF cookie sent
INFO - 2018-10-31 18:27:37 --> Input Class Initialized
INFO - 2018-10-31 18:27:37 --> Language Class Initialized
INFO - 2018-10-31 18:27:37 --> Loader Class Initialized
INFO - 2018-10-31 18:27:37 --> Helper loaded: url_helper
INFO - 2018-10-31 18:27:37 --> Helper loaded: form_helper
INFO - 2018-10-31 18:27:37 --> Helper loaded: language_helper
DEBUG - 2018-10-31 18:27:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-31 18:27:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-31 18:27:37 --> User Agent Class Initialized
INFO - 2018-10-31 18:27:37 --> Controller Class Initialized
INFO - 2018-10-31 18:27:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-31 18:27:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-31 18:27:37 --> Helper loaded: custom_helper
INFO - 2018-10-31 18:27:37 --> Helper loaded: directory_helper
INFO - 2018-10-31 18:28:30 --> Config Class Initialized
INFO - 2018-10-31 18:28:30 --> Hooks Class Initialized
DEBUG - 2018-10-31 18:28:30 --> UTF-8 Support Enabled
INFO - 2018-10-31 18:28:30 --> Utf8 Class Initialized
INFO - 2018-10-31 18:28:30 --> URI Class Initialized
INFO - 2018-10-31 18:28:30 --> Router Class Initialized
INFO - 2018-10-31 18:28:30 --> Output Class Initialized
INFO - 2018-10-31 18:28:30 --> Security Class Initialized
DEBUG - 2018-10-31 18:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-31 18:28:30 --> CSRF cookie sent
INFO - 2018-10-31 18:28:30 --> Input Class Initialized
INFO - 2018-10-31 18:28:30 --> Language Class Initialized
INFO - 2018-10-31 18:28:30 --> Loader Class Initialized
INFO - 2018-10-31 18:28:30 --> Helper loaded: url_helper
INFO - 2018-10-31 18:28:30 --> Helper loaded: form_helper
INFO - 2018-10-31 18:28:30 --> Helper loaded: language_helper
DEBUG - 2018-10-31 18:28:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-31 18:28:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-31 18:28:31 --> User Agent Class Initialized
INFO - 2018-10-31 18:28:31 --> Controller Class Initialized
INFO - 2018-10-31 18:28:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-31 18:28:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-31 18:28:31 --> Helper loaded: custom_helper
INFO - 2018-10-31 18:28:31 --> Helper loaded: directory_helper
INFO - 2018-10-31 18:29:26 --> Config Class Initialized
INFO - 2018-10-31 18:29:26 --> Hooks Class Initialized
DEBUG - 2018-10-31 18:29:26 --> UTF-8 Support Enabled
INFO - 2018-10-31 18:29:26 --> Utf8 Class Initialized
INFO - 2018-10-31 18:29:26 --> URI Class Initialized
INFO - 2018-10-31 18:29:26 --> Router Class Initialized
INFO - 2018-10-31 18:29:26 --> Output Class Initialized
INFO - 2018-10-31 18:29:27 --> Security Class Initialized
DEBUG - 2018-10-31 18:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-31 18:29:27 --> CSRF cookie sent
INFO - 2018-10-31 18:29:27 --> Input Class Initialized
INFO - 2018-10-31 18:29:27 --> Language Class Initialized
INFO - 2018-10-31 18:29:27 --> Loader Class Initialized
INFO - 2018-10-31 18:29:27 --> Helper loaded: url_helper
INFO - 2018-10-31 18:29:27 --> Helper loaded: form_helper
INFO - 2018-10-31 18:29:27 --> Helper loaded: language_helper
DEBUG - 2018-10-31 18:29:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-31 18:29:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-31 18:29:27 --> User Agent Class Initialized
INFO - 2018-10-31 18:29:27 --> Controller Class Initialized
INFO - 2018-10-31 18:29:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-31 18:29:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-31 18:29:27 --> Helper loaded: custom_helper
INFO - 2018-10-31 18:29:27 --> Helper loaded: directory_helper
INFO - 2018-10-31 18:29:40 --> Config Class Initialized
INFO - 2018-10-31 18:29:40 --> Hooks Class Initialized
DEBUG - 2018-10-31 18:29:40 --> UTF-8 Support Enabled
INFO - 2018-10-31 18:29:40 --> Utf8 Class Initialized
INFO - 2018-10-31 18:29:40 --> URI Class Initialized
INFO - 2018-10-31 18:29:40 --> Router Class Initialized
INFO - 2018-10-31 18:29:40 --> Output Class Initialized
INFO - 2018-10-31 18:29:40 --> Security Class Initialized
DEBUG - 2018-10-31 18:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-31 18:29:40 --> CSRF cookie sent
INFO - 2018-10-31 18:29:40 --> Input Class Initialized
INFO - 2018-10-31 18:29:40 --> Language Class Initialized
INFO - 2018-10-31 18:29:40 --> Loader Class Initialized
INFO - 2018-10-31 18:29:40 --> Helper loaded: url_helper
INFO - 2018-10-31 18:29:40 --> Helper loaded: form_helper
INFO - 2018-10-31 18:29:40 --> Helper loaded: language_helper
DEBUG - 2018-10-31 18:29:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-31 18:29:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-31 18:29:40 --> User Agent Class Initialized
INFO - 2018-10-31 18:29:40 --> Controller Class Initialized
INFO - 2018-10-31 18:29:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-31 18:29:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-31 18:29:40 --> Helper loaded: custom_helper
INFO - 2018-10-31 18:29:40 --> Helper loaded: directory_helper
ERROR - 2018-10-31 18:29:40 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 35
INFO - 2018-10-31 18:29:40 --> Final output sent to browser
DEBUG - 2018-10-31 18:29:40 --> Total execution time: 0.2749
INFO - 2018-10-31 18:29:50 --> Config Class Initialized
INFO - 2018-10-31 18:29:50 --> Hooks Class Initialized
DEBUG - 2018-10-31 18:29:50 --> UTF-8 Support Enabled
INFO - 2018-10-31 18:29:50 --> Utf8 Class Initialized
INFO - 2018-10-31 18:29:50 --> URI Class Initialized
INFO - 2018-10-31 18:29:50 --> Router Class Initialized
INFO - 2018-10-31 18:29:50 --> Output Class Initialized
INFO - 2018-10-31 18:29:50 --> Security Class Initialized
DEBUG - 2018-10-31 18:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-31 18:29:50 --> CSRF cookie sent
INFO - 2018-10-31 18:29:50 --> Input Class Initialized
INFO - 2018-10-31 18:29:50 --> Language Class Initialized
INFO - 2018-10-31 18:29:50 --> Loader Class Initialized
INFO - 2018-10-31 18:29:50 --> Helper loaded: url_helper
INFO - 2018-10-31 18:29:50 --> Helper loaded: form_helper
INFO - 2018-10-31 18:29:50 --> Helper loaded: language_helper
DEBUG - 2018-10-31 18:29:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-31 18:29:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-31 18:29:50 --> User Agent Class Initialized
INFO - 2018-10-31 18:29:50 --> Controller Class Initialized
INFO - 2018-10-31 18:29:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-31 18:29:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-31 18:29:50 --> Helper loaded: custom_helper
INFO - 2018-10-31 18:29:50 --> Helper loaded: directory_helper
ERROR - 2018-10-31 18:29:50 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 32
INFO - 2018-10-31 18:29:50 --> Final output sent to browser
DEBUG - 2018-10-31 18:29:50 --> Total execution time: 0.2777
INFO - 2018-10-31 18:30:05 --> Config Class Initialized
INFO - 2018-10-31 18:30:05 --> Hooks Class Initialized
DEBUG - 2018-10-31 18:30:05 --> UTF-8 Support Enabled
INFO - 2018-10-31 18:30:05 --> Utf8 Class Initialized
INFO - 2018-10-31 18:30:05 --> URI Class Initialized
INFO - 2018-10-31 18:30:05 --> Router Class Initialized
INFO - 2018-10-31 18:30:05 --> Output Class Initialized
INFO - 2018-10-31 18:30:05 --> Security Class Initialized
DEBUG - 2018-10-31 18:30:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-31 18:30:05 --> CSRF cookie sent
INFO - 2018-10-31 18:30:05 --> Input Class Initialized
INFO - 2018-10-31 18:30:05 --> Language Class Initialized
INFO - 2018-10-31 18:30:05 --> Loader Class Initialized
INFO - 2018-10-31 18:30:05 --> Helper loaded: url_helper
INFO - 2018-10-31 18:30:05 --> Helper loaded: form_helper
INFO - 2018-10-31 18:30:05 --> Helper loaded: language_helper
DEBUG - 2018-10-31 18:30:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-31 18:30:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-31 18:30:05 --> User Agent Class Initialized
INFO - 2018-10-31 18:30:05 --> Controller Class Initialized
INFO - 2018-10-31 18:30:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-31 18:30:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-31 18:30:05 --> Helper loaded: custom_helper
INFO - 2018-10-31 18:30:05 --> Helper loaded: directory_helper
INFO - 2018-10-31 18:30:41 --> Config Class Initialized
INFO - 2018-10-31 18:30:41 --> Hooks Class Initialized
DEBUG - 2018-10-31 18:30:41 --> UTF-8 Support Enabled
INFO - 2018-10-31 18:30:41 --> Utf8 Class Initialized
INFO - 2018-10-31 18:30:41 --> URI Class Initialized
INFO - 2018-10-31 18:30:41 --> Router Class Initialized
INFO - 2018-10-31 18:30:41 --> Output Class Initialized
INFO - 2018-10-31 18:30:41 --> Security Class Initialized
DEBUG - 2018-10-31 18:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-31 18:30:41 --> CSRF cookie sent
INFO - 2018-10-31 18:30:41 --> Input Class Initialized
INFO - 2018-10-31 18:30:41 --> Language Class Initialized
INFO - 2018-10-31 18:30:41 --> Loader Class Initialized
INFO - 2018-10-31 18:30:41 --> Helper loaded: url_helper
INFO - 2018-10-31 18:30:41 --> Helper loaded: form_helper
INFO - 2018-10-31 18:30:41 --> Helper loaded: language_helper
DEBUG - 2018-10-31 18:30:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-31 18:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-31 18:30:41 --> User Agent Class Initialized
INFO - 2018-10-31 18:30:41 --> Controller Class Initialized
INFO - 2018-10-31 18:30:41 --> Helper loaded: directory_helper
INFO - 2018-10-31 18:30:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-31 18:30:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-31 18:30:41 --> Helper loaded: custom_helper
INFO - 2018-10-31 18:31:08 --> Config Class Initialized
INFO - 2018-10-31 18:31:08 --> Hooks Class Initialized
DEBUG - 2018-10-31 18:31:08 --> UTF-8 Support Enabled
INFO - 2018-10-31 18:31:08 --> Utf8 Class Initialized
INFO - 2018-10-31 18:31:08 --> URI Class Initialized
INFO - 2018-10-31 18:31:08 --> Router Class Initialized
INFO - 2018-10-31 18:31:08 --> Output Class Initialized
INFO - 2018-10-31 18:31:08 --> Security Class Initialized
DEBUG - 2018-10-31 18:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-31 18:31:08 --> CSRF cookie sent
INFO - 2018-10-31 18:31:08 --> Input Class Initialized
INFO - 2018-10-31 18:31:08 --> Language Class Initialized
INFO - 2018-10-31 18:31:08 --> Loader Class Initialized
INFO - 2018-10-31 18:31:08 --> Helper loaded: url_helper
INFO - 2018-10-31 18:31:08 --> Helper loaded: form_helper
INFO - 2018-10-31 18:31:08 --> Helper loaded: language_helper
DEBUG - 2018-10-31 18:31:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-31 18:31:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-31 18:31:08 --> User Agent Class Initialized
INFO - 2018-10-31 18:31:08 --> Controller Class Initialized
INFO - 2018-10-31 18:31:08 --> Helper loaded: directory_helper
INFO - 2018-10-31 18:31:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-31 18:31:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-31 18:31:08 --> Helper loaded: custom_helper
ERROR - 2018-10-31 18:31:08 --> Severity: Notice --> Array to string conversion E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 29
INFO - 2018-10-31 18:31:14 --> Config Class Initialized
INFO - 2018-10-31 18:31:14 --> Hooks Class Initialized
DEBUG - 2018-10-31 18:31:14 --> UTF-8 Support Enabled
INFO - 2018-10-31 18:31:14 --> Utf8 Class Initialized
INFO - 2018-10-31 18:31:14 --> URI Class Initialized
INFO - 2018-10-31 18:31:14 --> Router Class Initialized
INFO - 2018-10-31 18:31:14 --> Output Class Initialized
INFO - 2018-10-31 18:31:14 --> Security Class Initialized
DEBUG - 2018-10-31 18:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-31 18:31:14 --> CSRF cookie sent
INFO - 2018-10-31 18:31:14 --> Input Class Initialized
INFO - 2018-10-31 18:31:14 --> Language Class Initialized
INFO - 2018-10-31 18:31:14 --> Loader Class Initialized
INFO - 2018-10-31 18:31:14 --> Helper loaded: url_helper
INFO - 2018-10-31 18:31:14 --> Helper loaded: form_helper
INFO - 2018-10-31 18:31:14 --> Helper loaded: language_helper
DEBUG - 2018-10-31 18:31:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-31 18:31:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-31 18:31:14 --> User Agent Class Initialized
INFO - 2018-10-31 18:31:14 --> Controller Class Initialized
INFO - 2018-10-31 18:31:14 --> Helper loaded: directory_helper
INFO - 2018-10-31 18:31:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-31 18:31:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-31 18:31:14 --> Helper loaded: custom_helper
ERROR - 2018-10-31 18:31:14 --> Severity: error --> Exception: Call to undefined function directory_copy() E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 36

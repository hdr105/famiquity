<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-11-01 12:12:57 --> Config Class Initialized
INFO - 2018-11-01 12:12:57 --> Hooks Class Initialized
DEBUG - 2018-11-01 12:12:57 --> UTF-8 Support Enabled
INFO - 2018-11-01 12:12:57 --> Utf8 Class Initialized
INFO - 2018-11-01 12:12:57 --> URI Class Initialized
DEBUG - 2018-11-01 12:12:57 --> No URI present. Default controller set.
INFO - 2018-11-01 12:12:57 --> Router Class Initialized
INFO - 2018-11-01 12:12:57 --> Output Class Initialized
INFO - 2018-11-01 12:12:57 --> Security Class Initialized
DEBUG - 2018-11-01 12:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 12:12:57 --> CSRF cookie sent
INFO - 2018-11-01 12:12:57 --> Input Class Initialized
INFO - 2018-11-01 12:12:57 --> Language Class Initialized
INFO - 2018-11-01 12:12:57 --> Loader Class Initialized
INFO - 2018-11-01 12:12:57 --> Helper loaded: url_helper
INFO - 2018-11-01 12:12:57 --> Helper loaded: form_helper
INFO - 2018-11-01 12:12:57 --> Helper loaded: language_helper
DEBUG - 2018-11-01 12:12:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 12:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 12:12:57 --> User Agent Class Initialized
INFO - 2018-11-01 12:12:57 --> Controller Class Initialized
INFO - 2018-11-01 12:12:57 --> Helper loaded: directory_helper
INFO - 2018-11-01 12:12:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-11-01 12:12:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-11-01 12:12:57 --> Helper loaded: custom_helper
INFO - 2018-11-01 12:12:57 --> Pixel_Model class loaded
INFO - 2018-11-01 12:12:57 --> Database Driver Class Initialized
INFO - 2018-11-01 12:12:57 --> Model "QuestionsModel" initialized
INFO - 2018-11-01 12:12:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-11-01 12:12:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-11-01 12:12:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-11-01 12:12:57 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-11-01 12:12:58 --> Final output sent to browser
DEBUG - 2018-11-01 12:12:58 --> Total execution time: 1.0696
INFO - 2018-11-01 12:14:19 --> Config Class Initialized
INFO - 2018-11-01 12:14:19 --> Hooks Class Initialized
DEBUG - 2018-11-01 12:14:19 --> UTF-8 Support Enabled
INFO - 2018-11-01 12:14:19 --> Utf8 Class Initialized
INFO - 2018-11-01 12:14:19 --> URI Class Initialized
INFO - 2018-11-01 12:14:19 --> Router Class Initialized
INFO - 2018-11-01 12:14:19 --> Output Class Initialized
INFO - 2018-11-01 12:14:19 --> Security Class Initialized
DEBUG - 2018-11-01 12:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 12:14:19 --> CSRF cookie sent
INFO - 2018-11-01 12:14:19 --> Input Class Initialized
INFO - 2018-11-01 12:14:19 --> Language Class Initialized
INFO - 2018-11-01 12:14:19 --> Loader Class Initialized
INFO - 2018-11-01 12:14:19 --> Helper loaded: url_helper
INFO - 2018-11-01 12:14:19 --> Helper loaded: form_helper
INFO - 2018-11-01 12:14:19 --> Helper loaded: language_helper
DEBUG - 2018-11-01 12:14:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 12:14:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 12:14:19 --> User Agent Class Initialized
INFO - 2018-11-01 12:14:19 --> Controller Class Initialized
INFO - 2018-11-01 12:14:19 --> Helper loaded: directory_helper
INFO - 2018-11-01 12:14:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-11-01 12:14:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-11-01 12:14:19 --> Helper loaded: custom_helper
ERROR - 2018-11-01 12:14:19 --> Severity: error --> Exception: Call to undefined function directory_copy() E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 36
INFO - 2018-11-01 12:18:43 --> Config Class Initialized
INFO - 2018-11-01 12:18:43 --> Hooks Class Initialized
DEBUG - 2018-11-01 12:18:43 --> UTF-8 Support Enabled
INFO - 2018-11-01 12:18:43 --> Utf8 Class Initialized
INFO - 2018-11-01 12:18:43 --> URI Class Initialized
INFO - 2018-11-01 12:18:43 --> Router Class Initialized
INFO - 2018-11-01 12:18:43 --> Output Class Initialized
INFO - 2018-11-01 12:18:43 --> Security Class Initialized
DEBUG - 2018-11-01 12:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 12:18:43 --> CSRF cookie sent
INFO - 2018-11-01 12:18:43 --> Input Class Initialized
INFO - 2018-11-01 12:18:43 --> Language Class Initialized
INFO - 2018-11-01 12:18:43 --> Loader Class Initialized
INFO - 2018-11-01 12:18:43 --> Helper loaded: url_helper
INFO - 2018-11-01 12:18:43 --> Helper loaded: form_helper
INFO - 2018-11-01 12:18:43 --> Helper loaded: language_helper
DEBUG - 2018-11-01 12:18:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 12:18:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 12:18:43 --> User Agent Class Initialized
INFO - 2018-11-01 12:18:43 --> Controller Class Initialized
INFO - 2018-11-01 12:18:43 --> Helper loaded: directory_helper
INFO - 2018-11-01 12:18:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-11-01 12:18:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-11-01 12:18:43 --> Helper loaded: custom_helper
ERROR - 2018-11-01 12:18:43 --> Severity: Warning --> copy(): The first argument to copy() function cannot be a directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 37
ERROR - 2018-11-01 12:18:43 --> Severity: Warning --> copy(): The first argument to copy() function cannot be a directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 37
ERROR - 2018-11-01 12:18:43 --> Severity: Warning --> copy(): The first argument to copy() function cannot be a directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 37
ERROR - 2018-11-01 12:18:43 --> Severity: Warning --> copy(): The first argument to copy() function cannot be a directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 37
ERROR - 2018-11-01 12:18:43 --> Severity: Warning --> copy(): The first argument to copy() function cannot be a directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 37
ERROR - 2018-11-01 12:18:43 --> Severity: Warning --> copy(): The first argument to copy() function cannot be a directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 37
ERROR - 2018-11-01 12:18:43 --> Severity: Warning --> copy(): The first argument to copy() function cannot be a directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 37
ERROR - 2018-11-01 12:18:43 --> Severity: Warning --> copy(): The first argument to copy() function cannot be a directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 37
ERROR - 2018-11-01 12:18:43 --> Severity: Warning --> copy(): The first argument to copy() function cannot be a directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 37
ERROR - 2018-11-01 12:18:43 --> Severity: Warning --> copy(): The first argument to copy() function cannot be a directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 37
ERROR - 2018-11-01 12:18:43 --> Severity: Warning --> copy(): The first argument to copy() function cannot be a directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 37
ERROR - 2018-11-01 12:18:43 --> Severity: Warning --> copy(): The first argument to copy() function cannot be a directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 37
INFO - 2018-11-01 12:18:43 --> Final output sent to browser
DEBUG - 2018-11-01 12:18:43 --> Total execution time: 0.3329
INFO - 2018-11-01 12:19:54 --> Config Class Initialized
INFO - 2018-11-01 12:19:54 --> Hooks Class Initialized
DEBUG - 2018-11-01 12:19:54 --> UTF-8 Support Enabled
INFO - 2018-11-01 12:19:54 --> Utf8 Class Initialized
INFO - 2018-11-01 12:19:54 --> URI Class Initialized
INFO - 2018-11-01 12:19:54 --> Router Class Initialized
INFO - 2018-11-01 12:19:54 --> Output Class Initialized
INFO - 2018-11-01 12:19:54 --> Security Class Initialized
DEBUG - 2018-11-01 12:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 12:19:54 --> CSRF cookie sent
INFO - 2018-11-01 12:19:54 --> Input Class Initialized
INFO - 2018-11-01 12:19:54 --> Language Class Initialized
ERROR - 2018-11-01 12:19:54 --> Severity: error --> Exception: syntax error, unexpected ')' E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 16
INFO - 2018-11-01 12:20:07 --> Config Class Initialized
INFO - 2018-11-01 12:20:07 --> Hooks Class Initialized
DEBUG - 2018-11-01 12:20:07 --> UTF-8 Support Enabled
INFO - 2018-11-01 12:20:07 --> Utf8 Class Initialized
INFO - 2018-11-01 12:20:07 --> URI Class Initialized
INFO - 2018-11-01 12:20:07 --> Router Class Initialized
INFO - 2018-11-01 12:20:07 --> Output Class Initialized
INFO - 2018-11-01 12:20:07 --> Security Class Initialized
DEBUG - 2018-11-01 12:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 12:20:07 --> CSRF cookie sent
INFO - 2018-11-01 12:20:07 --> Input Class Initialized
INFO - 2018-11-01 12:20:07 --> Language Class Initialized
INFO - 2018-11-01 12:20:07 --> Loader Class Initialized
INFO - 2018-11-01 12:20:07 --> Helper loaded: url_helper
INFO - 2018-11-01 12:20:07 --> Helper loaded: form_helper
INFO - 2018-11-01 12:20:07 --> Helper loaded: language_helper
DEBUG - 2018-11-01 12:20:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 12:20:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 12:20:07 --> User Agent Class Initialized
INFO - 2018-11-01 12:20:07 --> Controller Class Initialized
INFO - 2018-11-01 12:20:07 --> Helper loaded: directory_helper
INFO - 2018-11-01 12:20:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-11-01 12:20:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-11-01 12:20:07 --> Helper loaded: custom_helper
ERROR - 2018-11-01 12:20:07 --> Severity: error --> Exception: Call to undefined method BackupController::recursive_copy() E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 29
INFO - 2018-11-01 12:21:09 --> Config Class Initialized
INFO - 2018-11-01 12:21:09 --> Hooks Class Initialized
DEBUG - 2018-11-01 12:21:09 --> UTF-8 Support Enabled
INFO - 2018-11-01 12:21:09 --> Utf8 Class Initialized
INFO - 2018-11-01 12:21:09 --> URI Class Initialized
INFO - 2018-11-01 12:21:09 --> Router Class Initialized
INFO - 2018-11-01 12:21:09 --> Output Class Initialized
INFO - 2018-11-01 12:21:09 --> Security Class Initialized
DEBUG - 2018-11-01 12:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 12:21:09 --> CSRF cookie sent
INFO - 2018-11-01 12:21:09 --> Input Class Initialized
INFO - 2018-11-01 12:21:09 --> Language Class Initialized
INFO - 2018-11-01 12:21:09 --> Loader Class Initialized
INFO - 2018-11-01 12:21:09 --> Helper loaded: url_helper
INFO - 2018-11-01 12:21:09 --> Helper loaded: form_helper
INFO - 2018-11-01 12:21:09 --> Helper loaded: language_helper
DEBUG - 2018-11-01 12:21:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 12:21:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 12:21:09 --> User Agent Class Initialized
INFO - 2018-11-01 12:21:09 --> Controller Class Initialized
INFO - 2018-11-01 12:21:09 --> Helper loaded: directory_helper
INFO - 2018-11-01 12:21:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-11-01 12:21:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-11-01 12:21:09 --> Helper loaded: custom_helper
INFO - 2018-11-01 12:21:19 --> Final output sent to browser
DEBUG - 2018-11-01 12:21:19 --> Total execution time: 10.5684
INFO - 2018-11-01 12:22:49 --> Config Class Initialized
INFO - 2018-11-01 12:22:49 --> Hooks Class Initialized
DEBUG - 2018-11-01 12:22:49 --> UTF-8 Support Enabled
INFO - 2018-11-01 12:22:49 --> Utf8 Class Initialized
INFO - 2018-11-01 12:22:49 --> URI Class Initialized
INFO - 2018-11-01 12:22:49 --> Router Class Initialized
INFO - 2018-11-01 12:22:49 --> Output Class Initialized
INFO - 2018-11-01 12:22:49 --> Security Class Initialized
DEBUG - 2018-11-01 12:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 12:22:49 --> CSRF cookie sent
INFO - 2018-11-01 12:22:49 --> Input Class Initialized
INFO - 2018-11-01 12:22:49 --> Language Class Initialized
INFO - 2018-11-01 12:22:49 --> Loader Class Initialized
INFO - 2018-11-01 12:22:49 --> Helper loaded: url_helper
INFO - 2018-11-01 12:22:49 --> Helper loaded: form_helper
INFO - 2018-11-01 12:22:49 --> Helper loaded: language_helper
DEBUG - 2018-11-01 12:22:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 12:22:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 12:22:49 --> User Agent Class Initialized
INFO - 2018-11-01 12:22:49 --> Controller Class Initialized
INFO - 2018-11-01 12:22:49 --> Helper loaded: directory_helper
INFO - 2018-11-01 12:22:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-11-01 12:22:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-11-01 12:22:49 --> Helper loaded: custom_helper
INFO - 2018-11-01 12:22:52 --> Final output sent to browser
DEBUG - 2018-11-01 12:22:52 --> Total execution time: 3.0646
INFO - 2018-11-01 12:34:27 --> Config Class Initialized
INFO - 2018-11-01 12:34:27 --> Hooks Class Initialized
DEBUG - 2018-11-01 12:34:27 --> UTF-8 Support Enabled
INFO - 2018-11-01 12:34:27 --> Utf8 Class Initialized
INFO - 2018-11-01 12:34:27 --> URI Class Initialized
INFO - 2018-11-01 12:34:27 --> Router Class Initialized
INFO - 2018-11-01 12:34:27 --> Output Class Initialized
INFO - 2018-11-01 12:34:27 --> Security Class Initialized
DEBUG - 2018-11-01 12:34:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 12:34:27 --> CSRF cookie sent
INFO - 2018-11-01 12:34:27 --> Input Class Initialized
INFO - 2018-11-01 12:34:27 --> Language Class Initialized
INFO - 2018-11-01 12:34:27 --> Loader Class Initialized
INFO - 2018-11-01 12:34:28 --> Helper loaded: url_helper
INFO - 2018-11-01 12:34:28 --> Helper loaded: form_helper
INFO - 2018-11-01 12:34:28 --> Helper loaded: language_helper
DEBUG - 2018-11-01 12:34:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 12:34:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 12:34:28 --> User Agent Class Initialized
INFO - 2018-11-01 12:34:28 --> Controller Class Initialized
INFO - 2018-11-01 12:34:28 --> Helper loaded: directory_helper
INFO - 2018-11-01 12:34:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-11-01 12:34:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-11-01 12:34:28 --> Helper loaded: custom_helper
ERROR - 2018-11-01 12:34:28 --> Severity: error --> Exception: Call to undefined method BackupController::_load_zip_lib() E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 55
INFO - 2018-11-01 12:34:48 --> Config Class Initialized
INFO - 2018-11-01 12:34:48 --> Hooks Class Initialized
DEBUG - 2018-11-01 12:34:48 --> UTF-8 Support Enabled
INFO - 2018-11-01 12:34:48 --> Utf8 Class Initialized
INFO - 2018-11-01 12:34:48 --> URI Class Initialized
INFO - 2018-11-01 12:34:48 --> Router Class Initialized
INFO - 2018-11-01 12:34:48 --> Output Class Initialized
INFO - 2018-11-01 12:34:48 --> Security Class Initialized
DEBUG - 2018-11-01 12:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 12:34:48 --> CSRF cookie sent
INFO - 2018-11-01 12:34:48 --> Input Class Initialized
INFO - 2018-11-01 12:34:48 --> Language Class Initialized
INFO - 2018-11-01 12:34:48 --> Loader Class Initialized
INFO - 2018-11-01 12:34:48 --> Helper loaded: url_helper
INFO - 2018-11-01 12:34:48 --> Helper loaded: form_helper
INFO - 2018-11-01 12:34:48 --> Helper loaded: language_helper
DEBUG - 2018-11-01 12:34:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 12:34:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 12:34:48 --> User Agent Class Initialized
INFO - 2018-11-01 12:34:48 --> Controller Class Initialized
INFO - 2018-11-01 12:34:48 --> Helper loaded: directory_helper
INFO - 2018-11-01 12:34:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-11-01 12:34:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-11-01 12:34:48 --> Helper loaded: custom_helper
INFO - 2018-11-01 12:34:48 --> Zip Compression Class Initialized
ERROR - 2018-11-01 12:34:48 --> Severity: error --> Exception: Call to undefined method BackupController::_load_zip_lib() E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 56
INFO - 2018-11-01 12:34:56 --> Config Class Initialized
INFO - 2018-11-01 12:34:56 --> Hooks Class Initialized
DEBUG - 2018-11-01 12:34:56 --> UTF-8 Support Enabled
INFO - 2018-11-01 12:34:56 --> Utf8 Class Initialized
INFO - 2018-11-01 12:34:56 --> URI Class Initialized
INFO - 2018-11-01 12:34:56 --> Router Class Initialized
INFO - 2018-11-01 12:34:56 --> Output Class Initialized
INFO - 2018-11-01 12:34:56 --> Security Class Initialized
DEBUG - 2018-11-01 12:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 12:34:56 --> CSRF cookie sent
INFO - 2018-11-01 12:34:56 --> Input Class Initialized
INFO - 2018-11-01 12:34:56 --> Language Class Initialized
INFO - 2018-11-01 12:34:56 --> Loader Class Initialized
INFO - 2018-11-01 12:34:56 --> Helper loaded: url_helper
INFO - 2018-11-01 12:34:56 --> Helper loaded: form_helper
INFO - 2018-11-01 12:34:56 --> Helper loaded: language_helper
DEBUG - 2018-11-01 12:34:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 12:34:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 12:34:56 --> User Agent Class Initialized
INFO - 2018-11-01 12:34:56 --> Controller Class Initialized
INFO - 2018-11-01 12:34:56 --> Helper loaded: directory_helper
INFO - 2018-11-01 12:34:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-11-01 12:34:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-11-01 12:34:56 --> Helper loaded: custom_helper
INFO - 2018-11-01 12:34:56 --> Zip Compression Class Initialized
DEBUG - 2018-11-01 12:34:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:57 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:57 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:57 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:57 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:57 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:57 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:57 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:57 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:57 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:57 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:57 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:57 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:57 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:57 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:57 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:57 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:57 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:57 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:57 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:57 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:57 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:57 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:57 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:57 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:57 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:57 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:57 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:57 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:57 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:57 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:57 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:57 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:57 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:57 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:57 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:57 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:57 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:57 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:57 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:57 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:57 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:57 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:57 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:57 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:57 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:57 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:57 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:57 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:57 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:57 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:57 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:57 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:57 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:57 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:57 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:57 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:57 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:57 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:57 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:57 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:57 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:57 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:57 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:57 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:58 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:58 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:58 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:58 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:58 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:58 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:58 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:58 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:58 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:58 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:58 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:58 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:58 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:58 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:58 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:58 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:58 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:58 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:58 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:58 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:58 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:58 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:58 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:58 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:58 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:58 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:58 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:58 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:58 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:58 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:58 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:58 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:58 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:58 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:58 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:58 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:58 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:58 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:58 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:58 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:58 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:58 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:58 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:58 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:58 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:58 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:58 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:58 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:58 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:58 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:58 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:58 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:58 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:58 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:58 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:59 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:59 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:59 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:59 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:59 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:59 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:59 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:59 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:59 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:59 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:59 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:59 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:59 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:59 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:59 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:59 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:59 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:59 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:59 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:59 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:59 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:59 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:59 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:59 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:59 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:59 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:59 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:59 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:59 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:59 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:59 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:59 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:59 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:59 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:59 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:59 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:59 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:59 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:59 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:59 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:59 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:59 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:59 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:59 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:59 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:59 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:59 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:59 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:59 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:59 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:59 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:59 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:59 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:59 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:59 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:59 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:59 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:59 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:34:59 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:00 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:35:01 --> Zip class already loaded. Second attempt ignored.
INFO - 2018-11-01 12:35:01 --> Final output sent to browser
DEBUG - 2018-11-01 12:35:01 --> Total execution time: 5.6016
INFO - 2018-11-01 12:37:05 --> Config Class Initialized
INFO - 2018-11-01 12:37:05 --> Hooks Class Initialized
DEBUG - 2018-11-01 12:37:05 --> UTF-8 Support Enabled
INFO - 2018-11-01 12:37:05 --> Utf8 Class Initialized
INFO - 2018-11-01 12:37:05 --> URI Class Initialized
INFO - 2018-11-01 12:37:05 --> Router Class Initialized
INFO - 2018-11-01 12:37:05 --> Output Class Initialized
INFO - 2018-11-01 12:37:05 --> Security Class Initialized
DEBUG - 2018-11-01 12:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 12:37:05 --> CSRF cookie sent
INFO - 2018-11-01 12:37:05 --> Input Class Initialized
INFO - 2018-11-01 12:37:05 --> Language Class Initialized
INFO - 2018-11-01 12:37:05 --> Loader Class Initialized
INFO - 2018-11-01 12:37:05 --> Helper loaded: url_helper
INFO - 2018-11-01 12:37:05 --> Helper loaded: form_helper
INFO - 2018-11-01 12:37:05 --> Helper loaded: language_helper
DEBUG - 2018-11-01 12:37:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 12:37:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 12:37:05 --> User Agent Class Initialized
INFO - 2018-11-01 12:37:05 --> Controller Class Initialized
INFO - 2018-11-01 12:37:05 --> Helper loaded: directory_helper
INFO - 2018-11-01 12:37:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-11-01 12:37:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-11-01 12:37:05 --> Helper loaded: custom_helper
INFO - 2018-11-01 12:37:05 --> Zip Compression Class Initialized
DEBUG - 2018-11-01 12:37:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:05 --> Zip class already loaded. Second attempt ignored.
ERROR - 2018-11-01 12:37:05 --> Severity: Warning --> strlen() expects parameter 1 to be string, array given E:\xampp7\htdocs\famiquity\system\libraries\Zip.php 505
ERROR - 2018-11-01 12:37:05 --> Severity: Warning --> crc32() expects parameter 1 to be string, array given E:\xampp7\htdocs\famiquity\system\libraries\Zip.php 268
ERROR - 2018-11-01 12:37:05 --> Severity: Warning --> gzcompress() expects parameter 1 to be string, array given E:\xampp7\htdocs\famiquity\system\libraries\Zip.php 269
DEBUG - 2018-11-01 12:37:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:05 --> Zip class already loaded. Second attempt ignored.
ERROR - 2018-11-01 12:37:05 --> Severity: Warning --> strlen() expects parameter 1 to be string, array given E:\xampp7\htdocs\famiquity\system\libraries\Zip.php 505
ERROR - 2018-11-01 12:37:05 --> Severity: Warning --> crc32() expects parameter 1 to be string, array given E:\xampp7\htdocs\famiquity\system\libraries\Zip.php 268
ERROR - 2018-11-01 12:37:05 --> Severity: Warning --> gzcompress() expects parameter 1 to be string, array given E:\xampp7\htdocs\famiquity\system\libraries\Zip.php 269
DEBUG - 2018-11-01 12:37:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:06 --> Zip class already loaded. Second attempt ignored.
ERROR - 2018-11-01 12:37:06 --> Severity: Warning --> strlen() expects parameter 1 to be string, array given E:\xampp7\htdocs\famiquity\system\libraries\Zip.php 505
ERROR - 2018-11-01 12:37:06 --> Severity: Warning --> crc32() expects parameter 1 to be string, array given E:\xampp7\htdocs\famiquity\system\libraries\Zip.php 268
ERROR - 2018-11-01 12:37:06 --> Severity: Warning --> gzcompress() expects parameter 1 to be string, array given E:\xampp7\htdocs\famiquity\system\libraries\Zip.php 269
DEBUG - 2018-11-01 12:37:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:06 --> Zip class already loaded. Second attempt ignored.
ERROR - 2018-11-01 12:37:06 --> Severity: Warning --> strlen() expects parameter 1 to be string, array given E:\xampp7\htdocs\famiquity\system\libraries\Zip.php 505
ERROR - 2018-11-01 12:37:06 --> Severity: Warning --> crc32() expects parameter 1 to be string, array given E:\xampp7\htdocs\famiquity\system\libraries\Zip.php 268
ERROR - 2018-11-01 12:37:06 --> Severity: Warning --> gzcompress() expects parameter 1 to be string, array given E:\xampp7\htdocs\famiquity\system\libraries\Zip.php 269
DEBUG - 2018-11-01 12:37:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:06 --> Zip class already loaded. Second attempt ignored.
ERROR - 2018-11-01 12:37:06 --> Severity: Warning --> strlen() expects parameter 1 to be string, array given E:\xampp7\htdocs\famiquity\system\libraries\Zip.php 505
ERROR - 2018-11-01 12:37:06 --> Severity: Warning --> crc32() expects parameter 1 to be string, array given E:\xampp7\htdocs\famiquity\system\libraries\Zip.php 268
ERROR - 2018-11-01 12:37:06 --> Severity: Warning --> gzcompress() expects parameter 1 to be string, array given E:\xampp7\htdocs\famiquity\system\libraries\Zip.php 269
DEBUG - 2018-11-01 12:37:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:06 --> Zip class already loaded. Second attempt ignored.
ERROR - 2018-11-01 12:37:06 --> Severity: Warning --> strlen() expects parameter 1 to be string, array given E:\xampp7\htdocs\famiquity\system\libraries\Zip.php 505
ERROR - 2018-11-01 12:37:06 --> Severity: Warning --> crc32() expects parameter 1 to be string, array given E:\xampp7\htdocs\famiquity\system\libraries\Zip.php 268
ERROR - 2018-11-01 12:37:06 --> Severity: Warning --> gzcompress() expects parameter 1 to be string, array given E:\xampp7\htdocs\famiquity\system\libraries\Zip.php 269
DEBUG - 2018-11-01 12:37:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:06 --> Zip class already loaded. Second attempt ignored.
ERROR - 2018-11-01 12:37:06 --> Severity: Warning --> strlen() expects parameter 1 to be string, array given E:\xampp7\htdocs\famiquity\system\libraries\Zip.php 505
ERROR - 2018-11-01 12:37:06 --> Severity: Warning --> crc32() expects parameter 1 to be string, array given E:\xampp7\htdocs\famiquity\system\libraries\Zip.php 268
ERROR - 2018-11-01 12:37:06 --> Severity: Warning --> gzcompress() expects parameter 1 to be string, array given E:\xampp7\htdocs\famiquity\system\libraries\Zip.php 269
DEBUG - 2018-11-01 12:37:06 --> Zip class already loaded. Second attempt ignored.
ERROR - 2018-11-01 12:37:06 --> Severity: Warning --> strlen() expects parameter 1 to be string, array given E:\xampp7\htdocs\famiquity\system\libraries\Zip.php 505
ERROR - 2018-11-01 12:37:06 --> Severity: Warning --> crc32() expects parameter 1 to be string, array given E:\xampp7\htdocs\famiquity\system\libraries\Zip.php 268
ERROR - 2018-11-01 12:37:06 --> Severity: Warning --> gzcompress() expects parameter 1 to be string, array given E:\xampp7\htdocs\famiquity\system\libraries\Zip.php 269
DEBUG - 2018-11-01 12:37:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:06 --> Zip class already loaded. Second attempt ignored.
ERROR - 2018-11-01 12:37:06 --> Severity: Warning --> strlen() expects parameter 1 to be string, array given E:\xampp7\htdocs\famiquity\system\libraries\Zip.php 505
ERROR - 2018-11-01 12:37:06 --> Severity: Warning --> crc32() expects parameter 1 to be string, array given E:\xampp7\htdocs\famiquity\system\libraries\Zip.php 268
ERROR - 2018-11-01 12:37:06 --> Severity: Warning --> gzcompress() expects parameter 1 to be string, array given E:\xampp7\htdocs\famiquity\system\libraries\Zip.php 269
DEBUG - 2018-11-01 12:37:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:08 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:08 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:08 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:08 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:08 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:08 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:08 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:08 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:08 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:08 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:08 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:08 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:08 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:08 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:08 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:08 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:08 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:08 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:08 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:08 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:08 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:08 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:08 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:08 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:08 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:08 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:08 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:08 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:08 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:08 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:08 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:08 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:08 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:08 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:08 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:08 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:08 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:08 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:08 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:08 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:08 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:08 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:08 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:08 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:08 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:08 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:08 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:08 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:08 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:09 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:09 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:09 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:09 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:09 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:09 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:09 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:09 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:09 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:09 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:09 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:09 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:09 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:09 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:09 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:09 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:09 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:09 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:09 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:09 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:09 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:09 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:09 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:09 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:09 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:09 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:09 --> Zip class already loaded. Second attempt ignored.
ERROR - 2018-11-01 12:37:09 --> Severity: Warning --> strlen() expects parameter 1 to be string, array given E:\xampp7\htdocs\famiquity\system\libraries\Zip.php 505
ERROR - 2018-11-01 12:37:09 --> Severity: Warning --> crc32() expects parameter 1 to be string, array given E:\xampp7\htdocs\famiquity\system\libraries\Zip.php 268
ERROR - 2018-11-01 12:37:09 --> Severity: Warning --> gzcompress() expects parameter 1 to be string, array given E:\xampp7\htdocs\famiquity\system\libraries\Zip.php 269
DEBUG - 2018-11-01 12:37:09 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:09 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:09 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:09 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:09 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:09 --> Zip class already loaded. Second attempt ignored.
ERROR - 2018-11-01 12:37:09 --> Severity: Warning --> strlen() expects parameter 1 to be string, array given E:\xampp7\htdocs\famiquity\system\libraries\Zip.php 505
ERROR - 2018-11-01 12:37:09 --> Severity: Warning --> crc32() expects parameter 1 to be string, array given E:\xampp7\htdocs\famiquity\system\libraries\Zip.php 268
ERROR - 2018-11-01 12:37:09 --> Severity: Warning --> gzcompress() expects parameter 1 to be string, array given E:\xampp7\htdocs\famiquity\system\libraries\Zip.php 269
DEBUG - 2018-11-01 12:37:09 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:09 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:09 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:09 --> Zip class already loaded. Second attempt ignored.
ERROR - 2018-11-01 12:37:09 --> Severity: Warning --> strlen() expects parameter 1 to be string, array given E:\xampp7\htdocs\famiquity\system\libraries\Zip.php 505
ERROR - 2018-11-01 12:37:09 --> Severity: Warning --> crc32() expects parameter 1 to be string, array given E:\xampp7\htdocs\famiquity\system\libraries\Zip.php 268
ERROR - 2018-11-01 12:37:09 --> Severity: Warning --> gzcompress() expects parameter 1 to be string, array given E:\xampp7\htdocs\famiquity\system\libraries\Zip.php 269
ERROR - 2018-11-01 12:37:09 --> Severity: Warning --> strlen() expects parameter 1 to be string, array given E:\xampp7\htdocs\famiquity\system\libraries\Zip.php 505
ERROR - 2018-11-01 12:37:09 --> Severity: Warning --> crc32() expects parameter 1 to be string, array given E:\xampp7\htdocs\famiquity\system\libraries\Zip.php 268
ERROR - 2018-11-01 12:37:09 --> Severity: Warning --> gzcompress() expects parameter 1 to be string, array given E:\xampp7\htdocs\famiquity\system\libraries\Zip.php 269
DEBUG - 2018-11-01 12:37:09 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:09 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:09 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:09 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:09 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:09 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:09 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:09 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:09 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:09 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:10 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:10 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:10 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:10 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:10 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:10 --> Zip class already loaded. Second attempt ignored.
ERROR - 2018-11-01 12:37:10 --> Severity: Warning --> strlen() expects parameter 1 to be string, array given E:\xampp7\htdocs\famiquity\system\libraries\Zip.php 505
ERROR - 2018-11-01 12:37:10 --> Severity: Warning --> crc32() expects parameter 1 to be string, array given E:\xampp7\htdocs\famiquity\system\libraries\Zip.php 268
ERROR - 2018-11-01 12:37:10 --> Severity: Warning --> gzcompress() expects parameter 1 to be string, array given E:\xampp7\htdocs\famiquity\system\libraries\Zip.php 269
DEBUG - 2018-11-01 12:37:10 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:10 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:10 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:10 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:10 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:10 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:10 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:10 --> Zip class already loaded. Second attempt ignored.
ERROR - 2018-11-01 12:37:10 --> Severity: Warning --> strlen() expects parameter 1 to be string, array given E:\xampp7\htdocs\famiquity\system\libraries\Zip.php 505
ERROR - 2018-11-01 12:37:10 --> Severity: Warning --> crc32() expects parameter 1 to be string, array given E:\xampp7\htdocs\famiquity\system\libraries\Zip.php 268
ERROR - 2018-11-01 12:37:10 --> Severity: Warning --> gzcompress() expects parameter 1 to be string, array given E:\xampp7\htdocs\famiquity\system\libraries\Zip.php 269
DEBUG - 2018-11-01 12:37:10 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:10 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:10 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:10 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:10 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:10 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:10 --> Zip class already loaded. Second attempt ignored.
ERROR - 2018-11-01 12:37:10 --> Severity: Warning --> strlen() expects parameter 1 to be string, array given E:\xampp7\htdocs\famiquity\system\libraries\Zip.php 505
ERROR - 2018-11-01 12:37:10 --> Severity: Warning --> crc32() expects parameter 1 to be string, array given E:\xampp7\htdocs\famiquity\system\libraries\Zip.php 268
ERROR - 2018-11-01 12:37:10 --> Severity: Warning --> gzcompress() expects parameter 1 to be string, array given E:\xampp7\htdocs\famiquity\system\libraries\Zip.php 269
DEBUG - 2018-11-01 12:37:10 --> Zip class already loaded. Second attempt ignored.
ERROR - 2018-11-01 12:37:10 --> Severity: Warning --> strlen() expects parameter 1 to be string, array given E:\xampp7\htdocs\famiquity\system\libraries\Zip.php 505
ERROR - 2018-11-01 12:37:10 --> Severity: Warning --> crc32() expects parameter 1 to be string, array given E:\xampp7\htdocs\famiquity\system\libraries\Zip.php 268
ERROR - 2018-11-01 12:37:10 --> Severity: Warning --> gzcompress() expects parameter 1 to be string, array given E:\xampp7\htdocs\famiquity\system\libraries\Zip.php 269
DEBUG - 2018-11-01 12:37:10 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:10 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:10 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:10 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:10 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:10 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:10 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:10 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:10 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:10 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:10 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:10 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:10 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:10 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:10 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:10 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:10 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:10 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:10 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:10 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:10 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:10 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:10 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:10 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:10 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:10 --> Zip class already loaded. Second attempt ignored.
ERROR - 2018-11-01 12:37:10 --> Severity: Warning --> strlen() expects parameter 1 to be string, array given E:\xampp7\htdocs\famiquity\system\libraries\Zip.php 505
ERROR - 2018-11-01 12:37:10 --> Severity: Warning --> crc32() expects parameter 1 to be string, array given E:\xampp7\htdocs\famiquity\system\libraries\Zip.php 268
ERROR - 2018-11-01 12:37:10 --> Severity: Warning --> gzcompress() expects parameter 1 to be string, array given E:\xampp7\htdocs\famiquity\system\libraries\Zip.php 269
DEBUG - 2018-11-01 12:37:10 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:10 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:10 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:10 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:10 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:10 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:10 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:10 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:10 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:10 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:10 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:10 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:10 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:10 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:10 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:10 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:10 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:10 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:10 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:10 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:11 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:11 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:11 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:11 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:11 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:11 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:11 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:11 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:11 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:11 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:11 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:11 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:11 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:11 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:11 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:11 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:11 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:11 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:11 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:11 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:11 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:11 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:11 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:11 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:11 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:11 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:11 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:11 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:11 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:11 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:11 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:11 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:11 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:11 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:11 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:11 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:11 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:11 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:11 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:11 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:11 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:11 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:11 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:11 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:11 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:11 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:11 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:11 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:11 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:11 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:11 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:11 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:11 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:11 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:11 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:11 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:11 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:11 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:11 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:11 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:11 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:11 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:11 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:11 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:11 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:11 --> Zip class already loaded. Second attempt ignored.
ERROR - 2018-11-01 12:37:11 --> Severity: Warning --> strlen() expects parameter 1 to be string, array given E:\xampp7\htdocs\famiquity\system\libraries\Zip.php 505
ERROR - 2018-11-01 12:37:11 --> Severity: Warning --> crc32() expects parameter 1 to be string, array given E:\xampp7\htdocs\famiquity\system\libraries\Zip.php 268
ERROR - 2018-11-01 12:37:11 --> Severity: Warning --> gzcompress() expects parameter 1 to be string, array given E:\xampp7\htdocs\famiquity\system\libraries\Zip.php 269
DEBUG - 2018-11-01 12:37:11 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:11 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:11 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:12 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:12 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:12 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:12 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:12 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:12 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:12 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:12 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:12 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:12 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:12 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:12 --> Zip class already loaded. Second attempt ignored.
ERROR - 2018-11-01 12:37:12 --> Severity: Warning --> strlen() expects parameter 1 to be string, array given E:\xampp7\htdocs\famiquity\system\libraries\Zip.php 505
ERROR - 2018-11-01 12:37:12 --> Severity: Warning --> crc32() expects parameter 1 to be string, array given E:\xampp7\htdocs\famiquity\system\libraries\Zip.php 268
ERROR - 2018-11-01 12:37:12 --> Severity: Warning --> gzcompress() expects parameter 1 to be string, array given E:\xampp7\htdocs\famiquity\system\libraries\Zip.php 269
DEBUG - 2018-11-01 12:37:12 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:12 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:12 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:12 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:12 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:12 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:12 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:12 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:12 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:12 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:12 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:12 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:12 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:12 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:12 --> Zip class already loaded. Second attempt ignored.
ERROR - 2018-11-01 12:37:12 --> Severity: Warning --> strlen() expects parameter 1 to be string, array given E:\xampp7\htdocs\famiquity\system\libraries\Zip.php 505
ERROR - 2018-11-01 12:37:12 --> Severity: Warning --> crc32() expects parameter 1 to be string, array given E:\xampp7\htdocs\famiquity\system\libraries\Zip.php 268
ERROR - 2018-11-01 12:37:12 --> Severity: Warning --> gzcompress() expects parameter 1 to be string, array given E:\xampp7\htdocs\famiquity\system\libraries\Zip.php 269
DEBUG - 2018-11-01 12:37:12 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:12 --> Zip class already loaded. Second attempt ignored.
ERROR - 2018-11-01 12:37:12 --> Severity: Warning --> strlen() expects parameter 1 to be string, array given E:\xampp7\htdocs\famiquity\system\libraries\Zip.php 505
ERROR - 2018-11-01 12:37:12 --> Severity: Warning --> crc32() expects parameter 1 to be string, array given E:\xampp7\htdocs\famiquity\system\libraries\Zip.php 268
ERROR - 2018-11-01 12:37:12 --> Severity: Warning --> gzcompress() expects parameter 1 to be string, array given E:\xampp7\htdocs\famiquity\system\libraries\Zip.php 269
ERROR - 2018-11-01 12:37:12 --> Severity: Warning --> strlen() expects parameter 1 to be string, array given E:\xampp7\htdocs\famiquity\system\libraries\Zip.php 505
ERROR - 2018-11-01 12:37:12 --> Severity: Warning --> crc32() expects parameter 1 to be string, array given E:\xampp7\htdocs\famiquity\system\libraries\Zip.php 268
ERROR - 2018-11-01 12:37:12 --> Severity: Warning --> gzcompress() expects parameter 1 to be string, array given E:\xampp7\htdocs\famiquity\system\libraries\Zip.php 269
INFO - 2018-11-01 12:37:12 --> Final output sent to browser
DEBUG - 2018-11-01 12:37:12 --> Total execution time: 7.2325
INFO - 2018-11-01 12:37:50 --> Config Class Initialized
INFO - 2018-11-01 12:37:50 --> Hooks Class Initialized
DEBUG - 2018-11-01 12:37:50 --> UTF-8 Support Enabled
INFO - 2018-11-01 12:37:50 --> Utf8 Class Initialized
INFO - 2018-11-01 12:37:50 --> URI Class Initialized
INFO - 2018-11-01 12:37:50 --> Router Class Initialized
INFO - 2018-11-01 12:37:50 --> Output Class Initialized
INFO - 2018-11-01 12:37:50 --> Security Class Initialized
DEBUG - 2018-11-01 12:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 12:37:50 --> CSRF cookie sent
INFO - 2018-11-01 12:37:50 --> Input Class Initialized
INFO - 2018-11-01 12:37:50 --> Language Class Initialized
INFO - 2018-11-01 12:37:50 --> Loader Class Initialized
INFO - 2018-11-01 12:37:50 --> Helper loaded: url_helper
INFO - 2018-11-01 12:37:50 --> Helper loaded: form_helper
INFO - 2018-11-01 12:37:50 --> Helper loaded: language_helper
DEBUG - 2018-11-01 12:37:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 12:37:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 12:37:50 --> User Agent Class Initialized
INFO - 2018-11-01 12:37:51 --> Controller Class Initialized
INFO - 2018-11-01 12:37:51 --> Helper loaded: directory_helper
INFO - 2018-11-01 12:37:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-11-01 12:37:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-11-01 12:37:51 --> Helper loaded: custom_helper
INFO - 2018-11-01 12:37:51 --> Zip Compression Class Initialized
DEBUG - 2018-11-01 12:37:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:55 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:55 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:55 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:55 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:55 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:55 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:55 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:55 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:55 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:55 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:55 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:55 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:55 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:55 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:55 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:55 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:55 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:55 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:55 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:55 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:55 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:55 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:55 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:55 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:55 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:55 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:55 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:55 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:55 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:55 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:55 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:55 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:55 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:55 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:55 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:55 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:55 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:55 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:55 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:55 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:55 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:55 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:55 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:55 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:55 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:55 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:55 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:55 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:55 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:55 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:55 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:55 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:55 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:55 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:55 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:55 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:55 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:55 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:55 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:55 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:55 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:55 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:55 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:55 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:55 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:55 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:55 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:55 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:55 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:55 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:55 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:55 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:55 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:55 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:56 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:37:56 --> Zip class already loaded. Second attempt ignored.
INFO - 2018-11-01 12:37:56 --> Final output sent to browser
DEBUG - 2018-11-01 12:37:56 --> Total execution time: 6.1801
INFO - 2018-11-01 12:45:48 --> Config Class Initialized
INFO - 2018-11-01 12:45:48 --> Hooks Class Initialized
DEBUG - 2018-11-01 12:45:48 --> UTF-8 Support Enabled
INFO - 2018-11-01 12:45:48 --> Utf8 Class Initialized
INFO - 2018-11-01 12:45:48 --> URI Class Initialized
INFO - 2018-11-01 12:45:48 --> Router Class Initialized
INFO - 2018-11-01 12:45:48 --> Output Class Initialized
INFO - 2018-11-01 12:45:48 --> Security Class Initialized
DEBUG - 2018-11-01 12:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 12:45:48 --> CSRF cookie sent
INFO - 2018-11-01 12:45:48 --> Input Class Initialized
INFO - 2018-11-01 12:45:48 --> Language Class Initialized
INFO - 2018-11-01 12:45:48 --> Loader Class Initialized
INFO - 2018-11-01 12:45:48 --> Helper loaded: url_helper
INFO - 2018-11-01 12:45:48 --> Helper loaded: form_helper
INFO - 2018-11-01 12:45:48 --> Helper loaded: language_helper
DEBUG - 2018-11-01 12:45:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 12:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 12:45:48 --> User Agent Class Initialized
INFO - 2018-11-01 12:45:48 --> Controller Class Initialized
INFO - 2018-11-01 12:45:48 --> Helper loaded: directory_helper
INFO - 2018-11-01 12:45:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-11-01 12:45:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-11-01 12:45:48 --> Helper loaded: custom_helper
INFO - 2018-11-01 12:45:48 --> Zip Compression Class Initialized
DEBUG - 2018-11-01 12:45:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:45:54 --> Zip class already loaded. Second attempt ignored.
INFO - 2018-11-01 12:45:54 --> Final output sent to browser
DEBUG - 2018-11-01 12:45:54 --> Total execution time: 6.7006
INFO - 2018-11-01 12:46:44 --> Config Class Initialized
INFO - 2018-11-01 12:46:44 --> Hooks Class Initialized
DEBUG - 2018-11-01 12:46:44 --> UTF-8 Support Enabled
INFO - 2018-11-01 12:46:44 --> Utf8 Class Initialized
INFO - 2018-11-01 12:46:44 --> URI Class Initialized
INFO - 2018-11-01 12:46:44 --> Router Class Initialized
INFO - 2018-11-01 12:46:44 --> Output Class Initialized
INFO - 2018-11-01 12:46:44 --> Security Class Initialized
DEBUG - 2018-11-01 12:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 12:46:44 --> CSRF cookie sent
INFO - 2018-11-01 12:46:44 --> Input Class Initialized
INFO - 2018-11-01 12:46:44 --> Language Class Initialized
INFO - 2018-11-01 12:46:44 --> Loader Class Initialized
INFO - 2018-11-01 12:46:44 --> Helper loaded: url_helper
INFO - 2018-11-01 12:46:44 --> Helper loaded: form_helper
INFO - 2018-11-01 12:46:44 --> Helper loaded: language_helper
DEBUG - 2018-11-01 12:46:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 12:46:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 12:46:44 --> User Agent Class Initialized
INFO - 2018-11-01 12:46:44 --> Controller Class Initialized
INFO - 2018-11-01 12:46:44 --> Helper loaded: directory_helper
INFO - 2018-11-01 12:46:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-11-01 12:46:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-11-01 12:46:44 --> Helper loaded: custom_helper
INFO - 2018-11-01 12:46:44 --> Zip Compression Class Initialized
DEBUG - 2018-11-01 12:46:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:46:51 --> Zip class already loaded. Second attempt ignored.
INFO - 2018-11-01 12:46:51 --> Final output sent to browser
DEBUG - 2018-11-01 12:46:51 --> Total execution time: 7.0103
INFO - 2018-11-01 12:47:43 --> Config Class Initialized
INFO - 2018-11-01 12:47:43 --> Hooks Class Initialized
DEBUG - 2018-11-01 12:47:43 --> UTF-8 Support Enabled
INFO - 2018-11-01 12:47:43 --> Utf8 Class Initialized
INFO - 2018-11-01 12:47:43 --> URI Class Initialized
INFO - 2018-11-01 12:47:43 --> Router Class Initialized
INFO - 2018-11-01 12:47:43 --> Output Class Initialized
INFO - 2018-11-01 12:47:43 --> Security Class Initialized
DEBUG - 2018-11-01 12:47:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 12:47:43 --> CSRF cookie sent
INFO - 2018-11-01 12:47:43 --> Input Class Initialized
INFO - 2018-11-01 12:47:43 --> Language Class Initialized
INFO - 2018-11-01 12:47:43 --> Loader Class Initialized
INFO - 2018-11-01 12:47:43 --> Helper loaded: url_helper
INFO - 2018-11-01 12:47:43 --> Helper loaded: form_helper
INFO - 2018-11-01 12:47:43 --> Helper loaded: language_helper
DEBUG - 2018-11-01 12:47:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 12:47:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 12:47:43 --> User Agent Class Initialized
INFO - 2018-11-01 12:47:43 --> Controller Class Initialized
INFO - 2018-11-01 12:47:43 --> Helper loaded: directory_helper
INFO - 2018-11-01 12:47:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-11-01 12:47:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-11-01 12:47:43 --> Helper loaded: custom_helper
INFO - 2018-11-01 12:47:43 --> Zip Compression Class Initialized
DEBUG - 2018-11-01 12:47:43 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:47:50 --> Zip class already loaded. Second attempt ignored.
INFO - 2018-11-01 12:47:50 --> Final output sent to browser
DEBUG - 2018-11-01 12:47:50 --> Total execution time: 7.1895
INFO - 2018-11-01 12:50:00 --> Config Class Initialized
INFO - 2018-11-01 12:50:00 --> Hooks Class Initialized
DEBUG - 2018-11-01 12:50:00 --> UTF-8 Support Enabled
INFO - 2018-11-01 12:50:00 --> Utf8 Class Initialized
INFO - 2018-11-01 12:50:00 --> URI Class Initialized
INFO - 2018-11-01 12:50:00 --> Router Class Initialized
INFO - 2018-11-01 12:50:00 --> Output Class Initialized
INFO - 2018-11-01 12:50:00 --> Security Class Initialized
DEBUG - 2018-11-01 12:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 12:50:01 --> CSRF cookie sent
INFO - 2018-11-01 12:50:01 --> Input Class Initialized
INFO - 2018-11-01 12:50:01 --> Language Class Initialized
INFO - 2018-11-01 12:50:01 --> Loader Class Initialized
INFO - 2018-11-01 12:50:01 --> Helper loaded: url_helper
INFO - 2018-11-01 12:50:01 --> Helper loaded: form_helper
INFO - 2018-11-01 12:50:01 --> Helper loaded: language_helper
DEBUG - 2018-11-01 12:50:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 12:50:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 12:50:01 --> User Agent Class Initialized
INFO - 2018-11-01 12:50:01 --> Controller Class Initialized
INFO - 2018-11-01 12:50:01 --> Helper loaded: directory_helper
INFO - 2018-11-01 12:50:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-11-01 12:50:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-11-01 12:50:01 --> Helper loaded: custom_helper
INFO - 2018-11-01 12:50:01 --> Zip Compression Class Initialized
DEBUG - 2018-11-01 12:50:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:01 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:02 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:02 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:02 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:02 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:02 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:02 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:02 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:02 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:02 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:02 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:02 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:02 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:02 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:02 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:02 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:02 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:02 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:02 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:02 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:02 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:02 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:02 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:02 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:02 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:02 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:02 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:02 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:02 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:02 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:02 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:02 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:02 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:02 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:02 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:02 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:02 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:02 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:02 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:02 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:02 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:02 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:02 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:02 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:02 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:02 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:02 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:02 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:02 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:02 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:02 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:02 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:02 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:03 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:03 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:03 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:03 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:03 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:03 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:03 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:03 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:03 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:03 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:03 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:03 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:03 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:03 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:03 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:03 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:03 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:03 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:03 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:03 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:03 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:03 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:03 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:03 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:03 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:03 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:03 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:03 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:03 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:03 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:03 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:03 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:03 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:03 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:03 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:03 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:03 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:03 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:03 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:03 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:03 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:03 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:03 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:03 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:03 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:03 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:03 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:03 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:03 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:03 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:04 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:04 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:04 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:04 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:04 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:04 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:04 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:04 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:04 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:04 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:04 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:04 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:04 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:04 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:04 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:04 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:04 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:04 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:04 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:04 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:04 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:04 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:04 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:04 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:04 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:04 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:04 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:04 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:04 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:04 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:04 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:04 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:04 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:04 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:04 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:04 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:04 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:04 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:04 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:04 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:04 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:05 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:06 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:07 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:08 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:08 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:08 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:08 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:08 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:08 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:08 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:08 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:08 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:08 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:08 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:08 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:08 --> Zip class already loaded. Second attempt ignored.
INFO - 2018-11-01 12:50:08 --> Final output sent to browser
DEBUG - 2018-11-01 12:50:08 --> Total execution time: 7.4468
INFO - 2018-11-01 12:50:37 --> Config Class Initialized
INFO - 2018-11-01 12:50:37 --> Hooks Class Initialized
DEBUG - 2018-11-01 12:50:37 --> UTF-8 Support Enabled
INFO - 2018-11-01 12:50:37 --> Utf8 Class Initialized
INFO - 2018-11-01 12:50:37 --> URI Class Initialized
INFO - 2018-11-01 12:50:37 --> Router Class Initialized
INFO - 2018-11-01 12:50:37 --> Output Class Initialized
INFO - 2018-11-01 12:50:37 --> Security Class Initialized
DEBUG - 2018-11-01 12:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 12:50:37 --> CSRF cookie sent
INFO - 2018-11-01 12:50:37 --> Input Class Initialized
INFO - 2018-11-01 12:50:37 --> Language Class Initialized
INFO - 2018-11-01 12:50:37 --> Loader Class Initialized
INFO - 2018-11-01 12:50:37 --> Helper loaded: url_helper
INFO - 2018-11-01 12:50:37 --> Helper loaded: form_helper
INFO - 2018-11-01 12:50:37 --> Helper loaded: language_helper
DEBUG - 2018-11-01 12:50:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 12:50:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 12:50:37 --> User Agent Class Initialized
INFO - 2018-11-01 12:50:37 --> Controller Class Initialized
INFO - 2018-11-01 12:50:37 --> Helper loaded: directory_helper
INFO - 2018-11-01 12:50:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-11-01 12:50:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-11-01 12:50:37 --> Helper loaded: custom_helper
INFO - 2018-11-01 12:50:37 --> Zip Compression Class Initialized
DEBUG - 2018-11-01 12:50:37 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:37 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:37 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:37 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:37 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:37 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:38 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:38 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:38 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:38 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:38 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:38 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:38 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:38 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:38 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:38 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:38 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:38 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:38 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:38 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:38 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:38 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:38 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:38 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:38 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:38 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:38 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:38 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:38 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:38 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:38 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:38 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:38 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:38 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:38 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:38 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:38 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:38 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:38 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:38 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:38 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:38 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:38 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:38 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:38 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:38 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:38 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:38 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:38 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:38 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:38 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:38 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:38 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:38 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:38 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:38 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:38 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:38 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:38 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:38 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:38 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:38 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:38 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:38 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:38 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:39 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:39 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:39 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:39 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:39 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:39 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:39 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:39 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:39 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:39 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:39 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:39 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:39 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:39 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:39 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:39 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:39 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:39 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:39 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:39 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:39 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:39 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:39 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:39 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:39 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:39 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:39 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:39 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:39 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:39 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:39 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:39 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:39 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:39 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:39 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:39 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:39 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:39 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:39 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:39 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:39 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:39 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:39 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:39 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:39 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:39 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:39 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:39 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:40 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:40 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:40 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:40 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:40 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:40 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:40 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:40 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:40 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:40 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:40 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:40 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:40 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:40 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:40 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:40 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:40 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:40 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:40 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:40 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:40 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:40 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:40 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:40 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:40 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:40 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:40 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:40 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:40 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:40 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:40 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:40 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:40 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:40 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:40 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:40 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:40 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:40 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:40 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:40 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:40 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:40 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:40 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:40 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:40 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:40 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:41 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:41 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:41 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:41 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:41 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:41 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:41 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:41 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:41 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:41 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:41 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:41 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:41 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:41 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:41 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:41 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:41 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:41 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:41 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:41 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:41 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:41 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:41 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:41 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:41 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:41 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:41 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:41 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:41 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:41 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:41 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:41 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:41 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:41 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:41 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:41 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:41 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:41 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:41 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:41 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:41 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:41 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:42 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:42 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:42 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:42 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:42 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:42 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:42 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:42 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:42 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:42 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:42 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:42 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:42 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:42 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:42 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:42 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:42 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:42 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:42 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:42 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:42 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:42 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:42 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:42 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:42 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:42 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:42 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:42 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:42 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:42 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:42 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:42 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:42 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:42 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:42 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:42 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:42 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:42 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:42 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:42 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:42 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:42 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:42 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:42 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:42 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:42 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:42 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:42 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:42 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:42 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:42 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:42 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:42 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:42 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:42 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:42 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:42 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:42 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:42 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:42 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:42 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:42 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:42 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:42 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:43 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:43 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:43 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:43 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:43 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:43 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:43 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:43 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:43 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:43 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:43 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:43 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:43 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:43 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:43 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:43 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:43 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:43 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:43 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:43 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:43 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:43 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:43 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:43 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:43 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:43 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:43 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:43 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:43 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:43 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:43 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:43 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:43 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:43 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:43 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:43 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:43 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:43 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:43 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:43 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:43 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:43 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:43 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:43 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:43 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:43 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:43 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:43 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:43 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:43 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:43 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:43 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:43 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:43 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:43 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:43 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:43 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:43 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:43 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:43 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:44 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:45 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:45 --> Zip class already loaded. Second attempt ignored.
INFO - 2018-11-01 12:50:45 --> Final output sent to browser
DEBUG - 2018-11-01 12:50:45 --> Total execution time: 7.5319
INFO - 2018-11-01 12:50:46 --> Config Class Initialized
INFO - 2018-11-01 12:50:46 --> Hooks Class Initialized
DEBUG - 2018-11-01 12:50:46 --> UTF-8 Support Enabled
INFO - 2018-11-01 12:50:46 --> Utf8 Class Initialized
INFO - 2018-11-01 12:50:46 --> URI Class Initialized
INFO - 2018-11-01 12:50:46 --> Router Class Initialized
INFO - 2018-11-01 12:50:46 --> Output Class Initialized
INFO - 2018-11-01 12:50:46 --> Security Class Initialized
DEBUG - 2018-11-01 12:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 12:50:46 --> CSRF cookie sent
INFO - 2018-11-01 12:50:46 --> Input Class Initialized
INFO - 2018-11-01 12:50:46 --> Language Class Initialized
INFO - 2018-11-01 12:50:46 --> Loader Class Initialized
INFO - 2018-11-01 12:50:46 --> Helper loaded: url_helper
INFO - 2018-11-01 12:50:46 --> Helper loaded: form_helper
INFO - 2018-11-01 12:50:46 --> Helper loaded: language_helper
DEBUG - 2018-11-01 12:50:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 12:50:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 12:50:46 --> User Agent Class Initialized
INFO - 2018-11-01 12:50:46 --> Controller Class Initialized
INFO - 2018-11-01 12:50:46 --> Helper loaded: directory_helper
INFO - 2018-11-01 12:50:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-11-01 12:50:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-11-01 12:50:46 --> Helper loaded: custom_helper
INFO - 2018-11-01 12:50:46 --> Zip Compression Class Initialized
DEBUG - 2018-11-01 12:50:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:46 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:50 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:51 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:52 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:53 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:54 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 12:50:54 --> Zip class already loaded. Second attempt ignored.
INFO - 2018-11-01 12:50:54 --> Final output sent to browser
DEBUG - 2018-11-01 12:50:54 --> Total execution time: 7.8152
INFO - 2018-11-01 12:52:22 --> Config Class Initialized
INFO - 2018-11-01 12:52:22 --> Hooks Class Initialized
DEBUG - 2018-11-01 12:52:22 --> UTF-8 Support Enabled
INFO - 2018-11-01 12:52:22 --> Utf8 Class Initialized
INFO - 2018-11-01 12:52:22 --> URI Class Initialized
INFO - 2018-11-01 12:52:22 --> Router Class Initialized
INFO - 2018-11-01 12:52:22 --> Output Class Initialized
INFO - 2018-11-01 12:52:22 --> Security Class Initialized
DEBUG - 2018-11-01 12:52:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 12:52:22 --> CSRF cookie sent
INFO - 2018-11-01 12:52:22 --> Input Class Initialized
INFO - 2018-11-01 12:52:22 --> Language Class Initialized
INFO - 2018-11-01 12:52:22 --> Loader Class Initialized
INFO - 2018-11-01 12:52:22 --> Helper loaded: url_helper
INFO - 2018-11-01 12:52:22 --> Helper loaded: form_helper
INFO - 2018-11-01 12:52:22 --> Helper loaded: language_helper
DEBUG - 2018-11-01 12:52:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 12:52:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 12:52:22 --> User Agent Class Initialized
INFO - 2018-11-01 12:52:22 --> Controller Class Initialized
INFO - 2018-11-01 12:52:22 --> Helper loaded: directory_helper
INFO - 2018-11-01 12:52:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-11-01 12:52:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-11-01 12:52:22 --> Helper loaded: custom_helper
INFO - 2018-11-01 12:52:25 --> Database Driver Class Initialized
INFO - 2018-11-01 12:52:25 --> Database Utility Class Initialized
INFO - 2018-11-01 12:52:25 --> Database Utility Class Initialized
INFO - 2018-11-01 12:52:25 --> Zip Compression Class Initialized
ERROR - 2018-11-01 12:52:26 --> Severity: Notice --> Only variables should be assigned by reference E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 34
INFO - 2018-11-01 12:52:26 --> Helper loaded: file_helper
INFO - 2018-11-01 12:52:26 --> Final output sent to browser
DEBUG - 2018-11-01 12:52:26 --> Total execution time: 3.7514
INFO - 2018-11-01 12:55:16 --> Config Class Initialized
INFO - 2018-11-01 12:55:16 --> Hooks Class Initialized
DEBUG - 2018-11-01 12:55:16 --> UTF-8 Support Enabled
INFO - 2018-11-01 12:55:16 --> Utf8 Class Initialized
INFO - 2018-11-01 12:55:16 --> URI Class Initialized
INFO - 2018-11-01 12:55:16 --> Router Class Initialized
INFO - 2018-11-01 12:55:16 --> Output Class Initialized
INFO - 2018-11-01 12:55:16 --> Security Class Initialized
DEBUG - 2018-11-01 12:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 12:55:16 --> CSRF cookie sent
INFO - 2018-11-01 12:55:16 --> Input Class Initialized
INFO - 2018-11-01 12:55:16 --> Language Class Initialized
INFO - 2018-11-01 12:55:16 --> Loader Class Initialized
INFO - 2018-11-01 12:55:16 --> Helper loaded: url_helper
INFO - 2018-11-01 12:55:16 --> Helper loaded: form_helper
INFO - 2018-11-01 12:55:16 --> Helper loaded: language_helper
DEBUG - 2018-11-01 12:55:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 12:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 12:55:16 --> User Agent Class Initialized
INFO - 2018-11-01 12:55:16 --> Controller Class Initialized
INFO - 2018-11-01 12:55:16 --> Helper loaded: directory_helper
INFO - 2018-11-01 12:55:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-11-01 12:55:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-11-01 12:55:16 --> Helper loaded: custom_helper
INFO - 2018-11-01 12:55:19 --> Database Driver Class Initialized
INFO - 2018-11-01 12:55:19 --> Database Utility Class Initialized
INFO - 2018-11-01 12:55:19 --> Database Utility Class Initialized
INFO - 2018-11-01 12:55:19 --> Zip Compression Class Initialized
ERROR - 2018-11-01 12:55:19 --> Severity: Notice --> Only variables should be assigned by reference E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 40
INFO - 2018-11-01 12:55:19 --> Helper loaded: file_helper
INFO - 2018-11-01 12:55:19 --> Final output sent to browser
DEBUG - 2018-11-01 12:55:19 --> Total execution time: 3.4082
INFO - 2018-11-01 12:55:53 --> Config Class Initialized
INFO - 2018-11-01 12:55:53 --> Hooks Class Initialized
DEBUG - 2018-11-01 12:55:53 --> UTF-8 Support Enabled
INFO - 2018-11-01 12:55:53 --> Utf8 Class Initialized
INFO - 2018-11-01 12:55:53 --> URI Class Initialized
INFO - 2018-11-01 12:55:53 --> Router Class Initialized
INFO - 2018-11-01 12:55:53 --> Output Class Initialized
INFO - 2018-11-01 12:55:53 --> Security Class Initialized
DEBUG - 2018-11-01 12:55:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 12:55:53 --> CSRF cookie sent
INFO - 2018-11-01 12:55:53 --> Input Class Initialized
INFO - 2018-11-01 12:55:53 --> Language Class Initialized
INFO - 2018-11-01 12:55:53 --> Loader Class Initialized
INFO - 2018-11-01 12:55:53 --> Helper loaded: url_helper
INFO - 2018-11-01 12:55:53 --> Helper loaded: form_helper
INFO - 2018-11-01 12:55:53 --> Helper loaded: language_helper
DEBUG - 2018-11-01 12:55:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 12:55:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 12:55:53 --> User Agent Class Initialized
INFO - 2018-11-01 12:55:53 --> Controller Class Initialized
INFO - 2018-11-01 12:55:53 --> Helper loaded: directory_helper
INFO - 2018-11-01 12:55:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-11-01 12:55:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-11-01 12:55:53 --> Helper loaded: custom_helper
INFO - 2018-11-01 12:55:56 --> Database Driver Class Initialized
INFO - 2018-11-01 12:55:56 --> Database Utility Class Initialized
INFO - 2018-11-01 12:55:56 --> Database Utility Class Initialized
INFO - 2018-11-01 12:55:56 --> Zip Compression Class Initialized
INFO - 2018-11-01 12:55:56 --> Helper loaded: file_helper
INFO - 2018-11-01 12:55:56 --> Final output sent to browser
DEBUG - 2018-11-01 12:55:56 --> Total execution time: 3.2506
INFO - 2018-11-01 13:07:25 --> Config Class Initialized
INFO - 2018-11-01 13:07:25 --> Hooks Class Initialized
DEBUG - 2018-11-01 13:07:25 --> UTF-8 Support Enabled
INFO - 2018-11-01 13:07:25 --> Utf8 Class Initialized
INFO - 2018-11-01 13:07:26 --> URI Class Initialized
DEBUG - 2018-11-01 13:07:26 --> No URI present. Default controller set.
INFO - 2018-11-01 13:07:26 --> Router Class Initialized
INFO - 2018-11-01 13:07:26 --> Output Class Initialized
INFO - 2018-11-01 13:07:26 --> Security Class Initialized
DEBUG - 2018-11-01 13:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 13:07:26 --> CSRF cookie sent
INFO - 2018-11-01 13:07:26 --> Input Class Initialized
INFO - 2018-11-01 13:07:26 --> Language Class Initialized
INFO - 2018-11-01 13:07:26 --> Loader Class Initialized
INFO - 2018-11-01 13:07:26 --> Helper loaded: url_helper
INFO - 2018-11-01 13:07:26 --> Helper loaded: form_helper
INFO - 2018-11-01 13:07:26 --> Helper loaded: language_helper
DEBUG - 2018-11-01 13:07:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 13:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 13:07:26 --> User Agent Class Initialized
INFO - 2018-11-01 13:07:26 --> Controller Class Initialized
INFO - 2018-11-01 13:07:26 --> Helper loaded: directory_helper
INFO - 2018-11-01 13:07:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-11-01 13:07:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-11-01 13:07:26 --> Helper loaded: custom_helper
INFO - 2018-11-01 13:07:26 --> Pixel_Model class loaded
INFO - 2018-11-01 13:07:26 --> Database Driver Class Initialized
INFO - 2018-11-01 13:07:26 --> Model "QuestionsModel" initialized
INFO - 2018-11-01 13:07:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-11-01 13:07:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-11-01 13:07:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-11-01 13:07:26 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-11-01 13:07:26 --> Final output sent to browser
DEBUG - 2018-11-01 13:07:26 --> Total execution time: 1.1170
INFO - 2018-11-01 13:48:17 --> Config Class Initialized
INFO - 2018-11-01 13:48:17 --> Hooks Class Initialized
DEBUG - 2018-11-01 13:48:17 --> UTF-8 Support Enabled
INFO - 2018-11-01 13:48:17 --> Utf8 Class Initialized
INFO - 2018-11-01 13:48:17 --> URI Class Initialized
INFO - 2018-11-01 13:48:17 --> Router Class Initialized
INFO - 2018-11-01 13:48:17 --> Output Class Initialized
INFO - 2018-11-01 13:48:17 --> Security Class Initialized
DEBUG - 2018-11-01 13:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 13:48:17 --> CSRF cookie sent
INFO - 2018-11-01 13:48:17 --> Input Class Initialized
INFO - 2018-11-01 13:48:17 --> Language Class Initialized
INFO - 2018-11-01 13:48:17 --> Loader Class Initialized
INFO - 2018-11-01 13:48:17 --> Helper loaded: url_helper
INFO - 2018-11-01 13:48:17 --> Helper loaded: form_helper
INFO - 2018-11-01 13:48:17 --> Helper loaded: language_helper
DEBUG - 2018-11-01 13:48:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 13:48:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 13:48:17 --> User Agent Class Initialized
INFO - 2018-11-01 13:48:17 --> Controller Class Initialized
INFO - 2018-11-01 13:48:17 --> Helper loaded: directory_helper
INFO - 2018-11-01 13:48:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-11-01 13:48:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-11-01 13:48:18 --> Helper loaded: custom_helper
INFO - 2018-11-01 13:48:18 --> Zip Compression Class Initialized
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:18 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:19 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:20 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:20 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:20 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:20 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:20 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:20 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:20 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:20 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:20 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:20 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:20 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:20 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:20 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:20 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:20 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:20 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:20 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:20 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:20 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:20 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:20 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:20 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:20 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:20 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:20 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:20 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:20 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:20 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:20 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:20 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:20 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:20 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:20 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:20 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:20 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:20 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:20 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:20 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:20 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:20 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:20 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:20 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:20 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:20 --> Zip class already loaded. Second attempt ignored.
INFO - 2018-11-01 13:48:20 --> Database Driver Class Initialized
INFO - 2018-11-01 13:48:20 --> Database Utility Class Initialized
INFO - 2018-11-01 13:48:20 --> Database Utility Class Initialized
DEBUG - 2018-11-01 13:48:20 --> Zip class already loaded. Second attempt ignored.
INFO - 2018-11-01 13:48:20 --> Helper loaded: file_helper
INFO - 2018-11-01 13:48:20 --> Final output sent to browser
DEBUG - 2018-11-01 13:48:20 --> Total execution time: 2.6697
INFO - 2018-11-01 13:48:48 --> Config Class Initialized
INFO - 2018-11-01 13:48:48 --> Hooks Class Initialized
DEBUG - 2018-11-01 13:48:48 --> UTF-8 Support Enabled
INFO - 2018-11-01 13:48:48 --> Utf8 Class Initialized
INFO - 2018-11-01 13:48:48 --> URI Class Initialized
INFO - 2018-11-01 13:48:48 --> Router Class Initialized
INFO - 2018-11-01 13:48:48 --> Output Class Initialized
INFO - 2018-11-01 13:48:48 --> Security Class Initialized
DEBUG - 2018-11-01 13:48:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 13:48:48 --> CSRF cookie sent
INFO - 2018-11-01 13:48:48 --> Input Class Initialized
INFO - 2018-11-01 13:48:48 --> Language Class Initialized
INFO - 2018-11-01 13:48:48 --> Loader Class Initialized
INFO - 2018-11-01 13:48:48 --> Helper loaded: url_helper
INFO - 2018-11-01 13:48:48 --> Helper loaded: form_helper
INFO - 2018-11-01 13:48:48 --> Helper loaded: language_helper
DEBUG - 2018-11-01 13:48:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 13:48:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 13:48:48 --> User Agent Class Initialized
INFO - 2018-11-01 13:48:48 --> Controller Class Initialized
INFO - 2018-11-01 13:48:48 --> Helper loaded: directory_helper
INFO - 2018-11-01 13:48:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-11-01 13:48:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-11-01 13:48:48 --> Helper loaded: custom_helper
INFO - 2018-11-01 13:48:48 --> Zip Compression Class Initialized
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
INFO - 2018-11-01 13:48:49 --> Database Driver Class Initialized
INFO - 2018-11-01 13:48:49 --> Database Utility Class Initialized
INFO - 2018-11-01 13:48:49 --> Database Utility Class Initialized
DEBUG - 2018-11-01 13:48:49 --> Zip class already loaded. Second attempt ignored.
INFO - 2018-11-01 13:48:49 --> Helper loaded: file_helper
INFO - 2018-11-01 13:48:49 --> Final output sent to browser
DEBUG - 2018-11-01 13:48:49 --> Total execution time: 0.5267
INFO - 2018-11-01 13:49:28 --> Config Class Initialized
INFO - 2018-11-01 13:49:28 --> Hooks Class Initialized
DEBUG - 2018-11-01 13:49:28 --> UTF-8 Support Enabled
INFO - 2018-11-01 13:49:28 --> Utf8 Class Initialized
INFO - 2018-11-01 13:49:28 --> URI Class Initialized
INFO - 2018-11-01 13:49:28 --> Router Class Initialized
INFO - 2018-11-01 13:49:28 --> Output Class Initialized
INFO - 2018-11-01 13:49:28 --> Security Class Initialized
DEBUG - 2018-11-01 13:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 13:49:28 --> CSRF cookie sent
INFO - 2018-11-01 13:49:28 --> Input Class Initialized
INFO - 2018-11-01 13:49:28 --> Language Class Initialized
INFO - 2018-11-01 13:49:28 --> Loader Class Initialized
INFO - 2018-11-01 13:49:28 --> Helper loaded: url_helper
INFO - 2018-11-01 13:49:28 --> Helper loaded: form_helper
INFO - 2018-11-01 13:49:28 --> Helper loaded: language_helper
DEBUG - 2018-11-01 13:49:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 13:49:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 13:49:28 --> User Agent Class Initialized
INFO - 2018-11-01 13:49:28 --> Controller Class Initialized
INFO - 2018-11-01 13:49:28 --> Helper loaded: directory_helper
INFO - 2018-11-01 13:49:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-11-01 13:49:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-11-01 13:49:28 --> Helper loaded: custom_helper
INFO - 2018-11-01 13:49:28 --> Zip Compression Class Initialized
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:28 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
INFO - 2018-11-01 13:49:29 --> Database Driver Class Initialized
INFO - 2018-11-01 13:49:29 --> Database Utility Class Initialized
INFO - 2018-11-01 13:49:29 --> Database Utility Class Initialized
DEBUG - 2018-11-01 13:49:29 --> Zip class already loaded. Second attempt ignored.
INFO - 2018-11-01 13:49:29 --> Helper loaded: file_helper
INFO - 2018-11-01 13:49:29 --> Final output sent to browser
DEBUG - 2018-11-01 13:49:29 --> Total execution time: 0.5295
INFO - 2018-11-01 13:49:47 --> Config Class Initialized
INFO - 2018-11-01 13:49:47 --> Hooks Class Initialized
DEBUG - 2018-11-01 13:49:47 --> UTF-8 Support Enabled
INFO - 2018-11-01 13:49:47 --> Utf8 Class Initialized
INFO - 2018-11-01 13:49:47 --> URI Class Initialized
INFO - 2018-11-01 13:49:47 --> Router Class Initialized
INFO - 2018-11-01 13:49:47 --> Output Class Initialized
INFO - 2018-11-01 13:49:47 --> Security Class Initialized
DEBUG - 2018-11-01 13:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 13:49:47 --> CSRF cookie sent
INFO - 2018-11-01 13:49:47 --> Input Class Initialized
INFO - 2018-11-01 13:49:47 --> Language Class Initialized
INFO - 2018-11-01 13:49:47 --> Loader Class Initialized
INFO - 2018-11-01 13:49:47 --> Helper loaded: url_helper
INFO - 2018-11-01 13:49:47 --> Helper loaded: form_helper
INFO - 2018-11-01 13:49:47 --> Helper loaded: language_helper
DEBUG - 2018-11-01 13:49:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 13:49:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 13:49:47 --> User Agent Class Initialized
INFO - 2018-11-01 13:49:47 --> Controller Class Initialized
INFO - 2018-11-01 13:49:47 --> Helper loaded: directory_helper
INFO - 2018-11-01 13:49:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-11-01 13:49:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-11-01 13:49:47 --> Helper loaded: custom_helper
INFO - 2018-11-01 13:49:47 --> Zip Compression Class Initialized
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:47 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
INFO - 2018-11-01 13:49:48 --> Database Driver Class Initialized
INFO - 2018-11-01 13:49:48 --> Database Utility Class Initialized
INFO - 2018-11-01 13:49:48 --> Database Utility Class Initialized
DEBUG - 2018-11-01 13:49:48 --> Zip class already loaded. Second attempt ignored.
INFO - 2018-11-01 13:49:48 --> Helper loaded: file_helper
INFO - 2018-11-01 13:49:48 --> Final output sent to browser
DEBUG - 2018-11-01 13:49:48 --> Total execution time: 0.4703
INFO - 2018-11-01 13:50:29 --> Config Class Initialized
INFO - 2018-11-01 13:50:29 --> Hooks Class Initialized
DEBUG - 2018-11-01 13:50:29 --> UTF-8 Support Enabled
INFO - 2018-11-01 13:50:29 --> Utf8 Class Initialized
INFO - 2018-11-01 13:50:29 --> URI Class Initialized
INFO - 2018-11-01 13:50:29 --> Router Class Initialized
INFO - 2018-11-01 13:50:29 --> Output Class Initialized
INFO - 2018-11-01 13:50:29 --> Security Class Initialized
DEBUG - 2018-11-01 13:50:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 13:50:29 --> CSRF cookie sent
INFO - 2018-11-01 13:50:29 --> Input Class Initialized
INFO - 2018-11-01 13:50:29 --> Language Class Initialized
INFO - 2018-11-01 13:50:29 --> Loader Class Initialized
INFO - 2018-11-01 13:50:29 --> Helper loaded: url_helper
INFO - 2018-11-01 13:50:29 --> Helper loaded: form_helper
INFO - 2018-11-01 13:50:29 --> Helper loaded: language_helper
DEBUG - 2018-11-01 13:50:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 13:50:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 13:50:29 --> User Agent Class Initialized
INFO - 2018-11-01 13:50:29 --> Controller Class Initialized
INFO - 2018-11-01 13:50:29 --> Helper loaded: directory_helper
INFO - 2018-11-01 13:50:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-11-01 13:50:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-11-01 13:50:29 --> Helper loaded: custom_helper
INFO - 2018-11-01 13:50:29 --> Zip Compression Class Initialized
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:29 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
INFO - 2018-11-01 13:50:30 --> Database Driver Class Initialized
INFO - 2018-11-01 13:50:30 --> Database Utility Class Initialized
INFO - 2018-11-01 13:50:30 --> Database Utility Class Initialized
DEBUG - 2018-11-01 13:50:30 --> Zip class already loaded. Second attempt ignored.
INFO - 2018-11-01 13:50:30 --> Helper loaded: file_helper
INFO - 2018-11-01 13:50:30 --> Final output sent to browser
DEBUG - 2018-11-01 13:50:30 --> Total execution time: 0.4556
INFO - 2018-11-01 13:52:13 --> Config Class Initialized
INFO - 2018-11-01 13:52:13 --> Hooks Class Initialized
DEBUG - 2018-11-01 13:52:13 --> UTF-8 Support Enabled
INFO - 2018-11-01 13:52:13 --> Utf8 Class Initialized
INFO - 2018-11-01 13:52:13 --> URI Class Initialized
INFO - 2018-11-01 13:52:13 --> Router Class Initialized
INFO - 2018-11-01 13:52:13 --> Output Class Initialized
INFO - 2018-11-01 13:52:13 --> Security Class Initialized
DEBUG - 2018-11-01 13:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 13:52:13 --> CSRF cookie sent
INFO - 2018-11-01 13:52:13 --> Input Class Initialized
INFO - 2018-11-01 13:52:13 --> Language Class Initialized
INFO - 2018-11-01 13:52:13 --> Loader Class Initialized
INFO - 2018-11-01 13:52:13 --> Helper loaded: url_helper
INFO - 2018-11-01 13:52:13 --> Helper loaded: form_helper
INFO - 2018-11-01 13:52:13 --> Helper loaded: language_helper
DEBUG - 2018-11-01 13:52:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 13:52:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 13:52:13 --> User Agent Class Initialized
INFO - 2018-11-01 13:52:13 --> Controller Class Initialized
INFO - 2018-11-01 13:52:13 --> Helper loaded: directory_helper
INFO - 2018-11-01 13:52:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-11-01 13:52:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-11-01 13:52:13 --> Helper loaded: custom_helper
INFO - 2018-11-01 13:52:13 --> Zip Compression Class Initialized
INFO - 2018-11-01 13:52:15 --> Database Driver Class Initialized
INFO - 2018-11-01 13:52:16 --> Database Utility Class Initialized
INFO - 2018-11-01 13:52:16 --> Database Utility Class Initialized
DEBUG - 2018-11-01 13:52:16 --> Zip class already loaded. Second attempt ignored.
INFO - 2018-11-01 13:52:16 --> Helper loaded: file_helper
INFO - 2018-11-01 13:52:16 --> Final output sent to browser
DEBUG - 2018-11-01 13:52:16 --> Total execution time: 2.9880
INFO - 2018-11-01 13:52:44 --> Config Class Initialized
INFO - 2018-11-01 13:52:44 --> Hooks Class Initialized
DEBUG - 2018-11-01 13:52:44 --> UTF-8 Support Enabled
INFO - 2018-11-01 13:52:44 --> Utf8 Class Initialized
INFO - 2018-11-01 13:52:44 --> URI Class Initialized
INFO - 2018-11-01 13:52:44 --> Router Class Initialized
INFO - 2018-11-01 13:52:44 --> Output Class Initialized
INFO - 2018-11-01 13:52:44 --> Security Class Initialized
DEBUG - 2018-11-01 13:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 13:52:44 --> CSRF cookie sent
INFO - 2018-11-01 13:52:44 --> Input Class Initialized
INFO - 2018-11-01 13:52:44 --> Language Class Initialized
INFO - 2018-11-01 13:52:44 --> Loader Class Initialized
INFO - 2018-11-01 13:52:44 --> Helper loaded: url_helper
INFO - 2018-11-01 13:52:44 --> Helper loaded: form_helper
INFO - 2018-11-01 13:52:44 --> Helper loaded: language_helper
DEBUG - 2018-11-01 13:52:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 13:52:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 13:52:44 --> User Agent Class Initialized
INFO - 2018-11-01 13:52:44 --> Controller Class Initialized
INFO - 2018-11-01 13:52:44 --> Helper loaded: directory_helper
INFO - 2018-11-01 13:52:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-11-01 13:52:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-11-01 13:52:44 --> Helper loaded: custom_helper
INFO - 2018-11-01 13:52:44 --> Zip Compression Class Initialized
INFO - 2018-11-01 13:52:45 --> Database Driver Class Initialized
INFO - 2018-11-01 13:52:45 --> Database Utility Class Initialized
INFO - 2018-11-01 13:52:45 --> Database Utility Class Initialized
DEBUG - 2018-11-01 13:52:45 --> Zip class already loaded. Second attempt ignored.
INFO - 2018-11-01 13:52:45 --> Helper loaded: file_helper
INFO - 2018-11-01 13:52:45 --> Final output sent to browser
DEBUG - 2018-11-01 13:52:45 --> Total execution time: 0.3651
INFO - 2018-11-01 13:53:01 --> Config Class Initialized
INFO - 2018-11-01 13:53:01 --> Hooks Class Initialized
DEBUG - 2018-11-01 13:53:01 --> UTF-8 Support Enabled
INFO - 2018-11-01 13:53:01 --> Utf8 Class Initialized
INFO - 2018-11-01 13:53:01 --> URI Class Initialized
INFO - 2018-11-01 13:53:01 --> Router Class Initialized
INFO - 2018-11-01 13:53:01 --> Output Class Initialized
INFO - 2018-11-01 13:53:01 --> Security Class Initialized
DEBUG - 2018-11-01 13:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 13:53:01 --> CSRF cookie sent
INFO - 2018-11-01 13:53:01 --> Input Class Initialized
INFO - 2018-11-01 13:53:01 --> Language Class Initialized
INFO - 2018-11-01 13:53:01 --> Loader Class Initialized
INFO - 2018-11-01 13:53:01 --> Helper loaded: url_helper
INFO - 2018-11-01 13:53:01 --> Helper loaded: form_helper
INFO - 2018-11-01 13:53:01 --> Helper loaded: language_helper
DEBUG - 2018-11-01 13:53:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 13:53:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 13:53:01 --> User Agent Class Initialized
INFO - 2018-11-01 13:53:01 --> Controller Class Initialized
INFO - 2018-11-01 13:53:01 --> Helper loaded: directory_helper
INFO - 2018-11-01 13:53:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-11-01 13:53:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-11-01 13:53:01 --> Helper loaded: custom_helper
INFO - 2018-11-01 13:53:01 --> Zip Compression Class Initialized
INFO - 2018-11-01 13:53:01 --> Database Driver Class Initialized
INFO - 2018-11-01 13:53:01 --> Database Utility Class Initialized
INFO - 2018-11-01 13:53:01 --> Database Utility Class Initialized
DEBUG - 2018-11-01 13:53:01 --> Zip class already loaded. Second attempt ignored.
INFO - 2018-11-01 13:53:01 --> Helper loaded: file_helper
INFO - 2018-11-01 13:53:01 --> Final output sent to browser
DEBUG - 2018-11-01 13:53:01 --> Total execution time: 0.4272
INFO - 2018-11-01 14:00:38 --> Config Class Initialized
INFO - 2018-11-01 14:00:38 --> Hooks Class Initialized
DEBUG - 2018-11-01 14:00:38 --> UTF-8 Support Enabled
INFO - 2018-11-01 14:00:38 --> Utf8 Class Initialized
INFO - 2018-11-01 14:00:38 --> URI Class Initialized
INFO - 2018-11-01 14:00:38 --> Router Class Initialized
INFO - 2018-11-01 14:00:38 --> Output Class Initialized
INFO - 2018-11-01 14:00:38 --> Security Class Initialized
DEBUG - 2018-11-01 14:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 14:00:38 --> CSRF cookie sent
INFO - 2018-11-01 14:00:38 --> Input Class Initialized
INFO - 2018-11-01 14:00:38 --> Language Class Initialized
INFO - 2018-11-01 14:00:38 --> Loader Class Initialized
INFO - 2018-11-01 14:00:38 --> Helper loaded: url_helper
INFO - 2018-11-01 14:00:38 --> Helper loaded: form_helper
INFO - 2018-11-01 14:00:38 --> Helper loaded: language_helper
DEBUG - 2018-11-01 14:00:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 14:00:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 14:00:38 --> User Agent Class Initialized
INFO - 2018-11-01 14:00:38 --> Controller Class Initialized
INFO - 2018-11-01 14:00:38 --> Helper loaded: directory_helper
INFO - 2018-11-01 14:00:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-11-01 14:00:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-11-01 14:00:38 --> Helper loaded: custom_helper
INFO - 2018-11-01 14:00:38 --> Zip Compression Class Initialized
INFO - 2018-11-01 14:00:41 --> Helper loaded: download_helper
INFO - 2018-11-01 14:01:26 --> Config Class Initialized
INFO - 2018-11-01 14:01:26 --> Hooks Class Initialized
DEBUG - 2018-11-01 14:01:26 --> UTF-8 Support Enabled
INFO - 2018-11-01 14:01:26 --> Utf8 Class Initialized
INFO - 2018-11-01 14:01:26 --> URI Class Initialized
INFO - 2018-11-01 14:01:26 --> Router Class Initialized
INFO - 2018-11-01 14:01:26 --> Output Class Initialized
INFO - 2018-11-01 14:01:26 --> Security Class Initialized
DEBUG - 2018-11-01 14:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 14:01:26 --> CSRF cookie sent
INFO - 2018-11-01 14:01:26 --> Input Class Initialized
INFO - 2018-11-01 14:01:26 --> Language Class Initialized
INFO - 2018-11-01 14:01:26 --> Loader Class Initialized
INFO - 2018-11-01 14:01:26 --> Helper loaded: url_helper
INFO - 2018-11-01 14:01:26 --> Helper loaded: form_helper
INFO - 2018-11-01 14:01:26 --> Helper loaded: language_helper
DEBUG - 2018-11-01 14:01:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 14:01:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 14:01:26 --> User Agent Class Initialized
INFO - 2018-11-01 14:01:26 --> Controller Class Initialized
INFO - 2018-11-01 14:01:26 --> Helper loaded: directory_helper
INFO - 2018-11-01 14:01:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-11-01 14:01:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-11-01 14:01:26 --> Helper loaded: custom_helper
INFO - 2018-11-01 14:01:26 --> Zip Compression Class Initialized
INFO - 2018-11-01 14:01:27 --> Helper loaded: download_helper
INFO - 2018-11-01 14:02:55 --> Config Class Initialized
INFO - 2018-11-01 14:02:55 --> Hooks Class Initialized
DEBUG - 2018-11-01 14:02:55 --> UTF-8 Support Enabled
INFO - 2018-11-01 14:02:55 --> Utf8 Class Initialized
INFO - 2018-11-01 14:02:55 --> URI Class Initialized
INFO - 2018-11-01 14:02:55 --> Router Class Initialized
INFO - 2018-11-01 14:02:55 --> Output Class Initialized
INFO - 2018-11-01 14:02:55 --> Security Class Initialized
DEBUG - 2018-11-01 14:02:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 14:02:55 --> CSRF cookie sent
INFO - 2018-11-01 14:02:55 --> Input Class Initialized
INFO - 2018-11-01 14:02:55 --> Language Class Initialized
INFO - 2018-11-01 14:02:55 --> Loader Class Initialized
INFO - 2018-11-01 14:02:55 --> Helper loaded: url_helper
INFO - 2018-11-01 14:02:55 --> Helper loaded: form_helper
INFO - 2018-11-01 14:02:55 --> Helper loaded: language_helper
DEBUG - 2018-11-01 14:02:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 14:02:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 14:02:55 --> User Agent Class Initialized
INFO - 2018-11-01 14:02:55 --> Controller Class Initialized
INFO - 2018-11-01 14:02:55 --> Helper loaded: directory_helper
INFO - 2018-11-01 14:02:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-11-01 14:02:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-11-01 14:02:55 --> Helper loaded: custom_helper
INFO - 2018-11-01 14:02:55 --> Zip Compression Class Initialized
INFO - 2018-11-01 14:02:58 --> Database Driver Class Initialized
INFO - 2018-11-01 14:02:59 --> Database Utility Class Initialized
INFO - 2018-11-01 14:02:59 --> Database Utility Class Initialized
DEBUG - 2018-11-01 14:02:59 --> Zip class already loaded. Second attempt ignored.
INFO - 2018-11-01 14:02:59 --> Helper loaded: file_helper
INFO - 2018-11-01 14:02:59 --> Final output sent to browser
DEBUG - 2018-11-01 14:02:59 --> Total execution time: 3.8411
INFO - 2018-11-01 14:04:49 --> Config Class Initialized
INFO - 2018-11-01 14:04:49 --> Hooks Class Initialized
DEBUG - 2018-11-01 14:04:49 --> UTF-8 Support Enabled
INFO - 2018-11-01 14:04:49 --> Utf8 Class Initialized
INFO - 2018-11-01 14:04:49 --> URI Class Initialized
INFO - 2018-11-01 14:04:49 --> Router Class Initialized
INFO - 2018-11-01 14:04:49 --> Output Class Initialized
INFO - 2018-11-01 14:04:49 --> Security Class Initialized
DEBUG - 2018-11-01 14:04:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 14:04:49 --> CSRF cookie sent
INFO - 2018-11-01 14:04:49 --> Input Class Initialized
INFO - 2018-11-01 14:04:49 --> Language Class Initialized
INFO - 2018-11-01 14:04:49 --> Loader Class Initialized
INFO - 2018-11-01 14:04:49 --> Helper loaded: url_helper
INFO - 2018-11-01 14:04:49 --> Helper loaded: form_helper
INFO - 2018-11-01 14:04:49 --> Helper loaded: language_helper
DEBUG - 2018-11-01 14:04:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 14:04:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 14:04:49 --> User Agent Class Initialized
INFO - 2018-11-01 14:04:49 --> Controller Class Initialized
INFO - 2018-11-01 14:04:49 --> Helper loaded: directory_helper
INFO - 2018-11-01 14:04:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-11-01 14:04:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-11-01 14:04:49 --> Helper loaded: custom_helper
INFO - 2018-11-01 14:04:49 --> Zip Compression Class Initialized
INFO - 2018-11-01 14:04:49 --> Helper loaded: file_helper
INFO - 2018-11-01 14:04:49 --> Database Driver Class Initialized
INFO - 2018-11-01 14:04:49 --> Database Utility Class Initialized
INFO - 2018-11-01 14:04:49 --> Database Utility Class Initialized
DEBUG - 2018-11-01 14:04:49 --> Zip class already loaded. Second attempt ignored.
INFO - 2018-11-01 14:04:49 --> Final output sent to browser
DEBUG - 2018-11-01 14:04:49 --> Total execution time: 0.3614
INFO - 2018-11-01 14:12:12 --> Config Class Initialized
INFO - 2018-11-01 14:12:12 --> Hooks Class Initialized
DEBUG - 2018-11-01 14:12:12 --> UTF-8 Support Enabled
INFO - 2018-11-01 14:12:12 --> Utf8 Class Initialized
INFO - 2018-11-01 14:12:12 --> URI Class Initialized
INFO - 2018-11-01 14:12:12 --> Router Class Initialized
INFO - 2018-11-01 14:12:12 --> Output Class Initialized
INFO - 2018-11-01 14:12:12 --> Security Class Initialized
DEBUG - 2018-11-01 14:12:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 14:12:12 --> CSRF cookie sent
INFO - 2018-11-01 14:12:12 --> Input Class Initialized
INFO - 2018-11-01 14:12:12 --> Language Class Initialized
INFO - 2018-11-01 14:12:12 --> Loader Class Initialized
INFO - 2018-11-01 14:12:12 --> Helper loaded: url_helper
INFO - 2018-11-01 14:12:12 --> Helper loaded: form_helper
INFO - 2018-11-01 14:12:12 --> Helper loaded: language_helper
DEBUG - 2018-11-01 14:12:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 14:12:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 14:12:12 --> User Agent Class Initialized
INFO - 2018-11-01 14:12:12 --> Controller Class Initialized
INFO - 2018-11-01 14:12:12 --> Helper loaded: directory_helper
INFO - 2018-11-01 14:12:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-11-01 14:12:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-11-01 14:12:12 --> Helper loaded: custom_helper
INFO - 2018-11-01 14:12:12 --> Zip Compression Class Initialized
INFO - 2018-11-01 14:12:12 --> Helper loaded: file_helper
INFO - 2018-11-01 14:12:16 --> Helper loaded: download_helper
INFO - 2018-11-01 14:12:58 --> Config Class Initialized
INFO - 2018-11-01 14:12:58 --> Hooks Class Initialized
DEBUG - 2018-11-01 14:12:58 --> UTF-8 Support Enabled
INFO - 2018-11-01 14:12:58 --> Utf8 Class Initialized
INFO - 2018-11-01 14:12:58 --> URI Class Initialized
INFO - 2018-11-01 14:12:58 --> Router Class Initialized
INFO - 2018-11-01 14:12:58 --> Output Class Initialized
INFO - 2018-11-01 14:12:58 --> Security Class Initialized
DEBUG - 2018-11-01 14:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 14:12:58 --> CSRF cookie sent
INFO - 2018-11-01 14:12:58 --> Input Class Initialized
INFO - 2018-11-01 14:12:58 --> Language Class Initialized
INFO - 2018-11-01 14:12:58 --> Loader Class Initialized
INFO - 2018-11-01 14:12:58 --> Helper loaded: url_helper
INFO - 2018-11-01 14:12:58 --> Helper loaded: form_helper
INFO - 2018-11-01 14:12:58 --> Helper loaded: language_helper
DEBUG - 2018-11-01 14:12:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 14:12:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 14:12:58 --> User Agent Class Initialized
INFO - 2018-11-01 14:12:58 --> Controller Class Initialized
INFO - 2018-11-01 14:12:58 --> Helper loaded: directory_helper
INFO - 2018-11-01 14:12:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-11-01 14:12:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-11-01 14:12:58 --> Helper loaded: custom_helper
INFO - 2018-11-01 14:12:58 --> Zip Compression Class Initialized
INFO - 2018-11-01 14:12:58 --> Helper loaded: file_helper
INFO - 2018-11-01 14:12:58 --> Helper loaded: download_helper
INFO - 2018-11-01 16:05:03 --> Config Class Initialized
INFO - 2018-11-01 16:05:03 --> Hooks Class Initialized
DEBUG - 2018-11-01 16:05:03 --> UTF-8 Support Enabled
INFO - 2018-11-01 16:05:03 --> Utf8 Class Initialized
INFO - 2018-11-01 16:05:03 --> URI Class Initialized
INFO - 2018-11-01 16:05:03 --> Router Class Initialized
INFO - 2018-11-01 16:05:03 --> Output Class Initialized
INFO - 2018-11-01 16:05:03 --> Security Class Initialized
DEBUG - 2018-11-01 16:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 16:05:03 --> CSRF cookie sent
INFO - 2018-11-01 16:05:03 --> Input Class Initialized
INFO - 2018-11-01 16:05:03 --> Language Class Initialized
ERROR - 2018-11-01 16:05:03 --> Severity: error --> Exception: Call to a member function library() on null E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 10
INFO - 2018-11-01 16:05:17 --> Config Class Initialized
INFO - 2018-11-01 16:05:17 --> Hooks Class Initialized
DEBUG - 2018-11-01 16:05:17 --> UTF-8 Support Enabled
INFO - 2018-11-01 16:05:17 --> Utf8 Class Initialized
INFO - 2018-11-01 16:05:17 --> URI Class Initialized
INFO - 2018-11-01 16:05:17 --> Router Class Initialized
INFO - 2018-11-01 16:05:17 --> Output Class Initialized
INFO - 2018-11-01 16:05:17 --> Security Class Initialized
DEBUG - 2018-11-01 16:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 16:05:17 --> CSRF cookie sent
INFO - 2018-11-01 16:05:17 --> Input Class Initialized
INFO - 2018-11-01 16:05:17 --> Language Class Initialized
ERROR - 2018-11-01 16:05:17 --> Severity: Notice --> Undefined property: BackupController::$load E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 10
ERROR - 2018-11-01 16:05:17 --> Severity: error --> Exception: Call to a member function library() on null E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 10
INFO - 2018-11-01 16:06:53 --> Config Class Initialized
INFO - 2018-11-01 16:06:53 --> Hooks Class Initialized
DEBUG - 2018-11-01 16:06:53 --> UTF-8 Support Enabled
INFO - 2018-11-01 16:06:53 --> Utf8 Class Initialized
INFO - 2018-11-01 16:06:53 --> URI Class Initialized
INFO - 2018-11-01 16:06:53 --> Router Class Initialized
INFO - 2018-11-01 16:06:53 --> Output Class Initialized
INFO - 2018-11-01 16:06:53 --> Security Class Initialized
DEBUG - 2018-11-01 16:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 16:06:53 --> CSRF cookie sent
INFO - 2018-11-01 16:06:53 --> Input Class Initialized
INFO - 2018-11-01 16:06:53 --> Language Class Initialized
ERROR - 2018-11-01 16:06:53 --> Severity: Notice --> Undefined property: BackupController::$load E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 11
ERROR - 2018-11-01 16:06:53 --> Severity: error --> Exception: Call to a member function helper() on null E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 11
INFO - 2018-11-01 16:07:20 --> Config Class Initialized
INFO - 2018-11-01 16:07:20 --> Hooks Class Initialized
DEBUG - 2018-11-01 16:07:20 --> UTF-8 Support Enabled
INFO - 2018-11-01 16:07:20 --> Utf8 Class Initialized
INFO - 2018-11-01 16:07:20 --> URI Class Initialized
INFO - 2018-11-01 16:07:20 --> Router Class Initialized
INFO - 2018-11-01 16:07:20 --> Output Class Initialized
INFO - 2018-11-01 16:07:20 --> Security Class Initialized
DEBUG - 2018-11-01 16:07:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 16:07:20 --> CSRF cookie sent
INFO - 2018-11-01 16:07:20 --> Input Class Initialized
INFO - 2018-11-01 16:07:20 --> Language Class Initialized
INFO - 2018-11-01 16:07:20 --> Loader Class Initialized
INFO - 2018-11-01 16:07:20 --> Helper loaded: url_helper
INFO - 2018-11-01 16:07:20 --> Helper loaded: form_helper
INFO - 2018-11-01 16:07:20 --> Helper loaded: language_helper
DEBUG - 2018-11-01 16:07:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 16:07:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 16:07:20 --> User Agent Class Initialized
INFO - 2018-11-01 16:07:20 --> Controller Class Initialized
INFO - 2018-11-01 16:07:20 --> Helper loaded: file_helper
INFO - 2018-11-01 16:07:20 --> Helper loaded: directory_helper
INFO - 2018-11-01 16:07:20 --> Zip Compression Class Initialized
INFO - 2018-11-01 16:07:24 --> Final output sent to browser
DEBUG - 2018-11-01 16:07:24 --> Total execution time: 4.2933
INFO - 2018-11-01 16:08:32 --> Config Class Initialized
INFO - 2018-11-01 16:08:32 --> Hooks Class Initialized
DEBUG - 2018-11-01 16:08:32 --> UTF-8 Support Enabled
INFO - 2018-11-01 16:08:32 --> Utf8 Class Initialized
INFO - 2018-11-01 16:08:32 --> URI Class Initialized
INFO - 2018-11-01 16:08:32 --> Router Class Initialized
INFO - 2018-11-01 16:08:32 --> Output Class Initialized
INFO - 2018-11-01 16:08:32 --> Security Class Initialized
DEBUG - 2018-11-01 16:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 16:08:32 --> CSRF cookie sent
INFO - 2018-11-01 16:08:32 --> Input Class Initialized
INFO - 2018-11-01 16:08:32 --> Language Class Initialized
INFO - 2018-11-01 16:08:32 --> Loader Class Initialized
INFO - 2018-11-01 16:08:32 --> Helper loaded: url_helper
INFO - 2018-11-01 16:08:32 --> Helper loaded: form_helper
INFO - 2018-11-01 16:08:32 --> Helper loaded: language_helper
DEBUG - 2018-11-01 16:08:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 16:08:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 16:08:32 --> User Agent Class Initialized
INFO - 2018-11-01 16:08:32 --> Controller Class Initialized
INFO - 2018-11-01 16:08:32 --> Helper loaded: file_helper
INFO - 2018-11-01 16:08:32 --> Helper loaded: directory_helper
INFO - 2018-11-01 16:08:32 --> Zip Compression Class Initialized
INFO - 2018-11-01 16:08:33 --> Final output sent to browser
DEBUG - 2018-11-01 16:08:33 --> Total execution time: 1.1433
INFO - 2018-11-01 16:10:34 --> Config Class Initialized
INFO - 2018-11-01 16:10:34 --> Hooks Class Initialized
DEBUG - 2018-11-01 16:10:34 --> UTF-8 Support Enabled
INFO - 2018-11-01 16:10:34 --> Utf8 Class Initialized
INFO - 2018-11-01 16:10:34 --> URI Class Initialized
INFO - 2018-11-01 16:10:34 --> Router Class Initialized
INFO - 2018-11-01 16:10:34 --> Output Class Initialized
INFO - 2018-11-01 16:10:34 --> Security Class Initialized
DEBUG - 2018-11-01 16:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 16:10:34 --> CSRF cookie sent
INFO - 2018-11-01 16:10:34 --> Input Class Initialized
INFO - 2018-11-01 16:10:34 --> Language Class Initialized
INFO - 2018-11-01 16:10:34 --> Loader Class Initialized
INFO - 2018-11-01 16:10:34 --> Helper loaded: url_helper
INFO - 2018-11-01 16:10:34 --> Helper loaded: form_helper
INFO - 2018-11-01 16:10:34 --> Helper loaded: language_helper
DEBUG - 2018-11-01 16:10:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 16:10:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 16:10:34 --> User Agent Class Initialized
INFO - 2018-11-01 16:10:34 --> Controller Class Initialized
INFO - 2018-11-01 16:10:34 --> Helper loaded: file_helper
INFO - 2018-11-01 16:10:34 --> Helper loaded: directory_helper
INFO - 2018-11-01 16:10:34 --> Zip Compression Class Initialized
INFO - 2018-11-01 16:11:12 --> Config Class Initialized
INFO - 2018-11-01 16:11:12 --> Hooks Class Initialized
DEBUG - 2018-11-01 16:11:12 --> UTF-8 Support Enabled
INFO - 2018-11-01 16:11:12 --> Utf8 Class Initialized
INFO - 2018-11-01 16:11:12 --> URI Class Initialized
INFO - 2018-11-01 16:11:12 --> Router Class Initialized
INFO - 2018-11-01 16:11:12 --> Output Class Initialized
INFO - 2018-11-01 16:11:12 --> Security Class Initialized
DEBUG - 2018-11-01 16:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 16:11:12 --> CSRF cookie sent
INFO - 2018-11-01 16:11:12 --> Input Class Initialized
INFO - 2018-11-01 16:11:12 --> Language Class Initialized
INFO - 2018-11-01 16:11:12 --> Loader Class Initialized
INFO - 2018-11-01 16:11:12 --> Helper loaded: url_helper
INFO - 2018-11-01 16:11:12 --> Helper loaded: form_helper
INFO - 2018-11-01 16:11:12 --> Helper loaded: language_helper
DEBUG - 2018-11-01 16:11:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 16:11:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 16:11:12 --> User Agent Class Initialized
INFO - 2018-11-01 16:11:12 --> Controller Class Initialized
INFO - 2018-11-01 16:11:12 --> Helper loaded: file_helper
INFO - 2018-11-01 16:11:12 --> Helper loaded: directory_helper
INFO - 2018-11-01 16:11:12 --> Zip Compression Class Initialized
INFO - 2018-11-01 16:11:23 --> Config Class Initialized
INFO - 2018-11-01 16:11:23 --> Hooks Class Initialized
DEBUG - 2018-11-01 16:11:23 --> UTF-8 Support Enabled
INFO - 2018-11-01 16:11:23 --> Utf8 Class Initialized
INFO - 2018-11-01 16:11:23 --> URI Class Initialized
INFO - 2018-11-01 16:11:23 --> Router Class Initialized
INFO - 2018-11-01 16:11:23 --> Output Class Initialized
INFO - 2018-11-01 16:11:23 --> Security Class Initialized
DEBUG - 2018-11-01 16:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 16:11:23 --> CSRF cookie sent
INFO - 2018-11-01 16:11:23 --> Input Class Initialized
INFO - 2018-11-01 16:11:23 --> Language Class Initialized
INFO - 2018-11-01 16:11:23 --> Loader Class Initialized
INFO - 2018-11-01 16:11:23 --> Helper loaded: url_helper
INFO - 2018-11-01 16:11:23 --> Helper loaded: form_helper
INFO - 2018-11-01 16:11:23 --> Helper loaded: language_helper
DEBUG - 2018-11-01 16:11:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 16:11:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 16:11:23 --> User Agent Class Initialized
INFO - 2018-11-01 16:11:23 --> Controller Class Initialized
INFO - 2018-11-01 16:11:23 --> Helper loaded: file_helper
INFO - 2018-11-01 16:11:23 --> Helper loaded: directory_helper
INFO - 2018-11-01 16:11:23 --> Zip Compression Class Initialized
INFO - 2018-11-01 16:13:07 --> Config Class Initialized
INFO - 2018-11-01 16:13:07 --> Hooks Class Initialized
DEBUG - 2018-11-01 16:13:07 --> UTF-8 Support Enabled
INFO - 2018-11-01 16:13:07 --> Utf8 Class Initialized
INFO - 2018-11-01 16:13:07 --> URI Class Initialized
INFO - 2018-11-01 16:13:07 --> Router Class Initialized
INFO - 2018-11-01 16:13:07 --> Output Class Initialized
INFO - 2018-11-01 16:13:07 --> Security Class Initialized
DEBUG - 2018-11-01 16:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 16:13:07 --> CSRF cookie sent
INFO - 2018-11-01 16:13:07 --> Input Class Initialized
INFO - 2018-11-01 16:13:07 --> Language Class Initialized
INFO - 2018-11-01 16:13:07 --> Loader Class Initialized
INFO - 2018-11-01 16:13:07 --> Helper loaded: url_helper
INFO - 2018-11-01 16:13:07 --> Helper loaded: form_helper
INFO - 2018-11-01 16:13:07 --> Helper loaded: language_helper
DEBUG - 2018-11-01 16:13:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 16:13:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 16:13:07 --> User Agent Class Initialized
INFO - 2018-11-01 16:13:07 --> Controller Class Initialized
INFO - 2018-11-01 16:13:07 --> Helper loaded: file_helper
INFO - 2018-11-01 16:13:07 --> Helper loaded: directory_helper
INFO - 2018-11-01 16:13:07 --> Zip Compression Class Initialized
INFO - 2018-11-01 16:13:10 --> Final output sent to browser
DEBUG - 2018-11-01 16:13:10 --> Total execution time: 3.1372
INFO - 2018-11-01 16:16:33 --> Config Class Initialized
INFO - 2018-11-01 16:16:33 --> Hooks Class Initialized
DEBUG - 2018-11-01 16:16:33 --> UTF-8 Support Enabled
INFO - 2018-11-01 16:16:33 --> Utf8 Class Initialized
INFO - 2018-11-01 16:16:33 --> URI Class Initialized
INFO - 2018-11-01 16:16:33 --> Router Class Initialized
INFO - 2018-11-01 16:16:33 --> Output Class Initialized
INFO - 2018-11-01 16:16:33 --> Security Class Initialized
DEBUG - 2018-11-01 16:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 16:16:33 --> CSRF cookie sent
INFO - 2018-11-01 16:16:33 --> Input Class Initialized
INFO - 2018-11-01 16:16:33 --> Language Class Initialized
INFO - 2018-11-01 16:16:33 --> Loader Class Initialized
INFO - 2018-11-01 16:16:33 --> Helper loaded: url_helper
INFO - 2018-11-01 16:16:33 --> Helper loaded: form_helper
INFO - 2018-11-01 16:16:33 --> Helper loaded: language_helper
DEBUG - 2018-11-01 16:16:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 16:16:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 16:16:33 --> User Agent Class Initialized
INFO - 2018-11-01 16:16:33 --> Controller Class Initialized
INFO - 2018-11-01 16:16:33 --> Helper loaded: file_helper
INFO - 2018-11-01 16:16:33 --> Helper loaded: directory_helper
INFO - 2018-11-01 16:16:33 --> Zip Compression Class Initialized
INFO - 2018-11-01 16:16:33 --> Helper loaded: download_helper
INFO - 2018-11-01 16:19:54 --> Config Class Initialized
INFO - 2018-11-01 16:19:54 --> Hooks Class Initialized
DEBUG - 2018-11-01 16:19:54 --> UTF-8 Support Enabled
INFO - 2018-11-01 16:19:54 --> Utf8 Class Initialized
INFO - 2018-11-01 16:19:54 --> URI Class Initialized
INFO - 2018-11-01 16:19:54 --> Router Class Initialized
INFO - 2018-11-01 16:19:54 --> Output Class Initialized
INFO - 2018-11-01 16:19:54 --> Security Class Initialized
DEBUG - 2018-11-01 16:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 16:19:54 --> CSRF cookie sent
INFO - 2018-11-01 16:19:54 --> Input Class Initialized
INFO - 2018-11-01 16:19:54 --> Language Class Initialized
ERROR - 2018-11-01 16:19:54 --> Severity: error --> Exception: syntax error, unexpected '.', expecting variable (T_VARIABLE) or '{' or '$' E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 87
INFO - 2018-11-01 16:20:21 --> Config Class Initialized
INFO - 2018-11-01 16:20:21 --> Hooks Class Initialized
DEBUG - 2018-11-01 16:20:21 --> UTF-8 Support Enabled
INFO - 2018-11-01 16:20:21 --> Utf8 Class Initialized
INFO - 2018-11-01 16:20:21 --> URI Class Initialized
INFO - 2018-11-01 16:20:21 --> Router Class Initialized
INFO - 2018-11-01 16:20:21 --> Output Class Initialized
INFO - 2018-11-01 16:20:21 --> Security Class Initialized
DEBUG - 2018-11-01 16:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 16:20:21 --> CSRF cookie sent
INFO - 2018-11-01 16:20:21 --> Input Class Initialized
INFO - 2018-11-01 16:20:21 --> Language Class Initialized
INFO - 2018-11-01 16:20:21 --> Loader Class Initialized
INFO - 2018-11-01 16:20:21 --> Helper loaded: url_helper
INFO - 2018-11-01 16:20:21 --> Helper loaded: form_helper
INFO - 2018-11-01 16:20:21 --> Helper loaded: language_helper
DEBUG - 2018-11-01 16:20:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 16:20:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 16:20:21 --> User Agent Class Initialized
INFO - 2018-11-01 16:20:21 --> Controller Class Initialized
INFO - 2018-11-01 16:20:21 --> Helper loaded: file_helper
INFO - 2018-11-01 16:20:21 --> Helper loaded: directory_helper
INFO - 2018-11-01 16:20:21 --> Zip Compression Class Initialized
INFO - 2018-11-01 16:20:21 --> Helper loaded: download_helper
INFO - 2018-11-01 16:21:25 --> Config Class Initialized
INFO - 2018-11-01 16:21:25 --> Hooks Class Initialized
DEBUG - 2018-11-01 16:21:25 --> UTF-8 Support Enabled
INFO - 2018-11-01 16:21:25 --> Utf8 Class Initialized
INFO - 2018-11-01 16:21:25 --> URI Class Initialized
INFO - 2018-11-01 16:21:25 --> Router Class Initialized
INFO - 2018-11-01 16:21:25 --> Output Class Initialized
INFO - 2018-11-01 16:21:25 --> Security Class Initialized
DEBUG - 2018-11-01 16:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 16:21:25 --> CSRF cookie sent
INFO - 2018-11-01 16:21:25 --> Input Class Initialized
INFO - 2018-11-01 16:21:25 --> Language Class Initialized
INFO - 2018-11-01 16:21:25 --> Loader Class Initialized
INFO - 2018-11-01 16:21:25 --> Helper loaded: url_helper
INFO - 2018-11-01 16:21:25 --> Helper loaded: form_helper
INFO - 2018-11-01 16:21:25 --> Helper loaded: language_helper
DEBUG - 2018-11-01 16:21:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 16:21:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 16:21:25 --> User Agent Class Initialized
INFO - 2018-11-01 16:21:25 --> Controller Class Initialized
INFO - 2018-11-01 16:21:25 --> Helper loaded: file_helper
INFO - 2018-11-01 16:21:25 --> Helper loaded: directory_helper
INFO - 2018-11-01 16:21:25 --> Zip Compression Class Initialized
INFO - 2018-11-01 16:21:45 --> Config Class Initialized
INFO - 2018-11-01 16:21:45 --> Hooks Class Initialized
DEBUG - 2018-11-01 16:21:45 --> UTF-8 Support Enabled
INFO - 2018-11-01 16:21:45 --> Utf8 Class Initialized
INFO - 2018-11-01 16:21:45 --> URI Class Initialized
INFO - 2018-11-01 16:21:45 --> Router Class Initialized
INFO - 2018-11-01 16:21:45 --> Output Class Initialized
INFO - 2018-11-01 16:21:45 --> Security Class Initialized
DEBUG - 2018-11-01 16:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 16:21:45 --> CSRF cookie sent
INFO - 2018-11-01 16:21:45 --> Input Class Initialized
INFO - 2018-11-01 16:21:45 --> Language Class Initialized
INFO - 2018-11-01 16:21:45 --> Loader Class Initialized
INFO - 2018-11-01 16:21:45 --> Helper loaded: url_helper
INFO - 2018-11-01 16:21:45 --> Helper loaded: form_helper
INFO - 2018-11-01 16:21:45 --> Helper loaded: language_helper
DEBUG - 2018-11-01 16:21:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 16:21:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 16:21:45 --> User Agent Class Initialized
INFO - 2018-11-01 16:21:45 --> Controller Class Initialized
INFO - 2018-11-01 16:21:45 --> Helper loaded: file_helper
INFO - 2018-11-01 16:21:45 --> Helper loaded: directory_helper
INFO - 2018-11-01 16:21:45 --> Zip Compression Class Initialized
INFO - 2018-11-01 16:21:52 --> Config Class Initialized
INFO - 2018-11-01 16:21:52 --> Hooks Class Initialized
DEBUG - 2018-11-01 16:21:52 --> UTF-8 Support Enabled
INFO - 2018-11-01 16:21:52 --> Utf8 Class Initialized
INFO - 2018-11-01 16:21:52 --> URI Class Initialized
INFO - 2018-11-01 16:21:52 --> Router Class Initialized
INFO - 2018-11-01 16:21:52 --> Output Class Initialized
INFO - 2018-11-01 16:21:52 --> Security Class Initialized
DEBUG - 2018-11-01 16:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 16:21:52 --> CSRF cookie sent
INFO - 2018-11-01 16:21:52 --> Input Class Initialized
INFO - 2018-11-01 16:21:52 --> Language Class Initialized
INFO - 2018-11-01 16:21:52 --> Loader Class Initialized
INFO - 2018-11-01 16:21:52 --> Helper loaded: url_helper
INFO - 2018-11-01 16:21:52 --> Helper loaded: form_helper
INFO - 2018-11-01 16:21:52 --> Helper loaded: language_helper
DEBUG - 2018-11-01 16:21:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 16:21:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 16:21:52 --> User Agent Class Initialized
INFO - 2018-11-01 16:21:52 --> Controller Class Initialized
INFO - 2018-11-01 16:21:52 --> Helper loaded: file_helper
INFO - 2018-11-01 16:21:52 --> Helper loaded: directory_helper
INFO - 2018-11-01 16:21:52 --> Zip Compression Class Initialized
INFO - 2018-11-01 16:22:26 --> Config Class Initialized
INFO - 2018-11-01 16:22:26 --> Hooks Class Initialized
DEBUG - 2018-11-01 16:22:26 --> UTF-8 Support Enabled
INFO - 2018-11-01 16:22:26 --> Utf8 Class Initialized
INFO - 2018-11-01 16:22:26 --> URI Class Initialized
INFO - 2018-11-01 16:22:26 --> Router Class Initialized
INFO - 2018-11-01 16:22:26 --> Output Class Initialized
INFO - 2018-11-01 16:22:26 --> Security Class Initialized
DEBUG - 2018-11-01 16:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 16:22:26 --> CSRF cookie sent
INFO - 2018-11-01 16:22:26 --> Input Class Initialized
INFO - 2018-11-01 16:22:26 --> Language Class Initialized
INFO - 2018-11-01 16:22:26 --> Loader Class Initialized
INFO - 2018-11-01 16:22:26 --> Helper loaded: url_helper
INFO - 2018-11-01 16:22:26 --> Helper loaded: form_helper
INFO - 2018-11-01 16:22:26 --> Helper loaded: language_helper
DEBUG - 2018-11-01 16:22:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 16:22:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 16:22:26 --> User Agent Class Initialized
INFO - 2018-11-01 16:22:26 --> Controller Class Initialized
INFO - 2018-11-01 16:22:26 --> Helper loaded: file_helper
INFO - 2018-11-01 16:22:26 --> Helper loaded: directory_helper
INFO - 2018-11-01 16:22:26 --> Zip Compression Class Initialized
INFO - 2018-11-01 16:23:22 --> Config Class Initialized
INFO - 2018-11-01 16:23:22 --> Hooks Class Initialized
DEBUG - 2018-11-01 16:23:22 --> UTF-8 Support Enabled
INFO - 2018-11-01 16:23:22 --> Utf8 Class Initialized
INFO - 2018-11-01 16:23:22 --> URI Class Initialized
INFO - 2018-11-01 16:23:22 --> Router Class Initialized
INFO - 2018-11-01 16:23:22 --> Output Class Initialized
INFO - 2018-11-01 16:23:22 --> Security Class Initialized
DEBUG - 2018-11-01 16:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 16:23:22 --> CSRF cookie sent
INFO - 2018-11-01 16:23:22 --> Input Class Initialized
INFO - 2018-11-01 16:23:22 --> Language Class Initialized
INFO - 2018-11-01 16:23:22 --> Loader Class Initialized
INFO - 2018-11-01 16:23:22 --> Helper loaded: url_helper
INFO - 2018-11-01 16:23:22 --> Helper loaded: form_helper
INFO - 2018-11-01 16:23:22 --> Helper loaded: language_helper
DEBUG - 2018-11-01 16:23:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 16:23:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 16:23:22 --> User Agent Class Initialized
INFO - 2018-11-01 16:23:22 --> Controller Class Initialized
INFO - 2018-11-01 16:23:22 --> Helper loaded: file_helper
INFO - 2018-11-01 16:23:22 --> Helper loaded: directory_helper
INFO - 2018-11-01 16:23:22 --> Zip Compression Class Initialized
INFO - 2018-11-01 16:23:22 --> Final output sent to browser
DEBUG - 2018-11-01 16:23:22 --> Total execution time: 0.1029
INFO - 2018-11-01 16:24:27 --> Config Class Initialized
INFO - 2018-11-01 16:24:27 --> Hooks Class Initialized
DEBUG - 2018-11-01 16:24:27 --> UTF-8 Support Enabled
INFO - 2018-11-01 16:24:27 --> Utf8 Class Initialized
INFO - 2018-11-01 16:24:27 --> URI Class Initialized
INFO - 2018-11-01 16:24:27 --> Router Class Initialized
INFO - 2018-11-01 16:24:27 --> Output Class Initialized
INFO - 2018-11-01 16:24:27 --> Security Class Initialized
DEBUG - 2018-11-01 16:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 16:24:27 --> CSRF cookie sent
INFO - 2018-11-01 16:24:27 --> Input Class Initialized
INFO - 2018-11-01 16:24:27 --> Language Class Initialized
INFO - 2018-11-01 16:24:27 --> Loader Class Initialized
INFO - 2018-11-01 16:24:27 --> Helper loaded: url_helper
INFO - 2018-11-01 16:24:27 --> Helper loaded: form_helper
INFO - 2018-11-01 16:24:27 --> Helper loaded: language_helper
DEBUG - 2018-11-01 16:24:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 16:24:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 16:24:27 --> User Agent Class Initialized
INFO - 2018-11-01 16:24:27 --> Controller Class Initialized
INFO - 2018-11-01 16:24:27 --> Helper loaded: file_helper
INFO - 2018-11-01 16:24:27 --> Helper loaded: directory_helper
INFO - 2018-11-01 16:24:27 --> Zip Compression Class Initialized
INFO - 2018-11-01 16:24:27 --> Final output sent to browser
DEBUG - 2018-11-01 16:24:27 --> Total execution time: 0.1353
INFO - 2018-11-01 16:25:36 --> Config Class Initialized
INFO - 2018-11-01 16:25:36 --> Hooks Class Initialized
DEBUG - 2018-11-01 16:25:36 --> UTF-8 Support Enabled
INFO - 2018-11-01 16:25:36 --> Utf8 Class Initialized
INFO - 2018-11-01 16:25:36 --> URI Class Initialized
INFO - 2018-11-01 16:25:36 --> Router Class Initialized
INFO - 2018-11-01 16:25:36 --> Output Class Initialized
INFO - 2018-11-01 16:25:36 --> Security Class Initialized
DEBUG - 2018-11-01 16:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 16:25:36 --> CSRF cookie sent
INFO - 2018-11-01 16:25:36 --> Input Class Initialized
INFO - 2018-11-01 16:25:36 --> Language Class Initialized
INFO - 2018-11-01 16:25:36 --> Loader Class Initialized
INFO - 2018-11-01 16:25:36 --> Helper loaded: url_helper
INFO - 2018-11-01 16:25:36 --> Helper loaded: form_helper
INFO - 2018-11-01 16:25:37 --> Helper loaded: language_helper
DEBUG - 2018-11-01 16:25:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 16:25:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 16:25:37 --> User Agent Class Initialized
INFO - 2018-11-01 16:25:37 --> Controller Class Initialized
INFO - 2018-11-01 16:25:37 --> Helper loaded: file_helper
INFO - 2018-11-01 16:25:37 --> Helper loaded: directory_helper
INFO - 2018-11-01 16:25:37 --> Zip Compression Class Initialized
INFO - 2018-11-01 16:25:37 --> Database Driver Class Initialized
INFO - 2018-11-01 16:25:40 --> Database Utility Class Initialized
INFO - 2018-11-01 16:25:40 --> Database Utility Class Initialized
DEBUG - 2018-11-01 16:25:40 --> Zip class already loaded. Second attempt ignored.
ERROR - 2018-11-01 16:25:40 --> Severity: Notice --> Only variables should be assigned by reference E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 93
INFO - 2018-11-01 16:25:40 --> Database Utility Class Initialized
INFO - 2018-11-01 16:25:40 --> Database Utility Class Initialized
DEBUG - 2018-11-01 16:25:40 --> Zip class already loaded. Second attempt ignored.
ERROR - 2018-11-01 16:25:40 --> Severity: Notice --> Only variables should be assigned by reference E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 93
INFO - 2018-11-01 16:25:40 --> Database Utility Class Initialized
INFO - 2018-11-01 16:25:40 --> Database Utility Class Initialized
DEBUG - 2018-11-01 16:25:40 --> Zip class already loaded. Second attempt ignored.
ERROR - 2018-11-01 16:25:40 --> Severity: Notice --> Only variables should be assigned by reference E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 93
INFO - 2018-11-01 16:25:40 --> Database Utility Class Initialized
INFO - 2018-11-01 16:25:40 --> Database Utility Class Initialized
DEBUG - 2018-11-01 16:25:40 --> Zip class already loaded. Second attempt ignored.
ERROR - 2018-11-01 16:25:40 --> Severity: Notice --> Only variables should be assigned by reference E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 93
INFO - 2018-11-01 16:25:40 --> Database Utility Class Initialized
INFO - 2018-11-01 16:25:40 --> Database Utility Class Initialized
DEBUG - 2018-11-01 16:25:40 --> Zip class already loaded. Second attempt ignored.
ERROR - 2018-11-01 16:25:40 --> Severity: Notice --> Only variables should be assigned by reference E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 93
INFO - 2018-11-01 16:25:40 --> Database Utility Class Initialized
INFO - 2018-11-01 16:25:40 --> Database Utility Class Initialized
DEBUG - 2018-11-01 16:25:40 --> Zip class already loaded. Second attempt ignored.
ERROR - 2018-11-01 16:25:40 --> Severity: Notice --> Only variables should be assigned by reference E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 93
INFO - 2018-11-01 16:25:40 --> Database Utility Class Initialized
INFO - 2018-11-01 16:25:40 --> Database Utility Class Initialized
DEBUG - 2018-11-01 16:25:40 --> Zip class already loaded. Second attempt ignored.
ERROR - 2018-11-01 16:25:40 --> Severity: Notice --> Only variables should be assigned by reference E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 93
INFO - 2018-11-01 16:25:40 --> Database Utility Class Initialized
INFO - 2018-11-01 16:25:40 --> Database Utility Class Initialized
DEBUG - 2018-11-01 16:25:40 --> Zip class already loaded. Second attempt ignored.
ERROR - 2018-11-01 16:25:41 --> Severity: Notice --> Only variables should be assigned by reference E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 93
INFO - 2018-11-01 16:25:41 --> Database Utility Class Initialized
INFO - 2018-11-01 16:25:41 --> Database Utility Class Initialized
DEBUG - 2018-11-01 16:25:41 --> Zip class already loaded. Second attempt ignored.
ERROR - 2018-11-01 16:25:41 --> Severity: Notice --> Only variables should be assigned by reference E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 93
INFO - 2018-11-01 16:25:41 --> Database Utility Class Initialized
INFO - 2018-11-01 16:25:41 --> Database Utility Class Initialized
DEBUG - 2018-11-01 16:25:41 --> Zip class already loaded. Second attempt ignored.
ERROR - 2018-11-01 16:25:41 --> Severity: Notice --> Only variables should be assigned by reference E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 93
INFO - 2018-11-01 16:25:41 --> Database Utility Class Initialized
INFO - 2018-11-01 16:25:41 --> Database Utility Class Initialized
DEBUG - 2018-11-01 16:25:41 --> Zip class already loaded. Second attempt ignored.
ERROR - 2018-11-01 16:25:41 --> Severity: Notice --> Only variables should be assigned by reference E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 93
INFO - 2018-11-01 16:25:41 --> Database Utility Class Initialized
INFO - 2018-11-01 16:25:41 --> Database Utility Class Initialized
DEBUG - 2018-11-01 16:25:41 --> Zip class already loaded. Second attempt ignored.
ERROR - 2018-11-01 16:25:41 --> Severity: Notice --> Only variables should be assigned by reference E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 93
INFO - 2018-11-01 16:25:41 --> Database Utility Class Initialized
INFO - 2018-11-01 16:25:41 --> Database Utility Class Initialized
DEBUG - 2018-11-01 16:25:41 --> Zip class already loaded. Second attempt ignored.
ERROR - 2018-11-01 16:25:42 --> Severity: Notice --> Only variables should be assigned by reference E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 93
INFO - 2018-11-01 16:25:42 --> Database Utility Class Initialized
INFO - 2018-11-01 16:25:42 --> Database Utility Class Initialized
DEBUG - 2018-11-01 16:25:42 --> Zip class already loaded. Second attempt ignored.
ERROR - 2018-11-01 16:25:42 --> Severity: Notice --> Only variables should be assigned by reference E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 93
INFO - 2018-11-01 16:25:42 --> Database Utility Class Initialized
INFO - 2018-11-01 16:25:42 --> Database Utility Class Initialized
DEBUG - 2018-11-01 16:25:42 --> Zip class already loaded. Second attempt ignored.
ERROR - 2018-11-01 16:25:42 --> Severity: Notice --> Only variables should be assigned by reference E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 93
INFO - 2018-11-01 16:25:42 --> Database Utility Class Initialized
INFO - 2018-11-01 16:25:42 --> Database Utility Class Initialized
DEBUG - 2018-11-01 16:25:42 --> Zip class already loaded. Second attempt ignored.
ERROR - 2018-11-01 16:25:42 --> Severity: Notice --> Only variables should be assigned by reference E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 93
INFO - 2018-11-01 16:25:42 --> Database Utility Class Initialized
INFO - 2018-11-01 16:25:42 --> Database Utility Class Initialized
DEBUG - 2018-11-01 16:25:42 --> Zip class already loaded. Second attempt ignored.
ERROR - 2018-11-01 16:25:42 --> Severity: Notice --> Only variables should be assigned by reference E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 93
INFO - 2018-11-01 16:25:42 --> Database Utility Class Initialized
INFO - 2018-11-01 16:25:42 --> Database Utility Class Initialized
DEBUG - 2018-11-01 16:25:42 --> Zip class already loaded. Second attempt ignored.
ERROR - 2018-11-01 16:25:42 --> Severity: Notice --> Only variables should be assigned by reference E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 93
INFO - 2018-11-01 16:25:43 --> Database Utility Class Initialized
INFO - 2018-11-01 16:25:43 --> Database Utility Class Initialized
DEBUG - 2018-11-01 16:25:43 --> Zip class already loaded. Second attempt ignored.
ERROR - 2018-11-01 16:25:43 --> Severity: Notice --> Only variables should be assigned by reference E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 93
INFO - 2018-11-01 16:25:43 --> Database Utility Class Initialized
INFO - 2018-11-01 16:25:43 --> Database Utility Class Initialized
DEBUG - 2018-11-01 16:25:43 --> Zip class already loaded. Second attempt ignored.
ERROR - 2018-11-01 16:25:43 --> Severity: Notice --> Only variables should be assigned by reference E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 93
INFO - 2018-11-01 16:25:43 --> Database Utility Class Initialized
INFO - 2018-11-01 16:25:43 --> Database Utility Class Initialized
DEBUG - 2018-11-01 16:25:43 --> Zip class already loaded. Second attempt ignored.
ERROR - 2018-11-01 16:25:43 --> Severity: Notice --> Only variables should be assigned by reference E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 93
INFO - 2018-11-01 16:25:43 --> Database Utility Class Initialized
INFO - 2018-11-01 16:25:43 --> Database Utility Class Initialized
DEBUG - 2018-11-01 16:25:43 --> Zip class already loaded. Second attempt ignored.
ERROR - 2018-11-01 16:25:43 --> Severity: Notice --> Only variables should be assigned by reference E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 93
INFO - 2018-11-01 16:25:43 --> Database Utility Class Initialized
INFO - 2018-11-01 16:25:43 --> Database Utility Class Initialized
DEBUG - 2018-11-01 16:25:43 --> Zip class already loaded. Second attempt ignored.
ERROR - 2018-11-01 16:25:43 --> Severity: Notice --> Only variables should be assigned by reference E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 93
INFO - 2018-11-01 16:25:43 --> Final output sent to browser
DEBUG - 2018-11-01 16:25:43 --> Total execution time: 6.5184
INFO - 2018-11-01 16:27:02 --> Config Class Initialized
INFO - 2018-11-01 16:27:02 --> Hooks Class Initialized
DEBUG - 2018-11-01 16:27:02 --> UTF-8 Support Enabled
INFO - 2018-11-01 16:27:02 --> Utf8 Class Initialized
INFO - 2018-11-01 16:27:02 --> URI Class Initialized
INFO - 2018-11-01 16:27:02 --> Router Class Initialized
INFO - 2018-11-01 16:27:02 --> Output Class Initialized
INFO - 2018-11-01 16:27:02 --> Security Class Initialized
DEBUG - 2018-11-01 16:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 16:27:02 --> CSRF cookie sent
INFO - 2018-11-01 16:27:02 --> Input Class Initialized
INFO - 2018-11-01 16:27:02 --> Language Class Initialized
INFO - 2018-11-01 16:27:02 --> Loader Class Initialized
INFO - 2018-11-01 16:27:02 --> Helper loaded: url_helper
INFO - 2018-11-01 16:27:02 --> Helper loaded: form_helper
INFO - 2018-11-01 16:27:02 --> Helper loaded: language_helper
DEBUG - 2018-11-01 16:27:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 16:27:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 16:27:02 --> User Agent Class Initialized
INFO - 2018-11-01 16:27:02 --> Controller Class Initialized
INFO - 2018-11-01 16:27:02 --> Helper loaded: file_helper
INFO - 2018-11-01 16:27:02 --> Helper loaded: directory_helper
INFO - 2018-11-01 16:27:02 --> Zip Compression Class Initialized
INFO - 2018-11-01 16:27:02 --> Database Driver Class Initialized
INFO - 2018-11-01 16:27:05 --> Database Utility Class Initialized
INFO - 2018-11-01 16:27:05 --> Database Utility Class Initialized
DEBUG - 2018-11-01 16:27:05 --> Zip class already loaded. Second attempt ignored.
ERROR - 2018-11-01 16:27:06 --> Severity: Notice --> Only variables should be assigned by reference E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 96
INFO - 2018-11-01 16:27:06 --> Database Utility Class Initialized
INFO - 2018-11-01 16:27:06 --> Database Utility Class Initialized
DEBUG - 2018-11-01 16:27:06 --> Zip class already loaded. Second attempt ignored.
ERROR - 2018-11-01 16:27:06 --> Severity: Notice --> Only variables should be assigned by reference E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 96
INFO - 2018-11-01 16:27:06 --> Database Utility Class Initialized
INFO - 2018-11-01 16:27:06 --> Database Utility Class Initialized
DEBUG - 2018-11-01 16:27:06 --> Zip class already loaded. Second attempt ignored.
ERROR - 2018-11-01 16:27:06 --> Severity: Notice --> Only variables should be assigned by reference E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 96
INFO - 2018-11-01 16:27:06 --> Database Utility Class Initialized
INFO - 2018-11-01 16:27:06 --> Database Utility Class Initialized
DEBUG - 2018-11-01 16:27:06 --> Zip class already loaded. Second attempt ignored.
ERROR - 2018-11-01 16:27:06 --> Severity: Notice --> Only variables should be assigned by reference E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 96
INFO - 2018-11-01 16:27:06 --> Database Utility Class Initialized
INFO - 2018-11-01 16:27:06 --> Database Utility Class Initialized
DEBUG - 2018-11-01 16:27:06 --> Zip class already loaded. Second attempt ignored.
ERROR - 2018-11-01 16:27:06 --> Severity: Notice --> Only variables should be assigned by reference E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 96
INFO - 2018-11-01 16:27:06 --> Database Utility Class Initialized
INFO - 2018-11-01 16:27:06 --> Database Utility Class Initialized
DEBUG - 2018-11-01 16:27:06 --> Zip class already loaded. Second attempt ignored.
ERROR - 2018-11-01 16:27:06 --> Severity: Notice --> Only variables should be assigned by reference E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 96
INFO - 2018-11-01 16:27:06 --> Database Utility Class Initialized
INFO - 2018-11-01 16:27:06 --> Database Utility Class Initialized
DEBUG - 2018-11-01 16:27:06 --> Zip class already loaded. Second attempt ignored.
ERROR - 2018-11-01 16:27:06 --> Severity: Notice --> Only variables should be assigned by reference E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 96
INFO - 2018-11-01 16:27:06 --> Database Utility Class Initialized
INFO - 2018-11-01 16:27:06 --> Database Utility Class Initialized
DEBUG - 2018-11-01 16:27:06 --> Zip class already loaded. Second attempt ignored.
ERROR - 2018-11-01 16:27:06 --> Severity: Notice --> Only variables should be assigned by reference E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 96
INFO - 2018-11-01 16:27:06 --> Database Utility Class Initialized
INFO - 2018-11-01 16:27:06 --> Database Utility Class Initialized
DEBUG - 2018-11-01 16:27:06 --> Zip class already loaded. Second attempt ignored.
ERROR - 2018-11-01 16:27:06 --> Severity: Notice --> Only variables should be assigned by reference E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 96
INFO - 2018-11-01 16:27:07 --> Database Utility Class Initialized
INFO - 2018-11-01 16:27:07 --> Database Utility Class Initialized
DEBUG - 2018-11-01 16:27:07 --> Zip class already loaded. Second attempt ignored.
ERROR - 2018-11-01 16:27:07 --> Severity: Notice --> Only variables should be assigned by reference E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 96
INFO - 2018-11-01 16:27:07 --> Database Utility Class Initialized
INFO - 2018-11-01 16:27:07 --> Database Utility Class Initialized
DEBUG - 2018-11-01 16:27:07 --> Zip class already loaded. Second attempt ignored.
ERROR - 2018-11-01 16:27:07 --> Severity: Notice --> Only variables should be assigned by reference E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 96
INFO - 2018-11-01 16:27:07 --> Database Utility Class Initialized
INFO - 2018-11-01 16:27:07 --> Database Utility Class Initialized
DEBUG - 2018-11-01 16:27:07 --> Zip class already loaded. Second attempt ignored.
ERROR - 2018-11-01 16:27:07 --> Severity: Notice --> Only variables should be assigned by reference E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 96
INFO - 2018-11-01 16:27:07 --> Database Utility Class Initialized
INFO - 2018-11-01 16:27:07 --> Database Utility Class Initialized
DEBUG - 2018-11-01 16:27:07 --> Zip class already loaded. Second attempt ignored.
ERROR - 2018-11-01 16:27:07 --> Severity: Notice --> Only variables should be assigned by reference E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 96
INFO - 2018-11-01 16:27:07 --> Database Utility Class Initialized
INFO - 2018-11-01 16:27:07 --> Database Utility Class Initialized
DEBUG - 2018-11-01 16:27:07 --> Zip class already loaded. Second attempt ignored.
ERROR - 2018-11-01 16:27:07 --> Severity: Notice --> Only variables should be assigned by reference E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 96
INFO - 2018-11-01 16:27:07 --> Database Utility Class Initialized
INFO - 2018-11-01 16:27:07 --> Database Utility Class Initialized
DEBUG - 2018-11-01 16:27:07 --> Zip class already loaded. Second attempt ignored.
ERROR - 2018-11-01 16:27:07 --> Severity: Notice --> Only variables should be assigned by reference E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 96
INFO - 2018-11-01 16:27:07 --> Database Utility Class Initialized
INFO - 2018-11-01 16:27:07 --> Database Utility Class Initialized
DEBUG - 2018-11-01 16:27:07 --> Zip class already loaded. Second attempt ignored.
ERROR - 2018-11-01 16:27:07 --> Severity: Notice --> Only variables should be assigned by reference E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 96
INFO - 2018-11-01 16:27:07 --> Database Utility Class Initialized
INFO - 2018-11-01 16:27:07 --> Database Utility Class Initialized
DEBUG - 2018-11-01 16:27:07 --> Zip class already loaded. Second attempt ignored.
ERROR - 2018-11-01 16:27:07 --> Severity: Notice --> Only variables should be assigned by reference E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 96
INFO - 2018-11-01 16:27:07 --> Database Utility Class Initialized
INFO - 2018-11-01 16:27:07 --> Database Utility Class Initialized
DEBUG - 2018-11-01 16:27:07 --> Zip class already loaded. Second attempt ignored.
ERROR - 2018-11-01 16:27:07 --> Severity: Notice --> Only variables should be assigned by reference E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 96
INFO - 2018-11-01 16:27:07 --> Database Utility Class Initialized
INFO - 2018-11-01 16:27:07 --> Database Utility Class Initialized
DEBUG - 2018-11-01 16:27:07 --> Zip class already loaded. Second attempt ignored.
ERROR - 2018-11-01 16:27:08 --> Severity: Notice --> Only variables should be assigned by reference E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 96
INFO - 2018-11-01 16:27:08 --> Database Utility Class Initialized
INFO - 2018-11-01 16:27:08 --> Database Utility Class Initialized
DEBUG - 2018-11-01 16:27:08 --> Zip class already loaded. Second attempt ignored.
ERROR - 2018-11-01 16:27:08 --> Severity: Notice --> Only variables should be assigned by reference E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 96
INFO - 2018-11-01 16:27:08 --> Database Utility Class Initialized
INFO - 2018-11-01 16:27:08 --> Database Utility Class Initialized
DEBUG - 2018-11-01 16:27:08 --> Zip class already loaded. Second attempt ignored.
ERROR - 2018-11-01 16:27:08 --> Severity: Notice --> Only variables should be assigned by reference E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 96
INFO - 2018-11-01 16:27:08 --> Database Utility Class Initialized
INFO - 2018-11-01 16:27:08 --> Database Utility Class Initialized
DEBUG - 2018-11-01 16:27:08 --> Zip class already loaded. Second attempt ignored.
ERROR - 2018-11-01 16:27:08 --> Severity: Notice --> Only variables should be assigned by reference E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 96
INFO - 2018-11-01 16:27:08 --> Database Utility Class Initialized
INFO - 2018-11-01 16:27:08 --> Database Utility Class Initialized
DEBUG - 2018-11-01 16:27:08 --> Zip class already loaded. Second attempt ignored.
ERROR - 2018-11-01 16:27:08 --> Severity: Notice --> Only variables should be assigned by reference E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 96
INFO - 2018-11-01 16:27:08 --> Final output sent to browser
DEBUG - 2018-11-01 16:27:08 --> Total execution time: 5.9725
INFO - 2018-11-01 16:30:14 --> Config Class Initialized
INFO - 2018-11-01 16:30:14 --> Hooks Class Initialized
DEBUG - 2018-11-01 16:30:14 --> UTF-8 Support Enabled
INFO - 2018-11-01 16:30:14 --> Utf8 Class Initialized
INFO - 2018-11-01 16:30:14 --> URI Class Initialized
INFO - 2018-11-01 16:30:14 --> Router Class Initialized
INFO - 2018-11-01 16:30:14 --> Output Class Initialized
INFO - 2018-11-01 16:30:14 --> Security Class Initialized
DEBUG - 2018-11-01 16:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 16:30:14 --> CSRF cookie sent
INFO - 2018-11-01 16:30:14 --> Input Class Initialized
INFO - 2018-11-01 16:30:14 --> Language Class Initialized
INFO - 2018-11-01 16:30:14 --> Loader Class Initialized
INFO - 2018-11-01 16:30:14 --> Helper loaded: url_helper
INFO - 2018-11-01 16:30:14 --> Helper loaded: form_helper
INFO - 2018-11-01 16:30:14 --> Helper loaded: language_helper
DEBUG - 2018-11-01 16:30:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 16:30:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 16:30:15 --> User Agent Class Initialized
INFO - 2018-11-01 16:30:15 --> Controller Class Initialized
INFO - 2018-11-01 16:30:15 --> Helper loaded: file_helper
INFO - 2018-11-01 16:30:15 --> Helper loaded: directory_helper
INFO - 2018-11-01 16:30:15 --> Zip Compression Class Initialized
ERROR - 2018-11-01 16:30:15 --> Severity: error --> Exception: Call to undefined method BackupController::_load_zip_lib() E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 14
INFO - 2018-11-01 16:30:30 --> Config Class Initialized
INFO - 2018-11-01 16:30:30 --> Hooks Class Initialized
DEBUG - 2018-11-01 16:30:30 --> UTF-8 Support Enabled
INFO - 2018-11-01 16:30:30 --> Utf8 Class Initialized
INFO - 2018-11-01 16:30:30 --> URI Class Initialized
INFO - 2018-11-01 16:30:30 --> Router Class Initialized
INFO - 2018-11-01 16:30:30 --> Output Class Initialized
INFO - 2018-11-01 16:30:30 --> Security Class Initialized
DEBUG - 2018-11-01 16:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 16:30:30 --> CSRF cookie sent
INFO - 2018-11-01 16:30:30 --> Input Class Initialized
INFO - 2018-11-01 16:30:30 --> Language Class Initialized
INFO - 2018-11-01 16:30:30 --> Loader Class Initialized
INFO - 2018-11-01 16:30:30 --> Helper loaded: url_helper
INFO - 2018-11-01 16:30:30 --> Helper loaded: form_helper
INFO - 2018-11-01 16:30:30 --> Helper loaded: language_helper
DEBUG - 2018-11-01 16:30:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 16:30:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 16:30:30 --> User Agent Class Initialized
INFO - 2018-11-01 16:30:30 --> Controller Class Initialized
INFO - 2018-11-01 16:30:30 --> Helper loaded: file_helper
INFO - 2018-11-01 16:30:30 --> Helper loaded: directory_helper
INFO - 2018-11-01 16:30:30 --> Zip Compression Class Initialized
ERROR - 2018-11-01 16:30:30 --> Severity: error --> Exception: Call to undefined method BackupController::_load_zip_lib() E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 66
INFO - 2018-11-01 16:30:43 --> Config Class Initialized
INFO - 2018-11-01 16:30:43 --> Hooks Class Initialized
DEBUG - 2018-11-01 16:30:43 --> UTF-8 Support Enabled
INFO - 2018-11-01 16:30:43 --> Utf8 Class Initialized
INFO - 2018-11-01 16:30:43 --> URI Class Initialized
INFO - 2018-11-01 16:30:43 --> Router Class Initialized
INFO - 2018-11-01 16:30:43 --> Output Class Initialized
INFO - 2018-11-01 16:30:43 --> Security Class Initialized
DEBUG - 2018-11-01 16:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 16:30:43 --> CSRF cookie sent
INFO - 2018-11-01 16:30:43 --> Input Class Initialized
INFO - 2018-11-01 16:30:43 --> Language Class Initialized
INFO - 2018-11-01 16:30:43 --> Loader Class Initialized
INFO - 2018-11-01 16:30:43 --> Helper loaded: url_helper
INFO - 2018-11-01 16:30:43 --> Helper loaded: form_helper
INFO - 2018-11-01 16:30:43 --> Helper loaded: language_helper
DEBUG - 2018-11-01 16:30:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 16:30:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 16:30:43 --> User Agent Class Initialized
INFO - 2018-11-01 16:30:43 --> Controller Class Initialized
INFO - 2018-11-01 16:30:43 --> Helper loaded: file_helper
INFO - 2018-11-01 16:30:43 --> Helper loaded: directory_helper
INFO - 2018-11-01 16:30:43 --> Zip Compression Class Initialized
ERROR - 2018-11-01 16:30:43 --> Severity: error --> Exception: Call to undefined method BackupController::_archieve_and_download() E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 85
INFO - 2018-11-01 16:31:08 --> Config Class Initialized
INFO - 2018-11-01 16:31:08 --> Hooks Class Initialized
DEBUG - 2018-11-01 16:31:08 --> UTF-8 Support Enabled
INFO - 2018-11-01 16:31:08 --> Utf8 Class Initialized
INFO - 2018-11-01 16:31:08 --> URI Class Initialized
INFO - 2018-11-01 16:31:08 --> Router Class Initialized
INFO - 2018-11-01 16:31:08 --> Output Class Initialized
INFO - 2018-11-01 16:31:08 --> Security Class Initialized
DEBUG - 2018-11-01 16:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 16:31:08 --> CSRF cookie sent
INFO - 2018-11-01 16:31:08 --> Input Class Initialized
INFO - 2018-11-01 16:31:08 --> Language Class Initialized
INFO - 2018-11-01 16:31:08 --> Loader Class Initialized
INFO - 2018-11-01 16:31:08 --> Helper loaded: url_helper
INFO - 2018-11-01 16:31:08 --> Helper loaded: form_helper
INFO - 2018-11-01 16:31:08 --> Helper loaded: language_helper
DEBUG - 2018-11-01 16:31:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 16:31:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 16:31:08 --> User Agent Class Initialized
INFO - 2018-11-01 16:31:08 --> Controller Class Initialized
INFO - 2018-11-01 16:31:08 --> Helper loaded: file_helper
INFO - 2018-11-01 16:31:08 --> Helper loaded: directory_helper
INFO - 2018-11-01 16:31:08 --> Zip Compression Class Initialized
ERROR - 2018-11-01 16:31:08 --> Severity: error --> Exception: Call to undefined method CI_Zip::archieve() E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 85
INFO - 2018-11-01 16:31:24 --> Config Class Initialized
INFO - 2018-11-01 16:31:24 --> Hooks Class Initialized
DEBUG - 2018-11-01 16:31:24 --> UTF-8 Support Enabled
INFO - 2018-11-01 16:31:24 --> Utf8 Class Initialized
INFO - 2018-11-01 16:31:24 --> URI Class Initialized
INFO - 2018-11-01 16:31:24 --> Router Class Initialized
INFO - 2018-11-01 16:31:24 --> Output Class Initialized
INFO - 2018-11-01 16:31:24 --> Security Class Initialized
DEBUG - 2018-11-01 16:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 16:31:24 --> CSRF cookie sent
INFO - 2018-11-01 16:31:24 --> Input Class Initialized
INFO - 2018-11-01 16:31:24 --> Language Class Initialized
INFO - 2018-11-01 16:31:24 --> Loader Class Initialized
INFO - 2018-11-01 16:31:24 --> Helper loaded: url_helper
INFO - 2018-11-01 16:31:24 --> Helper loaded: form_helper
INFO - 2018-11-01 16:31:24 --> Helper loaded: language_helper
DEBUG - 2018-11-01 16:31:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 16:31:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 16:31:24 --> User Agent Class Initialized
INFO - 2018-11-01 16:31:24 --> Controller Class Initialized
INFO - 2018-11-01 16:31:24 --> Helper loaded: file_helper
INFO - 2018-11-01 16:31:24 --> Helper loaded: directory_helper
INFO - 2018-11-01 16:31:24 --> Zip Compression Class Initialized
INFO - 2018-11-01 16:31:24 --> Helper loaded: download_helper
INFO - 2018-11-01 16:32:21 --> Config Class Initialized
INFO - 2018-11-01 16:32:21 --> Hooks Class Initialized
DEBUG - 2018-11-01 16:32:21 --> UTF-8 Support Enabled
INFO - 2018-11-01 16:32:21 --> Utf8 Class Initialized
INFO - 2018-11-01 16:32:21 --> URI Class Initialized
INFO - 2018-11-01 16:32:21 --> Router Class Initialized
INFO - 2018-11-01 16:32:21 --> Output Class Initialized
INFO - 2018-11-01 16:32:21 --> Security Class Initialized
DEBUG - 2018-11-01 16:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 16:32:21 --> CSRF cookie sent
INFO - 2018-11-01 16:32:21 --> Input Class Initialized
INFO - 2018-11-01 16:32:21 --> Language Class Initialized
INFO - 2018-11-01 16:32:21 --> Loader Class Initialized
INFO - 2018-11-01 16:32:21 --> Helper loaded: url_helper
INFO - 2018-11-01 16:32:21 --> Helper loaded: form_helper
INFO - 2018-11-01 16:32:21 --> Helper loaded: language_helper
DEBUG - 2018-11-01 16:32:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 16:32:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 16:32:21 --> User Agent Class Initialized
INFO - 2018-11-01 16:32:21 --> Controller Class Initialized
INFO - 2018-11-01 16:32:21 --> Helper loaded: file_helper
INFO - 2018-11-01 16:32:21 --> Helper loaded: directory_helper
INFO - 2018-11-01 16:32:21 --> Zip Compression Class Initialized
INFO - 2018-11-01 16:32:21 --> Helper loaded: download_helper
INFO - 2018-11-01 16:33:22 --> Config Class Initialized
INFO - 2018-11-01 16:33:22 --> Hooks Class Initialized
DEBUG - 2018-11-01 16:33:22 --> UTF-8 Support Enabled
INFO - 2018-11-01 16:33:22 --> Utf8 Class Initialized
INFO - 2018-11-01 16:33:22 --> URI Class Initialized
INFO - 2018-11-01 16:33:22 --> Router Class Initialized
INFO - 2018-11-01 16:33:22 --> Output Class Initialized
INFO - 2018-11-01 16:33:22 --> Security Class Initialized
DEBUG - 2018-11-01 16:33:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 16:33:22 --> CSRF cookie sent
INFO - 2018-11-01 16:33:22 --> Input Class Initialized
INFO - 2018-11-01 16:33:22 --> Language Class Initialized
INFO - 2018-11-01 16:33:22 --> Loader Class Initialized
INFO - 2018-11-01 16:33:22 --> Helper loaded: url_helper
INFO - 2018-11-01 16:33:22 --> Helper loaded: form_helper
INFO - 2018-11-01 16:33:22 --> Helper loaded: language_helper
DEBUG - 2018-11-01 16:33:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 16:33:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 16:33:22 --> User Agent Class Initialized
INFO - 2018-11-01 16:33:22 --> Controller Class Initialized
INFO - 2018-11-01 16:33:22 --> Helper loaded: file_helper
INFO - 2018-11-01 16:33:22 --> Helper loaded: directory_helper
INFO - 2018-11-01 16:33:22 --> Zip Compression Class Initialized
INFO - 2018-11-01 16:33:48 --> Config Class Initialized
INFO - 2018-11-01 16:33:48 --> Hooks Class Initialized
DEBUG - 2018-11-01 16:33:48 --> UTF-8 Support Enabled
INFO - 2018-11-01 16:33:48 --> Utf8 Class Initialized
INFO - 2018-11-01 16:33:48 --> URI Class Initialized
INFO - 2018-11-01 16:33:48 --> Router Class Initialized
INFO - 2018-11-01 16:33:48 --> Output Class Initialized
INFO - 2018-11-01 16:33:48 --> Security Class Initialized
DEBUG - 2018-11-01 16:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 16:33:48 --> CSRF cookie sent
INFO - 2018-11-01 16:33:48 --> Input Class Initialized
INFO - 2018-11-01 16:33:48 --> Language Class Initialized
INFO - 2018-11-01 16:33:48 --> Loader Class Initialized
INFO - 2018-11-01 16:33:48 --> Helper loaded: url_helper
INFO - 2018-11-01 16:33:48 --> Helper loaded: form_helper
INFO - 2018-11-01 16:33:48 --> Helper loaded: language_helper
DEBUG - 2018-11-01 16:33:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 16:33:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 16:33:48 --> User Agent Class Initialized
INFO - 2018-11-01 16:33:48 --> Controller Class Initialized
INFO - 2018-11-01 16:33:48 --> Helper loaded: file_helper
INFO - 2018-11-01 16:33:48 --> Helper loaded: directory_helper
INFO - 2018-11-01 16:33:48 --> Zip Compression Class Initialized
INFO - 2018-11-01 16:34:12 --> Config Class Initialized
INFO - 2018-11-01 16:34:12 --> Hooks Class Initialized
DEBUG - 2018-11-01 16:34:12 --> UTF-8 Support Enabled
INFO - 2018-11-01 16:34:12 --> Utf8 Class Initialized
INFO - 2018-11-01 16:34:12 --> URI Class Initialized
INFO - 2018-11-01 16:34:12 --> Router Class Initialized
INFO - 2018-11-01 16:34:12 --> Output Class Initialized
INFO - 2018-11-01 16:34:12 --> Security Class Initialized
DEBUG - 2018-11-01 16:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 16:34:12 --> CSRF cookie sent
INFO - 2018-11-01 16:34:12 --> Input Class Initialized
INFO - 2018-11-01 16:34:12 --> Language Class Initialized
INFO - 2018-11-01 16:34:12 --> Loader Class Initialized
INFO - 2018-11-01 16:34:12 --> Helper loaded: url_helper
INFO - 2018-11-01 16:34:12 --> Helper loaded: form_helper
INFO - 2018-11-01 16:34:12 --> Helper loaded: language_helper
DEBUG - 2018-11-01 16:34:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 16:34:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 16:34:12 --> User Agent Class Initialized
INFO - 2018-11-01 16:34:12 --> Controller Class Initialized
INFO - 2018-11-01 16:34:12 --> Helper loaded: file_helper
INFO - 2018-11-01 16:34:12 --> Helper loaded: directory_helper
INFO - 2018-11-01 16:34:12 --> Zip Compression Class Initialized
INFO - 2018-11-01 16:34:15 --> Final output sent to browser
DEBUG - 2018-11-01 16:34:15 --> Total execution time: 2.8171
INFO - 2018-11-01 16:34:33 --> Config Class Initialized
INFO - 2018-11-01 16:34:33 --> Hooks Class Initialized
DEBUG - 2018-11-01 16:34:33 --> UTF-8 Support Enabled
INFO - 2018-11-01 16:34:33 --> Utf8 Class Initialized
INFO - 2018-11-01 16:34:33 --> URI Class Initialized
INFO - 2018-11-01 16:34:33 --> Router Class Initialized
INFO - 2018-11-01 16:34:33 --> Output Class Initialized
INFO - 2018-11-01 16:34:33 --> Security Class Initialized
DEBUG - 2018-11-01 16:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 16:34:33 --> CSRF cookie sent
INFO - 2018-11-01 16:34:33 --> Input Class Initialized
INFO - 2018-11-01 16:34:33 --> Language Class Initialized
INFO - 2018-11-01 16:34:33 --> Loader Class Initialized
INFO - 2018-11-01 16:34:33 --> Helper loaded: url_helper
INFO - 2018-11-01 16:34:33 --> Helper loaded: form_helper
INFO - 2018-11-01 16:34:33 --> Helper loaded: language_helper
DEBUG - 2018-11-01 16:34:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 16:34:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 16:34:33 --> User Agent Class Initialized
INFO - 2018-11-01 16:34:33 --> Controller Class Initialized
INFO - 2018-11-01 16:34:33 --> Helper loaded: file_helper
INFO - 2018-11-01 16:34:33 --> Helper loaded: directory_helper
INFO - 2018-11-01 16:34:33 --> Zip Compression Class Initialized
INFO - 2018-11-01 16:34:34 --> Final output sent to browser
DEBUG - 2018-11-01 16:34:34 --> Total execution time: 1.2844
INFO - 2018-11-01 16:45:37 --> Config Class Initialized
INFO - 2018-11-01 16:45:37 --> Hooks Class Initialized
DEBUG - 2018-11-01 16:45:37 --> UTF-8 Support Enabled
INFO - 2018-11-01 16:45:37 --> Utf8 Class Initialized
INFO - 2018-11-01 16:45:37 --> URI Class Initialized
INFO - 2018-11-01 16:45:37 --> Router Class Initialized
INFO - 2018-11-01 16:45:37 --> Output Class Initialized
INFO - 2018-11-01 16:45:37 --> Security Class Initialized
DEBUG - 2018-11-01 16:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 16:45:37 --> CSRF cookie sent
INFO - 2018-11-01 16:45:37 --> Input Class Initialized
INFO - 2018-11-01 16:45:37 --> Language Class Initialized
INFO - 2018-11-01 16:45:37 --> Loader Class Initialized
INFO - 2018-11-01 16:45:37 --> Helper loaded: url_helper
INFO - 2018-11-01 16:45:37 --> Helper loaded: form_helper
INFO - 2018-11-01 16:45:37 --> Helper loaded: language_helper
DEBUG - 2018-11-01 16:45:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 16:45:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 16:45:37 --> User Agent Class Initialized
INFO - 2018-11-01 16:45:37 --> Controller Class Initialized
INFO - 2018-11-01 16:45:37 --> Helper loaded: file_helper
INFO - 2018-11-01 16:45:37 --> Helper loaded: directory_helper
INFO - 2018-11-01 16:45:37 --> Zip Compression Class Initialized
INFO - 2018-11-01 16:45:55 --> Config Class Initialized
INFO - 2018-11-01 16:45:55 --> Hooks Class Initialized
DEBUG - 2018-11-01 16:45:55 --> UTF-8 Support Enabled
INFO - 2018-11-01 16:45:55 --> Utf8 Class Initialized
INFO - 2018-11-01 16:45:55 --> URI Class Initialized
INFO - 2018-11-01 16:45:55 --> Router Class Initialized
INFO - 2018-11-01 16:45:55 --> Output Class Initialized
INFO - 2018-11-01 16:45:55 --> Security Class Initialized
DEBUG - 2018-11-01 16:45:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 16:45:55 --> CSRF cookie sent
INFO - 2018-11-01 16:45:55 --> Input Class Initialized
INFO - 2018-11-01 16:45:55 --> Language Class Initialized
INFO - 2018-11-01 16:45:55 --> Loader Class Initialized
INFO - 2018-11-01 16:45:55 --> Helper loaded: url_helper
INFO - 2018-11-01 16:45:55 --> Helper loaded: form_helper
INFO - 2018-11-01 16:45:55 --> Helper loaded: language_helper
DEBUG - 2018-11-01 16:45:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 16:45:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 16:45:55 --> User Agent Class Initialized
INFO - 2018-11-01 16:45:55 --> Controller Class Initialized
INFO - 2018-11-01 16:45:55 --> Helper loaded: file_helper
INFO - 2018-11-01 16:45:55 --> Helper loaded: directory_helper
INFO - 2018-11-01 16:45:55 --> Zip Compression Class Initialized
INFO - 2018-11-01 16:48:03 --> Config Class Initialized
INFO - 2018-11-01 16:48:03 --> Hooks Class Initialized
DEBUG - 2018-11-01 16:48:03 --> UTF-8 Support Enabled
INFO - 2018-11-01 16:48:03 --> Utf8 Class Initialized
INFO - 2018-11-01 16:48:03 --> URI Class Initialized
INFO - 2018-11-01 16:48:03 --> Router Class Initialized
INFO - 2018-11-01 16:48:03 --> Output Class Initialized
INFO - 2018-11-01 16:48:03 --> Security Class Initialized
DEBUG - 2018-11-01 16:48:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 16:48:03 --> CSRF cookie sent
INFO - 2018-11-01 16:48:03 --> Input Class Initialized
INFO - 2018-11-01 16:48:03 --> Language Class Initialized
INFO - 2018-11-01 16:48:03 --> Loader Class Initialized
INFO - 2018-11-01 16:48:03 --> Helper loaded: url_helper
INFO - 2018-11-01 16:48:03 --> Helper loaded: form_helper
INFO - 2018-11-01 16:48:03 --> Helper loaded: language_helper
DEBUG - 2018-11-01 16:48:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 16:48:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 16:48:03 --> User Agent Class Initialized
INFO - 2018-11-01 16:48:03 --> Controller Class Initialized
INFO - 2018-11-01 16:48:03 --> Helper loaded: file_helper
INFO - 2018-11-01 16:48:03 --> Helper loaded: directory_helper
INFO - 2018-11-01 16:48:03 --> Zip Compression Class Initialized
INFO - 2018-11-01 16:48:05 --> Helper loaded: download_helper
INFO - 2018-11-01 16:49:16 --> Config Class Initialized
INFO - 2018-11-01 16:49:16 --> Hooks Class Initialized
DEBUG - 2018-11-01 16:49:16 --> UTF-8 Support Enabled
INFO - 2018-11-01 16:49:16 --> Utf8 Class Initialized
INFO - 2018-11-01 16:49:16 --> URI Class Initialized
INFO - 2018-11-01 16:49:16 --> Router Class Initialized
INFO - 2018-11-01 16:49:16 --> Output Class Initialized
INFO - 2018-11-01 16:49:16 --> Security Class Initialized
DEBUG - 2018-11-01 16:49:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 16:49:16 --> CSRF cookie sent
INFO - 2018-11-01 16:49:16 --> Input Class Initialized
INFO - 2018-11-01 16:49:16 --> Language Class Initialized
INFO - 2018-11-01 16:49:16 --> Loader Class Initialized
INFO - 2018-11-01 16:49:16 --> Helper loaded: url_helper
INFO - 2018-11-01 16:49:16 --> Helper loaded: form_helper
INFO - 2018-11-01 16:49:16 --> Helper loaded: language_helper
DEBUG - 2018-11-01 16:49:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 16:49:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 16:49:16 --> User Agent Class Initialized
INFO - 2018-11-01 16:49:17 --> Controller Class Initialized
INFO - 2018-11-01 16:49:17 --> Helper loaded: file_helper
INFO - 2018-11-01 16:49:17 --> Helper loaded: directory_helper
INFO - 2018-11-01 16:49:17 --> Zip Compression Class Initialized
INFO - 2018-11-01 16:49:18 --> Final output sent to browser
DEBUG - 2018-11-01 16:49:18 --> Total execution time: 1.8811
INFO - 2018-11-01 16:49:52 --> Config Class Initialized
INFO - 2018-11-01 16:49:52 --> Hooks Class Initialized
DEBUG - 2018-11-01 16:49:52 --> UTF-8 Support Enabled
INFO - 2018-11-01 16:49:52 --> Utf8 Class Initialized
INFO - 2018-11-01 16:49:52 --> URI Class Initialized
INFO - 2018-11-01 16:49:52 --> Router Class Initialized
INFO - 2018-11-01 16:49:52 --> Output Class Initialized
INFO - 2018-11-01 16:49:52 --> Security Class Initialized
DEBUG - 2018-11-01 16:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 16:49:52 --> CSRF cookie sent
INFO - 2018-11-01 16:49:52 --> Input Class Initialized
INFO - 2018-11-01 16:49:52 --> Language Class Initialized
INFO - 2018-11-01 16:49:52 --> Loader Class Initialized
INFO - 2018-11-01 16:49:52 --> Helper loaded: url_helper
INFO - 2018-11-01 16:49:52 --> Helper loaded: form_helper
INFO - 2018-11-01 16:49:52 --> Helper loaded: language_helper
DEBUG - 2018-11-01 16:49:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 16:49:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 16:49:52 --> User Agent Class Initialized
INFO - 2018-11-01 16:49:52 --> Controller Class Initialized
INFO - 2018-11-01 16:49:52 --> Helper loaded: file_helper
INFO - 2018-11-01 16:49:52 --> Helper loaded: directory_helper
INFO - 2018-11-01 16:49:52 --> Zip Compression Class Initialized
INFO - 2018-11-01 16:49:54 --> Final output sent to browser
DEBUG - 2018-11-01 16:49:54 --> Total execution time: 1.7093
INFO - 2018-11-01 16:50:42 --> Config Class Initialized
INFO - 2018-11-01 16:50:42 --> Hooks Class Initialized
DEBUG - 2018-11-01 16:50:42 --> UTF-8 Support Enabled
INFO - 2018-11-01 16:50:42 --> Utf8 Class Initialized
INFO - 2018-11-01 16:50:42 --> URI Class Initialized
INFO - 2018-11-01 16:50:42 --> Router Class Initialized
INFO - 2018-11-01 16:50:42 --> Output Class Initialized
INFO - 2018-11-01 16:50:42 --> Security Class Initialized
DEBUG - 2018-11-01 16:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 16:50:42 --> CSRF cookie sent
INFO - 2018-11-01 16:50:42 --> Input Class Initialized
INFO - 2018-11-01 16:50:42 --> Language Class Initialized
INFO - 2018-11-01 16:50:42 --> Loader Class Initialized
INFO - 2018-11-01 16:50:42 --> Helper loaded: url_helper
INFO - 2018-11-01 16:50:42 --> Helper loaded: form_helper
INFO - 2018-11-01 16:50:42 --> Helper loaded: language_helper
DEBUG - 2018-11-01 16:50:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 16:50:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 16:50:42 --> User Agent Class Initialized
INFO - 2018-11-01 16:50:42 --> Controller Class Initialized
INFO - 2018-11-01 16:50:42 --> Helper loaded: file_helper
INFO - 2018-11-01 16:50:42 --> Helper loaded: directory_helper
INFO - 2018-11-01 16:50:42 --> Zip Compression Class Initialized
INFO - 2018-11-01 16:50:43 --> Final output sent to browser
DEBUG - 2018-11-01 16:50:43 --> Total execution time: 1.3394
INFO - 2018-11-01 16:51:02 --> Config Class Initialized
INFO - 2018-11-01 16:51:02 --> Hooks Class Initialized
DEBUG - 2018-11-01 16:51:02 --> UTF-8 Support Enabled
INFO - 2018-11-01 16:51:02 --> Utf8 Class Initialized
INFO - 2018-11-01 16:51:02 --> URI Class Initialized
INFO - 2018-11-01 16:51:02 --> Router Class Initialized
INFO - 2018-11-01 16:51:02 --> Output Class Initialized
INFO - 2018-11-01 16:51:02 --> Security Class Initialized
DEBUG - 2018-11-01 16:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 16:51:02 --> CSRF cookie sent
INFO - 2018-11-01 16:51:02 --> Input Class Initialized
INFO - 2018-11-01 16:51:02 --> Language Class Initialized
INFO - 2018-11-01 16:51:02 --> Loader Class Initialized
INFO - 2018-11-01 16:51:02 --> Helper loaded: url_helper
INFO - 2018-11-01 16:51:02 --> Helper loaded: form_helper
INFO - 2018-11-01 16:51:02 --> Helper loaded: language_helper
DEBUG - 2018-11-01 16:51:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 16:51:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 16:51:02 --> User Agent Class Initialized
INFO - 2018-11-01 16:51:02 --> Controller Class Initialized
INFO - 2018-11-01 16:51:02 --> Helper loaded: file_helper
INFO - 2018-11-01 16:51:02 --> Helper loaded: directory_helper
INFO - 2018-11-01 16:51:02 --> Zip Compression Class Initialized
INFO - 2018-11-01 16:51:03 --> Final output sent to browser
DEBUG - 2018-11-01 16:51:03 --> Total execution time: 1.4372
INFO - 2018-11-01 16:51:31 --> Config Class Initialized
INFO - 2018-11-01 16:51:31 --> Hooks Class Initialized
DEBUG - 2018-11-01 16:51:31 --> UTF-8 Support Enabled
INFO - 2018-11-01 16:51:31 --> Utf8 Class Initialized
INFO - 2018-11-01 16:51:31 --> URI Class Initialized
INFO - 2018-11-01 16:51:31 --> Router Class Initialized
INFO - 2018-11-01 16:51:31 --> Output Class Initialized
INFO - 2018-11-01 16:51:31 --> Security Class Initialized
DEBUG - 2018-11-01 16:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 16:51:31 --> CSRF cookie sent
INFO - 2018-11-01 16:51:31 --> Input Class Initialized
INFO - 2018-11-01 16:51:31 --> Language Class Initialized
ERROR - 2018-11-01 16:51:31 --> Severity: error --> Exception: syntax error, unexpected ''.zip'' (T_CONSTANT_ENCAPSED_STRING), expecting ',' or ')' E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 27
INFO - 2018-11-01 16:51:39 --> Config Class Initialized
INFO - 2018-11-01 16:51:39 --> Hooks Class Initialized
DEBUG - 2018-11-01 16:51:39 --> UTF-8 Support Enabled
INFO - 2018-11-01 16:51:39 --> Utf8 Class Initialized
INFO - 2018-11-01 16:51:39 --> URI Class Initialized
INFO - 2018-11-01 16:51:39 --> Router Class Initialized
INFO - 2018-11-01 16:51:39 --> Output Class Initialized
INFO - 2018-11-01 16:51:39 --> Security Class Initialized
DEBUG - 2018-11-01 16:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 16:51:39 --> CSRF cookie sent
INFO - 2018-11-01 16:51:39 --> Input Class Initialized
INFO - 2018-11-01 16:51:39 --> Language Class Initialized
INFO - 2018-11-01 16:51:39 --> Loader Class Initialized
INFO - 2018-11-01 16:51:39 --> Helper loaded: url_helper
INFO - 2018-11-01 16:51:39 --> Helper loaded: form_helper
INFO - 2018-11-01 16:51:39 --> Helper loaded: language_helper
DEBUG - 2018-11-01 16:51:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 16:51:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 16:51:39 --> User Agent Class Initialized
INFO - 2018-11-01 16:51:39 --> Controller Class Initialized
INFO - 2018-11-01 16:51:39 --> Helper loaded: file_helper
INFO - 2018-11-01 16:51:39 --> Helper loaded: directory_helper
INFO - 2018-11-01 16:51:39 --> Zip Compression Class Initialized
INFO - 2018-11-01 16:51:41 --> Final output sent to browser
DEBUG - 2018-11-01 16:51:41 --> Total execution time: 1.6170
INFO - 2018-11-01 16:52:09 --> Config Class Initialized
INFO - 2018-11-01 16:52:09 --> Hooks Class Initialized
DEBUG - 2018-11-01 16:52:09 --> UTF-8 Support Enabled
INFO - 2018-11-01 16:52:09 --> Utf8 Class Initialized
INFO - 2018-11-01 16:52:09 --> URI Class Initialized
INFO - 2018-11-01 16:52:09 --> Router Class Initialized
INFO - 2018-11-01 16:52:09 --> Output Class Initialized
INFO - 2018-11-01 16:52:09 --> Security Class Initialized
DEBUG - 2018-11-01 16:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 16:52:09 --> CSRF cookie sent
INFO - 2018-11-01 16:52:09 --> Input Class Initialized
INFO - 2018-11-01 16:52:09 --> Language Class Initialized
INFO - 2018-11-01 16:52:09 --> Loader Class Initialized
INFO - 2018-11-01 16:52:09 --> Helper loaded: url_helper
INFO - 2018-11-01 16:52:09 --> Helper loaded: form_helper
INFO - 2018-11-01 16:52:09 --> Helper loaded: language_helper
DEBUG - 2018-11-01 16:52:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 16:52:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 16:52:09 --> User Agent Class Initialized
INFO - 2018-11-01 16:52:09 --> Controller Class Initialized
INFO - 2018-11-01 16:52:09 --> Helper loaded: file_helper
INFO - 2018-11-01 16:52:09 --> Helper loaded: directory_helper
INFO - 2018-11-01 16:52:09 --> Zip Compression Class Initialized
INFO - 2018-11-01 16:52:11 --> Final output sent to browser
DEBUG - 2018-11-01 16:52:11 --> Total execution time: 1.4757
INFO - 2018-11-01 16:54:50 --> Config Class Initialized
INFO - 2018-11-01 16:54:50 --> Hooks Class Initialized
DEBUG - 2018-11-01 16:54:50 --> UTF-8 Support Enabled
INFO - 2018-11-01 16:54:50 --> Utf8 Class Initialized
INFO - 2018-11-01 16:54:50 --> URI Class Initialized
INFO - 2018-11-01 16:54:50 --> Router Class Initialized
INFO - 2018-11-01 16:54:50 --> Output Class Initialized
INFO - 2018-11-01 16:54:50 --> Security Class Initialized
DEBUG - 2018-11-01 16:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 16:54:50 --> CSRF cookie sent
INFO - 2018-11-01 16:54:50 --> Input Class Initialized
INFO - 2018-11-01 16:54:50 --> Language Class Initialized
INFO - 2018-11-01 16:54:50 --> Loader Class Initialized
INFO - 2018-11-01 16:54:50 --> Helper loaded: url_helper
INFO - 2018-11-01 16:54:50 --> Helper loaded: form_helper
INFO - 2018-11-01 16:54:50 --> Helper loaded: language_helper
DEBUG - 2018-11-01 16:54:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 16:54:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 16:54:50 --> User Agent Class Initialized
INFO - 2018-11-01 16:54:50 --> Controller Class Initialized
INFO - 2018-11-01 16:54:50 --> Helper loaded: file_helper
INFO - 2018-11-01 16:54:50 --> Helper loaded: directory_helper
INFO - 2018-11-01 16:54:50 --> Zip Compression Class Initialized
INFO - 2018-11-01 16:54:52 --> Final output sent to browser
DEBUG - 2018-11-01 16:54:52 --> Total execution time: 1.6419
INFO - 2018-11-01 16:56:02 --> Config Class Initialized
INFO - 2018-11-01 16:56:02 --> Hooks Class Initialized
DEBUG - 2018-11-01 16:56:02 --> UTF-8 Support Enabled
INFO - 2018-11-01 16:56:02 --> Utf8 Class Initialized
INFO - 2018-11-01 16:56:02 --> URI Class Initialized
INFO - 2018-11-01 16:56:02 --> Router Class Initialized
INFO - 2018-11-01 16:56:02 --> Output Class Initialized
INFO - 2018-11-01 16:56:02 --> Security Class Initialized
DEBUG - 2018-11-01 16:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 16:56:02 --> CSRF cookie sent
INFO - 2018-11-01 16:56:02 --> Input Class Initialized
INFO - 2018-11-01 16:56:02 --> Language Class Initialized
INFO - 2018-11-01 16:56:02 --> Loader Class Initialized
INFO - 2018-11-01 16:56:02 --> Helper loaded: url_helper
INFO - 2018-11-01 16:56:02 --> Helper loaded: form_helper
INFO - 2018-11-01 16:56:02 --> Helper loaded: language_helper
DEBUG - 2018-11-01 16:56:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 16:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 16:56:02 --> User Agent Class Initialized
INFO - 2018-11-01 16:56:02 --> Controller Class Initialized
INFO - 2018-11-01 16:56:02 --> Helper loaded: file_helper
INFO - 2018-11-01 16:56:02 --> Helper loaded: directory_helper
INFO - 2018-11-01 16:56:02 --> Zip Compression Class Initialized
INFO - 2018-11-01 16:56:03 --> Database Driver Class Initialized
INFO - 2018-11-01 16:56:06 --> Database Utility Class Initialized
INFO - 2018-11-01 16:56:06 --> Database Utility Class Initialized
DEBUG - 2018-11-01 16:56:06 --> Zip class already loaded. Second attempt ignored.
ERROR - 2018-11-01 16:56:06 --> Severity: Notice --> Only variables should be assigned by reference E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 59
INFO - 2018-11-01 16:56:07 --> Final output sent to browser
DEBUG - 2018-11-01 16:56:07 --> Total execution time: 4.6157
INFO - 2018-11-01 16:57:54 --> Config Class Initialized
INFO - 2018-11-01 16:57:54 --> Hooks Class Initialized
DEBUG - 2018-11-01 16:57:54 --> UTF-8 Support Enabled
INFO - 2018-11-01 16:57:54 --> Utf8 Class Initialized
INFO - 2018-11-01 16:57:54 --> URI Class Initialized
INFO - 2018-11-01 16:57:54 --> Router Class Initialized
INFO - 2018-11-01 16:57:54 --> Output Class Initialized
INFO - 2018-11-01 16:57:54 --> Security Class Initialized
DEBUG - 2018-11-01 16:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 16:57:54 --> CSRF cookie sent
INFO - 2018-11-01 16:57:54 --> Input Class Initialized
INFO - 2018-11-01 16:57:54 --> Language Class Initialized
INFO - 2018-11-01 16:57:54 --> Loader Class Initialized
INFO - 2018-11-01 16:57:54 --> Helper loaded: url_helper
INFO - 2018-11-01 16:57:54 --> Helper loaded: form_helper
INFO - 2018-11-01 16:57:54 --> Helper loaded: language_helper
DEBUG - 2018-11-01 16:57:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 16:57:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 16:57:54 --> User Agent Class Initialized
INFO - 2018-11-01 16:57:54 --> Controller Class Initialized
INFO - 2018-11-01 16:57:54 --> Helper loaded: file_helper
INFO - 2018-11-01 16:57:54 --> Helper loaded: directory_helper
INFO - 2018-11-01 16:57:54 --> Zip Compression Class Initialized
INFO - 2018-11-01 16:57:55 --> Database Driver Class Initialized
INFO - 2018-11-01 16:57:58 --> Database Utility Class Initialized
INFO - 2018-11-01 16:57:58 --> Database Utility Class Initialized
DEBUG - 2018-11-01 16:57:58 --> Zip class already loaded. Second attempt ignored.
ERROR - 2018-11-01 16:57:58 --> Severity: Notice --> Only variables should be assigned by reference E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 59
INFO - 2018-11-01 16:57:59 --> Final output sent to browser
DEBUG - 2018-11-01 16:57:59 --> Total execution time: 4.6411
INFO - 2018-11-01 16:59:23 --> Config Class Initialized
INFO - 2018-11-01 16:59:23 --> Hooks Class Initialized
DEBUG - 2018-11-01 16:59:23 --> UTF-8 Support Enabled
INFO - 2018-11-01 16:59:23 --> Utf8 Class Initialized
INFO - 2018-11-01 16:59:23 --> URI Class Initialized
INFO - 2018-11-01 16:59:23 --> Router Class Initialized
INFO - 2018-11-01 16:59:23 --> Output Class Initialized
INFO - 2018-11-01 16:59:23 --> Security Class Initialized
DEBUG - 2018-11-01 16:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 16:59:23 --> CSRF cookie sent
INFO - 2018-11-01 16:59:23 --> Input Class Initialized
INFO - 2018-11-01 16:59:23 --> Language Class Initialized
INFO - 2018-11-01 16:59:23 --> Loader Class Initialized
INFO - 2018-11-01 16:59:23 --> Helper loaded: url_helper
INFO - 2018-11-01 16:59:23 --> Helper loaded: form_helper
INFO - 2018-11-01 16:59:23 --> Helper loaded: language_helper
DEBUG - 2018-11-01 16:59:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 16:59:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 16:59:23 --> User Agent Class Initialized
INFO - 2018-11-01 16:59:23 --> Controller Class Initialized
INFO - 2018-11-01 16:59:23 --> Helper loaded: file_helper
INFO - 2018-11-01 16:59:23 --> Helper loaded: directory_helper
INFO - 2018-11-01 16:59:23 --> Zip Compression Class Initialized
INFO - 2018-11-01 16:59:24 --> Database Driver Class Initialized
INFO - 2018-11-01 16:59:24 --> Database Utility Class Initialized
INFO - 2018-11-01 16:59:24 --> Database Utility Class Initialized
DEBUG - 2018-11-01 16:59:24 --> Zip class already loaded. Second attempt ignored.
ERROR - 2018-11-01 16:59:24 --> Severity: Notice --> Only variables should be assigned by reference E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 59
ERROR - 2018-11-01 16:59:24 --> Severity: Notice --> Undefined variable: backuped E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 63
INFO - 2018-11-01 16:59:25 --> Final output sent to browser
DEBUG - 2018-11-01 16:59:25 --> Total execution time: 1.5181
INFO - 2018-11-01 17:00:26 --> Config Class Initialized
INFO - 2018-11-01 17:00:26 --> Hooks Class Initialized
DEBUG - 2018-11-01 17:00:26 --> UTF-8 Support Enabled
INFO - 2018-11-01 17:00:26 --> Utf8 Class Initialized
INFO - 2018-11-01 17:00:26 --> URI Class Initialized
INFO - 2018-11-01 17:00:26 --> Router Class Initialized
INFO - 2018-11-01 17:00:26 --> Output Class Initialized
INFO - 2018-11-01 17:00:26 --> Security Class Initialized
DEBUG - 2018-11-01 17:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 17:00:26 --> CSRF cookie sent
INFO - 2018-11-01 17:00:26 --> Input Class Initialized
INFO - 2018-11-01 17:00:26 --> Language Class Initialized
INFO - 2018-11-01 17:00:26 --> Loader Class Initialized
INFO - 2018-11-01 17:00:26 --> Helper loaded: url_helper
INFO - 2018-11-01 17:00:26 --> Helper loaded: form_helper
INFO - 2018-11-01 17:00:26 --> Helper loaded: language_helper
DEBUG - 2018-11-01 17:00:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 17:00:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 17:00:26 --> User Agent Class Initialized
INFO - 2018-11-01 17:00:26 --> Controller Class Initialized
INFO - 2018-11-01 17:00:26 --> Helper loaded: file_helper
INFO - 2018-11-01 17:00:26 --> Helper loaded: directory_helper
INFO - 2018-11-01 17:00:26 --> Zip Compression Class Initialized
INFO - 2018-11-01 17:00:27 --> Database Driver Class Initialized
INFO - 2018-11-01 17:00:30 --> Database Utility Class Initialized
INFO - 2018-11-01 17:00:30 --> Database Utility Class Initialized
DEBUG - 2018-11-01 17:00:30 --> Zip class already loaded. Second attempt ignored.
INFO - 2018-11-01 17:00:31 --> Final output sent to browser
DEBUG - 2018-11-01 17:00:31 --> Total execution time: 4.9700
INFO - 2018-11-01 17:01:51 --> Config Class Initialized
INFO - 2018-11-01 17:01:51 --> Hooks Class Initialized
DEBUG - 2018-11-01 17:01:51 --> UTF-8 Support Enabled
INFO - 2018-11-01 17:01:51 --> Utf8 Class Initialized
INFO - 2018-11-01 17:01:51 --> URI Class Initialized
INFO - 2018-11-01 17:01:51 --> Router Class Initialized
INFO - 2018-11-01 17:01:51 --> Output Class Initialized
INFO - 2018-11-01 17:01:51 --> Security Class Initialized
DEBUG - 2018-11-01 17:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 17:01:51 --> CSRF cookie sent
INFO - 2018-11-01 17:01:51 --> Input Class Initialized
INFO - 2018-11-01 17:01:51 --> Language Class Initialized
INFO - 2018-11-01 17:01:51 --> Loader Class Initialized
INFO - 2018-11-01 17:01:51 --> Helper loaded: url_helper
INFO - 2018-11-01 17:01:51 --> Helper loaded: form_helper
INFO - 2018-11-01 17:01:51 --> Helper loaded: language_helper
DEBUG - 2018-11-01 17:01:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 17:01:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 17:01:51 --> User Agent Class Initialized
INFO - 2018-11-01 17:01:51 --> Controller Class Initialized
INFO - 2018-11-01 17:01:51 --> Helper loaded: file_helper
INFO - 2018-11-01 17:01:51 --> Helper loaded: directory_helper
INFO - 2018-11-01 17:01:51 --> Zip Compression Class Initialized
INFO - 2018-11-01 17:01:52 --> Database Driver Class Initialized
INFO - 2018-11-01 17:01:55 --> Database Utility Class Initialized
DEBUG - 2018-11-01 17:01:55 --> Zip class already loaded. Second attempt ignored.
INFO - 2018-11-01 17:01:55 --> Final output sent to browser
DEBUG - 2018-11-01 17:01:55 --> Total execution time: 4.6251
INFO - 2018-11-01 17:02:23 --> Config Class Initialized
INFO - 2018-11-01 17:02:23 --> Hooks Class Initialized
DEBUG - 2018-11-01 17:02:23 --> UTF-8 Support Enabled
INFO - 2018-11-01 17:02:23 --> Utf8 Class Initialized
INFO - 2018-11-01 17:02:23 --> URI Class Initialized
INFO - 2018-11-01 17:02:23 --> Router Class Initialized
INFO - 2018-11-01 17:02:23 --> Output Class Initialized
INFO - 2018-11-01 17:02:23 --> Security Class Initialized
DEBUG - 2018-11-01 17:02:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 17:02:23 --> CSRF cookie sent
INFO - 2018-11-01 17:02:23 --> Input Class Initialized
INFO - 2018-11-01 17:02:23 --> Language Class Initialized
INFO - 2018-11-01 17:02:23 --> Loader Class Initialized
INFO - 2018-11-01 17:02:23 --> Helper loaded: url_helper
INFO - 2018-11-01 17:02:23 --> Helper loaded: form_helper
INFO - 2018-11-01 17:02:23 --> Helper loaded: language_helper
DEBUG - 2018-11-01 17:02:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 17:02:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 17:02:23 --> User Agent Class Initialized
INFO - 2018-11-01 17:02:23 --> Controller Class Initialized
INFO - 2018-11-01 17:02:23 --> Helper loaded: file_helper
INFO - 2018-11-01 17:02:23 --> Helper loaded: directory_helper
INFO - 2018-11-01 17:02:23 --> Zip Compression Class Initialized
INFO - 2018-11-01 17:02:24 --> Database Driver Class Initialized
INFO - 2018-11-01 17:02:24 --> Database Utility Class Initialized
INFO - 2018-11-01 17:02:24 --> Final output sent to browser
DEBUG - 2018-11-01 17:02:24 --> Total execution time: 1.7671
INFO - 2018-11-01 17:04:02 --> Config Class Initialized
INFO - 2018-11-01 17:04:02 --> Hooks Class Initialized
DEBUG - 2018-11-01 17:04:02 --> UTF-8 Support Enabled
INFO - 2018-11-01 17:04:02 --> Utf8 Class Initialized
INFO - 2018-11-01 17:04:02 --> URI Class Initialized
INFO - 2018-11-01 17:04:02 --> Router Class Initialized
INFO - 2018-11-01 17:04:02 --> Output Class Initialized
INFO - 2018-11-01 17:04:02 --> Security Class Initialized
DEBUG - 2018-11-01 17:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 17:04:02 --> CSRF cookie sent
INFO - 2018-11-01 17:04:02 --> Input Class Initialized
INFO - 2018-11-01 17:04:02 --> Language Class Initialized
INFO - 2018-11-01 17:04:02 --> Loader Class Initialized
INFO - 2018-11-01 17:04:02 --> Helper loaded: url_helper
INFO - 2018-11-01 17:04:02 --> Helper loaded: form_helper
INFO - 2018-11-01 17:04:02 --> Helper loaded: language_helper
DEBUG - 2018-11-01 17:04:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 17:04:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 17:04:02 --> User Agent Class Initialized
INFO - 2018-11-01 17:04:02 --> Controller Class Initialized
INFO - 2018-11-01 17:04:02 --> Helper loaded: file_helper
INFO - 2018-11-01 17:04:02 --> Helper loaded: directory_helper
INFO - 2018-11-01 17:04:02 --> Zip Compression Class Initialized
INFO - 2018-11-01 17:04:03 --> Database Driver Class Initialized
INFO - 2018-11-01 17:04:06 --> Database Utility Class Initialized
DEBUG - 2018-11-01 17:04:06 --> Zip class already loaded. Second attempt ignored.
ERROR - 2018-11-01 17:04:06 --> Severity: Warning --> rmdir(./backup/code-backup-on-2018-11-01-17-04-02): Directory not empty E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 30
INFO - 2018-11-01 17:04:06 --> Final output sent to browser
DEBUG - 2018-11-01 17:04:06 --> Total execution time: 4.5202
INFO - 2018-11-01 17:04:43 --> Config Class Initialized
INFO - 2018-11-01 17:04:43 --> Hooks Class Initialized
DEBUG - 2018-11-01 17:04:43 --> UTF-8 Support Enabled
INFO - 2018-11-01 17:04:43 --> Utf8 Class Initialized
INFO - 2018-11-01 17:04:43 --> URI Class Initialized
INFO - 2018-11-01 17:04:43 --> Router Class Initialized
INFO - 2018-11-01 17:04:43 --> Output Class Initialized
INFO - 2018-11-01 17:04:43 --> Security Class Initialized
DEBUG - 2018-11-01 17:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 17:04:43 --> CSRF cookie sent
INFO - 2018-11-01 17:04:43 --> Input Class Initialized
INFO - 2018-11-01 17:04:43 --> Language Class Initialized
INFO - 2018-11-01 17:04:43 --> Loader Class Initialized
INFO - 2018-11-01 17:04:43 --> Helper loaded: url_helper
INFO - 2018-11-01 17:04:43 --> Helper loaded: form_helper
INFO - 2018-11-01 17:04:43 --> Helper loaded: language_helper
DEBUG - 2018-11-01 17:04:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 17:04:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 17:04:43 --> User Agent Class Initialized
INFO - 2018-11-01 17:04:43 --> Controller Class Initialized
INFO - 2018-11-01 17:04:43 --> Helper loaded: file_helper
INFO - 2018-11-01 17:04:43 --> Helper loaded: directory_helper
INFO - 2018-11-01 17:04:43 --> Zip Compression Class Initialized
INFO - 2018-11-01 17:04:44 --> Database Driver Class Initialized
INFO - 2018-11-01 17:04:44 --> Database Utility Class Initialized
DEBUG - 2018-11-01 17:04:44 --> Zip class already loaded. Second attempt ignored.
INFO - 2018-11-01 17:04:46 --> Final output sent to browser
DEBUG - 2018-11-01 17:04:46 --> Total execution time: 3.2385
INFO - 2018-11-01 17:05:42 --> Config Class Initialized
INFO - 2018-11-01 17:05:42 --> Hooks Class Initialized
DEBUG - 2018-11-01 17:05:42 --> UTF-8 Support Enabled
INFO - 2018-11-01 17:05:42 --> Utf8 Class Initialized
INFO - 2018-11-01 17:05:42 --> URI Class Initialized
INFO - 2018-11-01 17:05:42 --> Router Class Initialized
INFO - 2018-11-01 17:05:42 --> Output Class Initialized
INFO - 2018-11-01 17:05:42 --> Security Class Initialized
DEBUG - 2018-11-01 17:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 17:05:42 --> CSRF cookie sent
INFO - 2018-11-01 17:05:42 --> Input Class Initialized
INFO - 2018-11-01 17:05:42 --> Language Class Initialized
INFO - 2018-11-01 17:05:42 --> Loader Class Initialized
INFO - 2018-11-01 17:05:42 --> Helper loaded: url_helper
INFO - 2018-11-01 17:05:42 --> Helper loaded: form_helper
INFO - 2018-11-01 17:05:42 --> Helper loaded: language_helper
DEBUG - 2018-11-01 17:05:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 17:05:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 17:05:42 --> User Agent Class Initialized
INFO - 2018-11-01 17:05:42 --> Controller Class Initialized
INFO - 2018-11-01 17:05:42 --> Helper loaded: file_helper
INFO - 2018-11-01 17:05:42 --> Helper loaded: directory_helper
INFO - 2018-11-01 17:05:42 --> Zip Compression Class Initialized
INFO - 2018-11-01 17:05:43 --> Database Driver Class Initialized
INFO - 2018-11-01 17:05:43 --> Database Utility Class Initialized
DEBUG - 2018-11-01 17:05:43 --> Zip class already loaded. Second attempt ignored.
INFO - 2018-11-01 17:05:46 --> Final output sent to browser
DEBUG - 2018-11-01 17:05:46 --> Total execution time: 3.8844
INFO - 2018-11-01 17:07:42 --> Config Class Initialized
INFO - 2018-11-01 17:07:42 --> Hooks Class Initialized
DEBUG - 2018-11-01 17:07:42 --> UTF-8 Support Enabled
INFO - 2018-11-01 17:07:42 --> Utf8 Class Initialized
INFO - 2018-11-01 17:07:42 --> URI Class Initialized
INFO - 2018-11-01 17:07:42 --> Router Class Initialized
INFO - 2018-11-01 17:07:42 --> Output Class Initialized
INFO - 2018-11-01 17:07:42 --> Security Class Initialized
DEBUG - 2018-11-01 17:07:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 17:07:42 --> CSRF cookie sent
INFO - 2018-11-01 17:07:42 --> Input Class Initialized
INFO - 2018-11-01 17:07:42 --> Language Class Initialized
INFO - 2018-11-01 17:07:42 --> Loader Class Initialized
INFO - 2018-11-01 17:07:42 --> Helper loaded: url_helper
INFO - 2018-11-01 17:07:42 --> Helper loaded: form_helper
INFO - 2018-11-01 17:07:42 --> Helper loaded: language_helper
DEBUG - 2018-11-01 17:07:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 17:07:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 17:07:42 --> User Agent Class Initialized
INFO - 2018-11-01 17:07:42 --> Controller Class Initialized
INFO - 2018-11-01 17:07:42 --> Helper loaded: file_helper
INFO - 2018-11-01 17:07:42 --> Helper loaded: directory_helper
INFO - 2018-11-01 17:07:42 --> Zip Compression Class Initialized
INFO - 2018-11-01 17:07:43 --> Database Driver Class Initialized
INFO - 2018-11-01 17:07:46 --> Database Utility Class Initialized
DEBUG - 2018-11-01 17:07:46 --> Zip class already loaded. Second attempt ignored.
INFO - 2018-11-01 17:07:50 --> Final output sent to browser
DEBUG - 2018-11-01 17:07:50 --> Total execution time: 7.7123
INFO - 2018-11-01 17:09:12 --> Config Class Initialized
INFO - 2018-11-01 17:09:12 --> Hooks Class Initialized
DEBUG - 2018-11-01 17:09:12 --> UTF-8 Support Enabled
INFO - 2018-11-01 17:09:12 --> Utf8 Class Initialized
INFO - 2018-11-01 17:09:12 --> URI Class Initialized
INFO - 2018-11-01 17:09:12 --> Router Class Initialized
INFO - 2018-11-01 17:09:12 --> Output Class Initialized
INFO - 2018-11-01 17:09:12 --> Security Class Initialized
DEBUG - 2018-11-01 17:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 17:09:12 --> CSRF cookie sent
INFO - 2018-11-01 17:09:12 --> Input Class Initialized
INFO - 2018-11-01 17:09:12 --> Language Class Initialized
INFO - 2018-11-01 17:09:12 --> Loader Class Initialized
INFO - 2018-11-01 17:09:12 --> Helper loaded: url_helper
INFO - 2018-11-01 17:09:12 --> Helper loaded: form_helper
INFO - 2018-11-01 17:09:12 --> Helper loaded: language_helper
DEBUG - 2018-11-01 17:09:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 17:09:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 17:09:12 --> User Agent Class Initialized
INFO - 2018-11-01 17:09:12 --> Controller Class Initialized
INFO - 2018-11-01 17:09:12 --> Helper loaded: file_helper
INFO - 2018-11-01 17:09:12 --> Helper loaded: directory_helper
INFO - 2018-11-01 17:09:12 --> Zip Compression Class Initialized
INFO - 2018-11-01 17:09:13 --> Database Driver Class Initialized
INFO - 2018-11-01 17:09:16 --> Database Utility Class Initialized
DEBUG - 2018-11-01 17:09:16 --> Zip class already loaded. Second attempt ignored.
ERROR - 2018-11-01 17:09:19 --> Severity: Warning --> rmdir(code-backup-on-2018-11-01-17-05-44.zip): No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 37
INFO - 2018-11-01 17:09:19 --> Final output sent to browser
DEBUG - 2018-11-01 17:09:19 --> Total execution time: 6.6429
INFO - 2018-11-01 17:09:54 --> Config Class Initialized
INFO - 2018-11-01 17:09:54 --> Hooks Class Initialized
DEBUG - 2018-11-01 17:09:54 --> UTF-8 Support Enabled
INFO - 2018-11-01 17:09:54 --> Utf8 Class Initialized
INFO - 2018-11-01 17:09:54 --> URI Class Initialized
INFO - 2018-11-01 17:09:54 --> Router Class Initialized
INFO - 2018-11-01 17:09:54 --> Output Class Initialized
INFO - 2018-11-01 17:09:54 --> Security Class Initialized
DEBUG - 2018-11-01 17:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 17:09:54 --> CSRF cookie sent
INFO - 2018-11-01 17:09:55 --> Input Class Initialized
INFO - 2018-11-01 17:09:55 --> Language Class Initialized
INFO - 2018-11-01 17:09:55 --> Loader Class Initialized
INFO - 2018-11-01 17:09:55 --> Helper loaded: url_helper
INFO - 2018-11-01 17:09:55 --> Helper loaded: form_helper
INFO - 2018-11-01 17:09:55 --> Helper loaded: language_helper
DEBUG - 2018-11-01 17:09:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 17:09:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 17:09:55 --> User Agent Class Initialized
INFO - 2018-11-01 17:09:55 --> Controller Class Initialized
INFO - 2018-11-01 17:09:55 --> Helper loaded: file_helper
INFO - 2018-11-01 17:09:55 --> Helper loaded: directory_helper
INFO - 2018-11-01 17:09:55 --> Zip Compression Class Initialized
INFO - 2018-11-01 17:09:55 --> Database Driver Class Initialized
INFO - 2018-11-01 17:09:58 --> Database Utility Class Initialized
DEBUG - 2018-11-01 17:09:58 --> Zip class already loaded. Second attempt ignored.
ERROR - 2018-11-01 17:10:02 --> Severity: Notice --> Array to string conversion E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 37
ERROR - 2018-11-01 17:10:02 --> Severity: Warning --> current() expects parameter 1 to be array, string given E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 37
ERROR - 2018-11-01 17:10:02 --> Severity: Warning --> rmdir(): Invalid argument E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 37
INFO - 2018-11-01 17:10:02 --> Final output sent to browser
DEBUG - 2018-11-01 17:10:02 --> Total execution time: 7.4797
INFO - 2018-11-01 17:10:27 --> Config Class Initialized
INFO - 2018-11-01 17:10:27 --> Hooks Class Initialized
DEBUG - 2018-11-01 17:10:27 --> UTF-8 Support Enabled
INFO - 2018-11-01 17:10:27 --> Utf8 Class Initialized
INFO - 2018-11-01 17:10:27 --> URI Class Initialized
INFO - 2018-11-01 17:10:27 --> Router Class Initialized
INFO - 2018-11-01 17:10:27 --> Output Class Initialized
INFO - 2018-11-01 17:10:27 --> Security Class Initialized
DEBUG - 2018-11-01 17:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 17:10:27 --> CSRF cookie sent
INFO - 2018-11-01 17:10:27 --> Input Class Initialized
INFO - 2018-11-01 17:10:27 --> Language Class Initialized
INFO - 2018-11-01 17:10:27 --> Loader Class Initialized
INFO - 2018-11-01 17:10:27 --> Helper loaded: url_helper
INFO - 2018-11-01 17:10:27 --> Helper loaded: form_helper
INFO - 2018-11-01 17:10:27 --> Helper loaded: language_helper
DEBUG - 2018-11-01 17:10:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 17:10:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 17:10:27 --> User Agent Class Initialized
INFO - 2018-11-01 17:10:27 --> Controller Class Initialized
INFO - 2018-11-01 17:10:27 --> Helper loaded: file_helper
INFO - 2018-11-01 17:10:27 --> Helper loaded: directory_helper
INFO - 2018-11-01 17:10:27 --> Zip Compression Class Initialized
INFO - 2018-11-01 17:10:28 --> Database Driver Class Initialized
INFO - 2018-11-01 17:10:28 --> Database Utility Class Initialized
DEBUG - 2018-11-01 17:10:28 --> Zip class already loaded. Second attempt ignored.
ERROR - 2018-11-01 17:10:31 --> Severity: Warning --> rmdir(./backup/code-backup-on-2018-11-01-17-05-44.zip): Not a directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 37
INFO - 2018-11-01 17:10:31 --> Final output sent to browser
DEBUG - 2018-11-01 17:10:31 --> Total execution time: 4.4054
INFO - 2018-11-01 17:12:10 --> Config Class Initialized
INFO - 2018-11-01 17:12:10 --> Hooks Class Initialized
DEBUG - 2018-11-01 17:12:10 --> UTF-8 Support Enabled
INFO - 2018-11-01 17:12:10 --> Utf8 Class Initialized
INFO - 2018-11-01 17:12:10 --> URI Class Initialized
INFO - 2018-11-01 17:12:10 --> Router Class Initialized
INFO - 2018-11-01 17:12:10 --> Output Class Initialized
INFO - 2018-11-01 17:12:10 --> Security Class Initialized
DEBUG - 2018-11-01 17:12:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 17:12:10 --> CSRF cookie sent
INFO - 2018-11-01 17:12:10 --> Input Class Initialized
INFO - 2018-11-01 17:12:10 --> Language Class Initialized
INFO - 2018-11-01 17:12:10 --> Loader Class Initialized
INFO - 2018-11-01 17:12:10 --> Helper loaded: url_helper
INFO - 2018-11-01 17:12:10 --> Helper loaded: form_helper
INFO - 2018-11-01 17:12:10 --> Helper loaded: language_helper
DEBUG - 2018-11-01 17:12:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 17:12:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 17:12:10 --> User Agent Class Initialized
INFO - 2018-11-01 17:12:10 --> Controller Class Initialized
INFO - 2018-11-01 17:12:10 --> Helper loaded: file_helper
INFO - 2018-11-01 17:12:10 --> Helper loaded: directory_helper
INFO - 2018-11-01 17:12:10 --> Zip Compression Class Initialized
INFO - 2018-11-01 17:12:11 --> Database Driver Class Initialized
INFO - 2018-11-01 17:12:14 --> Database Utility Class Initialized
DEBUG - 2018-11-01 17:12:14 --> Zip class already loaded. Second attempt ignored.
INFO - 2018-11-01 17:12:18 --> Final output sent to browser
DEBUG - 2018-11-01 17:12:18 --> Total execution time: 7.3384
INFO - 2018-11-01 17:12:50 --> Config Class Initialized
INFO - 2018-11-01 17:12:50 --> Hooks Class Initialized
DEBUG - 2018-11-01 17:12:50 --> UTF-8 Support Enabled
INFO - 2018-11-01 17:12:50 --> Utf8 Class Initialized
INFO - 2018-11-01 17:12:50 --> URI Class Initialized
INFO - 2018-11-01 17:12:50 --> Router Class Initialized
INFO - 2018-11-01 17:12:50 --> Output Class Initialized
INFO - 2018-11-01 17:12:50 --> Security Class Initialized
DEBUG - 2018-11-01 17:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 17:12:50 --> CSRF cookie sent
INFO - 2018-11-01 17:12:50 --> Input Class Initialized
INFO - 2018-11-01 17:12:50 --> Language Class Initialized
INFO - 2018-11-01 17:12:50 --> Loader Class Initialized
INFO - 2018-11-01 17:12:50 --> Helper loaded: url_helper
INFO - 2018-11-01 17:12:50 --> Helper loaded: form_helper
INFO - 2018-11-01 17:12:50 --> Helper loaded: language_helper
DEBUG - 2018-11-01 17:12:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 17:12:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 17:12:50 --> User Agent Class Initialized
INFO - 2018-11-01 17:12:50 --> Controller Class Initialized
INFO - 2018-11-01 17:12:50 --> Helper loaded: file_helper
INFO - 2018-11-01 17:12:50 --> Helper loaded: directory_helper
INFO - 2018-11-01 17:12:50 --> Zip Compression Class Initialized
INFO - 2018-11-01 17:12:51 --> Database Driver Class Initialized
INFO - 2018-11-01 17:12:51 --> Database Utility Class Initialized
DEBUG - 2018-11-01 17:12:51 --> Zip class already loaded. Second attempt ignored.
INFO - 2018-11-01 17:12:54 --> Final output sent to browser
DEBUG - 2018-11-01 17:12:54 --> Total execution time: 3.7200
INFO - 2018-11-01 17:15:42 --> Config Class Initialized
INFO - 2018-11-01 17:15:42 --> Hooks Class Initialized
DEBUG - 2018-11-01 17:15:42 --> UTF-8 Support Enabled
INFO - 2018-11-01 17:15:42 --> Utf8 Class Initialized
INFO - 2018-11-01 17:15:42 --> URI Class Initialized
INFO - 2018-11-01 17:15:42 --> Router Class Initialized
INFO - 2018-11-01 17:15:42 --> Output Class Initialized
INFO - 2018-11-01 17:15:42 --> Security Class Initialized
DEBUG - 2018-11-01 17:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 17:15:42 --> CSRF cookie sent
INFO - 2018-11-01 17:15:42 --> Input Class Initialized
INFO - 2018-11-01 17:15:42 --> Language Class Initialized
INFO - 2018-11-01 17:15:42 --> Loader Class Initialized
INFO - 2018-11-01 17:15:42 --> Helper loaded: url_helper
INFO - 2018-11-01 17:15:42 --> Helper loaded: form_helper
INFO - 2018-11-01 17:15:42 --> Helper loaded: language_helper
DEBUG - 2018-11-01 17:15:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 17:15:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 17:15:42 --> User Agent Class Initialized
INFO - 2018-11-01 17:15:42 --> Controller Class Initialized
INFO - 2018-11-01 17:15:42 --> Helper loaded: file_helper
INFO - 2018-11-01 17:15:42 --> Helper loaded: directory_helper
INFO - 2018-11-01 17:15:42 --> Zip Compression Class Initialized
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\cache/application\index.html): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\config/application\autoload.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\config/application\config.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\config/application\constants.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\config/application\database.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\config/application\doctypes.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\config/application\email.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\config/application\foreign_chars.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\config/application\hooks.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\config/application\index.html): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\config/application\memcached.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\config/application\migration.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\config/application\mimes.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\config/application\profiler.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\config/application\recaptcha.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\config/application\routes.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\config/application\smileys.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\config/application\user_agents.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\controllers/application\AuthenticationController.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\controllers/application\BackupController.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\controllers/application\EndUserAccountController.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\controllers/application\HomeController.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\controllers/application\MyAccountController.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\controllers/application\PayerReciepientController.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\controllers/application\QuestionnaireController.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\controllers/application\RegistrationController.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\controllers/application\RegistrationController_1.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\controllers/application\index.html): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\core/application\Pixel_Controller.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\core/application\Pixel_Input.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\core/application\Pixel_Model.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\core/application\Pixel_Security.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\core/application\index.html): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\helpers/application\custom_helper.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\helpers/application\index.html): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\hooks/application\index.html): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\language/application\en/application\common_lang.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\language/application\en/application\date_lang.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\language/application\en/application\db_lang.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\language/application\en/application\email_lang.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\language/application\en/application\form_validation_lang.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\language/application\en/application\imglib_lang.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\language/application\en/application\index.html): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\language/application\en/application\notifications_lang.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\language/application\en/application\pagination_lang.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\language/application\en/application\upload_lang.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\libraries/application\Constants.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\libraries/application\EmailsHelper.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\libraries/application\PhpMailerLib.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\libraries/application\PixelUploader.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\libraries/application\Recaptcha.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\libraries/application\Smart.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\libraries/application\index.html): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\index.html): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-03-12.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-03-13.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-03-18.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-03-19.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-03-21.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-03-22.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-03-23.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-03-29.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-04-01.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-04-02.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-04-03.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-04-04.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-04-05.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-04-10.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-04-11.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-04-12.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-04-13.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-04-14.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-04-16.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-04-18.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-04-19.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-04-20.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-04-21.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-04-23.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-04-24.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-04-25.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-04-26.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-04-27.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-04-29.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-04-30.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-05-01.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-05-02.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-06-11.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-06-12.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-06-18.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-06-19.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-06-20.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-06-21.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-06-22.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-06-23.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-06-24.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-06-25.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-06-26.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-06-27.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-06-28.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-06-29.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-06-30.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-07-01.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-07-02.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-07-03.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-07-04.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-07-05.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-07-06.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-07-07.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-07-08.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-07-09.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-07-10.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-07-11.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-07-12.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-07-13.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-07-14.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-07-15.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-07-16.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-07-17.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-07-18.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-07-19.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-07-20.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-07-21.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-07-22.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-07-23.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-07-24.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-07-25.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-07-26.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-07-27.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-07-28.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-07-29.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-07-30.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-07-31.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-08-01.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-08-02.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-08-03.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-08-06.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-08-07.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-08-13.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-08-14.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-08-15.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-08-16.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-08-17.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-08-20.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-08-21.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-08-22.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-08-23.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-08-24.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-08-27.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-08-28.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-08-29.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-08-30.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-09-04.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-09-05.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-09-06.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-09-07.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-09-10.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-09-11.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-09-13.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-09-14.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-09-16.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-09-18.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-09-19.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-09-20.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-09-21.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-09-23.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-09-25.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-09-26.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-09-27.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-09-28.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-10-01.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-10-02.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-10-03.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-10-04.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-10-05.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-10-08.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-10-09.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-10-11.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-10-12.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-10-13.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-10-14.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-10-15.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-10-16.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-10-17.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-10-18.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-10-22.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-10-23.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-10-24.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-10-25.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-10-29.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-10-31.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\logs/application\log-2018-11-01.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\models/application\AuthenticationModel.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\models/application\MyAccountModel.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\models/application\QuestionsModel.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\models/application\RegistrationModel.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\models/application\index.html): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\third_party/application\index.html): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\third_party/application\phpmailer/application\PHPMailer.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\911.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\about.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\advisors.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\asset_indicators.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\buy_gift.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\children_info.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\children_risk.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\cohabitation1.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\consultant.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\contact.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\emails/application\_buttons.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\emails/application\footer.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\emails/application\generic.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\emails/application\header.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\errors/application\cli/application\error_404.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\errors/application\cli/application\error_db.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\errors/application\cli/application\error_exception.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\errors/application\cli/application\error_general.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\errors/application\cli/application\error_php.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\errors/application\cli/application\index.html): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\errors/application\html/application\error_404.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\errors/application\html/application\error_db.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:42 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\errors/application\html/application\error_exception.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\errors/application\html/application\error_general.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\errors/application\html/application\error_php.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\errors/application\html/application\index.html): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\myaccount/application\add_institute.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\myaccount/application\application_list.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\myaccount/application\change_order.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\myaccount/application\change_password.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\myaccount/application\client_list.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\myaccount/application\edit_question.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\myaccount/application\edit_user.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\myaccount/application\forgot_password.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\myaccount/application\institute_list.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\myaccount/application\question_list.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\myaccount/application\signin.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\myaccount/application\users_list.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\additional_business_info.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\affectionate_salutation.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\alcoholic_drinks_per_week.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\application_view.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\assets_details.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\assets_info.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\automobile.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\bank_accounts.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\business_credit_line.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\business_tax_info.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\business_value_assets.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\coh_home_title.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\cohabitation.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\collectables.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\contact_us.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\credit_cards.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\crypto_currencies.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\disability_insurance.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\ethnic_background.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\financial.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\financial_control.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\finish.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\gadgets.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\gift_details.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\gifts_info.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\has_addiction_problem.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\has_dating_profile.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\has_hit_kids.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\has_relationship_outside.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\have_date.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\have_drugs.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\have_hit_s.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\have_loan_money.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\home_owner.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\home_title.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\home_value.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\income.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\influencer.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\influencer_info.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\inheritance.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\inheritance_maintained.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\inherited_income.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\investments_stocks.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\kids.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\kids_activities.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\kids_communicate.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\kids_dinner.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\kids_doctor.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\kids_help_complaint.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\kids_homework.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\kids_info.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\liens_on_house.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\marriage.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\merriage_home_title.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\money_owed_you.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\night_without_s.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\nights_not_home.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\other_autos.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\other_debt.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\other_kids.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\pension.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\people_confide.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\personal_credit_line.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\personal_loans.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\pet_abuse.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\relation_ship_status.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\risk_report.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\s_nights_not_home.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\s_nights_without_you.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\s_social_class.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\save_exit.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\shift_work.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\social_class.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\spouse_info.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\spouse_job.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\start_questions.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\suspension.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\things_to_improve.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\times_slept_couch.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\trust_info.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\wedding_gifit_value.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\withheld_sex.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\questions/application\your_job.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\register/application\activation_success.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\register/application\add_advisor.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\register/application\add_client.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\register/application\complete_registration.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\register/application\import_enduser.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\register/application\import_fa.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\register/application\signup.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\register/application\signup_fa.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\register/application\signup_lawyer.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\register/application\signup_terms.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\register/application\success_message.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\register/application\temp.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\register/application\terms.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\register/application\thanks.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\shared/application\_admin_nav.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\shared/application\_bar.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\shared/application\_basic_nav.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\shared/application\_buttons.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\shared/application\_end_user_nav.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\shared/application\_errors.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\shared/application\_fa_nav.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\shared/application\_footer.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\shared/application\_header.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\shared/application\_lawyer_nav.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\shared/application\_page_banner.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\shared/application\_page_banner_empty.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\shared/application\_page_header.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
ERROR - 2018-11-01 17:15:43 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-15-42/application\views/application\shared/application\_soft_error.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 121
INFO - 2018-11-01 17:15:43 --> Database Driver Class Initialized
INFO - 2018-11-01 17:15:46 --> Database Utility Class Initialized
DEBUG - 2018-11-01 17:15:46 --> Zip class already loaded. Second attempt ignored.
INFO - 2018-11-01 17:15:46 --> Final output sent to browser
DEBUG - 2018-11-01 17:15:46 --> Total execution time: 4.5814
INFO - 2018-11-01 17:17:54 --> Config Class Initialized
INFO - 2018-11-01 17:17:54 --> Hooks Class Initialized
DEBUG - 2018-11-01 17:17:54 --> UTF-8 Support Enabled
INFO - 2018-11-01 17:17:54 --> Utf8 Class Initialized
INFO - 2018-11-01 17:17:54 --> URI Class Initialized
INFO - 2018-11-01 17:17:54 --> Router Class Initialized
INFO - 2018-11-01 17:17:54 --> Output Class Initialized
INFO - 2018-11-01 17:17:54 --> Security Class Initialized
DEBUG - 2018-11-01 17:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 17:17:54 --> CSRF cookie sent
INFO - 2018-11-01 17:17:54 --> Input Class Initialized
INFO - 2018-11-01 17:17:54 --> Language Class Initialized
INFO - 2018-11-01 17:17:54 --> Loader Class Initialized
INFO - 2018-11-01 17:17:54 --> Helper loaded: url_helper
INFO - 2018-11-01 17:17:54 --> Helper loaded: form_helper
INFO - 2018-11-01 17:17:54 --> Helper loaded: language_helper
DEBUG - 2018-11-01 17:17:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 17:17:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 17:17:54 --> User Agent Class Initialized
INFO - 2018-11-01 17:17:54 --> Controller Class Initialized
INFO - 2018-11-01 17:17:54 --> Helper loaded: file_helper
INFO - 2018-11-01 17:17:54 --> Helper loaded: directory_helper
INFO - 2018-11-01 17:17:54 --> Zip Compression Class Initialized
ERROR - 2018-11-01 17:17:54 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\cache/application\index.html): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:54 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\config/application\autoload.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:54 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\config/application\config.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:54 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\config/application\constants.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:54 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\config/application\database.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:54 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\config/application\doctypes.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:54 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\config/application\email.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:54 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\config/application\foreign_chars.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:54 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\config/application\hooks.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:54 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\config/application\index.html): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:54 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\config/application\memcached.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:54 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\config/application\migration.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:54 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\config/application\mimes.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:54 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\config/application\profiler.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:54 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\config/application\recaptcha.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:54 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\config/application\routes.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:54 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\config/application\smileys.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:54 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\config/application\user_agents.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:54 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\controllers/application\AuthenticationController.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:54 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\controllers/application\BackupController.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:54 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\controllers/application\EndUserAccountController.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:54 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\controllers/application\HomeController.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:54 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\controllers/application\MyAccountController.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:54 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\controllers/application\PayerReciepientController.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:54 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\controllers/application\QuestionnaireController.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:54 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\controllers/application\RegistrationController.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:54 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\controllers/application\RegistrationController_1.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:54 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\controllers/application\index.html): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:54 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\core/application\Pixel_Controller.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:54 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\core/application\Pixel_Input.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:54 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\core/application\Pixel_Model.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\core/application\Pixel_Security.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\core/application\index.html): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\helpers/application\custom_helper.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\helpers/application\index.html): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\hooks/application\index.html): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\language/application\en/application\common_lang.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\language/application\en/application\date_lang.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\language/application\en/application\db_lang.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\language/application\en/application\email_lang.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\language/application\en/application\form_validation_lang.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\language/application\en/application\imglib_lang.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\language/application\en/application\index.html): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\language/application\en/application\notifications_lang.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\language/application\en/application\pagination_lang.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\language/application\en/application\upload_lang.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\libraries/application\Constants.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\libraries/application\EmailsHelper.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\libraries/application\PhpMailerLib.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\libraries/application\PixelUploader.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\libraries/application\Recaptcha.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\libraries/application\Smart.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\libraries/application\index.html): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\index.html): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-03-12.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-03-13.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-03-18.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-03-19.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-03-21.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-03-22.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-03-23.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-03-29.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-04-01.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-04-02.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-04-03.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-04-04.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-04-05.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-04-10.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-04-11.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-04-12.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-04-13.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-04-14.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-04-16.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-04-18.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-04-19.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-04-20.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-04-21.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-04-23.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-04-24.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-04-25.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-04-26.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-04-27.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-04-29.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-04-30.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-05-01.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-05-02.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-06-11.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-06-12.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-06-18.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-06-19.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-06-20.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-06-21.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-06-22.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-06-23.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-06-24.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-06-25.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-06-26.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-06-27.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-06-28.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-06-29.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-06-30.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-07-01.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-07-02.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-07-03.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-07-04.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-07-05.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-07-06.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-07-07.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-07-08.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-07-09.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-07-10.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-07-11.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-07-12.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-07-13.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-07-14.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-07-15.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-07-16.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-07-17.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-07-18.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-07-19.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-07-20.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-07-21.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-07-22.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-07-23.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-07-24.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-07-25.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-07-26.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-07-27.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-07-28.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-07-29.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-07-30.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-07-31.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-08-01.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-08-02.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-08-03.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-08-06.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-08-07.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-08-13.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-08-14.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-08-15.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-08-16.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-08-17.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-08-20.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-08-21.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-08-22.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-08-23.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-08-24.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-08-27.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-08-28.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-08-29.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-08-30.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-09-04.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-09-05.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-09-06.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-09-07.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-09-10.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-09-11.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-09-13.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-09-14.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-09-16.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-09-18.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-09-19.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-09-20.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-09-21.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-09-23.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-09-25.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-09-26.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-09-27.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-09-28.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-10-01.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-10-02.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-10-03.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-10-04.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-10-05.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-10-08.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-10-09.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-10-11.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-10-12.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-10-13.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-10-14.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-10-15.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-10-16.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-10-17.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-10-18.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-10-22.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-10-23.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-10-24.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-10-25.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-10-29.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-10-31.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\logs/application\log-2018-11-01.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\models/application\AuthenticationModel.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\models/application\MyAccountModel.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\models/application\QuestionsModel.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\models/application\RegistrationModel.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\models/application\index.html): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\third_party/application\index.html): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\third_party/application\phpmailer/application\PHPMailer.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\911.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\about.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\advisors.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\asset_indicators.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\buy_gift.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\children_info.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\children_risk.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\cohabitation1.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\consultant.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\contact.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\emails/application\_buttons.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\emails/application\footer.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\emails/application\generic.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\emails/application\header.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\errors/application\cli/application\error_404.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\errors/application\cli/application\error_db.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\errors/application\cli/application\error_exception.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\errors/application\cli/application\error_general.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\errors/application\cli/application\error_php.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\errors/application\cli/application\index.html): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\errors/application\html/application\error_404.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\errors/application\html/application\error_db.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\errors/application\html/application\error_exception.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\errors/application\html/application\error_general.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\errors/application\html/application\error_php.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\errors/application\html/application\index.html): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\myaccount/application\add_institute.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\myaccount/application\application_list.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\myaccount/application\change_order.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\myaccount/application\change_password.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\myaccount/application\client_list.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\myaccount/application\edit_question.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\myaccount/application\edit_user.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\myaccount/application\forgot_password.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\myaccount/application\institute_list.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\myaccount/application\question_list.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\myaccount/application\signin.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\myaccount/application\users_list.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\additional_business_info.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\affectionate_salutation.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\alcoholic_drinks_per_week.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\application_view.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\assets_details.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\assets_info.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\automobile.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\bank_accounts.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\business_credit_line.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\business_tax_info.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\business_value_assets.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\coh_home_title.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\cohabitation.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\collectables.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\contact_us.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\credit_cards.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\crypto_currencies.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\disability_insurance.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\ethnic_background.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\financial.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\financial_control.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\finish.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\gadgets.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\gift_details.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\gifts_info.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\has_addiction_problem.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\has_dating_profile.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\has_hit_kids.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\has_relationship_outside.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\have_date.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\have_drugs.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\have_hit_s.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\have_loan_money.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\home_owner.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\home_title.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\home_value.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\income.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\influencer.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\influencer_info.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\inheritance.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\inheritance_maintained.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\inherited_income.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\investments_stocks.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\kids.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\kids_activities.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\kids_communicate.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\kids_dinner.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\kids_doctor.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\kids_help_complaint.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\kids_homework.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\kids_info.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\liens_on_house.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\marriage.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\merriage_home_title.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\money_owed_you.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\night_without_s.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\nights_not_home.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\other_autos.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\other_debt.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\other_kids.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\pension.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\people_confide.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\personal_credit_line.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\personal_loans.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\pet_abuse.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\relation_ship_status.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\risk_report.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\s_nights_not_home.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\s_nights_without_you.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\s_social_class.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\save_exit.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\shift_work.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\social_class.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\spouse_info.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\spouse_job.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\start_questions.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\suspension.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\things_to_improve.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\times_slept_couch.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\trust_info.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\wedding_gifit_value.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\withheld_sex.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\questions/application\your_job.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\register/application\activation_success.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\register/application\add_advisor.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\register/application\add_client.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\register/application\complete_registration.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\register/application\import_enduser.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\register/application\import_fa.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\register/application\signup.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\register/application\signup_fa.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\register/application\signup_lawyer.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\register/application\signup_terms.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\register/application\success_message.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\register/application\temp.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\register/application\terms.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\register/application\thanks.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\shared/application\_admin_nav.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\shared/application\_bar.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\shared/application\_basic_nav.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\shared/application\_buttons.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\shared/application\_end_user_nav.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\shared/application\_errors.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\shared/application\_fa_nav.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\shared/application\_footer.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\shared/application\_header.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\shared/application\_lawyer_nav.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\shared/application\_page_banner.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\shared/application\_page_banner_empty.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\shared/application\_page_header.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:17:55 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-17-54/application\views/application\shared/application\_soft_error.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
INFO - 2018-11-01 17:17:55 --> Database Driver Class Initialized
INFO - 2018-11-01 17:17:58 --> Database Utility Class Initialized
DEBUG - 2018-11-01 17:17:58 --> Zip class already loaded. Second attempt ignored.
INFO - 2018-11-01 17:17:59 --> Final output sent to browser
DEBUG - 2018-11-01 17:17:59 --> Total execution time: 4.2657
INFO - 2018-11-01 17:18:43 --> Config Class Initialized
INFO - 2018-11-01 17:18:43 --> Hooks Class Initialized
DEBUG - 2018-11-01 17:18:43 --> UTF-8 Support Enabled
INFO - 2018-11-01 17:18:43 --> Utf8 Class Initialized
INFO - 2018-11-01 17:18:43 --> URI Class Initialized
INFO - 2018-11-01 17:18:43 --> Router Class Initialized
INFO - 2018-11-01 17:18:43 --> Output Class Initialized
INFO - 2018-11-01 17:18:43 --> Security Class Initialized
DEBUG - 2018-11-01 17:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 17:18:43 --> CSRF cookie sent
INFO - 2018-11-01 17:18:43 --> Input Class Initialized
INFO - 2018-11-01 17:18:43 --> Language Class Initialized
INFO - 2018-11-01 17:18:43 --> Loader Class Initialized
INFO - 2018-11-01 17:18:43 --> Helper loaded: url_helper
INFO - 2018-11-01 17:18:43 --> Helper loaded: form_helper
INFO - 2018-11-01 17:18:43 --> Helper loaded: language_helper
DEBUG - 2018-11-01 17:18:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 17:18:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 17:18:43 --> User Agent Class Initialized
INFO - 2018-11-01 17:18:43 --> Controller Class Initialized
INFO - 2018-11-01 17:18:43 --> Helper loaded: file_helper
INFO - 2018-11-01 17:18:43 --> Helper loaded: directory_helper
INFO - 2018-11-01 17:18:43 --> Zip Compression Class Initialized
INFO - 2018-11-01 17:18:43 --> Database Driver Class Initialized
INFO - 2018-11-01 17:18:43 --> Database Utility Class Initialized
DEBUG - 2018-11-01 17:18:44 --> Zip class already loaded. Second attempt ignored.
INFO - 2018-11-01 17:18:46 --> Final output sent to browser
DEBUG - 2018-11-01 17:18:46 --> Total execution time: 3.5081
INFO - 2018-11-01 17:19:40 --> Config Class Initialized
INFO - 2018-11-01 17:19:40 --> Hooks Class Initialized
DEBUG - 2018-11-01 17:19:40 --> UTF-8 Support Enabled
INFO - 2018-11-01 17:19:40 --> Utf8 Class Initialized
INFO - 2018-11-01 17:19:40 --> URI Class Initialized
INFO - 2018-11-01 17:19:40 --> Router Class Initialized
INFO - 2018-11-01 17:19:40 --> Output Class Initialized
INFO - 2018-11-01 17:19:40 --> Security Class Initialized
DEBUG - 2018-11-01 17:19:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 17:19:40 --> CSRF cookie sent
INFO - 2018-11-01 17:19:40 --> Input Class Initialized
INFO - 2018-11-01 17:19:40 --> Language Class Initialized
INFO - 2018-11-01 17:19:40 --> Loader Class Initialized
INFO - 2018-11-01 17:19:40 --> Helper loaded: url_helper
INFO - 2018-11-01 17:19:40 --> Helper loaded: form_helper
INFO - 2018-11-01 17:19:40 --> Helper loaded: language_helper
DEBUG - 2018-11-01 17:19:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 17:19:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 17:19:40 --> User Agent Class Initialized
INFO - 2018-11-01 17:19:40 --> Controller Class Initialized
INFO - 2018-11-01 17:19:40 --> Helper loaded: file_helper
INFO - 2018-11-01 17:19:40 --> Helper loaded: directory_helper
INFO - 2018-11-01 17:19:40 --> Zip Compression Class Initialized
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\cache/application\index.html): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\config/application\autoload.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\config/application\config.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\config/application\constants.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\config/application\database.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\config/application\doctypes.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\config/application\email.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\config/application\foreign_chars.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\config/application\hooks.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\config/application\index.html): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\config/application\memcached.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\config/application\migration.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\config/application\mimes.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\config/application\profiler.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\config/application\recaptcha.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\config/application\routes.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\config/application\smileys.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\config/application\user_agents.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\controllers/application\AuthenticationController.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\controllers/application\BackupController.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\controllers/application\EndUserAccountController.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\controllers/application\HomeController.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\controllers/application\MyAccountController.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\controllers/application\PayerReciepientController.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\controllers/application\QuestionnaireController.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\controllers/application\RegistrationController.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\controllers/application\RegistrationController_1.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\controllers/application\index.html): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\core/application\Pixel_Controller.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\core/application\Pixel_Input.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\core/application\Pixel_Model.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\core/application\Pixel_Security.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\core/application\index.html): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\helpers/application\custom_helper.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\helpers/application\index.html): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\hooks/application\index.html): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\language/application\en/application\common_lang.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\language/application\en/application\date_lang.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\language/application\en/application\db_lang.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\language/application\en/application\email_lang.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\language/application\en/application\form_validation_lang.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\language/application\en/application\imglib_lang.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\language/application\en/application\index.html): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\language/application\en/application\notifications_lang.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\language/application\en/application\pagination_lang.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\language/application\en/application\upload_lang.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\libraries/application\Constants.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\libraries/application\EmailsHelper.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\libraries/application\PhpMailerLib.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\libraries/application\PixelUploader.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\libraries/application\Recaptcha.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\libraries/application\Smart.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\libraries/application\index.html): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\index.html): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-03-12.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-03-13.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-03-18.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-03-19.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-03-21.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-03-22.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-03-23.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-03-29.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-04-01.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-04-02.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-04-03.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-04-04.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-04-05.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-04-10.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-04-11.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-04-12.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-04-13.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-04-14.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-04-16.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-04-18.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-04-19.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-04-20.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-04-21.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-04-23.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-04-24.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-04-25.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-04-26.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-04-27.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-04-29.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-04-30.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-05-01.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-05-02.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-06-11.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-06-12.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-06-18.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-06-19.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-06-20.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-06-21.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-06-22.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-06-23.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-06-24.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-06-25.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-06-26.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-06-27.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-06-28.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-06-29.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-06-30.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-07-01.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-07-02.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-07-03.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-07-04.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-07-05.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-07-06.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-07-07.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-07-08.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-07-09.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-07-10.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-07-11.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-07-12.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-07-13.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-07-14.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-07-15.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-07-16.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-07-17.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-07-18.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-07-19.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-07-20.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-07-21.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-07-22.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-07-23.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-07-24.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-07-25.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-07-26.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-07-27.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-07-28.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-07-29.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-07-30.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-07-31.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-08-01.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-08-02.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-08-03.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-08-06.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-08-07.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-08-13.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-08-14.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-08-15.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-08-16.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-08-17.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-08-20.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-08-21.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-08-22.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-08-23.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-08-24.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-08-27.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-08-28.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-08-29.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-08-30.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-09-04.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-09-05.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-09-06.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-09-07.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-09-10.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-09-11.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-09-13.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-09-14.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-09-16.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-09-18.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-09-19.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-09-20.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-09-21.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-09-23.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-09-25.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-09-26.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-09-27.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-09-28.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-10-01.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-10-02.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-10-03.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-10-04.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-10-05.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-10-08.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-10-09.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-10-11.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-10-12.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-10-13.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-10-14.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-10-15.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-10-16.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-10-17.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-10-18.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-10-22.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-10-23.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-10-24.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-10-25.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-10-29.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-10-31.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\logs/application\log-2018-11-01.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\models/application\AuthenticationModel.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\models/application\MyAccountModel.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\models/application\QuestionsModel.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\models/application\RegistrationModel.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\models/application\index.html): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\third_party/application\index.html): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\third_party/application\phpmailer/application\PHPMailer.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\911.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\about.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\advisors.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\asset_indicators.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\buy_gift.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\children_info.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\children_risk.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\cohabitation1.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\consultant.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\contact.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\emails/application\_buttons.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\emails/application\footer.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\emails/application\generic.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\emails/application\header.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\errors/application\cli/application\error_404.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\errors/application\cli/application\error_db.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\errors/application\cli/application\error_exception.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\errors/application\cli/application\error_general.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\errors/application\cli/application\error_php.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\errors/application\cli/application\index.html): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\errors/application\html/application\error_404.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\errors/application\html/application\error_db.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\errors/application\html/application\error_exception.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\errors/application\html/application\error_general.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\errors/application\html/application\error_php.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\errors/application\html/application\index.html): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\myaccount/application\add_institute.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\myaccount/application\application_list.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\myaccount/application\change_order.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\myaccount/application\change_password.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\myaccount/application\client_list.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\myaccount/application\edit_question.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\myaccount/application\edit_user.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\myaccount/application\forgot_password.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\myaccount/application\institute_list.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\myaccount/application\question_list.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\myaccount/application\signin.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\myaccount/application\users_list.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\additional_business_info.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\affectionate_salutation.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\alcoholic_drinks_per_week.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\application_view.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\assets_details.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\assets_info.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\automobile.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\bank_accounts.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\business_credit_line.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\business_tax_info.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\business_value_assets.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:40 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\coh_home_title.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\cohabitation.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\collectables.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\contact_us.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\credit_cards.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\crypto_currencies.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\disability_insurance.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\ethnic_background.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\financial.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\financial_control.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\finish.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\gadgets.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\gift_details.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\gifts_info.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\has_addiction_problem.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\has_dating_profile.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\has_hit_kids.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\has_relationship_outside.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\have_date.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\have_drugs.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\have_hit_s.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\have_loan_money.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\home_owner.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\home_title.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\home_value.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\income.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\influencer.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\influencer_info.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\inheritance.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\inheritance_maintained.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\inherited_income.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\investments_stocks.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\kids.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\kids_activities.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\kids_communicate.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\kids_dinner.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\kids_doctor.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\kids_help_complaint.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\kids_homework.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\kids_info.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\liens_on_house.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\marriage.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\merriage_home_title.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\money_owed_you.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\night_without_s.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\nights_not_home.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\other_autos.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\other_debt.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\other_kids.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\pension.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\people_confide.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\personal_credit_line.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\personal_loans.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\pet_abuse.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\relation_ship_status.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\risk_report.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\s_nights_not_home.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\s_nights_without_you.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\s_social_class.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\save_exit.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\shift_work.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\social_class.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\spouse_info.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\spouse_job.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\start_questions.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\suspension.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\things_to_improve.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\times_slept_couch.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\trust_info.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\wedding_gifit_value.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\withheld_sex.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\questions/application\your_job.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\register/application\activation_success.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\register/application\add_advisor.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\register/application\add_client.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\register/application\complete_registration.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\register/application\import_enduser.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\register/application\import_fa.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\register/application\signup.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\register/application\signup_fa.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\register/application\signup_lawyer.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\register/application\signup_terms.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\register/application\success_message.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\register/application\temp.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\register/application\terms.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\register/application\thanks.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\shared/application\_admin_nav.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\shared/application\_bar.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\shared/application\_basic_nav.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\shared/application\_buttons.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\shared/application\_end_user_nav.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\shared/application\_errors.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\shared/application\_fa_nav.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\shared/application\_footer.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\shared/application\_header.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\shared/application\_lawyer_nav.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\shared/application\_page_banner.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\shared/application\_page_banner_empty.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\shared/application\_page_header.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
ERROR - 2018-11-01 17:19:41 --> Severity: Warning --> copy(./backup/code-backup-on-2018-11-01-17-19-40/application\views/application\shared/application\_soft_error.php): failed to open stream: No such file or directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 120
INFO - 2018-11-01 17:19:41 --> Database Driver Class Initialized
INFO - 2018-11-01 17:19:41 --> Database Utility Class Initialized
DEBUG - 2018-11-01 17:19:41 --> Zip class already loaded. Second attempt ignored.
INFO - 2018-11-01 17:19:41 --> Final output sent to browser
DEBUG - 2018-11-01 17:19:41 --> Total execution time: 1.6607
INFO - 2018-11-01 17:20:25 --> Config Class Initialized
INFO - 2018-11-01 17:20:25 --> Hooks Class Initialized
DEBUG - 2018-11-01 17:20:25 --> UTF-8 Support Enabled
INFO - 2018-11-01 17:20:25 --> Utf8 Class Initialized
INFO - 2018-11-01 17:20:25 --> URI Class Initialized
INFO - 2018-11-01 17:20:25 --> Router Class Initialized
INFO - 2018-11-01 17:20:25 --> Output Class Initialized
INFO - 2018-11-01 17:20:25 --> Security Class Initialized
DEBUG - 2018-11-01 17:20:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 17:20:25 --> CSRF cookie sent
INFO - 2018-11-01 17:20:25 --> Input Class Initialized
INFO - 2018-11-01 17:20:25 --> Language Class Initialized
INFO - 2018-11-01 17:20:25 --> Loader Class Initialized
INFO - 2018-11-01 17:20:25 --> Helper loaded: url_helper
INFO - 2018-11-01 17:20:25 --> Helper loaded: form_helper
INFO - 2018-11-01 17:20:25 --> Helper loaded: language_helper
DEBUG - 2018-11-01 17:20:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 17:20:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 17:20:25 --> User Agent Class Initialized
INFO - 2018-11-01 17:20:25 --> Controller Class Initialized
INFO - 2018-11-01 17:20:25 --> Helper loaded: file_helper
INFO - 2018-11-01 17:20:25 --> Helper loaded: directory_helper
INFO - 2018-11-01 17:20:25 --> Zip Compression Class Initialized
INFO - 2018-11-01 17:20:26 --> Database Driver Class Initialized
INFO - 2018-11-01 17:20:29 --> Database Utility Class Initialized
DEBUG - 2018-11-01 17:20:29 --> Zip class already loaded. Second attempt ignored.
INFO - 2018-11-01 17:20:31 --> Final output sent to browser
DEBUG - 2018-11-01 17:20:31 --> Total execution time: 6.1473
INFO - 2018-11-01 17:21:09 --> Config Class Initialized
INFO - 2018-11-01 17:21:09 --> Hooks Class Initialized
DEBUG - 2018-11-01 17:21:09 --> UTF-8 Support Enabled
INFO - 2018-11-01 17:21:09 --> Utf8 Class Initialized
INFO - 2018-11-01 17:21:09 --> URI Class Initialized
INFO - 2018-11-01 17:21:09 --> Router Class Initialized
INFO - 2018-11-01 17:21:09 --> Output Class Initialized
INFO - 2018-11-01 17:21:09 --> Security Class Initialized
DEBUG - 2018-11-01 17:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 17:21:09 --> CSRF cookie sent
INFO - 2018-11-01 17:21:09 --> Input Class Initialized
INFO - 2018-11-01 17:21:09 --> Language Class Initialized
INFO - 2018-11-01 17:21:09 --> Loader Class Initialized
INFO - 2018-11-01 17:21:09 --> Helper loaded: url_helper
INFO - 2018-11-01 17:21:09 --> Helper loaded: form_helper
INFO - 2018-11-01 17:21:09 --> Helper loaded: language_helper
DEBUG - 2018-11-01 17:21:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 17:21:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 17:21:09 --> User Agent Class Initialized
INFO - 2018-11-01 17:21:09 --> Controller Class Initialized
INFO - 2018-11-01 17:21:09 --> Helper loaded: file_helper
INFO - 2018-11-01 17:21:09 --> Helper loaded: directory_helper
INFO - 2018-11-01 17:21:09 --> Zip Compression Class Initialized
INFO - 2018-11-01 17:21:10 --> Database Driver Class Initialized
INFO - 2018-11-01 17:21:10 --> Database Utility Class Initialized
DEBUG - 2018-11-01 17:21:10 --> Zip class already loaded. Second attempt ignored.
INFO - 2018-11-01 17:21:14 --> Final output sent to browser
DEBUG - 2018-11-01 17:21:14 --> Total execution time: 4.5339
INFO - 2018-11-01 17:22:19 --> Config Class Initialized
INFO - 2018-11-01 17:22:19 --> Hooks Class Initialized
DEBUG - 2018-11-01 17:22:19 --> UTF-8 Support Enabled
INFO - 2018-11-01 17:22:19 --> Utf8 Class Initialized
INFO - 2018-11-01 17:22:19 --> URI Class Initialized
INFO - 2018-11-01 17:22:19 --> Router Class Initialized
INFO - 2018-11-01 17:22:19 --> Output Class Initialized
INFO - 2018-11-01 17:22:19 --> Security Class Initialized
DEBUG - 2018-11-01 17:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-01 17:22:19 --> CSRF cookie sent
INFO - 2018-11-01 17:22:19 --> Input Class Initialized
INFO - 2018-11-01 17:22:19 --> Language Class Initialized
INFO - 2018-11-01 17:22:19 --> Loader Class Initialized
INFO - 2018-11-01 17:22:19 --> Helper loaded: url_helper
INFO - 2018-11-01 17:22:19 --> Helper loaded: form_helper
INFO - 2018-11-01 17:22:19 --> Helper loaded: language_helper
DEBUG - 2018-11-01 17:22:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-01 17:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-01 17:22:19 --> User Agent Class Initialized
INFO - 2018-11-01 17:22:19 --> Controller Class Initialized
INFO - 2018-11-01 17:22:19 --> Helper loaded: file_helper
INFO - 2018-11-01 17:22:19 --> Helper loaded: directory_helper
INFO - 2018-11-01 17:22:19 --> Zip Compression Class Initialized
INFO - 2018-11-01 17:22:20 --> Database Driver Class Initialized
INFO - 2018-11-01 17:22:23 --> Database Utility Class Initialized
DEBUG - 2018-11-01 17:22:23 --> Zip class already loaded. Second attempt ignored.
INFO - 2018-11-01 17:22:25 --> Final output sent to browser
DEBUG - 2018-11-01 17:22:25 --> Total execution time: 6.5531

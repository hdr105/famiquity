<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-11-03 13:12:27 --> Config Class Initialized
INFO - 2018-11-03 13:12:27 --> Hooks Class Initialized
DEBUG - 2018-11-03 13:12:27 --> UTF-8 Support Enabled
INFO - 2018-11-03 13:12:27 --> Utf8 Class Initialized
INFO - 2018-11-03 13:12:27 --> URI Class Initialized
DEBUG - 2018-11-03 13:12:27 --> No URI present. Default controller set.
INFO - 2018-11-03 13:12:27 --> Router Class Initialized
INFO - 2018-11-03 13:12:27 --> Output Class Initialized
INFO - 2018-11-03 13:12:27 --> Security Class Initialized
DEBUG - 2018-11-03 13:12:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-03 13:12:27 --> CSRF cookie sent
INFO - 2018-11-03 13:12:27 --> Input Class Initialized
INFO - 2018-11-03 13:12:27 --> Language Class Initialized
INFO - 2018-11-03 13:12:27 --> Loader Class Initialized
INFO - 2018-11-03 13:12:27 --> Helper loaded: url_helper
INFO - 2018-11-03 13:12:27 --> Helper loaded: form_helper
INFO - 2018-11-03 13:12:27 --> Helper loaded: language_helper
DEBUG - 2018-11-03 13:12:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-03 13:12:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-03 13:12:27 --> User Agent Class Initialized
INFO - 2018-11-03 13:12:27 --> Controller Class Initialized
INFO - 2018-11-03 13:12:27 --> Helper loaded: directory_helper
INFO - 2018-11-03 13:12:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-11-03 13:12:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-11-03 13:12:28 --> Helper loaded: custom_helper
INFO - 2018-11-03 13:12:28 --> Pixel_Model class loaded
INFO - 2018-11-03 13:12:28 --> Database Driver Class Initialized
INFO - 2018-11-03 13:12:28 --> Model "QuestionsModel" initialized
INFO - 2018-11-03 13:12:28 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-11-03 13:12:28 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-11-03 13:12:28 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-11-03 13:12:28 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-11-03 13:12:28 --> Final output sent to browser
DEBUG - 2018-11-03 13:12:28 --> Total execution time: 0.2122
INFO - 2018-11-03 13:15:22 --> Config Class Initialized
INFO - 2018-11-03 13:15:22 --> Hooks Class Initialized
DEBUG - 2018-11-03 13:15:22 --> UTF-8 Support Enabled
INFO - 2018-11-03 13:15:22 --> Utf8 Class Initialized
INFO - 2018-11-03 13:15:22 --> URI Class Initialized
INFO - 2018-11-03 13:15:22 --> Router Class Initialized
INFO - 2018-11-03 13:15:22 --> Output Class Initialized
INFO - 2018-11-03 13:15:22 --> Security Class Initialized
DEBUG - 2018-11-03 13:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-03 13:15:22 --> CSRF cookie sent
INFO - 2018-11-03 13:15:22 --> Input Class Initialized
INFO - 2018-11-03 13:15:22 --> Language Class Initialized
INFO - 2018-11-03 13:15:22 --> Loader Class Initialized
INFO - 2018-11-03 13:15:22 --> Helper loaded: url_helper
INFO - 2018-11-03 13:15:22 --> Helper loaded: form_helper
INFO - 2018-11-03 13:15:22 --> Helper loaded: language_helper
DEBUG - 2018-11-03 13:15:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-03 13:15:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-03 13:15:22 --> User Agent Class Initialized
INFO - 2018-11-03 13:15:22 --> Controller Class Initialized
INFO - 2018-11-03 13:15:22 --> Helper loaded: file_helper
INFO - 2018-11-03 13:15:22 --> Helper loaded: directory_helper
INFO - 2018-11-03 13:15:22 --> Zip Compression Class Initialized
INFO - 2018-11-03 13:15:24 --> Database Driver Class Initialized
INFO - 2018-11-03 13:15:27 --> Database Utility Class Initialized
DEBUG - 2018-11-03 13:15:27 --> Zip class already loaded. Second attempt ignored.
INFO - 2018-11-03 13:15:30 --> Final output sent to browser
DEBUG - 2018-11-03 13:15:30 --> Total execution time: 8.7137
INFO - 2018-11-03 13:17:35 --> Config Class Initialized
INFO - 2018-11-03 13:17:35 --> Hooks Class Initialized
DEBUG - 2018-11-03 13:17:35 --> UTF-8 Support Enabled
INFO - 2018-11-03 13:17:35 --> Utf8 Class Initialized
INFO - 2018-11-03 13:17:35 --> URI Class Initialized
INFO - 2018-11-03 13:17:35 --> Router Class Initialized
INFO - 2018-11-03 13:17:35 --> Output Class Initialized
INFO - 2018-11-03 13:17:35 --> Security Class Initialized
DEBUG - 2018-11-03 13:17:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-03 13:17:35 --> CSRF cookie sent
INFO - 2018-11-03 13:17:35 --> Input Class Initialized
INFO - 2018-11-03 13:17:35 --> Language Class Initialized
INFO - 2018-11-03 13:17:35 --> Loader Class Initialized
INFO - 2018-11-03 13:17:35 --> Helper loaded: url_helper
INFO - 2018-11-03 13:17:35 --> Helper loaded: form_helper
INFO - 2018-11-03 13:17:35 --> Helper loaded: language_helper
DEBUG - 2018-11-03 13:17:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-03 13:17:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-03 13:17:35 --> User Agent Class Initialized
INFO - 2018-11-03 13:17:35 --> Controller Class Initialized
INFO - 2018-11-03 13:17:35 --> Helper loaded: file_helper
INFO - 2018-11-03 13:17:35 --> Helper loaded: directory_helper
INFO - 2018-11-03 13:17:35 --> Zip Compression Class Initialized
INFO - 2018-11-03 13:17:36 --> Database Driver Class Initialized
INFO - 2018-11-03 13:17:39 --> Database Utility Class Initialized
DEBUG - 2018-11-03 13:17:39 --> Zip class already loaded. Second attempt ignored.
INFO - 2018-11-03 13:17:43 --> Final output sent to browser
DEBUG - 2018-11-03 13:17:43 --> Total execution time: 8.5180
INFO - 2018-11-03 13:19:55 --> Config Class Initialized
INFO - 2018-11-03 13:19:55 --> Hooks Class Initialized
DEBUG - 2018-11-03 13:19:55 --> UTF-8 Support Enabled
INFO - 2018-11-03 13:19:55 --> Utf8 Class Initialized
INFO - 2018-11-03 13:19:55 --> URI Class Initialized
INFO - 2018-11-03 13:19:55 --> Router Class Initialized
INFO - 2018-11-03 13:19:55 --> Output Class Initialized
INFO - 2018-11-03 13:19:55 --> Security Class Initialized
DEBUG - 2018-11-03 13:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-03 13:19:55 --> CSRF cookie sent
INFO - 2018-11-03 13:19:55 --> Input Class Initialized
INFO - 2018-11-03 13:19:55 --> Language Class Initialized
INFO - 2018-11-03 13:19:55 --> Loader Class Initialized
INFO - 2018-11-03 13:19:55 --> Helper loaded: url_helper
INFO - 2018-11-03 13:19:55 --> Helper loaded: form_helper
INFO - 2018-11-03 13:19:55 --> Helper loaded: language_helper
DEBUG - 2018-11-03 13:19:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-03 13:19:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-03 13:19:55 --> User Agent Class Initialized
INFO - 2018-11-03 13:19:55 --> Controller Class Initialized
INFO - 2018-11-03 13:19:55 --> Helper loaded: file_helper
INFO - 2018-11-03 13:19:55 --> Helper loaded: directory_helper
INFO - 2018-11-03 13:19:55 --> Zip Compression Class Initialized
INFO - 2018-11-03 13:19:58 --> Database Driver Class Initialized
INFO - 2018-11-03 13:20:01 --> Database Utility Class Initialized
DEBUG - 2018-11-03 13:20:01 --> Zip class already loaded. Second attempt ignored.
INFO - 2018-11-03 13:20:08 --> Final output sent to browser
DEBUG - 2018-11-03 13:20:08 --> Total execution time: 13.0141
INFO - 2018-11-03 13:21:58 --> Config Class Initialized
INFO - 2018-11-03 13:21:58 --> Hooks Class Initialized
DEBUG - 2018-11-03 13:21:58 --> UTF-8 Support Enabled
INFO - 2018-11-03 13:21:58 --> Utf8 Class Initialized
INFO - 2018-11-03 13:21:58 --> URI Class Initialized
INFO - 2018-11-03 13:21:58 --> Router Class Initialized
INFO - 2018-11-03 13:21:58 --> Output Class Initialized
INFO - 2018-11-03 13:21:58 --> Security Class Initialized
DEBUG - 2018-11-03 13:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-03 13:21:58 --> CSRF cookie sent
INFO - 2018-11-03 13:21:58 --> Input Class Initialized
INFO - 2018-11-03 13:21:58 --> Language Class Initialized
INFO - 2018-11-03 13:21:58 --> Loader Class Initialized
INFO - 2018-11-03 13:21:58 --> Helper loaded: url_helper
INFO - 2018-11-03 13:21:58 --> Helper loaded: form_helper
INFO - 2018-11-03 13:21:58 --> Helper loaded: language_helper
DEBUG - 2018-11-03 13:21:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-03 13:21:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-03 13:21:58 --> User Agent Class Initialized
INFO - 2018-11-03 13:21:58 --> Controller Class Initialized
INFO - 2018-11-03 13:21:58 --> Helper loaded: file_helper
INFO - 2018-11-03 13:21:58 --> Helper loaded: directory_helper
INFO - 2018-11-03 13:21:58 --> Zip Compression Class Initialized
INFO - 2018-11-03 13:22:02 --> Database Driver Class Initialized
INFO - 2018-11-03 13:22:05 --> Database Utility Class Initialized
DEBUG - 2018-11-03 13:22:05 --> Zip class already loaded. Second attempt ignored.
INFO - 2018-11-03 13:22:13 --> Final output sent to browser
DEBUG - 2018-11-03 13:22:13 --> Total execution time: 15.2099
INFO - 2018-11-03 13:25:15 --> Config Class Initialized
INFO - 2018-11-03 13:25:15 --> Hooks Class Initialized
DEBUG - 2018-11-03 13:25:15 --> UTF-8 Support Enabled
INFO - 2018-11-03 13:25:15 --> Utf8 Class Initialized
INFO - 2018-11-03 13:25:15 --> URI Class Initialized
INFO - 2018-11-03 13:25:15 --> Router Class Initialized
INFO - 2018-11-03 13:25:15 --> Output Class Initialized
INFO - 2018-11-03 13:25:15 --> Security Class Initialized
DEBUG - 2018-11-03 13:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-03 13:25:15 --> CSRF cookie sent
INFO - 2018-11-03 13:25:15 --> Input Class Initialized
INFO - 2018-11-03 13:25:15 --> Language Class Initialized
INFO - 2018-11-03 13:25:15 --> Loader Class Initialized
INFO - 2018-11-03 13:25:15 --> Helper loaded: url_helper
INFO - 2018-11-03 13:25:15 --> Helper loaded: form_helper
INFO - 2018-11-03 13:25:15 --> Helper loaded: language_helper
DEBUG - 2018-11-03 13:25:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-03 13:25:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-03 13:25:15 --> User Agent Class Initialized
INFO - 2018-11-03 13:25:15 --> Controller Class Initialized
INFO - 2018-11-03 13:25:15 --> Helper loaded: file_helper
INFO - 2018-11-03 13:25:15 --> Helper loaded: directory_helper
INFO - 2018-11-03 13:25:15 --> Zip Compression Class Initialized
INFO - 2018-11-03 13:25:18 --> Database Driver Class Initialized
INFO - 2018-11-03 13:25:21 --> Database Utility Class Initialized
DEBUG - 2018-11-03 13:25:21 --> Zip class already loaded. Second attempt ignored.
ERROR - 2018-11-03 13:25:21 --> Severity: Warning --> copy(): The second argument to copy() function cannot be a directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 232
ERROR - 2018-11-03 13:25:21 --> Severity: Warning --> copy(): The second argument to copy() function cannot be a directory E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 232
INFO - 2018-11-03 13:25:28 --> Final output sent to browser
DEBUG - 2018-11-03 13:25:28 --> Total execution time: 13.2373
INFO - 2018-11-03 13:27:49 --> Config Class Initialized
INFO - 2018-11-03 13:27:49 --> Hooks Class Initialized
DEBUG - 2018-11-03 13:27:49 --> UTF-8 Support Enabled
INFO - 2018-11-03 13:27:49 --> Utf8 Class Initialized
INFO - 2018-11-03 13:27:49 --> URI Class Initialized
INFO - 2018-11-03 13:27:49 --> Router Class Initialized
INFO - 2018-11-03 13:27:49 --> Output Class Initialized
INFO - 2018-11-03 13:27:49 --> Security Class Initialized
DEBUG - 2018-11-03 13:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-03 13:27:49 --> CSRF cookie sent
INFO - 2018-11-03 13:27:49 --> Input Class Initialized
INFO - 2018-11-03 13:27:49 --> Language Class Initialized
INFO - 2018-11-03 13:27:49 --> Loader Class Initialized
INFO - 2018-11-03 13:27:49 --> Helper loaded: url_helper
INFO - 2018-11-03 13:27:49 --> Helper loaded: form_helper
INFO - 2018-11-03 13:27:49 --> Helper loaded: language_helper
DEBUG - 2018-11-03 13:27:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-03 13:27:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-03 13:27:49 --> User Agent Class Initialized
INFO - 2018-11-03 13:27:49 --> Controller Class Initialized
INFO - 2018-11-03 13:27:49 --> Helper loaded: file_helper
INFO - 2018-11-03 13:27:49 --> Helper loaded: directory_helper
INFO - 2018-11-03 13:27:49 --> Zip Compression Class Initialized
INFO - 2018-11-03 13:27:52 --> Database Driver Class Initialized
INFO - 2018-11-03 13:27:52 --> Database Utility Class Initialized
DEBUG - 2018-11-03 13:27:52 --> Zip class already loaded. Second attempt ignored.
INFO - 2018-11-03 13:28:02 --> Final output sent to browser
DEBUG - 2018-11-03 13:28:02 --> Total execution time: 13.4584
INFO - 2018-11-03 13:29:14 --> Config Class Initialized
INFO - 2018-11-03 13:29:14 --> Hooks Class Initialized
DEBUG - 2018-11-03 13:29:14 --> UTF-8 Support Enabled
INFO - 2018-11-03 13:29:14 --> Utf8 Class Initialized
INFO - 2018-11-03 13:29:14 --> URI Class Initialized
INFO - 2018-11-03 13:29:14 --> Router Class Initialized
INFO - 2018-11-03 13:29:14 --> Output Class Initialized
INFO - 2018-11-03 13:29:14 --> Security Class Initialized
DEBUG - 2018-11-03 13:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-03 13:29:14 --> CSRF cookie sent
INFO - 2018-11-03 13:29:14 --> Input Class Initialized
INFO - 2018-11-03 13:29:14 --> Language Class Initialized
INFO - 2018-11-03 13:29:14 --> Loader Class Initialized
INFO - 2018-11-03 13:29:14 --> Helper loaded: url_helper
INFO - 2018-11-03 13:29:14 --> Helper loaded: form_helper
INFO - 2018-11-03 13:29:14 --> Helper loaded: language_helper
DEBUG - 2018-11-03 13:29:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-03 13:29:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-03 13:29:14 --> User Agent Class Initialized
INFO - 2018-11-03 13:29:14 --> Controller Class Initialized
INFO - 2018-11-03 13:29:14 --> Helper loaded: file_helper
INFO - 2018-11-03 13:29:14 --> Helper loaded: directory_helper
INFO - 2018-11-03 13:29:14 --> Zip Compression Class Initialized
INFO - 2018-11-03 13:29:17 --> Database Driver Class Initialized
INFO - 2018-11-03 13:29:20 --> Database Utility Class Initialized
DEBUG - 2018-11-03 13:29:20 --> Zip class already loaded. Second attempt ignored.
INFO - 2018-11-03 13:29:27 --> Final output sent to browser
DEBUG - 2018-11-03 13:29:27 --> Total execution time: 13.1414
INFO - 2018-11-03 13:32:41 --> Config Class Initialized
INFO - 2018-11-03 13:32:41 --> Hooks Class Initialized
DEBUG - 2018-11-03 13:32:41 --> UTF-8 Support Enabled
INFO - 2018-11-03 13:32:41 --> Utf8 Class Initialized
INFO - 2018-11-03 13:32:41 --> URI Class Initialized
INFO - 2018-11-03 13:32:41 --> Router Class Initialized
INFO - 2018-11-03 13:32:41 --> Output Class Initialized
INFO - 2018-11-03 13:32:41 --> Security Class Initialized
DEBUG - 2018-11-03 13:32:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-03 13:32:41 --> CSRF cookie sent
INFO - 2018-11-03 13:32:41 --> Input Class Initialized
INFO - 2018-11-03 13:32:41 --> Language Class Initialized
INFO - 2018-11-03 13:32:41 --> Loader Class Initialized
INFO - 2018-11-03 13:32:41 --> Helper loaded: url_helper
INFO - 2018-11-03 13:32:41 --> Helper loaded: form_helper
INFO - 2018-11-03 13:32:41 --> Helper loaded: language_helper
DEBUG - 2018-11-03 13:32:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-03 13:32:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-03 13:32:41 --> User Agent Class Initialized
INFO - 2018-11-03 13:32:41 --> Controller Class Initialized
INFO - 2018-11-03 13:32:41 --> Helper loaded: file_helper
INFO - 2018-11-03 13:32:41 --> Helper loaded: directory_helper
INFO - 2018-11-03 13:32:41 --> Zip Compression Class Initialized
INFO - 2018-11-03 13:32:44 --> Database Driver Class Initialized
INFO - 2018-11-03 13:32:47 --> Database Utility Class Initialized
DEBUG - 2018-11-03 13:32:47 --> Zip class already loaded. Second attempt ignored.
INFO - 2018-11-03 13:32:56 --> Final output sent to browser
DEBUG - 2018-11-03 13:32:56 --> Total execution time: 14.7155
INFO - 2018-11-03 13:33:50 --> Config Class Initialized
INFO - 2018-11-03 13:33:50 --> Hooks Class Initialized
DEBUG - 2018-11-03 13:33:50 --> UTF-8 Support Enabled
INFO - 2018-11-03 13:33:50 --> Utf8 Class Initialized
INFO - 2018-11-03 13:33:50 --> URI Class Initialized
INFO - 2018-11-03 13:33:50 --> Router Class Initialized
INFO - 2018-11-03 13:33:50 --> Output Class Initialized
INFO - 2018-11-03 13:33:50 --> Security Class Initialized
DEBUG - 2018-11-03 13:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-03 13:33:50 --> CSRF cookie sent
INFO - 2018-11-03 13:33:50 --> Input Class Initialized
INFO - 2018-11-03 13:33:50 --> Language Class Initialized
INFO - 2018-11-03 13:33:50 --> Loader Class Initialized
INFO - 2018-11-03 13:33:50 --> Helper loaded: url_helper
INFO - 2018-11-03 13:33:50 --> Helper loaded: form_helper
INFO - 2018-11-03 13:33:50 --> Helper loaded: language_helper
DEBUG - 2018-11-03 13:33:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-03 13:33:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-03 13:33:50 --> User Agent Class Initialized
INFO - 2018-11-03 13:33:50 --> Controller Class Initialized
INFO - 2018-11-03 13:33:50 --> Helper loaded: file_helper
INFO - 2018-11-03 13:33:50 --> Helper loaded: directory_helper
INFO - 2018-11-03 13:33:50 --> Zip Compression Class Initialized
INFO - 2018-11-03 13:33:54 --> Database Driver Class Initialized
INFO - 2018-11-03 13:33:57 --> Database Utility Class Initialized
DEBUG - 2018-11-03 13:33:57 --> Zip class already loaded. Second attempt ignored.
INFO - 2018-11-03 13:34:06 --> Final output sent to browser
DEBUG - 2018-11-03 13:34:06 --> Total execution time: 15.8293
INFO - 2018-11-03 13:35:18 --> Config Class Initialized
INFO - 2018-11-03 13:35:18 --> Hooks Class Initialized
DEBUG - 2018-11-03 13:35:18 --> UTF-8 Support Enabled
INFO - 2018-11-03 13:35:18 --> Utf8 Class Initialized
INFO - 2018-11-03 13:35:18 --> URI Class Initialized
INFO - 2018-11-03 13:35:18 --> Router Class Initialized
INFO - 2018-11-03 13:35:18 --> Output Class Initialized
INFO - 2018-11-03 13:35:18 --> Security Class Initialized
DEBUG - 2018-11-03 13:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-03 13:35:18 --> CSRF cookie sent
INFO - 2018-11-03 13:35:18 --> Input Class Initialized
INFO - 2018-11-03 13:35:18 --> Language Class Initialized
INFO - 2018-11-03 13:35:18 --> Loader Class Initialized
INFO - 2018-11-03 13:35:18 --> Helper loaded: url_helper
INFO - 2018-11-03 13:35:18 --> Helper loaded: form_helper
INFO - 2018-11-03 13:35:18 --> Helper loaded: language_helper
DEBUG - 2018-11-03 13:35:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-03 13:35:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-03 13:35:18 --> User Agent Class Initialized
INFO - 2018-11-03 13:35:18 --> Controller Class Initialized
INFO - 2018-11-03 13:35:18 --> Helper loaded: file_helper
INFO - 2018-11-03 13:35:18 --> Helper loaded: directory_helper
INFO - 2018-11-03 13:35:18 --> Zip Compression Class Initialized
INFO - 2018-11-03 13:35:22 --> Database Driver Class Initialized
INFO - 2018-11-03 13:35:25 --> Database Utility Class Initialized
DEBUG - 2018-11-03 13:35:25 --> Zip class already loaded. Second attempt ignored.
INFO - 2018-11-03 13:35:34 --> Final output sent to browser
DEBUG - 2018-11-03 13:35:34 --> Total execution time: 15.6043
INFO - 2018-11-03 13:36:46 --> Config Class Initialized
INFO - 2018-11-03 13:36:46 --> Hooks Class Initialized
DEBUG - 2018-11-03 13:36:46 --> UTF-8 Support Enabled
INFO - 2018-11-03 13:36:46 --> Utf8 Class Initialized
INFO - 2018-11-03 13:36:46 --> URI Class Initialized
INFO - 2018-11-03 13:36:46 --> Router Class Initialized
INFO - 2018-11-03 13:36:46 --> Output Class Initialized
INFO - 2018-11-03 13:36:46 --> Security Class Initialized
DEBUG - 2018-11-03 13:36:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-03 13:36:46 --> CSRF cookie sent
INFO - 2018-11-03 13:36:46 --> Input Class Initialized
INFO - 2018-11-03 13:36:46 --> Language Class Initialized
INFO - 2018-11-03 13:36:46 --> Loader Class Initialized
INFO - 2018-11-03 13:36:46 --> Helper loaded: url_helper
INFO - 2018-11-03 13:36:46 --> Helper loaded: form_helper
INFO - 2018-11-03 13:36:46 --> Helper loaded: language_helper
DEBUG - 2018-11-03 13:36:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-03 13:36:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-03 13:36:46 --> User Agent Class Initialized
INFO - 2018-11-03 13:36:46 --> Controller Class Initialized
INFO - 2018-11-03 13:36:46 --> Helper loaded: file_helper
INFO - 2018-11-03 13:36:46 --> Helper loaded: directory_helper
INFO - 2018-11-03 13:36:46 --> Zip Compression Class Initialized
INFO - 2018-11-03 13:36:50 --> Database Driver Class Initialized
INFO - 2018-11-03 13:36:50 --> Database Utility Class Initialized
DEBUG - 2018-11-03 13:36:50 --> Zip class already loaded. Second attempt ignored.
INFO - 2018-11-03 13:36:57 --> Final output sent to browser
DEBUG - 2018-11-03 13:36:57 --> Total execution time: 10.8735
INFO - 2018-11-03 13:39:04 --> Config Class Initialized
INFO - 2018-11-03 13:39:04 --> Hooks Class Initialized
DEBUG - 2018-11-03 13:39:04 --> UTF-8 Support Enabled
INFO - 2018-11-03 13:39:04 --> Utf8 Class Initialized
INFO - 2018-11-03 13:39:04 --> URI Class Initialized
INFO - 2018-11-03 13:39:04 --> Router Class Initialized
INFO - 2018-11-03 13:39:04 --> Output Class Initialized
INFO - 2018-11-03 13:39:04 --> Security Class Initialized
DEBUG - 2018-11-03 13:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-03 13:39:04 --> CSRF cookie sent
INFO - 2018-11-03 13:39:04 --> Input Class Initialized
INFO - 2018-11-03 13:39:04 --> Language Class Initialized
INFO - 2018-11-03 13:39:04 --> Loader Class Initialized
INFO - 2018-11-03 13:39:04 --> Helper loaded: url_helper
INFO - 2018-11-03 13:39:04 --> Helper loaded: form_helper
INFO - 2018-11-03 13:39:04 --> Helper loaded: language_helper
DEBUG - 2018-11-03 13:39:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-03 13:39:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-03 13:39:04 --> User Agent Class Initialized
INFO - 2018-11-03 13:39:04 --> Controller Class Initialized
INFO - 2018-11-03 13:39:04 --> Helper loaded: file_helper
INFO - 2018-11-03 13:39:04 --> Helper loaded: directory_helper
INFO - 2018-11-03 13:39:04 --> Zip Compression Class Initialized
INFO - 2018-11-03 13:39:07 --> Database Driver Class Initialized
INFO - 2018-11-03 13:39:10 --> Database Utility Class Initialized
DEBUG - 2018-11-03 13:39:10 --> Zip class already loaded. Second attempt ignored.
INFO - 2018-11-03 13:39:18 --> Final output sent to browser
DEBUG - 2018-11-03 13:39:18 --> Total execution time: 14.7630
INFO - 2018-11-03 13:40:04 --> Config Class Initialized
INFO - 2018-11-03 13:40:04 --> Hooks Class Initialized
DEBUG - 2018-11-03 13:40:04 --> UTF-8 Support Enabled
INFO - 2018-11-03 13:40:04 --> Utf8 Class Initialized
INFO - 2018-11-03 13:40:04 --> URI Class Initialized
INFO - 2018-11-03 13:40:04 --> Router Class Initialized
INFO - 2018-11-03 13:40:04 --> Output Class Initialized
INFO - 2018-11-03 13:40:04 --> Security Class Initialized
DEBUG - 2018-11-03 13:40:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-03 13:40:04 --> CSRF cookie sent
INFO - 2018-11-03 13:40:04 --> Input Class Initialized
INFO - 2018-11-03 13:40:04 --> Language Class Initialized
INFO - 2018-11-03 13:40:04 --> Loader Class Initialized
INFO - 2018-11-03 13:40:04 --> Helper loaded: url_helper
INFO - 2018-11-03 13:40:04 --> Helper loaded: form_helper
INFO - 2018-11-03 13:40:04 --> Helper loaded: language_helper
DEBUG - 2018-11-03 13:40:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-03 13:40:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-03 13:40:04 --> User Agent Class Initialized
INFO - 2018-11-03 13:40:04 --> Controller Class Initialized
INFO - 2018-11-03 13:40:04 --> Helper loaded: file_helper
INFO - 2018-11-03 13:40:04 --> Helper loaded: directory_helper
INFO - 2018-11-03 13:40:04 --> Zip Compression Class Initialized
INFO - 2018-11-03 13:40:07 --> Database Driver Class Initialized
INFO - 2018-11-03 13:40:07 --> Database Utility Class Initialized
DEBUG - 2018-11-03 13:40:07 --> Zip class already loaded. Second attempt ignored.
INFO - 2018-11-03 13:40:13 --> Final output sent to browser
DEBUG - 2018-11-03 13:40:13 --> Total execution time: 8.2445
INFO - 2018-11-03 13:44:34 --> Config Class Initialized
INFO - 2018-11-03 13:44:34 --> Hooks Class Initialized
DEBUG - 2018-11-03 13:44:34 --> UTF-8 Support Enabled
INFO - 2018-11-03 13:44:34 --> Utf8 Class Initialized
INFO - 2018-11-03 13:44:34 --> URI Class Initialized
INFO - 2018-11-03 13:44:34 --> Router Class Initialized
INFO - 2018-11-03 13:44:34 --> Output Class Initialized
INFO - 2018-11-03 13:44:34 --> Security Class Initialized
DEBUG - 2018-11-03 13:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-03 13:44:34 --> CSRF cookie sent
INFO - 2018-11-03 13:44:34 --> Input Class Initialized
INFO - 2018-11-03 13:44:34 --> Language Class Initialized
INFO - 2018-11-03 13:44:34 --> Loader Class Initialized
INFO - 2018-11-03 13:44:34 --> Helper loaded: url_helper
INFO - 2018-11-03 13:44:34 --> Helper loaded: form_helper
INFO - 2018-11-03 13:44:34 --> Helper loaded: language_helper
DEBUG - 2018-11-03 13:44:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-03 13:44:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-03 13:44:34 --> User Agent Class Initialized
INFO - 2018-11-03 13:44:34 --> Controller Class Initialized
INFO - 2018-11-03 13:44:34 --> Helper loaded: file_helper
INFO - 2018-11-03 13:44:34 --> Helper loaded: directory_helper
INFO - 2018-11-03 13:44:34 --> Zip Compression Class Initialized
INFO - 2018-11-03 13:44:36 --> Database Driver Class Initialized
INFO - 2018-11-03 13:44:39 --> Database Utility Class Initialized
DEBUG - 2018-11-03 13:44:39 --> Zip class already loaded. Second attempt ignored.
ERROR - 2018-11-03 13:44:39 --> Severity: error --> Exception: Too few arguments to function BackupController::applications_copy(), 2 passed in E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php on line 30 and at least 3 expected E:\xampp7\htdocs\famiquity\application\controllers\BackupController.php 99
INFO - 2018-11-03 13:45:51 --> Config Class Initialized
INFO - 2018-11-03 13:45:51 --> Hooks Class Initialized
DEBUG - 2018-11-03 13:45:51 --> UTF-8 Support Enabled
INFO - 2018-11-03 13:45:51 --> Utf8 Class Initialized
INFO - 2018-11-03 13:45:51 --> URI Class Initialized
INFO - 2018-11-03 13:45:51 --> Router Class Initialized
INFO - 2018-11-03 13:45:51 --> Output Class Initialized
INFO - 2018-11-03 13:45:51 --> Security Class Initialized
DEBUG - 2018-11-03 13:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-03 13:45:51 --> CSRF cookie sent
INFO - 2018-11-03 13:45:51 --> Input Class Initialized
INFO - 2018-11-03 13:45:51 --> Language Class Initialized
INFO - 2018-11-03 13:45:51 --> Loader Class Initialized
INFO - 2018-11-03 13:45:51 --> Helper loaded: url_helper
INFO - 2018-11-03 13:45:51 --> Helper loaded: form_helper
INFO - 2018-11-03 13:45:51 --> Helper loaded: language_helper
DEBUG - 2018-11-03 13:45:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-03 13:45:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-03 13:45:51 --> User Agent Class Initialized
INFO - 2018-11-03 13:45:51 --> Controller Class Initialized
INFO - 2018-11-03 13:45:51 --> Helper loaded: file_helper
INFO - 2018-11-03 13:45:51 --> Helper loaded: directory_helper
INFO - 2018-11-03 13:45:51 --> Zip Compression Class Initialized
INFO - 2018-11-03 13:45:54 --> Database Driver Class Initialized
INFO - 2018-11-03 13:45:57 --> Database Utility Class Initialized
DEBUG - 2018-11-03 13:45:57 --> Zip class already loaded. Second attempt ignored.
INFO - 2018-11-03 13:46:06 --> Final output sent to browser
DEBUG - 2018-11-03 13:46:06 --> Total execution time: 14.7433
INFO - 2018-11-03 13:50:38 --> Config Class Initialized
INFO - 2018-11-03 13:50:38 --> Hooks Class Initialized
DEBUG - 2018-11-03 13:50:38 --> UTF-8 Support Enabled
INFO - 2018-11-03 13:50:38 --> Utf8 Class Initialized
INFO - 2018-11-03 13:50:38 --> URI Class Initialized
INFO - 2018-11-03 13:50:38 --> Router Class Initialized
INFO - 2018-11-03 13:50:38 --> Output Class Initialized
INFO - 2018-11-03 13:50:38 --> Security Class Initialized
DEBUG - 2018-11-03 13:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-03 13:50:38 --> CSRF cookie sent
INFO - 2018-11-03 13:50:38 --> Input Class Initialized
INFO - 2018-11-03 13:50:38 --> Language Class Initialized
INFO - 2018-11-03 13:50:38 --> Loader Class Initialized
INFO - 2018-11-03 13:50:38 --> Helper loaded: url_helper
INFO - 2018-11-03 13:50:38 --> Helper loaded: form_helper
INFO - 2018-11-03 13:50:38 --> Helper loaded: language_helper
DEBUG - 2018-11-03 13:50:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-03 13:50:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-03 13:50:38 --> User Agent Class Initialized
INFO - 2018-11-03 13:50:38 --> Controller Class Initialized
INFO - 2018-11-03 13:50:38 --> Helper loaded: file_helper
INFO - 2018-11-03 13:50:38 --> Helper loaded: directory_helper
INFO - 2018-11-03 13:50:38 --> Zip Compression Class Initialized
INFO - 2018-11-03 13:50:41 --> Database Driver Class Initialized
INFO - 2018-11-03 13:50:44 --> Database Utility Class Initialized
DEBUG - 2018-11-03 13:50:44 --> Zip class already loaded. Second attempt ignored.
INFO - 2018-11-03 13:50:52 --> Final output sent to browser
DEBUG - 2018-11-03 13:50:52 --> Total execution time: 14.4505
INFO - 2018-11-03 13:51:38 --> Config Class Initialized
INFO - 2018-11-03 13:51:38 --> Hooks Class Initialized
DEBUG - 2018-11-03 13:51:38 --> UTF-8 Support Enabled
INFO - 2018-11-03 13:51:38 --> Utf8 Class Initialized
INFO - 2018-11-03 13:51:38 --> URI Class Initialized
INFO - 2018-11-03 13:51:38 --> Router Class Initialized
INFO - 2018-11-03 13:51:38 --> Output Class Initialized
INFO - 2018-11-03 13:51:38 --> Security Class Initialized
DEBUG - 2018-11-03 13:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-03 13:51:38 --> CSRF cookie sent
INFO - 2018-11-03 13:51:38 --> Input Class Initialized
INFO - 2018-11-03 13:51:38 --> Language Class Initialized
INFO - 2018-11-03 13:51:38 --> Loader Class Initialized
INFO - 2018-11-03 13:51:38 --> Helper loaded: url_helper
INFO - 2018-11-03 13:51:38 --> Helper loaded: form_helper
INFO - 2018-11-03 13:51:38 --> Helper loaded: language_helper
DEBUG - 2018-11-03 13:51:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-03 13:51:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-03 13:51:38 --> User Agent Class Initialized
INFO - 2018-11-03 13:51:38 --> Controller Class Initialized
INFO - 2018-11-03 13:51:38 --> Helper loaded: file_helper
INFO - 2018-11-03 13:51:38 --> Helper loaded: directory_helper
INFO - 2018-11-03 13:51:38 --> Zip Compression Class Initialized
INFO - 2018-11-03 13:51:41 --> Database Driver Class Initialized
INFO - 2018-11-03 13:51:44 --> Database Utility Class Initialized
DEBUG - 2018-11-03 13:51:44 --> Zip class already loaded. Second attempt ignored.
INFO - 2018-11-03 13:51:45 --> Config Class Initialized
INFO - 2018-11-03 13:51:45 --> Hooks Class Initialized
DEBUG - 2018-11-03 13:51:45 --> UTF-8 Support Enabled
INFO - 2018-11-03 13:51:45 --> Utf8 Class Initialized
INFO - 2018-11-03 13:51:45 --> URI Class Initialized
DEBUG - 2018-11-03 13:51:45 --> No URI present. Default controller set.
INFO - 2018-11-03 13:51:45 --> Router Class Initialized
INFO - 2018-11-03 13:51:45 --> Output Class Initialized
INFO - 2018-11-03 13:51:45 --> Security Class Initialized
DEBUG - 2018-11-03 13:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-03 13:51:45 --> CSRF cookie sent
INFO - 2018-11-03 13:51:45 --> Input Class Initialized
INFO - 2018-11-03 13:51:45 --> Language Class Initialized
INFO - 2018-11-03 13:51:45 --> Loader Class Initialized
INFO - 2018-11-03 13:51:45 --> Helper loaded: url_helper
INFO - 2018-11-03 13:51:45 --> Helper loaded: form_helper
INFO - 2018-11-03 13:51:45 --> Helper loaded: language_helper
DEBUG - 2018-11-03 13:51:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-03 13:51:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-03 13:51:45 --> User Agent Class Initialized
INFO - 2018-11-03 13:51:45 --> Controller Class Initialized
INFO - 2018-11-03 13:51:45 --> Helper loaded: directory_helper
INFO - 2018-11-03 13:51:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-11-03 13:51:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-11-03 13:51:45 --> Helper loaded: custom_helper
INFO - 2018-11-03 13:51:45 --> Pixel_Model class loaded
INFO - 2018-11-03 13:51:45 --> Database Driver Class Initialized
INFO - 2018-11-03 13:51:45 --> Model "QuestionsModel" initialized
INFO - 2018-11-03 13:51:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-11-03 13:51:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-11-03 13:51:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-11-03 13:51:45 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-11-03 13:51:45 --> Final output sent to browser
DEBUG - 2018-11-03 13:51:45 --> Total execution time: 0.1104
INFO - 2018-11-03 13:53:33 --> Config Class Initialized
INFO - 2018-11-03 13:53:33 --> Hooks Class Initialized
DEBUG - 2018-11-03 13:53:33 --> UTF-8 Support Enabled
INFO - 2018-11-03 13:53:33 --> Utf8 Class Initialized
INFO - 2018-11-03 13:53:33 --> URI Class Initialized
DEBUG - 2018-11-03 13:53:33 --> No URI present. Default controller set.
INFO - 2018-11-03 13:53:33 --> Router Class Initialized
INFO - 2018-11-03 13:53:33 --> Output Class Initialized
INFO - 2018-11-03 13:53:33 --> Security Class Initialized
DEBUG - 2018-11-03 13:53:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-03 13:53:33 --> CSRF cookie sent
INFO - 2018-11-03 13:53:33 --> Input Class Initialized
INFO - 2018-11-03 13:53:33 --> Language Class Initialized
INFO - 2018-11-03 13:53:33 --> Loader Class Initialized
INFO - 2018-11-03 13:53:33 --> Helper loaded: url_helper
INFO - 2018-11-03 13:53:33 --> Helper loaded: form_helper
INFO - 2018-11-03 13:53:33 --> Helper loaded: language_helper
DEBUG - 2018-11-03 13:53:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-03 13:53:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-03 13:53:33 --> User Agent Class Initialized
INFO - 2018-11-03 13:53:33 --> Controller Class Initialized
INFO - 2018-11-03 13:53:33 --> Helper loaded: directory_helper
INFO - 2018-11-03 13:53:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-11-03 13:53:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-11-03 13:53:33 --> Helper loaded: custom_helper
INFO - 2018-11-03 13:53:33 --> Pixel_Model class loaded
INFO - 2018-11-03 13:53:33 --> Database Driver Class Initialized
INFO - 2018-11-03 13:53:36 --> Model "QuestionsModel" initialized
INFO - 2018-11-03 13:53:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_basic_nav.php
INFO - 2018-11-03 13:53:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_header.php
INFO - 2018-11-03 13:53:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\home.php
INFO - 2018-11-03 13:53:36 --> File loaded: E:\xampp7\htdocs\famiquity\application\views\shared/_footer.php
INFO - 2018-11-03 13:53:36 --> Final output sent to browser
DEBUG - 2018-11-03 13:53:36 --> Total execution time: 3.1812
INFO - 2018-11-03 13:53:39 --> Config Class Initialized
INFO - 2018-11-03 13:53:39 --> Hooks Class Initialized
DEBUG - 2018-11-03 13:53:39 --> UTF-8 Support Enabled
INFO - 2018-11-03 13:53:39 --> Utf8 Class Initialized
INFO - 2018-11-03 13:53:39 --> URI Class Initialized
INFO - 2018-11-03 13:53:39 --> Router Class Initialized
INFO - 2018-11-03 13:53:39 --> Output Class Initialized
INFO - 2018-11-03 13:53:39 --> Security Class Initialized
DEBUG - 2018-11-03 13:53:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-03 13:53:39 --> CSRF cookie sent
INFO - 2018-11-03 13:53:39 --> Input Class Initialized
INFO - 2018-11-03 13:53:39 --> Language Class Initialized
INFO - 2018-11-03 13:53:39 --> Loader Class Initialized
INFO - 2018-11-03 13:53:39 --> Helper loaded: url_helper
INFO - 2018-11-03 13:53:39 --> Helper loaded: form_helper
INFO - 2018-11-03 13:53:39 --> Helper loaded: language_helper
DEBUG - 2018-11-03 13:53:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-03 13:53:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-03 13:53:39 --> User Agent Class Initialized
INFO - 2018-11-03 13:53:39 --> Controller Class Initialized
INFO - 2018-11-03 13:53:39 --> Helper loaded: file_helper
INFO - 2018-11-03 13:53:39 --> Helper loaded: directory_helper
INFO - 2018-11-03 13:53:39 --> Zip Compression Class Initialized

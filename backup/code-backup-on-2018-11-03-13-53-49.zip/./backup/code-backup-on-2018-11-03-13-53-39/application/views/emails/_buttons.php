<table border="0" cellspacing="0" cellpadding="0" style="float:left; margin-right:10px;">
	<tr>
	  <td><a href="<?php Smart::echoString($param['link']); ?>" style="font-size: 16px; font-family: 'Open Sans', Arial, sans-serif; color: #ffffff; text-decoration: none; background-color: #9f0003; border-top: 15px solid #9f0003; border-bottom: 15px solid #9f0003; border-right: 18px solid #9f0003; border-left: 18px solid #9f0003; display: inline-block;text-shadow: 1px 1px #333333;"><?php Smart::echoString($param['text']); ?></a></td>
	</tr>
</table>
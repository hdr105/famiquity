<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
		<meta charset="utf-8">
        
            <meta name="viewport" content="width=device-width, initial-scale=1.0">	
                <title><?php Smart::echoString($heading); ?></title>
                <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600,700" rel='stylesheet' type='text/css'>

                        <style type="text/css">
                            img { height:auto; }
                            @media only screen and (max-width: 550px), screen and (max-device-width: 550px) {
                                .mobile-td{ text-align:center!important; }
                                .mobile-img{ margin-left:auto!important; margin-right:auto!important; }
                                .responsive{ width:100%!important; float:left;  }	
                            }
                        </style>		
                        </head>
                        <body bgcolor="#F8F8F8" border="0" cell cellspacing="0"  >

                            <!--[if (gte mso 9)|(IE)]>
                              <table width="600" align="center" cell cellspacing="0" border="0">
                                    <tr>
                                      <td>
                            <![endif]-->	
                            <table bgcolor="#faf2e3" width="100%" style="max-width:595px; margin:10px auto;" cell cellspacing="0"  ><tr><td align="center" valign="top">
                                        <table width="100%" bgcolor="#9f0003" cell cellspacing="0" border="0">
                                            
                                            <tr><td height="100" width="100%" bgcolor="#9f0003" style="padding-left:20px;padding-right:20px;" valign="middle" class="mobile-td">
                                                    <a href="<?php echo base_url();?>" target="_blank">
                                                        <img align="top" alt="" border="0" src="" title="" class="mobile-img" />
                                                        <img src="<?php echo base_url("assets/images/email-logo.png") ?>" alt=""/>
                                                    </a>
                                                </td></tr>
                                        </table>

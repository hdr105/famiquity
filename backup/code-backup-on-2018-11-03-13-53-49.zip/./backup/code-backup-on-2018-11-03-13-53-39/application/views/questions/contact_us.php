<?php $this->load->view('shared/_page_banner_empty'); ?>
<section class="gray-bg page-section-ptb o-hidden">
    <?php $this->load->view('shared/_page_header', array("txt1" => "", "txt2" => "Contact Us", "txt3" => "")); ?>
    <div class="container form-margin">
        <div class="row">
            <div class="col-md-8 col-md-offset-2 text-center">
                <h1 class="text-center">Please contact our Client Experience Team at cx@famiquity.com to discuss further</h1>
                <p>Famiquity is not operational, and will be launching soon.  Please review our <a href="<?php echo base_url('terms-and-conditions'); ?>"><strong>Terms</strong></a> regarding the answers you have provided thus far</p>
                <div id="register-form" class="register-form">
                    <br>
                    <div class="section-field text-center">
                      
                       
                    </div> 
                </div>
                
            </div>
        </div>
    </div>

</section>
<?php $this->load->view('shared/_page_banner', array("heading" => "Registration Completed", "desc" => "We know the secret of your success", "image" => Smart::loadImages('bg/02.jpg'))); ?>
<section class="gray-bg page-section-ptb o-hidden">
    <?php $this->load->view('shared/_page_header', array("txt1" => "", "txt2" => "Activate Your Account", "txt3" => "We know the secret of your success")); ?>
    <div class="container form-margin">

        <div class="row">

            
            <div class="col-md-6 col-md-offset-3">
                Thank you for registering with us, an activation email has been sent to you along with the activation information, please activate your account.
            </div>
            
        </div>
    </div>
</section>
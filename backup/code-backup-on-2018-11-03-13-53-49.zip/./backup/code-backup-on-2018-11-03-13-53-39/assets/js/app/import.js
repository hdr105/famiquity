$(function() {
    CKEDITOR.replaceClass = 'cke';
    /*$("#letter_type").on('change', function(){
        var body = $(this).find(':selected').data('body')
        var subject = $(this).find(':selected').data('subject')
        //alert(body);
        $("#subject").val(subject);
        CKEDITOR.instances['message'].setData(body);
        //CKEDITOR.replaceClass = 'cke';
    });*/
});